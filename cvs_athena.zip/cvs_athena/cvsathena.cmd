;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

[Command]
name = "CPU31"
command = U, D, F, U, D
time = 1

[Command]
name = "CPU32"
command = U, B, F, U, D
time = 1

[Command]
name = "CPU33"
command = U, D, D, U, D
time = 1

[Command]
name = "CPU34"
command = F, B, U, U, D
time = 1

[Command]
name = "CPU35"
command = U, F, U, B, U, D
time = 1

[Command]
name = "CPU36"
command = U, D, B, U, D
time = 1

[Command]
name = "CPU37"
command = F, F, B, U, D
time = 1

[Command]
name = "CPU38"
command = U, D, U, U, D
time = 1

[Command]
name = "CPU39"
command = F, B, B, U, D
time = 1

[Command]
name = "CPU40"
command = F, F, B, B, U, D
time = 1

[Command]
name = "CPU41"
command = U, U, F, U, D
time = 1

[Command]
name = "CPU42"
command = U, B, B, U, D
time = 1

[Command]
name = "CPU43"
command = U, B, F, F, U, D
time = 1

[Command]
name = "CPU44"
command = U, F, B, U, U, D
time = 1

[Command]
name = "CPU45"
command = U, B, F, U, U, D
time = 1

[Command]
name = "CPU46"
command = U, B, B, B, U, D
time = 1

[Command]
name = "CPU47"
command = U, D, B, F, U, D
time = 1

[Command]
name = "CPU48"
command = U, D, B, D, U, D
time = 1

[Command]
name = "CPU49"
command = U, D, F, U, U, D
time = 1

[Command]
name = "CPU50"
command = U, D, U, B, U, D
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "�V���C�j���O�N���X�^���r�b�g1"
command = ~F, D, B, F, D, B, x
time = 30

[Command]
name = "�V���C�j���O�N���X�^���r�b�g1"
command = ~F, D, B, F, D, B, ~x
time = 30

[Command]
name = "�V���C�j���O�N���X�^���r�b�g2"
command = ~F, D, B, F, D, B, y
time = 30

[Command]
name = "�V���C�j���O�N���X�^���r�b�g2"
command = ~F, D, B, F, D, B, ~y
time = 30

[Command]
name = "�V���C�j���O�N���X�^���r�b�g3"
command = ~F, D, B, F, D, B, z
time = 30

[Command]
name = "�V���C�j���O�N���X�^���r�b�g3"
command = ~F, D, B, F, D, B, ~z
time = 30

[Command]
name = "�t�F�j�b�N�X�t�@���O�A���[1"
command = ~D, DF, F, D, DF, a
time = 21

[Command]
name = "�t�F�j�b�N�X�t�@���O�A���[1"
command = ~D, DF, F, D, DF, ~a
time = 21

[Command]
name = "�t�F�j�b�N�X�t�@���O�A���[2"
command = ~D, DF, F, D, DF, b
time = 21

[Command]
name = "�t�F�j�b�N�X�t�@���O�A���[2"
command = ~D, DF, F, D, DF, ~b
time = 21

[Command]
name = "�t�F�j�b�N�X�t�@���O�A���[3"
command = ~D, DF, F, D, DF, c
time = 21

[Command]
name = "�t�F�j�b�N�X�t�@���O�A���[3"
command = ~D, DF, F, D, DF, ~c
time = 21

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "�T�C�R�{�[���A�^�b�N1"
command = ~D, DB, B, x
time = 12

[Command]
name = "�T�C�R�{�[���A�^�b�N1"
command = ~D, DB, B, ~x
time = 12

[Command]
name = "�T�C�R�{�[���A�^�b�N2"
command = ~D, DB, B, y
time = 12

[Command]
name = "�T�C�R�{�[���A�^�b�N2"
command = ~D, DB, B, ~y
time = 12

[Command]
name = "�T�C�R�{�[���A�^�b�N3"
command = ~D, DB, B, z
time = 12

[Command]
name = "�T�C�R�{�[���A�^�b�N3"
command = ~D, DB, B, ~z
time = 12

[Command]
name = "�X�[�p�[�T�C�L�b�N�X���["
command = ~B, DB, D, DF, F, x
time = 18

[Command]
name = "�X�[�p�[�T�C�L�b�N�X���["
command = ~B, DB, D, DF, F, ~x
time = 18

[Command]
name = "�X�[�p�[�T�C�L�b�N�X���["
command = ~B, DB, D, DF, F, y
time = 18

[Command]
name = "�X�[�p�[�T�C�L�b�N�X���["
command = ~B, DB, D, DF, F, ~y
time = 18

[Command]
name = "�X�[�p�[�T�C�L�b�N�X���["
command = ~B, DB, D, DF, F, z
time = 18

[Command]
name = "�X�[�p�[�T�C�L�b�N�X���["
command = ~B, DB, D, DF, F, ~z
time = 18

[Command]
name = "�T�C�R�\�[�h1"
command = ~F, D, DF, x
time = 12

[Command]
name = "�T�C�R�\�[�h1"
command = ~F, D, DF, ~x
time = 12

[Command]
name = "�T�C�R�\�[�h2"
command = ~F, D, DF, y
time = 12

[Command]
name = "�T�C�R�\�[�h2"
command = ~F, D, DF, ~y
time = 12

[Command]
name = "�T�C�R�\�[�h3"
command = ~F, D, DF, z
time = 12

[Command]
name = "�T�C�R�\�[�h3"
command = ~F, D, DF, ~z
time = 12

[Command]
name = "�T�C�R�e���|�[�g1"
command = ~D, DF, F, a
time = 12

[Command]
name = "�T�C�R�e���|�[�g1"
command = ~D, DF, F, ~a
time = 12

[Command]
name = "�T�C�R�e���|�[�g2"
command = ~D, DF, F, b
time = 12

[Command]
name = "�T�C�R�e���|�[�g2"
command = ~D, DF, F, ~b
time = 12

[Command]
name = "�T�C�R�e���|�[�g3"
command = ~D, DF, F, c
time = 12

[Command]
name = "�T�C�R�e���|�[�g3"
command = ~D, DF, F, ~c
time = 12

[Command]
name = "�˃T�C�R���t���N�^�[1"
command = ~F, DF, D, DB, B, a
time = 18

[Command]
name = "�˃T�C�R���t���N�^�[1"
command = ~F, DF, D, DB, B, ~a
time = 18

[Command]
name = "�˃T�C�R���t���N�^�[2"
command = ~F, DF, D, DB, B, b
time = 18

[Command]
name = "�˃T�C�R���t���N�^�[2"
command = ~F, DF, D, DB, B, ~b
time = 18

[Command]
name = "�˃T�C�R���t���N�^�[3"
command = ~F, DF, D, DB, B, c
time = 18

[Command]
name = "�˃T�C�R���t���N�^�[3"
command = ~F, DF, D, DB, B, ~c
time = 18

[Command]
name = "�t�F�j�b�N�X�A���[1"
command = ~D, DB, B, a
time = 12

[Command]
name = "�t�F�j�b�N�X�A���[1"
command = ~D, DB, B, ~a
time = 12

[Command]
name = "�t�F�j�b�N�X�A���[2"
command = ~D, DB, B, b
time = 12

[Command]
name = "�t�F�j�b�N�X�A���[2"
command = ~D, DB, B, ~b
time = 12

[Command]
name = "�t�F�j�b�N�X�A���[3"
command = ~D, DB, B, c
time = 12

[Command]
name = "�t�F�j�b�N�X�A���[3"
command = ~D, DB, B, ~c
time = 12

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 10

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

[Command]
name = "������~"
command = x+y
time = 10

[Command]
name = "������~"
command = y+z
time = 10

[Command]
name = "������~"
command = z+x
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;---------------------------------------------------------------------------
;�V���C�j���O�N���X�^���r�b�g
[State -1, ball]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1205) && !NumProjID(3055)
triggerall = Command = "�V���C�j���O�N���X�^���r�b�g1" || Command = "�V���C�j���O�N���X�^���r�b�g2" || Command = "�V���C�j���O�N���X�^���r�b�g3"
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A || (statetype = A && !(var(0)&2**5))
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2)
trigger19 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(10) < 0))
trigger21 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(9) < 0))
trigger22 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger23 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(10) < 0))
trigger24 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger25 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger26 = StateNo = 300 && (((var(36) = 1||var(36) = 2) && time <= 2) || (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2))
trigger27 = StateNo = 700 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger28 = StateNo = 195 && var(36) && var(16)
trigger29 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger30 = (StateNo = [1600,2999]) && var(36) && var(16)
trigger31 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger32 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger33 = (StateNo = [1000,1499]) && (var(20) = 2 || var(20) = 6)
trigger34 = (StateNo = [1600,2999]) && var(36) && var(16)
trigger35 = (StateNo = [3200,3299]) && (var(20) = 2 || var(20) = 6) && time > 44
trigger36 = StateNo = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�N���X�^���V���[�g
[State -1, ball]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�T�C�R�{�[���A�^�b�N1" || Command = "�T�C�R�{�[���A�^�b�N2" || Command = "�T�C�R�{�[���A�^�b�N3"
triggerall = stateno = 3000 && AnimElemTime(4) > 0
trigger1 = AnimElemTime(27) < 0 && !var(5)
trigger2 = AnimElemTime(35) < 0 && var(5) = 1
trigger3 = AnimElemTime(43) < 0 && var(5) = 2
ignorehitpause = 0

;---------------------------------------------------------------------------
;�t�F�j�b�N�X�t�@���O�A���[
[State -1, ball]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1006)
triggerall = Command = "�t�F�j�b�N�X�t�@���O�A���[1" || Command = "�t�F�j�b�N�X�t�@���O�A���[2" || Command = "�t�F�j�b�N�X�t�@���O�A���[3"
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype = A
triggerall = !(var(0)&2**5)
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(10) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(9) < 0))
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(10) < 0))
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger8 = StateNo = 700 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger9 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger10 = (StateNo = [1600,2999]) && var(36) && var(16)
trigger11 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger12 = (StateNo = [1000,1499]) && (var(20) = 2 || var(20) = 6)
trigger13 = (StateNo = [1600,2999]) && (var(20) = 2 || var(20) = 6)
trigger14 = (StateNo = [3000,3199]) && (var(20) = 2 || var(20) = 6) && time > 44
trigger15 = StateNo = 701
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�X�[�p�[�T�C�L�b�N�X���[
[State -1, ball]
type = ChangeState
value = 1500
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�X�[�p�[�T�C�L�b�N�X���["
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2)
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2)
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger21 = StateNo = 195 && var(36) && var(16)
trigger22 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger23 = (StateNo = [1600,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�T�C�L�b�N�e���|�[�g
[State -1, ball]
type = ChangeState
value = 1400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�T�C�R�e���|�[�g1" || Command = "�T�C�R�e���|�[�g2" || Command = "�T�C�R�e���|�[�g3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2)
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2)
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger21 = StateNo = 195 && var(36) && var(16)
trigger22 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger23 = (StateNo = [1600,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�˃T�C�R���t���N�^�[
[State -1, ball]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1205) && !NumProjID(3055)
triggerall = Command = "�˃T�C�R���t���N�^�[1" || Command = "�˃T�C�R���t���N�^�[2" || Command = "�˃T�C�R���t���N�^�[3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2)
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2)
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger21 = StateNo = 195 && var(36) && var(16)
trigger22 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger23 = (StateNo = [1600,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�T�C�R�\�[�h
[State -1, ball]
type = ChangeState
value = 1300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�T�C�R�\�[�h1" || Command = "�T�C�R�\�[�h2" || Command = "�T�C�R�\�[�h3"
triggerall = statetype != A || (statetype = A && !(var(0)&2**5))
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2)
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2)
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(10) < 0))
trigger21 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(9) < 0))
trigger22 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger23 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger24 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger25 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger26 = StateNo = 300 && (var(16) || time <= 2)
trigger27 = StateNo = 700 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger28 = StateNo = 195 && var(36) && var(16)
trigger29 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger30 = (StateNo = [1600,2999]) && var(36) && var(16)
trigger31 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger32 = StateNo = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�t�F�j�b�N�X�A���[
[State -1, ball]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�t�F�j�b�N�X�A���[1" || Command = "�t�F�j�b�N�X�A���[2" || Command = "�t�F�j�b�N�X�A���[3"
triggerall = statetype = A
triggerall = !(var(0)&2**5)
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(10) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(9) < 0))
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger8 = StateNo = 700 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger9 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger10 = (StateNo = [1600,2999]) && var(36) && var(16)
trigger11 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger12 = StateNo = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�T�C�R�{�[���A�^�b�N
[State -1, ball]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1205) && !NumProjID(3055)
triggerall = Command = "�T�C�R�{�[���A�^�b�N1" || Command = "�T�C�R�{�[���A�^�b�N2" || Command = "�T�C�R�{�[���A�^�b�N3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2)
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2)
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger21 = StateNo = 195 && var(36) && var(16)
trigger22 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger23 = (StateNo = [1600,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2)
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2)
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger21 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger22 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5200
triggerall = !var(59)
triggerall = !(var(0)&2**10)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2
trigger21 = (StateNo = [195,799]) && var(36) && var(16)
trigger22 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2
trigger21 = (StateNo = [195,799]) && var(36) && var(16)
trigger22 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time <= 2
trigger3 = StateNo = 610 && time <= 2
trigger4 = StateNo = 620 && time <= 2
trigger5 = StateNo = 630 && time <= 2
trigger6 = StateNo = 640 && time <= 2
trigger7 = StateNo = 650 && time <= 2
trigger8 = StateNo = 700 && time <= 2

;---------------------------------------------------------------------------
;�O�p����
[State -1, Run Back]
type = ChangeState
value = 48
triggerall = !var(59)
triggerall = command = "holdup"
triggerall = stateno = 50 && prevstateno != 48
triggerall = pos y < -20
trigger1 = frontedgebodydist < 5 && command = "holdback"
trigger2 = backedgebodydist < 5 && command = "holdfwd"

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;�T�C�L�b�N�V���[�g
[State -1, Throw]
type = ChangeState
value = 920
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback" || command = "holddown") && command = "z"
triggerall = statetype = A
triggerall = ctrl
triggerall = P2bodydist X = [-const(size.ground.front),9]
triggerall = P2bodydist Y = [-68,-enemynear,const(size.head.pos.y)-60]
trigger1 = p2statetype = A
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;�A��
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 211 && (var(36) = 1||var(36) = 2)
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�t�F�j�b�N�X�{��
[State -1]
type = ChangeState
value = 700
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = vel X > 0
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ���������p���`
[State -1, Taunt]
type = ChangeState
value = 201
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 201 && time > 4
trigger4 = StateNo = 400 && time > 4
trigger5 = StateNo = 430 && time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 201 && time > 4
trigger4 = StateNo = 400 && time > 4
trigger5 = StateNo = 430 && time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-30,30]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�ߋ���������L�b�N
[State -1, Taunt]
type = ChangeState
value = 231
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 201 && time > 4
trigger4 = StateNo = 400 && time > 4
trigger5 = StateNo = 430 && time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 201 && time > 4
trigger4 = StateNo = 400 && time > 4
trigger5 = StateNo = 430 && time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 251
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 251
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-30,30]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 201 && time > 4
trigger4 = StateNo = 400 && time > 4
trigger5 = StateNo = 430 && time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 201 && time > 4
trigger4 = StateNo = 400 && time > 4
trigger5 = StateNo = 430 && time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 701
ignorehitpause = 0
  
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
