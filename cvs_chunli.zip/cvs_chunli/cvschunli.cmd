;-| �b�o�t |-----------------------------------------------------------
[Command]
name = "cpu1"
command = D, F,DF
time = 1

[Command]
name = "cpu2"
command = D, F,F
time = 1

[Command]
name = "cpu3"
command = D, B, F
time = 1

[Command]
name = "cpu4"
command = D, B, B
time = 1

[Command]
name = "cpu5"
command = D, DB, U
time = 1

[Command]
name = "cpu6"
command = D, U, F
time = 1

[Command]
name = "cpu7"
command = D, U, U
time = 1

[Command]
name = "cpu8"
command = D, B, D
time = 1

[Command]
name = "cpu9"
command = D, D, B
time = 1

[Command]
name = "cpu10"
command = D, UB, F
time = 1

[Command]
name = "cpu11"
command = B, F,DF
time = 1

[Command]
name = "cpu12"
command = B, F,F
time = 1

[Command]
name = "cpu13"
command = B, B, F
time = 1

[Command]
name = "cpu14"
command = B, B, B
time = 1

[Command]
name = "cpu15"
command = B, DB, U
time = 1

[Command]
name = "cpu16"
command = B, U, F
time = 1

[Command]
name = "cpu17"
command = B, U, U
time = 1

[Command]
name = "cpu18"
command = B, B, D
time = 1

[Command]
name = "cpu19"
command = B, D, B
time = 1

[Command]
name = "cpu20"
command = B, UB, F
time = 1

[Command]
name = "cpu21"
command = F, F,DF
time = 1

[Command]
name = "cpu22"
command = F, F, F
time = 1

[Command]
name = "cpu23"
command = F, B, F
time = 1

[Command]
name = "cpu24"
command = F, B, B
time = 1

[Command]
name = "cpu25"
command = F, DB, U
time = 1

[Command]
name = "cpu26"
command = F, U, F
time = 1

[Command]
name = "cpu27"
command = F, U, U
time = 1

[Command]
name = "cpu28"
command = F, B, D
time = 1

[Command]
name = "cpu29"
command = F, D, B
time = 1

[Command]
name = "cpu30"
command = F, UB, F
time = 1

[Command]
name = "cpu31"
command = U, F,DF
time = 1

[Command]
name = "cpu32"
command = U, F, F
time = 1

[Command]
name = "cpu33"
command = U, B, F
time = 1

[Command]
name = "cpu34"
command = U, B, B
time = 1

[Command]
name = "cpu35"
command = U, DB, U
time = 1

[Command]
name = "cpu36"
command = U, U, F
time = 1

[Command]
name = "cpu37"
command = U, U, U
time = 1

[Command]
name = "cpu38"
command = U, B, D
time = 1

[Command]
name = "cpu39"
command = U, D, B
time = 1

[Command]
name = "cpu40"
command = U, UB, F
time = 1

[Command]
name = "cpu41"
command = x, b, F,F
time = 1

[Command]
name = "cpu42"
command = c, F, F
time = 1

[Command]
name = "cpu43"
command = B, U, b,y
time = 1

[Command]
name = "cpu44"
command = B, B, c
time = 1

[Command]
name = "cpu45"
command = x, DB, y
time = 1

[Command]
name = "cpu46"
command = F, s, U
time = 1

[Command]
name = "cpu47"
command = U, x, s
time = 1

[Command]
name = "cpu48"
command = U, y, D
time = 1

[Command]
name = "cpu49"
command = U, F, B,b
time = 1

[Command]
name = "cpu50"
command = c, UB, z
time = 1
;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "houyoku1"
command = ~D, DF, F, D, DF, a
time = 21

[Command]
name = "houyoku1"
command = ~D, DF, F, D, DF, ~a
time = 21

[Command]
name = "houyoku2"
command = ~D, DF, F, D, DF, b
time = 21

[Command]
name = "houyoku2"
command = ~D, DF, F, D, DF, ~b
time = 21

[Command]
name = "houyoku3"
command = ~D, DF, F, D, DF, c
time = 21

[Command]
name = "houyoku3"
command = ~D, DF, F, D, DF, ~c
time = 21

[Command]
name = "kikoushou1"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "kikoushou1"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "kikoushou2"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "kikoushou2"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "kikoushou3"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "kikoushou3"
command = ~D, DF, F, D, DF, ~z
time = 21

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "kikou1"
command = ~D, DF, F, x
time = 20

[Command]
name = "kikou1"
command = ~D, DF, F, ~x
time = 20

[Command]
name = "kikou2"
command = ~D, DF, F, y
time = 20

[Command]
name = "kikou2"
command = ~D, DF, F, ~y
time = 20

[Command]
name = "kikou3"
command = ~D, DF, F, z
time = 20

[Command]
name = "kikou3"
command = ~D, DF, F, ~z
time = 20

[Command]
name = "spining1"
command = ~36$D, $U, a
time = 12

[Command]
name = "spining1"
command = ~36$D, $U, ~a
time = 12

[Command]
name = "spining2"
command = ~36$D, $U, b
time = 12

[Command]
name = "spining2"
command = ~36$D, $U, ~b
time = 12

[Command]
name = "spining3"
command = ~36$D, $U, c
time = 12

[Command]
name = "spining3"
command = ~36$D, $U, ~c
time = 12

[Command]
name = "spining4"
command = ~$D, $U, a
time = 12

[Command]
name = "spining4"
command = ~$D, $U, ~a
time = 12

[Command]
name = "spining5"
command = ~$D, $U, b
time = 12

[Command]
name = "spining5"
command = ~$D, $U, ~b
time = 12

[Command]
name = "spining6"
command = ~$D, $U, c
time = 12

[Command]
name = "spining6"
command = ~$D, $U, ~c
time = 12

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 18

[Command]
name = "FF"     
command = F, F
time = 12

[Command]
name = "BB"     
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;~~~~~~~~CPU~~~~~~~~~
;===========================================================================
;---------------------------------------------------------------------------
[State -1]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "cpu1"
trigger2  = command = "cpu2"
trigger3  = command = "cpu3"
trigger4  = command = "cpu4"
trigger5  = command = "cpu5"
trigger6  = command = "cpu6"
trigger7  = command = "cpu7"
trigger8  = command = "cpu8"
trigger9  = command = "cpu9"
trigger10  = command = "cpu10"
trigger11  = command = "cpu11"
trigger12  = command = "cpu12"
trigger13  = command = "cpu13"
trigger14  = command = "cpu14"
trigger15  = command = "cpu15"
trigger16  = command = "cpu16"
trigger17  = command = "cpu17"
trigger18  = command = "cpu18"
trigger19  = command = "cpu19"
trigger20  = command = "cpu20"
trigger21  = command = "cpu21"
trigger22  = command = "cpu22"
trigger23  = command = "cpu23"
trigger24  = command = "cpu24"
trigger25  = command = "cpu25"
trigger26  = command = "cpu26"
trigger27  = command = "cpu27"
trigger28  = command = "cpu28"
trigger29  = command = "cpu29"
trigger30  = command = "cpu30"
trigger31  = command = "cpu31"
trigger32  = command = "cpu32"
trigger33  = command = "cpu33"
trigger34  = command = "cpu34"
trigger35  = command = "cpu35"
trigger36  = command = "cpu36"
trigger37  = command = "cpu37"
trigger38  = command = "cpu38"
var(59) = 1

[State -1]
type = VarSet
triggerall = var(59)=1
trigger1 = gametime%30=0 || StateNo=800||stateno=40||stateno=13
fvar(18)=(999-random)

;===========================================================================
;---------------------------------------------------------------------------
;���������p�W�����v
[State 140, 5] ;Implemented within engine
type = ChangeState
triggerall = var(59) && statetype!=A
triggerall = (ctrl||stateno=3||stateno=13||(stateno=[21,22]))
trigger1 = (((enemynear,HitDefAttr=SCA,HT)&&enemynear,time>30)||((enemynear,hitdefattr=SCA,ST)&&enemynear,time>22&&random%3=0))
trigger1 = enemynear,name!="cvsiori" && enemynear,name!="cvsryo" && enemynear,name!="cvskim" && Abs(P2bodydist X)<120
value = 40

;�󒆎�g
[state 5210,1]
type = ChangeState
triggerall = var(59)
triggerall = stateno=5050
triggerall = Vel Y > -1
triggerall = alive
triggerall = CanRecover
trigger1 = ifelse(Pos Y<-30,random%5=0,random%4=0)
value = 5210 ;HITFALL_AIRRECOVER

~~~~~~~~~~~~~~~~~�I���W�i���R���{~~~~~~~~~~~~~~~~~~~~~~
;�I���W�i���R���{����
[state -1,clp]
type = ChangeState
value = 870
triggerall = var(59) && P2statetype!=L && statetype!=A && !var(16) && (var(20)=1||var(20)=6) && Power>=3000 && roundstate=2
trigger1 = (P2statetype!=A||(enemynear,Vel Y<0 && enemynear,Pos Y>-40))
trigger1 = (ctrl||stateno=3||stateno=13||stateno=21||stateno=22) && Abs(P2bodydist X)<70 && random%4=1

;========Land========
;�P����
[state -1,clp]
type = ChangeState
value = 3100
triggerall = var(59) && P2statetype!=L && statetype!=A && var(16)
triggerall = (P2statetype!=A||(enemynear,Vel Y<0 && enemynear,Pos Y>-40)) && enemynear,hitfall=0
trigger1 = (stateno=[220,221]) && Abs(P2bodydist X)<100 && (var(36)=1||enemy,life<40) && var(16)<40

;����P
[state -1,clp]
type = ChangeState
value = 410
triggerall = var(59) && P2statetype!=L && statetype!=A && var(16)
triggerall = (P2statetype!=A||(enemynear,Vel Y<0 && enemynear,Pos Y>-40))
trigger1 = (ctrl||stateno=3||stateno=13||stateno=21||stateno=22) && Abs(P2bodydist X)<70 && random%5<=2

;������P
[state -1,clp]
type = ChangeState
value = 220+(abs(P2bodydist X)<=32)
triggerall = var(59) && P2statetype!=L && statetype!=A && (var(16)=[1,60])
triggerall = (P2statetype!=A||(enemynear,Vel Y<0 && enemynear,Pos Y>-40)) && enemynear,hitfall=0
trigger1 = (stateno=310||stateno=221) && Abs(P2bodydist X)<100 && var(36)

;�����r
[state -1,clp]
type = ChangeState
value = 310
triggerall = var(59) && P2statetype!=L && statetype!=A && var(16)
triggerall = (P2statetype!=A||(enemynear,Vel Y<0 && enemynear,Pos Y>-40)) && enemynear,hitfall=0
trigger1 = (stateno=410||stateno=310) && Abs(P2bodydist X)<100 && var(36)

;===�u���b�L���O�㔽���p
;����K
[state -1]
type = ChangeState
value = 450
triggerall = var(59) && P2statetype!=L
triggerall = statetype!=A
trigger1 = ctrl && (prevstateno=[4000,4010])
trigger1 = P2bodydist X<70 && P2statetype=A

;����P
[state -1]
type = ChangeState
value = 420
triggerall = var(59) && P2statetype!=L
triggerall = statetype!=A
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
trigger1 = ctrl && (prevstateno=[4000,4010])
trigger1 = P2bodydist X>30

;����K
[state -1]
type = ChangeState
value = 450
triggerall = var(59) && P2statetype!=L
triggerall = statetype!=A
trigger1 = ctrl && (prevstateno=[4000,4010])
trigger1 = P2bodydist X>30

;����P
[state -1]
type = ChangeState
value = 400
triggerall = var(59) && P2statetype!=L
triggerall = statetype!=A
trigger1 = ctrl && (prevstateno=[4000,4010])
trigger1 = P2bodydist X<30

;�W�����v��P
[state -1]
type = ChangeState
value = 620+(!vel Y)
triggerall = var(59) && P2statetype!=L
triggerall = statetype=A
trigger1 = ctrl && stateno=4030
trigger1 = P2bodydist X<60 && abs(P2bodydist Y)<60
;=================

;�C����
[State -1, kikouken]
type = ChangeState
value = 3000
triggerall = var(59)
triggerall = roundstate = 2 && P2statetype!=L && Abs(P2bodydist X)<=ifelse(enemynear,Vel X!=0,80,55)
triggerall = ((!var(20) || var(20) = 6)&&Power >= 2000)||(var(20)=4&&var(15)&&Power>=1000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(20)=5&&var(43))
triggerall = statetype != A
trigger1 = (ctrl || stateno=3 || stateno=13 || (stateno=[21,22]) || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2))
trigger1 = P2statetype=A && enemynear,Vel Y>4 && enemynear,Pos Y >-50 && fvar(18)>700 && !numtarget && (enemynear,Vel X=[0,6])
trigger1 = (P2stateno=50 || (P2stateno=[600,799]))&&fvar(33)!=3
trigger2 = StateNo = 450 && var(36) = 1 && P2statetype=A && enemynear,Pos Y<-40

;---------------------------------------------------------------------------
;�P����
[State -1, kikouken]
type = ChangeState
value = 3100
triggerall = var(59) && !var(16)
triggerall = roundstate = 2 && P2statetype!=L && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = statetype != A
;trigger1 = (ctrl || stateno=3 || stateno=13 || (stateno=[21,22]) || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)) && Enemynear,Life<56 && (P2bodydist X=[80,120])
trigger1 = StateNo = 410 && (var(36) = 1||var(36) = 2) && (P2BodyDist X = [0,85]) && fvar(29) && AnimEleMTime(3)>=0 && AniMElemtime(5)<2 && random%2=0
trigger2 = StateNo = 410 && (var(36) = 1||var(36) = 2) && (P2BodyDist X = [0,75]) && Enemynear,Life<56 && AnimEleMTime(3)>=0 && AniMElemtime(5)<0 && random%2=0
trigger3 = StateNo = 410 && (var(36) = 1||var(36) = 2) && (P2BodyDist X = [80,135]) && AnimEleMTime(3)>=0 && AniMElemtime(5)<2
trigger4 = stateno=211 && AnimElemtime(10)>=0 && Animelemtime(11)<0 && var(36) && var(17)>1
trigger5 = stateno=420 && var(36)

[State 100, 4]
type = ChangeState
triggerall = var(36) = 1 && var(59) && stateno=3100 && random%4=0
trigger1 = !var(5) && animelemtime(38) > 0
trigger2 = var(5) = 1 && animelemtime(50) > 0
trigger3 = var(5) = 2 && animelemtime(62) > 0
value = 40

;�W�����v���L�b�N
[State -1,crouch]
type = ChangeState
value = 650
triggerall = var(59) && StateType=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-10)) && P2Statetype=A && enemynear,Hitfall=1
trigger1 = ctrl && random<350 && P2BodyDist X <=50 && pos Y <-50 && enemynear,Backedgebodydist >40
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;�ʏ퓊��
[State -1]
type = ChangeState
value = 900-(enemynear,Statetype=A || P2movetype=H)*680
triggerall = var(59) && roundstate=2 && !(enemynear,Statetype=L&&enemynear,alive)
triggerall = P2BodyDist X <=32 && !fvar(31) && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
triggerall = (!var(16)||(var(16)&&enemy,life<90))
triggerall = StateNo != 100 && StateType!=A && (Ctrl || stateno=3 || stateno=13 || (stateno=[21,22]))
trigger1 = (fvar(18)<ifelse(Power>=1000,320,240)||(P2statetype=S && enemynear,movetype=I && (enemynear,time=[18,22]))||(prevstateno=140 && time>2&&random<200)) && (!fvar(31) || (fvar(31)=4&&var(12)>2))
trigger2 = ((stateno=101||anim=106) && animtime=0)||prevstateno=105||prevstateno=101

;������K
[State -1,crouch]
type = ChangeState
value = 230
triggerall = var(59) && StateType!=A
triggerall = roundState=2 && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = random%3=0 && (P2stateno=5110 || (P2stateno=5120 && enemynear,time<4)) && enemynear,Statetype=L && Abs(P2bodydist X)<=40 && fvar(18)<=220 && !fvar(34)

;�S��r
[State -1,crouch]
type = ChangeState
value = 1100
triggerall = var(59) && StateType!=A
triggerall = roundState=2 && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = random%5<3 && P2stateno=5120 && enemynear,Statetype=L && Abs(P2bodydist X)<=40 && fvar(18)<=400 && enemynear,time<20 && fvar(34)
trigger1 = (ctrl || stateno=3 || stateno=13 || (stateno=[21,22]))
trigger2 = stateno=3100 && var(5)=1 && var(36)=1 && AnimElemTime(44)>=0 && AnimElemTime(46)<0 && Power>=1000
trigger3 = stateno=430 && movecontact=1

;�X�s�j���O�o�[�h�L�b�N
[State -1,crouch]
type = ChangeState
value = 1200
triggerall = var(59) && StateType!=A && !var(16)
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-10))
triggerall = (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = random%5<=1 && (P2BodyDist X = [0,70]) && !fvar(31) && stateno=410 && var(36)=2 && AnimElemTime(3)>=0 && AnimElemTime(4)<0

;�C����
[State -1,crouch]
type = ChangeState
value = 1000
triggerall = var(59) && StateType!=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-10))
triggerall = (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = random%4=0 && (P2BodyDist X = [75,110]) && !fvar(31) && stateno=210 && var(36) && AnimElemTime(5)>=0 && AnimElemTime(6)<0
trigger2 = Abs(P2bodydist X)>110 && Abs(P2bodydist X)<150 && (fvar(18)=[500,600]) &&  (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22]))

;�������p���`
[State -1,crouch]
type = ChangeState
value = 210+(Abs(P2bodydist X)<=16)
triggerall = var(59) && StateType!=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-6))
triggerall = (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
triggerall = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22]))
trigger1 = fvar(18)<170 && (P2BodyDist X = [40,70]) && !fvar(31) && !fvar(29)
trigger2 = fvar(18)<80 && (P2BodyDist X = [70,90]) && !fvar(31)

;�������p���`
[State -1,crouch]
type = ChangeState
value = 220+(Abs(P2bodydist X)<=25)
triggerall = var(59) && StateType!=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-6))
triggerall = (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && (fvar(18)=[170,200]) && (P2BodyDist X = [80,100]) && !fvar(31)

;�����r
[State -1,crouch]
type = ChangeState
value = 310
triggerall = var(59) && StateType!=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-6)) && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && (fvar(18)=[200,260]) && (P2BodyDist X = [60,90]) && !fvar(31)
;----------------------------
;�ߋ������p���`
[State -1,crouch]
type = ChangeState
value = 210+(P2bodydist X<=16)
triggerall = var(59) && StateType!=A && !var(16)
triggerall = roundState=2 && (P2statetype=L&&enemynear,anim=5120&&(enemynear,animtime=[-3,-2])) && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && random<350 && (P2BodyDist X = [-16,16]) && !fvar(31) && fvar(18)<=ifelse(Power>=1000,320,240)

;���Ⴊ�ݎ�L�b�N
[State -1,crouch]
type = ChangeState
value = 430
triggerall = var(59) && StateType!=A && !var(16)
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-4)) && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && random<125 && (P2BodyDist X = [0,20]) && !fvar(31) && fvar(18)>ifelse(Power>=1000,320,240)

;���Ⴊ�ݎ�p���`
[State -1,crouch]
type = ChangeState
value = 400
triggerall = var(59) && StateType!=A && !var(16)
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-4)) && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && random<300 && (P2BodyDist X = [0,40]) && (!fvar(31)||(fvar(31)&&ceil(fvar(18))%4=0)) && fvar(18)>ifelse(Power>=1000,320,240)
trigger2 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && (Abs(P2bodydist X) = [0,40]) && fvar(33)=2
;trigger3 = Stateno=400 && time>9 && (P2BodyDist X = [0,45])

;���Ⴊ�ݒ��p���`
[State -1,crouch]
type = ChangeState
value = 410
triggerall = var(59) && StateType!=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-5)) && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && (fvar(18)=[260,340]) && (P2BodyDist X = [40,75]) && !fvar(31)
trigger2 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && (fvar(18)=[230,280]) && (P2BodyDist X = [75,95]) && !fvar(31)
trigger3 = ((prevstateno=400&&(ctrl|| stateno=3 || stateno=13 || (stateno=[21,22]))) || (Stateno=400 && AnimTime=0)) && (P2BodyDist X = [0,70]) && (var(36)=1||(var(36)=2 && fvar(18)>600)) && fvar(29)
trigger4 = stateno=1100 && AnimTime=0 && (P2BodyDist X = [0,85]) && var(36)=1
trigger5 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && (Abs(P2bodydist X) = [40,75]) && fvar(33)=2

;���Ⴊ�ݒ��L�b�N
[State -1,crouch]
type = ChangeState
value = 440
triggerall = var(59) && StateType!=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-5)) && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && (fvar(18)=[260,340]) && (P2BodyDist X = [75,85]) && !fvar(31)
;-----------------------
;���Ⴊ�݋��L�b�N
[State -1,crouch]
type = ChangeState
value = 450
triggerall = var(59) && StateType!=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-6))
triggerall = P2Statetype=A  && enemynear,Vel Y>6.5 && enemynear,Pos Y>-35 && enemynear,Pos Y>-55 && enemynear,Vel X>=0
triggerall = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22]))
trigger1 = (P2BodyDist X = [30,100]) && enemynear,hitfall=0 && (P2stateno!=[100,110]) && (P2movetype!=A || (P2movetype=A && (P2stateno=[600,799])))&&fvar(33)!=3
trigger2 = (Abs(P2bodydist X) = [0,80]) && fvar(33)=1 && random%3=0

;�W�����v��L�b�N
[State -1,crouch]
type = ChangeState
value = 630+(Vel X=0)
triggerall = var(59) && StateType=A && enemynear,Hitfall=0
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-10)) && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger1 = ctrl && random%4=0 && (P2BodyDist X = [-20,20]) && !fvar(31) && Pos Y>-65

;�W�����v���p���`�i�󒆓����j
[State -1,crouch]
type = ChangeState
value = 620+(Vel X=0)+(Abs(P2Bodydist X)<=24&&P2movetype!=H)*350-(Abs(P2Bodydist X)<=24&&P2movetype!=H&&Vel X=0)
triggerall = var(59) && StateType=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-10))
trigger1 = ctrl && random%3=0 && P2BodyDist X>=0 && P2BodyDist X<=ifelse(Vel X>0,75,50) && !fvar(31) && enemynear,Hitfall=0 && Pos Y<=-60 && Enemynear,Pos Y <=-55 && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30))
trigger2 = ctrl && random<350 && P2BodyDist X <=50 && pos Y <-50 && enemynear,Hitfall=1 && enemynear,backedgebodydist <=40 && P2statetype=A
trigger3 = P2statetype=A && enemynear,Pos y<-50 && enemynear,hitfall=0 && Abs(P2bodydist X)<=60 && ctrl && Pos Y<-50

;��{��
[State -1,crouch]
type = ChangeState
value = 710
triggerall = var(59) && StateType=A
triggerall = roundState=2 && (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-10))
trigger1 = Stateno=620 && AnimElemTime(3)>=0 && AnimElemTime(5)<0 && var(36)

[State -1]
;�W�����v
type = ChangeState
value = 40
triggerall = var(59) && (roundstate=2 || (RoundState=3 && Win)) && !(enemynear,Statetype=L&&enemynear,alive) && (fvar(33)!=[1,2])
triggerall = StateType != A  && (roundstate=2 || (RoundState=3 && Win)) && (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22]))
trigger1 = enemy,numproj > 0 && ifelse((P2BodyDist X = [160,190]),(fvar(18) = [960,1000]),(fvar(18) = [800,1000])) && P2BodyDist X >=160
trigger1 = enemynear,MoveType!=H && Enemynear,Time>18
trigger2 = (P2BodyDist X = [100,159]) && fvar(18)>ifelse(fvar(30),880,920)
trigger3 = enemynear,stateno = 5120 && random < 350 && (P2BodyDist X = [80,120]) && ctrl && fvar(18)<350
trigger5 = (P2BodyDist X = [160,200]) && fvar(18)>980 && fvar(30) && (ctrl || StateNo=3 || StateNo=20)
trigger6 = enemynear,Vel X >0 && P2BodyDist X <80 && enemynear,Pos Y <-60 && (ctrl || StateNo=13) && random<(ifelse(P2BodyDist X <50,80,30)) && enemynear,Vel Y<=0 && !var(21) && fvar(18)>750
trigger7 = ((P2bodydist X=[60,80])||(P2bodydist X=[110,130])) && fvar(18)>ifelse(P2bodydist X>=110,910,790) && P2statetype!=A && enemynear,backedgebodydist>5;�߂���_��
trigger8 = (P2bodydist X=[60,100]) && (var(59)=2 || var(59)=3 || var(59)=4 || var(59)=5) && fvar(18)>820
trigger9 = P2bodydist X<90 && fvar(18)>720 && P2statetype=A && enemynear,Vel Y>=0 && enemynear,Pos Y<-60

;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 1
triggerall = var(20) = 0 || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = roundState=2 && enemynear,Statetype != L
triggerall = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22]))
trigger1 = (P2statetype!=A||(P2statetype=A && enemynear,Pos Y>=-40 && enemynear,Vel Y<=0))
trigger1 = P2BodyDist X >=100 && (Random = [326+(P2bodydist X>160)*2-(fvar(31)=[1,3])*4,330])
trigger2 = enemy,numproj>0 && P2BodyDist X >=150 && ((enemynear,movetype=A && Enemynear,Time>((P2BodyDist X)/11+2))||enemynear,movetype!=A)
trigger2 = (P2BodyDist X<170 && (fvar(18)=[500,820])) || (P2BodyDist X >=170 && (fvar(18)=[350,800]))

;����
[State -1]
type = ChangeState
value = 830
triggerall = var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A && (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22]))
trigger1 =  enemynear,Statetype=A && enemynear,Vel Y >0 && enemynear,Pos Y >-60 && random <70 && P2BodyDist X <40
trigger2 = enemynear,Statetype!=A && ((enemynear,movetype=I && random <10) || (enemynear,Movetype=A && random <30)) && (P2BodyDist X =[40,140])

;---------------------------------------------------------------------
;�X�e�b�v
[State -1]
type = ChangeState
value = 102
triggerall = var(59) && StateType!=A && roundstate=2
triggerall = var(20) = 0 || var(20) = 1 || var(20) = 2
trigger1 = (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-10))
trigger1 = (p2Bodydist X=[80,140]) && (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && random<7 && enemy,numproj=0 && enemynear,Pos Y>-40 && (enemynear,Vel Y<0 || enemynear,statetype!=A)
trigger2 = (ctrl || stateno=3 || stateno=13 || (stateno=[21,22])) && random%4=0 && enemynear,statetype=L && (p2bodyDist x=[60,100])

;---------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 100
triggerall = var(59) && StateType!=A && roundstate=2
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5
triggerall = (ctrl || stateno=3 || stateno=13 || (stateno=[21,22]))
trigger1 = (!(enemynear,Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-10)) && p2bodyDist x>120 && fvar(18)<140
trigger1 = enemy,numproj=0 && enemynear,Pos Y>-40 && (enemynear,Vel Y<0 || enemynear,statetype!=A)
trigger2 = StateNo != 100 && enemynear,statetype=L && (p2bodyDist x=[40,100]) && random<100
trigger3 = (numproj>0||(projcontacttime(1005)=[1,15])) && P2Bodydist X >140
trigger4 = p2movetype=H && (p2bodydist X=[30,60]) && fvar(18)<600

;�o�b�N�X�e�b�v
[State -1]
type = ChangeState
value = 105
triggerall = var(59) && StateType!=A && roundstate=2
trigger1 = (ctrl || stateno=3 || stateno=13 || (stateno=[21,22])) && random%4=0 && enemynear,statetype=L && enemynear,alive && (p2bodyDist x=[0,100]) && ceil(fvar(18))%3=0 && !fvar(34)

;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A && Power>=2000
triggerall = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22]))
trigger1 = P2BodyDist X >= 120 && Random <= ifelse(Power>=2700,200,40)

;-----------�K�[�h------------
;�K�[�h
[state -1, Guard]
type = ChangeState
value = 131
triggerall = var(59) && RoundState = 2 && statetype!=A
triggerall = P2statetype!=A || (P2statetype=A && enemynear,Pos y>-40 && enemynear,Vel Y<=0)
triggerall = (enemynear,Movetype = A||((enemy,numproj>0||enemy,numhelper)&&Inguarddist)) && (ctrl || stateno=13)
trigger1 = P2BodyDist X <=120 && ifelse((fvar(31)&&ceil(fvar(18))%4=0)&&!(P2statetype=A&&enemynear,vel Y>0&&P2bodydist X>60&&enemynear,Pos Y<-30),random%7>=5,1)
trigger2 = random%9!=0 && Statetype!=A && P2BodyDist X >120 && enemy,numproj=0
trigger3 = (ceil(fvar(18)) = [320-(var(20)=2)*320,870]) && (P2BodyDist X >120||(Abs(P2bodydist Y)>60&&enemynear,time>24))
trigger3 = (enemy,numproj>0||enemy,numhelper) && ((enemynear,movetype=A && Enemynear,Time>20) || enemynear,movetype!=A) && random%5<3
trigger3 = !(var(20)=2&&enemy,numproj&&random%20!=0)

;�K�[�h
[state -1, Guard]
type = ChangeState
value = ifelse (StateType=A,132,130)
triggerall = var(59) && RoundState = 2 &&((statetype=A && (((enemy,numproj>0||enemy,numhelper>0)&&inguarddist)||enemynear,statetype=A))||statetype!=A)
triggerall = (((var(20)=6&&enemy,numproj)||(var(20)!=2&&var(20)!=5&&var(20)!=6&&(var(20)=[2,6])&&var(4)!=1))&&StateType!=A) || Var(20)=0
triggerall = !(P2statetype=A && enemynear,Pos y>-40 && enemynear,Vel Y<=0)
triggerall = (enemynear,Movetype = A||((enemy,numproj>0||enemy,numhelper)&&inguarddist)) && (ctrl || stateno=13 || stateno=21 || stateNo=22)
trigger1 = P2BodyDist X <=120 && ifelse((fvar(31)&&ceil(fvar(18))%4=0)&&!(P2statetype=A&&enemynear,vel Y>0&&P2bodydist X>60&&enemynear,Pos Y<-30),random%7>=5,1)
trigger2 = random%9!=0 && Statetype!=A && P2BodyDist X >120 && enemy,numproj=0
trigger3 = (ceil(fvar(18)) = [300-(var(20)=2)*300,870]) && (P2BodyDist X >120||(Abs(P2bodydist Y)>60&&enemynear,time>24))
trigger3 = (enemy,numproj>0||enemy,numhelper) && ((enemynear,movetype=A && Enemynear,Time>20) || enemynear,movetype!=A) && random%5<3
trigger3 = !(var(20)=2&&enemy,numproj&&random%20!=0)

[State -1]
;�����i�O�j
type = ChangeState
triggerall = var(59) && roundstate = 2 && enemynear,numproj=0
triggerall = StateType != A && Movetype = I && P2bodydist X>10 && (ctrl || (stateno=13 && time>16))
trigger1 = (((p2bodydist X=[90,110]) && fvar(18)<330) || p2bodydist X>110||enemynear,statetype=L)
trigger1 = ((!(enemynear,Statetype=L&&enemynear,alive) && P2BodyDist X >70) || (enemynear,Statetype=L && enemynear,alive=1 && P2BodyDist X <= 60))
trigger2 = numproj>0 && p2bodydist X>110
trigger3 = p2bodydist X<40 && (enemynear,stateno=[150,153])
trigger4 = enemynear,statetype=L && (Abs(P2bodydist X)=[40,100])
value = 21

[State -1]
;�����i��j
type = ChangeState
triggerall = var(59) && roundstate = 2 && backedgebodydist>5
triggerall = StateType != A && Movetype = I && backedgebodydist >20 && (ctrl || (stateno=13 && time>16) || (stateno=21 && time>12))
trigger1 = fvar(18)>750
trigger1 = ((!(enemynear,Statetype=L&&enemynear,alive) && (P2BodyDist X = [80,110])) || (p2bodydist X>110 && time>8) || (enemynear,Statetype=L && enemynear,alive=1 && P2BodyDist X > 80))
trigger2 = P2statetype=A && enemynear,Vel Y>0 && enemynear,Pos Y<-60 && (P2bodydist X=[60,90])
value = 22

[State -1]
;���Ⴊ��
type = ChangeState
value = 13
triggerall = var(59) && roundstate=2 && StateType != A
trigger1 = ((ctrl && stateno!=20)||(stateno=21 && time>ifelse(p2bodydist X>140,14,8) && random<400)) && !(enemynear,Statetype=L&&enemynear,alive) && (P2BodyDist X = [60,160]) && (fvar(18)=[200,800])
trigger2 = P2BodyDist X<60 && ctrl && stateno!=20 && !(enemynear,Statetype=L&&enemynear,alive) && prevstateno!=52 && stateno!=52 && enemynear,Pos Y>-40 && (enemynear,Vel Y<0 || enemynear,statetype!=A)
trigger3 = ctrl && fvar(31)

[State -1]
;����
type = ChangeState
value = 3
triggerall = var(59) && roundstate=2 && StateType != A
trigger1 = P2BodyDist X>160 && ctrl && !(enemynear,Statetype=L&&enemynear,alive) && enemynear,Pos Y>-40 && (enemynear,Vel Y<0 || enemynear,statetype!=A)

;===Player
;===========================================================================
;---------------------------------------------------------------------------
;�C����
[State -1, kikouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = Command = "kikoushou1" || Command = "kikoushou2" || Command = "kikoushou3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(5) < 0)
trigger6 = StateNo = 221 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 241 && (var(16) || animelemtime(6) < 0 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || animelemtime(5) < 0)
trigger12 = StateNo = 251 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 420 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 430 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 440 && (var(16) || animelemtime(5) < 0)
trigger18 = StateNo = 450 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger20 = StateNo = 310 && (var(16) || animelemtime(5) < 0)
trigger21 = StateNo = 325 && var(16)
trigger22 = StateNo = 330 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger23 = StateNo = 340 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger24 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger25 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger26 = (StateNo = [1000,1699]) && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0

;---------------------------------------------------------------------------
;�P����
[State -1, kikouken]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = Command = "houyoku1" || Command = "houyoku2" || Command = "houyoku3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(5) < 0)
trigger6 = StateNo = 221 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 241 && (var(16) || animelemtime(6) < 0 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || animelemtime(5) < 0)
trigger12 = StateNo = 251 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 420 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 430 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 440 && (var(16) || animelemtime(5) < 0)
trigger18 = StateNo = 450 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger20 = StateNo = 310 && (var(16) || animelemtime(5) < 0)
trigger21 = StateNo = 325 && var(16)
trigger22 = StateNo = 330 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger23 = StateNo = 340 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger24 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger25 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger26 = (StateNo = [1000,1299]) && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�S��r
[State -1, kikouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(2) = [45,54]
triggerall = Command = "a" || Command = "b" || Command = "c"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(5) < 0)
trigger6 = StateNo = 221 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 241 && (var(16) || animelemtime(6) < 0 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || animelemtime(5) < 0)
trigger12 = StateNo = 251 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 430 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 440 && (var(16) || animelemtime(5) < 0)
trigger18 = StateNo = 450 && (var(16) || animelemtime(4) < 0)
trigger19 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger20 = StateNo = 310 && (var(16) || animelemtime(5) < 0)
trigger21 = StateNo = 325 && var(16)
trigger22 = StateNo = 330 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger23 = StateNo = 340 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger24 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger25 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�C����
[State -1, kikouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005)
triggerall = Command = "kikou1" || Command = "kikou2" || Command = "kikou3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(5) < 0)
trigger6 = StateNo = 221 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 241 && (var(16) || animelemtime(6) < 0 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || animelemtime(5) < 0)
trigger12 = StateNo = 251 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 430 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 440 && (var(16) || animelemtime(5) < 0)
trigger18 = StateNo = 450 && (var(16) || animelemtime(4) < 0)
trigger19 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger20 = StateNo = 310 && (var(16) || animelemtime(5) < 0)
trigger21 = StateNo = 325 && var(16)
trigger22 = StateNo = 330 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger23 = StateNo = 340 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger24 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger25 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�X�s�j���O�o�[�h�L�b�N�i�ʏ�j
[State -1, reppuken]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = !var(16)
triggerall = roundstate = 2
triggerall = Command = "spining1" || Command = "spining2" || Command = "spining3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && animelemtime(5) < 0
trigger6 = StateNo = 221 && (animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231 && (animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && animelemtime(3) < 0
trigger10 = StateNo = 241 && (animelemtime(6) < 0 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && animelemtime(5) < 0
trigger12 = StateNo = 251 && (animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 400 && (animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 410 && (animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 420 && animelemtime(3) < 0
trigger16 = StateNo = 430 && (animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 440 && animelemtime(5) < 0
trigger18 = StateNo = 450 && animelemtime(4) < 0
trigger19 = StateNo = 300 && animelemtime(4) < 0
trigger20 = StateNo = 310 && animelemtime(5) < 0
trigger21 = StateNo = 330 && (animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger22 = StateNo = 340 && (animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger23 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3) && statetype != A
ignorehitpause = 0

;---------------------------------------------------------------------------
;�X�s�j���O�o�[�h�L�b�N�i�I���R���j
[State -1, reppuken]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = var(16)
triggerall = roundstate = 2
triggerall = Command = "spining4" || Command = "spining5" || Command = "spining6"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (StateNo = [195,799]) && statetype != A
trigger3 = (StateNo = [1000,1299]) && var(36) && statetype != A
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(5) < 0)
trigger6 = StateNo = 221 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 241 && (var(16) || animelemtime(6) < 0 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || animelemtime(5) < 0)
trigger12 = StateNo = 251 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 430 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 440 && (var(16) || animelemtime(5) < 0)
trigger18 = StateNo = 450 && (var(16) || animelemtime(4) < 0)
trigger19 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger20 = StateNo = 310 && (var(16) || animelemtime(5) < 0)
trigger21 = StateNo = 325 && var(16)
trigger22 = StateNo = 330 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger23 = StateNo = 340 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger24 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger25 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5201
triggerall = !var(59)
triggerall = !var(1)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= 10
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 251 && time < 2
trigger13 = StateNo = 400 && time < 2
trigger14 = StateNo = 410 && time < 2
trigger15 = StateNo = 420 && time < 2
trigger16 = StateNo = 430 && time < 2
trigger17 = StateNo = 440 && time < 2
trigger18 = StateNo = 450 && time < 2
trigger19 = StateNo = 300 && time < 2
trigger20 = StateNo = 310 && time < 2
trigger21 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger22 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 251 && time < 2
trigger13 = StateNo = 400 && time < 2
trigger14 = StateNo = 410 && time < 2
trigger15 = StateNo = 420 && time < 2
trigger16 = StateNo = 430 && time < 2
trigger17 = StateNo = 440 && time < 2
trigger18 = StateNo = 450 && time < 2
trigger19 = StateNo = 300 && time < 2
trigger20 = StateNo = 310 && time < 2
trigger21 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger22 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 251 && time < 2
trigger13 = StateNo = 400 && time < 2
trigger14 = StateNo = 410 && time < 2
trigger15 = StateNo = 420 && time < 2
trigger16 = StateNo = 430 && time < 2
trigger17 = StateNo = 440 && time < 2
trigger18 = StateNo = 450 && time < 2
trigger19 = StateNo = 300 && time < 2
trigger20 = StateNo = 310 && time < 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 251 && time < 2
trigger13 = StateNo = 400 && time < 2
trigger14 = StateNo = 410 && time < 2
trigger15 = StateNo = 420 && time < 2
trigger16 = StateNo = 430 && time < 2
trigger17 = StateNo = 440 && time < 2
trigger18 = StateNo = 450 && time < 2
trigger19 = StateNo = 300 && time < 2
trigger20 = StateNo = 310 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 251 && time < 2
trigger13 = StateNo = 400 && time < 2
trigger14 = StateNo = 410 && time < 2
trigger15 = StateNo = 420 && time < 2
trigger16 = StateNo = 430 && time < 2
trigger17 = StateNo = 440 && time < 2
trigger18 = StateNo = 450 && time < 2
trigger19 = StateNo = 300 && time < 2
trigger20 = StateNo = 310 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time < 2
trigger3 = StateNo = 610 && time < 2
trigger4 = StateNo = 620 && time < 2
trigger5 = StateNo = 621 && time < 2
trigger6 = StateNo = 630 && time < 2
trigger7 = StateNo = 631 && time < 2
trigger8 = StateNo = 640 && time < 2
trigger9 = StateNo = 641 && time < 2
trigger10 = StateNo = 650 && time < 2
trigger11 = StateNo = 651 && time < 2
trigger12 = StateNo = 320 && time < 2

;---------------------------------------------------------------------------
;�O�p����
[State -1, Run Back]
type = ChangeState
value = 48
triggerall = !var(59)
triggerall = command = "holdup"
triggerall = stateno = 50 && prevstateno != 48
triggerall = pos y < -40
trigger1 = frontedgebodydist < 5 && command = "holdback"
trigger2 = backedgebodydist < 5 && command = "holdfwd"

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [-22,22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;������
[State -1, Throw]
type = ChangeState
value = 970
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback" || command = "holddown") && command = "z"
triggerall = statetype = A
triggerall = ctrl
triggerall = p2bodydist X = [-22,22]
trigger1 = p2statetype = A
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;�ߐ��R
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����r
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋr��
[State -1, Taunt]
type = ChangeState
value = 320
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���i�A�R�i��i�ځj
[State -1, Taunt]
type = ChangeState
value = 330
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype != A
trigger1 = StateNo = 230 && (var(36) = 1||var(36) = 2) && animelemtime(4) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;���i�A�R�i��i�ځj
[State -1, Taunt]
type = ChangeState
value = 340
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype != A
trigger1 = StateNo = 330 && (var(36) = 1||var(36) = 2) && animelemtime(3) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;��܋r
[State -1]
type = ChangeState
value = 700
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "holddown"
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;��{��
[State -1]
type = ChangeState
value = 710
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
trigger1 = StateNo = 620 && animelemtime(3) > 1
ignorehitpause = 0

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-16,16]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-32,32]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ���������L�b�N
[State -1, Taunt]
type = ChangeState
value = 231
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-5,5]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-32,32]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 251
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-32,32]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 
trigger2 = StateNo = 200 && Time > 4
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�΂߃W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����W�����v���p���`
[State -1]
type = ChangeState
value = 621
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�΂߃W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����W�����v��L�b�N
[State -1]
type = ChangeState
value = 631
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�΂߃W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�����W�����v���L�b�N
[State -1]
type = ChangeState
value = 641
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�΂߃W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����W�����v���L�b�N
[State -1]
type = ChangeState
value = 651
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701 && animelemtime(5) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
