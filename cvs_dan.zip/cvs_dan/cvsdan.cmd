;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "�����`��"
command = ~D, DF, F, D, DF, s
time = 21

[Command]
name = "�����`��"
command = ~D, DF, F, D, DF, ~s
time = 21

[Command]
name = "�k��䓹��1"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "�k��䓹��1"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "�k��䓹��2"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "�k��䓹��2"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "�k��䓹��3"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "�k��䓹��3"
command = ~D, DF, F, D, DF, ~z
time = 21

[Command]
name = "�W�����1"
command = ~D, DF, F, D, DF, a
time = 21

[Command]
name = "�W�����1"
command = ~D, DF, F, D, DF, ~a
time = 21

[Command]
name = "�W�����2"
command = ~D, DF, F, D, DF, b
time = 21

[Command]
name = "�W�����2"
command = ~D, DF, F, D, DF, ~b
time = 21

[Command]
name = "�W�����3"
command = ~D, DF, F, D, DF, c
time = 21

[Command]
name = "�W�����3"
command = ~D, DF, F, D, DF, ~c
time = 21

[Command]
name = "�K��������1"
command = ~D, DB, B, D, DB, a
time = 21

[Command]
name = "�K��������1"
command = ~D, DB, B, D, DB, ~a
time = 21

[Command]
name = "�K��������2"
command = ~D, DB, B, D, DB, b
time = 21

[Command]
name = "�K��������2"
command = ~D, DB, B, D, DB, ~b
time = 21

[Command]
name = "�K��������3"
command = ~D, DB, B, D, DB, c
time = 21

[Command]
name = "�K��������3"
command = ~D, DB, B, D, DB, ~c
time = 21

[Command]
name = "�������K��1"
command = ~F, B, DB, D, DF, F, x
time = 21

[Command]
name = "�������K��1"
command = ~F, B, DB, D, DF, F, ~x
time = 21

[Command]
name = "�������K��2"
command = ~F, B, DB, D, DF, F, y
time = 21

[Command]
name = "�������K��2"
command = ~F, B, DB, D, DF, F, ~y
time = 21

[Command]
name = "�������K��3"
command = ~F, B, DB, D, DF, F, z
time = 21

[Command]
name = "�������K��3"
command = ~F, B, DB, D, DF, F, ~z
time = 21

[Command]
name = "����"
command = ~z, a, B, x, x
time = 35

[Command]
name = "����"
command = ~z, a, B, x, ~x
time = 35

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "�䓹��1"
command = ~D, DF, F, x
time = 12

[Command]
name = "�䓹��1"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "�䓹��2"
command = ~D, DF, F, y
time = 12

[Command]
name = "�䓹��2"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "�䓹��3"
command = ~D, DF, F, z
time = 12

[Command]
name = "�䓹��3"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "�W����1"
command = ~F, D, DF, x
time = 12

[Command]
name = "�W����1"
command = ~F, D, DF, ~x
time = 12

[Command]
name = "�W����2"
command = ~F, D, DF, y
time = 12

[Command]
name = "�W����2"
command = ~F, D, DF, ~y
time = 12

[Command]
name = "�W����3"
command = ~F, D, DF, z
time = 12

[Command]
name = "�W����3"
command = ~F, D, DF, ~z
time = 12

[Command]
name = "�f��r1"
command = ~D, DB, B, a
time = 15

[Command]
name = "�f��r1"
command = ~D, DB, B, ~a
time = 15

[Command]
name = "�f��r2"
command = ~D, DB, B, b
time = 15

[Command]
name = "�f��r2"
command = ~D, DB, B, ~b
time = 15

[Command]
name = "�f��r3"
command = ~D, DB, B, c
time = 15

[Command]
name = "�f��r3"
command = ~D, DB, B, ~c
time = 15

[Command]
name = "���ɓV�n�䓹�˂�"
command = ~D, DB, B, D, DB, x
time = 21

[Command]
name = "���ɓV�n�䓹�˂�"
command = ~D, DB, B, D, DB, ~x
time = 21

[Command]
name = "���ɓV�n�䓹�˂�"
command = ~D, DB, B, D, DB, y
time = 21

[Command]
name = "���ɓV�n�䓹�˂�"
command = ~D, DB, B, D, DB, ~y
time = 21

[Command]
name = "���ɓV�n�䓹�˂�"
command = ~D, DB, B, D, DB, z
time = 21

[Command]
name = "���ɓV�n�䓹�˂�"
command = ~D, DB, B, D, DB, ~z
time = 21

[Command]
name = "�O�]����"
command = ~D, DF, F, s
time = 12

[Command]
name = "�O�]����"
command = ~D, DF, F, ~s
time = 12

[Command]
name = "��]����"
command = ~D, DB, B, s
time = 12

[Command]
name = "��]����"
command = ~D, DB, B, ~s
time = 12

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 10

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

[Command]
name = "n"
command = 
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]

;===========================================================================
;AI�p

;AI
[State -1, AI]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
var(59) = 1

;===========================================================================
;---------------------------------------------------------------------------
;��g�i�󒆁j
[State -1]
type = ChangeState
value = 5210
triggerall = Var(59) = 1
triggerall = Alive
triggerall = CanRecover
triggerall = Vel Y > -1
triggerall = Pos Y >= -40
triggerall = StateNo = 5050
trigger1 = random = [150,200]

;---------------------------------------------------------------------------
;��g�i�n��j
[State -1]
type = ChangeState
value = 5200
triggerall = var(59) = 1
triggerall = ((var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6) && !(var(0)&2**10)) || CanRecover
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = random <= 400

;---------------------------------------------------------------------------
;�W�����v�i��������j
[state -1, Guard]
type = ChangeState
value = 40
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist || P2bodydist X = [-60,120]
triggerall = ctrl || stateno = 21
triggerall = statetype != A
trigger1 = enemynear,HitDefAttr = SC, NT,ST,HT
	trigger1 = random = [0,700]

;===========================================================================
;---------------------------------------------------------------------------
;����
[State -1, hadouken]
type = ChangeState
value = 3300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = enemynear,prevstateno != [5000,5999]
triggerall = P2MoveType != H && (100*enemynear,life/enemynear,const(data.life))<=30
trigger1 = (p2bodydist X = [0,60]) && Random <= 200 && P2StateType != A
trigger1 = (ctrl && time < 10) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (p2bodydist X = [0,60]) && P2MoveType = A && abs(enemynear,Pos Y - Pos Y) <= 30 && enemynear,Vel Y > 0 && Random <= 200
trigger2 = (ctrl && time < 10) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [20,100]) && ctrl && random%4=2
ignorehitpause = 0

;---------------------------------------------------------------------------
;�k��䓹��
[State -1, gadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !NumProj
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A && P2StateType != L
trigger1 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger1 = (P2BodyDist X = [30,160]) && P2MoveType = I && (random<=ifelse(power<=1999,120,ifelse(power<=2999,240,360)))
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger2 = P2BodyDist X <= 90 && P2MoveType = A && P2BodyDist Y >= -30 && (Random <= ifelse(power<=1999,60,ifelse(power<=2999,150,270)))
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger3 = ((StateNo = 210 || StateNo = 220 || StateNo = 221 || StateNo = 230 || StateNo = 410 || StateNo = 420 || StateNo = 440) && var(36)=1) && (random<=ifelse(power<=1999,190,ifelse(power<=2999,290,420)))
trigger4 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4 
trigger4 = (P2BodyDist X = [30,160]) && P2MoveType = I && random<=120
trigger4 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger5 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4 
trigger5 = P2BodyDist X <= 90 && P2MoveType = A && P2BodyDist Y >= -30 && Random <= 60
trigger5 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4 
trigger6 = ((StateNo = 210 || StateNo = 220 || StateNo = 221 || StateNo = 230 || StateNo = 410 || StateNo = 420 || StateNo = 440) && var(36)=1) && random<=190
trigger7 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger7 = (P2BodyDist X = [30,160]) && P2MoveType = I && random<=360
trigger7 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger8 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger8 = P2BodyDist X <= 90 && P2MoveType = A && P2BodyDist Y >= -30 && Random <= 270
trigger8 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger9 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger9 = ((StateNo = 210 || StateNo = 220 || StateNo = 221 || StateNo = 230 || StateNo = 410 || StateNo = 420 || StateNo = 440) && var(36)=1) && random<=420
trigger10 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [20,100]) && ctrl && random%5=2

;---------------------------------------------------------------------------
;�������K��
[State -1, gadouken]
type = ChangeState
value = 3400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !NumProj
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A && P2StateType != L
trigger1 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger1 = P2BodyDist X <= 30 && P2MoveType = A && P2BodyDist Y >= -30 && (Random <= ifelse(power<=1999,100,ifelse(power<=2999,200,280)))
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger2 = (P2BodyDist X = [30,160]) && P2MoveType = I && (random>ifelse(power<=1999,880,ifelse(power<=2999,760,600)))
trigger2 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4 
trigger3 = P2BodyDist X <= 30 && P2MoveType = A && P2BodyDist Y >= -30 && Random <= 100
trigger3 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger4 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4 
trigger4 = (P2BodyDist X = [30,160]) && P2MoveType = I && random>880
trigger4 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger5 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger5 = P2BodyDist X <= 30 && P2MoveType = A && P2BodyDist Y >= -30 && Random <= 280
trigger5 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger6 = (P2BodyDist X = [30,160]) && P2MoveType = I && random>600
trigger6 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)

;---------------------------------------------------------------------------
;�W�����
[State -1, gadouken]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A && P2StateType != L
trigger1 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger1 = P2BodyDist X <= 30 && P2MoveType = A && (Random > ifelse(power<=1999,800,ifelse(power<=2999,760,690))) && P2StateType = A
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger2 = (P2BodyDist X = [30,160]) && P2MoveType = I && (random>ifelse(power<=1999,880,ifelse(power<=2999,760,600))) && P2StateType = A
trigger2 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger3 = ((StateNo = 210 || StateNo = 220 || StateNo = 221 || StateNo = 410 || StateNo = 420 || StateNo = 440) && var(36)=1) && Random <= 570 && Power >= 3000
trigger4 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4
trigger4 = P2BodyDist X <= 30 && P2MoveType = A && Random > 800 && P2StateType = A
trigger4 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger5 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4
trigger5 = (P2BodyDist X = [30,160]) && P2MoveType = I && random>880 && P2StateType = A
trigger5 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger6 = P2BodyDist X <= 30 && P2MoveType = A && Random > 690 && P2StateType = A
trigger6 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger7 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger7 = (P2BodyDist X = [30,160]) && P2MoveType = I && random>600 && P2StateType = A
trigger7 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger8 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger8 = ((StateNo = 210 || StateNo = 220 || StateNo = 221 || StateNo = 410 || StateNo = 420 || StateNo = 440) && var(36)=1) && Random <= 570

;---------------------------------------------------------------------------
;�K��������
[State -1, gadouken]
type = ChangeState
value = 3200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A && P2StateType != L
trigger1 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger1 = P2BodyDist X <= 15 && P2MoveType = A && (Random > ifelse(power<=1999,850,ifelse(power<=2999,800,750))) && P2StateType != A
trigger1 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = !var(15) && !var(16) && var(20) = 0 || var(20) = 6
trigger2 = stateno = 1305 && P2MoveType = H && (var(20) = 2 || var(20) = 6) && Random <= ifelse(power<=1999,120,ifelse(power<=2999,310,500)) && P2BodyDist X <= 55&&frontEdgebodyDist < 20
trigger3 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4
trigger3 = P2BodyDist X <= 15 && P2MoveType = A && Random > 850 && P2StateType != A
trigger3 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger4 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4
trigger4 = stateno = 1305 && P2MoveType = H && (var(20) = 2 || var(20) = 6) && Random <= 120 && P2BodyDist X <= 55&&frontEdgebodyDist < 20
trigger5 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger5 = P2BodyDist X <= 15 && P2MoveType = A && Random > 750 && P2StateType != A
trigger5 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger6 = stateno = 1305 && P2MoveType = H && (var(20) = 2 || var(20) = 6) && Random <= 500 && P2BodyDist X <= 55&&frontEdgebodyDist < 20

;---------------------------------------------------------------------------
;�����`��
[State -1, gadouken]
type = ChangeState
value = 3500
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A
trigger1 = (P2BodyDist X = [0,100]) && P2MoveType = I && Random > 970
trigger1 = ctrl || stateno = 21 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)

;===========================================================================
;---------------------------------------------------------------------------
;�W����
[State -1, gadouken]
type = ChangeState
value = 1100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L
trigger1 = P2StateType = A && (P2BodyDist X = [23,40]) && P2BodyDist Y >= -80 && Random <= 300
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (P2BodyDist X = [40,150]) && Random <= 100 && P2MoveType != A
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [0,40]) && ctrl && random%4=3

;---------------------------------------------------------------------------
;gadou
[State -1, gadouken]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !NumProj
triggerall = statetype != A
trigger1 = ((StateNo = 420 || StateNo = 440) && var(36)=2) && Random <= 250 && P2BodyDist X > 15
trigger2 = ((StateNo = 420 || StateNo = 440) && var(36)=1) && Random <= 250 && P2BodyDist X > 20
trigger3 = (P2BodyDist X = [80,250]) && Random <= 80 && P2MoveType != A
trigger3 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger4 = ((StateNo = 200 || StateNo = 400) && (var(36)=1||var(36)=2)) && Random <= 200 && P2BodyDist X > 15
trigger5 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [40,100]) && ctrl && random%5=1

;---------------------------------------------------------------------------
;���ɓV�n�䓹�˂�
[State -1, gadouken]
type = ChangeState
value = 1300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L
trigger1 = (P2BodyDist X = [0,60]) && P2MoveType = I && Random > 960
trigger1 = ctrl || stateno = 21 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)

;---------------------------------------------------------------------------
;�f��r
[State -1, gadouken]
type = ChangeState
value = 1200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L
trigger1 = ((StateNo = 420 || StateNo = 440) && var(36)=1) && Random <= 450 && P2BodyDist X <= 20 && P2StateType != A
trigger2 = (P2BodyDist X = [60,200]) && P2MoveType = I && (Random = [700,800])
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [20,80]) && ctrl && random%5=4

;---------------------------------------------------------------------------
;�󒆒f��r
[State -1, gadouken]
type = ChangeState
value = 1250
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = (P2BodyDist Y >= 70) && (Random = [851,960]) && Ctrl && Vel X > 0 
trigger2 = ((StateNo = 600 || StateNo = 630 ) && var(36)=2) && Random <= 350
trigger3 = StateNo = 3100 && Var(5) = 1 && var(36)=1 && AnimElemTime(11) >= 0
trigger4 = (P2BodyDist Y >= 70) && Random <= 250 && Ctrl && Vel X <= 0
trigger5 = StateNo = 3200 && Var(5) = 1 && var(36)=1 && AnimElemTime(20) >= 0
trigger6 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [20,100]) && ctrl && random%5=4

;---------------------------------------------------------------------------
;�O�]����
[State -1, gadouken]
type = ChangeState
value = 1400
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = P2MoveType != A
trigger1 = (P2BodyDist X = [80,150]) && P2MoveType = I && Ctrl && (Random = [570,600])

;---------------------------------------------------------------------------
;��]����
[State -1, gadouken]
type = ChangeState
value = 1410
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = (P2BodyDist X = [80,150]) && P2MoveType = I && Ctrl && (Random = [601,640])

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = var(59) = 1
triggerall = var(1) != [1,2]
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = (Power >= 1000 && (var(20) = 0 || var(20) = 4 || var(20) = 6)) || (Power >= 1500 && var(20) = 1) || (var(14) && var(20) = 3)
triggerall = P2StateType != L
trigger1 = P2BodyDist X <= 50 && Random <= ifelse(power<=1999,970,ifelse(power<=2999,880,800))

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = var(59) = 1
triggerall = var(1) != [1,2]
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = P2StateType != L
trigger1 = P2BodyDist X <= 50 && (Random = [121,240]) 

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = var(59) = 1
triggerall = var(1) != [1,2]
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = P2StateType != L
trigger1 = P2BodyDist X <= 50 && (Random = [221,290]) 

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = var(59) = 1
triggerall = statetype != A
trigger1 = ((P2BodyDist X = [0,150]) && P2MoveType = I && Ctrl) && (Random = [641,660])

;---------------------------------------------------------------------------
;���Ⴊ�ݒ���
[State -1, Taunt]
type = ChangeState
value = 196
triggerall = var(59) = 1
triggerall = statetype != A
trigger1 = ((P2BodyDist X = [0,150]) && P2MoveType = I && Ctrl) && (Random = [661,680])

;---------------------------------------------------------------------------
;�󒆒���
[State -1, Taunt]
type = ChangeState
value = 197
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = (P2BodyDist X <= 60 && P2BodyDist Y <= 40 && Ctrl) && (Random = [221*2,250])

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = var(59) = 1
triggerall = (var(20) = 3 && !var(14)) || var(20) = 6
triggerall = statetype != A
triggerall = Power < 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = !enemynear,numproj
trigger1 = (P2BodyDist X >= 120 && Ctrl) && Random <= 100
trigger2 = (P2BodyDist X >= 120 && Ctrl) && Ctrl && Random <= 130 && P2StateType = L
trigger2 = teammode = single

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2Life > 150
triggerall = !((100*life/const(data.life))<=20 && P2bodydist X <= 160)
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2BodyDist X >= 80 && Random <= 450

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
trigger1 = Random <= 150 && Ctrl

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 25 && Random <= 400 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = 200 || StateNo = 400) && (var(36)=1||var(36)=2) && Random <= 300 && (P2BodyDist X <= 10)

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 15 && Random <= 100 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
trigger1 = P2BodyDist X <= 20 && Random <= 250 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = var(59) = 1
trigger1 = StateNo = 830 && (Time =[14,24]) && Random <= 120

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = (P2BodyDist X = [26,40]) && Random <= 220 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 20 && Random <= 150 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 23 && Random <= 100 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = var(59) = 1
trigger1 = StateNo = 830 && (Time =[14,24]) && Random > 820

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 18 && Random <= 50 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 25 && Random <= 600 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = 200 || StateNo = 400) && (var(36)=1||var(36)=2) && Random <= 400 && (P2BodyDist X <= 10)

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 15 && Random <= 220 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 15 && Random <= 220 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2StateType = A && (P2BodyDist X = [0,20]) && P2BodyDist Y >= -80 && Random <= 180
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 15 && Random <= 320 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = P2BodyDist X <= 15 && Random <= 320 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && Pos Y >= -110
trigger1 = (P2BodyDist X <= 15 && Ctrl) && Random <= 270 && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A && Ctrl && Pos Y >= -110
trigger1 = (P2BodyDist X <= 70 && P2BodyDist Y <= 50) && (Random = [0,560]) && time > 8

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A && Ctrl && Pos Y >= -110
trigger1 = (P2BodyDist X <= 50 && P2BodyDist Y <= 30) && (Random = [61,580]) && time > 8
 
;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A && Ctrl && Pos Y >= -110
trigger1 = (P2BodyDist X <= 30 && P2BodyDist Y <= 20) && (Random = [181,860]) && time > 8 && P2BodyDist Y <= 20
 
;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A && Ctrl && Pos Y >= -110
trigger1 = (P2BodyDist X <= 70 && P2BodyDist Y <= 40) && (Random = [361,950]) && time > 8 && P2BodyDist Y <= 40

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A && Ctrl && Pos Y >= -110
trigger1 = (P2BodyDist X <= 70 && P2BodyDist Y <= 50) && (Random = [451,900]) && time > 8 && P2BodyDist Y <= 30
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A && Ctrl && Pos Y >= -110
trigger1 = (P2BodyDist X <= 70 && P2BodyDist Y <= 40) && (Random = [381,999]) && time > 8 && P2BodyDist Y <= 20

;---------------------------------------------------------------------------
;�K�[�h
[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype != A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,500)*(1+(statetype!=A))

[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype = A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,400)*(1+(statetype!=A))

;---------------------------------------------------------------------------
;�W�����v
[State -1, Jump]
type = ChangeState
value = 40
triggerall = Var(59) = 1 && StateType != A && P2MoveType = I && Ctrl
trigger1 = BackEdgebodyDist > 5 && P2BodyDist X <= 119 && (Random = [550,770])
trigger2 = (P2BodyDist X >= 150 && Ctrl) && PrevStateNo = 1000 && (Random = [300,550])

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(59) = 1
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = P2MoveType != A
triggerall = statetype != A
trigger1 = ((P2BodyDist X = [40,180]) && Ctrl) && (Random = [261,300])
trigger2 = (P2BodyDist X > 60 && Ctrl) && (Random = [161,220])

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = var(59) = 1
triggerall = var(20) = 0 || var(20) = 1 || var(20) = 2
triggerall = P2MoveType != A
triggerall = statetype != A
trigger1 = (P2BodyDist X >= 50 && Ctrl) && (Random = [261,350])
trigger2 = Ctrl && (Random = [261,420]) && P2StateType = L && P2BodyDist X >= 20

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 1
triggerall = statetype != A
trigger1 = (P2BodyDist X <= 50 && P2MoveType != A && Ctrl) && (Random = [471,500])&& P2MoveType != H
trigger2 = (P2BodyDist X <= 40 && P2StateType = L && Ctrl) && (Random = [361,380])

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 1
triggerall = var(20) = 0 || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = stateno != [120,159]
triggerall = stateno != [4000,4199]
triggerall = prevstateno != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
trigger1 = (P2BodyDist X > 100 && Ctrl) && (Random = [300,330])
trigger2 = (P2BodyDist X <= 100 && P2MoveType != A && P2MoveType != H && Ctrl) && (Random = [901,949])
trigger3 = (P2BodyDist X <= 100 && P2MoveType = A && Ctrl) && (Random = [931,959])

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = stateno != [120,159]
triggerall = stateno != [4000,4199]
triggerall = prevstateno != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
trigger1 = (P2BodyDist X <= 60 && P2MoveType != A && P2MoveType != H && Ctrl) && (Random = [561,580])
trigger2 = (P2BodyDist X <= 60 && P2MoveType = A && Ctrl) && (Random = [651,679])

;---------------------------------------------------------------------------
;����
[State -1, Walk]
type = ChangeState
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
triggerall = !InGuardDist
triggerall = stateno != [10,12]
triggerall = prevstateno != [10,12]
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != 21
triggerall = prevstateno != 21
triggerall = stateno != [120,159]
triggerall = prevstateno != [120,159]
triggerall = !(var(16) && numtarget)
trigger1 = random%6<=3

;===========================================================================
;---------------------------------------------------------------------------
;����
[State -1, hadouken]
type = ChangeState
value = 3300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = Command = "����"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = [200,799]
trigger3 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger4 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 51
trigger5 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger6 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
trigger7 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger8 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
trigger9 = StateNo = 3400 && (var(20) = 2 || var(20) = 6) && time > 51
trigger10 = StateNo = 3500 && (var(20) = 2 || var(20) = 6) && time > 51
trigger11 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����`��
[State -1, gadouken]
type = ChangeState
value = 3500
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�����`��"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger18 = (StateNo = [195,197]) && (var(20) = 2 || var(20) = 6)
trigger19 = (StateNo = [1000,2999]) && (var(20) = 2 || var(20) = 6)
trigger20 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 51
trigger21 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger22 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
trigger23 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger24 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
trigger25 = StateNo = 3400 && (var(20) = 2 || var(20) = 6) && time > 51
ignorehitpause = 0

;---------------------------------------------------------------------------
;�k��䓹��
[State -1, gadouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005)&&!NumProjID(3005)&&!NumProjID(3405)
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�k��䓹��1" || Command = "�k��䓹��2" || Command = "�k��䓹��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger18 = (StateNo = [195,197]) && (var(20) = 2 || var(20) = 6)
trigger19 = (StateNo = [1000,2999]) && (var(20) = 2 || var(20) = 6)
trigger20 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger21 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
trigger22 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger23 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
trigger24 = StateNo = 3400 && (var(20) = 2 || var(20) = 6) && time > 51
trigger25 = StateNo = 3500 && (var(20) = 2 || var(20) = 6) && time > 51
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������K��
[State -1, gadouken]
type = ChangeState
value = 3400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005)&&!NumProjID(3005)&&!NumProjID(3405)
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�������K��1" || Command = "�������K��2" || Command = "�������K��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger18 = (StateNo = [195,197]) && (var(20) = 2 || var(20) = 6)
trigger19 = (StateNo = [1000,2999]) && (var(20) = 2 || var(20) = 6)
trigger20 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 51
trigger21 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger22 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
trigger23 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger24 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����
[State -1, gadouken]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�W�����1" || Command = "�W�����2" || Command = "�W�����3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger18 = (StateNo = [195,197]) && (var(20) = 2 || var(20) = 6)
trigger19 = (StateNo = [1000,2999]) && (var(20) = 2 || var(20) = 6)
trigger20 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 51
trigger21 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger22 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
trigger23 = StateNo = 3400 && (var(20) = 2 || var(20) = 6) && time > 51
trigger24 = StateNo = 3500 && (var(20) = 2 || var(20) = 6) && time > 51
ignorehitpause = 0

;---------------------------------------------------------------------------
;�K��������
[State -1, gadouken]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�K��������1" || Command = "�K��������2" || Command = "�K��������3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger18 = (StateNo = [195,197]) && (var(20) = 2 || var(20) = 6)
trigger19 = (StateNo = [1000,2999]) && (var(20) = 2 || var(20) = 6)
trigger20 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 51
trigger21 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger22 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
trigger23 = StateNo = 3400 && (var(20) = 2 || var(20) = 6) && time > 51
trigger24 = StateNo = 3500 && (var(20) = 2 || var(20) = 6) && time > 51
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�W����
[State -1, gadouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�W����1" || Command = "�W����2" || Command = "�W����3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�䓹��
[State -1, gadouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005)&&!NumProjID(3005)&&!NumProjID(3405)
triggerall = Command = "�䓹��1" || Command = "�䓹��2" || Command = "�䓹��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���ɓV�n�䓹�˂�
[State -1, gadouken]
type = ChangeState
value = 1300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "���ɓV�n�䓹�˂�"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�f��r
[State -1, gadouken]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�f��r1" || Command = "�f��r2" || Command = "�f��r3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�󒆒f��r
[State -1, gadouken]
type = ChangeState
value = 1250
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = Command = "�f��r1" || Command = "�f��r2" || Command = "�f��r3"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger8 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger9 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�O�]����
[State -1, gadouken]
type = ChangeState
value = 1400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�O�]����"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;��]����
[State -1, gadouken]
type = ChangeState
value = 1410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "��]����"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�W�����v����
[State -1, Taunt]
type = ChangeState
value = 197
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger8 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger9 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ���
[State -1, Taunt]
type = ChangeState
value = 196
triggerall = !var(59)
triggerall = command = "start"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger12 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = (StateNo = [195,197]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger17 = (StateNo = [3000,3499]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5200
triggerall = !var(59)
triggerall = !(var(0)&2**10)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 250 && time <= 2
trigger9 = StateNo = 400 && time <= 2
trigger10 = StateNo = 410 && time <= 2
trigger11 = StateNo = 420 && time <= 2
trigger12 = StateNo = 430 && time <= 2
trigger13 = StateNo = 440 && time <= 2
trigger14 = StateNo = 450 && time <= 2
trigger15 = (StateNo = [195,799]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 250 && time <= 2
trigger9 = StateNo = 400 && time <= 2
trigger10 = StateNo = 410 && time <= 2
trigger11 = StateNo = 420 && time <= 2
trigger12 = StateNo = 430 && time <= 2
trigger13 = StateNo = 440 && time <= 2
trigger14 = StateNo = 450 && time <= 2
trigger15 = (StateNo = [195,799]) && var(36) && var(16)
trigger16 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 250 && time <= 2
trigger9 = StateNo = 400 && time <= 2
trigger10 = StateNo = 410 && time <= 2
trigger11 = StateNo = 420 && time <= 2
trigger12 = StateNo = 430 && time <= 2
trigger13 = StateNo = 440 && time <= 2
trigger14 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 250 && time <= 2
trigger9 = StateNo = 400 && time <= 2
trigger10 = StateNo = 410 && time <= 2
trigger11 = StateNo = 420 && time <= 2
trigger12 = StateNo = 430 && time <= 2
trigger13 = StateNo = 440 && time <= 2
trigger14 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 250 && time <= 2
trigger9 = StateNo = 400 && time <= 2
trigger10 = StateNo = 410 && time <= 2
trigger11 = StateNo = 420 && time <= 2
trigger12 = StateNo = 430 && time <= 2
trigger13 = StateNo = 440 && time <= 2
trigger14 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time <= 2
trigger3 = StateNo = 610 && time <= 2
trigger4 = StateNo = 620 && time <= 2
trigger5 = StateNo = 630 && time <= 2
trigger6 = StateNo = 640 && time <= 2
trigger7 = StateNo = 650 && time <= 2

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = P2StateType = S || P2StateType = C
trigger1 = P2MoveType != H || var(16)

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time = [14,24]

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
