                            ____________________________
===========================|   CVS Decapre by "tJun"    |==========================
                           |                            |
                           |(malcolmlee1988@hotmail.com)|
                            ����������������������������          
                              Dedicated to "Warusaki3"

Name -  Decapre (Capcom Vs SNK)

Release Date - 27/06/2020

Version - 1.43 (Updated on 14/2/2021)

WINMUGEN  only

Customized version of Street Fighter, Decapre character, for WINMUGEN

~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Updates
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[14.2.2021] - 9th update (ver 1.43)
-Applied SFF fix by evomugen00 (sprites are now placed in the correct palette in the SFF)
-Added 12 new palettes

[20.7.2020] - 8th update (ver 1.42)
-Fixed issue : accidentally overwritten the act files with the wrong palettes in version 1.41.
-Removed explod for Strafe Dagger

[20.7.2020] - 7th update (ver 1.41)
-Fixed minor hitbox issue

[19.7.2020] - 6th update (ver 1.4)
-Revamped many of the hitboxes (neutral stance, crouch, jump, gethits and throws etc.).
-Fixed wrong command issue for Rapid Dagger (strong button) for non-charge version.
-Changed some of the helpers fx to hi-res which include Strafe dagger, Invisible Ray and during one of her intros (fire aura).
-Enabled one of her victory win pose (where she removes mask and teleports away) to only trigger after ending the match with a super move on the second round.
-Added sound effect to winpose no. 1.
-Adjusted Psycho Stream's projectile velocity - slightly reduced the velocity for medium and strong version.
-Added explod for Psycho Stream.
-Fixed issue regarding level 1 and level 2 Psycho Stream triggering Finest KO after defeating enemy using a special move.
-Fixed more palette issues.
-Fixed palette issue on small portrait.
-Added new palette no.13 and no.14.

[29.6.2020] - 5th update (ver 1.3)
-Fixed the changed to the appropriate sprpriority for "Strafe Dagger" helper fx.
-Changed the velocity properties of "Forward roll" with minor adjustment of the animation.
-Adjusted gethit state 5950 animation and CNS.

[28.6.2020] - 4th update (ver 1.22)
-Fixed "fall recover" not being able to activate on upon hit by certain attacks.

[28.6.2020] - 3rd update (ver 1.21)
-Fixed and enabled "Scramble" (air) -> "Break" (HP) to combo into "Psycho Sting"
-Minor palette fix.

[28.6.2020] - 2nd update (ver1.2)
-Fixed problem with the animation for short and long neutral jumps.
-Opponent can no longer tech (air) recover from Target Combo 1 and "Scramble" (air) -> "Break" (HP) combo.
-Added a small patch to include non-charge command motions for her special and super moves.

[28.6.2020] - 1st update (ver 1.1)

-Fixed and removed the "first attack message" from triggering everytime after Decapre hits the opponent with ""Psycho Stream" of after hitting the opponent with any attacks after using Psycho Stream.
-Fixed the back dash animation which stops before Decapre touches the ground and allowing her to walk backwards before the animation finishes.
-Changed "Strafe Dagger" command to [D, DB, B, D, DB, (punch)] from [B (hold 2 sec), F, B, F, (punch)] (due to it being too restrictive and sometimes doesn't work and I also realised there was a mistake in the command).
-Fixed "Cannon Strike" command (doesn't work with light kick version (button A). 
-Minor fix for DCM command.
-Changed "Psycho Stream number of hits (to be source accurate to original game). Total hits changed to 5 (level 1), 7 (level 2) and 9 (level 3) from 3 (level 1), 4 (level 2) and 5 (level 3). The projectile damage is adjusted accordingly.
-Enable follow-up and combo into Scramble -> Break (Ground Pound) after level 2 "Psycho Stream" (C-groove and EX-groove only). Also changed the properties of Break (Ground Pound) - longer active frame.

---------------------------------------------------------------------------------------------

###Issues ###
-

+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +


### What is not done ###

*** Some attacks may not be included or accurate to the source character (from Ultra Street Fighter IV), due to limitation of sprites. Therefore, she may have some attacks similar to Cammy's *** 
*** AI ***

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


===============< Introduction >===============


Hello, I hope that you had fun playing with my previous characters : CVS Poison (2009) and CVS Psylocke (2010) and CVS Mature (2011).


It has been 9 years since I last release a character. This time I am going to release my fourth CVS character, which will be the final one.


This time, I have converted a Street Fighter IV character to CVS gameplay, CVS Decapre!!


*CVS Decapre is made by tJun using Warusaki3's character as base*


Enjoy~


===============< Features >===============

 - Special intros versus Cammy, Vega and Shadaloo Dolls.

 - Special victory pose against Vega and Shadaloo Dolls.

 - Special victory pose after ending the match with a super move (during second round)


===============| Movelist |===============


| X | Y | Z |
|   |   |   |
--------------
| A | B | C |
|   |   |   |


x = Weak Punch

y = Medium Punch

z = Strong Punch

a = Weak Kick

b = Medium Kick

c = Strong Kick

U = Up

D = Down

F = Forward

B = Back

S = Taunt

----------<<<<< Miscelaneous >>>>>-----------

- Run = F, F (can hold)

- Back Dash = B, B (can hold)

- Dodge = a + x

- Dodge Attack = any p or k (during Dodge)

- Forward Roll = F + a + x

- Parry (can also be done in the air, and during guard):

    - F (tap) -> high attacks

    - D (tap) -> low attacks

- Just Defense = B or DB (just before getting hit)

- Power Charge = c + z (can hold)

- Power Stock = b + y

- Custom Combo = c + z (during full meter) (can be done in air)

- Counter = any MP or MK (while guarding) 

- Safe Fall = a + x (after getting hit by knock-down)


**************************************************************************************************

======<Movelist Summary>======

<THROW>

.Shadow Suplex           :            F/B + HP   (near opponent)
.Frankensteiner          :            F/B + HK   (near opponent)
.Flying Neck Hunt        :            F/B + HP   (Air, near opponent)
.Air Frankensteiner      :            F/B + HK   (Air, near opponent)

<UNIQUE MOVE>

.Fox Tail                :            F + MK

<TARGET COMBO>

.Target Combo 1          :            MP + HK (near opponent) - can combo into super jump follow by air throw (Flying neck Hunt)
.Target Combo 1          :            MP + HP

<SPECIAL - NORMAL MODE>

.Psycho Sting            :            D (hold 2 secs), U, p
.Rapid Dagger            :            Repeatedly press p
.Spiral Arrow  (air)     :            B (hold 2 secs), F, k (air)
.Cannon Strike (air)     :            D, DB, B, k (air)
.Scramble (ground)       :            B (hold 2 secs), F, k [(A)]
    .Razor Edge Slicer   :            k
    .Break               :            p  
.Scramble (ground to air):            B (hold 2 secs), F, k [(B) OR (C)] ; (B) - teleport 45 degrees ; (C) - teleport 70 degrees
    .Cannon Strike (air) :            k
    .Break  (air)        :            p [(X) OR (Y) OR (Z)] ; (X) - teleport backwards to previous location ; (Y) - teleport straight down  ; (Z) - slams the ground (Ground pound attack) - can combo into : 1) super jump follow by air throw (Flying neck Hunt) OR 2) Psycho Sting
    .Air Normals (air)   :            p/k (during late part of Scramble)
.Invisible Ray           :            B (hold 2 secs), F, p    
.Psycho Transaction      :            3p (Hold)
.Cannon Spike            :            Counter move only

<SUPER>

.Strafe Dagger        :            D, DB, B, D, DB, B, p
.Psycho Stream        :            D, DF, F, D, DF, F, p

<Lv3 SUPER>

.DCM (Ground)         :            B (hold for 2 secs), F, B, F, k
.DCM (Air)            :            DB (hold for 2 secs), DF, DB, U, k


======<Movelist Commands (Non-Charge Patch)>======

*These are the changes of command to non-charge motions which can be applied through a small patch included in this character folder (CNS and CMD files).

.Psycho Sting            :            F, D, DF, p
.Rapid Dagger            :            D, DB, B, p
.Spiral Arrow  (air)     :            D, DF, F, k (air)
.Cannon Strike (air)     :            D, DB, B, k (air)
.Scramble (ground)       :            D, DF, F, k [(A)]
    .Razor Edge Slicer   :            k
    .Break               :            p  
.Scramble (ground to air):            D, DF, F, k [(B) OR (C)] ; (B) - teleport 45 degrees ; (C) - teleport 70 degrees
    .Cannon Strike (air) :            k
    .Break  (air)        :            p [(X) OR (Y) OR (Z)] ; (X) - teleport backwards to previous location ; (Y) - teleport straight down  ; (Z) - slams the ground (Ground pound attack) - can combo into : 1) super jump follow by air throw (Flying neck Hunt) OR 2) Psycho Sting
    .Air Normals (air)   :            p/k (during late part of Scramble)
.Invisible Ray           :            D, DF, F, p    
.Psycho Transaction      :            3p (Hold)
.Cannon Spike            :            Counter move only

<SUPER>

.Strafe Dagger        :            D, DB, B, D, DB, B, p
.Psycho Stream        :            D, DF, F, D, DF, F, p

<Lv3 SUPER>

.DCM (Ground)         :            D, DF, F, D, DF, F, k
.DCM (Air)            :            D, DB, B, D, DB, B, k


************************************************************************************************

======<Move Details>======

--------
*THROWS 
--------

���  SHADOW SUPLEX
        F + Z (near opponent)

Decapre goes behind the opponent and wraps her arms around their waist. Then she proceeds to shifts her body weight to lift the opponent and make them land on their upper shoulders/lower head.  


���  AIR FRANKENSTEINER
        F + c (near opponent)

Decapre climbs up on her opponent's shoulders in a seated position with her thighs holding on to their heads. She then performs a back flip while using her own momentum to launch her opponent into a forced somersault, and crashing her opponent back-first on the ground.   

------------
*AIR THROWS 
------------

���  FLYING NECK HUNT
       F + Z (near opponent in air)

When Decapre is in midair, she reaches out and grabs her opponent's neck with one arm and then tosses her opponent into the ground. 

���  FRANKENSTEINER
        F + c (near opponent)

Decapre climbs up on her opponent's shoulders in a seated position with her thighs holding on to their heads. She then performs a back flip while using her own momentum to launch her opponent into a forced somersault, and crashing her opponent back-first on the ground.

------------------------------------------
*UNIQUE MOVES 
------------------------------------------

��� FOX TAIL
    F + MK

Decapre lifts one leg high up and then drops her heel on top of her opponent in an arcing motion. This is an overhead attack. Hits twice when opponent is standing.

Disclaimer: This move resembles Juni's Falling Arc (overhead attack) as I am unable to code the original move due to limitation of sprites.

------------------------------------------
*TARGET COMBO
------------------------------------------

��� TARGET COMBO 1
    MP + HK (near opponent)

After this combo, Decapre launches the opponent in the air and can be followed up by :
- Air throw (Flying Neck Hunt)
- Psycho Sting (strict timing)


��� TARGET COMBO 2
    MP + HP

Has further range from (MP + HK combo) and can be used to poke opponent from far.
    
------------------------------------------
*SPECIAL MOVES
------------------------------------------

���  PSYCHO STING 	 
        D (hold 2 secs), U + X or Y or Z

Anti-air move - Decapre draws the dagger on her hand and performs a stabbing, Psycho Powered uppercut. 
                The punch button determines different special properties. 

                  X - Strike invincible (your goto anti-air to counter most attacks)
                  Y - Projectile invincible (good to catch opponents who throw fireballs)          
                  Z - Throw invincible (good against grapplers who try to abuse throws)

���  RAPID DAGGER  	 
        Press repeatedly X or Y or Z

Expansion + Rapid move - Decapre runs towards the opponent, and stabs them rapidly with her daggers as she runs. She finishes the move with a slash that sends the opponent flying. 
(Pressure)               The number of hits depends on the last button input before execution of rapid dagger.               

                  X - Makes 4 hits
                  Y - Makes 6 hits          
                  Z - Makes 8 hits

���  SPIRAL ARROW  (in air)	
        B (hold 2 secs), F + A or B or C (in air)

Self projectile move  -  Decapre lunges forward during the technique, spinning in a corkscrew manner with her feet leading towards the opponent, performing a short sliding kick along the ground as she lands. 
                         This move is similar to Cammy's and Juni's. Spiral Arrow will hit twice from the appropriate range. 
                         The distance travelled depends on the button pressed. The move tends to be unsafe on block, except when done at the maximum distance. 

���  Cannon Strike (in air)
        D, DB, B + A or B or C (in air)

Dive kick move - Decapre performs a stylish focused turning motion into a diagonal down-forward one-legged driving kick with deadly force.
                 The distance travelled and angle of descent for Cannon Strike vary using different kick buttons.   

                 A - Hits at a steep angle and travels a short distance
                 B - hits just in between the Light and Heavy versions and travels an average distance          
                 C - Hits at a 45� angle and travels the furthest

��� SCRAMBLE (Ground) 
       B (hold 2 secs, F + A

Teleport move - Decapre teleports to another location in forward direction. It is also character dependent meaning it stops in front of the opponent if there is no follow up input of command.
(mix-up)        After a short duration, where she can follow-up with a special move depending on the button input.                  

     
��� RAZOR EDGE SLICER (follow-up move of Scramble (Ground))
              A or B or C (during Scramble (Ground))

Slide kick move - Executed by pressing any kick during Scramble (Ground)) 
(follow-up)       It is a sliding kick that hits low to trip the opponent.

��� BREAK (follow-up move of Scramble (Ground)) 
              X or Y or Z (Scramble (Ground))

Teleport move - Executed by pressing punch during Scramble (Ground)
(follow-up)     Break causes Decapre to change the trajectory and movement of Scramble. Each punch type causes Decapre to move differently, and her options also change depending on which type of Scramble she is using to Break.

                  A - Decapre teleports backwards and returns to her original position
                  B - Decapre stops suddenly at her current position.          
                  C - Decapre teleports forwards further, and can end up behind her opponent if done close to them.

��� SCRAMBLE (Ground to Air)
        B (hold 2 secs), F + Y or Z

Teleport move - Decapre teleports to another location in the air. Distance and angle is determined by the punch button pressed.
(mix-up)        After a short duration, she can follow-up with a special move depending on the button input.
                After Scramble that puts her airborne (without any input), the teleport naturally finishes and she keeps the momentum resulting in a downward float that allows the use of jump normals (non-neutral normals)

                  Y - Decapre charges into the air at around 45 degree angle
                  Z - Decapre charges her into the air at around 70 degree angle          

���  CANNON STRIKE (follow-up move of Scramble)
        A or B or C (during Scramble)

Dive kick move - Decapre performs a dive kick. The distance travelled and angle of descent for Cannon Strike vary using different kick buttons. 
(follow-up)
                 A - Hits at a steep angle and travels a short distance
                 B - hits just in between the Light and Heavy versions and travels an average distance          
                 C - Hits at a 45� angle and travels the furthest

��� BREAK (follow-up move of Scramble) 
              X or Y or Z (during Scramble)

Teleport move - Executed by pressing punch during Scramble
(follow-up)     Decapre will suddenly stop, and the strength of the button determines where Decapre will stop as well as perform different actions respectively. This is where the mixup aspect of Decapre stems from.

                  X - Decapre teleports backwards and downwards back to where she started.
                  Y - Decapre travels straight down with fast recovery on the move.          
                  Z - Decapre performs a slam attack onto the ground (ground pound attack) - can combo into air throw (Flying Neck Hunt), air normals or Psycho Sting.

���  INVISIBLE RAY *move taken from Ultra SFIV Omega Edition*
        B (hold 2 secs), F + X or Y or Z

Projectile move - Decapre launches an invisible projectile towards the opponent, the projectile/fireball cross the screen at the same time it is launched. 
                  It can be used to erase other projectiles. For being invisible, Decapre can use it to deceive opponents or to distance themselves from it
                  Invisible Ray's start-up and projectile speed depend on which button pressed.   

                 A - Slight delay before execution and projectile travels at slower speed.
                 B - Moderate delay before execution. Average start-up time and projectile travels at moderate speed. 
                 C - Longer delay before execution. start-up time and projectile travels faster speed.

���  PSYCHO TRANSACTION *move taken from Ultra SFIV Omega Edition*
        X + Y + Z (press and hold all 3 buttons together)

Charge move - Decapre sacrifices part of her health to fill the Super Meter or Rage Gauge. While holding down the button, Decapre continues to deplete her health until it reach the end. 
              Decapre to sacrifice a portion of her health for additional super and ultra meter, a high risk move that could pay dividends if utilized effectively. 
              During the move, Decapre is fully exposed to the opponent, but if used properly can become a good offense, giving Decapre the ability to combo with her super moves.

-------------------------------------------------------------------
*SUPER MOVES
-------------------------------------------------------------------

���  STRAFE DAGGER *slightly modified from Ultra SFIV*
        D, DB, B, D, DB + X or Y or Z

Executed by charging backward then pressing forward, backward, forward and punch, 
Decapre draws her daggers and flies spinning towards her opponent, similar to a Psycho Crusher, while stabbing them multiple times, which sends the opponent flying.

��� PSYCHO STREAM *command modified from Ultra SFIV*
        D, DF, F, D, DF + X or Y or Z

Decapre gathers a massive amount of Psycho Power in her hand, and fires a ball of energy at the opponent. 
It moves slowly across the screen in a manner similar to Yoga Catastrophe, but dissipates after a certain amount of time.

-------------------------------------------------------------------
*HYPER MOVES (Level 3 & MAX Only) 
-------------------------------------------------------------------

���  DCM "Defensive Counter-Maneuver" (Ground) *slightly modified from Ultra SFIV*
        B (hold for 2 secs), F, B, F + A or B or C 

There are two variants of this move: the is a ground-to-ground attack version, and the other is an anti-air attack.
Decapre performs a jumping knee strike that momentarily mounts her on her opponent's chest before launching them upwards as she somersaults back to the ground. 
As she lands, she draws her daggers before leaping up towards her foe, quickly delivering a series of slashes from multiple directions before slamming them into the ground.

���  DCM "Defensive Counter-Maneuver" (Air) *slightly modified from Ultra SFIV*
        DB (hold for 2 secs), DF, DB, U + A or B or C 

There are two variants of this move: the is an anti-air attack version, and the other is a ground-to-ground attack
Decapre performs a jumping knee strike that momentarily mounts her on her opponent's chest before launching them upwards as she somersaults back to the ground. 
As she lands, she draws her daggers before leaping up towards her foe, quickly delivering a series of slashes from multiple directions before slamming them into the ground.


************************************************************************************************

======<Basic Combos>======


crouch lp, crouch lp, far mp, far hp

crouch lp, crouch lp, far mp, far mk

crouch lp, crouch lp, far mp > Rapid Dagger

crouch lp, close mp, close hk > super jump > air throw

crouch lp, crouch lp, crouch mp > Rapid Dagger, Sting OR  Scramble (Ground) + Razor Edge Slicer

crouch lk, crouch lp, crouch mp > Rapid Dagger, Sting OR OR Scramble (Ground) + Razor Edge Slicer

crouch lk, crouch lp, crouch mp, crouch HP

crouch lk, crouch lp, crouch mk > Scramble (Ground) + Razor Edge Slicer 

crouch mp, far mp, far HP

crouch mp, crouch mp, crouch HP

close mp, close hk > Psycho Sting

close hp, cr MK > Scramble (Ground) + Razor Edge Slicer

close hp, cr MP > Scramble (Ground) + Razor Edge Slicer


*Basic Moves can combo into Special Moves


======<Special Move Combos>======


Scramble (air to ground) -> Break (HP) followed by Psycho Sting


======<Super Move Combos>======

*Special Moves can combo into Super Moves (P-groove and EX-groove only). Few examples : 
   
   - Rapid Dagger -> DCM (Ground)
   - Psycho Sting -> DCM (air)
   - Scramble (Ground) + Razor Edge Slicer -> Psycho Strafe
   - Invisible Ray -> Psycho Stream

*More advanced combos:

Jump HP, close HP > Rapid Dagger -> Psycho Strafe (level 2) -> Scramble (air to ground) -> Break (HP) -> super jump -> air throw (EX-groove only)

Jump HP, close HP > Rapid Dagger -> Psycho Strafe (level 2) -> Psycho Sting -> Psycho Stream (EX-groove only).

Jump HP, close HP, cr MK > Scramble (Ground) + Razor Edge Slicer -> Psycho Strafe (level 2) -> Psycho Sting -> Psycho Strafe (EX-groove only).

*Any level 2 supers can be followed up by a Special Move or another level 1 Super Move (C-groove or EX-groove only).


************************************************************************************************
==========================================
CHARACTER PROFILE & BACKGROUND
==========================================

_._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._
Decapre is a member of M. Bison's elite guards, the Dolls, she is an imperfect product of the Shadaloo cloning experiments that created Cammy. 
_._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._

Decapre is a member of Bison's "Dolls" project, where teenage girls have been kidnapped and brainwashed to become a group of 12 elite assassins for M.Bison. 
Decapre Decapre's name is derived from the Russian word for December, 'Dekabr'. 
Originally from Russia, her appearance resembles Cammy, albeit with the Shadaloo Doll outfit and a blue-gray metal mask. Her hair is platinum blonde and is styled in the same long pigtails as Cammy. 
Her face is shown to be burned on the left side, hence the mask. Decapre wears a pair of retractable daggers that emit Psycho Power. 
In her first playable appearance, Ultra Street Fighter 4, Decapre is seen with a degrading mental state and can only focus on killing and destroying her enemies. 
She also harbors an intense hatred towards Cammy which drives her to escape her stasis pod and hunt her down.

Full Name : Decapre

Sex : Female

Birthplace : Russia

Birthdate : 18th December

Height : 5 feet 4 inches (164cm)

Weight : 101 lbs (46kg)

Measurements (bust, waist, hip) : 86cm, 57cm, 88cm

Blood type : B

Occupation : Shadaloo Doll (Assassin)

First appearance : Street Fighter Alpha 3

Game appearance : Ultra Street Fighter IV, Street Fighter V

Affiliation : Shadaloo

Hair Color : Platinum blonde

Eye Color : Olive

Likes : Dogs

Dislikes : Cammy (formerly), ambiguity

Hobbies : Fighting, Trying to kill Cammy

Goals : Defeat Seth, Get her revenge and kill Cammy

Skills : Repairing fragile machinery

Rival : Cammy

Friend : Other Shadaloo Dolls

Type of Villian : Vengeful fighter

Fighting Style : Decapre fights using Shadaloo fighting techniques with psycho infused daggers. She is shown to have a fighting style that seems to combine both Cammy and M. Bison's fighting styles.  
                 She also has retractable daggers on her gloves that contain a small amount of Psycho Powers. 

Quote : "Execute!"

---------------------------------------------
--------------References---------------------
---------------------------------------------

https://streetfighter.fandom.com/wiki/Decapre

https://villains.fandom.com/wiki/Decapre

http://wiki.shoryuken.com/Ultra_Street_Fighter_IV/Decapre

https://www.fightersgeneration.com/characters5/decapre.html


------------------------------------___________________------------------------------------
-----------------------------------|                   |-----------------------------------
-----------------------------------|      CREDITS      |-----------------------------------
-----------------------------------|___________________|-----------------------------------


=====<Special thanks goes to >=====


Warusaki3 : I used his CVS characters as base for CVS Decapre.


            This character is dedicated to Warusaki3 who inspired me to make CVS characters.


            Many thanks to Warusaki3 for your contributions to MUGEN.


Pullo : For creating a unique and original Decapre character, which I have mainly used the sources and references from this charecter. I have also used some of the sprites and particle effects. 


Chuchoryu : For releasing an edited SFF file for Pullo's Decapre, which I used the SFF for my character.


semicharmed : For sharing the source of Street Fighter IV AE audio files which I have used for Decapre's voice and sound effects.


POTS : An excellent MUGEN content creator. I used his character, Cammy for certain reference.


�k���ݏZ������] : I took some particle effects from this character, Voltage-Zero Returns.


SolidZone : For detecting bugs and providing useful feedback to improve this character.


evomugen00 : For providing the SFF fix (correcting the colour palettes for some of the sprites in the SFF)


KarmaCharmeleon : For providing me with good feedback and information related to original game source.


Memes never die/Manby : For giving feedback on the problem with neutral jump animations and opponents able to recover from TC1 and Scramble (air) -> Break (HP)


[MFG]gui0007 : For releasing a great showcase video for CVS Decapre.


DW: For giving your valuable advice including the clsn, hitbox, fx and pal issues. I also looked up Juli for hitbox references.


Project 13 : For reporting some bug issues and contributing ideas.


Charles_2011 : For identifying bugs (hitbox issues).


heavyheaven : For providing feedback on Decapre's move commands.


EM00 : For providing the SFF fix for the sprites with wrong palette.


Jmorphman : I borrowed some fx from one of his characters.


H" : For being such an awesome and inspiring CVS creator.


Jesuszilla : Another great CVS creator who helped me improve.


Kotobukiya : For using their artwork of Decapre as portrait.


Capcom : For the creating the game Capcom vs SNK (series) and Ultra Street Fighter IV as well as the character, Decapre.


Elecbyte : For designing the MUGEN engine.


Everyone in the MUGEN community for all your support.


And finally, YOU for downloading this character.



/\/\/\/\/\/\/
 Disclaimer
/\/\/\/\/\/\/

Decapre is a fictional character copyright and licence of Capcom.

Decapre and Street Fighter are properties of Capcom.

This character is a non-profit fan-work. No parts of this character can be used for commercial purposes.


#################################

                THE END

           ##################################

Thank you for your support~
  

     Hope you enjoy playing with this character!
             

                    Have a nice year ahead^^

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

With Regards,

 ~tJ~
