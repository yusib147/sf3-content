CVS Decapre version 1.4 Patch (No Charge)

This is the patch to change commands to non-charge motions for this character : CVS Decapre Version 1.4 with non-charge commands.

You will need to replace the original CNS and CMD files with these files.