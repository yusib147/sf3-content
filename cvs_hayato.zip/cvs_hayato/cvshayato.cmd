;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

[Command]
name = "CPU31"
command = U, D, F, U, D
time = 1

[Command]
name = "CPU32"
command = U, B, F, U, D
time = 1

[Command]
name = "CPU33"
command = U, D, D, U, D
time = 1

[Command]
name = "CPU34"
command = F, B, U, U, D
time = 1

[Command]
name = "CPU35"
command = U, F, U, B, U, D
time = 1

[Command]
name = "CPU36"
command = U, D, B, U, D
time = 1

[Command]
name = "CPU37"
command = F, F, B, U, D
time = 1

[Command]
name = "CPU38"
command = U, D, U, U, D
time = 1

[Command]
name = "CPU39"
command = F, B, B, U, D
time = 1

[Command]
name = "CPU40"
command = F, F, B, B, U, D
time = 1

[Command]
name = "CPU41"
command = U, U, F, U, D
time = 1

[Command]
name = "CPU42"
command = U, B, B, U, D
time = 1

[Command]
name = "CPU43"
command = U, B, F, F, U, D
time = 1

[Command]
name = "CPU44"
command = U, F, B, U, U, D
time = 1

[Command]
name = "CPU45"
command = U, B, F, U, U, D
time = 1

[Command]
name = "CPU46"
command = U, B, B, B, U, D
time = 1

[Command]
name = "CPU47"
command = U, D, B, F, U, D
time = 1

[Command]
name = "CPU48"
command = U, D, B, D, U, D
time = 1

[Command]
name = "CPU49"
command = U, D, F, U, U, D
time = 1

[Command]
name = "CPU50"
command = U, D, U, B, U, D
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "�������a"
command = ~x, z, B, a, c
time = 35

[Command]
name = "�������a"
command = ~x, z, B, a, ~c
time = 35

[Command]
name = "�����a1"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "�����a1"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "�����a2"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "�����a2"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "�����a3"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "�����a3"
command = ~D, DF, F, D, DF, ~z
time = 21

[Command]
name = "����1"
command = ~D, DF, F, D, DF, a
time = 21

[Command]
name = "����1"
command = ~D, DF, F, D, DF, ~a
time = 21

[Command]
name = "����2"
command = ~D, DF, F, D, DF, b
time = 21

[Command]
name = "����2"
command = ~D, DF, F, D, DF, ~b
time = 21

[Command]
name = "����3"
command = ~D, DF, F, D, DF, c
time = 21

[Command]
name = "����3"
command = ~D, DF, F, D, DF, ~c
time = 21

[Command]
name = "�~��1"
command = ~D, DB, B, D, DB, x
time = 21

[Command]
name = "�~��1"
command = ~D, DB, B, D, DB, ~x
time = 21

[Command]
name = "�~��2"
command = ~D, DB, B, D, DB, y
time = 21

[Command]
name = "�~��2"
command = ~D, DB, B, D, DB, ~y
time = 21

[Command]
name = "�~��3"
command = ~D, DB, B, D, DB, z
time = 21

[Command]
name = "�~��3"
command = ~D, DB, B, D, DB, ~z
time = 21

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "���d1"
command = ~D, DF, F, x
time = 12

[Command]
name = "���d1"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "���d2"
command = ~D, DF, F, y
time = 12

[Command]
name = "���d2"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "���d3"
command = ~D, DF, F, z
time = 12

[Command]
name = "���d3"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "�g�@1"
command = ~F, D, DF, x
time = 12

[Command]
name = "�g�@1"
command = ~F, D, DF, ~x
time = 12

[Command]
name = "�g�@2"
command = ~F, D, DF, y
time = 12

[Command]
name = "�g�@2"
command = ~F, D, DF, ~y
time = 12

[Command]
name = "�g�@3"
command = ~F, D, DF, z
time = 12

[Command]
name = "�g�@3"
command = ~F, D, DF, ~z
time = 12

[Command]
name = "����1"
command = ~D, DB, B, x
time = 12

[Command]
name = "����1"
command = ~D, DB, B, ~x
time = 12

[Command]
name = "����2"
command = ~D, DB, B, y
time = 12

[Command]
name = "����2"
command = ~D, DB, B, ~y
time = 12

[Command]
name = "����3"
command = ~D, DB, B, z
time = 12

[Command]
name = "����3"
command = ~D, DB, B, ~z
time = 12

[Command]
name = "���ՖC1"
command = ~B, DB, D, DF, F, a
time = 15

[Command]
name = "���ՖC1"
command = ~B, DB, D, DF, F, ~a
time = 15

[Command]
name = "���ՖC2"
command = ~B, DB, D, DF, F, b
time = 15

[Command]
name = "���ՖC2"
command = ~B, DB, D, DF, F, ~b
time = 15

[Command]
name = "���ՖC3"
command = ~B, DB, D, DF, F, c
time = 15

[Command]
name = "���ՖC3"
command = ~B, DB, D, DF, F, ~c
time = 15

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 10

[Command]
name = "FF"
command = F, F
time = 12

[Command]
name = "BB"
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]

;===========================================================================
;AI�p

;AI
[State -1, AI]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
trigger31  = command = "CPU31"
trigger32  = command = "CPU32"
trigger33  = command = "CPU33"
trigger34  = command = "CPU34"
trigger35  = command = "CPU35"
trigger36  = command = "CPU36"
trigger37  = command = "CPU37"
trigger38  = command = "CPU38"
trigger39  = command = "CPU39"
trigger40  = command = "CPU40"
trigger41  = command = "CPU41"
trigger42  = command = "CPU42"
trigger43  = command = "CPU43"
trigger44  = command = "CPU44"
trigger45  = command = "CPU45"
trigger46  = command = "CPU46"
trigger47  = command = "CPU47"
trigger48  = command = "CPU48"
trigger49  = command = "CPU49"
trigger50  = command = "CPU50"
var(59) = 1

;===========================================================================
;---------------------------------------------------------------------------
;��g�i�󒆁j
[State -1]
type = ChangeState
value = 5210
triggerall = Var(59) = 1
triggerall = Alive
triggerall = CanRecover
triggerall = Vel Y > -1
triggerall = Pos Y >= -40
triggerall = StateNo = 5050
trigger1 = random = [150,200]

;---------------------------------------------------------------------------
;��g�i�n��j
[State -1]
type = ChangeState
value = 5200
triggerall = var(59) = 1
triggerall = ((var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6) && !(var(0)&2**10)) || CanRecover
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = random <= 400

;---------------------------------------------------------------------------
;�W�����v�i��������j
[state -1, Guard]
type = ChangeState
value = 40
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist || P2bodydist X = [-60,120]
triggerall = ctrl || stateno = 21
triggerall = statetype != A
trigger1 = enemynear,HitDefAttr = SC, NT,ST,HT
	trigger1 = random = [0,700]

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = var(59) = 1
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2life > 150 || (100*life/const(data.life))<=15
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [0,70]
trigger1 = P2StateType = S || P2StateType = C
trigger1 = P2MoveType = A
trigger1 = enemynear,time >= (10+random%10)
	trigger1 = random <= 300

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = null;ChangeState
value = 875
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl

;===========================================================================
;�N���オ�胊�o�[�T��

;---------------------------------------------------------------------------
;�������a
[State -1, hadouken]
type = ChangeState
value = 3300
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (10+random%10)
trigger1 = P2bodydist X = [0,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,vel X >= 0
	trigger1 = random = [150,300]
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (10+random%10)
trigger1 = P2bodydist X = [0,30]
trigger1 = P2bodydist Y = [-40,-25]
trigger1 = enemynear,vel X >= 0
trigger1 = enemynear,vel Y > 1
trigger1 = P2MoveType != H
	trigger1 = random = [150,700]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����a
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (10+random%10)
trigger1 = P2bodydist X = [20,50]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,vel X >= 0
	trigger1 = random = [100,500]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�~��
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = fvar(26) < 2 || var(16)
triggerall = roundstate = 2
triggerall = !NumHelper(7100)
triggerall = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (10+random%10)
trigger1 = P2bodydist X = [20,50]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,vel X >= 0
	trigger1 = random = [100,400]
trigger2 = P2bodydist X = [20,50]
trigger2 = P2bodydist Y = [-80,-40]
trigger2 = P2MoveType != H
trigger2 = enemynear,vel X >= 0
trigger2 = enemynear,vel Y > 1
	trigger2 = random = [200,600]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;���d�i�X�p�L�����z�Ηp�j
[State -1]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = (var(20) = 2 && Power >= 3000) || (var(20) = 6 && Power >= 1000)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
trigger1 = stateno = 400
trigger1 = var(17) > 1
trigger1 = var(36) = 1 && numtarget
	trigger1 = random < 900
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������a
[State -1, hadouken]
type = ChangeState
value = 3300
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = StateNo = 250
trigger1 = animelemtime(12) > 0
trigger1 = var(36) = 1 && numtarget
trigger1 = !(var(16) && numtarget)
trigger2 = StateNo = 520
trigger2 = var(36) = 1 && numtarget
trigger2 = var(17) > 1
trigger2 = !(var(16) && numtarget)
trigger2 = target,life > 250 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
trigger3 = P2bodydist X = [0,80]
trigger3 = StateNo = 1000
trigger3 = animelemtime(16) = 0
trigger3 = var(36) = 1 && numtarget
trigger3 = var(17) > 1
trigger3 = var(20) = 2 || var(20) = 6
trigger3 = !(var(16) && numtarget)
trigger3 = target,life > 250 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger1 = P2bodydist X = [0,50]
trigger1 = P2bodydist Y = [-40,-25]
trigger1 = enemynear,vel X >= 0
trigger1 = enemynear,vel Y > 1
trigger1 = P2MoveType != H
trigger1 = enemynear,time >= (10+random%10)
trigger1 = !(var(16) && numtarget)
	trigger1 = random < 150
trigger2 = P2bodydist X = [0,30]
trigger2 = P2StateType != A
trigger2 = StateNo = 400
trigger2 = var(17) >= 2
trigger2 = var(36) = 1 && numtarget
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
trigger2 = target,life > 50 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
	trigger2 = random < 200-((var(20)=1)*150)
trigger3 = prevstateno = [4000,4199]
trigger3 = P2bodydist X = [0,50]
trigger3 = P2bodydist Y = [-30,-15]
trigger3 = ctrl
	trigger3 = random%4!=3
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����a
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger1 = P2bodydist X = [0,70]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,vel X >= 0
trigger1 = enemynear,time >= (10+random%10)
trigger1 = !(var(16) && numtarget)
	trigger1 = random < 80
trigger2 = P2StateType != A
trigger2 = StateNo = 400
trigger2 = var(36) = 1 && numtarget
trigger2 = var(17) >= 2
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
trigger2 = target,life > 50 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
	trigger2 = random < 700-((var(20)=1)*500)
trigger3 = P2StateType != A
trigger3 = StateNo = 410 || StateNo = 440
trigger3 = var(36) = 1 && numtarget
trigger3 = !(var(16) && numtarget)
trigger3 = MoveType = A
trigger3 = target,life > 50 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
	trigger3 = random < 500+((var(17)>1)*500)-((var(20)=1)*500)
trigger4 = StateNo = 1000
trigger4 = animelemtime(6) = 2
trigger4 = var(36) = 1 && numtarget
trigger4 = var(17) >= 2
trigger4 = var(20) = 2 || var(20) = 6
trigger4 = !(var(16) && numtarget)
trigger4 = !(((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3))
trigger5 = StateNo = 1000
trigger5 = animelemtime(6) = 0
trigger5 = var(36) = 1 && numtarget
trigger5 = var(17) >= 2
trigger5 = var(20) = 2 || var(20) = 6
trigger5 = !(var(16) && numtarget)
	trigger5 = random < 500
trigger6 = StateNo = 3100
trigger6 = animelemtime(12) >= 3
trigger6 = var(5) = 2
trigger6 = var(36) = 3 && numtarget
trigger6 = var(20) = 2 || var(20) = 6
trigger6 = !(var(16) && numtarget)
trigger7 = StateNo = 310 || StateNo = 330 || StateNo = 500 || StateNo = 510 || StateNo = 520
trigger7 = var(36) = 1 && numtarget
trigger7 = var(16) = [1,20]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�~��
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = fvar(26) < 2 || var(16)
triggerall = roundstate = 2
triggerall = !NumHelper(7100)
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger1 = P2bodydist X = [50,90]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,vel X >= 0
trigger1 = !(var(16) && numtarget)
	trigger1 = random < 80
trigger2 = ctrl || stateno = 21 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger2 = P2bodydist X = [50,90]
trigger2 = P2bodydist Y = [-80,-30]
trigger2 = P2MoveType != H
trigger2 = enemynear,vel X >= 0
trigger2 = enemynear,vel Y > 1
trigger2 = !(var(16) && numtarget)
	trigger2 = random < 300
trigger3 = ctrl || stateno = 21 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = P2bodydist X = [0,80]
trigger3 = P2bodydist Y = [-90,-60]
trigger3 = P2MoveType = H
trigger3 = numtarget
trigger3 = target,stateno = [5000,5070]
trigger3 = target,stateno != 5040
trigger3 = target,Vel Y > -3
trigger3 = !(var(16) && numtarget)
trigger3 = frontedgedist > 50
trigger3 = var(20) != 2 || var(20) != 5 || !var(15)
	trigger3 = Random <= 600
trigger4 = ctrl || stateno = 21 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger4 = P2bodydist X = [0,60]
trigger4 = P2bodydist Y = [-90,-60]
trigger4 = P2MoveType = H
trigger4 = numtarget
trigger4 = target,stateno = 1306
trigger4 = target,Vel Y > 0
trigger4 = !(var(16) && numtarget)
trigger4 = frontedgedist > 50
	trigger4 = Random <= 600
trigger5 = prevstateno = [4000,4199]
trigger5 = P2bodydist X = [0,30]
trigger5 = P2bodydist Y = [-50,0]
trigger5 = ctrl
	trigger5 = random%4!=3
trigger6 = ctrl || stateno = 21 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = fvar(13) = (0,150]
trigger6 = random < 900
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�g�@
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = StateNo = 3011
trigger1 = animelemtime(4) = 1
trigger1 = var(5) = 1
trigger1 = var(36) = 1 && numtarget
trigger1 = !(var(16) && numtarget)
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = numtarget
trigger2 = target,stateno = 1306
trigger2 = target,Vel Y > 5
ignorehitpause = 0

;---------------------------------------------------------------------------
;���d
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2StateType != A
trigger1 = StateNo = 400
trigger1 = var(36) = [1,2]
trigger1 = !(var(16) && numtarget)
trigger1 = MoveType = A
	trigger1 = random < 100+((var(17)>1)*900)
trigger2 = P2StateType != A
trigger2 = StateNo = 410 || StateNo = 440
trigger2 = var(36) = 1
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
	trigger2 = random < 500+((var(17)>1)*500)
trigger3 = prevstateno = [4000,4199]
trigger3 = P2bodydist X = [0,40]
trigger3 = P2StateType != A
trigger3 = !enemynear,numproj
trigger3 = ctrl
	trigger3 = random%4!=3
trigger4 = ctrl || (stateno = 21 && vel X < 0)
trigger4 = P2bodydist X = [90,150]
trigger1 = P2bodydist Y = [-20,0]
trigger4 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger4 = !enemynear,numproj
trigger4 = !(var(16) && numtarget)
	trigger4 = Random = [900,910]
trigger5 = StateNo = 3100
trigger5 = animelemtime(10) >= 19
trigger5 = var(5) = 1
trigger5 = var(36) = 3 && numtarget
trigger5 = !(var(16) && numtarget)
trigger6 = StateNo = 420
trigger6 = var(36) = [1,2]
trigger6 = var(16) > 30
trigger6 = var(17) < 4
ignorehitpause = 0

;---------------------------------------------------------------------------
;���ՖC
[State -1, hadouken]
type = ChangeState
value = 1300
triggerall = var(59) = 1
triggerall = statetype = S
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
triggerall = !var(16)
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
	trigger1 = Random = [650,750]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = (power < 1000 && var(20) = 3 && !var(14)) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = !inguarddist
triggerall = !enemynear,numproj
triggerall = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 140
	trigger1 = Random = [650,920]
trigger2 = P2bodydist X >= 140
trigger2 = P2StateType = L
trigger2 = teammode = single
	trigger2 = Random = [200,500]

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
triggerall = P2Life > 150
triggerall = !((100*life/const(data.life))<=20 && P2bodydist X <= 160)
trigger1 = P2bodydist X >= 100
	trigger1 = Random <= 500
trigger2 = P2StateType = L
	trigger2 = Random <= 700

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 1
triggerall = statetype = S
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
triggerall = !var(16)
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21
	trigger1 = Random = [650,700]

;---------------------------------------------------------------------------
;��
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [80,130]
trigger1 = P2StateType != A
trigger1 = P2MoveType != A
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [750,800]
trigger2 = StateNo = 420 || StateNo = 1000
trigger2 = var(36) = [1,2]
trigger2 = var(16) > 30
trigger2 = var(17) < 10
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-1-2
[State -1, Taunt]
type = ChangeState
value = 330
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 310
trigger1 = var(36) = [1,2]
trigger1 = !var(16)
trigger2 = StateNo = 310
trigger2 = var(36) = [1,2]
trigger2 = var(16) > 20
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-3
[State -1, Taunt]
type = ChangeState
value = ifelse(random%2=0,510,500)
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 330
trigger1 = var(36) = [1,2]
trigger1 = !var(16)
trigger2 = StateNo = 330
trigger2 = var(36) = [1,2]
trigger2 = var(16) > 20
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-2-4
[State -1, Taunt]
type = ChangeState
value = 520
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 500 || StateNo = 510
trigger1 = var(36) = 1 && numtarget
trigger1 = !var(16)
trigger2 = StateNo = 380
trigger2 = var(36) = [1,2]
trigger2 = !var(16)
	trigger2 = random < 500
trigger3 = StateNo = 500 || StateNo = 510
trigger3 = var(36) = 2
trigger3 = !var(16)
	trigger3 = random < 500
trigger4 = StateNo = 500 || StateNo = 510
trigger4 = var(36) = [1,2]
trigger4 = var(16) > 20
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-2-5
[State -1, Taunt]
type = ChangeState
value = 320
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 520
trigger1 = prevstateno = [500,510]
trigger1 = var(36) = 1 && numtarget
trigger1 = !var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-2-6
[State -1, Taunt]
type = ChangeState
value = 340
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 320
trigger1 = var(36) = 1 && numtarget
trigger1 = !(((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16))
trigger2 = StateNo = 320
trigger2 = var(36) = 1 && numtarget
trigger2 = frontedgedist <= 50
trigger3 = StateNo = 320
trigger3 = var(36) = 1 && numtarget
trigger3 = var(20) = 2 || var(20) = 5 || !var(15)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{2-1-2
[State -1, Taunt]
type = ChangeState
value = 370
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 350
trigger1 = var(36) = [1,2]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{2-1-3
[State -1, Taunt]
type = ChangeState
value = 380
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 370
trigger1 = var(36) = [1,2]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{2-1-4
[State -1, Taunt]
type = ChangeState
value = 390
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 380
trigger1 = var(36) = 1 && numtarget
trigger2 = StateNo = 380
trigger2 = var(36) = 2
	trigger2 = random < 500
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{2-1-5
[State -1, Taunt]
type = ChangeState
value = 1160
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 390
trigger1 = var(36) = 1 && numtarget
trigger2 = StateNo = 520
trigger2 = prevstateno = 380
trigger2 = var(36) = 1 && numtarget
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{�n��1
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [50,80]
trigger1 = P2StateType != A
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [750,800]
trigger2 = StateNo = 52
trigger2 = prevstateno = 640
trigger2 = var(16) > 20
trigger2 = var(17) >= 10
trigger3 = StateNo = 520
trigger3 = var(36) = 1 && numtarget
trigger3 = var(16) > 20
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{�n��2
[State -1, Taunt]
type = ChangeState
value = 350
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [40,60]
trigger1 = P2StateType != A
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [870,900]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���t
[State -1]
type = ChangeState
value = 700
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-20,30]
trigger1 = P2bodydist Y = [60,30]
trigger1 = P2StateType != A
trigger1 = Pos Y <= -40
trigger1 = ctrl
trigger1 = !(var(16) && numtarget)
	trigger1 = random = [100,350]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger1 = P2bodydist X = [-5,30]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = prevstateno != 430
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [400,600]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = P2MoveType = H
trigger2 = P2bodydist X = [-5,25]
trigger2 = !(var(16) && numtarget)
	trigger2 = Random >= 800
trigger3 = P2bodydist X = [-5,20]
trigger3 = StateNo = 430
trigger3 = time > 4
trigger3 = var(36) = [1,2]
trigger3 = !(var(16) && numtarget)
	trigger3 = Random <= 800
trigger4 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger4 = P2bodydist X >= 150
trigger4 = P2MoveType != A
trigger4 = !(var(16) && numtarget)
trigger4 = !inguarddist
	trigger4 = Random = [850,870]
trigger5 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger5 = P2bodydist X = [-5,30]
trigger5 = P2StateType = S
trigger5 = !(var(16) && numtarget)
	trigger5 = Random = [350,420]
ignorehitpause = 0

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [60,90]
trigger1 = P2StateType != A
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = prevstateno != 200
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [820,920]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [60,100]
trigger1 = P2bodydist Y = [-20,0]
trigger1 = P2MoveType != A
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [810,830]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [40,90]
trigger1 = P2bodydist Y = [-10,0]
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = prevstateno != 400
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [820,850]
trigger2 = P2bodydist X = [20,90]
trigger2 = P2StateType != A
trigger2 = StateNo = 430
trigger2 = Time > 4
trigger2 = var(36) = [1,2]
	trigger2 = random < 900
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [40,90]
trigger1 = P2bodydist Y = [-20,0]
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [820,850]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [40,80]
trigger1 = P2bodydist Y = [-60,-40]
trigger1 = P2stateno = [0,999]
trigger1 = enemynear,Vel X >= 0
trigger1 = enemynear,Vel Y > 1
trigger1 = P2StateType = A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = frontedgebodydist > 100
	trigger1 = Random = [300,550]
trigger2 = StateNo = 52
trigger2 = prevstateno = 640
trigger2 = var(16) > 30
trigger2 = var(17) < 10
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [30,60]
trigger1 = P2StateType != A
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [740,770]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger1 = P2StateType = A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = P2bodydist X = [80,120]
trigger1 = P2bodydist Y = [-50,-30]
trigger1 = P2stateno = [0,999]
trigger1 = enemynear,Vel X >= 0
trigger1 = enemynear,Vel Y > 0
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 350
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-10,70]
trigger1 = P2bodydist Y = [-10,90]
trigger1 = Pos Y < -50
trigger1 = Vel Y > 1
trigger1 = ctrl || stateno = 701
	trigger1 = random = [100,500]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [40,90]
trigger1 = P2bodydist Y = [-20,60]
trigger1 = Pos Y < -50
trigger1 = Vel Y > 1
trigger1 = ctrl || stateno = 701
	trigger1 = random = [100,490]
trigger2 = P2bodydist X = [-10,90]
trigger2 = P2bodydist Y = [-20,90]
trigger2 = Pos Y < -50
trigger2 = Vel Y > 1
trigger2 = ctrl || stateno = 701
trigger2 = frontedgedist < 30
	trigger2 = random = [100,490]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-30,20]
trigger1 = P2bodydist Y = [-20,30]
trigger1 = Pos Y < -30
trigger1 = Vel Y > 1
trigger1 = ctrl || stateno = 701
	trigger1 = random = [100,450]
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [0,70]
trigger1 = P2bodydist Y = [-20,20]
trigger1 = Pos Y < -50
trigger1 = Vel Y = [-2,2]
trigger1 = ctrl || stateno = 701
	trigger1 = random = [120,320]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = StateNo = 300
trigger1 = var(16) > 40
trigger1 = var(36) = [1,2]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�K�[�h
[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype != A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,400)*(1+(statetype!=A))

[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype = A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,300)*(1+(statetype!=A))

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(59) = 1
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = statetype != A
triggerall = P2MoveType != A
trigger1 = P2bodydist X > 200
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 170

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = var(59) = 1
triggerall = !var(20) || var(20) = 1 || var(20) = 2
triggerall = statetype != A
triggerall = P2MoveType != A
trigger1 = P2bodydist X > 180
trigger1 = P2MoveType = I
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [270,300]
trigger3 = P2bodydist X > 160
trigger3 = P2StateType = L
trigger3 = Ctrl || (stateno = 21 && anim = 20)
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [150,250]

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 1
triggerall = statetype != A
trigger1 = backedgedist > 60
trigger1 = P2bodydist X <= 50
trigger1 = P2MoveType != A
trigger1 = Ctrl || (stateno = 21 && anim = 21)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,310]

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = !var(20) || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = PrevStateNo != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger1 = P2bodydist X >= 180
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 20
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = P2bodydist X = [0,50]
trigger2 = P2MoveType = A
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [430,440]
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A
triggerall = PrevStateNo != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger1 = P2bodydist X = [0,40]
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 10
trigger2 = P2bodydist X = [0,40]
trigger2 = P2MoveType = A
trigger2 = !(var(16) && numtarget)
	trigger2 = Random <= 30
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Walk]
type = ChangeState
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
triggerall = !InGuardDist
triggerall = stateno != [10,12]
triggerall = prevstateno != [10,12]
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != 21
triggerall = prevstateno != 21
triggerall = stateno != [120,159]
triggerall = prevstateno != [120,159]
trigger1 = !(var(16) && numtarget)
	trigger1 = random%3=0

;===========================================================================
;---------------------------------------------------------------------------
;�������a
[State -1, hadouken]
type = ChangeState
value = 3300
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = Command = "�������a" || (ceil(fvar(29))&2**29)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = [200,799]
trigger3 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger4 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger5 = (StateNo = [1300,2999]) && var(36) && var(16)
trigger6 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger7 = (StateNo = [1000,1299]) && (var(20) = 2 || var(20) = 6)
trigger8 = (StateNo = [2800,2999]) && (var(20) = 2 || var(20) = 6)
trigger9 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger10 = StateNo = 3011 && (var(20) = 2 || var(20) = 6)
trigger11 = StateNo = 3025 && (var(20) = 2 || var(20) = 6)
trigger12 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger13 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger14 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "����1" || Command = "����2" || Command = "����3" || (ceil(fvar(29))&2**26) || (ceil(fvar(29))&2**27) || (ceil(fvar(29))&2**28)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 250 && (var(16) || time <= 2)
trigger8 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 430
trigger12 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 450 && (var(16) || time <= 2)
trigger14 = stateno = 305 && var(16)
trigger15 = stateno = 310 && (var(16) || time <= 2)
trigger16 = stateno = 320 && (var(16) || time <= 2)
trigger17 = stateno = 330 && (var(16) || time <= 2)
trigger18 = stateno = 341 && var(16)
trigger19 = stateno = 350 && (var(16) || time <= 2)
trigger20 = stateno = 360 && (var(16) || time <= 2)
trigger21 = stateno = 370 && (var(16) || time <= 2)
trigger22 = stateno = 380 && (var(16) || time <= 2)
trigger23 = stateno = 390 && (var(16) || time <= 2)
trigger24 = stateno = 500 && (var(16) || time <= 2)
trigger25 = stateno = 510 && (var(16) || time <= 2)
trigger26 = stateno = 520 && (var(16) || time <= 2)
trigger27 = StateNo = 195 && var(36) && var(16)
trigger28 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger29 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger30 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger31 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger32 = (StateNo = [1000,1299]) && (var(20) = 2 || var(20) = 6)
trigger33 = (StateNo = [2800,2999]) && (var(20) = 2 || var(20) = 6)
trigger34 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger35 = StateNo = 3011 && (var(20) = 2 || var(20) = 6)
trigger36 = StateNo = 3025 && (var(20) = 2 || var(20) = 6)
trigger37 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0

;---------------------------------------------------------------------------
;�~��
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = !NumHelper(7100)
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�~��1" || Command = "�~��2" || Command = "�~��3" || (ceil(fvar(29))&2**23) || (ceil(fvar(29))&2**24) || (ceil(fvar(29))&2**25)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 250 && (var(16) || time <= 2)
trigger8 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 430
trigger12 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 450 && (var(16) || time <= 2)
trigger14 = stateno = 305 && var(16)
trigger15 = stateno = 310 && (var(16) || time <= 2)
trigger16 = stateno = 320 && (var(16) || time <= 2)
trigger17 = stateno = 330 && (var(16) || time <= 2)
trigger18 = stateno = 341 && var(16)
trigger19 = stateno = 350 && (var(16) || time <= 2)
trigger20 = stateno = 360 && (var(16) || time <= 2)
trigger21 = stateno = 370 && (var(16) || time <= 2)
trigger22 = stateno = 380 && (var(16) || time <= 2)
trigger23 = stateno = 390 && (var(16) || time <= 2)
trigger24 = stateno = 500 && (var(16) || time <= 2)
trigger25 = stateno = 510 && (var(16) || time <= 2)
trigger26 = stateno = 520 && (var(16) || time <= 2)
trigger27 = StateNo = 195 && var(36) && var(16)
trigger28 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger29 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger30 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger31 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger32 = (StateNo = [1000,1299]) && (var(20) = 2 || var(20) = 6)
trigger33 = (StateNo = [2800,2999]) && (var(20) = 2 || var(20) = 6)
trigger34 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger35 = StateNo = 3011 && (var(20) = 2 || var(20) = 6)
trigger36 = StateNo = 3025 && (var(20) = 2 || var(20) = 6)
trigger37 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger38 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����a
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�����a1" || Command = "�����a2" || Command = "�����a3" || (ceil(fvar(29))&2**20) || (ceil(fvar(29))&2**21) || (ceil(fvar(29))&2**22)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 250 && (var(16) || time <= 2)
trigger8 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 430
trigger12 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 450 && (var(16) || time <= 2)
trigger14 = stateno = 305 && var(16)
trigger15 = stateno = 310 && (var(16) || time <= 2)
trigger16 = stateno = 320 && (var(16) || time <= 2)
trigger17 = stateno = 330 && (var(16) || time <= 2)
trigger18 = stateno = 341 && var(16)
trigger19 = stateno = 350 && (var(16) || time <= 2)
trigger20 = stateno = 360 && (var(16) || time <= 2)
trigger21 = stateno = 370 && (var(16) || time <= 2)
trigger22 = stateno = 380 && (var(16) || time <= 2)
trigger23 = stateno = 390 && (var(16) || time <= 2)
trigger24 = stateno = 500 && (var(16) || time <= 2)
trigger25 = stateno = 510 && (var(16) || time <= 2)
trigger26 = stateno = 520 && (var(16) || time <= 2)
trigger27 = StateNo = 195 && var(36) && var(16)
trigger28 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger29 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger30 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger31 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger32 = (StateNo = [1000,1299]) && (var(20) = 2 || var(20) = 6)
trigger33 = (StateNo = [2800,2999]) && (var(20) = 2 || var(20) = 6)
trigger34 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger35 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger36 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�g�@
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "�g�@1" || Command = "�g�@2" || Command = "�g�@3" || (ceil(fvar(29))&2**17) || (ceil(fvar(29))&2**18) || (ceil(fvar(29))&2**19)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 240 && (var(16) || time <= 2) && prevstateno != 830
trigger7 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2)
trigger12 = StateNo = 430
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = stateno = 305 && var(16)
trigger16 = stateno = 310 && (var(16) || time <= 2)
trigger17 = stateno = 320 && (var(16) || time <= 2)
trigger18 = stateno = 330 && (var(16) || time <= 2)
trigger19 = stateno = 341 && var(16)
trigger20 = stateno = 350 && (var(16) || time <= 2)
trigger21 = stateno = 360 && (var(16) || time <= 2)
trigger22 = stateno = 370 && (var(16) || time <= 2)
trigger23 = stateno = 380 && (var(16) || time <= 2)
trigger24 = stateno = 390 && (var(16) || time <= 2)
trigger25 = stateno = 500 && (var(16) || time <= 2)
trigger26 = stateno = 510 && (var(16) || time <= 2)
trigger27 = stateno = 520 && (var(16) || time <= 2)
trigger28 = StateNo = 195 && var(36) && var(16)
trigger29 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger30 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger31 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���d
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "���d1" || Command = "���d2" || Command = "���d3" || (ceil(fvar(29))&2**14) || (ceil(fvar(29))&2**15) || (ceil(fvar(29))&2**16)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 240 && (var(16) || time <= 2) && prevstateno != 830
trigger7 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2)
trigger12 = StateNo = 430
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = stateno = 305 && var(16)
trigger16 = stateno = 310 && (var(16) || time <= 2)
trigger17 = stateno = 320 && (var(16) || time <= 2)
trigger18 = stateno = 330 && (var(16) || time <= 2)
trigger19 = stateno = 341 && var(16)
trigger20 = stateno = 350 && (var(16) || time <= 2)
trigger21 = stateno = 360 && (var(16) || time <= 2)
trigger22 = stateno = 370 && (var(16) || time <= 2)
trigger23 = stateno = 380 && (var(16) || time <= 2)
trigger24 = stateno = 390 && (var(16) || time <= 2)
trigger25 = stateno = 500 && (var(16) || time <= 2)
trigger26 = stateno = 510 && (var(16) || time <= 2)
trigger27 = stateno = 520 && (var(16) || time <= 2)
trigger28 = StateNo = 195 && var(36) && var(16)
trigger29 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger30 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger31 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, hadouken]
type = null;ChangeState
value = 1200
triggerall = !var(59)
triggerall = !var(12)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "����1" || Command = "����2" || Command = "����3" || (ceil(fvar(29))&2**11) || (ceil(fvar(29))&2**12) || (ceil(fvar(29))&2**13)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 240 && (var(16) || time <= 2) && prevstateno != 830
trigger7 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2)
trigger12 = StateNo = 430
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = stateno = 305 && var(16)
trigger16 = stateno = 310 && (var(16) || time <= 2)
trigger17 = stateno = 320 && (var(16) || time <= 2)
trigger18 = stateno = 330 && (var(16) || time <= 2)
trigger19 = stateno = 341 && var(16)
trigger20 = stateno = 350 && (var(16) || time <= 2)
trigger21 = stateno = 360 && (var(16) || time <= 2)
trigger22 = stateno = 370 && (var(16) || time <= 2)
trigger23 = stateno = 380 && (var(16) || time <= 2)
trigger24 = stateno = 390 && (var(16) || time <= 2)
trigger25 = stateno = 500 && (var(16) || time <= 2)
trigger26 = stateno = 510 && (var(16) || time <= 2)
trigger27 = stateno = 520 && (var(16) || time <= 2)
trigger28 = StateNo = 195 && var(36) && var(16)
trigger29 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger30 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger31 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���ՖC
[State -1, hadouken]
type = ChangeState
value = 1300
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "���ՖC1" || Command = "���ՖC2" || Command = "���ՖC3" || (ceil(fvar(29))&2**8) || (ceil(fvar(29))&2**9) || (ceil(fvar(29))&2**10)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 240 && (var(16) || time <= 2) && prevstateno != 830
trigger7 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2)
trigger12 = StateNo = 430
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = stateno = 305 && var(16)
trigger16 = stateno = 310 && (var(16) || time <= 2)
trigger17 = stateno = 320 && (var(16) || time <= 2)
trigger18 = stateno = 330 && (var(16) || time <= 2)
trigger19 = stateno = 341 && var(16)
trigger20 = stateno = 350 && (var(16) || time <= 2)
trigger21 = stateno = 360 && (var(16) || time <= 2)
trigger22 = stateno = 370 && (var(16) || time <= 2)
trigger23 = stateno = 380 && (var(16) || time <= 2)
trigger24 = stateno = 390 && (var(16) || time <= 2)
trigger25 = stateno = 500 && (var(16) || time <= 2)
trigger26 = stateno = 510 && (var(16) || time <= 2)
trigger27 = stateno = 520 && (var(16) || time <= 2)
trigger28 = StateNo = 195 && var(36) && var(16)
trigger29 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger30 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger31 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = !var(2)
triggerall = command = "start" || (ceil(fvar(29))&2**6)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 240 && (var(16) || time <= 2) && prevstateno != 830
trigger7 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger8 = StateNo = 250 && (var(16) || time <= 2)
trigger9 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 420 && (var(16) || time <= 2)
trigger12 = StateNo = 430
trigger13 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 450 && (var(16) || time <= 2)
trigger15 = stateno = 305 && var(16)
trigger16 = stateno = 310 && (var(16) || time <= 2)
trigger17 = stateno = 320 && (var(16) || time <= 2)
trigger18 = stateno = 330 && (var(16) || time <= 2)
trigger19 = stateno = 341 && var(16)
trigger20 = stateno = 350 && (var(16) || time <= 2)
trigger21 = stateno = 360 && (var(16) || time <= 2)
trigger22 = stateno = 370 && (var(16) || time <= 2)
trigger23 = stateno = 380 && (var(16) || time <= 2)
trigger24 = stateno = 390 && (var(16) || time <= 2)
trigger25 = stateno = 500 && (var(16) || time <= 2)
trigger26 = stateno = 510 && (var(16) || time <= 2)
trigger27 = stateno = 520 && (var(16) || time <= 2)
trigger28 = StateNo = 195 && var(36) && var(16)
trigger29 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger30 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger31 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5200
triggerall = !var(59)
triggerall = !(var(0)&2**10)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) || (var(20) = 6 && command = "holdfwd")) && (command = "recovery" || (ceil(fvar(29))&2**7))
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 230 && time <= 2
trigger6 = StateNo = 240 && time <= 2
trigger7 = StateNo = 250 && time <= 2
trigger8 = StateNo = 400 && time <= 2
trigger9 = StateNo = 410 && time <= 2
trigger10 = StateNo = 420 && time <= 2
trigger11 = StateNo = 430 && time <= 2
trigger12 = StateNo = 440 && time <= 2
trigger13 = StateNo = 450 && time <= 2
trigger14 = (StateNo = [195,799]) && var(36) && var(16)
trigger15 = (StateNo = [1000,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery" || (ceil(fvar(29))&2**7)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 230 && time <= 2
trigger6 = StateNo = 240 && time <= 2
trigger7 = StateNo = 250 && time <= 2
trigger8 = StateNo = 400 && time <= 2
trigger9 = StateNo = 410 && time <= 2
trigger10 = StateNo = 420 && time <= 2
trigger11 = StateNo = 430 && time <= 2
trigger12 = StateNo = 440 && time <= 2
trigger13 = StateNo = 450 && time <= 2
trigger14 = (StateNo = [195,799]) && var(36) && var(16)
trigger15 = (StateNo = [1000,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 230 && time <= 2
trigger6 = StateNo = 240 && time <= 2
trigger7 = StateNo = 250 && time <= 2
trigger8 = StateNo = 400 && time <= 2
trigger9 = StateNo = 410 && time <= 2
trigger10 = StateNo = 420 && time <= 2
trigger11 = StateNo = 430 && time <= 2
trigger12 = StateNo = 440 && time <= 2
trigger13 = StateNo = 450 && time <= 2
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = !var(2)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 230 && time <= 2
trigger6 = StateNo = 240 && time <= 2
trigger7 = StateNo = 250 && time <= 2
trigger8 = StateNo = 400 && time <= 2
trigger9 = StateNo = 410 && time <= 2
trigger10 = StateNo = 420 && time <= 2
trigger11 = StateNo = 430 && time <= 2
trigger12 = StateNo = 440 && time <= 2
trigger13 = StateNo = 450 && time <= 2
ignorehitpause = 0

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = !var(2)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 230 && time <= 2
trigger6 = StateNo = 240 && time <= 2
trigger7 = StateNo = 250 && time <= 2
trigger8 = StateNo = 400 && time <= 2
trigger9 = StateNo = 410 && time <= 2
trigger10 = StateNo = 420 && time <= 2
trigger11 = StateNo = 430 && time <= 2
trigger12 = StateNo = 440 && time <= 2
trigger13 = StateNo = 450 && time <= 2
ignorehitpause = 0

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = !var(2)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time <= 2
trigger3 = StateNo = 610 && time <= 2
trigger4 = StateNo = 620 && time <= 2
trigger5 = StateNo = 630 && time <= 2
trigger6 = StateNo = 640 && time <= 2
trigger7 = StateNo = 650 && time <= 2

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;��
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = command = "holdfwd" && command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-1-2
[State -1, Taunt]
type = ChangeState
value = 330
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 310 && (var(36) = 1||var(36) = 2)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-3-3
[State -1, Taunt]
type = ChangeState
value = 510
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 330 && (var(36) = 1||var(36) = 2)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-1-3
[State -1, Taunt]
type = ChangeState
value = 500
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 330 && (var(36) = 1||var(36) = 2)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-1-4
[State -1, Taunt]
type = ChangeState
value = 360
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 500 && (var(36) = 1||var(36) = 2)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-2-4
[State -1, Taunt]
type = ChangeState
value = 520
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || (ceil(fvar(29))&2**4)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 500 && (var(36) = 1||var(36) = 2)
trigger2 = StateNo = 510 && (var(36) = 1||var(36) = 2)
trigger3 = StateNo = 380 && (var(36) = 1||var(36) = 2)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-2-5
[State -1, Taunt]
type = ChangeState
value = 320
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 520 && (var(36) = 1||var(36) = 2) && prevstateno = [500,510]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{1-2-6
[State -1, Taunt]
type = ChangeState
value = 340
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 320 && (var(36) = 1||var(36) = 2)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{2-1-2
[State -1, Taunt]
type = ChangeState
value = 370
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 350 && (var(36) = 1||var(36) = 2)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{2-1-3
[State -1, Taunt]
type = ChangeState
value = 380
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 370 && (var(36) = 1||var(36) = 2)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{2-1-4
[State -1, Taunt]
type = ChangeState
value = 390
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 380 && (var(36) = 1||var(36) = 2)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{2-1-5
[State -1, Taunt]
type = ChangeState
value = 1160
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = StateNo = 390 && (var(36) = 1||var(36) = 2)
trigger2 = StateNo = 520 && (var(36) = 1||var(36) = 2) && prevstateno = 380
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{�n��1
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = command = "holdback" && command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�v���Y�}�R���{�n��2
[State -1, Taunt]
type = ChangeState
value = 350
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = command = "holdback" && command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���t
[State -1]
type = ChangeState
value = 700
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || (ceil(fvar(29))&2**5)
triggerall = command = "holddown"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 430 && Time > 4
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = !var(2)
triggerall = command = "x" || command = "y" || command = "z"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || (ceil(fvar(29))&2**3)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 430 && Time > 4
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || (ceil(fvar(29))&2**4)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = !var(2)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || (ceil(fvar(29))&2**5)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 430 && Time > 4
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || (ceil(fvar(29))&2**3)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 
trigger2 = StateNo = 430 && Time > 4
trigger3 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || (ceil(fvar(29))&2**4)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || (ceil(fvar(29))&2**5)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || (ceil(fvar(29))&2**3)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || (ceil(fvar(29))&2**4)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || (ceil(fvar(29))&2**5)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
