;===========================================================================
; CMD file for.
;===========================================================================
;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

[Command]
name = "CPU31"
command = U, D, F, U, D
time = 1

[Command]
name = "CPU32"
command = U, B, F, U, D
time = 1

[Command]
name = "CPU33"
command = U, D, D, U, D
time = 1

[Command]
name = "CPU34"
command = F, B, U, U, D
time = 1

[Command]
name = "CPU35"
command = U, F, U, B, U, D
time = 1

[Command]
name = "CPU36"
command = U, D, B, U, D
time = 1

[Command]
name = "CPU37"
command = F, F, B, U, D
time = 1

[Command]
name = "CPU38"
command = U, D, U, U, D
time = 1

[Command]
name = "CPU39"
command = F, B, B, U, D
time = 1

[Command]
name = "CPU40"
command = F, F, B, B, U, D
time = 1

[Command]
name = "CPU41"
command = U, U, F, U, D
time = 1

[Command]
name = "CPU42"
command = U, B, B, U, D
time = 1

[Command]
name = "CPU43"
command = U, B, F, F, U, D
time = 1

[Command]
name = "CPU44"
command = U, F, B, U, U, D
time = 1

[Command]
name = "CPU45"
command = U, B, F, U, U, D
time = 1

[Command]
name = "CPU46"
command = U, B, B, B, U, D
time = 1

[Command]
name = "CPU47"
command = U, D, B, F, U, D
time = 1

[Command]
name = "CPU48"
command = U, D, B, D, U, D
time = 1

[Command]
name = "CPU49"
command = U, D, F, U, U, D
time = 1

[Command]
name = "CPU50"
command = U, D, U, B, U, D
time = 1

;-| Super Motions |---------------------------------------------------------

[Command]
name = "fhcf_x"
command = ~F, B, DB, D, DF, F, x
time = 25

[Command]
name = "fhcf_x"
command = ~F, B, DB, D, DF, F, ~x
time = 25

[Command]
name = "fhcf_y"
command = ~F, B, DB, D, DF, F, y
time = 25

[Command]
name = "fhcf_y"
command = ~F, B, DB, D, DF, F, ~y
time = 25

[Command]
name = "fhcf_z"
command = ~F, B, DB, D, DF, F, z
time = 25

[Command]
name = "fhcf_z"
command = ~F, B, DB, D, DF, F, ~z
time = 25

[Command]
name = "qcbf_x"
command = ~D, DB, B, DB, F, x
time = 25

[Command]
name = "qcbf_x"
command = ~D, DB, B, DB, F, ~x
time = 25

[Command]
name = "qcbf_y"
command = ~D, DB, B, DB, F, y
time = 25

[Command]
name = "qcbf_y"
command = ~D, DB, B, DB, F, ~y
time = 25

[Command]
name = "qcbf_z"
command = ~D, DB, B, DB, F, z
time = 25

[Command]
name = "qcbf_z"
command = ~D, DB, B, DB, F, ~z
time = 25

[Command]
name = "qcfb_x"
command = ~D, DF, F, DF, B, x
time = 25

[Command]
name = "qcfb_x"
command = ~D, DF, F, DF, B, ~x
time = 25

[Command]
name = "qcfb_y"
command = ~D, DF, F, DF, B, y
time = 25

[Command]
name = "qcfb_y"
command = ~D, DF, F, DF, B, ~y
time = 25

[Command]
name = "qcfb_z"
command = ~D, DF, F, DF, B, z
time = 25

[Command]
name = "qcfb_z"
command = ~D, DF, F, DF, B, ~z
time = 25

[Command]
name = "hcbf_a"
command = ~F, DF, D, DB, B, F, a
time = 25

[Command]
name = "hcbf_a"
command = ~F, DF, D, DB, B, F, ~a
time = 25

[Command]
name = "hcbf_b"
command = ~F, DF, D, DB, B, F, b
time = 25

[Command]
name = "hcbf_b"
command = ~F, DF, D, DB, B, F, ~b
time = 25

[Command]
name = "hcbf_c"
command = ~F, DF, D, DB, B, F, c
time = 25

[Command]
name = "hcbf_c"
command = ~F, DF, D, DB, B, F, ~c
time = 25

;-| Special Motions |-------------------------------------------------------

[Command]
name = "dp_a"
command = ~F, D, DF, a
time = 12

[Command]
name = "dp_a"
command = ~F, D, DF, ~a
time = 12

[Command]
name = "dp_b"
command = ~F, D, DF, b
time = 12

[Command]
name = "dp_b"
command = ~F, D, DF, ~b
time = 12

[Command]
name = "dp_c"
command = ~F, D, DF, c
time = 12

[Command]
name = "dp_c"
command = ~F, D, DF, ~c
time = 12

[Command]
name = "qcf_x"
command = ~D, DF, F, x
time = 12

[Command]
name = "qcf_x"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "qcf_y"
command = ~D, DF, F, y
time = 12

[Command]
name = "qcf_y"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "qcf_z"
command = ~D, DF, F, z
time = 12

[Command]
name = "qcf_z"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "qcf_c"
command = ~D, DF, F, c
time = 12

[Command]
name = "qcf_c"
command = ~D, DF, F, ~c
time = 12

[Command]
name = "hcf_a"
command = ~B, DB, D, DF, F, a
time = 20

[Command]
name = "hcf_a"
command = ~B, DB, D, DF, F, ~a
time = 20

[Command]
name = "hcf_b"
command = ~B, DB, D, DF, F, b
time = 20

[Command]
name = "hcf_b"
command = ~B, DB, D, DF, F, ~b
time = 20

[Command]
name = "hcf_c"
command = ~B, DB, D, DF, F, c
time = 20

[Command]
name = "hcf_c"
command = ~B, DB, D, DF, F, ~c
time = 20

[Command]
name = "hcb_a"
command = ~F, DF, D, DB, B, a
time = 20

[Command]
name = "hcb_a"
command = ~F, DF, D, DB, B, ~a
time = 20

[Command]
name = "hcb_b"
command = ~F, DF, D, DB, B, b
time = 20

[Command]
name = "hcb_b"
command = ~F, DF, D, DB, B, ~b
time = 20

[Command]
name = "hcb_c"
command = ~F, DF, D, DB, B, c
time = 20

[Command]
name = "hcb_c"
command = ~F, DF, D, DB, B, ~c
time = 20

[Command]
name = "qcb_x"
command = ~D, DB, B, x
time = 12

[Command]
name = "qcb_x"
command = ~D, DB, B, ~x
time = 12

[Command]
name = "qcb_y"
command = ~D, DB, B, y
time = 12

[Command]
name = "qcb_y"
command = ~D, DB, B, ~y
time = 12

[Command]
name = "qcb_z"
command = ~D, DB, B, z
time = 12

[Command]
name = "qcb_z"
command = ~D, DB, B, ~z
time = 12

;-| Button Combination |----------------------------------------------------

;-| Dir + Button |----------------------------------------------------------

;-| Single Button |---------------------------------------------------------

[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 10

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

[Command]
name = "ma"
command = a+b
time = 10

;-| Do not remove! |--------------------------------------------------------

[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

;===========================================================================
[Statedef -1]

;===========================================================================
;AI�p

;AI
[State -1, AI]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
trigger31  = command = "CPU31"
trigger32  = command = "CPU32"
trigger33  = command = "CPU33"
trigger34  = command = "CPU34"
trigger35  = command = "CPU35"
trigger36  = command = "CPU36"
trigger37  = command = "CPU37"
trigger38  = command = "CPU38"
trigger39  = command = "CPU39"
trigger40  = command = "CPU40"
trigger41  = command = "CPU41"
trigger42  = command = "CPU42"
trigger43  = command = "CPU43"
trigger44  = command = "CPU44"
trigger45  = command = "CPU45"
trigger46  = command = "CPU46"
trigger47  = command = "CPU47"
trigger48  = command = "CPU48"
trigger49  = command = "CPU49"
trigger50  = command = "CPU50"
var(59) = 1

;===========================================================================
;---------------------------------------------------------------------------
;��g�i�󒆁j
[State -1]
type = ChangeState
value = 5210
triggerall = Var(59) = 1
triggerall = Alive
triggerall = CanRecover
triggerall = Vel Y > -1
triggerall = Pos Y >= -40
triggerall = StateNo = 5050
trigger1 = random = [150,200]

;---------------------------------------------------------------------------
;��g�i�n��j
[State -1]
type = ChangeState
value = 5200
triggerall = var(59) = 1
triggerall = ((var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6) && !(var(0)&2**10)) || CanRecover
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = random <= 400

;---------------------------------------------------------------------------
;�W�����v�i��������j
[state -1, Guard]
type = ChangeState
value = 40
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist || P2bodydist X = [-60,120]
triggerall = ctrl || stateno = 21
triggerall = statetype != A
trigger1 = enemynear,HitDefAttr = SC, NT,ST,HT
	trigger1 = random = [0,700]

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = var(59) = 1
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2life > 150 || (100*life/const(data.life))<=15
trigger1 = stateno = 915 && animtime = 0
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [0,60]
trigger2 = P2StateType = S || P2StateType = C
trigger2 = P2MoveType = A
trigger2 = enemynear,time >= (4+random%10)
	trigger2 = random <= 200

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = null;ChangeState
value = 875
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl

;===========================================================================
;�N���オ�胊�o�[�T��

;---------------------------------------------------------------------------
; ��������ʐS��
[State -1]
type = ChangeState
value = 3200
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (8+random%10)
triggerall = P2life > 300 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
trigger1 = P2bodydist X = [-5,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,vel X >= 0
	trigger1 = random = [100,700]
trigger2 = P2bodydist X = [-5,30]
trigger2 = P2bodydist Y = [-40,-20]
trigger2 = P2MoveType != H
trigger2 = enemynear,vel X >= 0
trigger2 = enemynear,vel Y > 1
	trigger2 = random = [100,400]
ignorehitpause = 0

;---------------------------------------------------------------------------
; �r���z���s����
[State -1]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (8+random%10)
triggerall = P2life > 300 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
trigger1 = P2bodydist X = [20,60]
trigger1 = P2MoveType = A
	trigger1 = Random = [500,900]
ignorehitpause = 0

;---------------------------------------------------------------------------
; ��������_�C��
[State -1]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (4+random%10)
trigger1 = P2bodydist X = [-5,60]
trigger1 = enemynear,vel X >= 0
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
	trigger1 = random = [200,600]
trigger2 = P2bodydist X = [20,60]
trigger2 = P2bodydist Y = [-40,-20]
trigger2 = enemynear,vel X >= 0
trigger2 = enemynear,vel Y > 1
trigger2 = P2MoveType != H
	trigger2 = random = [200,900]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
; ��������ʐS��
[State -1]
type = ChangeState
value = 3200
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = P2bodydist X = [-5,10]
trigger1 = P2StateType != A
trigger1 = P2life > 300 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
trigger1 = stateno = 200 || stateno = 400 || stateno = 430
;trigger1 = MoveType = A
trigger1 = var(36) = 1 && numtarget
trigger1 = var(17) > 1
	trigger1 = random < 300
trigger2 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = !(var(16) && numtarget)
trigger2 = P2bodydist X = [-5,30]
trigger2 = P2bodydist Y = [-40,0]
trigger2 = enemynear,vel X >= 0
trigger2 = P2StateType != A || enemynear,vel Y > 1
trigger2 = P2MoveType = I
trigger2 = P2life > 300 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
	trigger2 = random < 50
trigger3 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = !(var(16) && numtarget)
trigger3 = P2bodydist X = [-5,30]
trigger3 = P2bodydist Y = [-30,0]
trigger3 = enemynear,vel X >= 0
trigger3 = P2StateType != A || enemynear,vel Y > 1
trigger3 = P2MoveType = A
trigger3 = enemynear,time >= (8+random%10)
trigger3 = P2life > 300 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
	trigger3 = random < 100
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ���i�X�p�L�����z�Ηp�j
[State -1]
type = ChangeState
value = 1005
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = var(20) = 2 || var(20) = 6
triggerall = Power >= 1000
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = stateno = 1042
trigger1 = var(36) = 1 && numtarget
ignorehitpause = 0

;---------------------------------------------------------------------------
; �r���z���s����
[State -1]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [-5,80]
trigger1 = P2MoveType = A
trigger1 = enemynear,time >= (8+random%10)
	trigger1 = Random <= 80
trigger2 = P2bodydist X = [50,120]
trigger2 = stateno = 215 || stateno = 255 || StateNo = 410
;trigger2 = MoveType = A
trigger2 = var(36) = 1 && numtarget
trigger2 = target,life > 300 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
	trigger2 = Random <= 300
trigger3 = var(20) = 2 || var(20) = 6
trigger3 = stateno = 1005
trigger3 = prevstateno = 1020 || prevstateno = 1042 || var(17) > 2
trigger3 = var(36) = 1 && numtarget
ignorehitpause = 0

;---------------------------------------------------------------------------
; ��������_�C��
[State -1]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = P2bodydist X >= 50
trigger1 = P2StateType != A
trigger1 = stateno = 200 || stateno = 400 || stateno = 430
trigger1 = var(36) = 1 && numtarget
;trigger1 = MoveType = A
trigger1 = var(17) > 1
	trigger1 = random < 900
trigger2 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger2 = ctrl || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = !(var(16) && numtarget)
trigger2 = P2bodydist X = [-5,120]
trigger2 = P2StateType != A
trigger2 = P2MoveType = A
trigger2 = enemynear,vel X >= 0
trigger2 = enemynear,time >= (4+random%10)
	trigger2 = random < 60
trigger3 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger3 = ctrl || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = !(var(16) && numtarget)
trigger3 = P2bodydist X = [30,120]
trigger3 = P2bodydist Y = [-40,-20]
trigger3 = P2MoveType != H
trigger3 = enemynear,vel X >= 0
trigger3 = enemynear,vel Y > 1
trigger3 = enemynear,time >= (4+random%10)
	trigger3 = random < 300
trigger4 = numtarget
trigger4 = target,life > 70*fvar(10)
trigger4 = stateno = 1020
trigger4 = !var(16)
trigger4 = var(36) = 1 && numtarget
trigger5 = P2StateType != A
trigger5 = numtarget
trigger5 = target,life > 70*fvar(10)
trigger5 = stateno = 1042
trigger5 = var(36) = 1 && numtarget
trigger5 = !var(16)
trigger6 = prevstateno = [4000,4199]
trigger6 = P2bodydist X = [0,120]
trigger6 = P2bodydist Y = [-30,0]
trigger6 = ctrl
	trigger6 = random%4!=3
trigger7 = ctrl || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger7 = !(var(16) && numtarget)
trigger7 = P2stateno = 1033
trigger7 = P2bodydist X = [-5,90]
trigger7 = P2bodydist Y = [-60,-40]
trigger7 = numtarget
trigger8 = P2StateType != A
trigger8 = P2bodydist X = [-5,75]
trigger8 = var(20) = 2 || var(20) = 6
trigger8 = stateno = 1005
trigger8 = var(17) > 2
trigger8 = var(36) = 1 && numtarget
trigger8 = !var(16)
trigger9 = var(16) = [1,80]
trigger9 = ctrl || stateno = 21
trigger9 = numtarget
trigger9 = target,Pos Y > -100
trigger9 = target,vel Y > 0
trigger10 = var(16) = [1,20]
trigger10 = var(36) = 1 && numtarget
trigger10 = stateno = 1005 || stateno = 1041
trigger10 = numtarget
trigger10 = target,statetype = A
trigger11 = var(16) = [1,20]
trigger11 = var(36) = 1 && numtarget
trigger11 = stateno = 400 || stateno = 420 || stateno = 1000 || stateno = 1041
trigger11 = numtarget
trigger11 = target,statetype != A
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
; ������˂���
[State -1]
type = ChangeState
value = 1020
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = P2bodydist X = [-5,30]
trigger1 = P2StateType = S || P2StateType = C
trigger1 = stateno = 200 || stateno = 400 || stateno = 430
trigger1 = var(36) = 2
;trigger1 = MoveType = A
	trigger1 = random < 100
trigger2 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = !(var(16) && numtarget)
trigger2 = P2bodydist X = [-5,30]
trigger2 = P2StateType = C
trigger2 = P2MoveType = I
	trigger2 = random = [150,190]
ignorehitpause = 0

; ������˂���i�I���R���p�j
[State -1]
type = ChangeState
value = 1020
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = P2bodydist X = [0,30]
trigger1 = numtarget
trigger1 = target,statetype = C
trigger1 = stateno = 255 || stateno = 400 || stateno = 420 || stateno = 1000 || stateno = 1005 || stateno = 1041
trigger1 = var(36) = 2
	trigger1 = random < 50
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ��i�I���R���p�j
[State -1]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = var(16)
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = P2bodydist X >= 50
trigger1 = stateno = 420
trigger1 = prevstateno != 420
trigger1 = var(17) < 8
trigger1 = var(36) = [1,2]
trigger1 = numtarget
trigger1 = target,statetype != A
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ��
[State -1]
type = ChangeState
value = 1005
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType = S || P2StateType = C
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [100,145]
	trigger1 = random = [150,200]
trigger2 = P2bodydist X >= 50
trigger2 = stateno = 200 || stateno = 400
trigger2 = !var(16)
trigger2 = var(36) = 1 && numtarget
;trigger2 = MoveType = A
	trigger2 = random <= 900
trigger3 = stateno = 1020
trigger3 = var(36) = 1 && numtarget
	trigger3 = random%4=1
trigger4 = stateno = 1042
trigger4 = var(36) = 1 && numtarget
	trigger4 = random%4=1
ignorehitpause = 0

; ���ԂɂĎa��� ���i�I���R���p�j
[State -1]
type = ChangeState
value = 1005
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = stateno = 1041
trigger1 = var(16)
trigger1 = var(36) = [1,2]
trigger1 = numtarget
trigger1 = target,Pos Y > 0
trigger1 = target,statetype = A
trigger1 = frontedgedist >= 110
trigger2 = stateno = 1041
trigger2 = var(16)
trigger2 = var(36) = [1,2]
trigger2 = numtarget
trigger2 = target,Pos Y > -20
trigger2 = target,statetype = A
trigger2 = frontedgedist = [81,110]
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ��
[State -1]
type = ChangeState
value = 1010
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType = S || P2StateType = C
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [120,145]
	trigger1 = random = [150,180]
trigger2 = stateno = 1020
trigger2 = !var(16)
trigger2 = var(36) = 1 && numtarget
	trigger2 = random%4=1
trigger3 = stateno = 1042
trigger3 = !var(16)
trigger3 = var(36) = 1 && numtarget
	trigger3 = random%4=1
ignorehitpause = 0

;---------------------------------------------------------------------------
; �ߊ��Ďa���
[State -1]
type = ChangeState
value = 1040
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType = S || P2StateType = C
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
triggerall = !enemynear,numproj
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X >= 180
trigger1 = P2MoveType = I
	trigger1 = random = [100,130]
trigger2 = stateno = 215 || stateno = 255
trigger2 = !var(16)
trigger2 = var(36) = [1,2]

; �ߊ��Ďa���i�I���R���p�j
[State -1]
type = ChangeState
value = 1040
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = prevstateno = 870
trigger1 = stateno = 1005
trigger1 = var(16)
trigger1 = var(36) = 1 && numtarget
trigger1 = numtarget
trigger1 = target,statetype = A
trigger1 = frontedgedist >= 110
trigger2 = stateno = 1041
trigger2 = var(16)
trigger2 = var(36) = 1 && numtarget
trigger2 = numtarget
trigger2 = target,statetype = A
trigger2 = frontedgedist >= 110
trigger3 = prevstateno != 870
trigger3 = stateno = 1005
trigger3 = var(16)
trigger3 = var(36) = 1 && numtarget
trigger3 = numtarget
trigger3 = target,statetype = A
trigger3 = target,vel Y > -4
trigger3 = frontedgedist >= 110
trigger4 = stateno = 420 || stateno = 1000 || stateno = 1041
trigger4 = P2bodydist X > 50
trigger4 = var(16) >= 21
trigger4 = var(36) = [1,2]
trigger4 = numtarget
trigger4 = target,statetype != A
ignorehitpause = 0

;---------------------------------------------------------------------------
; �������킷��
[State -1]
type = ChangeState
value = 1030
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = prevstateno != [4000,4199]
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
triggerall = !(var(16) && numtarget)
trigger1 = P2stateno = [200,999]
trigger1 = P2bodydist X = [20,40]
trigger1 = P2MoveType = A
trigger1 = enemynear,Vel Y >= 0
	trigger1 = Random = [650,700]
trigger2 = P2bodydist X = [20,40]
trigger2 = P2MoveType = A
trigger2 = P2bodydist Y = [-50,0]
trigger2 = P2stateno = [1000,2999]
	trigger2 = Random = [600,630]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = ifelse(random<300-(((var(20)=1||var(20)=6)&&power=3000)*250),900,910)
triggerall = var(59) = 1
triggerall = statetype = S
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
triggerall = !var(16)
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21
	trigger1 = Random = [400,650]

;---------------------------------------------------------------------------
;�W�����v
[State -1, Jump]
type = ChangeState
value = 40
triggerall = Var(59) = 1 && StateType != A
trigger1 = numtarget
trigger1 = target,stateno = 1033
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = ((!var(20) || var(20) = 4 || var(20) = 6) && Power < 1000) || (var(20) = 1 && Power < 1500) || (var(20) = 2 && Power < 3000) || (var(20) = 3 && !var(14) && (100*life/const(data.life))>30) || (var(20) = 5 && (var(0)&2**3))
trigger2 = var(16) > 85
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = numtarget
trigger2 = target,Pos Y >= -180

;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = 200
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X >= 150
trigger1 = P2MoveType != A
trigger1 = prevstateno != 200
trigger1 = !inguarddist
	trigger1 = Random = [900,920]
ignorehitpause = 0

;---------------------------------------------------------------------------
; ������������P
[State -1]
type = ChangeState
value = 210
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = P2bodydist X > 25
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [40,80]
trigger1 = P2bodydist Y = [0,-20]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
	trigger1 = Random = [60,120]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = !(var(16) && numtarget)
trigger2 = P2bodydist X > 120
trigger2 = P2bodydist Y = [0,-20]
trigger2 = P2MoveType != A
	trigger2 = Random = [900,905]
ignorehitpause = 0

;---------------------------------------------------------------------------
; �ߋ���������P
[State -1]
type = ChangeState
value = 215
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = P2bodydist X = [-25,25]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [-5,5]
trigger1 = P2MoveType = H
	trigger1 = Random <= 400
ignorehitpause = 0

;---------------------------------------------------------------------------
; ������������P
[State -1]
type = ChangeState
value = 220
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = P2bodydist X > 25
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [40,80]
trigger1 = P2bodydist Y = [-90,-40]
trigger1 = enemynear,Vel X >= 0
trigger1 = enemynear,Vel Y > 1
trigger1 = P2StateType = A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno = [0,999])
trigger1 = frontedgebodydist > 100
	trigger1 = Random = [300,500]
ignorehitpause = 0

;---------------------------------------------------------------------------
; �ߋ���������P
[State -1]
type = ChangeState
value = 225
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = P2bodydist X = [-25,25]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [10,25]
trigger1 = P2bodydist Y = [-100,-50]
trigger1 = enemynear,Vel X >= 0
trigger1 = enemynear,Vel Y > 1
trigger1 = P2StateType = A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno = [0,999])
trigger1 = frontedgebodydist > 80
	trigger1 = Random = [300,480]
trigger2 = stateno = 1041
trigger2 = var(16)
trigger2 = var(36) = 1 && numtarget
trigger2 = numtarget
trigger2 = target,statetype = A
trigger2 = frontedgedist < 110
trigger3 = stateno = 1005
trigger3 = var(16)
trigger3 = var(36) = 1 && numtarget
trigger3 = numtarget
trigger3 = target,statetype = A
trigger3 = frontedgedist < 110
ignorehitpause = 0

;---------------------------------------------------------------------------
; ������������K
[State -1]
type = ChangeState
value = 250
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = P2bodydist X > 25
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [70,100]
trigger1 = P2StateType = S || P2StateType = C
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
	trigger1 = Random = [800,820]
ignorehitpause = 0

;---------------------------------------------------------------------------
; �ߋ���������K
[State -1]
type = ChangeState
value = 255
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = P2bodydist X = [-25,25]
triggerall = statetype != A
triggerall = P2StateType = S || P2StateType = C
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [-5,10]
trigger1 = P2MoveType != A
	trigger1 = Random <= 900
trigger2 = stateno = 3119
trigger2 = animtime = 0
trigger3 = stateno = 1041
trigger3 = var(16)
trigger3 = var(17) < 8
trigger3 = var(36) = [1,2]
trigger3 = numtarget
trigger3 = target,statetype != A
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ݎ�P
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [20,50]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = prevstateno != 400
	trigger1 = Random = [60,100]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = !(var(16) && numtarget)
trigger2 = P2bodydist X > 50
trigger2 = P2MoveType != A
trigger2 = !inguarddist
	trigger2 = Random = [800,820]
trigger3 = P2bodydist X = [20,50]
trigger3 = P2StateType != A
trigger3 = StateNo = 430
trigger3 = time > 4
trigger3 = var(36) = [1,2]
	trigger3 = Random = [100,900]
trigger4 = stateno = 1041
trigger4 = var(16)
trigger4 = var(17) >= 8
trigger4 = var(36) = 1 && numtarget
trigger4 = numtarget
trigger4 = target,statetype != A
trigger5 = P2bodydist X = [-5,30]
trigger5 = stateno = 400
trigger5 = var(16)
trigger5 = var(17) >= 8
trigger5 = var(36) = [1,2]
trigger5 = numtarget
trigger5 = target,statetype != A
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ݒ�P
[State -1]
type = ChangeState
value = 410
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [40,160]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
	trigger1 = Random = [60,80]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = !(var(16) && numtarget)
trigger2 = P2bodydist X > 120
trigger2 = P2MoveType != A
	trigger2 = Random = [800,820]
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���݋�P
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [50,80]
trigger1 = P2bodydist Y = [-60,-30]
trigger1 = enemynear,Vel X >= 0
trigger1 = enemynear,Vel Y > 1
trigger1 = P2StateType = A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno = [0,999])
	trigger1 = Random = [300,400]
trigger2 = stateno = 1041
trigger2 = var(16)
trigger2 = var(36) = 1 && numtarget
trigger2 = numtarget
trigger2 = target,statetype = A
trigger2 = frontedgedist < 80
trigger3 = stateno = 255
trigger3 = var(16)
trigger3 = var(36) = 1 && numtarget
trigger4 = P2bodydist X = [0,50]
trigger4 = stateno = 420
trigger4 = var(16)
trigger4 = var(17) < 8
trigger4 = var(36) = [1,2]
trigger4 = numtarget
trigger4 = target,statetype != A
trigger5 = P2bodydist X > 30
trigger5 = stateno = 400
trigger5 = var(16)
trigger5 = var(17) >= 8
trigger5 = var(36) = 1 && numtarget
trigger5 = numtarget
trigger5 = target,statetype != A
trigger6 = stateno = 1041
trigger6 = var(16)
trigger6 = var(17) < 8
trigger6 = var(36) = [1,2]
trigger6 = numtarget
trigger6 = target,statetype != A
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ݎ�K
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [-5,30]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = prevstateno != 430
	trigger1 = Random = [50,800]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = !(var(16) && numtarget)
trigger2 = P2bodydist X > 150
trigger2 = P2MoveType != A
trigger2 = !inguarddist
	trigger2 = Random = [800,810]
trigger3 = P2bodydist X = [-5,30]
trigger3 = P2StateType != A
trigger3 = StateNo = 430
trigger3 = prevstateno != 430
trigger3 = time > 4
trigger3 = var(36) = [1,2]
	trigger3 = Random = [100,900]
trigger4 = P2bodydist X = [0,40]
trigger4 = numtarget
trigger4 = target,statetype = S
trigger4 = stateno = 250 || stateno = 251 || stateno = 300 || stateno = 310 || stateno = 440
trigger4 = var(16) > 20
trigger4 = var(36) = 2
	trigger4 = Random <= 50

; ���ݎ�K�i�I���R���p�j
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = var(16)
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = stateno = 225 || stateno = 420 || stateno = 1005
trigger1 = var(36) = 1 && numtarget
trigger1 = frontedgedist < 110
trigger1 = numtarget
trigger1 = target,statetype = A
trigger2 = stateno = 1041
trigger2 = var(16)
trigger2 = var(36) = 1 && numtarget
trigger2 = numtarget
trigger2 = target,statetype = A
trigger2 = frontedgedist = [81,120]
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���݋�K
[State -1]
type = ChangeState
value = 450
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [80,90]
trigger1 = P2bodydist Y = [-50,-30]
trigger1 = enemynear,Vel X > 1
trigger1 = P2StateType = A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
	trigger1 = Random = [300,390]
ignorehitpause = 0

;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 610
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = P2bodydist X = [-10,50]
trigger1 = P2bodydist Y = [-40,70]
trigger1 = Pos Y <= -40
trigger1 = Ctrl && !(var(16) && numtarget)
	trigger1 = Random = [0,300]
trigger2 = P2bodydist X = [-20,100]
trigger2 = P2bodydist Y = [-29,100]
trigger2 = Ctrl && var(16)
trigger2 = numtarget
trigger2 = target,Pos Y > -120
ignorehitpause = 0

;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = P2bodydist X = [-10,100]
trigger1 = P2bodydist Y = [-80,90]
trigger1 = Ctrl && !(var(16) && numtarget)
trigger1 = Pos Y <= -50
	trigger1 = Random = [0,100]
trigger2 = P2bodydist X = [0,100]
trigger2 = P2bodydist Y = [-80,-20]
trigger2 = time > 3
trigger2 = Ctrl && !(var(16) && numtarget)
trigger2 = numtarget
trigger2 = target,stateno = 1033
trigger3 = P2bodydist X = [-20,100]
trigger3 = P2bodydist Y = [-120,-30]
trigger3 = Ctrl && var(16)
trigger3 = numtarget
trigger3 = target,Pos Y > -120
trigger4 = stateno = 610 || stateno = 620
trigger4 = var(36) = 1 && numtarget
trigger4 = var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
; �W�����v��K
[State -1]
type = ChangeState
value = 650
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
trigger1 = P2bodydist X = [-20,30]
trigger1 = P2bodydist Y = [0,90]
trigger1 = P2StateType = S
trigger1 = Ctrl && !(var(16) && numtarget)
trigger1 = Pos Y <= -40
	trigger1 = Random = [0,200]
trigger2 = P2bodydist X = [-50,30]
trigger2 = P2bodydist Y = [0,60]
trigger2 = P2StateType = C
trigger2 = !(P2MoveType = A && (P2stateno = [3000,3999]) && enemynear,HitDefAttr != SC, NT,ST,HT)
trigger2 = Ctrl && !(var(16) && numtarget)
trigger2 = Vel Y < 0
	trigger2 = Random = [0,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�K�[�h
[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype != A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,500)*(1+(statetype!=A))

[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype = A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,400)*(1+(statetype!=A))

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !var(20) || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = stateno != [120,159]
triggerall = stateno != [4000,4199]
triggerall = prevstateno != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
triggerall = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
triggerall = !(var(16) && numtarget)
trigger1 = P2bodydist X >= 200
	trigger1 = Random = [30,40]
trigger2 = P2bodydist X <= 80
trigger2 = P2MoveType != A
trigger2 = P2MoveType != H
	trigger2 = Random = [240,245]
trigger3 = P2bodydist X <= 180
trigger3 = P2MoveType = A
	trigger3 = Random = [435,440]
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A
triggerall = stateno != [120,159]
triggerall = stateno != [4000,4199]
triggerall = prevstateno != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
triggerall = !((P2stateno = [3003,3005]) && P2MoveType = H)
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
triggerall = !(var(16) && numtarget)
trigger1 = P2bodydist X <= 70
trigger1 = P2MoveType != A
trigger1 = P2MoveType != H
	trigger1 = Random <= 30
trigger2 = P2bodydist X <= 70
trigger2 = P2MoveType = A
	trigger2 = Random <= 50
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = (power < 1000 && var(20) = 3 && !var(14)) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = !inguarddist
triggerall = !enemynear,numproj
triggerall = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 160
	trigger1 = Random = [760,920]
trigger2 = P2bodydist X >= 160
trigger2 = P2StateType = L
trigger2 = teammode = single
	trigger2 = Random = [300,500]

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2Life > 150
triggerall = !((100*life/const(data.life))<=20 && P2bodydist X <= 160)
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 100
	trigger1 = Random <= 450
trigger2 = P2StateType = L
	trigger2 = Random <= 650

;---------------------------------------------------------------------------
;����
[State -1, Walk]
type = ChangeState
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
triggerall = !InGuardDist
triggerall = stateno != [10,12]
triggerall = prevstateno != [10,12]
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != 21
triggerall = prevstateno != 21
triggerall = stateno != [120,159]
triggerall = prevstateno != [120,159]
triggerall = !(var(16) && numtarget)
trigger1 = random%8<=6

;===========================================================================
;---------------------------------------------------------------------------
; ��������ʐS��
[State -1]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = Command = "fhcf_x" || Command = "fhcf_y" || Command = "fhcf_z" || (ceil(fvar(29))&2**27) || (ceil(fvar(29))&2**28) || (ceil(fvar(29))&2**29)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger23 = (StateNo = [1000,1029]) && (var(20) = 2 || var(20) = 6)
trigger24 = (StateNo = [1040,2999]) && (var(20) = 2 || var(20) = 6)
trigger25 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger26 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger27 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger28 = StateNo = 3001 && animelemtime(27) > 1 && (var(20) = 2 || var(20) = 6)
trigger29 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger30 = (StateNo = [3101,3199]) && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
; �r���z���s����
[State -1]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = Command = "hcbf_a" || Command = "hcbf_b" || Command = "hcbf_c" || (ceil(fvar(29))&2**24) || (ceil(fvar(29))&2**25) || (ceil(fvar(29))&2**26)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger23 = (StateNo = [1000,1029]) && (var(20) = 2 || var(20) = 6)
trigger24 = (StateNo = [1040,2999]) && (var(20) = 2 || var(20) = 6)
trigger25 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger26 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger27 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger28 = StateNo = 3001 && animelemtime(27) > 1 && (var(20) = 2 || var(20) = 6)
trigger29 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0

;---------------------------------------------------------------------------
; ��������_�C��
[State -1]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "qcbf_x" || Command = "qcbf_y" || Command = "qcbf_z" || (ceil(fvar(29))&2**21) || (ceil(fvar(29))&2**22) || (ceil(fvar(29))&2**23)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger23 = (StateNo = [1000,1029]) && (var(20) = 2 || var(20) = 6)
trigger24 = (StateNo = [1040,2999]) && (var(20) = 2 || var(20) = 6)
trigger25 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger26 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger27 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger28 = (StateNo = [3101,3199]) && (var(20) = 2 || var(20) = 6)
trigger29 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger30 = stateno = 1020 && var(36) = 1
trigger31 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
; ������˂���
[State -1]
type = ChangeState
value = 1020
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "dp_a" || command = "dp_b" || command = "dp_c" || (ceil(fvar(29))&2**14) || (ceil(fvar(29))&2**15) || (ceil(fvar(29))&2**16)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2)
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger23 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ��
[State -1]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "qcf_x" || (ceil(fvar(29))&2**11)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2)
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger23 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger24 = stateno = 1020 && var(36) = 1
trigger25 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ��
[State -1]
type = ChangeState
value = 1005
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "qcf_y" || (ceil(fvar(29))&2**12)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2)
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger23 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger24 = stateno = 1020 && var(36) = 1
trigger25 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ��
[State -1]
type = ChangeState
value = 1010
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "qcf_z" || (ceil(fvar(29))&2**13)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2)
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger23 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger24 = stateno = 1020 && var(36) = 1
trigger25 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; �ߊ��Ďa���
[State -1]
type = ChangeState
value = 1040
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "qcb_x" || command = "qcb_y" || command = "qcb_z" || (ceil(fvar(29))&2**8) || (ceil(fvar(29))&2**9) || (ceil(fvar(29))&2**10)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2)
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger23 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; �������킷��
[State -1]
type = ChangeState
value = 1030
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "hcf_a" || command = "hcf_b" || command = "hcf_c" || (ceil(fvar(29))&2**17) || (ceil(fvar(29))&2**18) || (ceil(fvar(29))&2**19)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2)
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger23 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger24 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ����d�ɂĂ��킷��
[State -1]
type = ChangeState
value = 1050
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "ma" || (ceil(fvar(29))&2**20)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2)
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger23 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = !var(2)
triggerall = command = "start" || (ceil(fvar(29))&2**6)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 215 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 225 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 245 && (var(16) || time <= 2)
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 255 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || time <= 2)
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger21 = (StateNo = [1040,2999]) && var(36) && var(16)
trigger22 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger23 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5200
triggerall = !var(59)
triggerall = !(var(0)&2**10)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) || (var(20) = 6 && command = "holdfwd")) && (command = "recovery" || (ceil(fvar(29))&2**7))
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 215 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 225 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 245 && time <= 2
trigger10 = StateNo = 250 && time <= 2
trigger11 = StateNo = 255 && time <= 2
trigger12 = StateNo = 400 && time <= 2
trigger13 = StateNo = 410 && time <= 2
trigger14 = StateNo = 420 && time <= 2
trigger15 = StateNo = 430 && time <= 2
trigger16 = StateNo = 440 && time <= 2
trigger17 = StateNo = 450 && time <= 2
trigger18 = (StateNo = [195,799]) && var(36) && var(16)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery" || (ceil(fvar(29))&2**7)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 215 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 225 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 245 && time <= 2
trigger10 = StateNo = 250 && time <= 2
trigger11 = StateNo = 255 && time <= 2
trigger12 = StateNo = 400 && time <= 2
trigger13 = StateNo = 410 && time <= 2
trigger14 = StateNo = 420 && time <= 2
trigger15 = StateNo = 430 && time <= 2
trigger16 = StateNo = 440 && time <= 2
trigger17 = StateNo = 450 && time <= 2
trigger18 = (StateNo = [195,799]) && var(36) && var(16)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 215 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 225 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 245 && time <= 2
trigger10 = StateNo = 250 && time <= 2
trigger11 = StateNo = 255 && time <= 2
trigger12 = StateNo = 400 && time <= 2
trigger13 = StateNo = 410 && time <= 2
trigger14 = StateNo = 420 && time <= 2
trigger15 = StateNo = 430 && time <= 2
trigger16 = StateNo = 440 && time <= 2
trigger17 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 215 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 225 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 245 && time <= 2
trigger10 = StateNo = 250 && time <= 2
trigger11 = StateNo = 255 && time <= 2
trigger12 = StateNo = 400 && time <= 2
trigger13 = StateNo = 410 && time <= 2
trigger14 = StateNo = 420 && time <= 2
trigger15 = StateNo = 430 && time <= 2
trigger16 = StateNo = 440 && time <= 2
trigger17 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 215 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 225 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 245 && time <= 2
trigger10 = StateNo = 250 && time <= 2
trigger11 = StateNo = 255 && time <= 2
trigger12 = StateNo = 400 && time <= 2
trigger13 = StateNo = 410 && time <= 2
trigger14 = StateNo = 420 && time <= 2
trigger15 = StateNo = 430 && time <= 2
trigger16 = StateNo = 440 && time <= 2
trigger17 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time <= 2
trigger3 = StateNo = 610 && time <= 2
trigger4 = StateNo = 620 && time <= 2
trigger5 = StateNo = 630 && time <= 2
trigger6 = StateNo = 640 && time <= 2
trigger7 = StateNo = 650 && time <= 2

;---------------------------------------------------------------------------
; ��������������
[State -1]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z" && (command = "holdfwd" || command = "holdback")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = P2MoveType != H || var(16)
;---------------------------------------------------------------------------
; �a�蕚�����
[State -1]
type = ChangeState
value = 910
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c" && (command = "holdfwd" || command = "holdback")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = P2MoveType != H || var(16)
;---------------------------------------------------------------------------
; ��̐���Ƃ��
[State -1]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "hold_z"
triggerall = statetype != A
trigger1 = stateno = 225 && AnimElem = 7,> 0 && AnimElem = 8,< 0
ignorehitpause = 0
;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 430 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger6 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1]
type = ChangeState
value = 215
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]
;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = ifelse((p2bodydist x = [-25,25]),215,210)
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = ifelse((p2bodydist x = [-25,25]),225,220)
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ������K
[State -1]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || (ceil(fvar(29))&2**3)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 430 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger6 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1]
type = ChangeState
value = 240
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]
;---------------------------------------------------------------------------
; ������K
[State -1]
type = ChangeState
value = ifelse((p2bodydist x = [-25,25]),245,240)
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || (ceil(fvar(29))&2**4)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ������K
[State -1]
type = ChangeState
value = ifelse((p2bodydist x = [-25,25]),255,250)
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || (ceil(fvar(29))&2**5)
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���ݎ�P
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 430 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger6 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���ݒ�P
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���݋�P
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���ݎ�K
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || (ceil(fvar(29))&2**3)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 430 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger6 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���ݒ�K
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || (ceil(fvar(29))&2**4)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���݋�K
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || (ceil(fvar(29))&2**5)
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || (ceil(fvar(29))&2**0)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || (ceil(fvar(29))&2**1)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || (ceil(fvar(29))&2**2)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��K
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || (ceil(fvar(29))&2**3)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��K
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || (ceil(fvar(29))&2**4)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��K
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || (ceil(fvar(29))&2**5)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
