;===========================================================================
; CMD file for.
;===========================================================================

;-| Super Motions |---------------------------------------------------------

[Command]
name = "fhcf_x"
command = ~F, B, DB, D, DF, F, x
time = 25

[Command]
name = "fhcf_x"
command = ~F, B, DB, D, DF, F, ~x
time = 25

[Command]
name = "fhcf_y"
command = ~F, B, DB, D, DF, F, y
time = 25

[Command]
name = "fhcf_y"
command = ~F, B, DB, D, DF, F, ~y
time = 25

[Command]
name = "fhcf_z"
command = ~F, B, DB, D, DF, F, z
time = 25

[Command]
name = "fhcf_z"
command = ~F, B, DB, D, DF, F, ~z
time = 25

[Command]
name = "qcbf_x"
command = ~D, DB, B, DB, F, x
time = 25

[Command]
name = "qcbf_x"
command = ~D, DB, B, DB, F, ~x
time = 25

[Command]
name = "qcbf_y"
command = ~D, DB, B, DB, F, y
time = 25

[Command]
name = "qcbf_y"
command = ~D, DB, B, DB, F, ~y
time = 25

[Command]
name = "qcbf_z"
command = ~D, DB, B, DB, F, z
time = 25

[Command]
name = "qcbf_z"
command = ~D, DB, B, DB, F, ~z
time = 25

[Command]
name = "qcfb_x"
command = ~D, DF, F, DF, B, x
time = 25

[Command]
name = "qcfb_x"
command = ~D, DF, F, DF, B, ~x
time = 25

[Command]
name = "qcfb_y"
command = ~D, DF, F, DF, B, y
time = 25

[Command]
name = "qcfb_y"
command = ~D, DF, F, DF, B, ~y
time = 25

[Command]
name = "qcfb_z"
command = ~D, DF, F, DF, B, z
time = 25

[Command]
name = "qcfb_z"
command = ~D, DF, F, DF, B, ~z
time = 25

[Command]
name = "hcbf_a"
command = ~F, DF, D, DB, B, F, a
time = 25

[Command]
name = "hcbf_a"
command = ~F, DF, D, DB, B, F, ~a
time = 25

[Command]
name = "hcbf_b"
command = ~F, DF, D, DB, B, F, b
time = 25

[Command]
name = "hcbf_b"
command = ~F, DF, D, DB, B, F, ~b
time = 25

[Command]
name = "hcbf_c"
command = ~F, DF, D, DB, B, F, c
time = 25

[Command]
name = "hcbf_c"
command = ~F, DF, D, DB, B, F, ~c
time = 25

;-| Special Motions |-------------------------------------------------------

[Command]
name = "dp_a"
command = ~F, D, DF, a
time = 12

[Command]
name = "dp_a"
command = ~F, D, DF, ~a
time = 12

[Command]
name = "dp_b"
command = ~F, D, DF, b
time = 12

[Command]
name = "dp_b"
command = ~F, D, DF, ~b
time = 12

[Command]
name = "dp_c"
command = ~F, D, DF, c
time = 12

[Command]
name = "dp_c"
command = ~F, D, DF, ~c
time = 12

[Command]
name = "qcf_x"
command = ~D, DF, F, x
time = 12

[Command]
name = "qcf_x"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "qcf_y"
command = ~D, DF, F, y
time = 12

[Command]
name = "qcf_y"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "qcf_z"
command = ~D, DF, F, z
time = 12

[Command]
name = "qcf_z"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "qcf_c"
command = ~D, DF, F, c
time = 12

[Command]
name = "qcf_c"
command = ~D, DF, F, ~c
time = 12

[Command]
name = "hcf_a"
command = ~B, DB, D, DF, F, a
time = 20

[Command]
name = "hcf_a"
command = ~B, DB, D, DF, F, ~a
time = 20

[Command]
name = "hcf_b"
command = ~B, DB, D, DF, F, b
time = 20

[Command]
name = "hcf_b"
command = ~B, DB, D, DF, F, ~b
time = 20

[Command]
name = "hcf_c"
command = ~B, DB, D, DF, F, c
time = 20

[Command]
name = "hcf_c"
command = ~B, DB, D, DF, F, ~c
time = 20

[Command]
name = "hcb_a"
command = ~F, DF, D, DB, B, a
time = 20

[Command]
name = "hcb_a"
command = ~F, DF, D, DB, B, ~a
time = 20

[Command]
name = "hcb_b"
command = ~F, DF, D, DB, B, b
time = 20

[Command]
name = "hcb_b"
command = ~F, DF, D, DB, B, ~b
time = 20

[Command]
name = "hcb_c"
command = ~F, DF, D, DB, B, c
time = 20

[Command]
name = "hcb_c"
command = ~F, DF, D, DB, B, ~c
time = 20

[Command]
name = "qcb_x"
command = ~D, DB, B, x
time = 12

[Command]
name = "qcb_x"
command = ~D, DB, B, ~x
time = 12

[Command]
name = "qcb_y"
command = ~D, DB, B, y
time = 12

[Command]
name = "qcb_y"
command = ~D, DB, B, ~y
time = 12

[Command]
name = "qcb_z"
command = ~D, DB, B, z
time = 12

[Command]
name = "qcb_z"
command = ~D, DB, B, ~z
time = 12

;-| Button Combination |----------------------------------------------------

;-| Dir + Button |----------------------------------------------------------

;-| Single Button |---------------------------------------------------------

[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 18

[Command]
name = "FF"     
command = F, F
time = 12

[Command]
name = "BB"     
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

[Command]
name = "ma"
command = a+b
time = 10

[Command]
name = "ma"
command = b+c
time = 10

[Command]
name = "ma"
command = c+a
time = 10

[Command]
name = "ma"
command = a+b+c
time = 10

;-| Do not remove! |--------------------------------------------------------

[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

;===========================================================================

[Statedef -1]
;---------------------------------------------------------------------------
; ��������ʐS��
[State -1]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(18))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || var(43) 
triggerall = Command = "fhcf_x" || Command = "fhcf_y" || Command = "fhcf_z" || floor(fvar(29)*.1) = 3200
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(6) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
trigger21 = (StateNo = [1000,1029]) && statetype != A && (var(20) = 2 || var(20) = 6)
trigger22 = (StateNo = [1040,1049]) && statetype != A && (var(20) = 2 || var(20) = 6)
trigger23 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger24 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger25 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger26 = StateNo = 3001 && animelemtime(27) > 1 && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger28 = (StateNo = [3101,3199]) && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
; �r���z���s����
[State -1]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(18))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || var(43) 
triggerall = Command = "hcbf_a" || Command = "hcbf_b" || Command = "hcbf_c" || floor(fvar(29)*.1) = 3100
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(6) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
trigger21 = (StateNo = [1000,1029]) && statetype != A && (var(20) = 2 || var(20) = 6)
trigger22 = (StateNo = [1040,1049]) && statetype != A && (var(20) = 2 || var(20) = 6)
trigger23 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger24 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger25 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger26 = StateNo = 3001 && animelemtime(27) > 1 && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0

;---------------------------------------------------------------------------
; ��������_�C��
[State -1]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = Command = "a" || fvar(30) = 4
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(6) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
trigger21 = (StateNo = [1000,1029]) && statetype != A && (var(20) = 2 || var(20) = 6)
trigger22 = (StateNo = [1040,1049]) && statetype != A && (var(20) = 2 || var(20) = 6)
trigger23 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger24 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger25 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger26 = (StateNo = [3101,3199]) && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger28 = stateno = 1020 && var(36) = 1
trigger29 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ������˂���
[State -1]
type = ChangeState
value = 1020
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "dp_a" || command = "dp_b" || command = "dp_c" || floor(fvar(29)*.1) = 1020
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0)
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(3) < 0)
trigger7 = StateNo = 230 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0)
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 0)
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
trigger21 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger22 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ��
[State -1]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "qcf_x" || floor(fvar(29)*.1) = 1000
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0)
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(3) < 0)
trigger7 = StateNo = 230 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0)
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 0)
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
trigger21 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger22 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger23 = stateno = 1020 && var(36) = 1
trigger24 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ��
[State -1]
type = ChangeState
value = 1005
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "qcf_y" || floor(fvar(29)*.1) = 1005
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0)
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(3) < 0)
trigger7 = StateNo = 230 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0)
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 0)
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
trigger21 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger22 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger23 = stateno = 1020 && var(36) = 1
trigger24 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ���ԂɂĎa��� ��
[State -1]
type = ChangeState
value = 1010
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "qcf_z" || floor(fvar(29)*.1) = 1010
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0)
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(3) < 0)
trigger7 = StateNo = 230 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0)
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 0)
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
trigger21 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger22 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger23 = stateno = 1020 && var(36) = 1
trigger24 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; �ߊ��Ďa���
[State -1]
type = ChangeState
value = 1040
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "qcb_x" || command = "qcb_y" || command = "qcb_z" || floor(fvar(29)*.1) = 1040
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0)
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(3) < 0)
trigger7 = StateNo = 230 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0)
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 0)
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && statetype != A && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && statetype != A && var(36) && var(16)
trigger21 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger22 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ����d�ɂĂ��킷��
[State -1]
type = ChangeState
value = 1040
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 215 && var(36) = 1 && time > 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; �������킷��
[State -1]
type = ChangeState
value = 1030
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || command = "hcf_b" || command = "hcf_c" || floor(fvar(29)*.1) = 1030
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0)
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(3) < 0)
trigger7 = StateNo = 230 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0)
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 0)
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && statetype != A && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && statetype != A && var(36) && var(16)
trigger21 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger22 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
trigger23 = stateno = 1042 && var(36) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ����d�ɂĂ��킷��
[State -1]
type = ChangeState
value = 1050
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "ma" || floor(fvar(29)*.1) = 1050
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0)
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(3) < 0)
trigger7 = StateNo = 230 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0)
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 0)
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && statetype != A && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && statetype != A && var(36) && var(16)
trigger21 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger22 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
; ����d�ɂĂ��킷��
[State -1]
type = ChangeState
value = 1020
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = StateNo = 3000 && var(36) = 1 && Var(5) = 1 && !var(20)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = Power >= 3000 && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = !var(2)
triggerall = command = "start" || floor(fvar(29)*.1) = 195
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0)
trigger4 = StateNo = 215 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 225 && (var(16) || animelemtime(3) < 0)
trigger7 = StateNo = 230 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 245 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 250 && (var(16) || animelemtime(4) < 0)
trigger11 = StateNo = 255 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 400 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 0)
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 0)
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
trigger21 = StateNo = 3000 && var(36) = 1 && Var(5) = 1
trigger22 = StateNo = 3001 && animelemtime(27) > 1 && Var(5) = 1
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) || (var(20) = 6 && command = "holdfwd")) && (command = "recovery" || fvar(30) = 7)
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 215 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 225 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 245 && time < 2
trigger10 = StateNo = 250 && time < 2
trigger11 = StateNo = 255 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery" || fvar(30) = 7
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 215 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 225 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 245 && time < 2
trigger10 = StateNo = 250 && time < 2
trigger11 = StateNo = 255 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger19 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger20 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 215 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 225 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 245 && time < 2
trigger10 = StateNo = 250 && time < 2
trigger11 = StateNo = 255 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 215 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 225 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 245 && time < 2
trigger10 = StateNo = 250 && time < 2
trigger11 = StateNo = 255 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 215 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 225 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 245 && time < 2
trigger10 = StateNo = 250 && time < 2
trigger11 = StateNo = 255 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time < 2
trigger3 = StateNo = 610 && time < 2
trigger4 = StateNo = 620 && time < 2
trigger5 = StateNo = 630 && time < 2
trigger6 = StateNo = 640 && time < 2
trigger7 = StateNo = 650 && time < 2

;---------------------------------------------------------------------------
; ��������������
[State -1]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
trigger1 = command = "z" && (command = "holdfwd" || command = "holdback")
trigger1 = statetype = S && ctrl && p2BodyDist X <= 22 && enemynear,MoveType != H
trigger1 = p2statetype = S || p2statetype = C
;---------------------------------------------------------------------------
; �a�蕚�����
[State -1]
type = ChangeState
value = 910
triggerall = !var(59)
triggerall = roundstate = 2
trigger1 = command = "c" && (command = "holdfwd" || command = "holdback")
trigger1 = statetype = S && ctrl && p2BodyDist X <= 22 && enemynear,MoveType != H
trigger1 = p2statetype = S || p2statetype = C
;---------------------------------------------------------------------------
; ��̐���Ƃ��
[State -1]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "hold_z"
triggerall = statetype != A
trigger1 = stateno = 225 && AnimElem = 7,> 0 && AnimElem = 8,< 0
ignorehitpause = 0
;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || fvar(30) = 1
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 430 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger6 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1]
type = ChangeState
value = 215
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]
;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = ifelse(p2bodydist x < 25,215,210)
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || fvar(30) = 2
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = ifelse(p2bodydist x < 25,215,210)
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = anim = 20 && time = 6 && var(17) = 5
ignorehitpause = 0
;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = ifelse(p2bodydist x < 25,225,220)
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || fvar(30) = 3
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ������K
[State -1]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || fvar(30) = 4
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 430 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger6 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1]
type = ChangeState
value = 240
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]
;---------------------------------------------------------------------------
; ������K
[State -1]
type = ChangeState
value = ifelse(p2bodydist x < 25,245,240)
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || fvar(30) = 5
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ������K
[State -1]
type = ChangeState
value = ifelse(p2bodydist x < 25,255,250)
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || fvar(30) = 6
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���ݎ�P
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || fvar(30) = 1
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 430 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger6 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���ݒ�P
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || fvar(30) = 2
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���݋�P
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || fvar(30) = 3
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���ݎ�K
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || fvar(30) = 4
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 430 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger6 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���ݒ�K
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || fvar(30) = 5
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; ���݋�K
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || fvar(30) = 6
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1029]) && var(36) && var(16)
trigger4 = (StateNo = [1040,1049]) && var(36) && var(16)
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x" || fvar(30) = 1
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y" || fvar(30) = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z" || fvar(30) = 3
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = StateNo = 1070 && time = 21
;---------------------------------------------------------------------------
; �W�����v��K
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || fvar(30) = 4
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��K
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b" || fvar(30) = 5
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------
; �W�����v��K
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c" || fvar(30) = 6
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 1070
ignorehitpause = 0
;---------------------------------------------------------------------------