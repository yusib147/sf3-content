;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

[Command]
name = "CPU31"
command = U, D, F, U, D
time = 1

[Command]
name = "CPU32"
command = U, B, F, U, D
time = 1

[Command]
name = "CPU33"
command = U, D, D, U, D
time = 1

[Command]
name = "CPU34"
command = F, B, U, U, D
time = 1

[Command]
name = "CPU35"
command = U, F, U, B, U, D
time = 1

[Command]
name = "CPU36"
command = U, D, B, U, D
time = 1

[Command]
name = "CPU37"
command = F, F, B, U, D
time = 1

[Command]
name = "CPU38"
command = U, D, U, U, D
time = 1

[Command]
name = "CPU39"
command = F, B, B, U, D
time = 1

[Command]
name = "CPU40"
command = F, F, B, B, U, D
time = 1

[Command]
name = "CPU41"
command = U, U, F, U, D
time = 1

[Command]
name = "CPU42"
command = U, B, B, U, D
time = 1

[Command]
name = "CPU43"
command = U, B, F, F, U, D
time = 1

[Command]
name = "CPU44"
command = U, F, B, U, U, D
time = 1

[Command]
name = "CPU45"
command = U, B, F, U, U, D
time = 1

[Command]
name = "CPU46"
command = U, B, B, B, U, D
time = 1

[Command]
name = "CPU47"
command = U, D, B, F, U, D
time = 1

[Command]
name = "CPU48"
command = U, D, B, D, U, D
time = 1

[Command]
name = "CPU49"
command = U, D, F, U, U, D
time = 1

[Command]
name = "CPU50"
command = U, D, U, B, U, D
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "�o���V�@��1"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "�o���V�@��1"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "�o���V�@��2"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "�o���V�@��2"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "�o���V�@��3"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "�o���V�@��3"
command = ~D, DF, F, D, DF, ~z
time = 21

[Command]
name = "�V�ė��P1"
command = ~D, DF, F, D, DF, a
time = 21

[Command]
name = "�V�ė��P1"
command = ~D, DF, F, D, DF, ~a
time = 21

[Command]
name = "�V�ė��P2"
command = ~D, DF, F, D, DF, b
time = 21

[Command]
name = "�V�ė��P2"
command = ~D, DF, F, D, DF, ~b
time = 21

[Command]
name = "�V�ė��P3"
command = ~D, DF, F, D, DF, c
time = 21

[Command]
name = "�V�ė��P3"
command = ~D, DF, F, D, DF, ~c
time = 21

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "���C��1"
command = ~D, DF, F, x
time = 12

[Command]
name = "���C��1"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "���C��2"
command = ~D, DF, F, y
time = 12

[Command]
name = "���C��2"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "���C��3"
command = ~D, DF, F, z
time = 12

[Command]
name = "���C��3"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "�]�g��1"
command = ~F, D, DF, a
time = 12

[Command]
name = "�]�g��1"
command = ~F, D, DF, ~a
time = 12

[Command]
name = "�]�g��2"
command = ~F, D, DF, b
time = 12

[Command]
name = "�]�g��2"
command = ~F, D, DF, ~b
time = 12

[Command]
name = "�]�g��3"
command = ~F, D, DF, c
time = 12

[Command]
name = "�]�g��3"
command = ~F, D, DF, ~c
time = 12

[Command]
name = "�A���R1"
command = ~D, DB, B, a
time = 12

[Command]
name = "�A���R1"
command = ~D, DB, B, ~a
time = 12

[Command]
name = "�A���R2"
command = ~D, DB, B, b
time = 12

[Command]
name = "�A���R2"
command = ~D, DB, B, ~b
time = 12

[Command]
name = "�A���R3"
command = ~D, DB, B, c
time = 12

[Command]
name = "�A���R3"
command = ~D, DB, B, ~c
time = 12

[Command]
name = "�o���i1"
command = ~D, DB, B, x
time = 12

[Command]
name = "�o���i1"
command = ~D, DB, B, ~x
time = 12

[Command]
name = "�o���i2"
command = ~D, DB, B, y
time = 12

[Command]
name = "�o���i2"
command = ~D, DB, B, ~y
time = 12

[Command]
name = "�o���i3"
command = ~D, DB, B, z
time = 12

[Command]
name = "�o���i3"
command = ~D, DB, B, ~z
time = 12

[Command]
name = "�Ք��r1"
command = ~D, DB, B, a
time = 12

[Command]
name = "�Ք��r1"
command = ~D, DB, B, ~a
time = 12

[Command]
name = "�Ք��r2"
command = ~D, DB, B, b
time = 12

[Command]
name = "�Ք��r2"
command = ~D, DB, B, ~b
time = 12

[Command]
name = "�Ք��r3"
command = ~D, DB, B, c
time = 12

[Command]
name = "�Ք��r3"
command = ~D, DB, B, ~c
time = 12

[Command]
name = "�Ώ��1"
command = ~B, DB, D, DF, F, a
time = 18

[Command]
name = "�Ώ��1"
command = ~B, DB, D, DF, F, ~a
time = 18

[Command]
name = "�Ώ��2"
command = ~B, DB, D, DF, F, b
time = 18

[Command]
name = "�Ώ��2"
command = ~B, DB, D, DF, F, ~b
time = 18

[Command]
name = "�Ώ��3"
command = ~B, DB, D, DF, F, c
time = 18

[Command]
name = "�Ώ��3"
command = ~B, DB, D, DF, F, ~c
time = 18

[Command]
name = "�u���[�L���O"
command = a+b
time = 1

[Command]
name = "�u���[�L���O"
command = b+c
time = 1

[Command]
name = "�u���[�L���O"
command = c+a
time = 1

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 10

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;AI�p

;AI
[State -1, AI]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
trigger31  = command = "CPU31"
trigger32  = command = "CPU32"
trigger33  = command = "CPU33"
trigger34  = command = "CPU34"
trigger35  = command = "CPU35"
trigger36  = command = "CPU36"
trigger37  = command = "CPU37"
trigger38  = command = "CPU38"
trigger39  = command = "CPU39"
trigger40  = command = "CPU40"
trigger41  = command = "CPU41"
trigger42  = command = "CPU42"
trigger43  = command = "CPU43"
trigger44  = command = "CPU44"
trigger45  = command = "CPU45"
trigger46  = command = "CPU46"
trigger47  = command = "CPU47"
trigger48  = command = "CPU48"
trigger49  = command = "CPU49"
trigger50  = command = "CPU50"
var(59) = 1

;===========================================================================
;�ډ���
;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl
trigger1 = prevstateno = 400 || prevstateno = 430
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [100,400+((var(17)>1)*550)]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;��g�i�󒆁j
[State -1]
type = ChangeState
value = 5210
triggerall = Var(59) = 1
triggerall = Alive
triggerall = CanRecover
triggerall = Vel Y > -1
triggerall = Pos Y >= -40
triggerall = StateNo = 5050
trigger1 = random = [150,200]

;---------------------------------------------------------------------------
;��g�i�n��j
[State -1]
type = ChangeState
value = 5200
triggerall = var(59) = 1
triggerall = ((var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6) && !(var(0)&2**10)) || CanRecover
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = random <= 400

;---------------------------------------------------------------------------
;�W�����v�i��������j
[state -1, Guard]
type = ChangeState
value = 40
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist || P2bodydist X = [-60,120]
triggerall = ctrl || stateno = 21
triggerall = statetype != A
trigger1 = enemynear,HitDefAttr = SC, NT,ST,HT
	trigger1 = random = [0,700]

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = var(59) = 1
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,45]
trigger1 = P2StateType = S || P2StateType = C
trigger1 = P2MoveType = A
trigger1 = enemynear,time >= (5+random%10)
trigger1 = P2life > 150 || (100*life/const(data.life))<=15
	trigger1 = random <= 400
trigger2 = P2bodydist X = [-15,50]
trigger2 = P2StateType = A
trigger2 = frontedgedist <= 50
trigger2 = stateno = 1205
trigger2 = animtime = 0
trigger2 = var(17)
trigger2 = numtarget
trigger2 = target,life > 150 || (100*life/const(data.life))<=15

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
;[State -1]
;type = ChangeState
;value = 875
;triggerall = var(59) = 1
;triggerall = !(var(0)&2**5)
;triggerall = var(20) = 1 || var(20) = 6
;triggerall = !var(15) && !var(16)
;triggerall = roundstate = 2
;trigger1 = statetype = A
;trigger1 = ctrl

;---------------------------------------------------------------------------
;����
[State -1, Walk]
type = ChangeState
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
triggerall = !InGuardDist
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != 21
triggerall = prevstateno != 21
triggerall = stateno != [120,159]
triggerall = prevstateno != [120,159]
trigger1 = stateno != [10,12]
trigger1 = prevstateno != [10,12]
trigger1 = !(var(16) && numtarget)
	trigger1 = random%4=0
trigger2 = var(45) || var(23) = 1
trigger2 = !(var(16) && numtarget)
trigger2 = frontedgedist <= 60
;	trigger2 = Random = [50,950]

;---------------------------------------------------------------------------
;�W�����v
[State -1, Jump]
type = ChangeState
value = 40
triggerall = var(59) = 1
triggerall = StateType != A
triggerall = Ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X > 60
trigger1 = var(45) || var(23) = 1
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [50,450]

;===========================================================================
;�I���R��
;---------------------------------------------------------------------------
;�]�g��
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 1205 && (var(36) = [1,2]))
trigger1 = P2bodydist X = [-5,40]
trigger1 = P2bodydist Y = [-80,-30]
trigger1 = P2StateType = A
trigger1 = P2MoveType = H
trigger1 = numtarget
trigger1 = var(16) > 60
trigger2 = P2StateType = A
trigger2 = stateno = 220 || stateno = 221 || stateno = 240 || stateno = 241
trigger2 = var(36) = [1,2]
trigger2 = var(16) > 60
ignorehitpause = 0

;---------------------------------------------------------------------------
;��P
[State -1, hadouken]
type = ChangeState
value = 220+(P2bodydist X = [-20,20])
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2StateType != A
trigger1 = stateno = 220 || stateno = 221 || stateno = 240 || stateno = 241 || stateno = 1301 && animelemtime(2) >= 0
trigger1 = P2bodydist X < 30
trigger1 = var(36) = [1,2]
trigger1 = var(17) = [1,10)
trigger1 = var(16) > 30
ignorehitpause = 0

;---------------------------------------------------------------------------
;�o���i
[State -1, hadouken]
type = ChangeState
value = 1300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = stateno = 1301 && animelemtime(2) >= 0 && (var(36) = [1,2])
trigger1 = P2bodydist X = [-5,40]
trigger1 = P2MoveType = H
trigger1 = numtarget
trigger1 = var(16) > 30
trigger2 = P2StateType != A
trigger2 = stateno = 220 || stateno = 221 || stateno = 240 || stateno = 241
trigger2 = P2bodydist X >= 30
trigger2 = var(36) = [1,2]
trigger2 = var(16) > 30
ignorehitpause = 0

;---------------------------------------------------------------------------
;�V�ė��P
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 1205 && (var(36) = [1,2]))
trigger1 = P2bodydist X = [-15,30]
trigger1 = numtarget
trigger1 = target,Pos Y = [-80,-50]
trigger1 = var(16) = [1,60)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�o���V�@��
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = stateno = 1301 && animelemtime(2) >= 0 && (var(36) = [1,2])
trigger1 = P2MoveType = H
trigger1 = numtarget
trigger1 = var(16) = [1,30)
ignorehitpause = 0

;===========================================================================
;�N���オ�胊�o�[�T��
;---------------------------------------------------------------------------
;�V�ė��P
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)||(var(0)&2**3)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (10+random%10)
trigger1 = P2bodydist X = [-5,30]
trigger1 = P2bodydist Y = [-60,-40]
trigger1 = P2MoveType != H
trigger1 = enemynear,vel X >= 0
trigger1 = enemynear,vel Y > 0
	trigger1 = Random >= 300
ignorehitpause = 0

;---------------------------------------------------------------------------
;�o���V�@��
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)||(var(0)&2**3)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (10+random%10)
trigger1 = P2bodydist X = [-5,40]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
	rigger1 = Random <= 500
ignorehitpause = 0

;---------------------------------------------------------------------------
;�]�g��
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (10+random%10)
trigger1 = P2bodydist X = [-5,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
	trigger1 = Random > 700
trigger2 = P2bodydist X = [-5,30]
trigger2 = P2bodydist Y = [-50,-30]
trigger2 = P2StateType = A
trigger2 = P2MoveType != H
trigger2 = enemynear,vel X >= 0
trigger2 = enemynear,vel Y > 0
	trigger2 = Random > 200
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�o���V�@��
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)||(var(0)&2**3)
trigger1 = P2bodydist X = [-5,50]
trigger1 = P2MoveType = A
trigger1 = enemynear,vel X >= 0
trigger1 = enemynear,time >= (10+random%10)
trigger1 = !(var(16) && numtarget)
	trigger1 = random < 200
trigger2 = P2bodydist X = [-5,50]
trigger2 = (StateNo = 241 && animelemtime(5) < 0) || StateNo = 410 || (StateNo = 440 && animelemtime(5) < 0)
trigger2 = var(36) = 1 && numtarget
trigger2 = var(17) >= 2
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
trigger2 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger2 = Random < 100+((var(17)>1)*900)-((var(20)=1)*900)
trigger3 = P2bodydist X = [-5,50]
trigger3 = (StateNo = 220 && animelemtime(8) < 1) || (StateNo = 221 && animelemtime(7) < 1) || (StateNo = 420 && animelemtime(6) < 0)
trigger3 = var(36) = 1 && numtarget
trigger3 = var(17) >= 2
trigger3 = !(var(16) && numtarget)
trigger3 = MoveType = A
trigger3 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger3 = Random < 300+((var(17)>1)*500)-((var(20)=1)*700)
trigger4 = P2bodydist X = [25,45]
trigger4 = StateNo = 400 || StateNo = 430
trigger4 = PrevStateNo = 400 || PrevStateNo = 430
trigger4 = var(36) = 1 && numtarget
trigger4 = var(17) >= 2
trigger4 = !(var(16) && numtarget)
trigger4 = MoveType = A
trigger4 = target,life > 100 || var(20) = 3 || var(20) = 5
trigger4 = frontedgedist > 50
	trigger4 = Random < 300+((var(17)>1)*500)-((var(20)=1)*700)
trigger5 = prevstateno = [4000,4199]
trigger5 = P2bodydist X = [-5,50]
trigger5 = ctrl
	trigger5 = random%4!=3
trigger6 = P2bodydist X = [-5,60]
trigger6 = StateNo = 1000
trigger6 = var(36) = 3 && numtarget
trigger6 = var(17) >= 2
trigger6 = var(20) = 2 || var(20) = 6
trigger6 = !(var(16) && numtarget)
trigger6 = target,life > 150
	trigger6 = Random < 600
ignorehitpause = 0

;---------------------------------------------------------------------------
;�V�ė��P
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)||(var(0)&2**3)
trigger1 = P2bodydist X = [-5,20]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,vel X >= 0
trigger1 = enemynear,time >= (10+random%10)
trigger1 = !(var(16) && numtarget)
	trigger1 = random < 150
trigger2 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)||(var(0)&2**3)
trigger2 = P2bodydist X = [-5,30]
trigger2 = P2bodydist Y = [-60,-40]
trigger2 = P2MoveType != H
trigger2 = enemynear,vel X >= 0
trigger2 = enemynear,vel Y >= 0
trigger2 = !(var(16) && numtarget)
	trigger2 = random < 300
trigger3 = P2bodydist X = [-5,20]
trigger3 = P2StateType != A
trigger3 = (StateNo = 241 && animelemtime(5) < 0) || StateNo = 410 || (StateNo = 440 && animelemtime(5) < 0)
trigger3 = var(36) = 1 && numtarget
trigger3 = var(17) >= 2
trigger3 = !(var(16) && numtarget)
trigger3 = MoveType = A
	trigger3 = Random < 700-((var(20)=1)*550)
trigger4 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger4 = P2bodydist X = [-5,30]
trigger4 = numtarget
trigger4 = target,Pos Y = [-70,-50]
trigger4 = var(45) || var(23) = 1
trigger4 = var(20) != 1
trigger4 = !(var(16) && numtarget)
trigger5 = prevstateno = [4000,4199]
trigger5 = P2bodydist X = [-5,20]
trigger5 = P2bodydist Y = [-60,-40]
trigger5 = ctrl
	trigger5 = random%4!=3
trigger6 = StateNo = 1301 && animelemtime(10) > 0
trigger6 = var(36) = 1 && numtarget
trigger6 = var(20) = 2 || var(20) = 6
trigger6 = !(var(16) && numtarget)
trigger6 = MoveType = A
trigger6 = target,life > 150
	trigger6 = Random < 900
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�]�g��
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [-5,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = !(var(16) && numtarget)
trigger1 = enemynear,time >= (10+random%10)
	trigger1 = Random > 950
trigger2 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = P2bodydist X = [-5,40]
trigger2 = P2bodydist Y = [-50,-30]
trigger2 = P2StateType = A
trigger2 = P2MoveType != H
trigger2 = enemynear,vel X >= 0
trigger2 = enemynear,vel Y > 0
trigger2 = !(var(16) && numtarget)
	trigger2 = Random > 750
trigger3 = P2bodydist X = [-5,25]
trigger3 = numtarget
trigger3 = target,Pos Y = [-50,-30]
trigger3 = prevstateno = [4000,4199]
trigger3 = ctrl
trigger3 = !(var(16) && numtarget)
	trigger3 = random%5=2
trigger4 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger4 = P2bodydist X = [-5,30]
trigger4 = numtarget
trigger4 = target,Pos Y = [-50,-40]
trigger4 = var(45) || var(23) = 1
trigger4 = !(var(16) && numtarget)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�A���R
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = Pos Y <= -30
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = Vel Y > 1
trigger1 = Pos Y < -60
trigger1 = P2bodydist X = [-1,80]
trigger1 = P2bodydist Y = [0,90]
trigger1 = Ctrl
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [780,800]
trigger2 = StateNo = 610
trigger2 = var(36) = 1 && numtarget
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
	trigger2 = Random = [100,950]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�Ք��r
[State -1, hadouken]
type = ChangeState
value = 1500
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !inguarddist
trigger1 = P2bodydist X = [-5,10]
trigger1 = P2StateType != A
trigger1 = (StateNo = 221 && animelemtime(7) < 1) || (StateNo = 241 && animelemtime(5) < 0) || StateNo = 410 || (StateNo = 420 && animelemtime(6) < 0) || (StateNo = 440 && animelemtime(5) < 0)
trigger1 = var(36) = 1 && numtarget
trigger1 = !(var(16) && numtarget)
trigger1 = MoveType = A
	trigger1 = Random = [100,250-((var(17)>1)*700)]
trigger2 = P2bodydist X = [10,30]
trigger2 = P2StateType != A
trigger2 = StateNo = 400 || StateNo = 430
trigger2 = var(36) = 1 && numtarget
trigger2 = var(17) >= 2
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
trigger2 = !(((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)) || var(20) = 1
	trigger2 = Random < 550+((frontedgedist<=60)*600)+((var(20)=1)*600)
trigger3 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = P2bodydist X >= 130
trigger3 = enemynear,NumProj
trigger3 = !(var(16) && numtarget)
	trigger3 = random = [100,120]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�o���i
[State -1, hadouken]
type = ChangeState
value = 1300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-5,20]
trigger1 = P2StateType != A
trigger1 = (StateNo = 241 && animelemtime(5) < 0) || StateNo = 410 || (StateNo = 440 && animelemtime(5) < 0)
trigger1 = var(36) = 1 && numtarget
trigger1 = !(var(16) && numtarget)
trigger1 = MoveType = A
	trigger1 = Random < 100+((var(17)>1)*400)
trigger2 = P2StateType != A
trigger2 = (StateNo = 221 && animelemtime(7) < 1) || (StateNo = 420 && animelemtime(6) < 0)
trigger2 = var(36) = 1 && numtarget
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
	trigger2 = Random < 400+((var(17)>1)*400)-((frontedgedist>=50)*300)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�Ώ��
[State -1, hadouken]
type = ChangeState
value = 1400
triggerall = var(59) = 1
triggerall = statetype = S
triggerall = stateno != 100
triggerall = p2bodydist X = [-5,15]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
triggerall = !var(16)
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
	trigger1 = Random = [640,700]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���C��
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !NumProjID(1005)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X > 150
trigger1 = P2bodydist Y = [-60,0]
trigger1 = P2MoveType != H
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [900,999]
trigger2 = P2StateType != A
trigger2 = StateNo = 420 && animelemtime(6) < 0
trigger2 = var(36) = [1,2]
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [100,999]
trigger3 = P2StateType != A
trigger3 = (StateNo = 221 && animelemtime(7) < 1)
trigger3 = var(36) = [1,2]
trigger3 = !(var(16) && numtarget)
trigger3 = MoveType = A
	trigger3 = Random = [100,300]
trigger4 = P2StateType != A
trigger4 = (StateNo = 241 && animelemtime(5) < 0) || StateNo = 410
trigger4 = var(36) = [1,2]
trigger4 = !(var(16) && numtarget)
trigger4 = MoveType = A
	trigger4 = Random <= 450+((var(17)>1)*400)
trigger5 = P2StateType != A
trigger5 = (StateNo = 440 && animelemtime(5) < 0)
trigger5 = var(36) = [1,2]
trigger5 = !(var(16) && numtarget)
	trigger5 = Random <= 900+((var(17)>1)*100)
trigger6 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = P2bodydist X > 60
trigger6 = var(45) || var(23) = 1
trigger6 = !(var(16) && numtarget)
	trigger6 = Random = [50,750]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,10]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = prevstateno != 430
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 350
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [-5,10]
trigger2 = P2MoveType = H 
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [350,700]
trigger3 = P2bodydist X = [0,20]
trigger3 = StateNo = 400 || StateNo = 430
trigger3 = prevstateno != 430
trigger3 = time > 4
trigger3 = var(36) = [1,2]
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [300,800]
trigger4 = P2bodydist X = [-5,10]
trigger4 = P2StateType = S
trigger4 = stateno = 52
trigger4 = ctrl || animtime = 0
trigger4 = !(var(16) && numtarget)
	trigger4 = Random = [300,600]
trigger5 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger5 = P2bodydist X = [-5,10]
trigger5 = P2StateType = S
trigger5 = !(var(16) && numtarget)
	trigger5 = Random = [150,600]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [10,50]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,400]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [20,50]
trigger2 = P2MoveType = H
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [100,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X != [-15,15]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [25,50]
trigger1 = P2bodydist Y = [-40,0]
trigger1 = P2MoveType = I
trigger1 = prevstateno != 200
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [890,900]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X >= 180
trigger2 = P2MoveType != A
trigger2 = !(var(16) && numtarget)
trigger2 = !inguarddist
	trigger2 = Random = [600,610]
trigger3 = P2bodydist X = [25,40]
trigger3 = StateNo = 201 || StateNo = 400 || StateNo = 430
trigger3 = Time > 4
trigger3 = var(36) = [1,2]
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [200,210]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X != [-20,20]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [50,80]
trigger1 = P2bodydist Y = [-40,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [120,135]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X != [-20,20]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [40,70]
trigger1 = P2bodydist Y = [-30,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [120,135]
trigger2 = ctrl
trigger2 = prevstateno = 221
trigger2 = P2MoveType = H
trigger2 = P2StateType != A
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [100,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X != [-20,20]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21
trigger1 = P2bodydist X = [60,80]
trigger1 = P2bodydist Y = [-40,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [120,130]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X != [-20,20]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [30,50]
trigger1 = P2bodydist Y = [-40,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [120,135]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [20,50]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [120,135]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,15]
trigger1 = P2MoveType = I
trigger1 = prevstateno != 221
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [150,950]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [-5,15]
trigger2 = P2MoveType = H
trigger2 = prevstateno != 221
trigger2 = !(var(16) && numtarget)
	trigger2 = Random <= 900
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����r
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2StateType = C
trigger1 = P2bodydist X = [20,50]
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [620,630]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����R
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [20,45]
trigger1 = P2bodydist Y = [-30,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [120,135]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ���������p���`
[State -1, Taunt]
type = ChangeState
value = 201
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X = [-15,15]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,10]
trigger1 = P2bodydist Y = [-60,0]
trigger1 = P2StateType != C
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [750,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = roundstate = 2
triggerall = var(59) = 1
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = StateNo = 830 && Time = [14,24]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = P2BodyDist X = [-5,30]
trigger1 = P2BodyDist Y = [-50,0]
	trigger1 = Random = [600,630]

;---------------------------------------------------------------------------
;�ߋ���������L�b�N
[State -1, Taunt]
type = ChangeState
value = 231
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,15]
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [750,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,25]
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [150,750]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = roundstate = 2
triggerall = var(59) = 1
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = StateNo = 830 && Time = [14,24]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = P2BodyDist X = [-5,70]
trigger1 = P2BodyDist Y = [-30,0]
	trigger1 = Random = [600,610]

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-5,30]
trigger1 = StateNo = 201 || StateNo = 400 || StateNo = 430
trigger1 = prevstateno != 400
trigger1 = Time > 4
trigger1 = var(36) = [1,2]
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [90,500]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [15,40]
trigger1 = P2bodydist Y = [-50,-40]
trigger1 = P2StateType = A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = enemynear,Vel X > 0
trigger1 = !(var(16) && numtarget)
trigger1 = frontedgebodydist > 80
	trigger1 = Random <= 150
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [-5,10]
trigger2 = P2StateType != A
trigger2 = P2MoveType = H
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [700,750]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [50,80]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [780,800]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2StateType = A
trigger2 = P2MoveType != H
trigger2 = P2bodydist X = [60,80]
trigger2 = P2bodydist Y = [-50,-30]
trigger2 = enemynear,Vel X > 0
trigger2 = enemynear,Vel Y > 0
trigger2 = !(var(16) && numtarget)
	trigger2 = Random <= 250
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = Vel X
triggerall = !(var(0)&2**5)
triggerall = Vel Y > 1
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = Pos Y < -50
trigger1 = P2bodydist X = [-50,60]
trigger1 = P2bodydist Y = [-10,60]
trigger1 = time > 6
trigger1 = Ctrl
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [251,700]
trigger2 = P2bodydist X = [-50,20]
trigger2 = P2bodydist Y = [-20,60]
trigger2 = stateno = 701 && time >= 5
	trigger2 = Random = [400,650]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = P2stateno != 5201
triggerall = Vel X
triggerall = Vel Y > 0
triggerall = Pos Y < -40
triggerall = !(var(0)&2**5)
trigger1 = P2bodydist X = [-20,50]
trigger1 = P2bodydist Y = [-10,50]
trigger1 = time > 8
trigger1 = Ctrl
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [0,125]
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = Vel Y > 1
trigger1 = Pos Y < -50
trigger1 = P2bodydist X = [-1,70]
trigger1 = P2bodydist Y = [50,70]
trigger1 = P2StateType != A
trigger1 = Ctrl
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [551,800]
trigger2 = Pos Y < -60
trigger2 = P2bodydist X = [-15,40]
trigger2 = P2bodydist Y = [-50,50]
trigger2 = Ctrl
trigger2 = var(45) || var(23) = 1
trigger2 = numtarget
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [100,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-10,60]
trigger1 = P2bodydist Y = [-30,70]
trigger1 = stateno = 701 && time >= 5
	trigger1 = Random = [400,500]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = !(var(0)&2**5)
triggerall = Vel Y > -3
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = Pos Y < -50
trigger1 = P2bodydist X = [0,60]
trigger1 = P2bodydist Y = [-30,30]
trigger1 = time > 8
trigger1 = Ctrl
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [801,999]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���R��
[State -1]
type = ChangeState
value = 700
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = Vel X > 0
triggerall = Vel Y > -1
triggerall = Pos Y < -40
trigger1 = P2bodydist X = [-5,50]
trigger1 = P2bodydist Y = [50,80]
trigger1 = time > 6
trigger1 = Ctrl
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [600,630]
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = S
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
trigger1 = ctrl || stateno = 21
	trigger1 = Random <= 140

;---------------------------------------------------------------------------
;���]��
[State -1, Throw]
type = ChangeState
value = 920
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = stateno = 50
triggerall = P2bodydist X = [-const(size.ground.front),8]
triggerall = P2bodydist Y = [-70,-enemynear,const(size.head.pos.y)-62]
trigger1 = P2StateType = A
trigger1 = P2MoveType != H
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 100

;---------------------------------------------------------------------------
;�K�[�h
[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = !var(16)
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype != A
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,250)*(1+(statetype!=A))
trigger3 = enemynear,HitDefAttr = SCA, NA,SA,HA
trigger3 = prevstateno = 5120 || prevstateno = 5201
	trigger3 = random = [0,950]

[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = !var(16)
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype = A
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,400)*(1+(statetype!=A))

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(59) = 1
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = P2MoveType != A
triggerall = statetype != A
trigger1 = P2BodyDist X = [40,100]
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [290,300]
trigger2 = P2BodyDist X >= 100
trigger2 = Ctrl || (stateno = 21 && anim = 20)
trigger2 = !(var(16) && numtarget)
trigger2 = !inguarddist
trigger2 = !enemynear,numproj
	trigger2 = Random = [180,200]

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = var(59) = 1
triggerall = !var(20) || var(20) = 1 || var(20) = 2
triggerall = P2MoveType != A
triggerall = statetype != A
trigger1 = P2BodyDist X = [70,120]
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [290,300]
trigger2 = P2BodyDist X >= 120
trigger2 = P2StateType = L
trigger2 = Ctrl || (stateno = 21 && anim = 20)
trigger2 = !(var(16) && numtarget)
trigger2 = !inguarddist
trigger2 = !enemynear,numproj
	trigger2 = Random = [300,310]

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 1
triggerall = statetype != A
trigger1 = P2bodydist X <= 80
trigger1 = P2MoveType != A
trigger1 = Ctrl || (stateno = 21 && anim = 21)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [898,900]
trigger2 = P2bodydist X <= 40
trigger2 = P2StateType = L
trigger2 = Ctrl || (stateno = 21 && anim = 21)
trigger2 = !(var(16) && numtarget)
trigger2 = !inguarddist
trigger2 = !enemynear,numproj
	trigger2 = Random = [485,500]

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 1
triggerall = !var(20) || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = PrevStateNo != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 100
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [610,620]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X <= 50
trigger2 = P2MoveType = A
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [430,435]
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = PrevStateNo != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2BodyDist X = [-5,60]
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [585,600]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2BodyDist X = [-5,60]
trigger2 = P2MoveType = A
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [580,600]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = var(59) = 1
triggerall = (var(20) = 3 && !var(14)) || var(20) = 6
triggerall = statetype != A
triggerall = Power < 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = !enemynear,numproj
trigger1 = ctrl || stateno = 21
trigger1 = P2BodyDist X >= 180
trigger1 = !(var(16) && numtarget)
trigger1 = !inguarddist
trigger1 = !enemynear,numproj
	trigger1 = Random <= 60
trigger2 = ctrl || stateno = 21
trigger2 = P2BodyDist X >= 120
trigger2 = P2StateType = L
trigger2 = teammode = single
trigger2 = !(var(16) && numtarget)
	trigger2 = Random <= 150

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2Life > 150
triggerall = !((100*life/const(data.life))<=20 && P2bodydist X <= 160)
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2BodyDist X >= 100
trigger1 = !(var(16) && numtarget)
trigger1 = !inguarddist
trigger1 = !enemynear,numproj
	trigger1 = Random <= 200
trigger2 = P2StateType = L
trigger2 = !(var(16) && numtarget)
	trigger2 = Random <= 300

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195+(random%2)
triggerall = var(59) = 1
triggerall = statetype != A
trigger1 = ctrl
trigger1 = P2BodyDist X >= 200
trigger1 = !(var(16) && numtarget)
trigger1 = !inguarddist
trigger1 = !enemynear,numproj
	trigger1 = Random = [440,443]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�o���V�@��
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�o���V�@��1" || Command = "�o���V�@��2" || Command = "�o���V�@��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2)
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (var(16) || time <= 2)
trigger21 = StateNo = 305 && var(16)
trigger22 = StateNo = 310 && (var(16) || time <= 2)
trigger23 = (stateno = [195,196]) && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (stateno = [195,196]) && (var(20) = 2 || var(20) = 6)
trigger28 = (StateNo = [1000,1399]) && (var(20) = 2 || var(20) = 6)
trigger29 = (StateNo = [1500,2999]) && (var(20) = 2 || var(20) = 6)
trigger30 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger31 = StateNo = 3110 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�V�ė��P
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�V�ė��P1" || Command = "�V�ė��P2" || Command = "�V�ė��P3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2)
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (var(16) || time <= 2)
trigger21 = StateNo = 305 && var(16)
trigger22 = StateNo = 310 && (var(16) || time <= 2)
trigger23 = (stateno = [195,196]) && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (stateno = [195,196]) && (var(20) = 2 || var(20) = 6)
trigger28 = (StateNo = [1000,1399]) && (var(20) = 2 || var(20) = 6)
trigger29 = (StateNo = [1500,2999]) && (var(20) = 2 || var(20) = 6)
trigger30 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger31 = (StateNo = [3001,3099]) && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�]�g��
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�]�g��1" || Command = "�]�g��2" || Command = "�]�g��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2)
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (var(16) || time <= 2)
trigger21 = StateNo = 305 && var(16)
trigger22 = StateNo = 310 && (var(16) || time <= 2)
trigger23 = (stateno = [195,196]) && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3199]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���C��
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005)
triggerall = Command = "���C��1" || Command = "���C��2" || Command = "���C��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2)
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (var(16) || time <= 2)
trigger21 = StateNo = 305 && var(16)
trigger22 = StateNo = 310 && (var(16) || time <= 2)
trigger23 = (stateno = [195,196]) && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3199]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�A���R
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = Command = "�A���R1" || Command = "�A���R2" || Command = "�A���R3"
triggerall = statetype = A
triggerall = Pos Y <= -30
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2|| ((var(36) = 1||var(36) = 2) && animelemtime(7) < 0))
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger8 = StateNo = 300 && (var(36) = 1||var(36) = 2) && var(16)
trigger9 = StateNo = 700 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger10 = stateno = 701
trigger11 = (stateno = [195,196]) && var(36) && var(16)
trigger12 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger13 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger14 = (StateNo = [3000,3199]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�o���i
[State -1, hadouken]
type = ChangeState
value = 1300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�o���i1" || Command = "�o���i2" || Command = "�o���i3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2)
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (var(16) || time <= 2)
trigger21 = StateNo = 305 && var(16)
trigger22 = StateNo = 310 && (var(16) || time <= 2)
trigger23 = (stateno = [195,196]) && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3199]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�Ք��r
[State -1, hadouken]
type = ChangeState
value = 1500
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�Ք��r1" || Command = "�Ք��r2" || Command = "�Ք��r3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2)
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (var(16) || time <= 2)
trigger21 = StateNo = 305 && var(16)
trigger22 = StateNo = 310 && (var(16) || time <= 2)
trigger23 = (stateno = [195,196]) && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3199]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�Ώ��
[State -1, hadouken]
type = ChangeState
value = 1400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�Ώ��1" || Command = "�Ώ��2" || Command = "�Ώ��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2)
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (var(16) || time <= 2)
trigger21 = StateNo = 305 && var(16)
trigger22 = StateNo = 310 && (var(16) || time <= 2)
trigger23 = (stateno = [195,196]) && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3199]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����2
[State -1, Taunt]
type = ChangeState
value = 196
triggerall = !var(59)
triggerall = command = "start"
triggerall = command != "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2)
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (var(16) || time <= 2)
trigger21 = StateNo = 305 && var(16)
trigger22 = StateNo = 310 && (var(16) || time <= 2)
trigger23 = (stateno = [195,196]) && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3199]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2)
trigger9 = StateNo = 231 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 240 && (var(16) || time <= 2)
trigger11 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 250 && (var(16) || time <= 2)
trigger13 = StateNo = 251 && (var(16) || time <= 2)
trigger14 = StateNo = 400
trigger15 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger17 = StateNo = 430
trigger18 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 450 && (var(16) || time <= 2)
trigger20 = StateNo = 300 && (var(16) || time <= 2)
trigger21 = StateNo = 305 && var(16)
trigger22 = StateNo = 310 && (var(16) || time <= 2)
trigger23 = (stateno = [195,196]) && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3199]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5200
triggerall = !var(59)
triggerall = !(var(0)&2**10)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2
trigger21 = StateNo = 310 && time <= 2
trigger22 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger23 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger24 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2
trigger21 = StateNo = 310 && time <= 2
trigger22 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger23 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger24 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2
trigger21 = StateNo = 310 && time <= 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2
trigger21 = StateNo = 310 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 231 && time <= 2
trigger10 = StateNo = 240 && time <= 2
trigger11 = StateNo = 241 && time <= 2
trigger12 = StateNo = 250 && time <= 2
trigger13 = StateNo = 251 && time <= 2
trigger14 = StateNo = 400 && time <= 2
trigger15 = StateNo = 410 && time <= 2
trigger16 = StateNo = 420 && time <= 2
trigger17 = StateNo = 430 && time <= 2
trigger18 = StateNo = 440 && time <= 2
trigger19 = StateNo = 450 && time <= 2
trigger20 = StateNo = 300 && time <= 2
trigger21 = StateNo = 310 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time <= 2
trigger3 = StateNo = 610 && time <= 2
trigger4 = StateNo = 620 && time <= 2
trigger5 = StateNo = 630 && time <= 2
trigger6 = StateNo = 640 && time <= 2
trigger7 = StateNo = 650 && time <= 2
trigger8 = StateNo = 700 && time <= 2

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;���]��
[State -1, Throw]
type = ChangeState
value = 920
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback" || command = "holddown") && command = "z"
triggerall = statetype = A
triggerall = ctrl
triggerall = P2bodydist X = [-const(size.ground.front),8]
triggerall = P2bodydist Y = [-70,-enemynear,const(size.head.pos.y)-62]
trigger1 = p2statetype = A
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;�����r
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����R
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���R��
[State -1]
type = ChangeState
value = 700
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "holddown"
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ���������p���`
[State -1, Taunt]
type = ChangeState
value = 201
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-15,15]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 201 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = StateNo = 430 && Time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger7 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 201 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = StateNo = 430 && Time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger7 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ���������L�b�N
[State -1, Taunt]
type = ChangeState
value = 231
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 201 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = StateNo = 430 && Time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger7 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 201 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = StateNo = 430 && Time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger7 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 251
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 201 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = StateNo = 430 && Time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger7 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 201 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = StateNo = 430 && Time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger7 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger4 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 701
ignorehitpause = 0

;---------------------------------------------------------------------------
