;===================================================================== 
;  CMD File For "Genryusai Maki"	                    Made By H"
;=====================================================================

;=====================================================================
; Definition of the Commands
;=====================================================================
;
;-| Button Remapping |-----------------------------------------------------
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s

;-| Default Values |-------------------------------------------------------
[Defaults]
command.time = 15

command.buffer.time = 1

;-| Super Motions |---------------------------------------------------
[Command]
name = "Ajaratengu_Lv.1"
command = F,D,B,U,F,D,B, x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = D,B,U,F,D,B,U, x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = B,U,F,D,B,U,F, x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = U,B,D,F,U,B,D, x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = F,U,B,D,F,U,B, x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = D,F,U,B,D,F,U, x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = B,D,F,U,B,D,F, x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = U,F,D,B,U,F,D, x
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = F,D,B,U,F,D,B, y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = D,B,U,F,D,B,U, y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = B,U,F,D,B,U,F, y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = U,B,D,F,U,B,D, y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = F,U,B,D,F,U,B, y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = D,F,U,B,D,F,U, y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = B,D,F,U,B,D,F, y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = U,F,D,B,U,F,D, y
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = F,D,B,U,F,D,B, z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = D,B,U,F,D,B,U, z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = B,U,F,D,B,U,F, z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = U,B,D,F,U,B,D, z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = F,U,B,D,F,U,B, z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = D,F,U,B,D,F,U, z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = B,D,F,U,B,D,F, z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = U,F,D,B,U,F,D, z
time = 40

[Command]
name = "Ajaratengu"
command = F,D,B,U,F,D,B, x
time = 40

[Command]
name = "Ajaratengu"
command = D,B,U,F,D,B,U, x
time = 40

[Command]
name = "Ajaratengu"
command = B,U,F,D,B,U,F, x
time = 40

[Command]
name = "Ajaratengu"
command = U,B,D,F,U,B,D, x
time = 40

[Command]
name = "Ajaratengu"
command = F,U,B,D,F,U,B, x
time = 40

[Command]
name = "Ajaratengu"
command = D,F,U,B,D,F,U, x
time = 40

[Command]
name = "Ajaratengu"
command = B,D,F,U,B,D,F, x
time = 40

[Command]
name = "Ajaratengu"
command = U,F,D,B,U,F,D, x
time = 40

[Command]
name = "Ajaratengu"
command = F,D,B,U,F,D,B, y
time = 40

[Command]
name = "Ajaratengu"
command = D,B,U,F,D,B,U, y
time = 40

[Command]
name = "Ajaratengu"
command = B,U,F,D,B,U,F, y
time = 40

[Command]
name = "Ajaratengu"
command = U,B,D,F,U,B,D, y
time = 40

[Command]
name = "Ajaratengu"
command = F,U,B,D,F,U,B, y
time = 40

[Command]
name = "Ajaratengu"
command = D,F,U,B,D,F,U, y
time = 40

[Command]
name = "Ajaratengu"
command = B,D,F,U,B,D,F, y
time = 40

[Command]
name = "Ajaratengu"
command = U,F,D,B,U,F,D, y
time = 40

[Command]
name = "Ajaratengu"
command = F,D,B,U,F,D,B, z
time = 40

[Command]
name = "Ajaratengu"
command = D,B,U,F,D,B,U, z
time = 40

[Command]
name = "Ajaratengu"
command = B,U,F,D,B,U,F, z
time = 40

[Command]
name = "Ajaratengu"
command = U,B,D,F,U,B,D, z
time = 40

[Command]
name = "Ajaratengu"
command = F,U,B,D,F,U,B, z
time = 40

[Command]
name = "Ajaratengu"
command = D,F,U,B,D,F,U, z
time = 40

[Command]
name = "Ajaratengu"
command = B,D,F,U,B,D,F, z
time = 40

[Command]
name = "Ajaratengu"
command = U,F,D,B,U,F,D, z
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = F,D,B,U,F,D,B, ~x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = D,B,U,F,D,B,U, ~x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = B,U,F,D,B,U,F, ~x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = U,B,D,F,U,B,D, ~x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = F,U,B,D,F,U,B, ~x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = D,F,U,B,D,F,U, ~x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = B,D,F,U,B,D,F, ~x
time = 40

[Command]
name = "Ajaratengu_Lv.1"
command = U,F,D,B,U,F,D, ~x
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = F,D,B,U,F,D,B, ~y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = D,B,U,F,D,B,U, ~y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = B,U,F,D,B,U,F, ~y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = U,B,D,F,U,B,D, ~y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = F,U,B,D,F,U,B, ~y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = D,F,U,B,D,F,U, ~y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = B,D,F,U,B,D,F, ~y
time = 40

[Command]
name = "Ajaratengu_Lv.2"
command = U,F,D,B,U,F,D, ~y
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = F,D,B,U,F,D,B, ~z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = D,B,U,F,D,B,U, ~z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = B,U,F,D,B,U,F, ~z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = U,B,D,F,U,B,D, ~z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = F,U,B,D,F,U,B, ~z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = D,F,U,B,D,F,U, ~z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = B,D,F,U,B,D,F, ~z
time = 40

[Command]
name = "Ajaratengu_Lv.3"
command = U,F,D,B,U,F,D, ~z
time = 40

[Command]
name = "Ajaratengu"
command = F,D,B,U,F,D,B, ~x
time = 40

[Command]
name = "Ajaratengu"
command = D,B,U,F,D,B,U, ~x
time = 40

[Command]
name = "Ajaratengu"
command = B,U,F,D,B,U,F, ~x
time = 40

[Command]
name = "Ajaratengu"
command = U,B,D,F,U,B,D, ~x
time = 40

[Command]
name = "Ajaratengu"
command = F,U,B,D,F,U,B, ~x
time = 40

[Command]
name = "Ajaratengu"
command = D,F,U,B,D,F,U, ~x
time = 40

[Command]
name = "Ajaratengu"
command = B,D,F,U,B,D,F, ~x
time = 40

[Command]
name = "Ajaratengu"
command = U,F,D,B,U,F,D, ~x
time = 40

[Command]
name = "Ajaratengu"
command = F,D,B,U,F,D,B, ~y
time = 40

[Command]
name = "Ajaratengu"
command = D,B,U,F,D,B,U, ~y
time = 40

[Command]
name = "Ajaratengu"
command = B,U,F,D,B,U,F, ~y
time = 40

[Command]
name = "Ajaratengu"
command = U,B,D,F,U,B,D, ~y
time = 40

[Command]
name = "Ajaratengu"
command = F,U,B,D,F,U,B, ~y
time = 40

[Command]
name = "Ajaratengu"
command = D,F,U,B,D,F,U, ~y
time = 40

[Command]
name = "Ajaratengu"
command = B,D,F,U,B,D,F, ~y
time = 40

[Command]
name = "Ajaratengu"
command = U,F,D,B,U,F,D, ~y
time = 40

[Command]
name = "Ajaratengu"
command = F,D,B,U,F,D,B, ~z
time = 40

[Command]
name = "Ajaratengu"
command = D,B,U,F,D,B,U, ~z
time = 40

[Command]
name = "Ajaratengu"
command = B,U,F,D,B,U,F, ~z
time = 40

[Command]
name = "Ajaratengu"
command = U,B,D,F,U,B,D, ~z
time = 40

[Command]
name = "Ajaratengu"
command = F,U,B,D,F,U,B, ~z
time = 40

[Command]
name = "Ajaratengu"
command = D,F,U,B,D,F,U, ~z
time = 40

[Command]
name = "Ajaratengu"
command = B,D,F,U,B,D,F, ~z
time = 40

[Command]
name = "Ajaratengu"
command = U,F,D,B,U,F,D, ~z
time = 40

[Command]
name = "Bushin Gouraiha_Lv.1"
command = ~D, DF, F, D, DF, x
time = 25

[Command]
name = "Bushin Gouraiha_Lv.2"
command = ~D, DF, F, D, DF, y
time = 25

[Command]
name = "Bushin Gouraiha_Lv.3"
command = ~D, DF, F, D, DF, z
time = 25
[Command]
name = "Bushin Gouraiha"
command = ~D, DF, F, D, DF, x
time = 25

[Command]
name = "Bushin Gouraiha"
command = ~D, DF, F, D, DF, y
time = 25

[Command]
name = "Bushin Gouraiha"
command = ~D, DF, F, D, DF, z
time = 25

[Command]
name = "Bushin Gouraiha_Lv.1"
command = ~D, DF, F, D, DF, ~x
time = 25

[Command]
name = "Bushin Gouraiha_Lv.2"
command = ~D, DF, F, D, DF, ~y
time = 25

[Command]
name = "Bushin Gouraiha_Lv.3"
command = ~D, DF, F, D, DF, ~z
time = 25
[Command]
name = "Bushin Gouraiha"
command = ~D, DF, F, D, DF, ~x
time = 25

[Command]
name = "Bushin Gouraiha"
command = ~D, DF, F, D, DF, ~y
time = 25

[Command]
name = "Bushin Gouraiha"
command = ~D, DF, F, D, DF, ~z
time = 25

[Command]
name = "Tesshinhou_Lv.1"
command = ~D, DF, F, D, DF, a
time = 25

[Command]
name = "Tesshinhou_Lv.2"
command = ~D, DF, F, D, DF, b
time = 25

[Command]
name = "Tesshinhou_Lv.3"
command = ~D, DF, F, D, DF, c
time = 25

[Command]
name = "Tesshinhou"
command = ~D, DF, F, D, DF, a
time = 25

[Command]
name = "Tesshinhou"
command = ~D, DF, F, D, DF, b
time = 25

[Command]
name = "Tesshinhou"
command = ~D, DF, F, D, DF, c
time = 25

[Command]
name = "Tesshinhou_Lv.1"
command = ~D, DF, F, D, DF, ~a
time = 25

[Command]
name = "Tesshinhou_Lv.2"
command = ~D, DF, F, D, DF, ~b
time = 25

[Command]
name = "Tesshinhou_Lv.3"
command = ~D, DF, F, D, DF, ~c
time = 25

[Command]
name = "Tesshinhou"
command = ~D, DF, F, D, DF, ~a
time = 25

[Command]
name = "Tesshinhou"
command = ~D, DF, F, D, DF, ~b
time = 25

[Command]
name = "Tesshinhou"
command = ~D, DF, F, D, DF, ~c
time = 25

;-| Special Motions |-------------------------------------------------
[Command]
name = "Tengu Daoshi_x"
command = ~B, DB, D, DF, x
time = 20

[Command]
name = "Tengu Daoshi_y"
command = ~B, DB, D, DF, y
time = 20

[Command]
name = "Tengu Daoshi_z"
command = ~B, DB, D, DF, z
time = 20

[Command]
name = "Tengu Daoshi_x"
command = ~B, DB, D, DF, ~x
time = 20

[Command]
name = "Tengu Daoshi_y"
command = ~B, DB, D, DF, ~y
time = 20

[Command]
name = "Tengu Daoshi_z"
command = ~B, DB, D, DF, ~z
time = 20

[Command]
name = "Genko_x"
command = ~D, DF, F, x

[Command]
name = "Genko_y"
command = ~D, DF, F, y

[Command]
name = "Genko_z"
command = ~D, DF, F, z

[Command]
name = "Genko_x"
command = ~D, DF, F, ~x

[Command]
name = "Genko_y"
command = ~D, DF, F, ~y

[Command]
name = "Genko_z"
command = ~D, DF, F, ~z

[Command]
name = "Hayagake"
command = ~D, DF, F, a

[Command]
name = "Hayagake"
command = ~D, DF, F, b

[Command]
name = "Hayagake"
command = ~D, DF, F, c

[Command]
name = "Hayagake"
command = ~D, DF, F, ~a

[Command]
name = "Hayagake"
command = ~D, DF, F, ~b

[Command]
name = "Hayagake"
command = ~D, DF, F, ~c

[Command]
name = "Hassoukyaku_x"
command = ~D, DB, B, x

[Command]
name = "Hassoukyaku_y"
command = ~D, DB, B, y

[Command]
name = "Hassoukyaku_z"
command = ~D, DB, B, z

[Command]
name = "Hassoukyaku_a"
command = ~D, DB, B, a

[Command]
name = "Hassoukyaku_b"
command = ~D, DB, B, b

[Command]
name = "Hassoukyaku_c"
command = ~D, DB, B, c

[Command]
name = "Hassoukyaku_x"
command = ~D, DB, B, ~x

[Command]
name = "Hassoukyaku_y"
command = ~D, DB, B, ~y

[Command]
name = "Hassoukyaku_z"
command = ~D, DB, B, ~z

[Command]
name = "Hassoukyaku_a"
command = ~D, DB, B, ~a

[Command]
name = "Hassoukyaku_b"
command = ~D, DB, B, ~b

[Command]
name = "Hassoukyaku_c"
command = ~D, DB, B, ~c

[Command]
name = "Reppukyaku"
command = a+b
time = 1

[Command]
name = "Reppukyaku"
command = b+c
time = 1

[Command]
name = "Reppukyaku"
command = a+c
time = 1

;-| Double Tap |------------------------------------------------------
[Command]
name = "FF";Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB";Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |------------------------------------------
[Command]
name = "recovery_ground"
command = x+y+z
time = 1

[Command]
name = "Pow-MAX"
command = z+c
time = 1

[Command]
name = "recovery";Required (do not remove)
command = a+x
time = 1

;-| Dir + Button |----------------------------------------------------
[Command]
name = "GC_Attack"
command = /F,y+b
time = 1

[Command]
name = "GC_fwd"
command = /F,x+a
time = 1

[Command]
name = "GC_back"
command = /B,x+a
time = 1

[Command]
name = "fwd_c"
command = /F,c
time = 1

[Command]
name = "fwd_z"
command = /F,z
time = 1

[Command]
name = "back_c"
command = /B,c
time = 1

[Command]
name = "back_z"
command = /B,z
time = 1

[Command]
name = "down_y"
command = /D,y
time = 1

[Command]
name = "down_z"
command = /D,z
time = 1

[Command]
name = "charge1"
command = /c
time = 1

[Command]
name = "charge2"
command = /z
time = 1

;-| Single Button |---------------------------------------------------
[Command]
name = "x"
command = x
time = 1

[Command]
name = "a"
command = a
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

[Command]
name = "EX"
command = s
time = 1

;----------------------------- ����
[Command]
name = "fwd"
command = F
time = 1

[Command]
name = "downfwd"
command = DF
time = 1

[Command]
name = "down"
command = D
time = 1

[Command]
name = "downback"
command = DB
time = 1

[Command]
name = "back"
command = B
time = 1

[Command]
name = "upback"
command = UB
time = 1

[Command]
name = "up"
command = U
time = 1

[Command]
name = "upfwd"
command = UF
time = 1

[Command]
name = "Not-Neutral"
command = $U
time = 1

[Command]
name = "Not-Neutral"
command = $F
time = 1

[Command]
name = "Not-Neutral"
command = $D
time = 1

[Command]
name = "Not-Neutral"
command = $B
time = 1

;----------------------------- ���o�K�`��
[Command]
name = "random"
command = x
time = 1

[Command]
name = "random"
command = y
time = 1

[Command]
name = "random"
command = z
time = 1

[Command]
name = "random"
command = a
time = 1

[Command]
name = "random"
command = b
time = 1

[Command]
name = "random"
command = c
time = 1

[Command]
name = "random"
command = F
time = 1

[Command]
name = "random"
command = DF
time = 1

[Command]
name = "random"
command = D
time = 1

[Command]
name = "random"
command = DB
time = 1

[Command]
name = "random"
command = B
time = 1

[Command]
name = "random"
command = UB
time = 1

[Command]
name = "random"
command = U
time = 1

[Command]
name = "random"
command = UF
time = 1

;-| Hold Button |-----------------------------------------------------
[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_s"
command = /s
time = 1

;-| Hold Dir |--------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup";Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holdupfwd"
command = /UF
time = 1

[Command]
name = "holdupback"
command = /UB
time = 1

;=====================================================================
; State Entry for Commands
;=====================================================================

[Statedef -1]
;=====================================================================
; �L�����Z���ݒ�
;=====================================================================
;------------------------
[State -1,�L�����Z���ݒ胊�Z�b�g]
type       = varset
trigger1   = var(22)
var(22)    = 0

;------------------------
[State -1,Lv.2�X�p�R���L�����Z��]
type       = varset
triggerall = RoundState = 2
triggerall = !var(22)
triggerall = Var(30) = 1 && var(36) = 1
triggerall = MoveHit
trigger1   = StateNo = 3110
trigger2   = StateNo = 3015 || PrevStateNo = 3015 && StateNo = 3006
var(22)    = -1
ignorehitpause = 1

;------------------------
[State -1,�X�p�R���L�����Z���iEX�O���[���j]
type       = varset
triggerall = RoundState = 2
triggerall = !var(22)
triggerall = MoveHit
TriggerAll = var(43)&&floor(var(50)/100000%10)=1 || var(30)=3&&floor(var(52)/100%10)=1 || var(30)=4 && floor(var(52)/10%10)=1 && fvar(8)=-1
trigger1   = StateNo = 1131 && AnimElem = 1,> 0 && StateType != A || StateNo = 1132
trigger2   = !var(15) && (StateNo = 1161 && AnimElem = 2,> 0 && StateType != A  || StateNo = 1162)
trigger3   = (StateNo = 1000 || StateNo = 1010 || StateNo = 1020 || StateNo = 1300 || StateNo = 1301 || StateNo = 1450 || StateNo = 4505)
var(22)    = -2
ignorehitpause = 1

;------------------------
[State -1,��U��L�����Z��]
type       = varset
triggerall = RoundState = 2
triggerall = !var(22)
triggerall = !movecontact
triggerall = time < 4 || var(47)
trigger1   = (StateNo = [200,799])
var(22)    = 1
ignorehitpause = 1

;------------------------
[State -1,�K�E�Z�L�����Z��]
type       = varset
triggerall = RoundState = 2
triggerall = !var(22)
triggerall = MoveContact
trigger1   = StateNo = 200 && AnimElem = 2,> 0 || StateNo = 215 || StateNo = 225 || StateNo = 245
trigger2   = StateNo = 400 || StateNo = 410 || StateNo = 430
trigger3   = StateNo = 600 || StateNo = 610 || StateNo = 630
trigger4   = StateNo = 4000 && Time < 3
trigger5   = StateNo = 52
trigger6   = (StateNo = [200,699]) && var(43)&&floor(var(50)/1000000%10)=1
var(22)    = 2
ignorehitpause = 1

;------------------------
[State -1,SC�E���K�L�����Z��]
type       = varset
triggerall = RoundState = 2
triggerall = !var(22)
triggerall = MoveContact
trigger1   = StateNo = 210 || StateNo = 220 || StateNo = 230 || StateNo = 240 || StateNo = 250 && AnimElem = 6,>0 || StateNo = 255
trigger2   = StateNo = 420 || StateNo = 440 || StateNo = 450
trigger3   = StateNo = 620 || StateNo = 640 || StateNo = 650
var(22)    = 3
ignorehitpause = 1

;------------------------
[State -1,�I���W�i���R���{�i�K�E�Z�j]
type       = varset
triggerall = RoundState = 2
triggerall = !var(22)
triggerall = var(47)
trigger1   = StateNo = 721 && AnimElem = 6,> 0
trigger2   = StateNo = 1131 && AnimElem = 1,> 0 && StateType != A || StateNo = 1132
trigger3   = !var(15) && (StateNo = 1161 && AnimElem = 2,> 0 && StateType != A  || StateNo = 1162)
trigger4   = MoveContact && (StateNo = 1000 || StateNo = 1010 || StateNo = 1020 || StateNo = 1300 || StateNo = 1301 || StateNo = 1450)
var(22)    = 4
ignorehitpause = 1

;------------------------
[State -1,�I���W�i���R���{(�ʏ�j]
type       = varset
triggerall = RoundState = 2
triggerall = !var(22)
triggerall = var(47)
trigger1   = StateNo = [200,719]
var(22)    = 5
ignorehitpause = 1

;=====================================================================
; �X�[�p�[�R���{or���K�E�Z��������
;=====================================================================
[State -1,Lv.3��������OFF]
type       = VarAdd
triggerall = RoundState = 2
triggerall = floor(var(40)/100%10) = 1
trigger1   = var(30)=1 && Power < 3000
trigger2   = var(30)=3 && Power < 3000
trigger3   = var(30)=4 && (Fvar(8) ^^ (100*life/const(data.life))<=30)
trigger4   = var(30)=5 && (Power >= 1000 ^^ Fvar(8))
trigger5   = var(30)=6 && !Fvar(8)
var(40)    = -100
ignorehitpause = 1

[State -1,Lv.3��������ON]
type       = VarAdd
triggerall = RoundState = 2
triggerall = floor(var(40)/100%10) = 0
trigger1   = var(30)=1 && Power >= 3000
trigger2   = var(30)=3 && Power >= 3000
trigger3   = var(30)=4 && (Fvar(8) && (100*life/const(data.life))<=30)
trigger4   = var(30)=5 && Power >= 1000 && Fvar(8)
trigger5   = var(30)=6 && Fvar(8)
var(40)    = 100
ignorehitpause = 1

[State -1,Lv.2��������OFF]
type       = VarAdd
triggerall = RoundState = 2
triggerall = floor(var(40)/10%10) = 1
trigger1   = var(30)=1 && Power < 2000
var(40)    = -10
ignorehitpause = 1

[State -1,Lv.2��������ON]
type       = VarAdd
triggerall = RoundState = 2
triggerall = floor(var(40)/10%10) = 0
trigger1   = var(30)=1 && Power >= 2000
var(40)    = 10
ignorehitpause = 1

[State -1,Lv.1��������OFF]
type       = VarAdd
triggerall = RoundState = 2
triggerall = floor(var(40)%10) = 1
trigger1   = var(30)=1 && Power < 1000
trigger2   = var(30)=2 && !Fvar(8) && Power < 1500
trigger3   = var(30)=4 && (!Fvar(8) && (100*life/const(data.life))>30 || Fvar(8) && (100*life/const(data.life))<=30)
trigger4   = var(30)=5 && (!Fvar(8) && Power < 1000 || Fvar(8) && Power >= 1000)
var(40)    = -1
ignorehitpause = 1

[State -1,Lv.1��������ON]
type       = VarAdd
triggerall = RoundState = 2
triggerall = floor(var(40)%10) = 0
trigger1   = var(30)=1 && Power >= 1000
trigger2   = var(30)=2 && (Fvar(8) || Power >= 1500)
trigger3   = var(30)=4 && (Fvar(8) ^^ (100*life/const(data.life))<=30)
trigger4   = var(30)=5 && (Fvar(8) ^^ Power >= 1000)
var(40)    = 1
ignorehitpause = 1


;=====================================================================
; ���o�[�T��
;=====================================================================

;---------------------------------------------------------------------
[State -1,�Y�V��]
type     = varset
trigger1 = !var(0) && Command="Ajaratengu"
var(0)   = IfElse((Command="Ajaratengu_Lv.3"),1300,IfElse((Command="Ajaratengu_Lv.2"),1200,1100))

[State -1,�S�S��]
type     = varset
trigger1 = !var(0) && Command="Tesshinhou"
var(0)   = IfElse((Command="Tesshinhou_Lv.3"),2300,IfElse((Command="Tesshinhou_Lv.2"),2200,2100))

[State -1,���_�����j]
type     = varset
trigger1 = !var(0) && Command="Bushin Gouraiha"
var(0)   = IfElse((Command="Bushin Gouraiha_Lv.3"),3300,IfElse((Command="Bushin Gouraiha_Lv.2"),3200,3100))

[State -1,���R]
type     = varset
trigger1 = !var(0) && (Command="Genko_x" || Command="Genko_y" || Command="Genko_z")
var(0)   = IfElse((Command="Genko_z"),13,IfElse((Command="Genko_y"),12,11))

[State -1,���삯]
type     = varset
trigger1 = !var(0) && Command="Hayagake"
var(0)   = 20

[State -1,�t���삯]
type     = varset
trigger1 = !var(0) && (Command="Hassoukyaku_a" || Command="Hassoukyaku_b" || Command="Hassoukyaku_c")
var(0)   = 30

;---------------------------------------------------------------------
[State -1]
type     = varset
trigger1 = var(0) && !var(1)
var(1)   = 10

[State -1]
type     = varadd
trigger1 = var(1) > 0
var(1)   = -1

[State -1]
type     = varset
trigger1 = var(0) && !var(1)
var(0)   = 0

;=====================================================================
; Super Arts
;=====================================================================

;---------------------------------------------------------------------
[State -1,�󒆋Y�V��iLV.3�j]
type       = ChangeState
value      = 3320
triggerall = StateType = A && floor(var(40)/100%10)=1 && Pos Y < -35 && var(32)!= 2
trigger1   = (Ctrl || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || var(22) = [-2,-1])
trigger1   = (var(30)=[0,1]) && Command = "Ajaratengu_Lv.3" || (var(30)=[2,6]) && Command = "Ajaratengu"

;---------------------------------------------------------------------
[State -1,�󒆋Y�V��iLV.2�j]
type       = ChangeState
value      = 3310
triggerall = StateType = A && floor(var(40)/10%10)=1 && Pos Y < -35 && var(32)!= 2
trigger1   = (Ctrl || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || var(22) = [-2,-1])
trigger1   = Command = "Ajaratengu_Lv.3" && floor(var(40)/100%10)=0 || Command = "Ajaratengu_Lv.2"

;---------------------------------------------------------------------
[State -1,�󒆋Y�V��iLV.1�j]
type       = ChangeState
value      = 3300
triggerall = StateType = A && floor(var(40)%10)=1 && Pos Y < -35 && var(32)!= 2
trigger1   = (Ctrl || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || var(22) = [-2,-1])
trigger1   = Command = "Ajaratengu_Lv.3" && floor(var(40)/100%10)=0 || Command = "Ajaratengu_Lv.2" && floor(var(40)/10%10)=0 || Command = "Ajaratengu_Lv.1"

;---------------------------------------------------------------------
[State -1,�Y�V��iLV.3�j]
type       = ChangeState
value      = 3220
triggerall = StateType != A && floor(var(40)/100%10)=1
trigger1   = Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101 || StateNo=40 || StateNo=52 && Time>=2 || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || (var(22) = [-2,-1])
trigger1   = (var(30)=[0,1]) && Command = "Ajaratengu_Lv.3" || (var(30)=[2,6]) && Command = "Ajaratengu"
trigger2   = (stateno=5001 || stateno=5011 || stateno=151 || stateno=153 || stateno=140) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = (var(30)=[0,1]) && Var(0)=1300 || (var(30)=[2,6]) && Var(0)=[1100,1300]

;---------------------------------------------------------------------
[State -1,�Y�V��iLV.2�j]
type       = ChangeState
value      = 3210
triggerall = StateType != A && floor(var(40)/10%10)=1
trigger1   = Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101 || StateNo=40 || StateNo=52 && Time>=2 || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || (var(22) = [-2,-1])
trigger1   = Command = "Ajaratengu_Lv.3" && floor(var(40)/100%10)=0 || Command = "Ajaratengu_Lv.2"
trigger2   = (stateno=5001 || stateno=5011 || stateno=151 || stateno=153 || stateno=140) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = Var(0)=1300 && floor(var(40)/100%10)=0 || Var(0)=1200

;---------------------------------------------------------------------
[State -1,�Y�V��iLV.1�j]
type       = ChangeState
value      = 3200
triggerall = StateType != A && floor(var(40)%10)=1
trigger1   = Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101 || StateNo=40 || StateNo=52 && Time>=2 || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || (var(22) = [-2,-1])
trigger1   = Command = "Ajaratengu_Lv.3" && floor(var(40)/100%10)=0 || Command = "Ajaratengu_Lv.2" && floor(var(40)/10%10)=0 || Command = "Ajaratengu_Lv.1"
trigger2   = (stateno=5001 || stateno=5011 || stateno=151 || stateno=153 || stateno=140) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = Var(0)=1300 && floor(var(40)/100%10)=0 || Var(0)=1200 && floor(var(40)/10%10)=0 || Var(0)=1100

;---------------------------------------------------------------------
[State -1,�S�S���iLV.3�j]
type       = ChangeState
value      = 3020
triggerall = StateType != A && floor(var(40)/100%10)=1
trigger1   = Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || (var(22) = [-2,-1])
trigger1   = (var(30)=[0,1]) && Command = "Tesshinhou_Lv.3" || (var(30)=[2,6]) && Command = "Tesshinhou"
trigger2   = (stateno=5001 || stateno=5011 || stateno=151 || stateno=153 || stateno=140) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = (var(30)=[0,1]) && Var(0)=2300 || (var(30)=[2,6]) && Var(0)=[2100,2300]

;---------------------------------------------------------------------
[State -1,�S�S���iLV.2�j]
type       = ChangeState
value      = 3010
triggerall = StateType != A && floor(var(40)/10%10)=1
trigger1   = Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || (var(22) = [-2,-1])
trigger1   = Command = "Tesshinhou_Lv.3" && floor(var(40)/100%10)=0 || Command = "Tesshinhou_Lv.2"
trigger2   = (stateno=5001 || stateno=5011 || stateno=151 || stateno=153 || stateno=140) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = Var(0)=2300 && floor(var(40)/100%10)=0 || Var(0)=2200

;---------------------------------------------------------------------
[State -1,�S�S���iLV.1�j]
type       = ChangeState
value      = 3000
triggerall = StateType != A && floor(var(40)%10)=1
trigger1   = Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || (var(22) = [-2,-1])
trigger1   = Command = "Tesshinhou_Lv.3" && floor(var(40)/100%10)=0 || Command = "Tesshinhou_Lv.2" && floor(var(40)/10%10)=0 || Command = "Tesshinhou_Lv.1"
trigger2   = (stateno=5001 || stateno=5011 || stateno=151 || stateno=153 || stateno=140) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = Var(0)=2300 && floor(var(40)/100%10)=0 || Var(0)=2200 && floor(var(40)/10%10)=0 || Var(0)=2100

;---------------------------------------------------------------------
[State -1,���_�����j�iLV.3�j]
type       = ChangeState
value      =  3120
triggerall = StateType != A && floor(var(40)/100%10)=1
trigger1   = Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || (var(22) = [-2,-1])
trigger1   = (var(30)=[0,1]) && Command = "Bushin Gouraiha_Lv.3" || (var(30)=[2,6]) && Command = "Bushin Gouraiha"
trigger2   = (stateno=5001 || stateno=5011 || stateno=151 || stateno=153 || stateno=140) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = (var(30)=[0,1]) && Var(0)=2300 || (var(30)=[2,6]) && Var(0)=[2100,2300]

;---------------------------------------------------------------------
[State -1,���_�����j�iLV.2�j]
type       = ChangeState
value      =  3110
triggerall = StateType != A && floor(var(40)/10%10)=1
trigger1   = Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || (var(22) = [-2,-1])
trigger1   = Command = "Bushin Gouraiha_Lv.3" && floor(var(40)/100%10)=0 || Command = "Bushin Gouraiha_Lv.2"
trigger2   = (stateno=5001 || stateno=5011 || stateno=151 || stateno=153 || stateno=140) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = Var(0)=3300 && floor(var(40)/100%10)=0 || Var(0)=3200

;---------------------------------------------------------------------
[State -1,���_�����j�iLV.1�j]
type       = ChangeState
value      =  3100
triggerall = StateType != A && floor(var(40)%10)=1
trigger1   = Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,3]) || var(47)&&(var(22)=[4,5]) || (var(22) = [-2,-1])
trigger1   = Command = "Bushin Gouraiha_Lv.3" && floor(var(40)/100%10)=0 || Command = "Bushin Gouraiha_Lv.2" && floor(var(40)/10%10)=0 || Command = "Bushin Gouraiha_Lv.1"
trigger2   = (stateno=5001 || stateno=5011 || stateno=151 || stateno=153 || stateno=140) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = Var(0)=3300 && floor(var(40)/100%10)=0 || Var(0)=3200 && floor(var(40)/10%10)=0 || Var(0)=3100

;=====================================================================
; Special Arts
;=====================================================================

;---------------------------------------------------------------------
[State -1,�V��|���E��]
type       = ChangeState
value      = 1500
triggerall = StateType = A && var(32)!= 2
triggerall = pos y < -15 && var(32) != [2,3]
trigger1   = Command = "Tengu Daoshi_x"
trigger1   = Ctrl || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1

;---------------------------------------------------------------------
[State -1,�V��|���E��]
type       = ChangeState
value      = 1510
triggerall = StateType = A && var(32)!= 2
triggerall = pos y < -15 && var(32) != [2,3]
trigger1   = Command = "Tengu Daoshi_y"
trigger1   = Ctrl || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1

;---------------------------------------------------------------------
[State -1,�V��|���E��]
type       = ChangeState
value      = 1520
triggerall = StateType = A && var(32)!= 2
triggerall = pos y < -15 && var(32) != [2,3]
trigger1   = Command = "Tengu Daoshi_z"
trigger1   = Ctrl || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1

;---------------------------------------------------------------------
[State -1,���R�E��]
type       = ChangeState
value      = 1000
triggerall = StateType != A
trigger1   = Command = "Genko_x"
trigger1   = Ctrl || StateNo=100 && animelemtime(2)>1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1
trigger2   = (stateno=5001 || stateno=5011) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = var(0)=11

;---------------------------------------------------------------------
[State -1,���R�E��]
type = ChangeState
value = 1010
triggerall = StateType != A
trigger1   = Command = "Genko_y"
trigger1   = Ctrl || StateNo=100 && animelemtime(2)>1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1
trigger2   = (stateno=5001 || stateno=5011) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = var(0)=12

;---------------------------------------------------------------------
[State -1,���R�E��]
type       = ChangeState
value      = 1020
triggerall = StateType != A
trigger1   = Command = "Genko_z"
trigger1   = Ctrl || StateNo=100 && animelemtime(2)>1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1
trigger2   = (stateno=5001 || stateno=5011) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = var(0)=13

;---------------------------------------------------------------------
[State -1,���삯]
type       = ChangeState
value      = 1100
triggerall = StateType != A
trigger1   = Command = "Hayagake"
trigger1   = Ctrl || StateNo=100 && animelemtime(2)>1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1
trigger2   = (stateno=5001 || stateno=5011) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = var(0)=20

;---------------------------------------------------------------------
[State -1,�t���삯]
type       = ChangeState
value      = 1200
triggerall = StateType != A
triggerall = Command = "Hassoukyaku_a" || Command = "Hassoukyaku_b" || Command = "Hassoukyaku_c"
trigger1   = Ctrl || StateNo=100 && animelemtime(2)>1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1
trigger2   = (stateno=5001 || stateno=5011) && HitOver || stateno=5120 && AnimTime = 0
trigger2   = var(0)=30

;---------------------------------------------------------------------
[State -1,���z�r�i�p���`�j]
type       = ChangeState
value      = IfElse((Command = "Hassoukyaku_y"),1410,IfElse((Command = "Hassoukyaku_z"),1415,1400))
triggerall = StateType = A && pos y < -15 && var(32)!= 2 && backedgebodydist < 5 && var(32) != [2,3]
trigger1   = Ctrl || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1
trigger1   = Command = "Hassoukyaku_x" || Command = "Hassoukyaku_y" || Command = "Hassoukyaku_z"

;------------------------
[State -1,���z�r�i�L�b�N�j]
type       = ChangeState
value      = IfElse((Command = "Hassoukyaku_b"),1440,IfElse((Command = "Hassoukyaku_c"),1445,1430))
triggerall = StateType = A && pos y < -15 && var(32)!= 2 && backedgebodydist < 5 && var(32) != [2,3]
trigger1   = Ctrl || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1
trigger1   = Command = "Hassoukyaku_a" || Command = "Hassoukyaku_b" || Command = "Hassoukyaku_c"

;---------------------------------------------------------------------
[State -1,�󕗋r]
type       = ChangeState
value      = 1300
triggerall = StateType != A && Life > 1
trigger1   = Ctrl || StateNo=100 && animelemtime(2)>1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1
trigger1   = Command = "Reppukyaku"

;=====================================================================
; Basic Animation
;=====================================================================

;---------------------------------------------------------------------
[State -1,�X�e�b�v]
type       = ChangeState
value      = 110
triggerall = Command = "FF" && StateType = S && Ctrl
trigger1   = (var(30) = 1 || var(30) = 2 || var(30) = 3) && !var(43)
trigger2   = var(43)&&floor(var(51)%10)=1

;---------------------------------------------------------------------
[State -1,����]
type       = ChangeState
value      = 100
triggerall = Command = "FF" && StateType = S && Ctrl && StateNo != 100
trigger1   = (var(30) = 4 || var(30) = 5 || var(30) = 6) && !var(43)
trigger2   = var(43)&&floor(var(51)%10)=2

;---------------------------------------------------------------------
[State -1,�o�b�N�X�e�b�v]
type       = ChangeState
value      = 105
trigger1   = Command = "BB" && StateType = S && Ctrl

;=====================================================================
; Basic Throws
;=====================================================================

;---------------------------------------------------------------------
[State -1,����i�o�ʏ퓊���j]
type       = ChangeState
value      = 800
triggerall = StateNo != 100 && StateType = S && (Ctrl ||var(22) = 5)
triggerall = P2MoveType != H && !P2StateType = A
trigger1   = Command = "fwd_z" && P2BodyDist X < 26
trigger2   = Command = "back_z" && P2BodyDist X < 26

;---------------------------------------------------------------------
[State -1,�G���܂��i�j�ʏ퓊���j]
type       = ChangeState
value      = 850
triggerall = StateNo != 100 && StateType = S && (Ctrl ||var(22) = 5)
triggerall = P2MoveType != H && !P2StateType = A
trigger1   = Command = "fwd_c" && P2BodyDist X < 26
trigger2   = Command = "back_c" && P2BodyDist X < 26

;---------------------------------------------------------------------
; Special Attacks , Moves and so on.
;---------------------------------------------------------------------

;---------------------------------------------------------------------
[State -1,��荞��]
type       = ChangeState
value      = 4000
triggerall = Command = "recovery"  && StateType != A && ((Ctrl || Time < 2 && (stateno=[200,799]) || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger1   = (var(30)=1 || var(30)=2 || var(30)=5) && !var(43)
trigger2   = var(43)&&floor(var(51)/10%10)=1
trigger3   = var(43)&&floor(var(51)/10%10)=3 && Command = "holdfwd"

;---------------------------------------------------------------------
[State -1,����]
type       = ChangeState
value      = 4010
triggerall = Command = "recovery"  && StateType != A && (Ctrl || Time < 2 && (stateno=[200,799]) || StateNo=100 && animelemtime(2) >1 || StateNo=101)
trigger1   = var(30)=4 && !var(43)
trigger2   = var(43)&&floor(var(51)/10%10)=2
trigger3   = var(43)&&floor(var(51)/10%10)=3

;---------------------------------------------------------------------
[State -1,�J�E���^�[�U���i�p���`�j]
type       = ChangeState
value      = 4020
triggerall = Command = "x" || Command = "y" || Command = "z"
trigger1   = StateNo = 4010
trigger1   = AnimElem = 3,>1

[State -1,�J�E���^�[�U���i�L�b�N�j]
type       = ChangeState
value      = 4025
triggerall = Command = "a" || Command = "b" || Command = "c"
trigger1   = StateNo = 4010
trigger1   = Time = [14,23]

;---------------------------------------------------------------------
[State -1,�p���[���ߓ���]
type       = ChangeState
value      = 4100
TriggerAll = command = "charge1" && command = "charge2" && fvar(8)!
TriggerAll = statetype!= A && (var(30)=6 && fvar(37) <72 || var(30)=4 && fvar(37) <100 || var(30)!=4 && Power < 3000)
TriggerAll   = var(30)=4 || var(43)&&floor(var(50)/10000000%10)=1
Trigger1   = (Ctrl || Time < 2 && (stateno=[200,799]) || StateNo=100 && animelemtime(2) >1 || StateNo=101)

;---------------------------------------------------------------------
[State -1,�p���[MAX����]
type       = ChangeState
value      = 4150
TriggerAll = command = "Pow-MAX"
TriggerAll = statetype!= A && (Ctrl || Time < 2 && (stateno=[200,799]) || StateNo=100 && animelemtime(2) >1 || StateNo=101)
Trigger1   = var(30)=5 && Power >= 1000 && fvar(8)!
Trigger2   = var(30)=4 && floor(var(52)/10%10)=1 && fvar(8)=-1

[State -1,�N�C�b�NMAX����]
type       = ChangeState
value      = 4160
TriggerAll = command = "Pow-MAX"
triggerall = var(30)=4 && floor(var(52)/10%10)=1 && fvar(8)=-1
trigger1   = statetype != A && MoveContact
trigger1   = (StateNo = [200,799]) || var(22)=-2 || (StateNo = 150 || StateNo = 152)
ignorehitpause = 1

;---------------------------------------------------------------------
[State -1,�I���R�������i�n��j]
type       = ChangeState
value      = 4200
triggerall = command = "Pow-MAX"
triggerall = statetype != A && var(30)=2 && Power >= 3000 && fvar(8)!
trigger1   = (Ctrl || Time < 2 && (stateno=[200,799]) || StateNo=100 && animelemtime(2) >1 || StateNo=101)

[State -1,�I���R�������i�󒆁j]
type       = ChangeState
value      = 4210
triggerall = command = "Pow-MAX"
triggerall = statetype = A && var(30)=2 && Power >= 3000 && fvar(8)!
trigger1   = (Ctrl || Time < 2 && (stateno=[200,799]) || StateNo=100 && animelemtime(2) >1 || StateNo=101)

;---------------------------------------------------------------------
[State -1,�K�[�h�L�����Z���U��]
type       = ChangeState
value      = IfElse(Var(29),14500,4500)
triggerall = Command = "GC_Attack"
triggerall = (StateNo = 150 || StateNo = 152) && StateType != A
trigger1   = (var(30)=1 && Power>=1000) || (var(30)=2 && (Power>=1500||Fvar(8))) || (var(30)=4 && Fvar(8)) || (var(30)=5 && (Power>=1000||Fvar(8)))
trigger2   = var(43)&&floor(var(51)/100%10)=1
trigger2   = (var(30)=3 && Power>=3000) || (var(30)=6 && Fvar(8))

;---------------------------------------------------------------------
[State -1,�K�[�h�L�����Z���ړ�]
type       = ChangeState
value      = IfElse((Command = "GC_back"),4520,4510)
triggerall = Command = "GC_fwd" || Command = "GC_back"
triggerall = (StateNo = 150 || StateNo = 152) && StateType != A
trigger1   = (var(30)=1 && Power>=1000) || (var(30)=2 && (Power>=1500||Fvar(8))) || (var(30)=4 && Fvar(8)) || (var(30)=5 && (Power>=1000||Fvar(8)))
trigger2   = var(43)&&floor(var(51)/1000%10)=1
trigger2   = (var(30)=3 && Power>=3000) || (var(30)=6 && Fvar(8))

;=====================================================================
; Dir + Button
;=====================================================================

;---------------------------------------------------------------------
[State -1,�I���Ƃ�]
type       = ChangeState
value      = 700
triggerall = Command = "down_y" && StateType = A
triggerall = StateNo != 105
trigger1   = Ctrl || (Var(30) = 2 && var(22) = 4)
trigger2   = var(43)&&floor(var(50)/10000%10)=1 && MoveContact = 1
trigger2   = StateNo=600 || StateNo=630

;---------------------------------------------------------------------
[State -1,���_�������i���o�j]
type       = ChangeState
value      = 710
triggerall = Command = "y"
trigger1   = StateNo = 200 && Movecontact = [3,8]

[State -1,���_�������i���o�j]
type       = ChangeState
value      = 711
triggerall = Command = "z"
trigger1   = StateNo = 710 && Movecontact = [3,8]

[State -1,���_�������i���j�j]
type       = ChangeState
value      = 712
triggerall = Command = "c"
trigger1   = StateNo = 711 && Movecontact

[State -1,���_�������i�����o�j]
type       = ChangeState
value      = 720
triggerall = Command = "down_z"
trigger1   = StateNo = 711 && Movecontact

;=====================================================================
; Taunts
;=====================================================================

;---------------------------------------------------------------------
[State -1,����]
type       = ChangeState
value      = 195
triggerall = command = "start"
trigger1   = StateType = S
trigger1   = Ctrl || StateNo=100 && animelemtime(2)>1 || StateNo=101 || StateNo=52 && Time>=2 || (var(22)=[1,2]) || Var(30)=1&&var(22)=-1 || var(47)&&(var(22)=[3,5]) || var(22)=3&&var(43)&&floor(var(50)%100000)=1

;=====================================================================
; Basic Arts
;=====================================================================

;---------------------------------------------------------------------
[State -1,������p���`]
type       = ChangeState
value      = 200
triggerall = Command = "x" && !Command = "holddown"
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = (StateNo = 200 && AnimElem = 3,> 0)
trigger3   = (StateNo = 400 && AnimElem = 3,> 0)

;---------------------------------------------------------------------
[State -1,�������p���`]
type       = ChangeState
value      = IfElse(P2BodyDist X <= 15,215,210)
triggerall = Command = "y" && !Command = "holddown"
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger2   = StateNo=200 || StateNo=230 || StateNo=400 || StateNo=430

;---------------------------------------------------------------------
[State -1,�������p���`]
type       = ChangeState
value      = IfElse(P2BodyDist X <= 25,225,220)
triggerall = Command = "z" && !Command = "holddown"
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger2   = StateNo=200 || (StateNo=[210,215]) || StateNo=230 || (StateNo=[240,245]) || StateNo=400 || StateNo=410 || StateNo=430 || StateNo=440 || StateNo=710

;---------------------------------------------------------------------
[State -1,������L�b�N]
type       = ChangeState
value      = 230
triggerall = Command = "a" && !Command = "holddown"
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = (StateNo = 200 && AnimElem = 3,> 0)
trigger3   = (StateNo = 400 && AnimElem = 3,> 0)
trigger4   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger4   = StateNo=200 || StateNo=400

;---------------------------------------------------------------------
[State -1,�������L�b�N]
type       = ChangeState
value      = IfElse(P2BodyDist X <= 20,245,240)
triggerall = Command = "b" && !Command = "holddown"
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger2   = StateNo=200 || (StateNo=[210,215]) || StateNo=230 || StateNo=400 || StateNo=410 || StateNo=430

;---------------------------------------------------------------------
[State -1,�������L�b�N]
type       = ChangeState
value      = IfElse(P2BodyDist X <= 5,255,250)
triggerall = Command = "c" && !Command = "holddown"
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger2   = StateNo=200 || (StateNo=[210,215]) || (StateNo=[220,225]) || StateNo=230 || (StateNo=[240,245]) || StateNo=400 || StateNo=410 || StateNo=420 || StateNo=430 || StateNo=440 || StateNo=710 || StateNo=711

;---------------------------------------------------------------------
[State -1,���Ⴊ�ݎ�p���`]
type       = ChangeState
value      = 400
triggerall = Command = "x" && Command = "holddown" && StateType != A
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = (StateNo = 200 && AnimElem = 3,> 0)
trigger3   = (StateNo = 400 && AnimElem = 3,> 0)

;---------------------------------------------------------------------
[State -1,���Ⴊ�ݒ��p���`]
type       = ChangeState
value      = 410
triggerall = Command = "y" && Command = "holddown" && StateType != A
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger2   = StateNo=200 || StateNo=230 || StateNo=400 || StateNo=430

;---------------------------------------------------------------------
[State -1,���Ⴊ�݋��p���`]
type       = ChangeState
value      = 420
triggerall = Command = "z" && Command = "holddown" && StateType != A
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger2   = StateNo=200 || (StateNo=[210,215]) || StateNo=230 || (StateNo=[240,245]) || StateNo=400 || StateNo=410 || StateNo=430 || StateNo=440 || StateNo=710

;---------------------------------------------------------------------
[State -1,���Ⴊ�ݎ�L�b�N]
type       = ChangeState
value      = 430
triggerall = Command = "a" && Command = "holddown" && StateType != A
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = (StateNo = 200 && AnimElem = 3,> 0)
trigger3   = (StateNo = 400 && AnimElem = 3,> 0)
trigger4   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger4   = StateNo=200 || StateNo=400

;---------------------------------------------------------------------
[State -1,���Ⴊ�ݒ��L�b�N]
type       = ChangeState
value      = 440
triggerall = Command = "b" && Command = "holddown" && StateType != A
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger2   = StateNo=200 || (StateNo=[210,215]) || StateNo=230 || StateNo=400 || StateNo=410 || StateNo=430

;---------------------------------------------------------------------
[State -1,���Ⴊ�݋��L�b�N]
type       = ChangeState
value      = 450
triggerall = Command = "c" && Command = "holddown" && StateType != A
trigger1   = StateType != A && ((Ctrl || StateNo=100 && animelemtime(2) >1 || StateNo=101) || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5)))
trigger2   = var(43)&&floor(var(50)/1000%10)=1 && MoveContact = 1
trigger2   = StateNo=200 || (StateNo=[210,215]) || (StateNo=[220,225]) || StateNo=230 || (StateNo=[240,245]) || StateNo=400 || StateNo=410 || StateNo=420 || StateNo=430 || StateNo=440 || StateNo=710 || StateNo=711

;---------------------------------------------------------------------
[State -1,�W�����v��p���`]
type       = ChangeState
value      = 600
triggerall = Command = "x" && StateType = A
triggerall = StateNo != 105
trigger1   = Ctrl || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5))

;---------------------------------------------------------------------
[State -1,�W�����v���p���`]
type       = ChangeState
value      = 610
triggerall = Command = "y" && StateType = A
triggerall = StateNo != 105
trigger1   = Ctrl || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5))
trigger2   = var(43)&&floor(var(50)/10000%10)=1 && MoveContact = 1
trigger2   = StateNo=600 || StateNo=630

;---------------------------------------------------------------------
[State -1,�W�����v���p���`]
type       = ChangeState
value      = 620
triggerall = Command = "z" && StateType = A
triggerall = StateNo != 105
trigger1   = Ctrl || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5))
trigger2   = var(43)&&floor(var(50)/10000%10)=1 && MoveContact = 1
trigger2   = StateNo=600 || StateNo=610 || StateNo=630 || StateNo=640 || StateNo=700

;---------------------------------------------------------------------
[State -1,�W�����v��L�b�N]
type       = ChangeState
value      = 630
triggerall = Command = "a" && StateType = A
triggerall = StateNo != 105
trigger1   = Ctrl || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5))
trigger2   = var(43)&&floor(var(50)/10000%10)=1 && MoveContact = 1
trigger2   = StateNo=600

;---------------------------------------------------------------------
[State -1,�W�����v���L�b�N]
type       = ChangeState
value      = 640
triggerall = Command = "b" && StateType = A
triggerall = StateNo != 105
trigger1   = Ctrl || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5))
trigger2   = var(43)&&floor(var(50)/10000%10)=1 && MoveContact = 1
trigger2   = StateNo=600 || StateNo=610 || StateNo=630 || StateNo=700

;---------------------------------------------------------------------
[State -1,�W�����v���L�b�N]
type       = ChangeState
value      = 650
triggerall = Command = "c" && StateType = A
triggerall = StateNo != 105
trigger1   = Ctrl || (var(47) && ((var(22)=[2,4]) || MoveContact && var(22)=5))
trigger2   = var(43)&&floor(var(50)/10000%10)=1 && MoveContact = 1
trigger2   = StateNo=600 || StateNo=610 || StateNo=620 || StateNo=630 || StateNo=640 || StateNo=700

 
