===================================================================
Maki / CAPCOM VS SNK2 MILLIONAIRE FIGHTING2001 -by H"
							Ver.1.32
===================================================================
*Please do not link directly to the files.

email- ms09dom61@hotmail.com
					
===================================================================
 Note
===================================================================
 Sorry,This character is WinMUGEN(030614) only.
 It can't play with the Dos version.

 EX groove is Hold start at intro.

===================================================================
 Update report
===================================================================
2004/08/08   first relesed
     08/09   bug fix
     09/05   bug fix
     09/20   bug fix
     11/21   bug fix
     12/29   bug fix
2005/01/30   bug fix
     02/19   bug fix
     09/06   bug fix
2008/02/24   bug fix
     06/09   version up
     06/13   bug fix
     06/14   bug fix
     07/02   bug fix
     07/30   bug fix
     08/03   bug fix
     08/31   bug fix
     09/22   version up
     10/19   bug fix
     10/27   bug fix