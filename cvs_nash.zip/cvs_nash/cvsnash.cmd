;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "�u���C�N1"
command = ~45$B, $F, $B, F, x
time = 21

[Command]
name = "�u���C�N1"
command = ~45$B, $F, $B, F, ~x
time = 21

[Command]
name = "�u���C�N2"
command =  ~45$B, $F, $B, F, y
time = 21

[Command]
name = "�u���C�N2"
command =  ~45$B, $F, $B, F, ~y
time = 21

[Command]
name = "�u���C�N3"
command =  ~45$B, $F, $B, F, z
time = 21

[Command]
name = "�u���C�N3"
command = ~45$B, $F, $B, F, ~z
time = 21

[Command]
name = "�u���C�N4"
command = ~$B, $F, $B, F, x
time = 21

[Command]
name = "�u���C�N4"
command = ~$B, $F, $B, F, ~x
time = 21

[Command]
name = "�u���C�N5"
command =  ~$B, $F, $B, F, y
time = 21

[Command]
name = "�u���C�N5"
command =  ~$B, $F, $B, F, ~y
time = 21

[Command]
name = "�u���C�N6"
command =  ~$B, $F, $B, F, z
time = 21

[Command]
name = "�u���C�N6"
command = ~$B, $F, $B, F, ~z
time = 21

[Command]
name = "Blitz1"
command = ~45$B, $F, $B, F, a
time = 21

[Command]
name = "Blitz1"
command = ~45$B, $F, $B, F, ~a
time = 21

[Command]
name = "Blitz2"
command = ~45$B, $F, $B, F, b
time = 21

[Command]
name = "Blitz2"
command = ~45$B, $F, $B, F, ~b
time = 21

[Command]
name = "Blitz3"
command = ~45$B, $F, $B, F, c
time = 21

[Command]
name = "Blitz3"
command =  ~45$B, $F, $B, F, ~c
time = 21

[Command]
name = "Blitz4"
command = ~$B, $F, $B, F, a
time = 21

[Command]
name = "Blitz4"
command = ~$B, $F, $B, F, ~a
time = 21

[Command]
name = "Blitz5"
command = ~$B, $F, $B, F, b
time = 21

[Command]
name = "Blitz5"
command = ~$B, $F, $B, F, ~b
time = 21

[Command]
name = "Blitz6"
command = ~$B, $F, $B, F, c
time = 21

[Command]
name = "Blitz6"
command = ~$B, $F, $B, F, ~c
time = 21

[Command]
name = "Justice1"
command = ~D, DB, B, D, DB, a
time = 21

[Command]
name = "Justice1"
command = ~D, DB, B, D, DB, ~a
time = 21

[Command]
name = "Justice2"
command = ~D, DB, B, D, DB, b
time = 21

[Command]
name = "Justice2"
command = ~D, DB, B, D, DB, ~b
time = 21

[Command]
name = "Justice3"
command = ~D, DB, B, D, DB, c
time = 21

[Command]
name = "Justice3"
command =  ~D, DB, B, D, DB, ~c
time = 21

[Command]
name = "Justice4"
command = ~D, DB, B, D, DB, a
time = 21

[Command]
name = "Justice4"
command = ~D, DB, B, D, DB, ~a
time = 21

[Command]
name = "Justice5"
command = ~D, DB, B, D, DB, b
time = 21

[Command]
name = "Justice5"
command = ~D, DB, B, D, DB, ~b
time = 21

[Command]
name = "Justice6"
command = ~D, DB, B, D, DB, c
time = 21

[Command]
name = "Justice6"
command = ~D, DB, B, D, DB, ~c
time = 21

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "somersault1"
command = ~45$D, $U, a
time = 12

[Command]
name = "somersault1"
command = ~45$D, $U, ~a
time = 12

[Command]
name = "somersault2"
command = ~45$D, $U, b
time = 12

[Command]
name = "somersault2"
command = ~45$D, $U, ~b
time = 12

[Command]
name = "somersault3"
command = ~45$D, $U, c
time = 12
[Command]
name = "somersault3"
command =  ~45$D, $U, ~c
time = 12

[Command]
name = "somersault4"
command = ~$D, $U, a
time = 12

[Command]
name = "somersault4"
command = ~$D, $U, ~a
time = 12

[Command]
name = "somersault5"
command = ~$D, $U, b
time = 12

[Command]
name = "somersault5"
command = ~$D, $U, ~b
time = 12

[Command]
name = "somersault6"
command = ~$D, $U, c
time = 12

[Command]
name = "somersault6"
command = ~$D, $U, ~c
time = 12

[Command]
name = "sonic1"
command = ~45$B, $F, x
time = 12

[Command]
name = "sonic1"
command = ~45$B, $F, ~x
time = 12

[Command]
name = "sonic2"
command = ~45$B, F, y
time = 12

[Command]
name = "sonic2"
command = ~45$B, F, ~y
time = 12

[Command]
name = "sonic3"
command = ~45$B, F, z
time = 12

[Command]
name = "sonic3"
command = ~45$B, F, ~z
time = 12

[Command]
name = "sonic4"
command = ~$B, F, x
time = 12

[Command]
name = "sonic4"
command = ~$B, F, ~x
time = 12

[Command]
name = "sonic5"
command = ~$B, F, y
time = 12

[Command]
name = "sonic5"
command = ~$B, F, ~y
time = 12

[Command]
name = "sonic6"
command = ~$B, F, z
time = 12

[Command]
name = "sonic6"
command =  ~$B, F, ~z
time = 12

[Command]
name = "��"
command =   a+y �@   �@�@  ��@p;   
time = 12

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 18

[Command]
name = "FF"     
command = F, F
time = 12

[Command]
name = "BB"     
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

[Command];
name = "renda3"
command = U
time = 1

[Command];
name = "renda4"
command = B
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;---------------------------------------------------------------------------
;�\�j�b�N�u���C�N3
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(3205)
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14)
triggerall = Command = "�u���C�N1" ||  Command = "�u���C�N2" || Command = "�u���C�N3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (var(16) || animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 221 && (var(16) || animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 241 && (var(16) || animelemtime(3) < 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 250 && var(16)
trigger11 = StateNo = 251 && (var(16) || animelemtime(4) < 0)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || animelemtime(4) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger15 = StateNo = 430
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 2))
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger20 = StateNo = 320 && (var(16) || animelemtime(4) < 0)
trigger21 = StateNo = 330 && (var(16) || animelemtime(5) < 0)
trigger22 = (StateNo = [1000,1199]) && var(36) && var(16)
trigger23 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger24 = (StateNo = [1000,1199]) && (var(20) = 2 || var(20) = 6)
trigger25 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger26 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 51
trigger27 = StateNo = 3101 && (var(20) = 2 || var(20) = 6)
trigger28 = StateNo = 3102 && (var(20) = 2 || var(20) = 6)
trigger29 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�T�}�[�\���g�W���X�e�B�X�i�I���R���j
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = var(16)
triggerall = roundstate = 2
triggerall = Command = "�u���C�N4" || Command = "�u���C�N5" || Command = "�u���C�N6"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (StateNo = [195,799])
trigger3 = (StateNo = [1000,1199]) && var(36)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�T�}�[�\���g�W���X�e�B�X�i�ʏ�j
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = !var(16)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14)
triggerall = Command = "Justice1" || Command = "Justice2" || Command = "Justice3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 221 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230
trigger8 = StateNo = 240 && animelemtime(4) < 0
trigger9 = StateNo = 241 && (animelemtime(3) < 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (animelemtime(4) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (animelemtime(3) < 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (animelemtime(3) < 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 2))
trigger16 = StateNo = 300 && animelemtime(4) < 0
trigger17 = StateNo = 310 && animelemtime(2) < 0
trigger18 = StateNo = 320 && animelemtime(4) < 0
trigger19 = StateNo = 330 && animelemtime(5) < 0
trigger20 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger21 = (StateNo = [1000,1199]) && (var(20) = 2 || var(20) = 6)
trigger22 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger23 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 51
ignorehitpause = 0

;---------------------------------------------------------------------------
;�T�}�[�\���g�W���X�e�B�X�i�I���R���j
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = var(16)
triggerall = roundstate = 2
triggerall = Command = "Justice4" || Command = "Justice5" || Command = "Justice6"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (StateNo = [195,799])
trigger3 = (StateNo = [1000,1199]) && var(36)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�N���X�t�@�C�A�u���b�c�i�ʏ�j
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = !var(16)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14)
triggerall = Command = "Blitz1" || Command = "Blitz2" || Command = "Blitz3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 221 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230
trigger8 = StateNo = 240 && animelemtime(4) < 0
trigger9 = StateNo = 241 && (animelemtime(3) < 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (animelemtime(4) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (animelemtime(3) < 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (animelemtime(3) < 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 2))
trigger16 = StateNo = 300 && animelemtime(4) < 0
trigger17 = StateNo = 310 && animelemtime(2) < 0
trigger18 = StateNo = 320 && animelemtime(4) < 0
trigger19 = StateNo = 330 && animelemtime(5) < 0
trigger20 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger21 = (StateNo = [1000,1199]) && (var(20) = 2 || var(20) = 6)
trigger22 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 51
trigger23 = StateNo = 3101 && (var(20) = 2 || var(20) = 6)
trigger24 = StateNo = 3102 && (var(20) = 2 || var(20) = 6)
trigger25 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
trigger26 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 51
ignorehitpause = 0

;---------------------------------------------------------------------------
;�N���X�t�@�C�A�u���b�c�i�I���R���j
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = var(16)
triggerall = roundstate = 2
triggerall = Command = "Blitz4" || Command = "Blitz5" || Command = "Blitz6"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = [195,799]
trigger3 = (StateNo = [1000,1199]) && var(36)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�T�}�[�\���g�V�F���i�ʏ�j
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = !var(16)
triggerall = roundstate = 2
triggerall = Command = "somersault1" || Command = "somersault2" || Command = "somersault3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger4 = StateNo = 211 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && animelemtime(3) < 0
trigger6 = StateNo = 221 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230
trigger8 = StateNo = 240 && animelemtime(4) < 0
trigger9 = StateNo = 241 && (animelemtime(3) < 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && animelemtime(3) < 0
trigger13 = StateNo = 430 && animelemtime(3) < 0
trigger14 = StateNo = 440 && animelemtime(3) < 0
trigger15 = StateNo = 450 && animelemtime(3) < 0
trigger16 = StateNo = 300 && animelemtime(4) < 0
trigger17 = StateNo = 310 && animelemtime(2) < 0
trigger18 = StateNo = 320 && animelemtime(4) < 0
trigger19 = StateNo = 330 && animelemtime(5) < 0
trigger20 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�T�}�[�\���g�V�F���i�I���R���j
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = var(16)
triggerall = roundstate = 2
triggerall = Command = "somersault4" || Command = "somersault5" || Command = "somersault6"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (StateNo = [195,799]) && statetype != A
trigger3 = (StateNo = [1000,1199]) && var(36)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�\�j�b�N�u�[���i�ʏ�j
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = !var(16)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(3205)
triggerall = Command = "sonic1" || Command = "sonic2" || Command = "sonic3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger4 = StateNo = 211 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && animelemtime(3) < 0
trigger6 = StateNo = 221 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230
trigger8 = StateNo = 240 && animelemtime(4) < 0
trigger9 = StateNo = 241 && (animelemtime(3) < 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && animelemtime(3) < 0
trigger13 = StateNo = 430 && animelemtime(3) < 0
trigger14 = StateNo = 440 && animelemtime(3) < 0
trigger15 = StateNo = 450 && animelemtime(3) < 0
trigger16 = StateNo = 300 && animelemtime(4) < 0
trigger17 = StateNo = 310 && animelemtime(2) < 0
trigger18 = StateNo = 320 && animelemtime(4) < 0
trigger19 = StateNo = 330 && animelemtime(5) < 0
trigger20 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�\�j�b�N�u�[���i�I���R���j
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = var(16)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(3205)
triggerall = Command = "sonic4" || Command = "sonic5" || Command = "sonic6"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = [195,799]
trigger3 = (StateNo = [1000,1199]) && var(36)
ignorehitpause = 0

;---------------------------------------------------------------------------
;��
[State -1, Taunt]
type = ChangeState
value = 650
triggerall = command = "��" 
triggerall = statetype = A
trigger1 = ctrl 

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = Power >= 3000 && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger4 = StateNo = 211 && (var(16) || animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger6 = StateNo = 221 && (var(16) || animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230
trigger8 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger9 = StateNo = 241 && (var(16) || animelemtime(3) < 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 250 && var(16)
trigger11 = StateNo = 251 && (var(16) || animelemtime(4) < 0)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || animelemtime(2) < 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || animelemtime(3) < 0)
trigger15 = StateNo = 430 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 440 && (var(16) || animelemtime(3) < 0)
trigger17 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger18 = StateNo = 300 && (var(16) || animelemtime(4) < 0)
trigger19 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger20 = StateNo = 315 && var(16)
trigger21 = StateNo = 320 && (var(16) || animelemtime(4) < 0)
trigger22 = StateNo = 330 && (var(16) || animelemtime(5) < 0)
trigger23 = (StateNo = [1000,1199]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6  
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5201
triggerall = !var(59)
triggerall = !var(1)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= 10
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 241 && time < 2
trigger10 = StateNo = 251 && time < 2
trigger11 = StateNo = 400 && time < 2
trigger12 = StateNo = 410 && time < 2
trigger13 = StateNo = 420 && time < 2
trigger14 = StateNo = 430 && time < 2
trigger15 = StateNo = 440 && time < 2
trigger16 = StateNo = 450 && time < 2
trigger17 = StateNo = 300 && time < 2
trigger18 = StateNo = 310 && time < 2
trigger19 = StateNo = 320 && time < 2
trigger20 = StateNo = 330 && time < 2
trigger21 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger22 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 241 && time < 2
trigger10 = StateNo = 251 && time < 2
trigger11 = StateNo = 400 && time < 2
trigger12 = StateNo = 410 && time < 2
trigger13 = StateNo = 420 && time < 2
trigger14 = StateNo = 430 && time < 2
trigger15 = StateNo = 440 && time < 2
trigger16 = StateNo = 450 && time < 2
trigger17 = StateNo = 300 && time < 2
trigger18 = StateNo = 310 && time < 2
trigger19 = StateNo = 320 && time < 2
trigger20 = StateNo = 330 && time < 2
trigger21 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger22 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 241 && time < 2
trigger10 = StateNo = 251 && time < 2
trigger11 = StateNo = 400 && time < 2
trigger12 = StateNo = 410 && time < 2
trigger13 = StateNo = 420 && time < 2
trigger14 = StateNo = 430 && time < 2
trigger15 = StateNo = 440 && time < 2
trigger16 = StateNo = 450 && time < 2
trigger17 = StateNo = 300 && time < 2
trigger18 = StateNo = 310 && time < 2
trigger19 = StateNo = 320 && time < 2
trigger20 = StateNo = 330 && time < 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 241 && time < 2
trigger10 = StateNo = 251 && time < 2
trigger11 = StateNo = 400 && time < 2
trigger12 = StateNo = 410 && time < 2
trigger13 = StateNo = 420 && time < 2
trigger14 = StateNo = 430 && time < 2
trigger15 = StateNo = 440 && time < 2
trigger16 = StateNo = 450 && time < 2
trigger17 = StateNo = 300 && time < 2
trigger18 = StateNo = 310 && time < 2
trigger19 = StateNo = 320 && time < 2
trigger20 = StateNo = 330 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 211 && time < 2
trigger5 = StateNo = 220 && time < 2
trigger6 = StateNo = 221 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 240 && time < 2
trigger9 = StateNo = 241 && time < 2
trigger10 = StateNo = 251 && time < 2
trigger11 = StateNo = 400 && time < 2
trigger12 = StateNo = 410 && time < 2
trigger13 = StateNo = 420 && time < 2
trigger14 = StateNo = 430 && time < 2
trigger15 = StateNo = 440 && time < 2
trigger16 = StateNo = 450 && time < 2
trigger17 = StateNo = 300 && time < 2
trigger18 = StateNo = 310 && time < 2
trigger19 = StateNo = 320 && time < 2
trigger20 = StateNo = 330 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !var(4)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 250 && time < 2
trigger3 = StateNo = 600 && time < 2
trigger4 = StateNo = 610 && time < 2
trigger5 = StateNo = 611 && time < 2
trigger6 = StateNo = 620 && time < 2
trigger7 = StateNo = 621 && time < 2
trigger8 = StateNo = 630 && time < 2
trigger9 = StateNo = 631 && time < 2
trigger10 = StateNo = 640 && time < 2
trigger11 = StateNo = 641 && time < 2
trigger12 = StateNo = 650 && time < 2
trigger13 = StateNo = 651 && time < 2

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [-1,22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;�t���C���O���C���[
[State -1, Throw]
type = ChangeState
value = 920
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback" || command = "holddown") && command = "c"
triggerall = statetype = A
triggerall = ctrl
triggerall = P2bodydist X = [-1,9]
triggerall = P2bodydist Y = [-70,-enemynear,const(size.head.pos.y)-62]
trigger1 = p2statetype = A
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;�t���C���O�o�X�^�[�h���b�v
[State -1, Throw]
type = ChangeState
value = 930
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback" || command = "holddown") && command = "z"
triggerall = statetype = A
triggerall = ctrl
triggerall = P2bodydist X = [-1,9]
triggerall = P2bodydist Y = [-86,-enemynear,const(size.head.pos.y)-78]
trigger1 = p2statetype = A
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;�X�s�j���O�o�b�N�i�b�N��
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�j�[�o�Y�[�J
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown" && (Command = "holdfwd" || Command = "holdback")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���[�����O�\�o�b�g
[State -1, Taunt]
type = ChangeState
value = 320
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown" && (Command = "holdfwd" || Command = "holdback")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���o�[�X�X�s���L�b�N
[State -1, Taunt]
type = ChangeState
value =    330
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown" && (Command = "holdfwd" || Command = "holdback")
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 4
trigger5 = StateNo = 430 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 4
trigger5 = StateNo = 430 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 251
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 4
trigger5 = StateNo = 430 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 4
trigger5 = StateNo = 430 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1199]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�΂߃W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����W�����v���p���`
[State -1]
type = ChangeState
value = 611
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�΂߃W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����W�����v���p���`
[State -1]
type = ChangeState
value = 621
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�΂߃W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����W�����v��L�b�N
[State -1]
type = ChangeState
value = 631
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�΂߃W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�����W�����v���L�b�N
[State -1]
type = ChangeState
value = 641
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�΂߃W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����W�����v���L�b�N
[State -1]
type = ChangeState
value = 651
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
