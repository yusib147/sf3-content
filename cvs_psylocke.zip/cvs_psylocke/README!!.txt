                            ____________________________
===========================|    CVS Psylocke by "tJ"    |==========================
                           |                            |
                           |(malcolmlee1988@hotmail.com)|
                            ����������������������������          
                              Dedicated to "Warusaki3"

Name - Capcom Vs SNK Psylocke

Release Date - 04/04/2010

Version - 1.0

WINMUGEN  only


~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Updates
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[18/04/2010]

Solved Lagging/Slow down problems =D

Changed the sounds to match certain animations

Adjusted timing on super pause animation for supers

Modified the collision boxes for "Maelstrom" super

Replaced some missing sprites in certain animations

Fixed infinite juggling with basic attacks.

---------------------------------------------------------------------------------------------

### Minor Issues ###

Lagging during exexution of Level 3 supers. This is due to too many sprites in the sff.

As a result, I could not include the slash hit sparks for the supers as it worsens the lag.

+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +


### What is not done ###

*** I have not included her super "Kochou Gakure" due to the inavailability of suitable butterfly fx
    (and partly due to my lousy coding skills >.<)
    I might probably include it in the next update (upon demand).
    Instead, I have given her an alternative super.


++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


------------------------------------___________________------------------------------------
-----------------------------------|                   |-----------------------------------
-----------------------------------|      CREDITS      |-----------------------------------
-----------------------------------|___________________|-----------------------------------


Hey guys, I hope that you had fun playing with CVS Poison (my previous character) :)


It's about time I release another CVS character. 


This time, CVS Psylocke is here to kick ass!!


Firstly, I would like to express my appreciation towards these people who contributed so much help in my project.


Without them, there would not be a CVS Psylocke.


Special thanks goes to :


Warusaki3 : I used one of his CVS characters as base for CVS Psylocke.


            This character, CVS Psylocke is dedicated to Warusaki3 for being the best MUGEN creator =D


            Many thanks to Warusaki3 for your contributions to MUGEN.


H" : For being such an awesome CVS creator. I just love your CVS characters very much.
     

Cray/Sabaki : I used Psylocke's sprites from his character (his works are open source)


Jesuszilla : For pointing out the mistakes I have made and help me improve.


Rain : For your help especially on feedback and advice which were very useful


My brother, TY : Thanks for beta testing CVS Psylocke.


Capcom : For the introduction and creation of the game Marvel vs Capcom (series) and the character Psylocke


Elecbyte : For designing such a cool MUGEN engine. Without it, there would be no characters and no CVS Psylocke at all.


Everyone in the MUGEN community from MugenGuild and Mugen Infantry for all your feedback & support :p


And finally, YOU for downloading this character :)


Enjoy~


===============| Movelist |===============


| X | Y | Z |
|   |   |   |
--------------
| A | B | C |
|   |   |   |


x = Weak Punch

y = Medium Punch

z = Strong Punch

a = Weak Kick

b = Medium Kick

c = Strong Kick

U = Up

D = Down

F = Forward

B = Back

S = Taunt.

----------<<<<< Miscelaneous >>>>>-----------

- Run = F, F (can hold)

- Back Dash = B, B (can hold)

- Dodge = a + x

- Dodge Attack = any p or k (during Dodge)

- Forward Roll = F + a + x

- Parry (can also be done in the air, and during guard):

    - F (tap) -> high attacks

    - D (tap) -> low attacks

- Just Defense = B or DB (just before getting hit)

- Power Charge = c + z (can hold)

- Power Stock = b + y

- Custom Combo = c + z (during full meter) (can be done in air)

- Counter = any MP or MK (while guarding) 

- Safe Fall = a + x (after getting hit by knock-down)


--------
*THROWS 
--------

���  HELL RIDE
        F + Z (near opponent)

Psylocke grabs the opponent, rolls the opponent and then tosses him/her to the corner.


���  TOSS UP
        F + c (near opponent)

Posylocke grabs the opponent, and then tosses him/her up vertically in the air. 


------------
*AIR THROWS 
------------

���  REVOLVER
        F + Z (near opponent)

Psylocke grabs the opponent, rolls together with the opponent to the ground and then tosses him/her to the corner.


------------------------------------------
*UNIQUE MOVES
------------------------------------------

���  HEEL DROP
        F + B

Psylocke hops and lands a downward kick, heel first on the opponent. Cannot be blocked low.

 
���  VANITY FLIP
        F, DF + C

Psylocke does a 2-hit flip kick on the opponent and then propels herself backward to safety.


���  MOONSAULT KICK
        U + C (in air)

Psylocke does an aerial 2-hit flip kick on the opponent.



------------------------------------------
*SPECIAL MOVES
------------------------------------------

���  PSI-BLAST 	 
        D, DF, F + X or Y or Z

Projectile move - Psylocke fires a blast of psychic energy in the form of a butterfly shaped projectile.
                  The direction and speed of the projectile depends on the button pressed.

                  X - Projectile will travel downwards at a 45� angle. Speed = Slow
                  Y - Projectile will travel horizontally.             Speed = Medium
                  Z - Projectile will travel upwards at a 45� angle.   Speed = Fast

���  AERIAL PSI-BLAST 	 
        D, DF, F + X or Y or Z (in air)

Aerial Projectile move - Psylocke fires a blast of psychic energy in the form of a butterfly shaped projectile.
                         All versions travel at a 45� angle downwards.
                         The speed of the projectile depends on the button pressed.

                         X - Projectile will travel at a Slow speed
                         Y - Projectile will travel at a Medium speed
                         Z - Projectile will travel at a Fast speed

���  PSi-BLADE   	
        D, DF, F + A or B or C

Anti-aerial move  -  Psylocke spins herself and performs a multi-hitting uppercut move with great vertical range. 
                     The amount of hits and distance travelled above the ground depends on the button pressed.
                     (The stronger the button, the higher she travels)

                  X - Projectile will jump slightly above the ground.  Hits = 2
                  Y - Projectile will jump high above the grould.      Hits = 4     
                  Z - Projectile will jump very high above the ground. Hits = 6

���  PSI-DRILL  	 
        D, DB, B + X or Y or Z

Self-Projectile move - Psylocke projects herself horizontally with her fists charged with psychic blade.
                       The direction travelled depends on the button pressed.
                       (The stronger the button, the further she travels forward)

���  NINJUTSU 	
        D, D + X or Y or Z or A or B or C

Teleport move - Psylocke teleports to different positions around the opponent.
                The position of reappearance depends on the button pressed.

                X - teleports her to the top left of the screen.
                Y - teleports her to the top middle of the screen.
                Z - teleports her to the top right of the screen.
                A - teleports her to the bottom left of the screen.
                B - teleports her to the bottom middle of the screen.
                C - teleports her to the bottom right of the screen.


��� AERIAL PSI-DRILL
        D, DB, B + X or Y or Z (after performing Ninjutsu : D, D + X or Y or Z)

Aerial move - Can onle be done after performing Ninjutsu and reappearing in the air.
              Psylocke thrusts herself in at a 45� downwards and performs a Psi-Drill.


-------------------------------------------------------------------
*HYPER MOVES (Level 3 & MAX Only)
-------------------------------------------------------------------

���  PSI-ASTRAL
        ~ D, DB, B, D, DB, + X or Y or Z 

Psylocke summons a rain of psi-butterflies which will shower upon the opponent.


-------------------------------------------------------------------
*SUPER MOVES
-------------------------------------------------------------------

���  PSI-THRUST
        D, DF, F, D, DF + X or Y or Z

Psylocke poses for a second  and then projects herself forward with her fists forward

and performs an enhanced version of psi-drill while being surrounded by psychic energy.


��� Psi-MAELSTROM
        D, DF, F, D, DF + A or B or C


Psylocke spins herself and performs an uppercut super with multiple hits which travels vertically. 

This move is similar to Ken's Shinryuken. Mash buttons for additional hits.


==========================================
CHARACTER PROFILE & BACKGROUND
==========================================

_._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._
Psylocke, a mutant with considerable telepathic powers, is a recurring character affiliated with the X-Men. 
Psylocke was originally a Marvel U.K. character for a 10 year run before joining the American Marvel cast.
_._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._


Real Name : Elizabeth Glorianna "Betsy" Braddock 

X-Men (Mutant) Name : Psylocke

Sex : Female

Birthdate : 23rd April 1982

Birthplace : Maldon, Essex, England, UK

Height : 5 feet 11 inches

Weight : 155 lbs

Occupation : Adventurer; former charter pilot, super model, government agent, assassin 

First appearance : CAPTAIN BRITAIN #8

Game appearance : "X-Men: Children of the Atom," "Marvel vs. Capcom 2" etc.

Affiliation : X-Men, The Hand (Ninja Clan)

Hair Color : Dyed Purple

Eye Color : Purple

Weapons : Psi-Blade

Abilities : Telepathy, Telekinesis, Teleportation, Speed and Agility, Immunity to all forms of psionic powers

Fighting Style : Martial Arts
 
                 Fighting Skills and Techniques that rival those of a Ninja Master  

                 Able to read opponents' movements, giving her the opportunity to counter-attack
 
                 Create telepathic illusions to distract her enemies while fighting them

                 Use telekinetic powers to augment her strength, speed and fighting skills

Weakness : Tom Lennox (Betsy's former lover) sacrificed himself to allow Captain Britain enough time to escape

           Kaptain Briton tried to rape Betsy, but in self-defence Betsy attacked him mentally and killed him.

Romance : Archangel

Quote : "Next time I suggest you try fighting back."


---------------------------------------------
--------------References---------------------
---------------------------------------------

http://www.comicvine.com/psylocke/29-3176/


/\/\/\/\/\/\/
 Disclaimer
/\/\/\/\/\/\/

Psylocke is a fictional character copyright and licence of comic books published by Marvel Comics

Psylocke, Marvel vs Capcom, Marvel Super Heroes and X-Men: Children of the Atom are all copyrighted properties of Capcom

No parts of this character can be used for commercial purposes.


#################################

                THE END

           ##################################

Thank you for your support~
  

     Hope you enjoy playing with this character!
             

                    Have a nice year ahead^^

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

With Regards,

 ~tJ~
