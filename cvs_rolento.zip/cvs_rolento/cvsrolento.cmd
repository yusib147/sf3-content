;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "�X�e�B�[�����C��1"
command = ~D, DF, F, D, DF, a
time = 21

[Command]
name = "�X�e�B�[�����C��1"
command = ~D, DF, F, D, DF, ~a
time = 21

[Command]
name = "�X�e�B�[�����C��2"
command = ~D, DF, F, D, DF, b
time = 21

[Command]
name = "�X�e�B�[�����C��2"
command = ~D, DF, F, D, DF, ~b
time = 21

[Command]
name = "�X�e�B�[�����C��3"
command = ~D, DF, F, D, DF, c
time = 21

[Command]
name = "�X�e�B�[�����C��3"
command = ~D, DF, F, D, DF, ~c
time = 21

[Command]
name = "�e�C�N�m�[�v���Y�i�[1"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "�e�C�N�m�[�v���Y�i�[1"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "�e�C�N�m�[�v���Y�i�[2"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "�e�C�N�m�[�v���Y�i�[2"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "�e�C�N�m�[�v���Y�i�[3"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "�e�C�N�m�[�v���Y�i�[3"
command = ~D, DF, F, D, DF, ~z
time = 21

[Command]
name = "�}�C���X�C�[�p�[1"
command = ~D, DB, B, D, DB, x
time = 21

[Command]
name = "�}�C���X�C�[�p�[1"
command = ~D, DB, B, D, DB, ~x
time = 21

[Command]
name = "�}�C���X�C�[�p�[2"
command = ~D, DB, B, D, DB, y
time = 21

[Command]
name = "�}�C���X�C�[�p�[2"
command = ~D, DB, B, D, DB, ~y
time = 21

[Command]
name = "�}�C���X�C�[�p�[3"
command = ~D, DB, B, D, DB, z
time = 21

[Command]
name = "�}�C���X�C�[�p�[3"
command = ~D, DB, B, D, DB, ~z
time = 21

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "�X�e�B���K�[1"
command = ~F, D, DF, a
time = 12

[Command]
name = "�X�e�B���K�[1"
command = ~F, D, DF, ~a
time = 12

[Command]
name = "�X�e�B���K�[2"
command = ~F, D, DF, b
time = 12

[Command]
name = "�X�e�B���K�[2"
command = ~F, D, DF, ~b
time = 12

[Command]
name = "�X�e�B���K�[3"
command = ~F, D, DF, c
time = 12

[Command]
name = "�X�e�B���K�[3"
command = ~F, D, DF, ~c
time = 12

[Command]
name = "�p�g���I�b�g�T�[�N��1"
command = ~D, DF, F, x
time = 12

[Command]
name = "�p�g���I�b�g�T�[�N��1"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "�p�g���I�b�g�T�[�N��2"
command = ~D, DF, F, y
time = 12

[Command]
name = "�p�g���I�b�g�T�[�N��2"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "�p�g���I�b�g�T�[�N��3"
command = ~D, DF, F, z
time = 12

[Command]
name = "�p�g���I�b�g�T�[�N��3"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "���R���f���^�G�A���C�h1"
command = ~D, DB, B, x
time = 12

[Command]
name = "���R���f���^�G�A���C�h1"
command = ~D, DB, B, ~x
time = 12

[Command]
name = "���R���f���^�G�A���C�h2"
command = ~D, DB, B, y
time = 12

[Command]
name = "���R���f���^�G�A���C�h2"
command = ~D, DB, B, ~y
time = 12

[Command]
name = "���R���f���^�G�A���C�h3"
command = ~D, DB, B, z
time = 12

[Command]
name = "���R���f���^�G�A���C�h3"
command = ~D, DB, B, ~z
time = 12

[Command]
name = "���R���f���^�G�X�P�C�v"
command = ~D, DB, B, a
time = 12

[Command]
name = "���R���f���^�G�X�P�C�v"
command = ~D, DB, B, ~a
time = 12

[Command]
name = "���R���f���^�G�X�P�C�v"
command = ~D, DB, B, b
time = 12

[Command]
name = "���R���f���^�G�X�P�C�v"
command = ~D, DB, B, ~b
time = 12

[Command]
name = "���R���f���^�G�X�P�C�v"
command = ~D, DB, B, c
time = 12

[Command]
name = "���R���f���^�G�X�P�C�v"
command = ~D, DB, B, ~c
time = 12

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 18

[Command]
name = "FF"     
command = F, F
time = 12

[Command]
name = "BB"     
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

[Command]
name = "���R���f���^�A�^�b�N"
command = x+y
time = 10

[Command]
name = "���R���f���^�A�^�b�N"
command = y+z
time = 10

[Command]
name = "���R���f���^�A�^�b�N"
command = z+x
time = 10

[Command]
name = "�X�J�E�^�[�W�����v"
command = a+b
time = 10

[Command]
name = "�X�J�E�^�[�W�����v"
command = b+c
time = 10

[Command]
name = "�X�J�E�^�[�W�����v"
command = c+a
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;---------------------------------------------------------------------------
;�X�e�B�[�����C��
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�X�e�B�[�����C��1" || Command = "�X�e�B�[�����C��2" || Command = "�X�e�B�[�����C��3"
triggerall = !NumProj
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 410 && (var(16) || time <= 2)
trigger12 = StateNo = 420 && (var(16) || time <= 2)
trigger13 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || time <= 2)
trigger16 = StateNo = 195 && var(36) && var(16)
trigger17 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger18 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,2999]) && (var(20) = 2 || var(20) = 6)
trigger21 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger22 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 49
ignorehitpause = 0

;---------------------------------------------------------------------------
;�e�C�N�m�[�v���Y�i�[
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�e�C�N�m�[�v���Y�i�[1" || Command = "�e�C�N�m�[�v���Y�i�[2" || Command = "�e�C�N�m�[�v���Y�i�[3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 410 && (var(16) || time <= 2)
trigger12 = StateNo = 420 && (var(16) || time <= 2)
trigger13 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || time <= 2)
trigger16 = StateNo = 195 && var(36) && var(16)
trigger17 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger18 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,2999]) && (var(20) = 2 || var(20) = 6)
trigger21 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 49
trigger22 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0

;---------------------------------------------------------------------------
;�}�C���X�C�[�p�[
[State -1, hadouken]
type = changeState
value = 3100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�}�C���X�C�[�p�[1" || Command = "�}�C���X�C�[�p�[2" || Command = "�}�C���X�C�[�p�[3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 410 && (var(16) || time <= 2)
trigger12 = StateNo = 420 && (var(16) || time <= 2)
trigger13 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || time <= 2)
trigger16 = StateNo = 195 && var(36) && var(16)
trigger17 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger18 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger19 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger20 = (StateNo = [1000,2999]) && (var(20) = 2 || var(20) = 6)
trigger21 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger22 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�X�e�B���K�[
[State -1, hadouken]
type = ChangeState
value = 1500
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�X�e�B���K�[1" || Command = "�X�e�B���K�[2" || Command = "�X�e�B���K�[3"
triggerall = !NumProj
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0)) && prevstateno != 830
trigger6 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 410 && (var(16) || time <= 2)
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 195 && var(36) && var(16)
trigger18 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger19 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���R���f���^�G�A���C�h
[State -1, hadouken]
type = ChangeState
value = 1300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "���R���f���^�G�A���C�h1" || Command = "���R���f���^�G�A���C�h2" || Command = "���R���f���^�G�A���C�h3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0)) && prevstateno != 830
trigger6 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 410 && (var(16) || time <= 2)
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 195 && var(36) && var(16)
trigger18 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger19 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���R���f���^�G�X�P�C�v
[State -1, hadouken]
type = ChangeState
value = 1400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "���R���f���^�G�X�P�C�v"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0)) && prevstateno != 830
trigger6 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 410 && (var(16) || time <= 2)
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 195 && var(36) && var(16)
trigger18 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger19 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�g���b�N���C�f�B���O
[State -1, hadouken]
type = ChangeState
value = 1600
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = Command = "�X�J�E�^�[�W�����v"
triggerall = statetype = A
triggerall = Pos Y >= -30
triggerall = Vel Y > 0
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger8 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger9 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger10 = stateno = 1401 && AnimElemTime(3) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p�g���I�b�g�T�[�N��
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�p�g���I�b�g�T�[�N��1" || Command = "�p�g���I�b�g�T�[�N��2" || Command = "�p�g���I�b�g�T�[�N��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0)) && prevstateno != 830
trigger6 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 410 && (var(16) || time <= 2)
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 195 && var(36) && var(16)
trigger18 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger19 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�X�J�E�^�[�W�����v
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�X�J�E�^�[�W�����v"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0)) && prevstateno != 830
trigger6 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 410 && (var(16) || time <= 2)
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 195 && var(36) && var(16)
trigger18 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger19 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���R���f���^�A�^�b�N
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "���R���f���^�A�^�b�N"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0)) && prevstateno != 830
trigger6 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 410 && (var(16) || time <= 2)
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 195 && var(36) && var(16)
trigger18 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger19 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = !NumProj
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 220 && (var(16) || time <= 2)
trigger5 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0)) && prevstateno != 830
trigger6 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2)) && prevstateno = 830
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 250 && (var(16) || time <= 2)
trigger11 = StateNo = 400 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 410 && (var(16) || time <= 2)
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 195 && var(36) && var(16)
trigger18 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger19 = (StateNo = [3100,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5200
triggerall = !var(59)
triggerall = !(var(0)&2**10)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 241 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 400 && time <= 2
trigger11 = StateNo = 410 && time <= 2
trigger12 = StateNo = 420 && time <= 2
trigger13 = StateNo = 430 && time <= 2
trigger14 = StateNo = 440 && time <= 2
trigger15 = StateNo = 450 && time <= 2
trigger16 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger17 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 241 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 400 && time <= 2
trigger11 = StateNo = 410 && time <= 2
trigger12 = StateNo = 420 && time <= 2
trigger13 = StateNo = 430 && time <= 2
trigger14 = StateNo = 440 && time <= 2
trigger15 = StateNo = 450 && time <= 2
trigger16 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger17 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 241 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 400 && time <= 2
trigger11 = StateNo = 410 && time <= 2
trigger12 = StateNo = 420 && time <= 2
trigger13 = StateNo = 430 && time <= 2
trigger14 = StateNo = 440 && time <= 2
trigger15 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 241 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 400 && time <= 2
trigger11 = StateNo = 410 && time <= 2
trigger12 = StateNo = 420 && time <= 2
trigger13 = StateNo = 430 && time <= 2
trigger14 = StateNo = 440 && time <= 2
trigger15 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 220 && time <= 2
trigger5 = StateNo = 221 && time <= 2
trigger6 = StateNo = 230 && time <= 2
trigger7 = StateNo = 240 && time <= 2
trigger8 = StateNo = 241 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 400 && time <= 2
trigger11 = StateNo = 410 && time <= 2
trigger12 = StateNo = 420 && time <= 2
trigger13 = StateNo = 430 && time <= 2
trigger14 = StateNo = 440 && time <= 2
trigger15 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time <= 2
trigger3 = StateNo = 610 && time <= 2
trigger4 = StateNo = 620 && time <= 2
trigger5 = StateNo = 630 && time <= 2
trigger6 = StateNo = 640 && time <= 2
trigger7 = StateNo = 650 && time <= 2
trigger8 = StateNo = 300 && time <= 2
trigger9 = StateNo = 700 && time <= 2

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;�t�F�C�N���b�h
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�X�p�C�N���b�h
[State -1, Taunt]
type = ChangeState
value = 700
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 1401 && AnimElemTime(3) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 1401 && AnimElemTime(3) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 1401 && AnimElemTime(3) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 1401 && AnimElemTime(3) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 1401 && AnimElemTime(3) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 1401 && AnimElemTime(3) > 0
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = stateno = 1401 && AnimElemTime(3) > 0
ignorehitpause = 0

;---------------------------------------------------------------------------
