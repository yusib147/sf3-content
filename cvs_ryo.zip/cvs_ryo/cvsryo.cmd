;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

[Command]
name = "CPU31"
command = U, D, F, U, D
time = 1

[Command]
name = "CPU32"
command = U, B, F, U, D
time = 1

[Command]
name = "CPU33"
command = U, D, D, U, D
time = 1

[Command]
name = "CPU34"
command = F, B, U, U, D
time = 1

[Command]
name = "CPU35"
command = U, F, U, B, U, D
time = 1

[Command]
name = "CPU36"
command = U, D, B, U, D
time = 1

[Command]
name = "CPU37"
command = F, F, B, U, D
time = 1

[Command]
name = "CPU38"
command = U, D, U, U, D
time = 1

[Command]
name = "CPU39"
command = F, B, B, U, D
time = 1

[Command]
name = "CPU40"
command = F, F, B, B, U, D
time = 1

[Command]
name = "CPU41"
command = U, U, F, U, D
time = 1

[Command]
name = "CPU42"
command = U, B, B, U, D
time = 1

[Command]
name = "CPU43"
command = U, B, F, F, U, D
time = 1

[Command]
name = "CPU44"
command = U, F, B, U, U, D
time = 1

[Command]
name = "CPU45"
command = U, B, F, U, U, D
time = 1

[Command]
name = "CPU46"
command = U, B, B, B, U, D
time = 1

[Command]
name = "CPU47"
command = U, D, B, F, U, D
time = 1

[Command]
name = "CPU48"
command = U, D, B, D, U, D
time = 1

[Command]
name = "CPU49"
command = U, D, F, U, U, D
time = 1

[Command]
name = "CPU50"
command = U, D, U, B, U, D
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "���՗���1"
command = ~D, DF, F, DF, D, DB, B, x
time = 25

[Command]
name = "���՗���1"
command = ~D, DF, F, DF, D, DB, B, ~x
time = 25

[Command]
name = "���՗���2"
command = ~D, DF, F, DF, D, DB, B, y
time = 25

[Command]
name = "���՗���2"
command = ~D, DF, F, DF, D, DB, B, ~y
time = 25

[Command]
name = "���՗���3"
command = ~D, DF, F, DF, D, DB, B, z
time = 25

[Command]
name = "���՗���3"
command = ~D, DF, F, DF, D, DB, B, ~z
time = 25

[Command]
name = "�e���ęጝ1"
command = ~F, B, DB, D, DF, F, x
time = 21

[Command]
name = "�e���ęጝ1"
command = ~F, B, DB, D, DF, F, ~x
time = 21

[Command]
name = "�e���ęጝ2"
command = ~F, B, DB, D, DF, F, y
time = 21

[Command]
name = "�e���ęጝ2"
command = ~F, B, DB, D, DF, F, ~y
time = 21

[Command]
name = "�e���ęጝ3"
command = ~F, B, DB, D, DF, F, z
time = 21

[Command]
name = "�e���ęጝ3"
command = ~F, B, DB, D, DF, F, ~z
time = 21

[Command]
name = "�V�n�e����"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "�V�n�e����"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "�V�n�e����"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "�V�n�e����"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "�V�n�e����"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "�V�n�e����"
command = ~D, DF, F, D, DF, ~z
time = 21

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "������1"
command = ~D, DF, F, x
time = 12

[Command]
name = "������1"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "������2"
command = ~D, DF, F, y
time = 12

[Command]
name = "������2"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "������3"
command = ~D, DF, F, z
time = 12

[Command]
name = "������3"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "�ՖC1"
command = ~F, D, DF, x
time = 12

[Command]
name = "�ՖC1"
command = ~F, D, DF, ~x
time = 12

[Command]
name = "�ՖC2"
command = ~F, D, DF, y
time = 12

[Command]
name = "�ՖC2"
command = ~F, D, DF, ~y
time = 12

[Command]
name = "�ՖC3"
command = ~F, D, DF, z
time = 12

[Command]
name = "�ՖC3"
command = ~F, D, DF, ~z
time = 12

[Command]
name = "�Ɍ����A����1"
command = ~F, DF, D, DB, B, x
time = 18

[Command]
name = "�Ɍ����A����1"
command = ~F, DF, D, DB, B, ~x
time = 18

[Command]
name = "�Ɍ����A����2"
command = ~F, DF, D, DB, B, y
time = 18

[Command]
name = "�Ɍ����A����2"
command = ~F, DF, D, DB, B, ~y
time = 18

[Command]
name = "�Ɍ����A����3"
command = ~F, DF, D, DB, B, z
time = 18

[Command]
name = "�Ɍ����A����3"
command = ~F, DF, D, DB, B, ~z
time = 18

[Command]
name = "�Ҍ՗��_��1"
command = ~B, D, DB, x
time = 12

[Command]
name = "�Ҍ՗��_��1"
command = ~B, D, DB, ~x
time = 12

[Command]
name = "�Ҍ՗��_��2"
command = ~B, D, DB, y
time = 12

[Command]
name = "�Ҍ՗��_��2"
command = ~B, D, DB, ~y
time = 12

[Command]
name = "�Ҍ՗��_��3"
command = ~B, D, DB, z
time = 12

[Command]
name = "�Ҍ՗��_��3"
command = ~B, D, DB, ~z
time = 12

[Command]
name = "�b��1"
command = ~F, B, F, x
time = 15

[Command]
name = "�b��1"
command = ~F, B, F, ~x
time = 15

[Command]
name = "�b��2"
command = ~F, B, F, y
time = 15

[Command]
name = "�b��2"
command = ~F, B, F, ~y
time = 15

[Command]
name = "�b��3"
command = ~F, B, F, z
time = 15

[Command]
name = "�b��3"
command = ~F, B, F, ~z
time = 15

[Command]
name = "�򉍎����r1"
command = ~45DB, F, a
time = 12

[Command]
name = "�򉍎����r1"
command = ~45DB, F, ~a
time = 12

[Command]
name = "�򉍎����r2"
command = ~45DB, F, b
time = 12

[Command]
name = "�򉍎����r2"
command = ~45DB, F, ~b
time = 12

[Command]
name = "�򉍎����r3"
command = ~45DB, F, c
time = 12

[Command]
name = "�򉍎����r3"
command = ~45DB, F, ~c
time = 12

[Command]
name = "�򉍎����r4"
command = ~DB, F, a
time = 12

[Command]
name = "�򉍎����r4"
command = ~DB, F, ~a
time = 12

[Command]
name = "�򉍎����r5"
command = ~DB, F, b
time = 12

[Command]
name = "�򉍎����r5"
command = ~DB, F, ~b
time = 12

[Command]
name = "�򉍎����r6"
command = ~DB, F, c
time = 12

[Command]
name = "�򉍎����r6"
command = ~DB, F, ~c
time = 12

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 10

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;AI�p

;AI
[State -1, AI]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
trigger31  = command = "CPU31"
trigger32  = command = "CPU32"
trigger33  = command = "CPU33"
trigger34  = command = "CPU34"
trigger35  = command = "CPU35"
trigger36  = command = "CPU36"
trigger37  = command = "CPU37"
trigger38  = command = "CPU38"
trigger39  = command = "CPU39"
trigger40  = command = "CPU40"
trigger41  = command = "CPU41"
trigger42  = command = "CPU42"
trigger43  = command = "CPU43"
trigger44  = command = "CPU44"
trigger45  = command = "CPU45"
trigger46  = command = "CPU46"
trigger47  = command = "CPU47"
trigger48  = command = "CPU48"
trigger49  = command = "CPU49"
trigger50  = command = "CPU50"
var(59) = 1

;===========================================================================
;---------------------------------------------------------------------------
;�W�����v
[State -1, Jump]
type = ChangeState
value = 40
triggerall = Var(59) = 1 && StateType != A && enemynear,MoveType != H && Ctrl
trigger1 = abs(enemynear,Pos X - Pos X) <= 120 && Random <= 150-((var(20)=[0,1])*100)
trigger2 = abs(enemynear,Pos X - Pos X) >= 200 && Ctrl && Random <= 30

;---------------------------------------------------------------------------
;��g�i�󒆁j
[State -1]
type = ChangeState
value = 5210
triggerall = Var(59) = 1
triggerall = Alive
triggerall = CanRecover
triggerall = Vel Y > -1
triggerall = Pos Y >= -40
triggerall = StateNo = 5050
trigger1 = random = [150,200]

;---------------------------------------------------------------------------
;��g�i�n��j
[State -1]
type = ChangeState
value = 5200
triggerall = var(59) = 1
triggerall = ((var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6) && !(var(0)&2**10)) || CanRecover
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = random <= 400

;---------------------------------------------------------------------------
;�W�����v�i��������j
[state -1, Guard]
type = ChangeState
value = 40
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist || P2bodydist X = [-60,120]
triggerall = ctrl || stateno = 21
triggerall = statetype != A
trigger1 = enemynear,HitDefAttr = SC, NT,ST,HT
	trigger1 = random = [0,700]

;===========================================================================
;---------------------------------------------------------------------------
;���՗���
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A
triggerall = enemynear,statetype != L
trigger1 = (abs(enemynear,Pos X - Pos X)= [30,160]) && enemynear,MoveType = A && enemynear,StateType != A && (Random = [570,600])
trigger1 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (abs(enemynear,Pos X - Pos X)= [30,160]) && enemynear,MoveType = A && (abs(enemynear,Pos Y - Pos Y) = [10,40]) && enemynear,vel Y >= 0 && Random <= 600
trigger2 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = (StateNo = 200 || StateNo = 201 || StateNo = 230 || StateNo = 231 || stateno = 400 || stateno = 430) && var(36) = 1 && Random <= 900 && (abs(enemynear,Pos X - Pos X)= [70,120]) && enemynear,statetype != A && var(17) >= 2
trigger4 = (StateNo = 210 || StateNo = 211 || StateNo = 220 || StateNo = 410 || StateNo = 420 || StateNo = 440) && var(36) = 1 && Random <= 900-((var(17)<2)*800) && (abs(enemynear,Pos X - Pos X)= [70,130]) && enemynear,statetype != A
trigger5 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [0,80]) && ctrl && random%3=1
ignorehitpause = 0

;---------------------------------------------------------------------------
;�e���ęጝ
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1055) && !NumProjID(3005)
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A
triggerall = enemynear,statetype != L
trigger1 = (abs(enemynear,Pos X - Pos X)= [75,130]) && enemynear,MoveType = I && (abs(enemynear,Pos Y - Pos Y) = [0,30]) && Random >= 900 && enemynear,Vel Y >= 0
trigger1 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (abs(enemynear,Pos X - Pos X)= [75,130]) && enemynear,MoveType = A && (abs(enemynear,Pos Y - Pos Y) = [10,30]) && Random >= 600 && enemynear,Vel Y > 0
trigger2 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = (stateno = 210 || StateNo = 211 || stateno = 220 || stateno = 410 || StateNo = 420 || StateNo = 440) && var(36) = 1
trigger3 = (Random=[150+((var(17)<2)*700),950]) && (abs(enemynear,Pos X - Pos X) = [40,100]) && enemynear,statetype != A
trigger4 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [50,120]) && ctrl && random%4=3
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�ՖC
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear,statetype != L
trigger1 = (abs(enemynear,Pos X - Pos X) = [0,50]) && enemynear,MoveType = A && Random > 850 && enemynear,statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (abs(enemynear,Pos X - Pos X) = [0,50]) && enemynear,MoveType = A && Random > 500 && enemynear,statetype = A && (abs(enemynear,Pos Y - Pos Y) = [5,30])
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = (abs(enemynear,Pos X - Pos X) = [0,50]) && Random > 600 && enemynear,statetype != A
trigger3 = stateno = 52 && anim = 57 && time >= 2 && var(17) >= 1
trigger4 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [0,40]) && ctrl && random%4=1
ignorehitpause = 0

;---------------------------------------------------------------------------
;�򉍎����r
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = C
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != A
trigger1 = StateNo = 420 && var(36) = 1 && (abs(enemynear,Pos X - Pos X)= [30,90]) && var(17) >= 2 && enemynear,statetype != A
trigger2 = abs(enemynear,Pos X - Pos X) > 200 && (Random = [800,810]) && ctrl
ignorehitpause = 0

;---------------------------------------------------------------------------
;�Ɍ����A����
[State -1, reppuken]
type = ChangeState
value = 1400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !enemynear,numproj
trigger1 = StateNo = 211 && (var(36)=1||var(36)=2) && (abs(enemynear,Pos X - Pos X)= [40,60]) && (random = [100,400])
trigger2 = abs(enemynear,Pos X - Pos X) > 150 && (Random = [700,730]) && enemynear,MoveType != A && enemynear,statetype != A
trigger2 = (!var(20) || var(20) = 1 || var(20) = 2 || var(20) = 4 || var(20) = 6) && power < 3000 && !var(14) && ctrl
trigger3 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [0,40]) && ctrl && random%4=2
ignorehitpause = 0

;---------------------------------------------------------------------------
;�b��
[State -1, reppuken]
type = ChangeState
value = 1300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !enemynear,numproj
triggerall = enemynear,statetype != L
trigger1 = StateNo = 211 && var(36) = 1 && (abs(enemynear,Pos X - Pos X)= [0,30]) && (random = [500,800]) && enemynear,statetype != A
trigger2 = abs(enemynear,Pos X - Pos X) > 120 && (Random = [500,510]) && enemynear,MoveType != A && ctrl
trigger3 = (prevstateno = [4000,4199]) && (abs(enemynear,Pos X - Pos X) = [0,50]) && ctrl && random%6=5
ignorehitpause = 0

;---------------------------------------------------------------------------
;������
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1055) && !NumProjID(3005)
triggerall = statetype != A
trigger1 = abs(enemynear,Pos X - Pos X) > 140 && (Random = [850,900]) && enemynear,MoveType != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = (StateNo = 410 || StateNo = 420 || StateNo = 440) && var(36) = 1 && (abs(enemynear,Pos X - Pos X)= [60,90]) && Random <= 800
trigger3 = (StateNo = 410 || StateNo = 420 || StateNo = 440) && var(36) = 2 && (abs(enemynear,Pos X - Pos X)= [60,110]) && Random <= 800
trigger4 = StateNo = 211 && var(36) = 2 && (abs(enemynear,Pos X - Pos X)= [60,100]) && Random <= 800
ignorehitpause = 0

;---------------------------------------------------------------------------
;�󒆌�����
[State -1, hadouken]
type = ChangeState
value = 1050
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1055) && !NumProjID(3005)
triggerall = statetype = A
triggerall = enemynear,statetype != L
trigger1 = Ctrl && Random <= 80 && Vel X > 0 && vel Y = [-2,4]
trigger2 = Ctrl && Random <= 120 && Vel X = 0 && vel Y = [-3,3]
trigger3 = Ctrl && Random <= 50 && Vel X < 0 && vel Y = [-5,2]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�Ҍ՗��_��
[State -1, hadouken]
type = ChangeState
value = 1500
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear,statetype != L
trigger1 = (abs(enemynear,Pos X - Pos X) = [90,240]) && (Random = [820,840]) && enemynear,MoveType = I
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = roundstate = 2
triggerall = var(59) = 1
triggerall = var(1) != [1,2]
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = (Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)) || (Power >= 1500 && var(20) = 1) || (var(14) && var(20) = 3)
triggerall = enemynear,statetype != L
trigger1 = abs(enemynear,Pos X - Pos X) <= 50 && Random <= 20

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
;[State -1]
;type = ChangeState
;value = 810
;triggerall = var(59) = 1
;triggerall = var(20) = 4 || var(20) = 6
;triggerall = Power >= 1000
;triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
;triggerall = enemynear,statetype != L
;trigger1 = abs(enemynear,Pos X - Pos X)<= 50 && Random <= 50

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
;[State -1]
;type = ChangeState
;value = 820
;triggerall = var(59) = 1
;triggerall = var(20) = 4 || var(20) = 6
;triggerall = Power >= 1000
;triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
;triggerall = enemynear,statetype != L
;trigger1 = abs(enemynear,Pos X - Pos X)<= 50 && Random <= 20

;---------------------------------------------------------------------------
;����
;[State -1, Taunt]
;type = ChangeState
;value = 195
;triggerall = var(59) = 1
;triggerall = statetype != A
;triggerall = enemynear,statetype != L

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !var(20) || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = PrevStateNo != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = (abs(enemynear,Pos X - Pos X) >= 100) && Random <= 60
trigger2 = (abs(enemynear,Pos X - Pos X) <= 180 && enemynear,MoveType != A && enemynear,MoveType != H) && (Random = [240,270])
trigger3 = (abs(enemynear,Pos X - Pos X) <= 180 && enemynear,MoveType = A) && (Random = [430,460])
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A
triggerall = PrevStateNo != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = (abs(enemynear,Pos X - Pos X) <= 70 && enemynear,MoveType != A && enemynear,MoveType != H) && Random <= 50
trigger2 = (abs(enemynear,Pos X - Pos X) <= 70 && enemynear,MoveType = A) && Random <= 120
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = ctrl
triggerall = (power < 1000 && var(20) = 3 && !var(14)) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = !enemynear,numproj
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = (abs(enemynear,Pos X - Pos X) >= 140) && (Random = [700,860])
trigger2 = (abs(enemynear,Pos X - Pos X) >= 140) && (Random = [300,500]) && enemynear,statetype = L
trigger2 = teammode = single

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = (abs(enemynear,Pos X - Pos X) >= 100) && Random <= 450
trigger2 = Random <= 650 && enemynear,statetype = L

;---------------------------------------------------------------------------
;�I���R�������i�n��j
;[State -1]
;type = ChangeState
;value = 870
;triggerall = var(59) = 1
;triggerall = var(20) = 1 || var(20) = 6
;triggerall = !var(15) && !var(16)
;triggerall = roundstate = 2
;triggerall = statetype != A
;trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1)

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
;[State -1]
;type = ChangeState
;value = 875
;triggerall = var(59) = 1
;triggerall = !(var(0)&2**5)
;triggerall = var(20) = 1 || var(20) = 6
;triggerall = !var(15) && !var(16)
;triggerall = roundstate = 2
;trigger1 = statetype = A
;trigger1 = ctrl

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 1
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [6,22]
triggerall = enemynear,StateType = S || enemynear,StateType = C
triggerall = enemynear,MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
trigger1 = Random <= 200 && Ctrl

;---------------------------------------------------------------------------
;�X������
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = Ctrl && (Random = [100,180]) && enemynear,statetype = C && abs(enemynear,Pos X - Pos X) <= 50 && enemynear,statetype != A && enemynear,MoveType = I
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X > 25
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != C
trigger1 = ((abs(enemynear,Pos X - Pos X)= [30,75])) && (Random = [600,999]) && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (abs(enemynear,Pos X - Pos X) >= 120) && Ctrl && (Random = [900,970]) && enemynear,movetype != A
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != A
trigger1 = ((abs(enemynear,Pos X - Pos X)= [5,45])) && (Random = [500,850]) && enemynear,movetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X > 25
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != A
trigger1 = (abs(enemynear,Pos X - Pos X) = [30,85]) && (Random = [600,700]) && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = 200 || StateNo = 201 || StateNo = 231 || stateno = 400) && (var(36)=1||var(36)=2) && (Random = [350,400]) && enemynear,statetype != A && (abs(enemynear,Pos X - Pos X) = [40,85])

;---------------------------------------------------------------------------
;�ߋ���������L�b�N
[State -1, Taunt]
type = ChangeState
value = 231
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != A
trigger1 = (abs(enemynear,Pos X - Pos X) = [0,40]) && (Random = [850,950]) && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = 200 || StateNo = 201 || StateNo = 231 || stateno = 400) && (var(36)=1||var(36)=2) && (Random = [350,400]) && enemynear,statetype != A && (abs(enemynear,Pos X - Pos X) = [0,40])

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X > 25
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != A
trigger1 = (abs(enemynear,Pos X - Pos X)= [50,120]) && Random <= 100 && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != C
trigger1 = ((abs(enemynear,Pos X - Pos X)= [65,100])) && (Random = [800,900]) && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = enemynear,StateType = A && (abs(enemynear,Pos X - Pos X)= [75,120]) && abs(enemynear,Pos Y - Pos Y) <= 70 && Ctrl && enemynear,Vel X > 0 && (Random = [300,500]) && enemynear,movetype != H
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != A
trigger1 = (abs(enemynear,Pos X - Pos X) = [0,40]) && (Random = [650,800]) && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (abs(enemynear,Pos X - Pos X) >= 120) && Ctrl && (Random = [800,830]) && enemynear,movetype != A
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != A
trigger1 = (abs(enemynear,Pos X - Pos X)= [0,60]) && Random <= 350 && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear,statetype != L
trigger1 = ((abs(enemynear,Pos X - Pos X)= [0,50])) && (Random = [650,700]) && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = enemynear,MoveType = H && (abs(enemynear,Pos X - Pos X)= [30,50]) && (Random = [100,500]) && enemynear,statetype != A
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = StateNo = 430 && (var(36)=1||var(36)=2) && animtime = 0 && random <= 400 && enemynear,statetype != A && (abs(enemynear,Pos X - Pos X)= [0,50])
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != A
trigger1 = ((abs(enemynear,Pos X - Pos X)= [0,60])) && Random <= 150 && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = enemynear,MoveType = H && (abs(enemynear,Pos X - Pos X)= [0,50]) && (Random = [150,500])
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = (StateNo = 200 || StateNo = 201 || StateNo = 231 || StateNo = 400) && (var(36)=1||var(36)=2) && (Random = [300,800]) && enemynear,statetype != A && (abs(enemynear,Pos X - Pos X)= [0,60])
trigger4 = StateNo = 430 && (var(36)=1||var(36)=2) && animtime = 0 && random <= 700 && enemynear,statetype != A && (abs(enemynear,Pos X - Pos X)= [0,50])
trigger5 = (abs(enemynear,Pos X - Pos X) >= 120) && Ctrl && (Random = [850,880]) && enemynear,movetype != A
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear,statetype != L
triggerall = enemynear,statetype != A
trigger1 = ((abs(enemynear,Pos X - Pos X)= [15,90])) && (Random = [300,400]) && enemynear,movetype != H
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = enemynear,MoveType = H && (abs(enemynear,Pos X - Pos X)= [15,90]) && Ctrl && (Random = [500,750]) && enemynear,statetype != A
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = (StateNo = 200 || StateNo = 201 || StateNo = 231 || StateNo = 400 || StateNo = 430) && (var(36)=1||var(36)=2) && animtime = 0 && random <= 300 && enemynear,statetype != A && (abs(enemynear,Pos X - Pos X)= [40,80])
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemynear,statetype != L
trigger1 = (abs(enemynear,Pos X - Pos X)= [45,100]) && (Random = [120,200]) && enemynear,movetype != H && enemynear,statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = enemynear,StateType = A && (abs(enemynear,Pos X - Pos X)= [55,100]) && abs(enemynear,Pos Y - Pos Y) <= 30 && enemynear,Vel X > 0 && Random <= 350
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = enemynear,movetype != H
trigger1 = abs(enemynear,Pos X - Pos X) < 60 && (enemynear,Pos Y - Pos Y = [-40,-20]) && (Random = [0,300]) && time > 6 && Ctrl
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = (abs(enemynear,Pos X - Pos X) = [0,70]) && (enemynear,Pos Y - Pos Y = [-20,20]) && (Random = [101,500]) && time > 6 && Ctrl
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = !(var(0)&2**5)
triggerall = enemynear,movetype != H
trigger1 = abs(enemynear,Pos X - Pos X) < 100 && (enemynear,Pos Y - Pos Y = [5,25]) && (Random = [0,500]) && time > 6 && Ctrl
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = enemynear,movetype != H
trigger1 = (abs(enemynear,Pos X - Pos X)= [0,90]) && (enemynear,Pos Y - Pos Y = [10,30]) && (Random = [501,999]) && time > 6 && Ctrl
ignorehitpause = 0

;---------------------------------------------------------------------------
;�K�[�h
[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype != A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,300)*(1+(statetype!=A))

[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype = A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,400)*(1+(statetype!=A))

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(59) = 1
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = statetype != A
triggerall = enemynear,movetype != A
trigger1 = (abs(enemynear,Pos X - Pos X) = [100,240]) && Ctrl && (Random = [300,380])
trigger2 = abs(enemynear,Pos X - Pos X) > 240 && Ctrl && (Random = [340,440])

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = var(59) = 1
triggerall = !var(20) || var(20) = 1 || var(20) = 2
triggerall = statetype != A
triggerall = enemynear,movetype != A
trigger1 = abs(enemynear,Pos X - Pos X) >= 150 && Ctrl && (Random = [500,530])

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 1
triggerall = statetype != A
trigger1 = abs(enemynear,Pos X - Pos X) <= 120 && enemynear,MoveType != A && Ctrl && (Random = [830,900])
trigger2 = abs(enemynear,Pos X - Pos X) <= 70 && enemynear,statetype = L && Ctrl && (Random = [451,520])

;---------------------------------------------------------------------------
;����
[State -1, Walk]
type = ChangeState
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
triggerall = !InGuardDist
triggerall = stateno != [10,12]
triggerall = prevstateno != [10,12]
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != 21
triggerall = prevstateno != 21
triggerall = stateno != [120,159]
triggerall = prevstateno != [120,159]
triggerall = !(var(16) && numtarget)
trigger1 = random%10<=7

;===========================================================================
;---------------------------------------------------------------------------
;�V�n�e����
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = Command = "�V�n�e����"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger25 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger26 = (StateNo = [1000,1300]) && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 1301 && (var(20) = 2 || var(20) = 6) && animelemtime(17) > 0 && !var(5)
trigger28 = StateNo = 1301 && (var(20) = 2 || var(20) = 6) && animelemtime(29) > 0 && var(5) = 1
trigger29 = StateNo = 1301 && (var(20) = 2 || var(20) = 6) && animelemtime(41) > 0 && var(5) = 2
trigger30 = (StateNo = [1400,2999]) && (var(20) = 2 || var(20) = 6)
trigger31 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger32 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger33 = StateNo = 3101 && (var(20) = 2 || var(20) = 6)
trigger34 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�e���ęጝ
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = !NumProjID(1005) && !NumProjID(1055) && !NumProjID(3005)
triggerall = Command = "�e���ęጝ1" || Command = "�e���ęጝ2" || Command = "�e���ęጝ3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger25 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger26 = (StateNo = [1000,1300]) && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 1301 && (var(20) = 2 || var(20) = 6) && animelemtime(17) > 0 && !var(5)
trigger28 = StateNo = 1301 && (var(20) = 2 || var(20) = 6) && animelemtime(29) > 0 && var(5) = 1
trigger29 = StateNo = 1301 && (var(20) = 2 || var(20) = 6) && animelemtime(41) > 0 && var(5) = 2
trigger30 = (StateNo = [1400,2999]) && (var(20) = 2 || var(20) = 6)
trigger31 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger32 = StateNo = 3101 && (var(20) = 2 || var(20) = 6)
trigger33 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
trigger34 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger35 = StateNo = 3201 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���՗���
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "���՗���1" || Command = "���՗���2" || Command = "���՗���3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger25 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger26 = (StateNo = [1000,1300]) && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 1301 && (var(20) = 2 || var(20) = 6) && animelemtime(17) > 0 && !var(5)
trigger28 = StateNo = 1301 && (var(20) = 2 || var(20) = 6) && animelemtime(29) > 0 && var(5) = 1
trigger29 = StateNo = 1301 && (var(20) = 2 || var(20) = 6) && animelemtime(41) > 0 && var(5) = 2
trigger30 = (StateNo = [1400,2999]) && (var(20) = 2 || var(20) = 6)
trigger31 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger32 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger33 = StateNo = 3201 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�ՖC
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�ՖC1" || Command = "�ՖC2" || Command = "�ՖC3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1055) && !NumProjID(3005)
triggerall = Command = "������1" || Command = "������2" || Command = "������3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�󒆌�����
[State -1, hadouken]
type = ChangeState
value = 1050
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1055) && !NumProjID(3005)
triggerall = Command = "������1" || Command = "������2" || Command = "������3"
triggerall = statetype = A
triggerall = pos Y <= -20
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(10) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(11) < 0))
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger8 = StateNo = 195 && var(36) && var(16)
trigger9 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger10 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger11 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger12 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger13 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�Ҍ՗��_��
[State -1, hadouken]
type = ChangeState
value = 1500
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�Ҍ՗��_��1" || Command = "�Ҍ՗��_��2" || Command = "�Ҍ՗��_��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�b��
[State -1, hadouken]
type = ChangeState
value = 1300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�b��1" || Command = "�b��2" || Command = "�b��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�򉍎����r�i�ʏ�j
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = !var(16)
triggerall = roundstate = 2
triggerall = Command = "�򉍎����r1" || Command = "�򉍎����r2" || Command = "�򉍎����r3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && time <= 2
trigger10 = StateNo = 241 && time <= 2
trigger11 = StateNo = 250 && time <= 2
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger15 = StateNo = 430 && (time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && time <= 2
trigger18 = StateNo = 300 && time <= 2
trigger19 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�򉍎����r�i�I���R���j
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = var(16)
triggerall = roundstate = 2
triggerall = Command = "�򉍎����r4" || Command = "�򉍎����r5" || Command = "�򉍎����r6"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = [200,799]
trigger3 = StateNo = 195 && var(36)
trigger4 = (StateNo = [1000,1299]) && var(36)
trigger5 = StateNo = 1300 && (var(36) = [2,4])
trigger6 = StateNo = 1301 && var(36) && animelemtime(2) > 0
trigger7 = (StateNo = [1400,2999]) && var(36)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�Ɍ����A����
[State -1, hadouken]
type = ChangeState
value = 1400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�Ɍ����A����1" || Command = "�Ɍ����A����2" || Command = "�Ɍ����A����3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5200
triggerall = !var(59)
triggerall = !(var(0)&2**10)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2
trigger19 = (StateNo = [195,799]) && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2
trigger19 = (StateNo = [195,799]) && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time < 2
trigger3 = StateNo = 610 && time < 2
trigger4 = StateNo = 620 && time < 2
trigger5 = StateNo = 630 && time < 2
trigger6 = StateNo = 640 && time < 2
trigger7 = StateNo = 650 && time < 2

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)
trigger2 = numtarget
trigger2 = target,stateno = 3700

;---------------------------------------------------------------------------
;�X������
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ���������p���`
[State -1, Taunt]
type = ChangeState
value = 201
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ���������L�b�N
[State -1, Taunt]
type = ChangeState
value = 231
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
