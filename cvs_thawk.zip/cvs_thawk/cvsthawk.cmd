;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

[Command]
name = "CPU31"
command = U, D, F, U, D
time = 1

[Command]
name = "CPU32"
command = U, B, F, U, D
time = 1

[Command]
name = "CPU33"
command = U, D, D, U, D
time = 1

[Command]
name = "CPU34"
command = F, B, U, U, D
time = 1

[Command]
name = "CPU35"
command = U, F, U, B, U, D
time = 1

[Command]
name = "CPU36"
command = U, D, B, U, D
time = 1

[Command]
name = "CPU37"
command = F, F, B, U, D
time = 1

[Command]
name = "CPU38"
command = U, D, U, U, D
time = 1

[Command]
name = "CPU39"
command = F, B, B, U, D
time = 1

[Command]
name = "CPU40"
command = F, F, B, B, U, D
time = 1

[Command]
name = "CPU41"
command = U, U, F, U, D
time = 1

[Command]
name = "CPU42"
command = U, B, B, U, D
time = 1

[Command]
name = "CPU43"
command = U, B, F, F, U, D
time = 1

[Command]
name = "CPU44"
command = U, F, B, U, U, D
time = 1

[Command]
name = "CPU45"
command = U, B, F, U, U, D
time = 1

[Command]
name = "CPU46"
command = U, B, B, B, U, D
time = 1

[Command]
name = "CPU47"
command = U, D, B, F, U, D
time = 1

[Command]
name = "CPU48"
command = U, D, B, D, U, D
time = 1

[Command]
name = "CPU49"
command = U, D, F, U, U, D
time = 1

[Command]
name = "CPU50"
command = U, D, U, B, U, D
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "rtyphoon_x"
command = ~F, D, B, U, F, D, B, U, x
time = 40

[Command]
name = "rtyphoon_x"
command = ~F, D, B, U, F, D, B, U, ~x
time = 40

[Command]
name = "rtyphoon_x"
command = ~D, B, U, F, D, B, U, F, x
time = 40

[Command]
name = "rtyphoon_x"
command = ~D, B, U, F, D, B, U, F, ~x
time = 40

[Command]
name = "rtyphoon_x"
command = ~B, U, F, D, B, U, F, D, x
time = 40

[Command]
name = "rtyphoon_x"
command = ~B, U, F, D, B, U, F, D, ~x
time = 40

[Command]
name = "rtyphoon_x"
command = ~U, F, D, B, U, F, D, B, x
time = 40

[Command]
name = "rtyphoon_x"
command = ~U, F, D, B, U, F, D, B, ~x
time = 40

[Command]
name = "rtyphoon_x"
command = ~F, U, B, D, F, U, B, D, x
time = 40

[Command]
name = "rtyphoon_x"
command = ~F, U, B, D, F, U, B, D, ~x
time = 40

[Command]
name = "rtyphoon_x"
command = ~D, F, U, B, D, F, U, B, x
time = 60

[Command]
name = "rtyphoon_x"
command = ~D, F, U, B, D, F, U, B, ~x
time = 60

[Command]
name = "rtyphoon_x"
command = ~B, D, F, U, B, D, F, U, x
time = 60

[Command]
name = "rtyphoon_x"
command = ~B, D, F, U, B, D, F, U, ~x
time = 60

[Command]
name = "rtyphoon_x"
command = ~U, B, D, F, U, B, D, F, x
time = 60

[Command]
name = "rtyphoon_x"
command = ~U, B, D, F, U, B, D, F, ~x
time = 60

[Command]
name = "rtyphoon_x"
command = ~B, D, F, B, D, F, B, x
time = 60

[Command]
name = "rtyphoon_x"
command = ~B, D, F, B, D, F, B, ~x
time = 60

[Command]
name = "rtyphoon_x"
command = ~F, D, B, F, D, B, F, x
time = 60

[Command]
name = "rtyphoon_x"
command = ~F, D, B, F, D, B, F, ~x
time = 60

[Command]
name = "rtyphoon_y"
command = ~F, D, B, U, F, D, B, U, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~F, D, B, U, F, D, B, U, ~y
time = 60

[Command]
name = "rtyphoon_y"
command = ~D, B, U, F, D, B, U, F, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~D, B, U, F, D, B, U, F, ~y
time = 60

[Command]
name = "rtyphoon_y"
command = ~B, U, F, D, B, U, F, D, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~B, U, F, D, B, U, F, D, ~y
time = 60

[Command]
name = "rtyphoon_y"
command = ~U, F, D, B, U, F, D, B, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~U, F, D, B, U, F, D, B, ~y
time = 60

[Command]
name = "rtyphoon_y"
command = ~F, U, B, D, F, U, B, D, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~F, U, B, D, F, U, B, D, ~y
time = 60

[Command]
name = "rtyphoon_y"
command = ~D, F, U, B, D, F, U, B, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~D, F, U, B, D, F, U, B, ~y
time = 60

[Command]
name = "rtyphoon_y"
command = ~B, D, F, U, B, D, F, U, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~B, D, F, U, B, D, F, U, ~y
time = 60

[Command]
name = "rtyphoon_y"
command = ~U, B, D, F, U, B, D, F, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~U, B, D, F, U, B, D, F, ~y
time = 60

[Command]
name = "rtyphoon_y"
command = ~B, D, F, B, D, F, B, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~B, D, F, B, D, F, B, ~y
time = 60

[Command]
name = "rtyphoon_y"
command = ~F, D, B, F, D, B, F, y
time = 60

[Command]
name = "rtyphoon_y"
command = ~F, D, B, F, D, B, F, ~y
time = 60

[Command]
name = "rtyphoon_z"
command = ~F, D, B, U, F, D, B, U, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~F, D, B, U, F, D, B, U, ~z
time = 60

[Command]
name = "rtyphoon_z"
command = ~D, B, U, F, D, B, U, F, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~D, B, U, F, D, B, U, F, ~z
time = 60

[Command]
name = "rtyphoon_z"
command = ~B, U, F, D, B, U, F, D, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~B, U, F, D, B, U, F, D, ~z
time = 60

[Command]
name = "rtyphoon_z"
command = ~U, F, D, B, U, F, D, B, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~U, F, D, B, U, F, D, B, ~z
time = 60

[Command]
name = "rtyphoon_z"
command = ~F, U, B, D, F, U, B, D, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~F, U, B, D, F, U, B, D, ~z
time = 60

[Command]
name = "rtyphoon_z"
command = ~D, F, U, B, D, F, U, B, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~D, F, U, B, D, F, U, B, ~z
time = 60

[Command]
name = "rtyphoon_z"
command = ~B, D, F, U, B, D, F, U, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~B, D, F, U, B, D, F, U, ~z
time = 60

[Command]
name = "rtyphoon_z"
command = ~U, B, D, F, U, B, D, F, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~U, B, D, F, U, B, D, F, ~z
time = 60

[Command]
name = "rtyphoon_z"
command = ~B, D, F, B, D, F, B, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~B, D, F, B, D, F, B, ~z
time = 60

[Command]
name = "rtyphoon_z"
command = ~F, D, B, F, D, B, F, z
time = 60

[Command]
name = "rtyphoon_z"
command = ~F, D, B, F, D, B, F, ~z
time = 60

[Command]
name = "csplitter_x"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "csplitter_x"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "csplitter_y"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "csplitter_y"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "csplitter_z"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "csplitter_z"
command = ~D, DF, F, D, DF, ~z
time = 21

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "mtyphoon_x"
command = ~F, D, B, U, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~F, D, B, U, ~x
time = 40

[Command]
name = "mtyphoon_x"
command = ~D, B, U, F, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~D, B, U, F, ~x
time = 40

[Command]
name = "mtyphoon_x"
command = ~B, U, F, D, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~B, U, F, D, ~x
time = 40

[Command]
name = "mtyphoon_x"
command = ~U, F, D, B, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~U, F, D, B, ~x
time = 40

[Command]
name = "mtyphoon_x"
command = ~F, U, B, D, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~F, U, B, D, ~x
time = 40

[Command]
name = "mtyphoon_x"
command = ~D, F, U, B, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~D, F, U, B, ~x
time = 40

[Command]
name = "mtyphoon_x"
command = ~B, D, F, U, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~B, D, F, U, ~x
time = 40

[Command]
name = "mtyphoon_x"
command = ~U, B, D, F, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~U, B, D, F, ~x
time = 40

[Command]
name = "mtyphoon_x"
command = ~B, D, F, B, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~B, D, F, B, ~x
time = 40

[Command]
name = "mtyphoon_x"
command = ~F, D, B, F, x
time = 40

[Command]
name = "mtyphoon_x"
command = ~F, D, B, F, ~x
time = 40

[Command]
name = "mtyphoon_y"
command = ~F, D, B, U, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~F, D, B, U, ~y
time = 40

[Command]
name = "mtyphoon_y"
command = ~D, B, U, F, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~D, B, U, F, ~y
time = 40

[Command]
name = "mtyphoon_y"
command = ~B, U, F, D, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~B, U, F, D, ~y
time = 40

[Command]
name = "mtyphoon_y"
command = ~U, F, D, B, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~U, F, D, B, ~y
time = 40

[Command]
name = "mtyphoon_y"
command = ~F, U, B, D, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~F, U, B, D, ~y
time = 40

[Command]
name = "mtyphoon_y"
command = ~D, F, U, B, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~D, F, U, B, ~y
time = 40

[Command]
name = "mtyphoon_y"
command = ~B, D, F, U, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~B, D, F, U, ~y
time = 40

[Command]
name = "mtyphoon_y"
command = ~U, B, D, F, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~U, B, D, F, ~y
time = 40

[Command]
name = "mtyphoon_y"
command = ~B, D, F, B, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~B, D, F, B, ~y
time = 40

[Command]
name = "mtyphoon_y"
command = ~F, D, B, F, y
time = 40

[Command]
name = "mtyphoon_y"
command = ~F, D, B, F, ~y
time = 40

[Command]
name = "mtyphoon_z"
command = ~F, D, B, U, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~F, D, B, U, ~z
time = 40

[Command]
name = "mtyphoon_z"
command = ~D, B, U, F, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~D, B, U, F, ~z
time = 40

[Command]
name = "mtyphoon_z"
command = ~B, U, F, D, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~B, U, F, D, ~z
time = 40

[Command]
name = "mtyphoon_z"
command = ~U, F, D, B, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~U, F, D, B, ~z
time = 40

[Command]
name = "mtyphoon_z"
command = ~F, U, B, D, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~F, U, B, D, ~z
time = 40

[Command]
name = "mtyphoon_z"
command = ~D, F, U, B, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~D, F, U, B, ~z
time = 40

[Command]
name = "mtyphoon_z"
command = ~B, D, F, U, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~B, D, F, U, ~z
time = 40

[Command]
name = "mtyphoon_z"
command = ~U, B, D, F, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~U, B, D, F, ~z
time = 40

[Command]
name = "mtyphoon_z"
command = ~B, D, F, B, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~B, D, F, B, ~z
time = 40

[Command]
name = "mtyphoon_z"
command = ~F, D, B, F, z
time = 40

[Command]
name = "mtyphoon_z"
command = ~F, D, B, F, ~z
time = 40

[Command]
name = "cspire_x"
command = ~F, D, DF, ~x
time = 12

[Command]
name = "cspire_x"
command = ~F, D, DF, x
time = 12

[Command]
name = "cspire_y"
command = ~F, D, DF, y
time = 12

[Command]
name = "cspire_y"
command = ~F, D, DF, ~y
time = 12

[Command]
name = "cspire_z"
command = ~F, D, DF, z
time = 12

[Command]
name = "cspire_z"
command = ~F, D, DF, ~z
time = 12

[Command]
name = "tbuster_x"
command = ~B, D, DB, x
time = 12

[Command]
name = "tbuster_x"
command = ~B, D, DB, ~x
time = 12

[Command]
name = "tbuster_y"
command = ~B, D, DB, y
time = 12

[Command]
name = "tbuster_y"
command = ~B, D, DB, ~y
time = 12

[Command]
name = "tbuster_z"
command = ~B, D, DB, z
time = 12

[Command]
name = "tbuster_z"
command = ~B, D, DB, ~z
time = 12

[Command]
name = "cspiref_x"
command = ~B, D, DB, a
time = 15

[Command]
name = "cspiref_x"
command = ~B, D, DB, ~a
time = 15

[Command]
name = "cspiref_y"
command = ~B, D, DB, b
time = 15

[Command]
name = "cspiref_y"
command = ~B, D, DB, ~b
time = 15

[Command]
name = "cspiref_z"
command = ~B, D, DB, c
time = 15

[Command]
name = "cspiref_z"
command = ~B, D, DB, ~c
time = 15

[Command]
name = "condordive"
command = x+y
time = 10

[Command]
name = "condordive"
command = x+z
time = 10

[Command]
name = "condordive"
command = z+y
time = 10


;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 18

[Command]
name = "FF"     
command = F, F
time = 12

[Command]
name = "BB"     
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;AI�p

;AI
[State -1, AI]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
trigger31  = command = "CPU31"
trigger32  = command = "CPU32"
trigger33  = command = "CPU33"
trigger34  = command = "CPU34"
trigger35  = command = "CPU35"
trigger36  = command = "CPU36"
trigger37  = command = "CPU37"
trigger38  = command = "CPU38"
trigger39  = command = "CPU39"
trigger40  = command = "CPU40"
trigger41  = command = "CPU41"
trigger42  = command = "CPU42"
trigger43  = command = "CPU43"
trigger44  = command = "CPU44"
trigger45  = command = "CPU45"
trigger46  = command = "CPU46"
trigger47  = command = "CPU47"
trigger48  = command = "CPU48"
trigger49  = command = "CPU49"
trigger50  = command = "CPU50"
var(59) = 1

;===========================================================================
;---------------------------------------------------------------------------
;��g�i�󒆁j
[State -1]
type = ChangeState
value = 5210
triggerall = Var(59) = 1
triggerall = Alive
triggerall = CanRecover
triggerall = Vel Y > -1
triggerall = Pos Y >= -40
triggerall = StateNo = 5050
trigger1 = random = [150,200]

;---------------------------------------------------------------------------
;��g�i�n��j
[State -1]
type = ChangeState
triggerall = var(59)
triggerall = stateno=5050
triggerall = Vel Y > -1
triggerall = alive
triggerall = CanRecover
trigger1 = ifelse(Pos Y<-30,random%5=0,random%4=0)
value = 5210 ;HITFALL_AIRRECOVER

;---------------------------------------------------------------------------

[State 100, 4]
type = ChangeState
triggerall = var(59) && roundstate=2
triggerall = stateno=251&&animelemtime(4) >= 0
trigger1 = var(36) = [1,2]
value = 40
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Walk]
type = ChangeState
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
triggerall = !InGuardDist
triggerall = stateno != [10,12]
triggerall = prevstateno != [10,12]
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != 21
triggerall = prevstateno != 21
triggerall = stateno != [120,159]
triggerall = prevstateno != [120,159]
triggerall = P2stateno != 5120
trigger1 = !(var(16) && numtarget)
	trigger1 = random%10<=8

[State -1, Walk]
type = ChangeState
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
triggerall = !InGuardDist
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != [120,159]
triggerall = time > 10
trigger1 = !(var(16) && numtarget)
trigger1 = random%10<=8

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = var(59) && roundstate=2 && !(P2statetype=L&&enemynear,alive) && statetype!=A && (var(20)=1||var(20)=6) && Power>=3000 && roundstate=2
triggerall = !var(15) && !var(16)
trigger1 = (P2statetype!=A||(enemynear,Vel Y<0 && enemynear,Pos Y>-40&&!enemynear,hitfall))
trigger1 = (ctrl||stateno=3||stateno=13||(stateno=[21,22])) && Abs(P2bodydist X)<70 && random%4=1 && fvar(18)<=ifelse(fvar(31),850,700)

;--------------------------------------------------
;������P
[state -1]
type = ChangeState
value = 210
triggerall = var(59) && roundstate=2 && P2statetype!=L
triggerall = statetype!=A
trigger1 = ctrl && (prevstateno=[4000,4010])
trigger1 = (P2bodydist X=[33,70]) && P2statetype=A && enemynear,pos Y<-40

;������P
[state -1]
type = ChangeState
value = 210
triggerall = var(59) && roundstate=2 && P2statetype!=L
triggerall = statetype!=A
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
trigger1 = ctrl && (prevstateno=[4000,4010])
trigger1 = (P2bodydist X=[60,80])

;������P
[state -1,clp]
type = ChangeState
value = 220+(abs(P2bodydist X)<=32)
triggerall = var(59) && P2statetype!=L && statetype!=A && (var(16)=[1,60])
triggerall = (P2statetype!=A||(enemynear,Vel Y<0 && enemynear,Pos Y>-40)) && enemynear,hitfall=0
trigger1 = (stateno=310||stateno=221) && Abs(P2bodydist X)<100 && var(36)

;���Ⴊ�ݎ�p���`
[State -1,crouch]
type = ChangeState
value = 400
triggerall = var(59) && StateType!=A && !var(16)
triggerall = roundState=2 && (!(P2Statetype=L&&enemynear,alive)||(P2statetype=L&&enemynear,anim=5120&&enemynear,animtime>-4))
triggerall = (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30&&!enemynear,hitfall)||(P2stateno=5040 && enemynear,pos Y>-10 && enemynear,vel Y>6))
trigger1 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && random<300 && (P2BodyDist X = [0,40]) && (!fvar(31)||(fvar(31)&&ceil(fvar(18))%4=0)) && fvar(18)>ifelse(Power>=1000,320,240) && p2stateno!=5040
trigger2 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && (Abs(P2bodydist X) = [0,40]) && fvar(33)=4
trigger3 = (ctrl|| stateno=3 || stateno=13 || (stateno=[21,22])) && P2stateno=5040 && enemynear,pos Y>-10 && enemynear,vel Y>6 && random%5<3 && (P2BodyDist X = [0,40]) && (fvar(18)=[ifelse(Power>=1000,320,240),ifelse(Power>=1000,840,760)])
trigger4 = prevstateno=52 && ctrl && var(17)>=1 && (P2bodydist X=[-15,40])
;trigger3 = Stateno=400 && time>9 && (P2BodyDist X = [0,45])


;����P
[state -1,clp]
type = ChangeState
value = 410
triggerall = var(59) && P2statetype!=L && statetype!=A && var(16)
triggerall = (P2statetype!=A||(enemynear,Vel Y<0 && enemynear,Pos Y>-40))
trigger1 = (ctrl||stateno=3||stateno=13||(stateno=[21,22])) && Abs(P2bodydist X)<70 && random%5<=2

;����P
[state -1]
type = ChangeState
value = 420
triggerall = var(59) && roundstate=2 && P2statetype!=L
triggerall = statetype!=A
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
trigger1 = ctrl && (prevstateno=[4000,4010])
trigger1 = (P2bodydist X=[30,60])

;����K
[state -1]
type = ChangeState
value = 450
triggerall = var(59) && roundstate=2 && P2statetype!=L
triggerall = statetype!=A
trigger1 = ctrl && (prevstateno=[4000,4010])
trigger1 = P2bodydist X<70 && P2statetype=A && enemynear,pos Y>-40

;����K
[state -1]
type = ChangeState
value = 450
triggerall = var(59) && roundstate=2 && P2statetype!=L
triggerall = statetype!=A
trigger1 = ctrl && (prevstateno=[4000,4010])
trigger1 = P2bodydist X>30

;�ʏ퓊��
[State -1]
type = ChangeState
value = 900-(enemynear,Statetype=A || P2movetype=H)*679
triggerall = var(59) && roundstate=2 && !(P2Statetype=L&&enemynear,alive)
triggerall = P2BodyDist X <=22 && !fvar(31) && (P2Statetype!=A || (P2statetype=A && enemynear,Vel Y<0 && enemynear,Pos Y>=-30&&!enemynear,hitfall))
triggerall = (!var(16)||(var(16)&&enemy,life<90)) && P2movetype!=H
triggerall = StateNo != 100 && StateType!=A && (Ctrl || stateno=3 || stateno=13 || (stateno=[21,22]))
trigger1 = (fvar(18)<ifelse(Power>=1000,320,240)||(P2statetype=S && enemynear,movetype=I && (enemynear,time=[18,22]))||(prevstateno=140 && time>2&&random<200)) && (!fvar(31) || (fvar(31)=4&&var(12)>2))
trigger2 = ((stateno=101||anim=106) && animtime=0)||prevstateno=105||prevstateno=101

;---------------------------------------------------------------------------
;�j�[�v���X�i�C�g���A
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = [10,17]) || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = ((!var(20) || var(20) = 2 || var(20) = 6) && Power >= 2000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || var(43)
trigger1 = P2bodydist X = [0,80]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,time >= (4+random%10)
trigger1 = !(var(16) && numtarget)
	trigger1 = random = [400,550]
trigger2 = P2bodydist X = [0,150]
trigger2 = P2StateType != A
trigger2 = P2MoveType = H
trigger2 = stateno = 200 || stateno = 201
trigger2 = time = [4,8]
trigger2 = var(36) = 1 && numtarget
trigger2 = var(20) != 1 && !(var(20) = 6 && power > 2000)
trigger2 = !(((!var(20) || var(20) = 2 || (var(20) = 6 && !var(18))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || var(43) )
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
	trigger2 = random <= 950+((var(17)>1)*50)
trigger3 = P2bodydist X = [0,150]
trigger3 = P2StateType != A
trigger3 = P2MoveType = H
trigger3 = stateno = 410 || stateno = 420
trigger3 = time = [4,12]
trigger3 = var(36) = 1 && numtarget
trigger3 = var(20) != 1 && !(var(20) = 6 && power > 2000)
trigger3 = target,life > 50
trigger3 = !(var(16) && numtarget)
trigger3 = MoveType = A
	trigger3 = random <= 950+((var(17)>1)*50)
trigger4 = P2bodydist X = [0,150]
trigger4 = P2StateType != A
trigger4 = P2MoveType = H
trigger4 = P2bodydist X > 30
trigger4 = stateno = 440
trigger4 = animelemtime(4) < 0
trigger4 = var(36) = 1 && numtarget
trigger4 = var(20) != 1 && !(var(20) = 6 && power > 2000)
trigger4 = target,life > 50
trigger4 = !(var(16) && numtarget)
trigger4 = MoveType = A
	trigger4 = random <= 950+((var(17)>1)*50)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�t�@�C�i���A�g�~�b�N�o�X�^�[
[State -1, hyper Throw]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = (ctrl && prevstateno = 5120 && time <= 5) || ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [-5,65]
trigger1 = P2StateType != A
trigger1 = P2MoveType != H
trigger1 = P2StateNo != 40
trigger1 = enemynear,Vel X >= 0
	trigger1 = Random <= 450
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�_�[�N�X�}�b�V���i�󒆁j
[State -1, reppuken]
type = ChangeState
value = 1200
triggerall = var(59) = 1
triggerall = statetype = A
triggerall = P2MoveType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [60,150]
trigger1 = P2bodydist Y = [0,80]
trigger1 = Pos Y < -40
trigger1 = Vel Y > -3
trigger1 = ctrl
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 650
trigger2 = StateNo = 600 || StateNo = 630
trigger2 = var(36) = 2
trigger2 = Vel Y > -2
trigger2 = !(var(16) && numtarget)
	trigger2 = Random <= 50
trigger3 = StateNo = [3100,3199]
trigger3 = Var(5) = 1
trigger3 = var(36) = 1 && numtarget
trigger3 = AnimElemTime(26) >= 0
trigger3 = !(var(16) && numtarget)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ՖC
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = var(59) = 1
triggerall = fvar(26) < 3 || var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [-5,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = !(var(16) && numtarget)
	trigger1 = Random > (950-var(12)*5)
trigger2 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = P2bodydist X = [-5,30]
trigger2 = P2bodydist Y = [-40,-20]
trigger2 = P2StateType = A
trigger2 = P2MoveType != H
trigger2 = enemynear,vel X >= 0
trigger2 = enemynear,vel Y > 0
trigger2 = !(var(16) && numtarget)
	trigger2 = Random > (750-var(12)*20)
trigger3 = P2bodydist X = [-5,20]
trigger3 = numtarget
trigger3 = target,BackEdgebodyDist < 15
trigger3 = StateNo = 201 || StateNo = 211 || StateNo = 241 || StateNo = 400
trigger3 = !(var(16) && numtarget)
trigger3 = MoveType = A
trigger3 = var(36) = 1 && numtarget
trigger3 = var(17) >= 2
	trigger3 = Random = [850,900]
trigger4 = P2bodydist X = [0,20]
trigger4 = numtarget
trigger4 = target,BackEdgebodyDist >= 15
trigger4 = StateNo = 201 || StateNo = 211 || StateNo = 241 || StateNo = 400
trigger4 = !(var(16) && numtarget)
trigger4 = MoveType = A
trigger4 = var(36) = 1 && numtarget
trigger4 = var(17) >= 2
	trigger4 = Random = [850,900]
trigger5 = StateNo = 3100
trigger5 = animelemtime(15) > 0
trigger5 = !(var(16) && numtarget)
trigger5 = var(5) = 1
trigger5 = var(36) = 1 && numtarget
trigger6 = P2bodydist X = [-5,10]
trigger6 = prevstateno = [4000,4199]
trigger6 = ctrl
trigger6 = !(var(16) && numtarget)
	trigger6 = random%5=2
ignorehitpause = 0
	
;---------------------------------------------------------------------------
;�X�N�����[�p�C���h���C�o�[
[State -1, reppuken]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 5
trigger1 = P2bodydist X = [-5,65]
trigger1 = P2StateType != A
trigger1 = P2StateNo = [0,2999]
trigger1 = P2StateNo != 40
	trigger1 = Random = [300,700]
ignorehitpause = 0

;===========================================================================
	
;===========================================================================

;---------------------------------------------------------------------------
;�^�󓊂�
[State -1, Throw]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = P2stateno != [120,159]
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = time <= 5
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [1000,3999])
trigger1 = P2bodydist X = [5,65]
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [100,250]
trigger2 = P2bodydist X = [5,60]
trigger2 = P2MoveType != H
trigger2 = stateno = 230
trigger2 = !(var(16) && numtarget)
trigger2 = var(36) = 1 && numtarget
	trigger2 = Random = [600,900]
trigger3 = P2bodydist X = [5,60]
trigger3 = P2MoveType != H
trigger3 = stateno = 400
trigger3 = !(var(16) && numtarget)
trigger3 = var(36) = 1 && numtarget
	trigger3 = Random = [850,900]
trigger4 = P2bodydist X = [-5,60]
trigger4 = P2MoveType != H
trigger4 = !(var(16) && numtarget)
trigger4 = ctrl && time <= 5 && prevstateno = [800,830]
	trigger4 = Random <= 750
trigger5 = P2bodydist X = [-5,60]
trigger5 = P2MoveType != H
trigger5 = !(var(16) && numtarget)
trigger5 = ctrl && time <= 5 && ((prevstateno = [120,159]) || (prevstateno = [5000,5029]))
	trigger5 = Random = [750,850]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�n�[�h�G�b�W
[State -1, reppuken]
type = ChangeState
value = 1400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2StateType != A
trigger1 = StateNo = 211 || StateNo = 241
trigger1 = MoveType = A
trigger1 = var(36) = 1 && numtarget
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [(var(17)<2)*500,1000]
trigger2 = P2StateType != A
trigger2 = StateNo = 440
trigger2 = animelemtime(4) < 0
trigger2 = var(36) = 1 && numtarget
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [(var(17)<2)*550,1000]
trigger3 = ctrl || (stateno = 21 && anim = 21) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = P2bodydist X > 150
trigger3 = P2MoveType != H
trigger3 = !inguarddist
trigger3 = !enemynear,numproj
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [600,630]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�󕗌�
[State -1, reppuken]
type = ChangeState
value = 1300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !NumProj
triggerall = statetype != A
triggerall = !inguarddist
triggerall = !enemynear,numproj
trigger1 = P2bodydist X > 150
trigger1 = P2MoveType != H
trigger1 = ctrl || (stateno = 21 && anim = 20) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [400,450]
trigger2 = StateNo = 440
trigger2 = MoveType = A
trigger2 = !(var(16) && numtarget)
trigger2 = (var(36) = 1 && var(17) = 1) || var(36) = 2
	trigger2 = random < 200
trigger3 = StateNo = 211 || StateNo = 241
trigger3 = MoveType = A
trigger3 = var(36) = 2
trigger3 = !(var(16) && numtarget)
	trigger3 = Random <= 400
ignorehitpause = 0
	
	
;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = (Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)) || (var(14) && var(20) = 3)
triggerall = P2StateType != L
trigger1 = P2bodydist X = [10,50]
trigger1 = P2StateType != A || ((enemynear,Pos Y = [-30,0]) && enemynear,Vel Y > 1)
trigger1 = !enemynear,ctrl
	trigger1 = Random <= 10

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = var(59) = 1
triggerall = (var(20) = 3 && !var(14)) || var(20) = 6
triggerall = statetype != A
triggerall = Power < 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = !inguarddist
triggerall = !enemynear,numproj
triggerall = prevstateno != 850
trigger1 = P2bodydist X >= 160
trigger1 = Ctrl || stateno = 21
	trigger1 = Random = [180,240]
trigger2 = teammode = single
trigger2 = P2bodydist X >= 120
trigger2 = P2StateType = L
trigger2 = Ctrl || stateno = 21
	trigger2 = Random <= 200

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2Life > 150
triggerall = !((100*life/const(data.life))<=20 && P2bodydist X <= 160)
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 120
	trigger1 = Random <= 750
trigger2 = P2StateType = L
	trigger2 = Random <= 750

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 1
triggerall = statetype = S
triggerall = ctrl || stateno = 21
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = prevstateno != 5120
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = enemynear,prevstateno != [5000,5999]
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 550
	
;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,60]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !var(17)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [550,900]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [-5,30]
trigger2 = P2MoveType = H
trigger2 = prevstateno != 400
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [50,950]
trigger3 = P2bodydist X = [-5,30-((var(20) = 2 || var(20) = 6)*15)]
trigger3 = P2MoveType = H
trigger3 = stateno = 400
trigger3 = time = [5,7]
trigger3 = !(var(16) && numtarget)
;trigger3 = movetype = A
trigger3 = var(36) = [1,2]
	trigger3 = Random = [50,650]
ignorehitpause = 0
	
;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [45,60]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno = [0,999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random >= 850
trigger2 = ctrl || stateno = 21
trigger2 = P2MoveType = H
trigger2 = P2bodydist X = [20,60]
trigger2 = !(var(16) && numtarget)
	trigger2 = Random <= 650
trigger3 = (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X = [30,60]
trigger3 = P2MoveType = I || (P2MoveType = A && P2stateno = [0,999])
trigger3 = !(var(16) && numtarget)
	trigger3 = Random >= 900
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 251
triggerall = var(59) = 1
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger1 = P2bodydist X = [-15,20]
trigger1 = P2StateType != A
trigger1 = P2MoveType = H
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 500
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) >1) || stateno = 101
trigger2 = P2bodydist X = [0,20]
trigger2 = P2bodydist Y = [-80,-30]
trigger2 = P2StateType = A
trigger2 = P2MoveType = I || (P2MoveType = A && P2stateno = [0,999])
trigger2 = enemynear,Vel X > 1
trigger2 = !(var(16) && numtarget)
trigger2 = !enemynear,NumProj
trigger2 = frontedgebodydist > 80
	trigger2 = Random <= 300
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = StateNo = 830 && Time =[14,24]
trigger1 = P2bodydist X = [-10,40]
trigger1 = P2StateType != A
trigger1 = P2MoveType != A
	trigger1 = Random = [180,200]
	
;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
triggerall = roundstate = 2
value = 420
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [70,100]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [870,900]
trigger2 = numtarget
trigger2 = target,StateType = C
trigger2 = target,MoveType = H
trigger2 = stateno = 220 || stateno = 420 || stateno = 500
trigger2 = !(!var(12) && (prevstateno = 420 || (prevstateno = 500 && P2BodyDist X > 20)))
trigger2 = var(16) >= 20
trigger2 = var(36) = [1,2]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X != [-30,30]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [70,100]
trigger1 = P2bodydist Y = [-80,-50]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno = [0,999])
trigger1 = enemynear,Vel X > 0
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,400]
trigger2 = P2bodydist X = [60,100]
trigger2 = StateNo = 1551
trigger2 = animtime = 0
trigger2 = !(var(16) && numtarget)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,40]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [890,900]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [60,80]
trigger1 = P2StateType != C
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [880,900]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [70,100]
trigger1 = P2StateType != C
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [880,900]
trigger2 = numtarget
trigger2 = target,StateType = S
trigger2 = target,MoveType = H
trigger2 = stateno = 220 || stateno = 420 || stateno = 500
trigger2 = !(!var(12) && (prevstateno = 220 || (prevstateno = 500 && P2BodyDist X > 20)))
trigger2 = var(16) >= 20
trigger2 = var(36) = [1,2]
trigger3 = numtarget
trigger3 = target,MoveType = H
trigger3 = stateno = 1200
trigger3 = var(16) >= 20
trigger3 = var(36) = [1,2]
ignorehitpause = 0

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [0,50]
trigger1 = P2bodydist Y = [-40,0]
trigger1 = P2StateType != C
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = prevstateno != 400
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [880,900]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [-30,30]
trigger2 = P2bodydist Y = [-90,-70]
trigger2 = P2MoveType = I || (P2MoveType = A && P2stateno != [1000,3999])
trigger2 = prevstateno != 400
trigger2 = !(var(16) && numtarget)
trigger2 = frontedgebodydist > 80
	trigger2 = Random = [850,900]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [50,80]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [880,900]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [30,60]
trigger1 = P2StateType != C
trigger1 = P2MoveType != A
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [850,855]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�΂߃W�����v���p���`
[State -1]
type = ChangeState
value = 621
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = Pos Y < -30
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = statetype = A
triggerall = Vel X
trigger1 = P2bodydist X = [-1,100]
trigger1 = P2bodydist Y = [-30,50]
trigger1 = Ctrl
trigger1 = Vel Y > 1
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [100,400]
trigger2 = P2bodydist X = [-1,100]
trigger2 = P2bodydist Y = [-30,50]
trigger2 = Ctrl
trigger2 = Vel Y > -1
trigger2 = !(var(16) && numtarget)
trigger2 = var(4)
	trigger2 = Random = [100,600]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�t���C���O�{�f�B�[�A�^�b�N
[State -1, Taunt]
type = ChangeState
value = 720
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = Pos Y < -50
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = statetype = A
triggerall = Vel X
trigger1 = P2bodydist X = [-60,0]
trigger1 = P2bodydist Y = [0,50]
trigger1 = Ctrl
trigger1 = Vel Y > 1
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [100,500]
ignorehitpause = 0


;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = statetype = A
trigger1 = P2bodydist X = [-1,60]
trigger1 = P2bodydist Y = [-50,-10]
trigger1 = Ctrl
trigger1 = Vel Y > -2
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,320]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = Pos Y < -30
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = statetype = A
triggerall = !Vel X
trigger1 = P2bodydist X = [-1,30]
trigger1 = P2bodydist Y = [30,70]
trigger1 = Ctrl
trigger1 = Vel Y > -1
trigger1 = !(var(16) && numtarget)
trigger1 = var(4)
	trigger1 = Random = [100,200]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = Pos Y < -30
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = statetype = A
trigger1 = P2bodydist X = [30,110]
trigger1 = P2bodydist Y = [-30,50]
trigger1 = Ctrl
trigger1 = Vel Y > 1
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [100,300]
ignorehitpause = 0
	
;---------------------------------------------------------------------------
;�K�[�h
[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype != A
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,20,500)

[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype = A
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,80,400)

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = P2MoveType != A
trigger1 = P2bodydist X >= 150
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = PrevStateNo = 1000
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [600,700]
trigger2 = P2bodydist X > 200
trigger2 = Ctrl || (stateno = 21 && anim = 20)
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [400,550]

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(20) || var(20) = 1 || var(20) = 2
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = P2MoveType != A
trigger1 = P2bodydist X >= 150
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [550,620]
trigger2 = P2bodydist X >= 200
trigger2 = Ctrl || (stateno = 21 && anim = 20)
trigger2 = PrevStateNo = 1000
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [250,290]
trigger3 = P2bodydist X > 150
trigger3 = P2StateType = L
trigger3 = Ctrl || (stateno = 21 && anim = 20)
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [150,220]

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = backedgedist > 30
trigger1 = P2bodydist X <= 70
trigger1 = P2MoveType != A
trigger1 = Ctrl || (stateno = 21 && anim = 21)
trigger1 = !numtarget
trigger1 = backedgedist > 60
	trigger1 = Random = [300,310]

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 1
triggerall = !var(20) || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = stateno != [120,159]
triggerall = stateno != [4000,4199]
triggerall = prevstateno != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 100
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [640,650]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X >= 50
trigger2 = inguarddist
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [650,700]
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = var(59) = 1
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = stateno != [120,159]
triggerall = stateno != [4000,4199]
triggerall = prevstateno != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X <= 50
trigger1 = P2MoveType = I
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 40
trigger2 = P2bodydist X <= 50
trigger2 = P2MoveType = A
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = !(var(16) && numtarget)
	trigger2 = Random <= 100
ignorehitpause = 0


;===========================================================================
;---------------------------------------------------------------------------
;�V�����a��
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProj
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = Command = "csplitter_x" || Command = "csplitter_y" || Command = "csplitter_z"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(5) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(5) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger6 = StateNo = 631 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger7 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(4) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger8 = StateNo = 641 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger9 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(4) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger10 = StateNo = 651 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(4) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(7) < 0))
trigger11 = StateNo = 700 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger12 = (StateNo = [1100,1499]) && var(36) && var(16)
trigger13 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger14 = (StateNo = [1100,1499]) && statetype = A && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�e���ęጝ
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = !NumProjID(1005) && !NumProjID(1055) && !NumProjID(3005)
triggerall = Command = "rtyphoon_x" || Command = "rtyphoon_y" || Command = "rtyphoon_z"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1100,1499]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger22 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger23 = (StateNo = [1100,1499]) && (var(20) = 2 || var(20) = 6)
trigger24 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger25 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0

;---------------------------------------------------------------------------
;���՗���
[State -1, hadouken]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = Command = "csplitter_x" || Command = "csplitter_y" || Command = "csplitter_z"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1100,1499]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger22 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger23 = (StateNo = [1100,1499]) && (var(20) = 2 || var(20) = 6)
trigger24 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger25 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�ՖC
[State -1, hadouken]
type = ChangeState
value = 1300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "tbuster_x" || Command = "tbuster_y" || Command = "tbuster_z"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 195 && var(36) && var(16)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0
;---------------------------------------------------------------------------
; Condor Dive
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = Var(59) != 2
triggerall = command = "condordive"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(5) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(4) < 0)
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger6 = StateNo = 631 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger7 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger8 = StateNo = 641 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(2) < 0)
trigger9 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger10 = StateNo = 651 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(4) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(4) < 0))
trigger11 = StateNo = 700 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger12 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger13 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ՖC
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "cspire_x" || Command = "cspire_y" || Command = "cspire_z"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 195 && var(36) && var(16)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ՖC
[State -1, hadouken]
type = ChangeState
value = 1400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "cspiref_x" || Command = "cspiref_y" || Command = "cspiref_z"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 195 && var(36) && var(16)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !NumProjID(1005) && !NumProjID(1055) && !NumProjID(3005)
triggerall = Command = "mtyphoon_x" || Command = "mtyphoon_y" || Command = "mtyphoon_z"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2)
trigger14 = StateNo = 420 && (var(16) || time <= 2)
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 195 && var(36) && var(16)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 231
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2)
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 400
trigger13 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(3) < 0))
trigger15 = StateNo = 430 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 450 && (var(16) || time <= 2)
trigger18 = StateNo = 300 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3199]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5201
triggerall = !var(59)
triggerall = !var(1)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= 10
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2
trigger19 = (StateNo = [195,799]) && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2
trigger19 = (StateNo = [195,799]) && var(36) && var(16)
trigger20 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger21 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger22 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger23 = (StateNo = [1400,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 201 && time < 2
trigger4 = StateNo = 210 && time < 2
trigger5 = StateNo = 211 && time < 2
trigger6 = StateNo = 220 && time < 2
trigger7 = StateNo = 230 && time < 2
trigger8 = StateNo = 231 && time < 2
trigger9 = StateNo = 240 && time < 2
trigger10 = StateNo = 241 && time < 2
trigger11 = StateNo = 250 && time < 2
trigger12 = StateNo = 400 && time < 2
trigger13 = StateNo = 410 && time < 2
trigger14 = StateNo = 420 && time < 2
trigger15 = StateNo = 430 && time < 2
trigger16 = StateNo = 440 && time < 2
trigger17 = StateNo = 450 && time < 2
trigger18 = StateNo = 300 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !var(4)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time < 2
trigger3 = StateNo = 610 && time < 2
trigger4 = StateNo = 620 && time < 2
trigger5 = StateNo = 630 && time < 2
trigger6 = StateNo = 640 && time < 2
trigger7 = StateNo = 650 && time < 2

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)
trigger2 = numtarget
trigger2 = target,stateno = 3700

;---------------------------------------------------------------------------
;�t���C���O�{�f�B�[�A�^�b�N
[State -1, Taunt]
type = ChangeState
value = 720
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && var(36) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = (StateNo = [1600,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0


;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 251
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0


;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 231 && Time > 4
trigger5 = StateNo = 400 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger7 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger8 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger9 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger10 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1299]) && var(36) && var(16)
trigger4 = StateNo = 1300 && (var(36) = [2,4]) && var(16)
trigger5 = StateNo = 1301 && var(36) && var(16) && animelemtime(2) > 0
trigger6 = (StateNo = [1400,1599]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����W�����v���p���`
[State -1]
type = ChangeState
value = 621
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
