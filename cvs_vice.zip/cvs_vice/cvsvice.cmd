;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "�E�C�U�����O�T�[�t�F�X1"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "�E�C�U�����O�T�[�t�F�X1"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "�E�C�U�����O�T�[�t�F�X2"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "�E�C�U�����O�T�[�t�F�X2"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "�E�C�U�����O�T�[�t�F�X3"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "�E�C�U�����O�T�[�t�F�X3"
command = ~D, DF, F, D, DF, ~z
time = 21

[Command]
name = "�l�K�e�B�u�Q�C��1"
command = ~F, D, B, F, D, B, a
time = 30

[Command]
name = "�l�K�e�B�u�Q�C��1"
command = ~F, D, B, F, D, B, ~a
time = 30

[Command]
name = "�l�K�e�B�u�Q�C��2"
command = ~F, D, B, F, D, B, b
time = 30

[Command]
name = "�l�K�e�B�u�Q�C��2"
command = ~F, D, B, F, D, B, ~b
time = 30

[Command]
name = "�l�K�e�B�u�Q�C��3"
command = ~F, D, B, F, D, B, c
time = 30

[Command]
name = "�l�K�e�B�u�Q�C��3"
command = ~F, D, B, F, D, B, ~c
time = 30

[Command]
name = "�I�[�o�[�L��"
command = ~F, D, B, F, D, B, x
time = 30

[Command]
name = "�I�[�o�[�L��"
command = ~F, D, B, F, D, B, ~x
time = 30

[Command]
name = "�I�[�o�[�L��"
command = ~F, D, B, F, D, B, y
time = 30

[Command]
name = "�I�[�o�[�L��"
command = ~F, D, B, F, D, B, ~y
time = 30

[Command]
name = "�I�[�o�[�L��"
command = ~F, D, B, F, D, B, z
time = 30

[Command]
name = "�I�[�o�[�L��"
command = ~F, D, B, F, D, B, ~z
time = 30

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "�l�C���{��1"
command = ~B, DB, D, DF, x
time = 15

[Command]
name = "�l�C���{��1"
command = ~B, DB, D, DF, ~x
time = 15

[Command]
name = "�l�C���{��2"
command = ~B, DB, D, DF, y
time = 15

[Command]
name = "�l�C���{��2"
command = ~B, DB, D, DF, ~y
time = 15

[Command]
name = "�l�C���{��3"
command = ~B, DB, D, DF, z
time = 15

[Command]
name = "�l�C���{��3"
command = ~B, DB, D, DF, ~z
time = 15

[Command]
name = "�S�A�t�F�X�g1"
command = ~F, DF, D, DB, B, F, x
time = 30

[Command]
name = "�S�A�t�F�X�g1"
command = ~F, DF, D, DB, B, F, ~x
time = 30

[Command]
name = "�S�A�t�F�X�g2"
command = ~F, DF, D, DB, B, F, y
time = 30

[Command]
name = "�S�A�t�F�X�g2"
command = ~F, DF, D, DB, B, F, ~y
time = 30

[Command]
name = "�S�A�t�F�X�g3"
command = ~F, DF, D, DB, B, F, z
time = 30

[Command]
name = "�S�A�t�F�X�g3"
command = ~F, DF, D, DB, B, F, ~z
time = 30

[Command]
name = "�f�B�[�T�C�h1"
command = ~B, DB, D, DF, F, a
time = 18

[Command]
name = "�f�B�[�T�C�h1"
command = ~B, DB, D, DF, F, ~a
time = 18

[Command]
name = "�f�B�[�T�C�h2"
command = ~B, DB, D, DF, F, b
time = 18

[Command]
name = "�f�B�[�T�C�h2"
command = ~B, DB, D, DF, F, ~b
time = 18

[Command]
name = "�f�B�[�T�C�h3"
command = ~B, DB, D, DF, F, c
time = 18

[Command]
name = "�f�B�[�T�C�h3"
command = ~B, DB, D, DF, F, ~c
time = 18

[Command]
name = "�f�B�[�T�C�h�E�X���C���[1"
command = ~F, D, DF, a
time = 12

[Command]
name = "�f�B�[�T�C�h�E�X���C���[1"
command = ~F, D, DF, ~a
time = 12

[Command]
name = "�f�B�[�T�C�h�E�X���C���[2"
command = ~F, D, DF, b
time = 12

[Command]
name = "�f�B�[�T�C�h�E�X���C���[2"
command = ~F, D, DF, ~b
time = 12

[Command]
name = "�f�B�[�T�C�h�E�X���C���[3"
command = ~F, D, DF, c
time = 12

[Command]
name = "�f�B�[�T�C�h�E�X���C���[3"
command = ~F, D, DF, ~c
time = 12

[Command]
name = "�g�����L�����e�B�[1"
command = ~F, D, DF, x
time = 12

[Command]
name = "�g�����L�����e�B�[1"
command = ~F, D, DF, ~x
time = 12

[Command]
name = "�g�����L�����e�B�[2"
command = ~F, D, DF, y
time = 12

[Command]
name = "�g�����L�����e�B�[2"
command = ~F, D, DF, ~y
time = 12

[Command]
name = "�g�����L�����e�B�[3"
command = ~F, D, DF, z
time = 12

[Command]
name = "�g�����L�����e�B�[3"
command = ~F, D, DF, ~z
time = 12

[Command]
name = "�A�E�g���C�W1"
command = ~D, DB, B, a
time = 12

[Command]
name = "�A�E�g���C�W1"
command = ~D, DB, B, ~a
time = 12

[Command]
name = "�A�E�g���C�W2"
command = ~D, DB, B, b
time = 12

[Command]
name = "�A�E�g���C�W2"
command = ~D, DB, B, ~b
time = 12

[Command]
name = "�A�E�g���C�W3"
command = ~D, DB, B, c
time = 12

[Command]
name = "�A�E�g���C�W3"
command = ~D, DB, B, ~c
time = 12

[Command]
name = "���C�w��1"
command = ~D, DB, B, x
time = 12

[Command]
name = "���C�w��1"
command = ~D, DB, B, ~x
time = 12

[Command]
name = "���C�w��2"
command = ~D, DB, B, y
time = 12

[Command]
name = "���C�w��2"
command = ~D, DB, B, ~y
time = 12

[Command]
name = "���C�w��3"
command = ~D, DB, B, z
time = 12

[Command]
name = "���C�w��3"
command = ~D, DB, B, ~z
time = 12

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 10

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

[Command]
name = "n"
command = 
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;AI�p

;AI
[State -1, AI]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
var(59) = 1

;===========================================================================
;---------------------------------------------------------------------------
;��g�i�󒆁j
[State -1]
type = ChangeState
value = 5210
triggerall = Var(59) = 1
triggerall = Alive
triggerall = CanRecover
triggerall = Vel Y > -1
triggerall = Pos Y >= -40
triggerall = StateNo = 5050
trigger1 = random = [150,200]

;---------------------------------------------------------------------------
;��g�i�n��j
[State -1]
type = ChangeState
value = 5200
triggerall = var(59) = 1
triggerall = ((var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6) && !(var(0)&2**10)) || CanRecover
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = random <= 400

;---------------------------------------------------------------------------
;����
[State -1, Walk]
type = ChangeState
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
triggerall = !InGuardDist
triggerall = stateno != [10,12]
triggerall = prevstateno != [10,12]
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != 21
triggerall = prevstateno != 21
triggerall = stateno != [120,159]
triggerall = prevstateno != [120,159]
trigger1 = random%6=0

;---------------------------------------------------------------------------
;�W�����v�i��������j
[state -1, Guard]
type = ChangeState
value = 40
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist || P2bodydist X = [-60,120]
triggerall = ctrl || stateno = 21
triggerall = statetype != A
trigger1 = enemynear,HitDefAttr = SC, NT,ST,HT
	trigger1 = random = [0,700]

;===========================================================================
;---------------------------------------------------------------------------
;�I�[�o�[�L��
[State -1, nailbomb]
type = ChangeState
value = 3200
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = statetype = A && P2StateType != L
trigger1 = P2StateType = A
trigger1 = P2bodydist X = [0,52]
trigger1 = P2bodydist Y = [-25,25]
trigger1 = Ctrl
ignorehitpause = 0

;---------------------------------------------------------------------------
;�l�K�e�B�u�Q�C��
[State -1, nailbomb]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A && P2StateType != L
triggerall = enemynear,prevstateno != [5000,5999]
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
triggerall = P2StateType != A
trigger1 = !var(15) && !var(16) && (!var(20) || var(20) = 6)
trigger1 = P2bodydist X = [0,46]
trigger1 = P2MoveType = I
	trigger1 = Random > 300
trigger2 = !var(15) && !var(16) && (!var(20) || var(20) = 6)
trigger2 = P2bodydist X = [0,46]
trigger2 = P2MoveType = A
	trigger2 = Random > 150
trigger3 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4 
trigger3 = P2bodydist X = [0,46]
trigger3 = P2MoveType = I
	trigger2 = Random > 450
trigger4 = !var(15) && !var(16) && var(20) = 1 || (var(20) = 3 && life > 300) || (var(20) = 3 && life <= 300 && !var(14)) || var(20) = 4 
trigger4 = P2bodydist X = [0,46]
trigger4 = P2MoveType = A
	trigger4 = Random > 550
trigger5 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger5 = P2bodydist X = [0,46]
trigger5 = P2MoveType = I
	trigger5 = Random > 400
trigger6 = (!var(15) && !var(16) && var(20) = 2 || (var(20) = 3 && life <= 300 && var(14)) || var(20) = 5) || var(15) || var(16)
trigger6 = P2bodydist X = [0,46]
trigger6 = P2MoveType = A
	trigger6 = Random > 300
ignorehitpause = 0

;---------------------------------------------------------------------------
;�E�C�U�����O�T�[�t�F�X
[State -1, nailbomb]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = statetype != A && P2StateType != L
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = !var(15) && !var(16) && (!var(20) || var(20) = 6)
trigger1 = P2bodydist X = [45,150]
trigger1 = P2bodydist Y >= -30
trigger1 = enemynear,Vel X > 0 || P2StateType != A
trigger1 = enemynear,Vel X >= 0
trigger1 = P2MoveType = I
	trigger1 = Random > ifelse(power<=1999,999,ifelse(power<=2999,960,950))
trigger2 = !var(15) && !var(16) && (!var(20) || var(20) = 6)
trigger2 = P2bodydist X = [45,150]
trigger2 = P2bodydist Y >= -30
trigger2 = enemynear,Vel Y > 0 || P2StateType != A
trigger2 = enemynear,Vel X >= 0
trigger2 = P2MoveType = A
	trigger2 = Random > ifelse(power<=1999,980,ifelse(power<=2999,960,940))
ignorehitpause = 0

;---------------------------------------------------------------------------
;�K�[�h
[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = stateno != [120,159]
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = prevstateno != [120,159]
triggerall = ctrl || stateno = 21
triggerall = statetype != A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,60,500)

[state -1, Guard]
type = ChangeState
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = stateno != [120,159]
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = prevstateno != [120,159]
triggerall = ctrl
triggerall = statetype = A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,30,650)

;===========================================================================
;---------------------------------------------------------------------------
;�S�A�t�F�X�g
[State -1, nailbomb]
type = ChangeState
value = 1400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L
triggerall = enemynear,prevstateno != [5000,5999]
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [0,18]
trigger1 = P2StateType != A
	trigger1 = Random <= 550
ignorehitpause = 0

;---------------------------------------------------------------------------
;�g�����L�����e�B�[
[State -1, nailbomb]
type = ChangeState
value = 1300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [0,60]
trigger1 = P2StateType = A
trigger1 = P2MoveType = I
trigger1 = enemynear,Vel X >= 0
	trigger1 = Random <= 120
ignorehitpause = 0

;---------------------------------------------------------------------------
;�l�C���{��
[State -1, nailbomb]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L
triggerall = enemynear,prevstateno != [5000,5999]
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [0,18]
trigger1 = P2StateType != A
	trigger1 = Random > 600
ignorehitpause = 0

;---------------------------------------------------------------------------
;���C�w��
[State -1, nailbomb]
type = ChangeState
value = 1700
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = numtarget
trigger1 = target,statetype != A
trigger1 = StateNo = 211 || StateNo = 221 || StateNo = 241 || StateNo = 420
trigger1 = var(36) = 1
	trigger1 = Random <= 750
trigger2 = numtarget
trigger2 = target,statetype != A
trigger2 = P2bodydist X >= 30
trigger2 = StateNo = 200 || StateNo = 201 || StateNo = 230 || StateNo = 400 || StateNo = 430
trigger2 = var(36) = 1
	trigger2 = Random <= 850
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = P2bodydist X > 80
trigger3 = P2StateType = L
	trigger3 = Random = [60,120]
trigger4 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger4 = P2bodydist X = [50,120]
	trigger4 = Random = [50,80]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�f�B�[�T�C�h�E�X���C���[
[State -1, nailbomb]
type = ChangeState
value = 1200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [100,160]
trigger1 = P2StateType = A
trigger1 = P2MoveType = I
trigger1 = enemynear,Vel X >= 0 && FrontEdgebodyDist > 40
	trigger1 = Random > 900
ignorehitpause = 0

;---------------------------------------------------------------------------
;�f�B�[�T�C�h
[State -1, nailbomb]
type = ChangeState
value = 1100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L && P2StateType != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [100,140]
	trigger1 = Random <= 50
trigger2 = P2StateType != A
trigger2 = StateNo = 221 || StateNo = 420
trigger2 = var(36) = 1
trigger2 = FrontEdgebodyDist > 60
	trigger2 = Random > 720
ignorehitpause = 0

;---------------------------------------------------------------------------
;�A�E�g���C�W
[State -1, nailbomb]
type = ChangeState
value = 1500
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [0,60]
trigger1 = P2MoveType = I
	trigger1 = Random <= 120
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = P2bodydist X = [0,50]
trigger2 = P2StateType = L
	trigger2 = Random <= 50
ignorehitpause = 0

;---------------------------------------------------------------------------
;���C���i�X
[State -1, Hadousho]
type = ChangeState
value = 1600
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = P2bodydist Y = [-50,50]
trigger1 = Ctrl
trigger1 = Vel X >= 0
trigger1 = time = [8,16]
	trigger1 = Random = [990,999]
trigger2 = StateNo = 600 || StateNo = 630
trigger2 = var(36) = 2
	trigger2 = Random <= 180
trigger3 = Ctrl
trigger3 = P2StateType = L
	trigger3 = Random <= 50
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = S
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
trigger1 = Random <= 800
trigger1 = ctrl || stateno = 21

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = P2MoveType != A
trigger1 = P2bodydist X >= 240
trigger1 = Ctrl
	trigger1 = Random = [20,22]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = var(59) = 1
triggerall = (var(20) = 3 && !var(14)) || var(20) = 6
triggerall = statetype != A
triggerall = Power < 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = !enemynear,numproj
trigger1 = P2bodydist X >= 240
trigger1 = Ctrl
	trigger1 = Random <= 50
trigger2 = teammode = single
trigger2 = P2bodydist X >= 150
trigger2 = P2StateType = L
trigger2 = Ctrl
	trigger2 = Random <= 100

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2Life > 150
triggerall = !((100*life/const(data.life))<=20 && P2bodydist X <= 160)
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 120
	trigger1 = Random <= 450

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [0,15]
	trigger1 = Random <= 250
trigger2 = P2bodydist X = [0,20]
trigger2 = P2StateType != A
trigger2 = StateNo = 200 || StateNo = 201 || StateNo = 400 || StateNo = 430
trigger2 = var(36) = 1 || var(36) = 2
	trigger2 = Random <= 500
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X >= 120
trigger3 = P2MoveType != A
	trigger3 = Random = [800,810]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [0,20]
trigger1 = P2StateType != A
	trigger1 = Random <= 130
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X <= 30
trigger2 = P2bodydist Y = [-80,-40]
trigger2 = P2MoveType != H
	trigger2 = Random >= 650
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X = [10,55]
trigger3 = P2StateType != A
trigger3 = P2MoveType = H
trigger3 = P2stateno != [120,159]
	trigger3 = Random <= 700
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [0,30]
	trigger1 = Random <= 250
trigger2 = P2bodydist X = [0,30]
trigger2 = StateNo = 200 || StateNo = 201 || StateNo = 400 || StateNo = 430
trigger2 = var(36) = 1 || var(36) = 2
	trigger2 = Random <= 600
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X >= 120
trigger3 = P2MoveType != A
	trigger3 = Random = [600,610]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A && P2StateType != L && P2StateType != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [50,80]
	trigger1 = Random <= 150
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X > 20
triggerall = statetype != A
triggerall = P2StateType != C && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [25,50]
	trigger1 = Random <= 300
trigger2 = P2bodydist X = [20,40]
trigger2 = P2StateType != A
trigger2 = StateNo = 200 || StateNo = 201 || StateNo = 400 || StateNo = 430
trigger2 = var(36) = 1 || var(36) = 2
	trigger2 = Random <= 300
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X >= 120
trigger3 = P2MoveType != A
	trigger3 = Random <= 20
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X > 20
triggerall = statetype != A && P2StateType != A && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [60,100]
trigger1 = P2MoveType != H
	trigger1 = Random = [150,350]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X > 20
triggerall = statetype != A && P2StateType != A && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [60,90]
trigger1 = P2StateType != L
	trigger1 = Random <= 150
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X = [-24,24]
triggerall = statetype != A && P2StateType != A && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
	trigger1 = Random <= 100
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2StateType != A
trigger2 = P2MoveType = H
	trigger2 = Random <= 500
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X > 20
triggerall = statetype != A && P2StateType != L
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [46,100]
trigger1 = P2bodydist Y = [-90,-50]
trigger1 = P2MoveType != H
	trigger1 = Random <= 650
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A && Ctrl && P2StateType != L && Pos Y >= -110
trigger1 = P2bodydist X = [0,30]
trigger1 = P2bodydist Y = [-30,50]
trigger1 = P2MoveType != H
trigger1 = time = [8,28]
	trigger1 = Random = [250,300]
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A && Ctrl && Pos Y >= -110
trigger1 = P2bodydist X = [0,60]
trigger1 = P2bodydist Y = [0,30]
trigger1 = P2MoveType != H
trigger1 = time = [8,28]
	trigger1 = Random <= 150
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A && Ctrl && P2StateType != L && Pos Y >= -110
trigger1 = P2bodydist X = [10,50]
trigger1 = P2bodydist Y = [-10,30]
trigger1 = P2MoveType != H
trigger1 = time = [8,28]
	trigger1 = Random = [650,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(59) = 1
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = P2MoveType != A
triggerall = statetype != A
trigger1 = P2bodydist X = [40,120]
trigger1 = Ctrl
	trigger1 = Random = [281,300]
trigger2 = P2bodydist X > 120
trigger2 = Ctrl
	trigger2 = Random = [261,320]

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = var(59) = 1
triggerall = !var(20) || var(20) = 1 || var(20) = 2
triggerall = P2MoveType != A
triggerall = statetype != A
trigger1 = P2bodydist X >= 150
trigger1 = Ctrl
	trigger1 = Random = [291,300]
trigger2 = P2bodydist X >= 80
trigger2 = P2StateType = L
trigger2 = Ctrl
	trigger2 = Random = [291,300]

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 1
triggerall = statetype != A
trigger1 = P2bodydist X = [0,90]
trigger1 = P2MoveType != H
trigger1 = P2MoveType != A
trigger1 = Ctrl
	trigger1 = Random = [521,580]
trigger2 = P2bodydist X = [0,60]
trigger2 = P2StateType = L
trigger2 = Ctrl
	trigger2 = Random = [421,550]

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 1
triggerall = !var(20) || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = PrevStateNo != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X > 90
	trigger1 = Random = [300,330]
trigger2 = P2bodydist X = [50,120]
trigger2 = P2MoveType = I
	trigger2 = Random = [901,929]
trigger3 = P2bodydist X = [0,70]
trigger3 = P2MoveType = A
	trigger3 = Random = [781,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = PrevStateNo != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [20,80]
trigger1 = P2MoveType = I
	trigger1 = Random = [581,600]
trigger2 = P2bodydist X = [0,80]
trigger2 = P2MoveType = A
	trigger2 = Random = [651,709]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v
[State -1, Jump]
type = ChangeState
value = 40
triggerall = var(59) = 1
triggerall = StateType != A
triggerall = P2MoveType = I
triggerall = Ctrl
trigger1 = BackEdgebodyDist > 5
trigger1 = P2bodydist X <= 160
	trigger1 = Random = [700,780]
trigger2 = P2bodydist X > 160
	trigger2 = Random = [500,510]
trigger3 = (((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && life <= 300 && Power >= 3000) || (var(15) && Power >= 1000) || var(13) > 0)
trigger3 = P2StateType = A
	trigger3 = random <= 80

;===========================================================================
;---------------------------------------------------------------------------
;�I�[�o�[�L��
[State -1, nailbomb]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) 
triggerall = Command = "�I�[�o�[�L��"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(9) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(9) < 0))
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger8 = (StateNo = [1500,2999]) && (var(20) = 2 || var(20) = 6)
trigger9 = StateNo = 1300 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�E�C�U�����O�T�[�t�F�X
[State -1, nailbomb]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�E�C�U�����O�T�[�t�F�X1" || Command = "�E�C�U�����O�T�[�t�F�X2" || Command = "�E�C�U�����O�T�[�t�F�X3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 251 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger18 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
trigger24 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger25 = (StateNo = [1500,2999]) && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�l�K�e�B�u�Q�C��
[State -1, nailbomb]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (var(0)&2**3) || var(14) || var(16)
triggerall = Command = "�l�K�e�B�u�Q�C��1" || Command = "�l�K�e�B�u�Q�C��2" || Command = "�l�K�e�B�u�Q�C��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 251 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger18 = StateNo = 450 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
trigger24 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger25 = (StateNo = [1500,2999]) && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�S�A�t�F�X�g
[State -1, nailbomb]
type = ChangeState
value = 1400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�S�A�t�F�X�g1" || Command = "�S�A�t�F�X�g2" || Command = "�S�A�t�F�X�g3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 251 && (var(16) || time <= 2)
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2)
trigger15 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2)
trigger18 = StateNo = 450 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�g�����L�����e�B�[
[State -1, nailbomb]
type = ChangeState
value = 1300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�g�����L�����e�B�[1" || Command = "�g�����L�����e�B�[2" || Command = "�g�����L�����e�B�[3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 251 && (var(16) || time <= 2)
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2)
trigger15 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2)
trigger18 = StateNo = 450 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�l�C���{��
[State -1, nailbomb]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�l�C���{��1" || Command = "�l�C���{��2" || Command = "�l�C���{��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 251 && (var(16) || time <= 2)
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2)
trigger15 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2)
trigger18 = StateNo = 450 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���C�w��
[State -1, nailbomb]
type = ChangeState
value = 1700
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "���C�w��1" || Command = "���C�w��2" || Command = "���C�w��3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 251 && (var(16) || time <= 2)
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2)
trigger15 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2)
trigger18 = StateNo = 450 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�f�B�[�T�C�h�E�X���C���[
[State -1, nailbomb]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�f�B�[�T�C�h�E�X���C���[1" || Command = "�f�B�[�T�C�h�E�X���C���[2" || Command = "�f�B�[�T�C�h�E�X���C���[3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 251 && (var(16) || time <= 2)
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2)
trigger15 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2)
trigger18 = StateNo = 450 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�f�B�[�T�C�h
[State -1, nailbomb]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�f�B�[�T�C�h1" || Command = "�f�B�[�T�C�h2" || Command = "�f�B�[�T�C�h3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 251 && (var(16) || time <= 2)
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2)
trigger15 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2)
trigger18 = StateNo = 450 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�A�E�g���C�W
[State -1, nailbomb]
type = ChangeState
value = 1500
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�A�E�g���C�W1" || Command = "�A�E�g���C�W2" || Command = "�A�E�g���C�W3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 251 && (var(16) || time <= 2)
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2)
trigger15 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2)
trigger18 = StateNo = 450 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���C���i�X
[State -1, Hadousho]
type = ChangeState
value = 1600
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = roundstate = 2
triggerall = Command = "�A�E�g���C�W1" || Command = "�A�E�g���C�W2" || Command = "�A�E�g���C�W3"
triggerall = statetype = A
;triggerall = Time >= 15
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(9) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(6) < 0))
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(9) < 0))
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || time <= 2)
trigger8 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
trigger1 = Power >= 1000 && Command = "gc" && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && Command = "gc" && var(20) = 1
trigger3 = var(14) && Command = "gc" && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 201
trigger4 = StateNo = 210 && (var(16) || time <= 2)
trigger5 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 220 && (var(16) || time <= 2)
trigger7 = StateNo = 221 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 240 && (var(16) || time <= 2)
trigger10 = StateNo = 241 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger11 = StateNo = 250 && (var(16) || time <= 2)
trigger12 = StateNo = 251 && (var(16) || time <= 2)
trigger13 = StateNo = 400
trigger14 = StateNo = 410 && (var(16) || time <= 2)
trigger15 = StateNo = 420 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger16 = StateNo = 430
trigger17 = StateNo = 440 && (var(16) || time <= 2)
trigger18 = StateNo = 450 && (var(16) || time <= 2)
trigger19 = StateNo = 195 && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5200
triggerall = !var(59)
triggerall = !(var(0)&2**10)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 240 && time <= 2
trigger10 = StateNo = 241 && time <= 2
trigger11 = StateNo = 250 && time <= 2
trigger12 = StateNo = 251 && time <= 2
trigger13 = StateNo = 400 && time <= 2
trigger14 = StateNo = 410 && time <= 2
trigger15 = StateNo = 420 && time <= 2
trigger16 = StateNo = 430 && time <= 2
trigger17 = StateNo = 440 && time <= 2
trigger18 = StateNo = 450 && time <= 2
trigger19 = (StateNo = [195,799]) && var(36) && var(16)  
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 240 && time <= 2
trigger10 = StateNo = 241 && time <= 2
trigger11 = StateNo = 250 && time <= 2
trigger12 = StateNo = 251 && time <= 2
trigger13 = StateNo = 400 && time <= 2
trigger14 = StateNo = 410 && time <= 2
trigger15 = StateNo = 420 && time <= 2
trigger16 = StateNo = 430 && time <= 2
trigger17 = StateNo = 440 && time <= 2
trigger18 = StateNo = 450 && time <= 2
trigger19 = (StateNo = [195,799]) && var(36) && var(16)  
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger21 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger22 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger23 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 240 && time <= 2
trigger10 = StateNo = 241 && time <= 2
trigger11 = StateNo = 250 && time <= 2
trigger12 = StateNo = 251 && time <= 2
trigger13 = StateNo = 400 && time <= 2
trigger14 = StateNo = 410 && time <= 2
trigger15 = StateNo = 420 && time <= 2
trigger16 = StateNo = 430 && time <= 2
trigger17 = StateNo = 440 && time <= 2
trigger18 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 240 && time <= 2
trigger10 = StateNo = 241 && time <= 2
trigger11 = StateNo = 250 && time <= 2
trigger12 = StateNo = 251 && time <= 2
trigger13 = StateNo = 400 && time <= 2
trigger14 = StateNo = 410 && time <= 2
trigger15 = StateNo = 420 && time <= 2
trigger16 = StateNo = 430 && time <= 2
trigger17 = StateNo = 440 && time <= 2
trigger18 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 201 && time <= 2
trigger4 = StateNo = 210 && time <= 2
trigger5 = StateNo = 211 && time <= 2
trigger6 = StateNo = 220 && time <= 2
trigger7 = StateNo = 221 && time <= 2
trigger8 = StateNo = 230 && time <= 2
trigger9 = StateNo = 240 && time <= 2
trigger10 = StateNo = 241 && time <= 2
trigger11 = StateNo = 250 && time <= 2
trigger12 = StateNo = 251 && time <= 2
trigger13 = StateNo = 400 && time <= 2
trigger14 = StateNo = 410 && time <= 2
trigger15 = StateNo = 420 && time <= 2
trigger16 = StateNo = 430 && time <= 2
trigger17 = StateNo = 440 && time <= 2
trigger18 = StateNo = 450 && time <= 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time <= 2
trigger3 = StateNo = 610 && time <= 2
trigger4 = StateNo = 620 && time <= 2
trigger5 = StateNo = 630 && time <= 2
trigger6 = StateNo = 640 && time <= 2
trigger7 = StateNo = 650 && time <= 2

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = P2StateType = S || P2StateType = C
trigger1 = P2MoveType != H || var(16)

;---------------------------------------------------------------------------
;�ߋ���������p���`
[State -1, Taunt]
type = ChangeState
value = 201
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 400 && Time > 4
trigger5 = StateNo = 430 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger7 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger8 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger9 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger10 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 400 && Time > 4
trigger5 = StateNo = 430 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger7 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger8 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger9 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger10 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-24,24]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 400 && Time > 4
trigger5 = StateNo = 430 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger7 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger8 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger9 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger10 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 251
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 400 && Time > 4
trigger5 = StateNo = 430 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger7 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger8 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger9 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger10 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 201 && Time > 4
trigger4 = StateNo = 400 && Time > 4
trigger5 = StateNo = 430 && Time > 4
trigger6 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger7 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger8 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger9 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger10 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)  
trigger3 = (StateNo = [1500,2999]) && (var(36) = 1||var(36) = 2) && var(16)
trigger4 = StateNo = 1101 && animelemtime(7) > 0 && var(16)
trigger5 = StateNo = 1201 && animelemtime(4) > 0 && var(16)
trigger6 = StateNo = 1402 && animelemtime(2) > 0 && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0
 
;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
