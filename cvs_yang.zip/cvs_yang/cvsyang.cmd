
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

[Command]
name = "CPU31"
command = U, D, F, U, D
time = 1

[Command]
name = "CPU32"
command = U, B, F, U, D
time = 1

[Command]
name = "CPU33"
command = U, D, D, U, D
time = 1

[Command]
name = "CPU34"
command = F, B, U, U, D
time = 1

[Command]
name = "CPU35"
command = U, F, U, B, U, D
time = 1

[Command]
name = "CPU36"
command = U, D, B, U, D
time = 1

[Command]
name = "CPU37"
command = F, F, B, U, D
time = 1

[Command]
name = "CPU38"
command = U, D, U, U, D
time = 1

[Command]
name = "CPU39"
command = F, B, B, U, D
time = 1

[Command]
name = "CPU40"
command = F, F, B, B, U, D
time = 1

[Command]
name = "CPU41"
command = U, U, F, U, D
time = 1

[Command]
name = "CPU42"
command = U, B, B, U, D
time = 1

[Command]
name = "CPU43"
command = U, B, F, F, U, D
time = 1

[Command]
name = "CPU44"
command = U, F, B, U, U, D
time = 1

[Command]
name = "CPU45"
command = U, B, F, U, U, D
time = 1

[Command]
name = "CPU46"
command = U, B, B, B, U, D
time = 1

[Command]
name = "CPU47"
command = U, D, B, F, U, D
time = 1

[Command]
name = "CPU48"
command = U, D, B, D, U, D
time = 1

[Command]
name = "CPU49"
command = U, D, F, U, U, D
time = 1

[Command]
name = "CPU50"
command = U, D, U, B, U, D
time = 1


[Command]
name = "��V�o���w"
command = ~D, DB, B, D, DB, a
time = 21

[Command]
name = "��V�o���w"
command = ~D, DB, B, D, DB, ~a
time = 21

[Command]
name = "��V�o���w"
command = ~D, DB, B, D, DB, b
time = 21

[Command]
name = "��V�o���w"
command = ~D, DB, B, D, DB, ~b
time = 21

[Command]
name = "��V�o���w"
command = ~D, DB, B, D, DB, c
time = 21

[Command]
name = "��V�o���w"
command = ~D, DB, B, D, DB, ~c
time = 21



[Command]
name = "�����A��1"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "�����A��1"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "�����A��2"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "�����A��2"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "�����A��3"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "�����A��3"
command = ~D, DF, F, D, DF, ~z
time = 21

[Command]
name = "Tenshi-Senkyuutai L"
command = ~D, DF, F, D, DF, F, a
time = 21

[Command]
name = "Tenshi-Senkyuutai L"
command = ~D, DF, F, D, DF, F, ~a
time = 21

[Command]
name = "Tenshi-Senkyuutai M"
command = ~D, DF, F, D, DF, F, b
time = 21

[Command]
name = "Tenshi-Senkyuutai M"
command = ~D, DF, F, D, DF, F, ~b
time = 21

[Command]
name = "Tenshi-Senkyuutai H"
command = ~D, DF, F, D, DF, F, c
time = 21

[Command]
name = "Tenshi-Senkyuutai H"
command = ~D, DF, F, D, DF, F, ~c
time = 21


[Command]
name = "mantis strike 1"
command = ~D, DF, F, x
time = 12

[Command]
name = "mantis strike 1"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "mantis strike 2"
command = ~D, DF, F, y
time = 12

[Command]
name = "mantis strike 2"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "mantis strike 3"
command = ~D, DF, F, z
time = 12

[Command]
name =   "mantis strike 3"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "�S�R��1"
command = ~F, D, DF, x
time = 12

[Command]
name = "�S�R��1"
command = ~F, D, DF, ~x
time = 12

[Command]
name = "�S�R��2"
command = ~F, D, DF, y
time = 12

[Command]
name = "�S�R��2"
command = ~F, D, DF, ~y
time = 12

[Command]
name = "�S�R��3"
command = ~F, D, DF, z
time = 12

[Command]
name = "�S�R��3"
command = ~F, D, DF, ~z
time = 12

[Command]
name = "�Ֆo�q1"
command = ~D, DB, B, x
time = 12

[Command]
name = "�Ֆo�q1"
command = ~D, DB, B, ~x
time = 12

[Command]
name = "�Ֆo�q2"
command = ~D, DB, B, y
time = 12

[Command]
name = "�Ֆo�q2"
command = ~D, DB, B, ~y
time = 12

[Command]
name = "�Ֆo�q3"
command = ~D, DB, B, z
time = 12

[Command]
name = "�Ֆo�q3"
command = ~D, DB, B, ~z
time = 12

[Command]
name = "�Ֆo�q4"
command = ~D, DB, B, x+y
time = 12

[Command]
name = "�Ֆo�q4"
command = ~D, DB, B, y+z
time = 12

[Command]
name = "�Ֆo�q4"
command = ~D, DB, B, z+x
time = 12

[Command]
name = "���|��1"
command = ~D, DF, F, a
time = 12

[Command]
name = "���|��1"
command = ~D, DF, F, ~a
time = 12

[Command]
name = "���|��2"
command = ~D, DF, F, b
time = 12

[Command]
name = "���|��2"
command = ~D, DF, F, ~b
time = 12

[Command]
name = "���|��3"
command = ~D, DF, F, c
time = 12

[Command]
name = "���|��3"
command = ~D, DF, F, ~c
time = 12

[Command]
name = "�O���]�g"
command = ~F, DF, D, DB, B, a
time = 18

[Command]
name = "�O���]�g"
command = ~F, DF, D, DB, B, ~a
time = 18

[Command]
name = "�O���]�g"
command = ~F, DF, D, DB, B, b
time = 18

[Command]
name = "�O���]�g"
command = ~F, DF, D, DB, B, ~b
time = 18

[Command]
name = "�O���]�g"
command = ~F, DF, D, DB, B, c
time = 18

[Command]
name = "�O���]�g"
command = ~F, DF, D, DB, B, ~c
time = 18


[Command]
name = "longjump"
command = D, $U
time = 10

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10


[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10


[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1


[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1


[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command]
name = "block"
command = F
time = 1

[Command]
name = "block2"
command = D
time = 1

[Command]
name = "up"
command = U
time = 3

[Command]
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1




;   --- Uno Tag System [Type-S] Command definitions ---

[Command]
name = "aHsoNn"
command = ~D, D, D, z+c
Time = 25

[Command]
name = "sheoun"
command = ~D, DF, F, z+c
Time = 25

[Command]
name = "palit"
command = y+a
Time = 2

[Command]
name = "turtleuno"
command =  x+y
Time = 2


[Statedef -1]


[State -1, Partner Assist]
type = VarSet
sysvar(4) = 10
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 35 && Time > 0
triggerall = teammode = Simul
triggerall = StateNo != [3000,1251199]
triggerall = hitdefattr != SCA, HA, HP, HT
triggerAll = StateNo != [130,152]
triggerall = !(StateNo = [5000,5500])
trigger1 = command = "turtleuno"
trigger1 = var(59) <=  0
trigger2 = var(59) >  0
trigger2 = !ctrl && Movetype = A
trigger2 = Random < (((2 * ifelse(MoveContact, ifelse(MoveHit, 2, 3),1)) + (UniqHitCount * 2)) *(var(59)**2/64.0))
trigger3 = var(59) >  0
trigger3 = StateNo = [190,199]
trigger3 = AnimElemNo(0) = 2
ignorehitpause = 1

[State -1, Team Hyper Attack]
type = ChangeState
value = 1251125
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = Partner, life > 0
triggerall = power >= 3000
triggerall = RoundState = 2 
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 9		
triggerall= (StateType != A)
trigger1 = command = "sheoun"
trigger1 = (Ctrl = 1)
trigger1 = var(59) <=  0
trigger2 = command = "sheoun"
trigger2 = Anim = [200,1000]
trigger2 = movetype = A
trigger2 = hitdefattr = SC, NA
trigger2 = MoveContact
trigger2 = var(59) <=  0
trigger3 = var(59) > 0 && ctrl
trigger3 = Random < (10 + ((Life < Lifemax/6)*3))
trigger3 = NumEnemy && enemy, pos x = [0,200]
trigger4 = var(59) >  0 > 0
trigger4 = Anim = [200,1000]
trigger4 = movetype = A
trigger4 = hitdefattr = SC, NA
trigger4 = MoveContact
trigger4 = Random < (11 + ((MoveHit)*5) + ((Life < Lifemax/6)*5))
ignorehitpause = 1

[State -1, Delayed Hyper]
type = ChangeState
value = 1251127
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0
triggerall = power >= 1000
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time > 2 && Time > 45
triggerall = movetype = A
triggerall = StateNo = [2000,1251100]
triggerall = hitdefattr = SCA, HA, HP, HT || (StateNo >= 2000 && StateNo < 4000 && (hitcount < 8 || NumTarget && Target, GetHitVar(hitTime) >= 0))
trigger1 = command = "sheoun"
trigger1 = var(59) <=  0
trigger2 = var(59) >  0
trigger2 = NumTarget && MoveContact
trigger2 = Random < (10*(var(59)**2/64.0) + (Uniqhitcount*((Life < Partner,Life)*2)))
trigger2 = Partner, Time > 35
trigger3 = var(59) >  0
trigger3 = Partner, Time > 25 && Time > 25
trigger3 = HitCount >= 6
trigger3 = Random < (2*(3*(Lifemax/5) && Life < Partner, Life) * Uniqhitcount * ifelse(hitcount > 9, 2, 1))
ignorehitpause = 1

[State -1, UNO Mode]
type = ChangeState
value = 1251128
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0 && Power >= 1000
triggerall = Life <= (Lifemax/8)
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 20
triggerall = (StateType != A) && ((Ctrl = 1) || StateNo = 0 || (Movetype = A && hitdefattr = SC, NA))
trigger1 = command = "aHsoNn"
trigger1 = var(59) <=  0
trigger2 = var(59) >  0
trigger2 = Partner, Life < Lifemax/4
trigger2 = Random < ((25 + ifelse((Partner, Life < Lifemax/6), 25, 5))*(var(59)**2/64.0))

[State -1, Quick Change]
type = Helper
Helpertype = Normal
ID = 1251105
StateNo = 1251105
name = "Cross"
pos =0,0
postype = p1
ownpal = 0
supermoveTime = 9999
pausemoveTime = 9999
triggerall = !NumHelper(1251105)
triggerall = NumPartner
triggerall = power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),500,1000)
triggerall = Partner, life > 0
triggerall = Movetype = A && !(Hitdefattr = SCA, HT, HA, HP)
triggerall = (Partner, StateNo = 1251112 || Partner, StateNo = 1251114) && Time > 1
triggerall = (Partner, sysvar(4) != [8,9])
triggerall = StateNo = [200,2900]
triggerall = StateNo != [3000,1251116]
triggerall = NumTarget > 0 && Target, StateNo != [5110,5955]
trigger1 = command = "palit"
trigger1 = var(59) <=  0
trigger2 = var(59) >  0
trigger2 = MoveContact && UniqHitCount >= 3
trigger2 = Random < (((50*(var(59)**2/64.0)) + ((hitdefattr = SCA, SA)*10) + ifelse(lifemax/life > 25, 25, lifemax/life)) * ifelse((Target, statetype = A), 0.8, 1)*(1 + (Life < Lifemax*0.4)*1))
trigger2 = Partner, Life > Lifemax/8 || Life < Partner, Life
trigger2 = Partner, Time >= 120
trigger3 = var(59) >  0
trigger3 = Partner, Time > 30
trigger3 = Random < ((25*(2*(Life = (Lifemax/4) && Life < Partner, Life)) *(var(59)**2/64.0))*Uniqhitcount)
trigger3 = MoveContact
ctrl = 0
ignorehitpause = 1

[State -1, Tag out]
type = ChangeState
value = 1251110
triggerall = teammode = simul
;triggerall = sysvar(4) = 1 || sysvar(4) = 15
;triggerall = NumPartner && NumEnemy
triggerall = RoundState = 2 
;triggerall = Partner, life > 0 ||  Partner, life < 0
;triggerall = Partner, StateNo = [1251112,1251114]
;triggerall = Partner, Time >= 0	
triggerall = StateNo != [1251101,1251133]
triggerall = (MoveType != A && StateType != A) && (Ctrl = 1) || StateNo = 0
trigger1 = command = "palit"
trigger1 = var(59) <=  0
trigger2 = var(59) >  0
trigger2 = Random < (ifelse((LifeMax/Life > 120), 120, LifeMax/Life)+((EnemyNear,statetype=L)*25))
trigger2 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond
trigger2 = EnemyNear, movetype != A
trigger3 = var(59) >  0
trigger3 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond && Life < LifeMax * (LifeMax*0.55)
trigger3 = Random < ((ifelse(LifeMax/Life > 10, 10, LifeMax/Life) + (10+ifelse((EnemyNear, StateNo > 5000),25,1))) * ifelse((Life < Partner, Life), 1.45, 0.5))
trigger3 = Partner, Time > 1 * TicksPerSecond
trigger3= EnemyNear, statetype = L || p2bodydist x > 250 && EnemyNear, movetype != A
trigger4 = var(59) >  0
trigger4 = Life < 150 && Life < Partner, Life
trigger4 = EnemyNear, statetype = L || p2bodydist x > 200 && EnemyNear, movetype != A
trigger4 = Random < (125*(var(59)**2/64.0))

[State -1, C_6]
type = CtrlSet
value = 1
triggerall = RoundState = 2 && NumPartner
triggerall = NumTarget && Target, StateNo != [200,4999]
triggerall = StateNo != 1251106 && !Ctrl
triggerall = (Partner, StateNo != [1251128,1251129]) && (Partner, PrevStateNo != [1251128,1251129])
trigger1 = command="x"||command="y"||command="z"||command="a"||command="b"||command="c" 
trigger1 = sysvar(4) = 7
trigger1 = Movetype = A
trigger1 = MoveContact
trigger1 = hitdefattr = SCA, NA, SA
trigger1 = StateNo != PrevStateNo
trigger1 = Time > 2
trigger2 = PrevStateNo = 1251106
ignorehitpause = 0

; ------ Uno Tag System [Type-S] END LINE -------

;  ;]





[State -1, AI]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
trigger31  = command = "CPU31"
trigger32  = command = "CPU32"
trigger33  = command = "CPU33"
trigger34  = command = "CPU34"
trigger35  = command = "CPU35"
trigger36  = command = "CPU36"
trigger37  = command = "CPU37"
trigger38  = command = "CPU38"
trigger39  = command = "CPU39"
trigger40  = command = "CPU40"
trigger41  = command = "CPU41"
trigger42  = command = "CPU42"
trigger43  = command = "CPU43"
trigger44  = command = "CPU44"
trigger45  = command = "CPU45"
trigger46  = command = "CPU46"
trigger47  = command = "CPU47"
trigger48  = command = "CPU48"
trigger49  = command = "CPU49"
trigger50  = command = "CPU50"
var(59) = 1




[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 5210
triggerall = Var(59) = 1
triggerall = Alive
triggerall = CanRecover
triggerall = Vel Y > -1
triggerall = Pos Y >= -40
triggerall = StateNo = 5050
trigger1 = random = [150,200]



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 5200
triggerall = var(59) = 1
triggerall = ((var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6) && !(var(0)&2**10)) || CanRecover
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = random <= 400



[state -1, Guard]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 40
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist || P2bodydist X = [-60,120]
triggerall = ctrl || stateno = 21
triggerall = statetype != A
trigger1 = enemynear,HitDefAttr = SC, NT,ST,HT
trigger1 = random = [0,700]



[State -1]
type = null
value = 870
triggerall = var(59) = 1
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2life > 150 || (100*life/const(data.life))<=15
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-1,70]
trigger1 = P2StateType = S || P2StateType = C
trigger1 = P2MoveType = A
trigger1 = enemynear,time >= (4+random%10)
trigger1 = random <= 300



[State -1]
type = null
value = 875
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl






[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 3100
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (4+random%10)
trigger1 = P2bodydist X = [-1,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = random = [100,700]
trigger2 = P2bodydist X = [-1,30]
trigger2 = P2bodydist Y = [-50,-30]
trigger2 = P2MoveType != H
trigger2 = enemynear,Vel Y > 0
trigger2 = random = [100,700]
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 3000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && prevstateno = 5120 && time <= 1
triggerall = enemynear,time >= (4+random%10)
trigger1 = P2bodydist X = [-1,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = random = [200,700]
ignorehitpause = 0




[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1100
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = (var(20) = 2 && Power >= 3000) || (var(20) = 6 && Power >= 1000)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
trigger1 = P2bodydist X = [0,50]
trigger1 = stateno = 320
trigger1 = var(17) > 1
trigger1 = var(36) = 1 && numtarget
trigger1 = target,statetype != A
trigger1 = MoveType = A
trigger1 = random < 900
ignorehitpause = 0





[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 3100
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-1,50]
trigger1 = StateNo = 1100
trigger1 = !var(5)
trigger1 = var(36) = 1 && numtarget
trigger1 = target,statetype != A
trigger1 = var(20) = 2 || var(20) = 6
trigger1 = var(17) >= 2
trigger2 = P2bodydist X = [-1,50]
trigger2 = StateNo = 320
trigger2 = var(36) = 1 && numtarget
trigger2 = var(17) >= 2
trigger3 = StateNo = 340
trigger3 = var(36) = 1 && numtarget
trigger3 = var(17) >= 2
trigger4 = prevstateno = [4000,4199]
trigger4 = P2bodydist X = [0,30]
trigger4 = P2bodydist Y = [0,20]
trigger4 = ctrl
trigger4 = random%4!=3
trigger5 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger5 = P2bodydist X = [-1,40]
trigger5 = P2bodydist Y = [-30,0]
trigger5 = P2MoveType = A
trigger5 = enemynear,time >= (4+random%10)
trigger5 = !(var(16) && numtarget)
trigger5 = random = [500,700]
trigger6 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = P2bodydist X = [-1,40]
trigger6 = P2bodydist Y = [-50,-30]
trigger6 = P2MoveType = A
trigger6 = enemynear,time >= (4+random%10)
trigger6 = enemynear,Vel Y > 0
trigger6 = !(var(16) && numtarget)
trigger6 = random = [300,700]
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 3300
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3)
triggerall = !NumHelper(2000)
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl
trigger1 = P2bodydist X = [-20,40]
trigger1 = P2bodydist Y = [0,60]
trigger1 = P2MoveType = A
trigger1 = enemynear,time >= (4+random%10)
trigger1 = Pos Y > -20
trigger1 = Vel Y > 0
trigger1 = !(var(16) && numtarget)
trigger1 = random = [500,700]
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 3000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (((var(0)&2**3)|| var(14) || var(16)) > 0)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = ((!var(20)||var(20)=6)&&Power>=3000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14)>0)||(var(15)&&Power>=1000)||(var(0)&2**3)>0
trigger1 = P2bodydist X = [-1,50]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,time >= (4+random%10)
trigger1 = !(var(16) && numtarget)
trigger1 = random = [500,600]
trigger2 = !(((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) )
trigger2 = P2bodydist X = [-1,50]
trigger2 = stateno = 320
trigger2 = var(17) > 1
trigger2 = var(36) = 1 && numtarget
trigger2 = target,statetype != A
trigger2 = !(var(16) && numtarget)
trigger2 = target,life > 50 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
trigger2 = random < 700-((var(20)=1)*600)
trigger3 = P2bodydist X = [0,20]
trigger3 = stateno = 221
trigger3 = var(17) > 2
trigger3 = var(36) = 1 && numtarget
trigger3 = target,statetype != A
trigger3 = !(var(16) && numtarget)
trigger4 = stateno = 410
trigger4 = var(17) > 1
trigger4 = var(36) = 1 && numtarget
trigger4 = target,statetype != A
trigger4 = !(var(16) && numtarget)
trigger4 = MoveType = A
trigger4 = target,life > 50 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
trigger4 = random < 600-((var(20)=1)*500)
trigger1 = P2bodydist X > 15
trigger5 = stateno = 430 && (prevstateno = 400 || prevstateno = 430)
trigger5 = var(17) > 1
trigger5 = var(36) = 1 && numtarget
trigger5 = target,statetype != A
trigger5 = target,life > 50 || (100*life/const(data.life))<=20 || var(20) = 3 || var(20) = 5
trigger5 = !(var(16) && numtarget)
trigger5 = MoveType = A
trigger5 = random < 900-((var(20)=1)*800)
trigger6 = P2bodydist X = [-1,50]
trigger6 = StateNo = 1100
trigger6 = !var(5)
trigger6 = var(36) = 1 && numtarget
trigger6 = target,statetype != A
trigger6 = var(20) = 2 || var(20) = 6
trigger6 = var(17) >= 2
trigger7 = prevstateno = [4000,4199]
trigger7 = P2bodydist X = [-1,30]
trigger7 = P2StateType != A
trigger7 = ctrl
trigger7 = random%4!=3
ignorehitpause = 0




[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1100
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [80,150]
trigger1 = P2bodydist Y = [-10,0]
trigger1 = P2MoveType != A
trigger1 = !(var(16) && numtarget)
trigger1 = MoveType = A
trigger1 = random = [500,550]
trigger2 = P2bodydist X = [0,50]
trigger2 = stateno = 320
trigger2 = var(36) = [1,2]
trigger2 = P2StateType != A
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
trigger2 = random < 500
trigger3 = stateno = 3200
trigger3 = numhelper(2000)
trigger3 = helper(2000),stateno = 2801 && helper(2000),time = 1
trigger3 = var(5) = 1
trigger3 = P2statetype != A
trigger3 = !(var(16) && numtarget)
trigger4 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger4 = numhelper(2000)
trigger4 = helper(2000),stateno = 2802
trigger4 = numtarget
trigger4 = target,Vel Y = [-4,-1]
trigger5 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger5 = P2bodydist Y = [-300,-220]
trigger5 = numtarget
trigger5 = target,stateno = 3850
trigger5 = var(45)
trigger5 = !(var(16) && numtarget)
trigger6 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = P2bodydist X >= 0 || frontedgedist < 30
trigger6 = P2bodydist Y = [-160,-120)
trigger6 = numtarget
trigger6 = target,stateno != 3850
trigger6 = target,Vel Y > -3
trigger6 = prevstateno != 1100
trigger6 = var(45)
trigger6 = !(var(16) && numtarget)
trigger7 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger7 = P2bodydist X >= 0 || frontedgedist < 30
trigger7 = P2bodydist Y = [-180,-160)
trigger7 = numtarget
trigger7 = target,stateno != 3850
trigger7 = target,Vel Y > 3
trigger7 = prevstateno != 1100
trigger7 = var(45)
trigger7 = !(var(16) && numtarget)
trigger8 = P2bodydist X >= -10 || frontedgedist < 30
trigger8 = P2bodydist Y = [-200,-180)
trigger8 = StateNo = 1100
trigger8 = animtime = 0
trigger8 = var(36) = 1 && numtarget
trigger8 = target,statetype = A
trigger8 = target,Vel Y > 3
trigger9 = stateno = 3000
trigger9 = animelemtime(26) > 0
trigger9 = var(36) = 1
trigger9 = var(5) = 1
trigger9 = !(var(16) && numtarget)
trigger8 = random < 800
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1000
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
trigger1 = ctrl || (stateno = 21 && vel X < 0) || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X > 150
trigger1 = P2bodydist Y = [-20,0]
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = !enemynear,numproj
trigger1 = !(var(16) && numtarget)
trigger1 = random = [500,600]
trigger2 = stateno = 400 || stateno = 430
trigger2 = var(36) = 1 && numtarget
trigger2 = target,statetype = S
trigger2 = !(var(16) && numtarget)
trigger2 = MoveType = A
trigger2 = random < 800-(!(var(17)>1)*750)
trigger3 = stateno = 410
trigger3 = var(36) = 1 && numtarget
trigger3 = target,statetype = S
trigger3 = !(var(16) && numtarget)
trigger3 = MoveType = A
trigger3 = random < 800-(!(var(17)>1)*750)
trigger4 = P2bodydist X > 40
trigger4 = stateno = 430
trigger4 = var(36) = 1 && numtarget
trigger4 = target,statetype = S
trigger4 = var(17) > 1
trigger4 = !(var(16) && numtarget)
trigger4 = MoveType = A
trigger4 = random < 800-(!(var(17)>1)*750)
trigger5 = stateno = 440
trigger5 = animelemtime(6) < 0
trigger5 = var(36) = 1 && numtarget
trigger5 = target,statetype != A
trigger5 = !(var(16) && numtarget)
trigger5 = MoveType = A
trigger5 = random < 800-(!(var(17)>1)*250)
trigger6 = stateno = 320
trigger6 = var(36) = 1 && numtarget
trigger6 = target,statetype = S
trigger6 = var(17) > 1
trigger6 = !(var(16) && numtarget)
trigger6 = MoveType = A
trigger6 = random < 800 || P2bodydist X > 20
trigger7 = ctrl || stateno = 21
trigger7 = P2bodydist Y = [-80,-30]
trigger7 = var(45) || var(23) = 1
trigger7 = !(var(16) && numtarget)
trigger7 = !numhelper(2000)
trigger7 = !(((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3) )
trigger8 = ctrl || stateno = 21
trigger8 = P2bodydist Y = [-60,-30]
trigger8 = var(45) || var(23) = 1
trigger8 = !numhelper(2000)
trigger8 = !(var(16) && numtarget)
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1400
triggerall = var(59) = 1
triggerall = statetype = S
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
triggerall = !var(16)
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || (stateno = 21 && vel X > 0) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = Random = [0,750]
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1350
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
trigger1 = P2bodydist X = [-1,20]
trigger1 = stateno = 320
trigger1 = var(36) = [1,2]
trigger1 = P2StateType != A
trigger1 = !(var(16) && numtarget)
trigger1 = random < 100
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1300
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [-1,20]
trigger1 = P2stateno = 5120
trigger1 = enemynear,animtime = -13
trigger1 = !(var(16) && numtarget)
trigger1 = random = [500,650]
trigger2 = P2bodydist X = [-1,20]
trigger2 = stateno = 410
trigger2 = var(36) = 1 && numtarget
trigger2 = target,statetype != A
trigger2 = !(var(16) && numtarget)
trigger2 = random > 800-((var(17)>1)*700)
trigger3 = P2bodydist X = [-1,20]
trigger3 = stateno = 320
trigger3 = var(36) = [1,2]
trigger3 = P2StateType != A
trigger3 = !(var(16) && numtarget)
trigger3 = MoveType = A
trigger3 = random = [200,700]
ignorehitpause = 0



[State -1, hadouken]
type = null
value = 1200
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
ignorehitpause = 0




[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 850
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = (power < 1000 && var(20) = 3 && !var(14)) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = !inguarddist
triggerall = !enemynear,numproj
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 140
trigger1 = Random = [700,920]
trigger2 = P2bodydist X >= 140
trigger2 = P2StateType = L
trigger2 = teammode = single
trigger2 = Random = [250,500]



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2Life > 150
triggerall = !((100*life/const(data.life))<=20 && P2bodydist X <= 160)
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 100
trigger1 = Random <= 500-((var(20)=6)*400)
trigger2 = P2StateType = L
trigger2 = Random <= 700-((var(20)=6)*600)



[State -1, Throw]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 900
triggerall = var(59) = 1
triggerall = statetype = S
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = enemynear,prevstateno != [5000,5999]
triggerall = !var(16)
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21
trigger1 = Random = [650,700]



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 300
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !NumHelper(2000)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2StateType = C
trigger1 = P2MoveType != A
trigger1 = P2bodydist X = [20,50]
trigger1 = !(var(16) && numtarget)
trigger1 = Random <= 20
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 3300
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3)
triggerall = !NumHelper(2000)
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-30,50]
trigger1 = P2bodydist Y = [-10,60]
trigger1 = numtarget
trigger1 = target,Vel Y >= -4
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = ctrl
trigger1 = var(45) || var(23) = 1
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 700
triggerall = var(59) = 1
triggerall = !(var(0)&2**5)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = Vel X >= 0
triggerall = Pos Y <= -55
triggerall = !(enemynear,numproj&&inguarddist)
trigger1 = P2bodydist X = [30,150]
trigger1 = P2StateType = S || P2StateType = C
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = Vel Y = [-5,1]
trigger1 = Ctrl
trigger1 = !(var(16) && numtarget)
trigger1 = Random <= ifelse(ceil(P2bodydist X)*15<0,0,ifelse(ceil(P2bodydist X)*15>1000,1000,ceil(P2bodydist X)*15))
trigger2 = ctrl
trigger2 = P2bodydist Y <= -30
trigger2 = var(45) || var(23) = 1
trigger2 = !(var(16) && numtarget)
trigger3 = ctrl
trigger3 = numtarget
trigger3 = P2bodydist Y >= -30
trigger3 = target,Vel Y <= -1
trigger3 = var(45) || var(23) = 1
trigger3 = !(var(16) && numtarget)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 221
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2bodydist X = [-25,25]
triggerall = P2StateType != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !NumHelper(2000)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (((var(0)&2**3)|| var(14) || var(16)) > 0)
trigger1 = numtarget
trigger1 = target,stateno = 1405
trigger1 = target,animtime = -5
trigger1 = !(var(16) && numtarget)
trigger1 = Random = [100,500]
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 200
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != C
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !NumHelper(2000)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-1,30]
trigger1 = P2bodydist Y = [-20,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(P2StateType = A && P2MoveType = H)
trigger1 = prevstateno != 200
trigger1 = !(var(16) && numtarget)
trigger1 = P2stateno != 1405 || (P2stateno = 1405 && animtime = -4)
trigger1 = Random = [100,900]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X >= 120
trigger2 = P2MoveType != A
trigger2 = !(var(16) && numtarget)
trigger2 = prevstateno != 200
trigger2 = !inguarddist
trigger2 = Random = [600,650]
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = numtarget
trigger3 = target,stateno = 1405
trigger3 = target,animtime = -4
trigger3 = !(var(16) && numtarget)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 430
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
triggerall = !NumHelper(2000)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-1,30]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = P2stateno != 1405
trigger1 = prevstateno != 430
trigger1 = !(var(16) && numtarget)
trigger1 = Random <= 300
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2MoveType = H
trigger2 = P2stateno != 1405
trigger2 = P2bodydist X = [-1,30]
trigger2 = !(var(16) && numtarget)
trigger2 = Random >= 600
trigger3 = P2bodydist X = [-1,30]
trigger3 = StateNo = 430
trigger3 = time = 5
trigger3 = var(36) = [1,2]
trigger3 = !(var(16) && numtarget)
trigger3 = Random <= 900-(!var(17)*700)
trigger4 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger4 = P2bodydist X >= 160
trigger4 = P2MoveType != A
trigger4 = !(var(16) && numtarget)
trigger4 = !inguarddist
trigger4 = Random = [850,870]
trigger5 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger5 = P2bodydist X = [-1,30]
trigger5 = P2stateno != 1405
trigger5 = P2StateType = S
trigger5 = !(var(16) && numtarget)
trigger5 = Random = [350,450]
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 440
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !NumHelper(2000)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [40,65]
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = P2stateno != 1405
trigger1 = !(var(16) && numtarget)
trigger1 = Random = [750,950]
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = ifelse((P2BodyDist X = [-25,25]),211,210)
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !NumHelper(2000)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-1,20]
trigger1 = P2bodydist Y = [-20,0]
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = !(P2StateType = A && P2MoveType = H)
trigger1 = P2stateno != 1405
trigger1 = !(var(16) && numtarget)
trigger1 = Random = [700,900]
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 410
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !NumHelper(2000)
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [25,55]
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = P2stateno != 1405 || (P2stateno = 1405 && enemynear,animtime = -5)
trigger1 = !(var(16) && numtarget)
trigger1 = Random = [850,950]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [25,55]
trigger2 = numtarget
trigger2 = target,stateno = 1405
trigger2 = target,animtime = -5
trigger2 = !(var(16) && numtarget)
trigger2 = Random = [400,950]
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 240
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [-1,30]
trigger1 = P2bodydist Y = [-100,-80]
trigger1 = enemynear,Vel X >= 0
trigger1 = enemynear,Vel Y > 2
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = Random = [200,500]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [-30,20]
trigger2 = P2bodydist Y = [-150,-70]
trigger2 = var(45) || var(23) = 1
trigger2 = !(var(16) && numtarget)
trigger2 = target,Vel Y > 3
trigger2 = !numhelper(2000)
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X = [-30,20]
trigger3 = P2bodydist Y = [-140,-70]
trigger3 = var(45) || var(23) = 1
trigger3 = !(var(16) && numtarget)
trigger3 = target,Vel Y > -5
trigger3 = !numhelper(2000)
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 220
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = !(P2BodyDist X = [-25,25])
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [70,90]
trigger1 = P2bodydist Y = [-20,0]
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = !(P2StateType = A && P2MoveType = H)
trigger1 = !(var(16) && numtarget)
trigger1 = Random = [750,800]
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 250
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = !(P2BodyDist X = [-25,25])
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [70,80]
trigger1 = P2bodydist Y = [-20,0]
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = !(P2StateType = A && P2MoveType = H)
trigger1 = !(var(16) && numtarget)
trigger1 = Random = [680,700]
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 400
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !NumHelper(2000)
trigger1= ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 120
trigger1 = !(P2MoveType = A && P2stateno = [3000,3999])
trigger1 = !(var(16) && numtarget)
trigger1 = prevstateno != 400
trigger1 = !inguarddist
trigger1 = Random = [600,610]
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 420
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = !(var(16) && numtarget)
trigger1 = P2bodydist X = [20,50]
trigger1 = P2bodydist Y = [-80,-50]
trigger1 = enemynear,Vel X >= 0
trigger1 = enemynear,Vel Y > .01
trigger1 = P2StateType = A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = Random = [300,500]
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 450
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !enemynear,numproj
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2StateType = A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = P2bodydist X = [50,100]
trigger1 = P2bodydist Y = [-50,-30]
trigger1 = enemynear,Vel X >= 0
trigger1 = enemynear,Vel Y > 0
trigger1 = !(var(16) && numtarget)
trigger1 = Random <= 400
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = 360
trigger2 = P2StateType != A
trigger2 = P2MoveType = I
trigger2 = !(var(16) && numtarget)
trigger2 = Random <= 200
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 600
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-30,20]
trigger1 = P2bodydist Y = [-40,60]
trigger1 = Pos Y < -50
trigger1 = Vel Y > -3
trigger1 = ctrl
trigger1 = random = [100,450]













ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 620
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = Vel X
trigger1 = P2bodydist X = [-1,60]
trigger1 = P2bodydist Y = [0,80]
trigger1 = Pos Y < -60
trigger1 = Vel Y > 1
trigger1 = ctrl
trigger1 = random = [100,450]
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 621
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = !Vel X
trigger1 = P2bodydist X = [-1,60]
trigger1 = P2bodydist Y = [-40,30]
trigger1 = Pos Y < -60
trigger1 = Vel Y > -1
trigger1 = ctrl
trigger1 = random = [100,250]
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 640
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-30,60]
trigger1 = P2bodydist Y = [-40,70]
trigger1 = Pos Y < -50
trigger1 = Vel Y > 1
trigger1 = ctrl
trigger1 = random = [100,450]
ignorehitpause = 0



[state -1, Guard]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype != A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,700)

[state -1, Guard]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 120
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype = A
triggerall = !var(16)
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
trigger2 = random <= ifelse(var(20)=2||var(20)=6,50,500)



[State -1, Run Fwd]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 100
triggerall = var(59) = 1
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = statetype != A
triggerall = P2MoveType != A
triggerall = !inguarddist
triggerall = !var(45) && var(23) != 1
trigger1 = P2bodydist X > 100
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = !(var(16) && numtarget)
trigger1 = Random <= 250



[State -1, Run Fwd]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 102
triggerall = var(59) = 1
triggerall = !var(20) || var(20) = 1 || var(20) = 2
triggerall = statetype != A
triggerall = !inguarddist
triggerall = !var(45) && var(23) != 1
trigger1 = P2bodydist X > 200
trigger1 = P2MoveType = I
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = !(var(16) && numtarget)
trigger1 = Random = [270,300]
trigger2 = P2bodydist X > 120
trigger2 = P2StateType = L
trigger2 = Ctrl || (stateno = 21 && anim = 20)
trigger2 = !(var(16) && numtarget)
trigger2 = Random = [150,300]



[State -1, Run Back]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 105
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = !inguarddist
triggerall = !var(45) && var(23) != 1
trigger1 = backedgedist > 60
trigger1 = P2bodydist X <= 50
trigger1 = P2MoveType != A
trigger1 = Ctrl || (stateno = 21 && anim = 21)
trigger1 = !(var(16) && numtarget)
trigger1 = Random = [300,330]



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 800
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = !var(20) || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = !var(45) && var(23) != 1
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 150
trigger1 = !(var(16) && numtarget)
trigger1 = Random <= 25
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [-1,50]
trigger2 = P2MoveType = A
trigger2 = !(var(16) && numtarget)
trigger2 = Random = [430,440]
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 830
triggerall = var(59) = 1
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
triggerall = !var(45) && var(23) != 1
trigger1 = P2bodydist X = [-1,40]
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
trigger1 = Random <= 20
trigger2 = P2bodydist X = [-1,40]
trigger2 = P2MoveType = A
trigger2 = !(var(16) && numtarget)
trigger2 = Random <= 50
ignorehitpause = 0



[State -1, Walk]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = !InGuardDist
triggerall = Ctrl
triggerall = stateno != [10,12]
triggerall = prevstateno != [10,12]
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != 21
triggerall = prevstateno != 21
triggerall = stateno != [120,159]
triggerall = prevstateno != [120,159]
triggerall = !var(45) && var(23) != 1
trigger1 = !(var(16) && numtarget)
trigger1 = random%100!=0
trigger2 = !(var(16) && numtarget)
trigger2 = prevstateno = 1401



[State -1, Jump]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 40
triggerall = var(59) = 1
triggerall = StateType != A
triggerall = ctrl || (stateno = 21 && time > 10) || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
triggerall = P2StateType != L
triggerall = stateno != 52
triggerall = prevstateno != 52
triggerall = !InGuardDist
triggerall = !var(45) && var(23) != 1
trigger1 = P2bodydist X = [30,180]
trigger1 = !(var(16) && numtarget)
trigger1 = Random <= 50




[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 3100
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (((var(0)&2**3)|| var(14) || var(16)) > 0)
triggerall = Command = "Tenshi-Senkyuutai L" ||   Command = "Tenshi-Senkyuutai M"  ||   Command = "Tenshi-Senkyuutai H" || (ceil(fvar(29))&2**22) || (ceil(fvar(29))&2**23) || (ceil(fvar(29))&2**24)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2)
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 350 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 420 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger14 = StateNo = 430
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 300 && (var(16) || time <= 2)
trigger18 = StateNo = 310 && var(16)
trigger19 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 330 && var(16)
trigger21 = StateNo = 340 && (var(16) || (var(36) = 1||var(36) = 2))
trigger22 = StateNo = 350 && var(16)
trigger23 = StateNo = 195 && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger28 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger29 = (StateNo = [1000,1399]) && (var(20) = 2 || var(20) = 6)
trigger30 = (StateNo = [1500,2999]) && (var(20) = 2 || var(20) = 6)
trigger31 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger32 = StateNo = 3005 && (var(20) = 2 || var(20) = 6)
trigger33 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger34 = StateNo = 3305 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 3300
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(16))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || (var(0)&2**3)
triggerall = Command = "��V�o���w" || (ceil(fvar(29))&2**29)
triggerall = !NumHelper(2000)
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(10) < 0))
trigger3 = StateNo = 610 && (var(16) || time <= 2)
trigger4 = StateNo = 620 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger5 = StateNo = 621 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger6 = StateNo = 630 && (var(16) || time <= 2)
trigger7 = StateNo = 640 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger8 = StateNo = 650 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger9 = StateNo = 700 && (var(16) || time <= 2)
trigger10 = StateNo = 710 && (var(16) || time <= 2)
trigger11 = StateNo = 195 && var(36) && var(16)
trigger12 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger13 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger14 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger15 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger16 = StateNo = 195 && (var(20) = 2 || var(20) = 6)
trigger17 = (StateNo = [1000,1399]) && (var(20) = 2 || var(20) = 6)
trigger18 = (StateNo = [1500,2999]) && (var(20) = 2 || var(20) = 6)
trigger19 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger20 = StateNo = 3005 && (var(20) = 2 || var(20) = 6)
trigger21 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger22 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 3000
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || (((var(0)&2**3)|| var(14) || var(16)) > 0)
triggerall = Command = "�����A��1" || Command = "�����A��2" || Command = "�����A��3" || (ceil(fvar(29))&2**22) || (ceil(fvar(29))&2**23) || (ceil(fvar(29))&2**24)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221  && animelemtime(4) <= 2
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 221  && animelemtime(4) <= 2
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || time <= 2)
trigger16 = StateNo = 300 && (var(16) || time <= 2)
trigger17 = StateNo = 310 && var(16)
trigger18 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 330 && var(16)
trigger20 = StateNo = 221  && animelemtime(4) <= 2
trigger21 = StateNo = 350 && var(16)
trigger22 = StateNo = 195 && var(36) && var(16)
trigger23 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger24 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger25 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger26 = StateNo = 195 && (var(20) = 2 || var(20) = 6)

trigger27 = (StateNo = [1500,2999]) && (var(20) = 2 || var(20) = 6)
trigger28 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger29 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger30 = StateNo = 3305 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0








[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1100
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "�S�R��1" || Command = "�S�R��2" || Command = "�S�R��3" || (ceil(fvar(29))&2**11) || (ceil(fvar(29))&2**12) || (ceil(fvar(29))&2**13)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 300 && (var(16) || time <= 2)
trigger18 = StateNo = 310 && var(16)
trigger19 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 330 && var(16)
trigger21 = StateNo = 340 && var(16)
trigger22 = StateNo = 350 && var(16)
trigger23 = StateNo = 195 && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1000
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "mantis strike 1" || Command ="mantis strike 2" || Command = "mantis strike 3" || (ceil(fvar(29))&2**8) || (ceil(fvar(29))&2**9) || (ceil(fvar(29))&2**10)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger7 = StateNo = 230 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 420 && (var(16) || time <= 2)
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || time <= 2)
trigger16 = StateNo = 300 && (var(16) || time <= 2)
trigger17 = StateNo = 310 && var(16)
trigger18 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger19 = StateNo = 330 && var(16)
trigger20 = StateNo = 340 && var(16)
trigger21 = StateNo = 350 && var(16)
trigger22 = StateNo = 195 && var(36) && var(16)
trigger23 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger24 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger25 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger26 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1400
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "�O���]�g" || (ceil(fvar(29))&2**17)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 300 && (var(16) || time <= 2)
trigger18 = StateNo = 310 && var(16)
trigger19 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 330 && var(16)
trigger21 = StateNo = 340 && var(16)
trigger22 = StateNo = 350 && var(16)
trigger23 = StateNo = 195 && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1350
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "�Ֆo�q4" || (ceil(fvar(29))&2**21)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 300 && (var(16) || time <= 2)
trigger18 = StateNo = 310 && var(16)
trigger19 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 330 && var(16)
trigger21 = StateNo = 340 && var(16)
trigger22 = StateNo = 350 && var(16)
trigger23 = StateNo = 195 && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1300
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "�Ֆo�q1" || Command = "�Ֆo�q2" || Command = "�Ֆo�q3" || (ceil(fvar(29))&2**18) || (ceil(fvar(29))&2**19) || (ceil(fvar(29))&2**20)
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 300 && (var(16) || time <= 2)
trigger18 = StateNo = 310 && var(16)
trigger19 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 330 && var(16)
trigger21 = StateNo = 340 && var(16)
trigger22 = StateNo = 350 && var(16)
trigger23 = StateNo = 195 && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0



[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1260
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "���|��3"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 300 && (var(16) || time <= 2)
trigger18 = StateNo = 310 && var(16)
trigger19 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 330 && var(16)
trigger21 = StateNo = 340 && var(16)
trigger22 = StateNo = 350 && var(16)
trigger23 = StateNo = 195 && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0






[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1270
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "���|��2"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 300 && (var(16) || time <= 2)
trigger18 = StateNo = 310 && var(16)
trigger19 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 330 && var(16)
trigger21 = StateNo = 340 && var(16)
trigger22 = StateNo = 350 && var(16)
trigger23 = StateNo = 195 && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0







[State -1, hadouken]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1200
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = Command = "���|��1"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 300 && (var(16) || time <= 2)
trigger18 = StateNo = 310 && var(16)
trigger19 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 330 && var(16)
trigger21 = StateNo = 340 && var(16)
trigger22 = StateNo = 350 && var(16)
trigger23 = StateNo = 195 && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0





[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 1800
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 810
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 820
triggerall = !var(59)
triggerall = var(1) != [1,2]
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 195
triggerall = !var(59)
triggerall = !var(2)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || time <= 2)
trigger4 = StateNo = 211 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 220 && (var(16) || time <= 2)
trigger6 = StateNo = 221 && (var(16) || time <= 2 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger7 = StateNo = 230 && (var(16) || time <= 2)
trigger8 = StateNo = 240 && (var(16) || time <= 2)
trigger9 = StateNo = 250 && (var(16) || time <= 2)
trigger10 = StateNo = 251 && (var(16) || time <= 2)
trigger11 = StateNo = 400
trigger12 = StateNo = 410 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 420 && (var(16) || time <= 2)
trigger14 = StateNo = 430
trigger15 = StateNo = 440 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger16 = StateNo = 450 && (var(16) || time <= 2)
trigger17 = StateNo = 300 && (var(16) || time <= 2)
trigger18 = StateNo = 310 && var(16)
trigger19 = StateNo = 320 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
trigger20 = StateNo = 330 && var(16)
trigger21 = StateNo = 340 && var(16)
trigger22 = StateNo = 350 && var(16)
trigger23 = StateNo = 195 && var(36) && var(16)
trigger24 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger25 = (StateNo = [1500,2999]) && var(36) && var(16)
trigger26 = (StateNo = [3000,3099]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger27 = (StateNo = [3200,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0



[State -1, Run Fwd]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl



[State -1, Run Fwd]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl



[State -1, Run Back]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 5200
triggerall = !var(59)
triggerall = !(var(0)&2**10)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= -20
trigger1 = command = "recovery"
persistent = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 800
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 211 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 221 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 251 && time <= 2
trigger11 = StateNo = 400 && time <= 2
trigger12 = StateNo = 410 && time <= 2
trigger13 = StateNo = 420 && time <= 2
trigger14 = StateNo = 430 && time <= 2
trigger15 = StateNo = 440 && time <= 2
trigger16 = StateNo = 450 && time <= 2
trigger17 = StateNo = 300 && time <= 2
trigger18 = (StateNo = [195,799]) && var(36) && var(16)
trigger19 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 830
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 211 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 221 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 251 && time <= 2
trigger11 = StateNo = 400 && time <= 2
trigger12 = StateNo = 410 && time <= 2
trigger13 = StateNo = 420 && time <= 2
trigger14 = StateNo = 430 && time <= 2
trigger15 = StateNo = 440 && time <= 2
trigger16 = StateNo = 450 && time <= 2
trigger17 = StateNo = 300 && time <= 2
trigger18 = (StateNo = [195,799]) && var(36) && var(16)
trigger19 = (StateNo = [1000,1399]) && var(36) && var(16)
trigger20 = (StateNo = [1500,2999]) && var(36) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 850
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 211 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 221 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 251 && time <= 2
trigger11 = StateNo = 400 && time <= 2
trigger12 = StateNo = 410 && time <= 2
trigger13 = StateNo = 420 && time <= 2
trigger14 = StateNo = 430 && time <= 2
trigger15 = StateNo = 440 && time <= 2
trigger16 = StateNo = 450 && time <= 2
trigger17 = StateNo = 300 && time <= 2



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 211 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 221 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 251 && time <= 2
trigger11 = StateNo = 400 && time <= 2
trigger12 = StateNo = 410 && time <= 2
trigger13 = StateNo = 420 && time <= 2
trigger14 = StateNo = 430 && time <= 2
trigger15 = StateNo = 440 && time <= 2
trigger16 = StateNo = 450 && time <= 2
trigger17 = StateNo = 300 && time <= 2



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time <= 2
trigger3 = StateNo = 210 && time <= 2
trigger4 = StateNo = 211 && time <= 2
trigger5 = StateNo = 220 && time <= 2
trigger6 = StateNo = 221 && time <= 2
trigger7 = StateNo = 230 && time <= 2
trigger8 = StateNo = 240 && time <= 2
trigger9 = StateNo = 250 && time <= 2
trigger10 = StateNo = 251 && time <= 2
trigger11 = StateNo = 400 && time <= 2
trigger12 = StateNo = 410 && time <= 2
trigger13 = StateNo = 420 && time <= 2
trigger14 = StateNo = 430 && time <= 2
trigger15 = StateNo = 440 && time <= 2
trigger16 = StateNo = 450 && time <= 2
trigger17 = StateNo = 300 && time <= 2



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 875
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time <= 2
trigger3 = StateNo = 610 && time <= 2
trigger4 = StateNo = 620 && time <= 2
trigger5 = StateNo = 621 && time <= 2
trigger6 = StateNo = 630 && time <= 2
trigger7 = StateNo = 640 && time <= 2
trigger8 = StateNo = 650 && time <= 2
trigger9 = StateNo = 700 && time <= 2



[State -1, Throw]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 900
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodydist X = [-const(size.ground.front),22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 300
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown" && Command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1 Dive Kick]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 700
triggerall = !var(59)
triggerall = !(var(0)&2**5)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a" || command = "b" || command = "c"
triggerall = command = "holddown" && Command = "holdfwd"
triggerall = statetype = A
triggerall = Vel X >= 0
triggerall = Pos Y <= -45
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 640 && (var(16) || time <= 2 || (var(36) = 1||var(36) = 2))
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 200
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = StateNo = 430 && Time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 211
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0











[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 210
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 221
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 221
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z"
trigger1 = StateNo = 830 && Time =[14,24]



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 220
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 230
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 400 && Time > 4
trigger3 = StateNo = 430 && Time > 4
trigger4 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger5 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 240
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0





[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 245
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0






[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 251
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-25,25]
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 250
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 250
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 400
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = StateNo = 430 && Time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 410
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 420
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 430
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && Time > 4
trigger3 = StateNo = 400 && Time > 4
trigger4 = StateNo = 430 && Time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 440
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 450
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1399]) && statetype != A && var(36) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 600
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 610
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 620
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
triggerall = Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 621
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
triggerall = !Vel X
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 630
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 640
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = StateNo = 700 && Movecontact
ignorehitpause = 0



[State -1]
type = ChangeState
triggerall = !NumPartner || NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])
value = 650
triggerall = !var(59)
triggerall = !var(2)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0


