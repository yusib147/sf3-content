










================================ Cvs Yang By IKEISLEGEND================================================



OK check his command file for movelist his supers are Rishinmahaken and Tenshi-Senkyuutai I did not 


cod Sei SEi Enbu because he a would be too Cheesey if he had it My Yang Will have it tho XD

Hes a pretty basic cvs chars his plays simialr to 3s. He needs a few tweaks I plain on updating him soon

Whats missing? Special intros vs Gouki, Yun, Ryu, Silber and more

 His Dodge animation Needs to be colored



Credits: Thanks Cvsnb for the sprites and Waru for the template.



Feedback Welcome And I take Char Request givin you provide the sprites on commision.




Please Report Bugs to http://mugenguild.com/forum/profile
  

Please Give credit if moding my Char thanks




