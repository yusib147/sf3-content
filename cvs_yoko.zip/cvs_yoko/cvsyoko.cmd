;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

[Command]
name = "CPU31"
command = U, D, F, U, D
time = 1

[Command]
name = "CPU32"
command = U, B, F, U, D
time = 1

[Command]
name = "CPU33"
command = U, D, D, U, D
time = 1

[Command]
name = "CPU34"
command = F, B, U, U, D
time = 1

[Command]
name = "CPU35"
command = U, F, U, B, U, D
time = 1

[Command]
name = "CPU36"
command = U, D, B, U, D
time = 1

[Command]
name = "CPU37"
command = F, F, B, U, D
time = 1

[Command]
name = "CPU38"
command = U, D, U, U, D
time = 1

[Command]
name = "CPU39"
command = F, B, B, U, D
time = 1

[Command]
name = "CPU40"
command = F, F, B, B, U, D
time = 1

[Command]
name = "CPU41"
command = U, U, F, U, D
time = 1

[Command]
name = "CPU42"
command = U, B, B, U, D
time = 1

[Command]
name = "CPU43"
command = U, B, F, F, U, D
time = 1

[Command]
name = "CPU44"
command = U, F, B, U, U, D
time = 1

[Command]
name = "CPU45"
command = U, B, F, U, U, D
time = 1

[Command]
name = "CPU46"
command = U, B, B, B, U, D
time = 1

[Command]
name = "CPU47"
command = U, D, B, F, U, D
time = 1

[Command]
name = "CPU48"
command = U, D, B, D, U, D
time = 1

[Command]
name = "CPU49"
command = U, D, F, U, U, D
time = 1

[Command]
name = "CPU50"
command = U, D, U, B, U, D
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "�M�U�I�����̓A�b�p�[1"
command = ~D, DF, F, D, DF, x
time = 21

[Command]
name = "�M�U�I�����̓A�b�p�[1"
command = ~D, DF, F, D, DF, ~x
time = 21

[Command]
name = "�M�U�I�����̓A�b�p�[2"
command = ~D, DF, F, D, DF, y
time = 21

[Command]
name = "�M�U�I�����̓A�b�p�[2"
command = ~D, DF, F, D, DF, ~y
time = 21

[Command]
name = "�M�U�I�����̓A�b�p�[3"
command = ~D, DF, F, D, DF, z
time = 21

[Command]
name = "�M�U�I�����̓A�b�p�[3"
command = ~D, DF, F, D, DF, ~z
time = 21

[Command]
name = "�M�U�I�����̓L�b�N1"
command = ~D, DF, F, D, DF, a
time = 21

[Command]
name = "�M�U�I�����̓L�b�N1"
command = ~D, DF, F, D, DF, ~a
time = 21

[Command]
name = "�M�U�I�����̓L�b�N2"
command = ~D, DF, F, D, DF, b
time = 21

[Command]
name = "�M�U�I�����̓L�b�N2"
command = ~D, DF, F, D, DF, ~b
time = 21

[Command]
name = "�M�U�I�����̓L�b�N3"
command = ~D, DF, F, D, DF, c
time = 21

[Command]
name = "�M�U�I�����̓L�b�N3"
command = ~D, DF, F, D, DF, ~c
time = 21

[Command]
name = "�I���B���G�̃O�����c�I"
command = ~F, D, B, F, D, B, a
time = 30

[Command]
name = "�I���B���G�̃O�����c�I"
command = ~F, D, B, F, D, B, ~a
time = 30

[Command]
name = "�I���B���G�̃O�����c�I"
command = ~F, D, B, F, D, B, b
time = 30

[Command]
name = "�I���B���G�̃O�����c�I"
command = ~F, D, B, F, D, B, ~b
time = 30

[Command]
name = "�I���B���G�̃O�����c�I"
command = ~F, D, B, F, D, B, c
time = 30

[Command]
name = "�I���B���G�̃O�����c�I"
command = ~F, D, B, F, D, B, ~c
time = 30

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "�����̓A�b�p�[1"
command = ~D, DF, F, x
time = 12

[Command]
name = "�����̓A�b�p�[1"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "�����̓A�b�p�[2"
command = ~D, DF, F, y
time = 12

[Command]
name = "�����̓A�b�p�[2"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "�����̓A�b�p�[3"
command = ~D, DF, F, z
time = 12

[Command]
name = "�����̓A�b�p�[3"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "�����̓A�b�p�[4"
command = ~F, D, DF, a
time = 12

[Command]
name = "�����̓A�b�p�[4"
command = ~F, D, DF, ~a
time = 12

[Command]
name = "�����̓A�b�p�[5"
command = ~F, D, DF, b
time = 12

[Command]
name = "�����̓A�b�p�[5"
command = ~F, D, DF, ~b
time = 12

[Command]
name = "�����̓A�b�p�[6"
command = ~F, D, DF, c
time = 12

[Command]
name = "�����̓A�b�p�[6"
command = ~F, D, DF, ~c
time = 12

[Command]
name = "���b�g�i�[�X�g���C�N1"
command = ~D, DF, F, a
time = 12

[Command]
name = "���b�g�i�[�X�g���C�N1"
command = ~D, DF, F, ~a
time = 12

[Command]
name = "���b�g�i�[�X�g���C�N2"
command = ~D, DF, F, b
time = 12

[Command]
name = "���b�g�i�[�X�g���C�N2"
command = ~D, DF, F, ~b
time = 12

[Command]
name = "���b�g�i�[�X�g���C�N3"
command = ~D, DF, F, c
time = 12

[Command]
name = "���b�g�i�[�X�g���C�N3"
command = ~D, DF, F, ~c
time = 12

[Command]
name = "�X�i�C�v�G�A�[1"
command = ~F, D, DF, a
time = 12

[Command]
name = "�X�i�C�v�G�A�[1"
command = ~F, D, DF, ~a
time = 12

[Command]
name = "�X�i�C�v�G�A�[2"
command = ~F, D, DF, b
time = 12

[Command]
name = "�X�i�C�v�G�A�[2"
command = ~F, D, DF, ~b
time = 12

[Command]
name = "�X�i�C�v�G�A�[3"
command = ~F, D, DF, c
time = 12

[Command]
name = "�X�i�C�v�G�A�[3"
command = ~F, D, DF, ~c
time = 12

[Command]
name = "�V�����I1"
command = ~D, D, a
time = 12

[Command]
name = "�V�����I1"
command = ~D, D, ~a
time = 12

[Command]
name = "�V�����I2"
command = ~D, D, b
time = 12

[Command]
name = "�V�����I2"
command = ~D, D, ~b
time = 12

[Command]
name = "�V�����I3"
command = ~D, D, c
time = 12

[Command]
name = "�V�����I3"
command = ~D, D, ~c
time = 12

[Command]
name = "�J�~�i�I1"
command = ~F, DF, D, DB, B, F, x
time = 30

[Command]
name = "�J�~�i�I1"
command = ~F, DF, D, DB, B, F, ~x
time = 30

[Command]
name = "�J�~�i�I2"
command = ~F, DF, D, DB, B, F, y
time = 30

[Command]
name = "�J�~�i�I2"
command = ~F, DF, D, DB, B, F, ~y
time = 30

[Command]
name = "�J�~�i�I3"
command = ~F, DF, D, DB, B, F, z
time = 30

[Command]
name = "�J�~�i�I3"
command = ~F, DF, D, DB, B, F, ~z
time = 30

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 18

[Command]
name = "FF"     
command = F, F
time = 12

[Command]
name = "BB"     
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "gc"
command = y+b
time = 10

[Command]
name = "oc"
command = z+c
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargec"
command = /c
time = 1

[Command]
name = "chargez"
command = /z
time = 1

[Command];�i�O�u���b�L���O�R�}���h�j
name = "block"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "block2"
command = D
time = 1

[Command];�i�O���[���Z���N�g�p�j
name = "up"
command = U
time = 3

[Command];�i�O���[���Z���N�g�p�j
name = "down"
command = D
time = 3

[Command]
name = "back"
command = B
time = 1

[Command]
name = "downback"
command = DB
time = 1

[Command]
name = "n"
command = 
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]

;===========================================================================
;AI�p

;AI
[State -1, AI]
type = VarSet
triggerall = var(59) != 1
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
trigger31  = command = "CPU31"
trigger32  = command = "CPU32"
trigger33  = command = "CPU33"
trigger34  = command = "CPU34"
trigger35  = command = "CPU35"
trigger36  = command = "CPU36"
trigger37  = command = "CPU37"
trigger38  = command = "CPU38"
trigger39  = command = "CPU39"
trigger40  = command = "CPU40"
trigger41  = command = "CPU41"
trigger42  = command = "CPU42"
trigger43  = command = "CPU43"
trigger44  = command = "CPU44"
trigger45  = command = "CPU45"
trigger46  = command = "CPU46"
trigger47  = command = "CPU47"
trigger48  = command = "CPU48"
trigger49  = command = "CPU49"
trigger50  = command = "CPU50"
var(59) = 1

;===========================================================================
;---------------------------------------------------------------------------
;��g�i�󒆁j
[State -1]
type = ChangeState
value = 5210
triggerall = Var(59) = 1
triggerall = Alive
triggerall = CanRecover
triggerall = Vel Y > -1
triggerall = Pos Y >= -40
triggerall = StateNo = 5050
trigger1 = random = [150,200]

;---------------------------------------------------------------------------
;��g�i�n��j
[State -1]
type = ChangeState
value = 5201
triggerall = var(59) = 1
triggerall = ((var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6) && !var(1)) || CanRecover
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= 10
trigger1 = random <= 400

;---------------------------------------------------------------------------
;�W�����v�i��������j
[state -1, Guard]
type = ChangeState
value = 40
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = ctrl || stateno = 21
triggerall = statetype != A
trigger1 = enemynear,HitDefAttr = SC, NT,ST,HT

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = var(59) = 1
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2life > 150 || (100*life/const(data.life))<=15
trigger1 = ctrl || stateno = 21 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2bodydist X = [-5,40]
trigger1 = P2StateType = S || P2StateType = C
trigger1 = P2MoveType = A
trigger1 = enemynear,time >= (4+random%10)
	trigger1 = random = [200,600]

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
;[State -1]
;type = ChangeState
;value = 875
;triggerall = var(59) = 1
;triggerall = !var(4)
;triggerall = var(20) = 1 || var(20) = 6
;triggerall = !var(15) && !var(16)
;triggerall = roundstate = 2
;trigger1 = statetype = A
;trigger1 = ctrl

;---------------------------------------------------------------------------
;����
[State -1, Walk]
type = ChangeState
value = 21
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
triggerall = !InGuardDist
triggerall = stateno != [10,12]
triggerall = prevstateno != [10,12]
triggerall = stateno != 20
triggerall = prevstateno != 20
triggerall = stateno != 21
triggerall = prevstateno != 21
triggerall = stateno != [120,159]
triggerall = prevstateno != [120,159]
trigger1 = !((prevstateno = 1000 || prevstateno = 2800) && time < 2)
trigger1 = random%8<=6

;===========================================================================
;�I���R��

;---------------------------------------------------------------------------
;�M�U�I�����̓A�b�p�[
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = stateno = 1000
trigger1 = var(5) = 2
trigger1 = var(16) = [1,20)
trigger1 = var(36) = 1 && numtarget
ignorehitpause = 0

;---------------------------------------------------------------------------
;���[���N���b�V��
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-5,30]
trigger1 = P2StateType = C
trigger1 = stateno = 420 || stateno = 440 || stateno = 320 || stateno = 1000
trigger1 = var(16) > 20
trigger1 = var(36) = 2
trigger1 = random = [250,300]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1, Taunt]
type = ChangeState
value = 440
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-5,30]
trigger1 = stateno = 420 || stateno = 310 || stateno = 320 || stateno = 1000
trigger1 = var(16) > 20
trigger1 = var(36) = 2
trigger1 = random = [250,300]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����̓A�b�p�[
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = stateno = 1000
trigger1 = var(5) = 2
trigger1 = animelemtime(8) > 0
trigger1 = var(16) > 20
trigger1 = var(36) = 1 && numtarget
trigger2 = stateno = 1000
trigger2 = var(5) = 2
trigger2 = animelemtime(10) > 0
trigger2 = var(16) > 40
trigger2 = var(36) = 2
trigger3 = stateno = 420 || stateno = 320
trigger3 = var(16) > 20
trigger3 = var(36) = 1 && numtarget
trigger3 = var(17) >= 9
trigger4 = stateno = 420 || stateno = 440 || stateno = 310 || stateno = 320
trigger4 = var(16) > 40
trigger4 = var(36) = 2
ignorehitpause = 0

;---------------------------------------------------------------------------
;�A�T���g�L�b�N
[State -1, Taunt]
type = ChangeState
value = 320
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X >= 30
trigger1 = stateno = 420 || stateno = 440 || stateno = 310 || stateno = 320
trigger1 = var(16) > 20
trigger1 = var(17) = [0,8]
trigger1 = var(36) = [1,2]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1, Taunt]
type = ChangeState
value = 420
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-5,30]
trigger1 = stateno = 420 || stateno = 440 || stateno = 310 || stateno = 320
trigger1 = var(16) > 20
trigger1 = var(17) = [0,8]
trigger1 = var(36) = [1,2]
ignorehitpause = 0

;===========================================================================
;�N���オ�胊�o�[�T��

;---------------------------------------------------------------------------
;�I���B���G�̃O�����c�I
[State -1, hadouken]
type = ChangeState
value = 3300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(18))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || var(43) 
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && (prevstateno = 5120 || prevstateno = 5201) && time <= 1
triggerall = enemynear,time >= (4+random%10)
triggerall = P2life > 150 || (100*life/const(data.life))<=15
trigger1 = P2bodydist X = [0,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = A
trigger1 = enemynear,vel X >= 0
	trigger1 = random = [150,750]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�M�U�I�����̓A�b�p�[
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20)||var(20)=6)&&Power>=2000)||(var(20)=2&&Power>=3000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)||var(43)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl && (prevstateno = 5120 || prevstateno = 5201) && time <= 1
triggerall = enemynear,time >= (4+random%10)
trigger1 = P2bodydist X = [0,40]
trigger1 = P2bodydist Y = [-120,-60]
trigger1 = enemynear,vel X >= 0
trigger1 = enemynear,vel Y > 1
trigger1 = P2MoveType != H
	trigger1 = random = [150,800]
trigger2 = P2bodydist X = [0,40]
trigger2 = P2StateType != A
trigger2 = P2MoveType = A
trigger2 = enemynear,vel X >= 0
	trigger2 = random = [150,600]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�I���B���G�̃O�����c�I
[State -1, hadouken]
type = ChangeState
value = 3300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !numhelper(7500)
triggerall = !numhelper(30000)
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(18))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || var(43) 
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-5,20]
trigger1 = P2StateType != A
trigger1 = StateNo = 200 || StateNo = 400 || StateNo = 430
trigger1 = movetype = A
trigger1 = var(36) = 1 && numtarget
trigger1 = var(17) >= 2
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [100,650]
trigger2 = P2bodydist X = [-5,30]
trigger2 = P2StateType != A
trigger2 = StateNo = 300
trigger2 = movetype = A
trigger2 = var(36) = 1 && numtarget
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [0,700]
trigger3 = ctrl || stateno = 21 || stateno = 40 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = P2bodydist X = [-5,30]
trigger3 = P2StateType != A
trigger3 = P2MoveType = A
trigger3 = enemynear,vel X >= 0
trigger3 = enemynear,time >= (8+random%10)
trigger3 = !(var(16) && numtarget)
	trigger3 = random = [300,800]
trigger4 = prevstateno = [4000,4199]
trigger4 = P2bodydist X = [0,30]
trigger4 = P2StateType != A
trigger4 = ctrl
	trigger4 = random%4!=2
trigger5 = P2bodydist X = [-5,20]
trigger5 = P2StateType != A
trigger5 = StateNo = 1000
trigger5 = (animelemtime(7) >= 0 && animelemtime(9) < 0 && var(5) = 1) || (animelemtime(8) >= 0 && animelemtime(10) < 0 && var(5) = 2)
trigger5 = var(20) = 2 || var(20) = 6
trigger5 = var(17) > 2
trigger5 = var(36) = 1 && numtarget
trigger5 = !(var(16) && numtarget)
	trigger5 = Random = [0,600]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���b�g�i�[�I�[�o�[�h���C�u
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType = S
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ((!var(20)||var(20)=6)&&Power>=2000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)
trigger1 = P2bodydist X = [0,25]
trigger1 = P2StateType != A
trigger1 = StateNo = 241 || StateNo = 410 || StateNo = 440
trigger1 = movetype = A
trigger1 = var(36) = 1 && numtarget
trigger1 = var(17) >= 2
trigger1 = !(var(16) && numtarget)
trigger1 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger1 = Random = [100,200-((var(20)=1)*50)]
trigger2 = P2bodydist X = [0,30]
trigger2 = P2StateType != A
trigger2 = (StateNo = 221 && animelemtime(5) < 0) || StateNo = 420
trigger2 = movetype = A
trigger2 = var(36) = 1 && numtarget
trigger2 = !(var(16) && numtarget)
trigger2 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger2 = Random = [500,650-((var(20)=1)*50)]
trigger3 = ctrl || stateno = 21 || stateno = 40 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger3 = ((!var(20)||var(20)=6)&&Power>=2000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)
trigger3 = P2bodydist X = [0,50]
trigger3 = P2StateType != A
trigger3 = P2MoveType = A
trigger3 = enemynear,vel X >= 0
trigger3 = !(var(16) && numtarget)
	trigger3 = random < 200
trigger4 = prevstateno = [4000,4199]
trigger4 = P2bodydist X = [0,40]
trigger4 = P2StateType != A
trigger4 = ctrl
	trigger4 = random%4!=2
trigger5 = P2bodydist X = [-5,30]
trigger5 = P2StateType != A
trigger5 = StateNo = 1000
trigger5 = (animelemtime(7) >= 0 && animelemtime(9) < 0 && var(5) = 1) || (animelemtime(8) >= 0 && animelemtime(10) < 0 && var(5) = 2)
trigger5 = var(20) = 2 || var(20) = 6
trigger5 = var(17) > 2
trigger5 = var(36) = 1 && numtarget
trigger5 = !(var(16) && numtarget)
	trigger5 = Random = [100,200]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�M�U�I�����̓A�b�p�[
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2StateType != A
trigger1 = StateNo = 200 || StateNo = 400 || StateNo = 430
trigger1 = movetype = A
trigger1 = var(36) = 1 && numtarget
trigger1 = var(17) >= 2
trigger1 = !(var(16) && numtarget)
trigger1 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger1 = Random = [150,200-((var(20)=1)*30)]
trigger2 = P2StateType != A
trigger2 = StateNo = 241 || StateNo = 410 || StateNo = 440
trigger2 = movetype = A
trigger2 = var(36) = 1 && numtarget
trigger2 = var(17) >= 2
trigger2 = !(var(16) && numtarget)
trigger2 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger2 = Random = [200,300-((var(20)=1)*80)]
trigger3 = P2StateType != A
trigger3 = StateNo = 221 && animelemtime(5) < 0
trigger3 = movetype = A
trigger3 = var(36) = 1 && numtarget
trigger3 = var(17) >= 2
trigger3 = !(var(16) && numtarget)
trigger3 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger3 = Random = [100,200-((var(20)=1)*50)]
trigger4 = ctrl || stateno = 21 || stateno = 40 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger4 = P2bodydist X = [30,60]
trigger4 = P2bodydist Y = [-120,-90]
trigger4 = P2MoveType != H
trigger4 = enemynear,vel X >= 0
trigger4 = enemynear,vel Y > 1
trigger4 = !(var(16) && numtarget)
	trigger4 = random = [500,650-((var(20)=1)*100)]
trigger5 = ctrl || stateno = 21 || stateno = 40 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger5 = ((!var(20)||var(20)=6)&&Power>=2000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)
trigger5 = P2bodydist X = [30,60]
trigger5 = P2bodydist Y = [-120,-60]
trigger5 = P2MoveType != H
trigger5 = enemynear,vel X >= 0
trigger5 = enemynear,vel Y > 1
trigger5 = !(var(16) && numtarget)
	trigger5 = random = [500,850]
trigger6 = ctrl || stateno = 21 || stateno = 40 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = ((!var(20)||var(20)=6)&&Power>=2000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)
trigger6 = P2bodydist X = [0,60]
trigger6 = P2StateType != A
trigger6 = P2MoveType = A
trigger6 = enemynear,vel X >= 0
trigger6 = enemynear,time >= (4+random%10)
trigger6 = !(var(16) && numtarget)
	trigger6 = random = [400,480]
trigger7 = ctrl || stateno = 21 || stateno = 40 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger7 = P2bodydist X = [0,50]
trigger7 = P2bodydist Y = [-150,-120]
trigger7 = P2MoveType = H
trigger7 = numtarget
trigger7 = target,stateno = [5000,5070]
trigger7 = target,stateno != 5040
trigger7 = target,Vel Y > -3
trigger7 = !(var(16) && numtarget)
trigger7 = fvar(26) = [1,4]
trigger7 = var(20) != 2 || var(20) != 5 || !var(15)
trigger7 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger7 = Random = [100,700-((var(20)=1)*400)]
trigger8 = prevstateno = [4000,4199]
trigger8 = P2bodydist X = [0,30]
trigger8 = P2bodydist Y = [-50,0]
trigger8 = ctrl
	trigger8 = random%4!=3
trigger9 = ctrl || stateno = 21 || stateno = 40 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || (stateno = 52 && anim = 57 && time >= 2)
trigger9 = P2bodydist X = [-10,50]
trigger9 = P2bodydist Y = [-70,0]
trigger9 = enemynear,Vel Y <= 0
trigger9 = var(17) > 3
trigger9 = !(var(16) && numtarget)
trigger9 = NumHelper(20000)
trigger9 = Helper(20000),stateno = 20001
trigger9 = P2life > 100 || var(20) = 3 || var(20) = 5
	trigger9 = Random = [100,300]
trigger10 = P2bodydist X = [-5,50]
trigger10 = P2StateType != A
trigger10 = StateNo = 300
trigger10 = movetype = A
trigger10 = var(36) = 1 && numtarget
trigger10 = !(var(16) && numtarget)
trigger10 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger10 = Random = [480,600-((var(20)=1)*100)]
trigger11 = P2bodydist X = [0,50]
trigger11 = P2bodydist Y = [-90,0]
trigger11 = StateNo = 1000
trigger11 = (animelemtime(7) >= 0 && animelemtime(9) < 0 && var(5) = 1) || (animelemtime(8) >= 0 && animelemtime(10) < 0 && var(5) = 2)
trigger11 = var(20) = 2 || var(20) = 6
trigger11 = var(17) > 2
trigger11 = var(36) = 1 && numtarget
trigger11 = !(var(16) && numtarget)
	trigger11 = Random = [300,450]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�M�U�I�����̓L�b�N
[State -1, Hadousho]
type = ChangeState
value = 3100
triggerall = var(59) = 1
triggerall = !var(4)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = Pos Y < -50
trigger1 = ((!var(20)||var(20)=6)&&Power>=2000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)
trigger1 = P2bodydist X = [10,40]
trigger1 = P2bodydist Y = [80,120]
trigger1 = P2StateType = A
trigger1 = P2MoveType != H
trigger1 = Vel Y > -1
trigger1 = Pos Y = [-120,-75]
trigger1 = Ctrl
	trigger1 = Random = [500,950]
trigger2 = ((!var(20)||var(20)=6)&&Power>=2000)||(var(20)=3&&(100*life/const(data.life))<=30&&var(14))||(var(15)&&Power>=1000)
trigger2 = P2bodydist X = [10,40]
trigger2 = P2bodydist Y = [80,120]
trigger2 = P2StateType != A
trigger2 = P2MoveType = A
trigger2 = Vel Y > -1
trigger2 = Pos Y = [-120,-75]
trigger2 = Ctrl
	trigger2 = Random = [600,950-((var(20)=1)*100)]
trigger3 = ctrl
trigger3 = P2bodydist X = [0,60]
trigger3 = P2bodydist Y = [20,120]
trigger3 = var(17) > 3
trigger3 = !fvar(26)
trigger3 = !(var(16) && numtarget)
trigger3 = Pos Y <= -80
trigger3 = NumHelper(20000)
trigger3 = Helper(20000),stateno = 20001
trigger3 = P2life > 100 || var(20) = 3 || var(20) = 5
	trigger3 = Random = [100,800-((var(20)=1)*500)]
trigger4 = P2bodydist X = [-5,30]
trigger4 = P2bodydist Y = [40,100]
trigger4 = StateNo = 1300
trigger4 = var(20) = 2 || var(20) = 6
trigger4 = var(36) = 1 && numtarget
trigger4 = !(var(16) && numtarget)
trigger4 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger4 = Random = [500,600]
trigger5 = P2bodydist X = [-5,40]
trigger5 = P2bodydist Y = [30,100]
trigger5 = StateNo = 1210 || StateNo = 1211 || StateNo = 1220 || StateNo = 1221
trigger5 = var(17) > 3
trigger5 = var(20) = 2 || var(20) = 6
trigger5 = var(36) = 3 && numtarget
trigger5 = !(var(16) && numtarget)
trigger5 = target,life > 100 || var(20) = 3 || var(20) = 5
	trigger5 = Random = [500,750]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h
[state -1, Guard]
type = ChangeState
value = 130
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype != A
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,40,300)
trigger3 = enemynear,HitDefAttr = SCA, NA,SA,HA
trigger3 = prevstateno = 5120 || prevstateno = 5201
	trigger3 = random = [0,950]

[state -1, Guard]
type = ChangeState
value = 132
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = InGuardDist
triggerall = (stateno != [4000,4029]) && (stateno != [4100,4129])
triggerall = ctrl
triggerall = statetype = A
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
	trigger2 = random <= ifelse(var(20)=2||var(20)=6,80,350)

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(59) = 1
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = statetype != A
triggerall = P2MoveType != A
trigger1 = P2bodydist X = [60,200]
trigger1 = P2MoveType = I
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,350]
trigger2 = P2bodydist X > 200
trigger2 = Ctrl || (stateno = 21 && anim = 20)
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [350,400]

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = var(59) = 1
triggerall = !var(20) || var(20) = 1 || var(20) = 2
triggerall = statetype != A
triggerall = P2MoveType != A
trigger1 = P2bodydist X >= 170
trigger1 = P2MoveType = I
trigger1 = Ctrl || (stateno = 21 && anim = 20)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [500,600]
trigger2 = P2bodydist X > 150
trigger2 = P2StateType = L
trigger2 = Ctrl || (stateno = 21 && anim = 20)
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [150,200]

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = backedgedist > 60
trigger1 = P2bodydist X = [0,60]
trigger1 = P2MoveType = I
trigger1 = Ctrl || (stateno = 21 && anim = 21)
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [700,750]
trigger2 = P2bodydist X = [0,40]
trigger2 = P2StateType = L
trigger2 = Ctrl || (stateno = 21 && anim = 21)
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [350,400]

;---------------------------------------------------------------------------
;�W�����v
[State -1, Jump]
type = ChangeState
value = 40
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = Ctrl
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
trigger1 = P2bodydist X = [-10,200]
trigger1 = P2bodydist Y = [-60,0]
trigger1 = var(17) >= 3
trigger1 = !(var(16) && numtarget)
trigger1 = NumHelper(20000)
trigger1 = Helper(20000),stateno = 20001
	trigger1 = Random = [100,550]

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !var(20) || var(20) = 1 || var(20) = 4 || var(20) = 6
triggerall = statetype != A
triggerall = stateno != [120,159]
triggerall = stateno != [4000,4199]
triggerall = prevstateno != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 150
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [100,105]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [0,150]
trigger2 = P2MoveType = I
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [240,245]
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X = [0,150]
trigger3 = P2MoveType = A
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [430,435]
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = statetype != A
triggerall = stateno != [120,159]
triggerall = stateno != [4000,4199]
triggerall = prevstateno != [800,830]
triggerall = prevstateno != [150,159]
triggerall = prevstateno != [4000,4199]
triggerall = prevstateno != [5000,5199]
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [0,40]
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,220]
trigger2 = P2bodydist X = [0,40]
trigger2 = P2MoveType = A
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [600,610]
trigger3 = P2bodydist X >= 150
trigger3 = !(var(16) && numtarget)
trigger3 = inguarddist
	trigger3 = Random = [600,670]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�~�i�I
[State -1, hadouken]
type = ChangeState
value = 1500
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !numhelper(30000)
triggerall = statetype != A
triggerall = P2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
;triggerall = enemynear,prevstateno != [5000,5999]
triggerall = !var(16)
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
	trigger1 = Random = [100,400]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = prevstateno = 1100 || prevstateno = 1140 || prevstateno = 1145
	trigger2 = Random = [100,500]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�V�����I
[State -1, hadouken]
type = ChangeState
value = 1400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = !numhelper(20000)
triggerall = statetype != A
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = (P2Bodydist X = [-5,50]) || (P2Bodydist X = [80,130]) || (P2Bodydist X = [160,210])
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger1 = P2stateno = 5120
trigger1 = enemynear,animtime = -12
trigger1 = !(var(16) && numtarget)
	trigger1 = random = [300,700]
trigger2 = P2bodydist X = [-5,20]
trigger2 = P2StateType != A
trigger2 = StateNo = 200 || StateNo = 400 || StateNo = 430
trigger2 = movetype = A
trigger2 = var(36)=1||var(36)=2
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [50,100+((var(17)>=2)*500)]
trigger3 = P2bodydist X = [-5,20]
trigger3 = P2StateType != A
trigger3 = StateNo = 210 || StateNo = 241 || StateNo = 410 || StateNo = 440
trigger3 = movetype = A
trigger3 = var(36)=1||var(36)=2
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [0,50+((var(17)>=2)*400)]
trigger4 = P2bodydist X = [-5,30]
trigger4 = P2StateType != A
trigger4 = StateNo = 300
trigger4 = movetype = A
trigger4 = var(36)=1||var(36)=2
trigger4 = !(var(16) && numtarget)
	trigger4 = Random = [0,400]
trigger5 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger5 = prevstateno = 1000 || prevstateno = 2800
trigger5 = var(17) > 2
trigger5 = !(var(16) && numtarget)
	trigger5 = random = [100,900]
trigger6 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger6 = (P2Bodydist X = [-5,60]) || (P2Bodydist X = [80,140]) || (P2Bodydist X = [160,220])
trigger6 = P2StateType != A
trigger6 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger6 = !(var(16) && numtarget)
	trigger6 = random = [300,310]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����̓A�b�p�[
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2StateType != A
trigger1 = StateNo = 200 || StateNo = 400 || StateNo = 430
trigger1 = movetype = A
trigger1 = var(36) = 1 && numtarget
trigger1 = var(17) >= 2
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [0,700]
trigger2 = P2StateType != A
trigger2 = StateNo = 241 || StateNo = 410 || StateNo = 440
trigger2 = movetype = A
trigger2 = var(36) = 1 && numtarget
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [0,200+((var(17)>=2)*600)]
trigger3 = P2StateType != A
trigger3 = StateNo = 221 && animelemtime(5) < 0
trigger3 = movetype = A
trigger3 = var(36) = 1 && numtarget
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [0,950]
trigger4 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger4 = P2bodydist X = [-10,50]
trigger4 = P2StateType != A
trigger4 = var(17) > 3
trigger4 = !(var(16) && numtarget)
trigger4 = NumHelper(20000)
trigger4 = Helper(20000),stateno = 20001
	trigger4 = Random = [100,250]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���b�g�i�[�X�g���C�N
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [100,240]
trigger1 = P2StateType != A
trigger1 = P2MoveType != A
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,210]
trigger2 = P2bodydist X = [20,60]
trigger2 = P2StateType != A
trigger2 = StateNo = 200 || StateNo = 400 || StateNo = 430
trigger2 = movetype = A
trigger2 = var(36)=1||var(36)=2
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [0,500-((var(17)>=2)*200)]
trigger3 = P2bodydist X = [0,60]
trigger3 = P2StateType != A
trigger3 = (StateNo = 221 && animelemtime(5) < 0) || StateNo = 241 || StateNo = 410 || StateNo = 440
trigger3 = movetype = A
trigger3 = var(36)=1||var(36)=2
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [0,700]
trigger4 = StateNo = 3000 && animelemtime(18) > 0
trigger4 = var(5) = 1
trigger4 = var(36) = 1 && numtarget
trigger4 = !(var(16) && numtarget)
	trigger4 = Random = [0,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�X�i�C�v�G�A�[
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [80,160]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,205]
trigger2 = P2bodydist X = [20,60]
trigger2 = P2StateType != A
trigger2 = StateNo = 200 || StateNo = 400 || StateNo = 430
trigger2 = movetype = A
trigger2 = var(36)=2
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [300,310]
trigger3 = P2bodydist X = [20,60]
trigger3 = P2StateType != A
trigger3 = (StateNo = 221 && animelemtime(5) < 0) || StateNo = 241 || StateNo = 410 || StateNo = 440
trigger3 = movetype = A
trigger3 = var(36)=2
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [400,405]
trigger4 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger4 = P2bodydist X = [-10,120]
trigger4 = P2StateType != A
trigger4 = var(17) >= 3
trigger4 = !(var(16) && numtarget)
trigger4 = NumHelper(20000)
trigger4 = Helper(20000),stateno = 20001
	trigger4 = Random = [100,450]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���b�g�i�[�X�g���C�N�i�󒆁j
[State -1, Hadousho]
type = ChangeState
value = 1300
triggerall = var(59) = 1
triggerall = !var(4)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = Pos Y < -50
triggerall = !enemynear,numproj
trigger1 = P2bodydist X = [0,150]
trigger1 = Pos Y = [-180,-50]
trigger1 = Ctrl
	trigger1 = Random = [650,950]
trigger2 = P2bodydist X > 150
trigger2 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger2 = Vel Y > -3
trigger2 = Ctrl
trigger2 = !inguarddist
	trigger2 = Random = [700,950]
trigger3 = StateNo = 600 || StateNo = 630
trigger3 = var(36)=1||var(36)=2
trigger3 = Vel Y > -3
	trigger3 = Random = [200,300]
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = ifelse(var(12),2900,2800) 
triggerall = roundstate = 2
triggerall = var(59) = 1
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = (Power >= 2000 && (!var(20) || var(20) = 4 || var(20) = 6)) || (Power >= 2000 && var(20) = 1)
triggerall = P2StateType != L
trigger1 = !enemynear,ctrl
trigger1 = P2bodydist X = [0,30]
	trigger1 = Random = [100,105]

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = var(59) = 1
triggerall = statetype != A
triggerall = (power < 1000 && var(20) = 3 && !var(14)) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = !inguarddist
triggerall = !enemynear,numproj
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 150
	trigger1 = Random = [600,650]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = teammode = single
trigger2 = P2bodydist X >= 180
trigger2 = P2StateType = L
	trigger2 = Random = [200,400]

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = var(59) = 1
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 2000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = !inguarddist
triggerall = !enemynear,numproj
triggerall = P2Life > 150
triggerall = !((100*life/const(data.life))<=20 && P2bodydist X <= 160)
triggerall = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X >= 70
	trigger1 = Random <= 400
trigger2 = P2StateType = L
	trigger2 = Random <= 550

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 1
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [5,22]
triggerall = P2StateType = S || P2StateType = C
triggerall = P2MoveType != H
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = enemynear,prevstateno != [5000,5999]
trigger1 = !(var(16) && numtarget)
	trigger1 = Random <= 350

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,10]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
trigger1 = !NumHelper(20000)
	trigger1 = Random = [100,400]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [-5,10]
trigger2 = P2StateType != A
trigger2 = P2MoveType = H
trigger2 = !(var(16) && numtarget)
trigger2 = !NumHelper(20000)
	trigger2 = Random = [100,950]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1, Taunt]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [0,20]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = prevstateno != 430
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [100,600]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [0,10]
trigger2 = P2StateType != A
trigger2 = P2MoveType = H
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [350,850]
trigger3 = P2bodydist X = [-10,20]
trigger3 = P2StateType != A
trigger3 = StateNo = 200 || StateNo = 400 || StateNo = 430
trigger3 = var(36)=1||var(36)=2
trigger3 = var(17) < 2
trigger3 = time > 4
trigger3 = !(var(16) && numtarget)
	trigger3 = Random = [0,800]
trigger4 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger4 = P2bodydist X >= 150
trigger4 = P2MoveType != A
trigger4 = !(var(16) && numtarget)
trigger4 = !inguarddist
trigger4 = !enemynear,numproj
	trigger4 = Random = [750,760]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [0,10]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,700]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [10,40]
trigger2 = P2StateType != A
trigger2 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [200,400]
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X = [15,45]
trigger3 = P2StateType != A
trigger3 = P2MoveType = H
trigger3 = !(var(16) && numtarget)
trigger3 = !NumHelper(20000)
	trigger3 = Random = [350,850]
trigger4 = P2bodydist X = [15,50]
trigger4 = P2StateType != A
trigger4 = StateNo = 200 || StateNo = 400 || StateNo = 430
trigger4 = var(36)=1||var(36)=2
trigger4 = animtime = 0
trigger4 = !(var(16) && numtarget)
	trigger4 = Random = [0,800]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = roundstate = 2
triggerall = var(59) = 1
triggerall = P2StateType != L
triggerall = P2StateType != C
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
triggerall = StateNo = 830 && Time =[14,20]
trigger1 = P2bodydist X = [30,70]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,210]

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = roundstate = 2
triggerall = var(59) = 1
triggerall = StateNo = 830 && Time =[14,20]
trigger1 = P2bodydist X = [0,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,250]

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != C
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [10,35]
trigger1 = P2bodydist Y = [-40,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = prevstateno != 200
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,310]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X >= 120
trigger2 = P2MoveType != A
trigger2 = !(var(16) && numtarget)
trigger2 = !inguarddist
trigger2 = !enemynear,numproj
	trigger2 = Random = [700,710]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [30,50]
trigger1 = P2bodydist Y = [-30,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,315]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != C
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [25,45]
trigger1 = P2bodydist Y = [-30,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,315]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1, Taunt]
type = ChangeState
value = 400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [0,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = prevstateno != 400
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [400,500]
trigger2 = P2bodydist X = [-10,10]
trigger2 = P2StateType != A
trigger2 = StateNo = 200 || StateNo = 400 || StateNo = 430
trigger2 = var(36)=1||var(36)=2
trigger2 = var(17) >= 2
trigger2 = time > 4
trigger2 = !(var(16) && numtarget)
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X >= 130
trigger3 = P2MoveType != A
trigger3 = !(var(16) && numtarget)
trigger3 = !inguarddist
trigger3 = !enemynear,numproj
	trigger3 = Random = [750,765]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [-5,20]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [100,450]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [-5,10]
trigger2 = P2StateType != A
trigger2 = P2MoveType = H
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [100,600]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [35,50]
trigger1 = P2bodydist Y = [-30,0]
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,310]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [30,55]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,315]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = !(var(16) && numtarget)
trigger2 = P2bodydist X = [45,70]
trigger2 = P2bodydist Y = [-60,-30]
trigger2 = enemynear,Vel X >= 0
trigger2 = enemynear,Vel Y > 1
trigger2 = P2StateType = A
trigger2 = P2MoveType = I || (P2MoveType = A && P2stateno = [0,999])
	trigger2 = Random = [300,370]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [10,30]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [310,315]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = !(var(16) && numtarget)
trigger2 = P2bodydist X = [30,40]
trigger2 = P2bodydist Y = [-50,-30]
trigger2 = enemynear,Vel X >= 0
trigger2 = enemynear,Vel Y > 1
trigger2 = P2StateType = A
trigger2 = P2MoveType = I || (P2MoveType = A && P2stateno = [0,999])
	trigger2 = Random = [300,330]
trigger3 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger3 = P2bodydist X >= 180
trigger3 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger3 = !enemynear,numproj
trigger3 = !(var(16) && numtarget)
trigger3 = ((var(20) = [0,2]) || var(20) = 4 || var(20) = 6) && power < 3000 && !var(15) && !var(16)
	trigger3 = Random = [150,160]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�X�e�b�v���[�L�b�N
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [40,75]
trigger1 = P2StateType != A
trigger1 = P2MoveType != A
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,215]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���[���N���b�V��
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [50,70]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,205]
trigger2 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = P2bodydist X = [0,30]
trigger2 = P2StateType = C
trigger2 = P2MoveType = I || (P2MoveType = H && P2stateno = [120,155])
trigger2 = !(var(16) && numtarget)
	trigger2 = Random = [200,210]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�A�T���g�L�b�N
[State -1, Taunt]
type = ChangeState
value = 320
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [80,120]
trigger1 = P2StateType != A
trigger1 = P2MoveType != A
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [200,215]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2StateType != C
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [40,50]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [300,305]
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = ctrl || stateno = 21 || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger1 = P2bodydist X = [50,75]
trigger1 = P2StateType != A
trigger1 = P2MoveType = I || (P2MoveType = A && P2stateno != [3000,3999])
trigger1 = !(var(16) && numtarget)
	trigger1 = Random = [305,315]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-10,50]
trigger1 = P2bodydist Y = [20,70]
trigger1 = Ctrl && !(var(16) && numtarget)
trigger1 = Pos Y <= -50
trigger1 = Vel X > 0
trigger1 = Vel Y > 2
	trigger1 = Random = [0,700]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-40,60]
trigger1 = P2bodydist Y = [0,60]
trigger1 = Pos Y <= -70
trigger1 = Vel Y > -2
trigger1 = Ctrl && !(var(16) && numtarget)
	trigger1 = Random = [251,600]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-10,50]
trigger1 = P2bodydist Y = [-30,70]
trigger1 = Ctrl && !(var(16) && numtarget)
trigger1 = Pos Y <= -50
trigger1 = Vel X > 0
trigger1 = Vel Y > 2
	trigger1 = Random = [0,500]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = P2StateType != L
triggerall = P2stateno != 5120
triggerall = P2stateno != 5201
trigger1 = P2bodydist X = [-10,50]
trigger1 = P2bodydist Y = [-50,40]
trigger1 = Ctrl && !(var(16) && numtarget)
trigger1 = Pos Y <= -60
trigger1 = Vel Y > -3
	trigger1 = Random = [60,100]
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v
[State -1, Jump]
type = ChangeState
value = 40
triggerall = Var(59) = 1
triggerall = StateType != A
triggerall = P2MoveType = I
triggerall = Ctrl
trigger1 = BackEdgebodyDist > 5
trigger1 = P2bodydist X = [0,90]
trigger1 = P2StateType = C
	trigger1 = Random = [620,640]
trigger2 = P2bodydist X >= 200
	trigger2 = Random = [420,450]

;===========================================================================
;---------------------------------------------------------------------------
;�I���B���G�̃O�����c�I
[State -1, hadouken]
type = ChangeState
value = 3300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !numhelper(7500)
triggerall = !numhelper(30000)
triggerall = Command = "�I���B���G�̃O�����c�I"
triggerall = ((!var(20) || var(20) = 2 || (var(20) = 6 && !var(18))) && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30 && var(14)) || (var(15) && Power >= 1000) || var(43) 
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 221 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger8 = StateNo = 241 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || animelemtime(2) < 0)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 300 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger18 = StateNo = 320 && (var(16) || animelemtime(2) < 0)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger22 = (StateNo = [1000,1499]) && (var(20) = 2 || var(20) = 6)
trigger23 = (StateNo = [2800,2999]) && (var(20) = 2 || var(20) = 6)
trigger24 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger25 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger26 = StateNo = 3101 && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
trigger28 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger29 = StateNo = 3201 && (var(20) = 2 || var(20) = 6)
trigger30 = StateNo = 3202 && (var(20) = 2 || var(20) = 6)
trigger31 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���b�g�i�[�I�[�o�[�h���C�u
[State -1, hadouken]
type = ChangeState
value = 3200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�M�U�I�����̓L�b�N1" || Command = "�M�U�I�����̓L�b�N2" || Command = "�M�U�I�����̓L�b�N3"
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 221 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger8 = StateNo = 241 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || animelemtime(2) < 0)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 300 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger18 = StateNo = 320 && (var(16) || animelemtime(2) < 0)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger22 = (StateNo = [1000,1499]) && (var(20) = 2 || var(20) = 6)
trigger23 = (StateNo = [2800,2999]) && (var(20) = 2 || var(20) = 6)
trigger24 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger25 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger26 = StateNo = 3101 && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�M�U�I�����̓A�b�p�[
[State -1, hadouken]
type = ChangeState
value = 3000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�M�U�I�����̓A�b�p�[1" || Command = "�M�U�I�����̓A�b�p�[2" || Command = "�M�U�I�����̓A�b�p�[3"
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger5 = StateNo = 221 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger6 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger8 = StateNo = 241 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || animelemtime(2) < 0)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 300 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger18 = StateNo = 320 && (var(16) || animelemtime(2) < 0)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger22 = (StateNo = [1000,1499]) && (var(20) = 2 || var(20) = 6)
trigger23 = (StateNo = [2800,2999]) && (var(20) = 2 || var(20) = 6)
trigger24 = StateNo = 3100 && (var(20) = 2 || var(20) = 6) && time > 50
trigger25 = StateNo = 3101 && (var(20) = 2 || var(20) = 6)
trigger26 = StateNo = 3105 && (var(20) = 2 || var(20) = 6)
trigger27 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger28 = StateNo = 3201 && (var(20) = 2 || var(20) = 6)
trigger29 = StateNo = 3202 && (var(20) = 2 || var(20) = 6)
trigger30 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�M�U�I�����̓L�b�N
[State -1, Hadousho]
type = ChangeState
value = 3100
triggerall = !var(59)
triggerall = !var(4)
triggerall = roundstate = 2
triggerall = Command = "�M�U�I�����̓L�b�N1" || Command = "�M�U�I�����̓L�b�N2" || Command = "�M�U�I�����̓L�b�N3"
triggerall = ((!var(20) || var(20) = 4 || var(20) = 6) && Power >= 1000) || (var(20) = 1 && Power >= 1500) || (var(20) = 2 && Power >= 3000) || (var(20) = 3 && (100*life/const(data.life))<=30) || var(43) || var(14) || var(16)
triggerall = statetype = A
triggerall = Pos Y < -50
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(7) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger8 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger9 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger10 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
trigger11 = (StateNo = [1000,1499]) && (var(20) = 2 || var(20) = 6)
trigger12 = (StateNo = [2800,2999]) && (var(20) = 2 || var(20) = 6)
trigger13 = StateNo = 3000 && (var(20) = 2 || var(20) = 6) && time > 50
trigger14 = StateNo = 3200 && (var(20) = 2 || var(20) = 6) && time > 50
trigger15 = StateNo = 3201 && (var(20) = 2 || var(20) = 6)
trigger16 = StateNo = 3202 && (var(20) = 2 || var(20) = 6)
trigger17 = StateNo = 3205 && (var(20) = 2 || var(20) = 6)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�J�~�i�I
[State -1, hadouken]
type = ChangeState
value = 1500
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !numhelper(30000)
triggerall = Command = "�J�~�i�I1" || Command = "�J�~�i�I2" || Command = "�J�~�i�I3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger5 = StateNo = 221 && (var(16) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger6 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger8 = StateNo = 241 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (var(16) || animelemtime(4) < 0)
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 300 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger18 = StateNo = 320 && (var(16) || animelemtime(2) < 0)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�����̓A�b�p�[
[State -1, hadouken]
type = ChangeState
value = 1000
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�����̓A�b�p�[1" || Command = "�����̓A�b�p�[2" || Command = "�����̓A�b�p�[3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger5 = StateNo = 221 && (var(16) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger6 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger8 = StateNo = 241 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (var(16) || animelemtime(4) < 0)
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 300 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger18 = StateNo = 320 && (var(16) || animelemtime(2) < 0)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�X�i�C�v�G�A�[
[State -1, hadouken]
type = ChangeState
value = 1200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "�X�i�C�v�G�A�[1" || Command = "�X�i�C�v�G�A�[2" || Command = "�X�i�C�v�G�A�[3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger5 = StateNo = 221 && (var(16) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger6 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger8 = StateNo = 241 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (var(16) || animelemtime(4) < 0)
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 300 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger18 = StateNo = 320 && (var(16) || animelemtime(2) < 0)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���b�g�i�[�X�g���C�N
[State -1, hadouken]
type = ChangeState
value = 1100
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = Command = "���b�g�i�[�X�g���C�N1" || Command = "���b�g�i�[�X�g���C�N2" || Command = "���b�g�i�[�X�g���C�N3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger5 = StateNo = 221 && (var(16) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger6 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger8 = StateNo = 241 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (var(16) || animelemtime(4) < 0)
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 300 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger18 = StateNo = 320 && (var(16) || animelemtime(2) < 0)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���b�g�i�[�X�g���C�N�i�󒆁j
[State -1, Hadousho]
type = ChangeState
value = 1300
triggerall = !var(59)
triggerall = !var(4)
triggerall = roundstate = 2
triggerall = Command = "���b�g�i�[�X�g���C�N1" || Command = "���b�g�i�[�X�g���C�N2" || Command = "���b�g�i�[�X�g���C�N3"
triggerall = statetype = A
triggerall = Pos Y < -50
trigger1 = ctrl
trigger2 = StateNo = 600 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(7) < 0))
trigger3 = StateNo = 610 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger4 = StateNo = 620 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger5 = StateNo = 630 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(8) < 0))
trigger6 = StateNo = 640 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger7 = StateNo = 650 && (((var(36) = 1||var(36) = 2) && var(16)) || animelemtime(3) < 0)
trigger8 = (StateNo = [1000,2999]) && var(36) && var(16)
trigger9 = (StateNo = [3000,3299]) && Var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�V�����I
[State -1, hadouken]
type = ChangeState
value = 1400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = !numhelper(20000)
triggerall = Command = "�V�����I1" || Command = "�V�����I2" || Command = "�V�����I3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger5 = StateNo = 221 && (var(16) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger6 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger8 = StateNo = 241 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (var(16) || animelemtime(4) < 0)
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 300 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger18 = StateNo = 320 && (var(16) || animelemtime(2) < 0)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 2800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = Command = "gc" && command != "holddown" && Command = "holdfwd"
trigger1 = Power >= 1000 && (!var(20) || var(20) = 4 || var(20) = 6)
trigger2 = Power >= 1500 && var(20) = 1
trigger3 = var(14) && var(20) = 3

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i�O�j
[State -1]
type = ChangeState
value = 810
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdfwd"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���ړ��i��j
[State -1]
type = ChangeState
value = 820
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 4 || var(20) = 6
triggerall = Power >= 1000
triggerall = Command = "recovery" && command != "holddown" && Command = "holdback"
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !var(59)
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101 || stateno = 40 || (stateno = 52 && anim = 57 && time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger4 = StateNo = 220 && (var(16) || animelemtime(3) < 0)
trigger5 = StateNo = 221 && (var(16) || animelemtime(3) < 0 || ((var(36) = 1||var(36) = 2) && animelemtime(5) < 0))
trigger6 = StateNo = 230 && (var(16) || animelemtime(3) < 0 || (var(36) = 1||var(36) = 2))
trigger7 = StateNo = 240 && (var(16) || animelemtime(4) < 0)
trigger8 = StateNo = 241 && (var(16) || animelemtime(5) < 0 || (var(36) = 1||var(36) = 2))
trigger9 = StateNo = 250 && (var(16) || animelemtime(3) < 0)
trigger10 = StateNo = 400
trigger11 = StateNo = 410 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger12 = StateNo = 420 && (var(16) || animelemtime(4) < 0)
trigger13 = StateNo = 430
trigger14 = StateNo = 440 && (var(16) || animelemtime(4) < 0 || (var(36) = 1||var(36) = 2))
trigger15 = StateNo = 450 && (var(16) || animelemtime(3) < 0)
trigger16 = StateNo = 300 && (var(16) || animelemtime(2) < 0 || (var(36) = 1||var(36) = 2))
trigger17 = StateNo = 310 && (var(16) || animelemtime(2) < 0)
trigger18 = StateNo = 320 && (var(16) || animelemtime(2) < 0)
trigger19 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger20 = (StateNo = [2800,2999]) && var(36) && var(16)
trigger21 = (StateNo = [3000,3299]) && var(5) = 1 && (var(36) = 1||var(36) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = !var(59)
triggerall = var(20) = 3 || var(20) = 4 || var(20) = 5 || var(20) = 6
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 102
triggerall = !var(59)
triggerall = !var(20) || var(20) = 1 || var(20) = 2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !var(59)
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5200
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 4 || var(20) = 5 || var(20) = 6
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Vel Y > 0
triggerall = Pos Y >= 0
trigger1 = command = "recovery"
persistent = 0

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = ((!var(20) || var(20) = 1 || var(20) = 4) && command = "recovery") || (var(20) = 6 && command = "holdfwd" && command = "recovery")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 220 && time < 2
trigger5 = StateNo = 221 && time < 2
trigger6 = StateNo = 230 && time < 2
trigger7 = StateNo = 240 && time < 2
trigger8 = StateNo = 241 && time < 2
trigger9 = StateNo = 250 && time < 2
trigger10 = StateNo = 400 && time < 2
trigger11 = StateNo = 410 && time < 2
trigger12 = StateNo = 420 && time < 2
trigger13 = StateNo = 430 && time < 2
trigger14 = StateNo = 440 && time < 2
trigger15 = StateNo = 450 && time < 2
trigger16 = stateno = 300 && time < 2
trigger17 = stateno = 310 && time < 2
trigger18 = stateno = 320 && time < 2
trigger19 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger20 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger21 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 830
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = var(20) = 3 || var(20) = 6
triggerall = command = "recovery"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 220 && time < 2
trigger5 = StateNo = 221 && time < 2
trigger6 = StateNo = 230 && time < 2
trigger7 = StateNo = 240 && time < 2
trigger8 = StateNo = 241 && time < 2
trigger9 = StateNo = 250 && time < 2
trigger10 = StateNo = 400 && time < 2
trigger11 = StateNo = 410 && time < 2
trigger12 = StateNo = 420 && time < 2
trigger13 = StateNo = 430 && time < 2
trigger14 = StateNo = 440 && time < 2
trigger15 = StateNo = 450 && time < 2
trigger16 = stateno = 300 && time < 2
trigger17 = stateno = 310 && time < 2
trigger18 = stateno = 320 && time < 2
trigger19 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger20 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger21 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 850
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (power < 1000 && var(20) = 3) || (power < 3000 && var(20) = 6)
triggerall = !var(15) && !var(16) && !var(14)
triggerall = (command = "chargec" && command = "chargez")
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 220 && time < 2
trigger5 = StateNo = 221 && time < 2
trigger6 = StateNo = 230 && time < 2
trigger7 = StateNo = 240 && time < 2
trigger8 = StateNo = 241 && time < 2
trigger9 = StateNo = 250 && time < 2
trigger10 = StateNo = 400 && time < 2
trigger11 = StateNo = 410 && time < 2
trigger12 = StateNo = 420 && time < 2
trigger13 = StateNo = 430 && time < 2
trigger14 = StateNo = 440 && time < 2
trigger15 = StateNo = 450 && time < 2
trigger16 = stateno = 300 && time < 2
trigger17 = stateno = 310 && time < 2
trigger18 = stateno = 320 && time < 2

;---------------------------------------------------------------------------
;�p���[MAX����
[State -1]
type = ChangeState
value = 860
triggerall = !var(59)
triggerall = (var(20) = 4 && Command = "oc") || (var(20) = 6 && Command = "gc")
triggerall = Power >= 1000
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 220 && time < 2
trigger5 = StateNo = 221 && time < 2
trigger6 = StateNo = 230 && time < 2
trigger7 = StateNo = 240 && time < 2
trigger8 = StateNo = 241 && time < 2
trigger9 = StateNo = 250 && time < 2
trigger10 = StateNo = 400 && time < 2
trigger11 = StateNo = 410 && time < 2
trigger12 = StateNo = 420 && time < 2
trigger13 = StateNo = 430 && time < 2
trigger14 = StateNo = 440 && time < 2
trigger15 = StateNo = 450 && time < 2
trigger16 = stateno = 300 && time < 2
trigger17 = stateno = 310 && time < 2
trigger18 = stateno = 320 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�n��j
[State -1]
type = ChangeState
value = 870
triggerall = !var(59)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time < 2
trigger3 = StateNo = 210 && time < 2
trigger4 = StateNo = 220 && time < 2
trigger5 = StateNo = 221 && time < 2
trigger6 = StateNo = 230 && time < 2
trigger7 = StateNo = 240 && time < 2
trigger8 = StateNo = 241 && time < 2
trigger9 = StateNo = 250 && time < 2
trigger10 = StateNo = 400 && time < 2
trigger11 = StateNo = 410 && time < 2
trigger12 = StateNo = 420 && time < 2
trigger13 = StateNo = 430 && time < 2
trigger14 = StateNo = 440 && time < 2
trigger15 = StateNo = 450 && time < 2
trigger16 = stateno = 300 && time < 2
trigger17 = stateno = 310 && time < 2
trigger18 = stateno = 320 && time < 2

;---------------------------------------------------------------------------
;�I���R�������i�󒆁j
[State -1]
type = ChangeState
value = 875
triggerall = !var(59)
triggerall = !var(4)
triggerall = var(20) = 1 || var(20) = 6
triggerall = Power >= 3000 && Command = "oc"
triggerall = !var(15) && !var(16)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && time < 2
trigger3 = StateNo = 610 && time < 2
trigger4 = StateNo = 620 && time < 2
trigger5 = StateNo = 630 && time < 2
trigger6 = StateNo = 640 && time < 2
trigger7 = StateNo = 650 && time < 2

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && (command = "z" || command = "c")
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [-22,22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || var(16)

;---------------------------------------------------------------------------
;�X�e�b�v���[�L�b�N
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holdfwd"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���[���N���b�V��
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holdfwd"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�A�T���g�L�b�N
[State -1, Taunt]
type = ChangeState
value = 320
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holdfwd"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�p���`�j
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "x" || command = "y" || command = "z" 
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;�J�E���^�[�U���i�L�b�N�j
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = roundstate = 2
triggerall = !var(59)
triggerall = command = "a" || command = "b" || command = "c"
trigger1 = StateNo = 830 && Time =[14,24]

;---------------------------------------------------------------------------
;������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 400 && time > 4
trigger4 = StateNo = 430 && time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger7 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 400 && time > 4
trigger4 = StateNo = 430 && time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger7 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 241
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X = [-20,20]
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 240
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Taunt]
type = ChangeState
value = 250
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1, Taunt]
type = ChangeState
value = 400
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 400 && time > 4
trigger4 = StateNo = 430 && time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger7 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 420
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1, Taunt]
type = ChangeState
value = 430
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = StateNo = 200 && time > 4
trigger3 = StateNo = 400 && time > 4
trigger4 = StateNo = 430 && time > 4
trigger5 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger6 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger7 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) > 1) || stateno = 101
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
trigger3 = (StateNo = [1000,1499]) && var(36) && var(16)
trigger4 = (StateNo = [2800,2999]) && var(36) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 620
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 640
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
;�W�����v���L�b�N
[State -1]
type = ChangeState
value = 650
triggerall = !var(59)
triggerall = roundstate = 2
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = (StateNo = [195,799]) && (var(36) = 1||var(36) = 2) && var(16)
ignorehitpause = 0

;---------------------------------------------------------------------------
