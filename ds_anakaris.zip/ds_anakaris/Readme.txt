                            __________________________________________
===========================| Anakaris by varo_hades	              |===========================
                            ������������������������������������������        [15.09.18]

 - Contact:	varo_hades@hotmail.com
 - Website:	https://varohades.wixsite.com/varohadesmugen
 - Customized version of Capcom's Anakaris character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, Darkstalkers

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

<NORMAL>

.Reverse Warp				B, B			(When against the wall)
.Seinaru Bohi				D + c			(Air only)
.Ooinaru Bohi				DF + c			(Air only)
.Seija no Ayumi 			F/B + b
.Chi no Gekirin				F/B + c			

<SPECIAL>

.Miira Drop (EX)			D, DF, F, p
.Hitsugi No Mai (EX) (Air)		D, D, p
.Ouke no Sabaki (EX)			D, DF, F, p		(Air only)
.Cobra Blow (EX)			B, F, p
.Kotodama Gaeshi 			D, DB, B, k
.Haku (EX)				D, DF, F, k		(After Kotodama Gaeshi)
.Togame No Ana (EX)			F, D, DF, k		(While knocked down)
.Imashime No Bohi (EX)			D, D, k			(While opponent is downed)

<SUPER>

.Shinjitsu No Oshie (MAX):		F, p			(While blocking)
.Naraku No Ana (MAX):			D, DF, F, D, DF, F, k
.Pharaoh Magic (MAX) (Air):		D, DB, B, D, DB, B, p
.Pharaoh Salvation (MAX) (Air):		D, DB, B, D, DB, B, k
.Pharaoh Decoration (MAX) (Air):	D, DF, F, D, DF, F, p

<Lv3 SUPER>

.Pharaoh Split:               	 	D, DF, F, D, DF, F, 3p / a, a, D, b, c 

<SYSTEM>

.Forward Dash:                  	F, F
   .Run:                        	hold
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	a + x
   .Sidestep Attack:            	p / k
.Forward Roll:                  	F + a + x
.Backward Roll:                 	B + a + x
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold b + y
.Zero Counter:                  	B, DB, D, p / k 	(during standing or crouching guard)
.Custom Combo:                  	c + z           	(Air also)
.Fall Recovery:                 	2p / a + x      	(while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

=====<Miscellaneous>=====

- To change his size to TV aspect ratio (a.k.a. CvS scale), open the .def file and replace
  "ConstantsSFZ.cns" with "ConstantsCvS.cns".

=====<Special Thanks>=====
 - hsiehtm for sprites, code and anims
 - P.o.t.S. for code, effects, hitsparks, formatting style
 - Gal129 for code
 - Everybody at MUGEN for feedback
 - Everybody that won't read the readme first, and claim the credit

=====<Disclaimer>=====

 - The Anakaris character is property of Capcom
 - Capcom vs SNK is property of Capcom
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes