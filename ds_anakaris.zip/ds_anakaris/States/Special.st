; _________________________________________
;| Anakaris by varo_hades                  |
; �����������������������������������������
;==============================================================================================
;========================================<SPECIAL MOVES>=======================================
;==============================================================================================

;=====================<MIIRA DROP>==========================
[StateDef 1000]
type = S
physics = S
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1000, 1] ;Hands sound
type = PlaySnd
trigger1 = AnimElem = 3, = 3
value = 1000,0
channel = 0

[State 1000, 1] ;Hands
type = Helper
trigger1 = var(10) = 0
trigger1 = AnimElem = 3, = 3
name = "Anakaris Hands"
ID = 1011
stateno = 1011
pos = 94, -79

[State 1000, 1] ;Hands
type = Helper
trigger1 = var(10) = 1
trigger1 = AnimElem = 3, = 3
name = "Anakaris Hands"
ID = 1011
stateno = 1011
pos = 156, -79

[State 1000, 1] ;Hands
type = Helper
trigger1 = var(10) = 2
trigger1 = AnimElem = 3, = 3
name = "Anakaris Hands"
ID = 1011
stateno = 1011
pos = 212, -79

[State 1000, 2] ;Hit
type = ChangeState
trigger1 = NumHelper(1011) = 1
trigger1 = helper(1011), stateno = 1012
value = 1001

[State 1000, 3] ;No guard
type = AttackDist
trigger1 = 1
value = 0

[State 1000, 4] ;Get hit
type = ChangeState
trigger1 = numhelper(1011) > 0
trigger1 = helper(1011), stateno = 1014
value = 1003

[State 1000, 5]
type = ChangeState
trigger1 = Time = 44
value = 0
ctrl = 1

;Miira Drop - Grab Successful, Waiting
[Statedef 1001]
type = S
movetype = A
physics = S
velset = 0,0
sprpriority = 2

[State 1001, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1001, 2] ;End hands sound
type = StopSnd
trigger1 = Time = 0
channel = 0

[State 1001, 2] ;Throwing State
type = ChangeState
trigger1 = helper(1011), ParentDist X > -40
trigger2 = helper(1011), stateno = 1013
value = 1002

;Miira Drop - Throwing
[Statedef 1002]
type = S
movetype = A
physics = N
anim = 1001

[State 1002, Swing Sound] ;Swing Sound
type = PlaySnd
trigger1 = AnimElem = 8
trigger2 = AnimElem = 14
trigger3 = AnimElem = 20
trigger4 = AnimElem = 26
trigger5 = AnimElem = 32
value = 1, 1

[State 1002, Crash Sound] ;Crash Sound
type = PlaySnd
trigger1 = AnimElem = 43
value = 1100, 2

[State 1002, Hit Sound] ;Hit Sound
type = PlaySnd
trigger1 = AnimElem = 43
value = 2, 2

[State 1002, SprPriority 1]
type = SprPriority
trigger1 = AnimElem = 43
value = -1

[State 1002, Explod] ;Foot
type = Explod
trigger1 = AnimElem = 43
anim = 1002
bindtime = -1
sprpriority = 2

[State 1011, Impact Sound]
type = PlaySnd
trigger1 = AnimElem = 43
value = 820,2
channel = 1

[State 1011, Impact Dust]
type = Helper
trigger1 = AnimElem = 43
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = ceil(94 * const(size.xScale)),0
facing = -1
ownPal = 1

[State 1002, SprPriority 2]
type = SprPriority
trigger1 = AnimElem = 44
value = 2

[State 1002, State End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Miira Drop - HITG_SHAKE ;Copy of 5000
[Statedef 1003]
type = S
movetype = H
physics = N
velset = 0,0

[State 1003, Custom 1]
type = VarSet
trigger1 = Time = 0
v = 51
value = helper(1011), GetHitVar(animtype)

[State 1003, Custom 2]
type = VarSet
trigger1 = Time = 0
v = 52
value = helper(1011), GetHitVar(fall)

[State 1003, Custom 3]
type = VarSet
trigger1 = Time = 0
fv = 20
value = helper(1011), GetHitVar(yvel)

[State 1003, Custom 4]
type = VarSet
trigger1 = Time = 0
v = 53
value = helper(1011), GetHitVar(hitshaketime)

[State 1003, Custom 5]
type = VarSet
trigger1 = Time = 0
fv = 21
value = helper(1011), GetHitVar(yaccel)

[State 1003, Custom 6]
type = VarSet
trigger1 = Time = 0
fv = 22
value = helper(1011), GetHitVar(xvel)

[State 1003, Custom 7]
type = VarSet
trigger1 = Time = 0
fv = 23
value = helper(1011), GetHitVar(yvel)

[State 1003, Custom 8]
type = VarSet
trigger1 = Time = 0
v = 54
value = helper(1011), GetHitVar(fall)

[State 1003, Custom 9]
type = VarSet
trigger1 = Time = 0
v = 55
value = helper(1011), GetHitVar(hittime)

[State 1003, Custom 10]
type = VarSet
trigger1 = Time = 0
v = 56
value = helper(1011), GetHitVar(groundtype)

[State 1003, Custom 11]
type = VarSet
trigger1 = Time = 0
v = 57
value = helper(1011), GetHitVar(slidetime)

[State 5000, 1] ;Anim for HIT_LIGHT to HIT_HARD
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Var(51) != [3,5] ;GetHitVar(animtype)
value = ifelse((Var(56) = 1),5000,5010) + Var(51) ;GetHitVar(groundtype),GetHitVar(animtype)

[State 5000, 2] ;Anim for HIT_BACK
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Var(51) = [3,5] ;GetHitVar(animtype)
value = 5030

[State 5000, 3] ;Anim for HIT_UP/HIT_DIAGUP (only if it exists)
type = ChangeAnim
trigger1 = Time = 0
trigger1 = (Var(51) = [4,5]) && (SelfAnimExist(5047 + Var(51))) ;GetHitVar(animtype)
value = 5047 + Var(51) ;5051 - 4 + type ;GetHitVar(animtype)

[State 5000, 4] ;Freeze anim
type = ChangeAnim
trigger1 = Time > 0
value = anim

[State 5000, 5] ;State type gets set to aerial if getting hit up
type = StateTypeSet
trigger1 = Time = 0
trigger1 = FVar(23) != 0 || Var(54) ;GetHitVar(yvel),GetHitVar(fall)
trigger2 = Pos Y != 0
statetype = a

[State 5000, 6]
type = ChangeState
trigger1 = Time = Var(53) ;HitShakeTime Over
trigger1 = FVar(23) = 0 && !Var(54) ;GetHitVar(yvel),GetHitVar(fall)
value = 1004 ;HITG_SLIDE ; Copy of 5001

[State 5000, 7]
type = ChangeState
trigger1 = Time = Var(53) ;HitShakeTime Over
value = 661 ; Copy of 5030

[State 5000, FFB Light]
type = ForceFeedback
trigger1 = anim = 5000
trigger2 = anim = 5010
persistent = 0
time = 6
waveform = square

[State 5000, FFB Medium]
type = ForceFeedback
trigger1 = anim = 5001
trigger2 = anim = 5011
persistent = 0
time = 8
waveform = sinesquare
ampl = 110,-1,-.3

[State 5000, FFB Hard]
type = ForceFeedback
trigger1 = anim = 5012
trigger2 = anim = 5002
trigger3 = anim = 5030
persistent = 0
time = 15
waveform = sinesquare
ampl = 140

;Miira Drop - HITG_SLIDE ;Copy of 5001
[Statedef 1004]
type = S
movetype = H
physics = S

[State 5001, 1]
type = VelSet ;HitVelSet
trigger1 = Time = 0
x = FVar(22)*facing ;1

[State 5001, 2]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 5005 + Var(51) + (Var(56)=2)*10 ;GetHitVar(animtype),GetHitVar(groundtype)

[State 5001, 3] ;Stop sliding back
type = VelMul
trigger1 = Time >= Var(57) ;GetHitVar(slidetime)
x = .6

[State 5001, 4]
type = VelSet
trigger1 = Time = Var(55) ;HitOver
x = 0

[State 5001, 5]
type = DefenceMulSet
trigger1 = Time = Var(55) ;HitOver
value = 1

[State 5001, 6]
type = ChangeState
trigger1 = Time = Var(55) ;HitOver
value = 0
ctrl = 1

;Miira Drop - Hands Helper
[Statedef 1011]
type = S
movetype = A
ctrl = 0
juggle  = 3
anim = 1011
sprpriority = -1

[State 1011, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
Trigger1 = Time = 0
attr = S, ST
hitflag = H-
priority = 1, Miss
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -39
p1sprpriority = 1
getPower = ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)), 36 * !(Root, var(20))
givePower = 36, 36
p1facing = 1
p2facing = 1
p1stateno = 1012
p2stateno = 1021
guard.dist = 0
fall = 1
fall.yvelocity = -5
fall.damage = 130
fall.envshake.time = 16
fall.envshake.ampl = 5
fall.envshake.freq = 120

[State 1011, 2]
type = SprPriority
trigger1 = AnimElem = 5
value = 3

[State 1011, 3]
type = DestroySelf
trigger1 = Time = 37
trigger2 = parent, stateno != 1000

[State 1011, 4]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 1014

;Miira Drop - Hands Helper Grabbing
[Statedef 1012]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 1012, Grab Sound]
type = PlaySnd
trigger1 = Time = 1
value = 2, 800

[State 1012, Bind 1]
type = TargetBind
trigger1 = Anim = 1011
pos = 61,9

[State 1012, 1]
type = ChangeAnim
trigger1 = Anim = 1011
trigger1 = AnimElemTime(4) > 1
value = 1012

[State 1012, 2]
type = PosAdd
trigger1 = Anim = 1012
trigger1 = AnimElemTime(1) >= 9
x = -19

[State 1012, Bind 2]
type = TargetBind
trigger1 = Anim = 1012
pos = 53,9

[State 1012, 3]
type = TargetState
trigger1 = ParentDist X > -40
value = 1022

[State 1012, 4]
type = ChangeState
trigger1 = ParentDist X > -40
value = 1013

[State 1012, 5]
type = DestroySelf
trigger1 = parent, stateno != [1000,1002]

;Miira Drop - Hands Helper Waiting
[Statedef 1013]
type = A
movetype = A
ctrl = 0
anim = 1013
velset = 0,0
sprpriority = 3

[State 1013, 1]
type = BindToParent
trigger1 = 1
pos = 0, 0

[State 1013, Bind 1]
type = TargetBind
trigger1 = parent, Anim = 1001
trigger1 = parent, AnimElemTime(43) < 0
pos = 0, 0

[State 1013, Bind 2]
type = TargetBind
trigger1 = parent, Anim = 1001
trigger1 = parent, AnimElemTime(43) = 0
pos = 80,0

[State 1013, 3]
type = TargetState
trigger1 = parent, Anim = 1001
trigger1 = parent, AnimElem = 43
value = 1023

[State 1013, 4]
type = DestroySelf
trigger1 = target, stateno != 1022
trigger1 = target, stateno != 1023
trigger2 = parent, stateno != [1000,1002]

;Miira Drop - Helper Hit
[Statedef 1014]
type = A
movetype = H
ctrl = 0

[State 1014, 1]
type = DestroySelf
trigger1 = 1

;Miira Drop - Grabbed
[Statedef 1021]
type = A
movetype = H
physics = N
velset = 0,0

[State 1021, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1021

[State 1021, No scroll]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1021, 2]
type = SelfState
trigger1 = !gethitvar(isbound)
value = 5050

;Miira Drop - Being Thrown
[Statedef 1022]
type = A
movetype = H
physics = N
velset = 0,0

[State 1022, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1022

[State 1021, No scroll]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1022, 2]
type = SelfState
trigger1 = !gethitvar(isbound)
value = 5100

;Miira Drop - Being Thrown End - HIT_BOUNCE (hit ground)
[Statedef 1023]
type = L
movetype = H
physics = N

[State 1023, No scroll]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1023, 1]
type = VelSet
trigger1 = Time = 0
trigger1 = GetHitVar(fall.yvel) = 0
trigger1 = vel x > 1
x = 1

[State 1023, EnvShake]
type = FallEnvShake
trigger1 = Time = 0

[State 1023, Var] ;Save fall velocity
type = VarSet
trigger1 = Time = 0
;trigger1 = GetHitVar(fall.yvel) = 0
sysvar(1) = floor(vel y)

[State 1023, 2] ;Hit ground anim (normal)
type = ChangeAnim
triggerall = time = 0
trigger1 = (anim != [5051,5059]) && (anim != [5061,5069])
trigger2 = !SelfAnimExist(5100 + (anim % 10))
value = 5100

[State 1023, 3] ;Hit ground anim (for hit up)
type = ChangeAnim
trigger1 = time = 0
trigger1 = (anim = [5051,5059]) || (anim = [5061,5069])
trigger1 = SelfAnimExist(5100 + (anim % 10))
value = 5100 + (anim % 10)

[State 1023, 4]
type = PosSet
trigger1 = Time = 0
y = 0

[State 1023, 5]
type = VelSet
trigger1 = Time = 0
y = 0

[State 1023, 6] ;Reduce speed
type = VelMul
trigger1 = Time = 0
x = 0.75

[State 1023, 7]
type = SelfState
trigger1 = Time = 0
trigger1 = GetHitVar(fall.yvel) = 0
value = 5110 ;HIT_LIEDOWN

[State 1023, 9]
type = HitFallDamage
trigger1 = Time = 3

[State 1023, 11]
type = PosFreeze
trigger1 = 1

[State 1023, 12] ;Freeze last frame of animation
type = ChangeAnim
trigger1 = AnimTime = 0
value = Anim
elem = AnimElemNo(-1)

[State 1023, 12]
type = VelSet
trigger1 = Time = 20
x = -4

[State 1023, 13]
type = ChangeState
trigger1 = Time = 20
value = 1024

[State 1023, 14]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1023, 15]
type = ForceFeedback
trigger1 = Time = 0
waveform = sinesquare
ampl = 128,-3,-.2,.005
time = 20

;Miira Drop - Being Thrown End - HIT_BOUNCE (bounce into air)
[Statedef 1024]
type = L
movetype = H
physics = N

[State 1024, 1] ;Coming hit ground anim (normal)
type = ChangeAnim
triggerall = time = 0
trigger1 = anim != [5101,5109]
trigger2 = !SelfAnimExist(5160 + (anim % 10))
value = 5160

[State 1024, 2] ;Coming hit ground anim (for hit up)
type = ChangeAnim
triggerall = time = 0
trigger1 = anim = [5101,5109]
trigger1 = SelfAnimExist(5160 + (anim % 10))
value = 5160 + (anim % 10)

[State 1024, 3]
type = HitFallVel
trigger1 = Time = 0

[State 1024, 4]
type = PosSet
trigger1 = Time = 0
y = 20

[State 1024, 5] ;Acceleration
type = VelAdd
trigger1 = 1
y = .4

[State 1024, Custom 1] ;Hit ground
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 12
type = VelSet
x = 0

[State 1024, 6] ;Hit ground
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 12
type = SelfState
value = 5110

;========================<EX MIIRA DROP>=============================
[StateDef 1030]
type = S
physics = S
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 224

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, 1] ;Hands sound
type = PlaySnd
trigger1 = AnimElem = 3, = 3
value = 1030,0
channel = 0

[State 1030, 2] ;Hands
type = Helper
trigger1 = AnimElem = 3, = 3
name = "Anakaris Hands"
ID = 1041
stateno = 1041
pos = 71,-79

[State 1030, 3] ;Hit
type = ChangeState
trigger1 = NumHelper(1041) = 1
trigger1 = helper(1041), movecontact = 1
value = 1031

[State 2030, 4]
type = ChangeState
trigger1 = Time = 105
value = 0
ctrl = 1

;EX Miira Drop - Grab Successful, Waiting
[Statedef 1031]
type = S
movetype = A
physics = S
velset = 0,0
sprpriority = 2

[State 1031, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1031, 2] ;End hands sound
type = StopSnd
trigger1 = Time = 0
channel = 0

[State 1031, 3] ;Hit
type = ChangeState
trigger1 = helper(1041), ParentDist X > -40
trigger2 = helper(1041), stateno = 1043
value = 1032

;EX Miira Drop - Throwing
[Statedef 1032]
type = S
movetype = A
physics = N
anim = 1031
sprpriority = 0

[State 1032, Crash Sound] ;Crash Sound
type = PlaySnd
trigger1 = AnimElem = 9, = 1
trigger2 = AnimElem = 15, = 1
trigger3 = AnimElem = 21, = 1
value = 1100, 1

[State 1032, SprPriority 1]
type = SprPriority
trigger1 = AnimElem = 28
value = -1

[State 1032, Explod 1] ;Khybit
type = Explod
trigger1 = AnimElem = 28
anim = 1033
bindtime = -1
sprpriority = 0
shadow = 255,255,255
ownpal = 1

[State 1032, Twang Sound] ;Kick Out Twang Sound
type = PlaySnd
trigger1 = AnimElem = 29
value = 1030, 1

[State 1032, Special Khybit] ;Special Khybit
type = Helper
triggerall = AnimElem = 29
trigger1 = command = "holdstart"
trigger2 = Random < 50
pos = 0,-43
stateno = 1060

[State 1032, Kick Out Sound] ;Kick Out Crash Sound
type = PlaySnd
trigger1 = AnimElem = 29
value = 1100, 2

[State 1032, Explod 2] ;Foot
type = Explod
trigger1 = AnimElem = 29
anim = 1032
bindtime = -1
removetime = 30
sprpriority = 1
shadow = 255,255,255

[State 1032, State End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;EX Miira Drop - Hands Helper
[Statedef 1041]
type = S
movetype = A
ctrl = 0
juggle  = 3
anim = 1041
sprpriority = 3

[State 2041, 1] ;Right Hand Appear
type = Explod
trigger1 = Time = 0
anim = 1051
ID = 1051
bindtime = -1
sprpriority = -1
removeongethit = 1

[State 1041, 2]
type = VelSet
trigger1 = AnimElem = 4
x = 2.5

[State 1041, 3] ;Left Hand Helper
type = Helper
trigger1 = AnimElem = 4
name = "Left Hand"
ID = 1044
stateno = 1044
pos = 0,0

[State 1041, 4] ;Right Hand Helper
type = Helper
trigger1 = AnimElem = 4
name = "Right Hand"
ID = 1045
stateno = 1045
pos = 0,0

[State 1041, 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 4
attr = S, HT
hitflag = MA-
priority = 1, Miss
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -39
p1sprpriority = 1
getPower = 0,0
givePower = 36, 36
p1facing = 1
p2facing = 1
p1stateno = 1042
p2stateno = 1051
guard.dist = 0
fall = 1
fall.yvelocity = -8
fall.damage = 35
fall.envshake.time = 16
fall.envshake.ampl = 5
fall.envshake.freq = 120
getpower = 0

[State 1041, 5] ;Remove Right Hand
type = RemoveExplod
trigger1 = parent, stateno != 1030
ID = 1051

[State 1041, 6]
type = DestroySelf
trigger1 = parent, stateno != 1030

[State 1041, 7] ;Miss
type = ChangeState
trigger1 = Time = 77
value = 1046

;EX Miira Drop - Hands Helper Grabbing
[Statedef 1042]
type = A
movetype = A
ctrl = 0
anim = 1043
velset = 0,0
sprpriority = 3

[State 1042, Right Hand] ;Right Hand Appear
type = Explod
trigger1 = Time = 0
anim = 1053
ID = 1053
bindtime = -1
removetime = -1
sprpriority = -1
removeongethit = 1

[State 1042, Grab Sound]
type = PlaySnd
trigger1 = Time = 1
value = 2, 800

[State 1042, 1]
type = PosAdd
trigger1 = AnimElemTime(1) >= 10
x = -19

[State 1042, Bind 2]
type = TargetBind
trigger1 = 1
pos = 53,9

[State 1042, Remove Right Hand] ;Remove Right Hand Appear
type = RemoveExplod
trigger1 = ParentDist X > -40
trigger2 = parent, stateno != [1030,1032]
ID = 1053

[State 1042, 2]
type = TargetState
trigger1 = ParentDist X > -40
value = 1052

[State 1042, 3]
type = ChangeState
trigger1 = ParentDist X > -40
value = 1043

[State 1042, 4]
type = DestroySelf
trigger1 = parent, stateno != [1030,1032]

;EX Miira Drop - Hands Helper Waiting
[Statedef 1043]
type = A
movetype = A
ctrl = 0
anim = 1035
velset = 0,0
sprpriority = 3

[State 1043, 1]
type = BindToParent
trigger1 = 1
pos = 0, 0

[State 1043, Crash TargetLifeAdd] ;Crash Sound
type = TargetLifeAdd
trigerall = parent, Anim = 1031
trigger1 = parent, AnimElem = 9, = 1
trigger2 = parent, AnimElem = 15, = 1
trigger3 = parent, AnimElem = 21, = 1
value = -35
kill = 0

[State 1043, Bind 1]
type = TargetBind
trigger1 = parent, Anim = 1031
trigger1 = parent, AnimElemTime(29) < 0
pos = 0, 0

[State 1043, Bind 2]
type = TargetBind
trigger1 = parent, Anim = 1031
trigger1 = parent, AnimElemTime(29) = 0
pos = 80,0

[State 1043, 3]
type = TargetState
trigger1 = parent, Anim = 1031
trigger1 = parent, AnimElem = 29
value = 1053

[State 1043, 4] ;Set win type to ES
type = ParentVarSet
triggerall = numtarget != 0
triggerall = target, Life = 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life = 0
trigger2 = enemynear(1), life = 0
v = 5
value = 1
persistent = 0

[State 1043, 5]
type = DestroySelf
trigger1 = target, stateno != 1052
trigger1 = target, stateno != 1053
trigger2 = parent, stateno != [1030,1032]

;EX Miira Drop - Hands Helper - Left Hand
[Statedef 1044]
type = A
movetype = A
ctrl = 0
anim = 1042
sprpriority = 4

[State 1044, 1]
type = BindToParent
trigger1 = Time < 70
pos = 0,-40*sin(time*2*pi/32)

[State 1044, 2]
type = DestroySelf
trigger1 = Time = 91
trigger2 = parent, stateno != 1041
trigger2 = parent, stateno != 1046
trigger3 = root, stateno != 1030

;EX Miira Drop - Hands Helper - Right Hand
[Statedef 1045]
type = A
movetype = A
ctrl = 0
anim = 1052
sprpriority = -1

[State 1044, 1]
type = BindToParent
trigger1 = Time < 70
pos = 0,40*sin(time*2*pi/32)

[State 1044, 2]
type = DestroySelf
trigger1 = Time = 91
trigger2 = parent, stateno != 1041
trigger2 = parent, stateno != 1046
trigger3 = root, stateno != 1030

;EX Miira Drop - Hands Miss
[Statedef 1046]
type = A
movetype = A
velset = 0,0
sprpriority = 3

[State 2046, 1]
type = DestroySelf
trigger1 = Time = 21

;EX Miira Drop - Grabbed
[Statedef 1051]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = 1

[State 1051, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1021

[State 1051, No scroll]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1051, 2]
type = SelfState
trigger1 = !gethitvar(isbound)
value = 5050

;EX Miira Drop - Being Thrown
[Statedef 1052]
type = A
movetype = H
physics = N
velset = 0,0

[State 1052, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1022

[State 1052, No scroll]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 0,0

[State 1052, 2]
type = SelfState
trigger1 = !gethitvar(isbound)
value = 5100

;Vampire Savior - HIT_BOUNCE (hit ground) - EX Miira Drop - Being Thrown End
[Statedef 1053]
type = L
movetype = H
physics = N

[State 1053, No scroll]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 0,0

[State 1053, 1]
type = VelSet
trigger1 = Time = 0
trigger1 = GetHitVar(fall.yvel) = 0
trigger1 = vel x > 1
x = 1

[State 1053, EnvShake]
type = FallEnvShake
trigger1 = Time = 0

[State 1053, Var] ;Save fall velocity
type = VarSet
trigger1 = Time = 0
;trigger1 = GetHitVar(fall.yvel) = 0
sysvar(1) = floor(vel y)

[State 1053, 2] ;Hit ground anim (normal)
type = ChangeAnim
trigger1 = time = 0
trigger1 = !SelfAnimExist(5101)
value = 5100

[State 1053, 3] ;Hit ground anim (for hit up)
type = ChangeAnim
trigger1 = time = 0
trigger1 = SelfAnimExist(5101)
value = 5101

[State 1053, 4]
type = PosSet
trigger1 = Time = 0
y = 0

[State 1053, 5]
type = VelSet
trigger1 = Time = 0
y = 0

[State 1053, 6] ;Reduce speed
type = VelMul
trigger1 = Time = 0
x = 0.75

[State 1053, 7]
type = SelfState
trigger1 = Time = 0
trigger1 = GetHitVar(fall.yvel) = 0
value = 5110 ;HIT_LIEDOWN

[State 1053, 9]
type = HitFallDamage
trigger1 = Time = 3

[State 1053, 11]
type = PosFreeze
trigger1 = 1

[State 1053, 12] ;Freeze last frame of animation
type = ChangeAnim
trigger1 = AnimTime = 0
value = Anim
elem = AnimElemNo(-1)

[State 1053, Custom 1] ;Simulate HitShake
type = Offset
triggerall = Time >= 10
trigger1 = Time % 4 = [0,1]
x = 0

[State 1053, Custom 2] ;Simulate HitShake
type = Offset
triggerall = Time >= 10
trigger1 = Time % 4 = [2,3]
x = -2

[State 1053, Custom 3]
type = VelSet
trigger1 = Time = 20
x = -3

[State 1053, 13]
type = ChangeState
trigger1 = Time = 20
value = 1054

[State 1053, 14]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1053, 15]
type = ForceFeedback
trigger1 = Time = 0
waveform = sinesquare
ampl = 128,-3,-.2,.005
time = 20

;Vampire Savior - Miira Drop - Being Thrown End - HIT_BOUNCE (bounce into air)
[Statedef 1054]
type = L
movetype = H
physics = N

[State 1054, 1] ;Coming hit ground anim (normal)
type = ChangeAnim
triggerall = time = 0
trigger1 = anim != [5101,5109]
trigger2 = !SelfAnimExist(5160 + (anim % 10))
value = 5160

[State 1054, 2] ;Coming hit ground anim (for hit up)
type = ChangeAnim
triggerall = time = 0
trigger1 = anim = [5101,5109]
trigger1 = SelfAnimExist(5160 + (anim % 10))
value = 5160 + (anim % 10)

[State 1054, 3]
type = HitFallVel
trigger1 = Time = 0

[State 1054, 4]
type = PosSet
trigger1 = Time = 0
y = 20

[State 1054, 5] ;Acceleration
type = VelAdd
trigger1 = 1
y = .4

[State 1054, Custom 1] ;Hit ground
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 12
type = VelSet
x = 0

[State 1054, 6] ;Hit ground
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 12
type = SelfState
value = 5110

;EX Miira Drop - Khybit - In Air
[Statedef 1060]
type = A
movetype = I
physics = N
ctrl = 0
anim = 6110
velset = 4,0
sprpriority = -1

[State 1060, 1]
type = VarSet
trigger1 = Time = 0
v = 40
value = 2

[State 1060, 2]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1060, 3] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1060, 4]
type = ChangeState
trigger1 = Pos Y >= 0
value = 1061

;EX Miira Drop - Khybit - On Ground
[Statedef 1061]
type = S
movetype = I
physics = N
ctrl = 0
anim = 6111
velset = 0,0
sprpriority = -1

[State 1061, 1]
type = PosSet
trigger1 = Time = 0
y = 0

[State 1061, 2]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1061, 3]
type = ChangeState
trigger1 = Var(40) <= 0
trigger1 = Time >= 20
value = 1063

[State 1061, 4]
type = ChangeState
trigger1 = Var(40) > 0
trigger1 = Time = 2
value = 1062

;EX Miira Drop - Khybit - Bounce
[Statedef 1062]
type = S
movetype = I
physics = N
ctrl = 0
anim = 6110
velset = 4,-1
sprpriority = -1

[State 1061, 1]
type = VarAdd
trigger1 = Time = 0
v = 40
value = -1

[State 1062, 2]
type = PosSet
trigger1 = Time = 0
y = 0

[State 1062, 3]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1062, 4] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1062, 5]
type = ChangeState
trigger1 = Pos Y >= 0
trigger1 = Vel Y >= 0
value = 1061

;EX Miira Drop - Khybit - Fade
[Statedef 1063]
type = S
movetype = I
physics = N
ctrl = 0
anim = 6112
velset = 0,0
sprpriority = -1

[State 1063, 1]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1063, 2]
type = DestroySelf
trigger1 = Time = 20

;========================<HITSUGI NO MAI>=============================
[StateDef 1100]
type = S
physics = S
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1100, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 1100, 2] ;Coffin
type = Helper
trigger1 = var(10) = 0
trigger1 = AnimElem = 7, = 2
name = "Coffin"
ID = 1101
stateno = 1101
pos = 96,-240

[State 1100, 2] ;Coffin
type = Helper
trigger1 = var(10) = 1
trigger1 = AnimElem = 7
name = "Coffin"
ID = 1101
stateno = 1101
pos = 160,-240

[State 1100, 2] ;Coffin
type = Helper
trigger1 = var(10) = 2
trigger1 = AnimElem = 7
name = "Coffin"
ID = 1101
stateno = 1101
pos = 224,-240

[State 1100, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Hitsugi no Mai - Coffin Falling
[Statedef 1101]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,16
anim = 1101
sprpriority = 3

[State 1101, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1101, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1101, 1]
type = HitDef
trigger1 = AnimElem = 1
attr = A, SA
animtype  = Medium
damage = ceil(ifElse(fvar(11) * 120 < 7, 7, fvar(11) * 120)), 8
getPower = ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)), 36 * !(Root, var(20))
givePower = 36, 36
hitflag = MA
guardflag = HA
pausetime = 0,11
sparkno = -1
hitsound = -1
guardsound = S6,0
ground.type = High
ground.slidetime = 9
ground.hittime  = 9
ground.velocity = -3,-7
air.velocity = -3,-7
fall = -1
fall.yvelocity = -3
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd = -255,-255,-255,48
sprPriority = 3

[State 1101, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 1101, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1101, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1101, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 1101, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 1101, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 1101, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1100,1130]
var(18) = 1
persistent = 0

[State 1101, 2]
type = PosSet
trigger1 = Pos Y >= 0
y = 0

[State 1101, 3]
type = ChangeState
trigger1 = Pos Y = 0
trigger2 = MoveContact
value = 1102

;Hitsugi no Mai - Coffin Hitting
[Statedef 1102]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
anim = 1102
sprpriority = 3

[State 1102, 1]
type = null;EnvShake
trigger1 = Time = 0
time = 16
ampl = 5
freq = 120

[State 1102, 2] ;Crash Sound
type = PlaySnd
trigger1 = Time = 0
value = 1100, 1

[State 1102, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 1103

;Hitsugi no Mai - Coffin Rising
[Statedef 1103]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,-9
anim = 1101
sprpriority = 3

[State 1103, 3]
type = DestroySelf
trigger1 = Pos Y <= -240

;========================<EX HITSUGI NO MAI>=============================
[StateDef 1130]
type = S
physics = S
moveType = A
anim = 1130
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1130, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1130, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1130, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 231

[State 1130, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1130, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1130, 1] ;Voice
type = PlaySnd
trigger1 = AnimElem = 1
trigger2 = AnimElem = 9
trigger3 = AnimElem = 16
trigger4 = AnimElem = 23
trigger5 = AnimElem = 30
trigger6 = AnimElem = 37
trigger7 = AnimElem = 44
trigger8 = AnimElem = 51
value = 1130, 0
channel = 0

[State 1130, 2] ;Coffin
type = Helper
trigger1 = AnimElem = 7, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 160,-240

[State 1130, 3] ;Coffin
type = Helper
trigger1 = AnimElem = 14, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 256,-240

[State 1130, 4] ;Coffin
type = Helper
trigger1 = AnimElem = 21, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 112,-240

[State 1130, 5] ;Coffin
type = Helper
trigger1 = AnimElem = 28, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 192,-240

[State 1130, 6] ;Coffin
type = Helper
trigger1 = AnimElem = 35, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 96,-240

[State 1130, 7] ;Coffin
type = Helper
trigger1 = AnimElem = 42, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 256,-240

[State 1130, 8] ;Coffin
type = Helper
trigger1 = AnimElem = 49, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 144,-240

[State 1130, 9] ;Coffin
type = Helper
trigger1 = AnimElem = 56, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 224,-240

[State 1130, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;EX Hitsugi no Mai - Coffin Falling
[Statedef 1131]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,16
anim = 1101
sprpriority = 3

[State 1131, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1131, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1131, 1]
type = HitDef
trigger1 = AnimElem = 1
attr = A, HA
animtype  = Medium
damage = ceil(ifElse(fvar(11) * 130 < 7, 7, fvar(11) * 130)), 8
getPower = 0,0
givePower = 36, 36
hitflag = MA
guardflag = HA
pausetime = 0,11
sparkno = -1
hitsound   = -1
guardsound = S6,0
ground.type = High
ground.slidetime = 9
ground.hittime  = 9
ground.velocity = -3,-7
air.velocity = -3,-7
fall = -1
fall.yvelocity = -3
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd = -255,-255,-255,48
sprPriority = 3

[State 1131, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 1131, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1131, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1131, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 1131, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 1131, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 1131, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1100,1130]
var(18) = 1
persistent = 0

[State 1131, 2]
type = PosSet
trigger1 = Pos Y >= 0
y = 0

[State 1131, 3]
type = ChangeState
trigger1 = Pos Y = 0
trigger2 = MoveContact
value = 1132

;Hitsugi no Mai - Coffin Hitting
[Statedef 1132]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
anim = 1102
sprpriority = 3

[State 1132, 1] ;Set win type to ES
type = ParentVarSet
triggerall = numtarget != 0
triggerall = target, Life = 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life = 0
trigger2 = enemynear(1), life = 0
v = 5
value = 1
persistent = 0

[State 1132, 2]
type = null;EnvShake
trigger1 = Time = 0
time = 16
ampl = 5
freq = 120

[State 1132, 3] ;Crash Sound
type = PlaySnd
trigger1 = Time = 0
value = 1100, 1

[State 1132, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 1103

;========================<AIR HITSUGI NO MAI>=============================
[StateDef 1150]
type = A
physics = N
moveType = A
anim = 1150
ctrl = 0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1150, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1150, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1150, 1]
type = PosFreeze
trigger1 = 1
value = 1

[State 1150, 2] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 1150, 3] ;Coffin
type = Helper
trigger1 = var(10) = 0
trigger1 = AnimElem = 7, = 2
name = "Coffin"
ID = 1101
stateno = 1101
pos = 96,-240

[State 1150, 3] ;Coffin
type = Helper
trigger1 = var(10) = 1
trigger1 = AnimElem = 7, = 2
name = "Coffin"
ID = 1101
stateno = 1101
pos = 160,-240

[State 1150, 3] ;Coffin
type = Helper
trigger1 = var(10) = 2
trigger1 = AnimElem = 7, = 2
name = "Coffin"
ID = 1101
stateno = 1101
pos = 224,-240

[State 1150, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 1150, 4]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 1150, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;========================<EX AIR HITSUGI NO MAI>=============================
[StateDef 1180]
type = A
physics = N
moveType = A
anim = 1180
ctrl = 0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1180, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1180, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1180, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 231

[State 1180, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1180, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1180, 1]
type = PosFreeze
trigger1 = 1
value = 1

[State 1180, 2] ;Voice
type = PlaySnd
trigger1 = AnimElem = 1
trigger2 = AnimElem = 9
trigger3 = AnimElem = 16
trigger4 = AnimElem = 23
trigger5 = AnimElem = 30
trigger6 = AnimElem = 37
trigger7 = AnimElem = 44
trigger8 = AnimElem = 51
value = 1130, 0
channel = 0

[State 1180, 3] ;Coffin
type = Helper
trigger1 = AnimElem = 7, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 160,-240

[State 1180, 4] ;Coffin
type = Helper
trigger1 = AnimElem = 14, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 256,-240

[State 1180, 5] ;Coffin
type = Helper
trigger1 = AnimElem = 21, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 112,-240

[State 1180, 6] ;Coffin
type = Helper
trigger1 = AnimElem = 28, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 192,-240

[State 1180, 7] ;Coffin
type = Helper
trigger1 = AnimElem = 35, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 96,-240

[State 1180, 8] ;Coffin
type = Helper
trigger1 = AnimElem = 42, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 256,-240

[State 1180, 9] ;Coffin
type = Helper
trigger1 = AnimElem = 49, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 144,-240

[State 1180, 10] ;Coffin
type = Helper
trigger1 = AnimElem = 56, = 2
name = "Coffin"
ID = 1101
stateno = 1131
pos = 224,-240

[State 1180, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 1180, 11]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 1180, 12]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;=====================<OUKI NO SABAKI>==========================
[StateDef 1200]
type = A
physics = N
moveType = A
anim = 1200
ctrl = 0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1200, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1200, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1200, 1]
type = PosFreeze
trigger1 = 1
value = 1

[State 1200, 2] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 1200, 3] ;Projectile
type = Helper
trigger1 = var(10) = 0
trigger1 = AnimElem = 5, = 1
name = "Royal Judgement"
ID = 1210
stateno = 1209
pos = 96,-73
ownpal = 1

[State 1200, 3] ;Projectile
type = Helper
trigger1 = var(10) = 1
trigger1 = AnimElem = 5, = 1
name = "Royal Judgement"
ID = 1210
stateno = 1209
pos = 96,-73
ownpal = 1

[State 1200, 3] ;Projectile
type = Helper
trigger1 = var(10) = 2
trigger1 = AnimElem = 5, = 1
name = "Royal Judgement"
ID = 1210
stateno = 1209
pos = 96,-73
ownpal = 1

[State 1200, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 1200, 4]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 1200, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;Ouke no Sabaki - Projectile Helper - VarSet Time Left
[Statedef 1209]
type = A
movetype = A

[State 1209, 1] ;Transformed Time Left
type = VarSet
trigger1 = 1
v = 1
value = 49 + 200

[State 1209, 2]
type = VelSet
trigger1 = 1
x = 4
y = 2

[State 1209, 3]
type = ChangeState
trigger1 = 1
value = 1210

;Ouke no Sabaki - Projectile Helper
[Statedef 1210]
type = A
movetype = A
ctrl = 0
juggle  = 3
anim = 1210
sprpriority = -1

[State 1210, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1210, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1210, 1]
type = HitDef
trigger1 = Time = 25
attr = A, SP
damage = ceil(ifElse(fvar(11) * 100 < 7, 7, fvar(11) * 100)), 8
getPower = ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)), 36 * !(Root, var(20))
givePower = 36, 36
hitflag = MA-
guardflag = MA
priority = 1, Miss
pausetime = 0,10
sparkno = -1
hitsound = S1200,1
guardsound = S3,0
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 1215
p2stateno = 1220
ground.velocity = -4,-6
air.velocity = -3,-6
fall = 1
numhits = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd = -255,-255,-255,48
sprPriority = 3

[State 1210, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 1210, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1210, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1210, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 1210, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 1210, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 1210, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1200,1230]
var(18) = 1
persistent = 0

[State 1210, 2]
type = Helper
trigger1 = Time = 0
trigger2 = Time = 8
trigger3 = Time = 16
trigger4 = Time = 24
name = "Ghost"
ID = 1212
stateno = 1211

[State 1210, 3]
type = PosFreeze
trigger1 = Time < 25
value = 1

[State 1210, 4] ;Miss
type = ChangeState
trigger1 = Pos Y >= -30
trigger2 = MoveGuarded
value = 1214

;Ouke no Sabaki - Projectile Helper's Helper - Individual Ghost Image
[Statedef 1211]
type = A
movetype = A
ctrl = 0
anim = 1211
sprpriority = 3

[State 1211, BindToParent 1]
type = BindToParent
trigger1 = Anim = 1211
trigger1 = parent, stateno = 1210
pos = 0,0

[State 1211, BindToParent 1]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
pos = 0,0

[State 1211, BindToParent 2]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
pos = 5,0

[State 1211, BindToParent 3]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
pos = 10,-1

[State 1211, BindToParent 4]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
pos = 14,-2

[State 1211, BindToParent 5]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(5) >= 0 && AnimElemTime(6) < 0
pos = 18,-2

[State 1211, BindToParent 6]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
pos = 20,-3

[State 1211, BindToParent 7]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(7) >= 0 && AnimElemTime(8) < 0
pos = 22,-4

[State 1211, BindToParent 8]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(8) >= 0 && AnimElemTime(9) < 0
pos = 23,-5

[State 1211, BindToParent 9]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(9) >= 0 && AnimElemTime(10) < 0
pos = 22,-6

[State 1211, BindToParent 10]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(10) >= 0 && AnimElemTime(11) < 0
pos = 19,-6

[State 1211, BindToParent 11]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(11) >= 0 && AnimElemTime(12) < 0
pos = 17,-7

[State 1211, BindToParent 12]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(12) >= 0 && AnimElemTime(13) < 0
pos = 13,-7

[State 1211, BindToParent 13]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(13) >= 0 && AnimElemTime(14) < 0
pos = 9,-8

[State 1211, BindToParent 14]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(14) >= 0 && AnimElemTime(15) < 0
pos = 4,-9

[State 1211, BindToParent 15]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(15) >= 0 && AnimElemTime(16) < 0
pos = -1,-9

[State 1211, BindToParent 16]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(16) >= 0 && AnimElemTime(17) < 0
pos = -5,-9

[State 1211, BindToParent 17]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(17) >= 0 && AnimElemTime(18) < 0
pos = -9,-9

[State 1211, BindToParent 18]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(18) >= 0 && AnimElemTime(19) < 0
pos = -14,-9

[State 1211, BindToParent 19]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(19) >= 0 && AnimElemTime(20) < 0
pos = -19,-8

[State 1211, BindToParent 20]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(20) >= 0 && AnimElemTime(21) < 0
pos = -23,-7

[State 1211, BindToParent 21]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(21) >= 0 && AnimElemTime(22) < 0
pos = -27,-7

[State 1211, BindToParent 22]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(22) >= 0 && AnimElemTime(23) < 0
pos = -29,-6

[State 1211, BindToParent 23]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(23) >= 0 && AnimElemTime(24) < 0
pos = -32,-6

[State 1211, BindToParent 24]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(24) >= 0 && AnimElemTime(25) < 0
pos = -33,-5

[State 1211, BindToParent 25]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(25) >= 0 && AnimElemTime(26) < 0
pos = -32,-4

[State 1211, BindToParent 26]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(26) >= 0 && AnimElemTime(27) < 0
pos = -30,-3

[State 1211, BindToParent 27]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(27) >= 0 && AnimElemTime(28) < 0
pos = -28,-2

[State 1211, BindToParent 28]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(28) >= 0 && AnimElemTime(29) < 0
pos = -24,-2

[State 1211, BindToParent 29]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(29) >= 0 && AnimElemTime(30) < 0
pos = -20,-1

[State 1211, BindToParent 30]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(30) >= 0 && AnimElemTime(31) < 0
pos = -15,0

[State 1211, BindToParent 31]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(31) >= 0 && AnimElemTime(32) < 0
pos = -10,0

[State 1211, BindToParent 32]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1210
trigger1 = AnimElemTime(32) >= 0
pos = -5,0

[State 1211, ChangeAnim 1]
type = ChangeAnim
trigger1 = Anim = 1211
trigger1 = AnimTime = 0
value = 1212

[State 1211, SprPriority 1]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 5
value = 2

[State 1211, SprPriority 2]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 9
value = 0

[State 1211, SprPriority 3]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 13
value = -1

[State 1211, SprPriority 4]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 17
value = 0

[State 1211, SprPriority 5]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 21
value = 2

[State 1211, SprPriority 6]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 29
value = 3

;[State 1211, PosAdd]
;type = PosAdd
;trigger1 = Anim = 1212
;trigger1 = parent, stateno != 1210
;x = -5 + 27*cos(2*PI*(AnimElemNo(0)+7)/32)
;y = -5 +  5*sin(2*PI*(AnimElemNo(0)+7)/32)

[State 1211, ChangeAnim 2]
type = ChangeAnim
trigger1 = Anim = 1212
trigger1 = parent, stateno != 1210
value = 1213

[State 1211, Explod 1]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(5) >= 0
trigger1 = AnimElemTime(9) < 0
anim = 1215
sprpriority = 3

[State 1211, Explod 2]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(9) >= 0
trigger1 = AnimElemTime(13) < 0
anim = 1215
sprpriority = 1

[State 1211, Explod 3]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(13) >= 0
trigger1 = AnimElemTime(17) < 0
anim = 1215
sprpriority = 0

[State 1211, Explod 4]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(17) >= 0
trigger1 = AnimElemTime(21) < 0
anim = 1215
sprpriority = 1

[State 1211, Explod 5]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(21) >= 0
trigger1 = AnimElemTime(29) < 0
anim = 1215
sprpriority = 3

[State 1211, Explod 6]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(29) > 0
trigger2 = AnimElemTime(1) >= 0
trigger2 = AnimElemTime(5) < 0
anim = 1215
sprpriority = 4

[State 1211, DestroySelf]
type = DestroySelf
trigger1 = Anim = 1213
trigger1 = AnimTime = 0

;Ouke no Sabaki - Projectile Helper - Target Transformed
[Statedef 1212]
type = A
movetype = A
ctrl = 0
velset = 0,0
anim = 1214
sprpriority = -1

[State 1212, 1] ; Target dies early
type = ChangeState
triggerall = target, life = 0
trigger1 = target, stateno = 1220
trigger2 = target, stateno = 1242
trigger3 = target, stateno = 1243
value = 1216

[State 1212, 2]
type = TargetState
triggerall = Time = 0
trigger1 = Var(40) < 0
trigger2 = target, SelfAnimExist(19050)
value = 1242

[State 1212, 3]
type = PosSet
trigger1 = 1
x = target, Pos X
y = target, Pos Y

[State 1212, 4]
type = PosAdd
trigger1 = target, stateno = 1242
trigger1 = target, Anim = 1220
trigger1 = target, AnimTime = 0
y = -51

[State 1212, 5]
type = Turn
trigger1 = ParentDist X < 0
trigger1 = target, StateType != A

[State 1212, 6]
type = TargetFacing
trigger1 = target, facing != facing
value = 1

[State 1212, HitAdd]
type = HitAdd
trigger1 = target, stateno = [5000,5099]
value = -1

[State 1212, 7]
type = TargetState
trigger1 = target, stateno = [5000,5099]
trigger1 = target,prevstateno != [1231,1239]
trigger1 = target,prevstateno != [1242,1243]
trigger1 = target, life != 0
value = 1228

[State 1212, 7b]
type = TargetState
triggerall = target, stateno = [5000,5099]
trigger1 = target,prevstateno = [1231,1239]
trigger2 = target,prevstateno = [1242,1243]
trigger1 = target, life != 0
value = 1238

[State 1212, PlaySnd 1a] ;Transformation Sound
type = PlaySnd
trigger1 = Time = 5
value = 1200,0

[State 1212, Cloud Explod 1] ;Cloud
type = Explod
triggerall = target, time = 13
trigger1 = target, stateno = 1220
trigger2 = target, stateno = 1242
trigger3 = target, stateno = 1243
anim = 4015
pos = -29,-81
postype = p2
sprpriority = 5

[State 1212, Cloud Explod 2] ;Cloud
type = Explod
triggerall = target, time = 13
trigger1 = target, stateno = 1220
trigger2 = target, stateno = 1242
trigger3 = target, stateno = 1243
anim = 4015
pos = 38,-62
postype = p2
sprpriority = 5

[State 1212, Small Cloud Explod 1] ;Cloud
type = Explod
triggerall = target, time = 14
trigger1 = target, stateno = 1220
trigger2 = target, stateno = 1242
trigger3 = target, stateno = 1243
anim = 4017
pos = 52,-83
postype = p2
sprpriority = 5

[State 1212, Cloud Explod 3] ;Cloud
type = Explod
triggerall = target, time = 14
trigger1 = target, stateno = 1220
trigger2 = target, stateno = 1242
trigger3 = target, stateno = 1243
anim = 4015
pos = -14,-34
postype = p2
sprpriority = 5

[State 1212, Cloud Explod 4] ;Cloud
type = Explod
triggerall = target, time = 16
trigger1 = target, stateno = 1220
trigger2 = target, stateno = 1242
trigger3 = target, stateno = 1243
anim = 4015
pos = -46,-42
postype = p2
sprpriority = 5

[State 1212, Small Cloud Explod 2] ;Cloud
type = Explod
triggerall = target, time = 17
trigger1 = target, stateno = 1220
trigger2 = target, stateno = 1242
trigger3 = target, stateno = 1243
anim = 4017
pos = -44,-23
postype = p2
sprpriority = 5

[State 1212, Cloud Explod 5] ;Cloud
type = Explod
triggerall = target, time = 17
trigger1 = target, stateno = 1220
trigger2 = target, stateno = 1242
trigger3 = target, stateno = 1243
anim = 4015
pos = 50,-58
postype = p2
sprpriority = 5

[State 1212, Cloud Explod 6] ;Cloud
type = Explod
triggerall = target, time = 19
trigger1 = target, stateno = 1220
trigger2 = target, stateno = 1242
trigger3 = target, stateno = 1243
anim = 4015
pos = 10,-18
postype = p2
sprpriority = 5

[State 1212, Decrement Time Left]
type = VarAdd
trigger1 = Time > 0
v = 1
value = -1

[State 1212, ChangeAnim Off]
type = ChangeAnim
trigger1 = target, anim = [19030,19060]
trigger1 = Anim != 1214
value = 1214

[State 1212, ChangeAnim 1]
type = ChangeAnim
trigger1 = target, anim = 1221
trigger1 = Anim != 50000 + 10*Var(40)
trigger2 = target, anim = 1220
trigger2 = target, AnimTime = 0
value = 50000 + 10*Var(40)

[State 1212, ChangeAnim 2]
type = ChangeAnim
trigger1 = target, anim = 1222
trigger1 = Anim != 50001 + 10*Var(40)
value = 50001 + 10*Var(40)

[State 1212, ChangeAnim 3]
type = ChangeAnim
triggerall = Anim != 50002 + 10*Var(40)
trigger1 = target, Anim = 1223
trigger2 = target, Anim = 1224
trigger2 = SelfAnimExist(50003 + 10*Var(40)) = 0
value = 50002 + 10*Var(40)

[State 1212, AngleDraw 3]
type = AngleDraw
trigger1 = Anim = 50002 + 10*Var(40)
trigger1 = target, anim = 1224
trigger1 = SelfAnimExist(50003 + 10*Var(40)) = 0
scale = -1,1

[State 1212, ChangeAnim 4]
type = ChangeAnim
trigger1 = target, anim = 1224
trigger1 = SelfAnimExist(50003 + 10*Var(40))
trigger1 = Anim != 50003 + 10*Var(40)
value = 50003 + 10*Var(40)

[State 1212, ChangeAnim 5]
type = ChangeAnim
triggerall = Anim != 50004 + 10*Var(40)
trigger1 = target, anim = 1225
trigger2 = target, anim = 1231
value = 50004 + 10*Var(40)

[State 1212, AngleDraw 5]
type = AngleDraw
trigger1 = Anim = 50004 + 10*Var(40)
trigger1 = target, anim = 1231
scale = -1,1

[State 1212, ChangeAnim 6]
type = ChangeAnim
triggerall = Anim != 50005 + 10*Var(40)
trigger1 = target, anim = 1226
trigger2 = target, anim = 1232
trigger2 = SelfAnimExist(50006 + 10*Var(40)) = 0
value = 50005 + 10*Var(40)

[State 1212, AngleDraw 6]
type = AngleDraw
trigger1 = Anim = 50005 + 10*Var(40)
trigger1 = target, anim = 1232
trigger1 = SelfAnimExist(50006 + 10*Var(40)) = 0
scale = -1,1

[State 1212, ChangeAnim 6b]
type = ChangeAnim
trigger1 = target, anim = 1232
trigger1 = Anim != 50006 + 10*Var(40)
trigger1 = SelfAnimExist(50006 + 10*Var(40))
value = 50006 + 10*Var(40)

[State 1212, PlaySnd 7] ;Jump land sound
type = PlaySnd
triggerall = Anim != 50007 + 10*Var(40)
trigger1 = target, stateno = 1227
trigger1 = target, anim = 1227
trigger2 = target, stateno = 1247
trigger2 = target, anim = 1233
value = 40,0

[State 1212, ChangeAnim 7]
type = ChangeAnim
triggerall = Anim != 50007 + 10*Var(40)
trigger1 = target, anim = 1227
trigger2 = target, anim = 1233
value = 50007 + 10*Var(40)

[State 1212, AngleDraw 7]
type = AngleDraw
triggerall = Anim = 50007 + 10*Var(40)
trigger1 = target, anim = 1233
scale = -1,1

[State 1212, ChangeAnim 8]
type = ChangeAnim
triggerall = Anim != 50008 + 10*Var(40)
trigger1 = target, anim = 1228
trigger2 = target, stateno = 1230
value = 50008 + 10*Var(40)

[State 1212, ChangeAnim 8]
type = ChangeAnim
trigger1 = target, stateno = 1220
trigger1 = target, anim = 1228
value = 50008 + 10*Var(40)

[State 1212, Offset] ;P2 avoid dust
type = Offset
trigger1 = target, stateno = [1221,1228]
y = 1

[State 1212, Offset] ;P2 avoid dust
type = Offset
trigger1 = target, stateno != [1221,1228]
y = 0

[State 1212, End Transform 1]
type = TargetState
trigger1 = Var(1) <= 0
trigger1 = (target, stateno = [1221,1225]) || (target, stateno = 1227)
value = 1229

[State 1212, End Transform 1b]
type = TargetState
trigger1 = Var(1) <= 0
trigger1 = (target, stateno = [1231,1235]) || (target, stateno = 1237)
value = 1239

[State 1212, End Transform 2]
type = ChangeState
trigger1 = Var(1) <= 0
trigger1 = target, stateno = 1229
trigger2 = target, stateno = 1230
trigger2 = target, Time >= 6
trigger3 = Var(1) <= 0
trigger3 = target, stateno = 1239
value = 1213

;Ouke no Sabaki - Projectile Helper - End Transformed
[Statedef 1213]
type = A
movetype = A

[State 1213, 1]
type = PosSet
trigger1 = Anim != 1214
x = target, Pos X
y = target, Pos Y

[State 1213, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = target, stateno != 1230
trigger1 = target, anim != [19030,19060]
value = 50000 + 10*Var(40)

[State 1213, 3]
type = ChangeAnim
trigger1 = Time = 14
trigger1 = target, stateno = 1229
trigger2 = Time = 12
trigger2 = target, stateno = 1230
trigger3 = Time = 14
trigger3 = target, stateno = 1239
trigger4 = numtarget > 0
trigger4 = target, anim = [19030,19060]
value = 1214

[State 1213, EndSnd 1a] ;Transformation Sound
type = PlaySnd
trigger1 = Time = 0
value = 1200,0

[State 1213, Cloud Explod 1] ;Cloud
type = Explod
trigger1 = Time = 0
anim = 4015
pos = -29, -81-floor(Pos Y)
postype = p2
sprpriority = 3

[State 1213, Cloud Explod 2] ;Cloud
type = Explod
trigger1 = Time = 0
anim = 4015
pos = 38, -62-floor(Pos Y)
postype = p2
sprpriority = 3

[State 1213, Small Cloud Explod 1] ;Cloud
type = Explod
trigger1 = Time = 1
anim = 4017
pos = 52,-83-floor(Pos Y)
postype = p2
sprpriority = 5

[State 1213, Cloud Explod 3] ;Cloud
type = Explod
trigger1 = Time = 1
anim = 4015
pos = -14, -34-floor(Pos Y)
postype = p2
sprpriority = 3

[State 1213, Cloud Explod 4] ;Cloud
type = Explod
trigger1 = Time = 3
anim = 4015
pos = -46, -42-floor(Pos Y)
postype = p2
sprpriority = 3

[State 1213, Small Cloud Explod 2] ;Cloud
type = Explod
trigger1 = Time = 4
anim = 4017
pos = -44,-23-floor(Pos Y)
postype = p2
sprpriority = 5

[State 1213, Cloud Explod 5] ;Cloud
type = Explod
trigger1 = Time = 4
anim = 4015
pos = 50, -58-floor(Pos Y)
postype = p2
sprpriority = 3

[State 1213, Cloud Explod 6] ;Cloud
type = Explod
trigger1 = Time = 6
anim = 4015
pos = 10, -18-floor(Pos Y)
postype = p2
sprpriority = 3

[State 1213, 4]
type = DestroySelf
trigger1 = Time = 25

;Ouke no Sabaki - Projectile Helper - Miss
[Statedef 1214]
type = A
movetype = A

[State 1214, 1]
type = DestroySelf
trigger1 = Time > 0

;Ouke no Sabaki - Helper - Determine Animation
[Statedef 1215]
type = A
movetype = A

[State 1215, HitSound]
type = PlaySnd
trigger1 = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 1215, HitSpark]
type = Helper
trigger1 = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 1215, Default]
type = VarSet
trigger1 = 1
v = 40     ;Character animation
value = 0 ;Default animation

[State 1215, Anakaris]
type = VarSet
trigger1 = target, name = "Anakaris"
trigger2 = target, name = "Anakaris By Third"
trigger3 = target, name = "cvsanakaris"
v = 40
value = 1

[State 1215, Morrigan]
type = VarSet
trigger1 = target, name = "Morrigan"
trigger2 = target, name = "Morrigan Aensland"
trigger3 = target, name = "cvsmorrigan"
trigger4 = target, name = "Ultimate Morrigan"
v = 40
value = -1

[State 1215, Demitri]
type = VarSet
trigger1 = target, name = "Demitri"
trigger2 = target, name = "Demitri Maximoff"
trigger3 = target, name = "Demitri(DS)"
trigger4 = target, name = "Demitri-Ex"
trigger5 = target, name = "cvsdemitri"
v = 40
value = -2

[State 1215, Pyron]
type = VarSet
trigger1 = target, name = "Pyron"
trigger2 = target, name = "cvspyron"
v = 40
value = -3

[State 1215, Lilith]
type = VarSet
trigger1 = target, name = "Lilith"
trigger2 = target, name = "cvslilith"
v = 40
value = -4

[State 1215, Q-Bee]
type = VarSet
trigger1 = target, name = "Q-Bee"
trigger2 = target, name = "QBee"
trigger3 = target, name = "Q Bee"
trigger4 = target, name = "cvsqbee"
trigger5 = target, name = "Queen Bee"
v = 40
value = -5

[State 1215, Jedah]
type = VarSet
trigger1 = target, name = "Jedah"
trigger2 = target, name = "cvsjedah"
v = 40
value = -6

[State 1215, Vega]
type = VarSet
trigger1 = target, name = "Vega"
trigger2 = target, name = "M. Bison"
trigger3 = target, name = "M.Bison"
trigger4 = target, name = "MBison"
trigger5 = target, name = "[Necromancer's] M. Bison"
trigger6 = target, name = "cvsvega"
trigger7 = target, name = "cvsmbison"
v = 40
value = -7

[State 1215, Kenji]
type = VarSet
trigger1 = target, name = "Kenji"
trigger2 = target, name = "cvskenji"
v = 40
value = -8

[State 1215, Gallon]
type = VarSet
trigger1 = target, name = "Gallon"
trigger2 = target, name = "Jon Talbain"
trigger3 = target, name = "Talbain"
trigger4 = target, name = "J. Talbain"
trigger5 = target, name = "cvsgallon"
trigger6 = target, name = "cvstalbain"
trigger7 = target, name = "cvsjtalbain"
trigger8 = target, name = "John Talbain"
v = 40
value = 2

[State 1215, Zabel]
type = VarSet
trigger1 = target, name = "Zabel"
trigger2 = target, name = "Zabel Zarock"
trigger3 = target, name = "Lord Raptor"
trigger4 = target, name = "cvsraptor"
trigger5 = target, name = "cvszabel"
v = 40
value = 3

[State 1215, Felicia]
type = VarSet
trigger1 = target, name = "Felicia"
trigger2 = target, name = "Felicia MvC2 Style by MGBenz"
trigger3 = target, name = "cvsfelicia"
v = 40
value = 4

[State 1215, Bishamon]
type = VarSet
trigger1 = target, name = "Bishamon"
trigger2 = target, name = "Oboro"
trigger3 = target, name = "cvsbishamon"
trigger4 = target, name = "cvsoboro"
v = 40
value = 5

[State 1215, Victor]
type = VarSet
trigger1 = target, name = "Victor"
trigger2 = target, name = "cvsvictor"
v = 40
value = 6

[State 1215, Aulbath]
type = VarSet
trigger1 = target, name = "Aulbath"
trigger2 = target, name = "Rikuo"
trigger3 = target, name = "cvsaulbath"
trigger4 = target, name = "cvsrikuo"
v = 40
value = 7

[State 1215, Sasquatch]
type = VarSet
trigger1 = target, name = "Sasquatch"
trigger2 = target, name = "cvssasquatch"
v = 40
value = 8

[State 1215, Phobos]
type = VarSet
trigger1 = target, name = "Phobos"
trigger2 = target, name = "Huitzel"
trigger3 = target, name = "Deimos"
trigger4 = target, name = "cvsphobos"
trigger5 = target, name = "cvshuitzel"
trigger6 = target, name = "cvsdeimos"
v = 40
value = 9

[State 1215, Lei-Lei]
type = VarSet
trigger1 = target, name = "Lei-Lei"
trigger2 = target, name = "Lei Lei"
trigger3 = target, name = "LeiLei"
trigger4 = target, name = "Hsien-Ko"
trigger5 = target, name = "Hsien Ko"
trigger6 = target, name = "HsienKo"
trigger7 = target, name = "cvsleilei"
trigger8 = target, name = "cvshsienko"
v = 40
value = 10

[State 1215, Donovan]
type = VarSet
trigger1 = target, name = "Donovan"
v = 40
value = 11

[State 1215, Bulleta]
type = VarSet
trigger1 = target, name = "Bulleta"
trigger2 = target, name = "B.B. Hood"
trigger3 = target, name = "BB Hood"
trigger4 = target, name = "B.B.Hood"
trigger5 = target, name = "BBHood"
trigger6 = target, name = "Baby Bonnie Hood"
trigger7 = target, name = "Bulleta SXP"
trigger8 = target, name = "cvsbulleta"
trigger9 = target, name = "cvsbbhood"
trigger10 = target, name = "B. B. Hood"
v = 40
value = 12

[State 1215, Alex]
type = VarSet
trigger1 = target, name = "Alex"
trigger2 = target, name = "cvsalex"
v = 40
value = 13

[State 1215, Yun]
type = VarSet
trigger1 = target, name = "Yun"
trigger2 = target, name = "cvsyun"
v = 40
value = 14

[State 1215, Urien]
type = VarSet
trigger1 = target, name = "Urien"
trigger2 = target, name = "cvsurien"
v = 40
value = 15

[State 1215, Ryu]
type = VarSet
trigger1 = target, name = "Ryu"
trigger2 = target, name = "Evil Ryu"
trigger3 = target, name = "Ryu Hoshi"
trigger4 = target, name = "Ryu-X"
trigger5 = target, name = "Ryu Houji"
trigger6 = target, name = "cvsryu"
trigger7 = target, name = "cvsryu_normal"
trigger8 = target, name = "ryusnk"
trigger9 = target, name = "MvC-EoH Evil Ryu"
v = 40
value = 16

[State 1215, Chun-Li]
type = VarSet
trigger1 = target, name = "Chun-Li"
trigger2 = target, name = "Chun Li"
trigger3 = target, name = "ChunLi"
trigger4 = target, name = "Dark Chun Li"
trigger5 = target, name = "cvschunli"
v = 40
value = 17

[State 1215, Guile]
type = VarSet
trigger1 = target, name = "Guile"
trigger2 = target, name = "Guile-XI"
trigger3 = target, name = "Guile-XI Remix"
trigger4 = target, name = "cvsguile"
v = 40
value = 18

[State 1215, Zangief]
type = VarSet
trigger1 = target, name = "Zangief"
trigger2 = target, name = "cvszangief"
trigger3 = target, name = "Mecha Zangief"
trigger4 = target, name = "Mecha-Zangief"
trigger5 = target, name = "MechaZangief"
v = 40
value = 19

[State 1215, Sakura]
type = VarSet
trigger1 = target, name = "Sakura"
trigger2 = target, name = "Sakura Kasugano"
trigger3 = target, name = "cvssakura"
v = 40
value = 20

[State 1215, Gouki]
type = VarSet
trigger1 = target, name = "Gouki"
trigger2 = target, name = "Akuma"
trigger3 = target, name = "Shin Gouki"
trigger4 = target, name = "Shin Akuma"
trigger5 = target, name = "ShinGouki"
trigger6 = target, name = "ShinAkuma"
trigger7 = target, name = "Pocket Shin Gouki"
trigger8 = target, name = "cvsgouki"
trigger9 = target, name = "cvsakuma"
trigger10 = target, name = "Gouki by M.M.R."
trigger11 = target, name = "MvC-EoH Gouki"
v = 40
value = 21

[State 1215, Leo]
type = VarSet
trigger1 = target, name = "Leo"
trigger2 = target, name = "cvsleo"
v = 40
value = 22

[State 1215, Hauzer]
type = VarSet
trigger1 = target, name = "Hauzer"
trigger2 = target, name = "cvshauzer"
v = 40
value = 23

[State 1215, Hydron]
type = VarSet
trigger1 = target, name = "Hydron"
trigger2 = target, name = "Nool"
trigger3 = target, name = "cvshydron"
trigger4 = target, name = "cvsnool"
v = 40
value = 24

[State 1215, Guy]
type = VarSet
trigger1 = target, name = "Guy"
trigger2 = target, name = "cvsguy"
v = 40
value = 25

[State 1215, Rose]
type = VarSet
trigger1 = target, name = "Rose"
trigger2 = target, name = "cvsrose"
v = 40
value = 26

[State 1215, Karin]
type = VarSet
trigger1 = target, name = "Karin"
trigger2 = target, name = "Karin Kanzuki"
trigger3 = target, name = "cvskarin"
v = 40
value = 27

[State 1215, Ingrid]
type = VarSet
trigger1 = target, name = "Ingrid"
trigger2 = target, name = "Ingrid SXP"
trigger3 = target, name = "cvsingrid"
v = 40
value = 28

[State 1215, Super Mario]
type = VarSet
trigger1 = target, name = "Super Mario"
trigger2 = target, name = "Mario"
trigger3 = target, name = "SuperMario"
v = 40
value = 29

[State 1215, Super Luigi]
type = VarSet
trigger1 = target, name = "Super Luigi"
trigger2 = target, name = "Luigi"
trigger3 = target, name = "SuperLuigi"
v = 40
value = 30

[State 1215, Megaman]
type = VarSet
trigger1 = target, name = "Megaman"
trigger2 = target, name = "Rockman"
trigger3 = target, name = "Megaman Plus"
v = 40
value = 31

[State 1215, End State 3410]
type = ChangeState
trigger1 = PrevStateNo = 3410
value = 3412

[State 1215, End State 3410]
type = ChangeState
trigger1 = PrevStateNo = 3460
value = 3462

[State 1215, End State 3510]
type = ChangeState
trigger1 = PrevStateNo = 3510
value = 3512

[State 1215, End State 3560]
type = ChangeState
trigger1 = PrevStateNo = 3560
value = 3562

[State 1215, End State]
type = ChangeState
trigger1 = 1
value = 1212

;Ouke no Sabaki - Projectile Helper - Target Dies Early
[Statedef 1216]
type = A
movetype = A
sprpriority = -1

[State 1216, 1] ; Target dies early
type = TargetState
trigger1 = 1
value = 1244

[State 1216, 2]
type = DestroySelf
trigger1 = 1

;Ouke no Sabaki - Transforming
[Statedef 1220]
movetype = H
velset = 0,0

[State 1220, 1]
type = ChangeAnim2
trigger1 = Pos Y >= 0
trigger1 = Time = 0
value = 1220

[State 1220, 2]
type = ChangeAnim2
trigger1 = Pos Y < 0
trigger1 = Time = 0
value = 1230

[State 1220, 3]
type = PlaySnd
trigger1 = SelfAnimExist(19040) = 1
trigger1 = Time = 0
value = 19030,0

[State 1220, 4]
type = ChangeAnim
trigger1 = Anim = 1220
trigger1 = AnimTime = 0
trigger1 = SelfAnimExist(19030) = 1
value = 19030

[State 1220, 4b]
type = ChangeAnim2
trigger1 = Anim = 1220
trigger1 = AnimTime = 0
trigger1 = SelfAnimExist(19030) = 0
value = 1221

[State 1220, 5]
type = ChangeAnim2
trigger1 = Anim = 1230
trigger1 = AnimTime = 0
value = 1228

[State 1220, 6]
type = HitFallSet
trigger1 = Time = 0
value = 0

[State 1220, 7]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1220, 8]
type = PlayerPush
trigger1 = 1
value = 0

[State 1220, 8]
type = ChangeState
trigger1 = Pos Y < 0
trigger1 = Time = 49
value = 1228

[State 1220, 9]
type = ChangeState
trigger1 = Time = 49
value = 1221

;Ouke no Sabaki - Transformed - Stand
[Statedef 1221]
type = S
movetype = H
physics = S
velset = 0,0

[State 1221, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19030) = 1
value = 19030

[State 1221, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19030) = 0
value = 1221

[State 1221, 2] ;Avoid dust on ground
type = PosSet
trigger1 = 1
y = -1

[State 1221, 3] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1221, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1221, 5] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1221, 6] ;Crouch
type = ChangeState
trigger1 = command = "holddown"
value = 1222

[State 1221, 7] ;Walk
type = ChangeState
trigger1 = command = "holdfwd"
trigger2 = command = "holdback"
value = 1223

[State 1221, 8] ;Jump
type = ChangeState
trigger1 = command = "holdup"
value = 1225

;Ouke no Sabaki - Transformed - Crouch
[Statedef 1222]
type = C
movetype = H
physics = S
velset = 0,0

[State 1222, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19032) = 1
value = 19032

[State 1222, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19032) = 0
value = 1222

[State 1222, 2] ;Avoid dust on ground
type = PosSet
trigger1 = 1
y = -1

[State 1222, 3] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1222, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1222, 5] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1222, 6] ;Stand
type = ChangeState
trigger1 = command != "holddown"
value = 1221

;Ouke no Sabaki - Transformed - Walk
[Statedef 1223]
type = S
movetype = H
physics = N
velset = 0,0

[State 1223, 1]
type = ChangeAnim
trigger1 = command = "holdfwd"
trigger1 = command != "holdback"
trigger1 = SelfAnimExist(19034) = 1
trigger1 = Anim != 19034
value = 19034

[State 1223, 1b]
type = ChangeAnim2
trigger1 = command = "holdfwd"
trigger1 = command != "holdback"
trigger1 = SelfAnimExist(19034) = 0
trigger1 = Anim != 1223
value = 1223

[State 1223, 2]
type = ChangeAnim
trigger1 = command = "holdback"
trigger1 = SelfAnimExist(19035) = 1
trigger1 = Anim != 19035
value = 19035

[State 1223, 2]
type = AngleDraw
trigger1 = command = "holdback"
trigger1 = Anim = 19034
scale = -1,1

[State 1223, 2b]
type = ChangeAnim2
trigger1 = command = "holdback"
trigger1 = SelfAnimExist(19035) = 0
trigger1 = Anim != 1224
value = 1224

[State 1223, 3]
type = VelSet
trigger1 = command = "holdfwd"
x = 2
y = 0

[State 1223, 4]
type = VelSet
trigger1 = command = "holdback"
x = -2
y = 0

[State 1223, 5] ;Avoid dust on ground
type = PosSet
trigger1 = 1
y = -1

[State 1223, 6] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1223, 7]
type = PlayerPush
trigger1 = 1
value = 0

[State 1223, 8] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1223, 9] ;Crouch
type = ChangeState
trigger1 = command = "holddown"
value = 1222

[State 1223, 10] ;Jump
type = ChangeState
trigger1 = command = "holdup"
value = 1225

[State 1223, 11] ;Stand
type = ChangeState
trigger1 = command != "holdfwd"
trigger1 = command != "holdback"
value = 1221

;Ouke no Sabaki - Transformed - Jump Start
[Statedef 1225]
type = S
movetype = H
physics = N
velset = 0,0

[State 1225, 1]
type = ChangeState
trigger1 = Time = 0
trigger1 = command = "holdback"
value = 1245

[State 1225, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19038) = 1
value = 19038

[State 1225, 2b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19038) = 0
value = 1225

[State 1225, 3] ;Avoid dust on ground
type = PosSet
trigger1 = 1
y = -1

[State 1225, 4] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1225, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 1225, 6]
type = ChangeState
trigger1 = AnimTime = 0
trigger2 = AnimTime > 0
trigger2 = Time >= 2
value = 1226

;Ouke no Sabaki - Transformed - Jump
[Statedef 1226]
type = A
movetype = H
physics = N
velset = 0,-9

[State 1226, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19036) = 1
value = 19036

[State 1226, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19036) = 0
value = 1226

[State 1226, 2]
type = VelSet
trigger1 = Time = 0
trigger1 = command = "holdfwd"
x = 2

[State 1226, 3] ;Gravity
type = VelAdd
trigger1 = 1
y = .5

[State 1226, 4] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1226, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 1226, 6]
type = ChangeState
trigger1 = Pos Y >= -1
trigger1 = Vel Y > 0
value = 1227

;Ouke no Sabaki - Transformed - Jump Land
[Statedef 1227]
type = S
movetype = H
physics = N
velset = 0,0

[State 1227, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19039) = 1
value = 19039

[State 1227, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19039) = 0
value = 1227

[State 1227, 2] ;Avoid dust on ground
type = PosSet
trigger1 = Time = 0
y = -1

[State 1227, 3] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1227, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1227, 5] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1227, 6] ;Stand
type = ChangeState
trigger1 = AnimTime = 0
trigger2 = AnimTime > 0
trigger2 = Time >= 9
value = 1221

;Ouke no Sabaki - Transformed - Get Hit
[Statedef 1228]
type = A
movetype = H
physics = N
velset = -2.5,-6

[State 1228, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19040) = 1
value = 19040

[State 1228, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19040) = 0
value = 1228

[State 1228, 2]
type = PlaySnd
trigger1 = SelfAnimExist(19040) = 1
trigger1 = Time = 0
value = 19030,0

[State 1228, 3] ;Gravity
type = VelAdd
trigger1 = 1
y = .5

[State 1228, 4]
type = HitFallSet
trigger1 = Time = 0
value = 0

[State 1228, 5] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1228, 6]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1228, 7]
type = PlayerPush
trigger1 = 1
value = 0

[State 1228, 8] ;Die
type = ChangeState
trigger1 = Pos Y >= -1
trigger1 = Vel Y > 0
trigger1 = Life = 0
value = 1230

[State 1228, 9]
type = ChangeState
trigger1 = Pos Y >= -1
trigger1 = Vel Y > 0
value = 1221

;Ouke no Sabaki - Transformed - End
[Statedef 1229]
type = S
movetype = H
physics = N
velset = 0,0

[State 1229, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1229, 2]
type = PlayerPush
trigger1 = 1
value = 0

[State 1229, 3]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19030) = 1
value = 19030

[State 1229, 3b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19030) = 0
value = 1221

[State 1229, 4]
type = PosSet
trigger1 = Time = 0
y = 0

[State 1229, 5]
type = Offset
trigger1 = Time = 0
y = 0

[State 1229, 6]
type = ChangeAnim
trigger1 = Time = 14
value = 0

[State 1229, 7]
type = SelfState
trigger1 = Time >= 24
value = 0
ctrl = 1

;Ouke no Sabaki - Transformed - Die
[Statedef 1230]
type = S
movetype = H
physics = N
velset = 0,0

[State 1230, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1230, 2]
type = PlayerPush
trigger1 = 1
value = 0

[State 1230, 3]
type = PosSet
trigger1 = Time = 0
y = 0

[State 1230, 4]
type = ChangeAnim2
trigger1 = Anim != 1228
value = 1228

[State 1230, 5]
type = SelfState
trigger1 = Time >= 18
value = 5100

;Ouke no Sabaki - Transformed - Stand - Flying
[Statedef 1231]
type = S
movetype = H
physics = S
velset = 0,0

[State 1221, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19050) = 1
value = 19050

[State 1221, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19050) = 0
value = 1221

[State 1232, 2]
type = PosAdd
trigger1 = Pos Y > -51
y = -4

[State 1231, 3]
type = PosSet
trigger1 = Pos Y < -51
y = -51

[State 1231, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1231, 5] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1231, 6] ;Crouch
type = ChangeState
trigger1 = command = "holddown"
value = 1232

[State 1231, 7] ;Walk
type = ChangeState
trigger1 = command = "holdfwd"
trigger2 = command = "holdback"
value = 1233

[State 1231, 8] ;Jump
type = ChangeState
trigger1 = command = "holdup"
value = 1235

;Ouke no Sabaki - Transformed - Crouch - Flying
[Statedef 1232]
type = C
movetype = H
physics = S
velset = 0,0

[State 1232, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19052) = 1
value = 19052

[State 1232, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19052) = 0
value = 1222

[State 1232, 2]
type = PosAdd
trigger1 = Pos Y < -21
y = 4

[State 1232, 3]
type = PosSet
trigger1 = Pos Y > -21
y = -21

[State 1232, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1232, 5] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1232, 6] ;Stand
type = ChangeState
trigger1 = command != "holddown"
value = 1231

;Ouke no Sabaki - Transformed - Walk - Flying
[Statedef 1233]
type = S
movetype = H
physics = N
velset = 0,0

[State 1233, 1]
type = ChangeAnim
triggerall = SelfAnimExist(19054) = 1
triggerall = Anim != 19054
trigger1 = command = "holdfwd"
trigger2 = command = "holdback"
trigger2 = SelfAnimExist(19055) = 0
value = 19054

[State 1233, 1b]
type = ChangeAnim2
trigger1 = command = "holdfwd"
trigger1 = command != "holdback"
trigger1 = SelfAnimExist(19054) = 0
trigger1 = Anim != 1223
value = 1223

[State 1233, 2]
type = ChangeAnim
trigger1 = command = "holdback"
trigger1 = SelfAnimExist(19055) = 1
trigger1 = Anim != 19055
value = 19055

[State 1233, 2]
type = AngleDraw
trigger1 = command = "holdback"
trigger1 = Anim = 19054
scale = -1,1

[State 1233, 2b]
type = ChangeAnim2
trigger1 = command = "holdback"
trigger1 = SelfAnimExist(19054) = 0
trigger1 = SelfAnimExist(19055) = 0
trigger1 = Anim != 1224
value = 1224

[State 1233, 3]
type = VelSet
trigger1 = command = "holdfwd"
x = 2
y = 0

[State 1233, 4]
type = VelSet
trigger1 = command = "holdback"
x = -2
y = 0

[State 1233, 5]
type = PosAdd
trigger1 = Pos Y > -51
y = -4

[State 1233, 6]
type = PosSet
trigger1 = Pos Y < -51
y = -51

[State 1233, 7]
type = PlayerPush
trigger1 = 1
value = 0

[State 1233, 8] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1233, 9] ;Crouch
type = ChangeState
trigger1 = command = "holddown"
value = 1232

[State 1233, 10] ;Jump
type = ChangeState
trigger1 = command = "holdup"
value = 1235

[State 1233, 11] ;Stand
type = ChangeState
trigger1 = command != "holdfwd"
trigger1 = command != "holdback"
value = 1231

;Ouke no Sabaki - Transformed - Jump Start - Flying
[Statedef 1235]
type = S
movetype = H
physics = N
velset = 0,0

[State 1235, 1]
type = ChangeState
trigger1 = Time = 0
trigger1 = command = "holdback"
value = 1255

[State 1235, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19058) = 1
value = 19058

[State 1235, 2b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19058) = 0
value = 1225

[State 1235, 3]
type = PosSet
trigger1 = Time = 0
y = -51

[State 1235, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1235, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 1236

;Ouke no Sabaki - Transformed - Jump - Flying
[Statedef 1236]
type = A
movetype = H
physics = N
velset = 0,-9

[State 1236, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19056) = 1
value = 19056

[State 1236, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19056) = 0
value = 1226

[State 1236, 2] ;Backwards
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = Anim = 1231
value = 1232

[State 1236, 3]
type = VelSet
trigger1 = Time = 0
trigger1 = command = "holdfwd"
x = 2

[State 1236, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1236, 5] ;Gravity
type = VelAdd
trigger1 = 1
y = .5

[State 1236, 6]
type = ChangeState
trigger1 = Pos Y >= -51
trigger1 = Vel Y > 0
value = 1237

;Ouke no Sabaki - Transformed - Jump Land - Flying
[Statedef 1237]
type = S
movetype = H
physics = N
velset = 0,0

[State 1227, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19059) = 1
value = 19059

[State 1227, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19059) = 0
value = 1227

[State 1237, 2]
type = PosSet
trigger1 = Time = 0
y = -51

[State 1237, 3]
type = PlayerPush
trigger1 = 1
value = 0

[State 1237, 4] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1237, 5] ;Stand
type = ChangeState
trigger1 = AnimTime = 0
value = 1231

;Ouke no Sabaki - Transformed - Jump Start Backwards
[Statedef 1245]
type = S
movetype = H
physics = N
velset = 0,0

[State 1245, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19038) = 1
value = 19032

[State 1245, 2]
type = AngleDraw
trigger1 = Anim = 19038
scale = -1,1

[State 1245, 2b] ;Backwards
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19038) = 0
value = 1231

[State 1245, 3] ;Avoid dust on ground
type = PosSet
trigger1 = 1
y = -1

[State 1245, 4] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1245, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 1245, 6]
type = ChangeState
trigger1 = AnimTime = 0
trigger2 = AnimTime > 0
trigger2 = Time >= 2
value = 1246

;Ouke no Sabaki - Transformed - Jump Backwards
[Statedef 1246]
type = A
movetype = H
physics = N
velset = 0,-9

[State 1246, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19036) = 1
value = 19036

[State 1246, 2]
type = AngleDraw
trigger1 = Vel X < 0
trigger1 = Anim = 19036
scale = -1,1

[State 1246, 2b] ;Backwards
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19036) = 0
value = 1232

[State 1246, 3]
type = VelSet
trigger1 = Time = 0
x = -2

[State 1246, 4] ;Gravity
type = VelAdd
trigger1 = 1
y = .5

[State 1246, 5] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1246, 6]
type = PlayerPush
trigger1 = 1
value = 0

[State 1246, 7]
type = ChangeState
trigger1 = Pos Y >= -1
trigger1 = Vel Y > 0
value = 1247

;Ouke no Sabaki - Transformed - Jump Land Backwards
[Statedef 1247]
type = S
movetype = H
physics = N
velset = 0,0

[State 1247, 1] ;Backwards
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19039) = 1
value = 19039

[State 1247, 1]
type = AngleDraw
trigger1 = Anim = 19039
scale = -1,1

[State 1247, 1b] ;Backwards
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19039) = 0
value = 1233

[State 1247, 2] ;Avoid dust on ground
type = PosSet
trigger1 = Time = 0
y = -1

[State 1247, 3] ;Avoid dust on ground
type = OffSet
trigger1 = 1
y = 1

[State 1247, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1247, 5] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1247, 6] ;Stand
type = ChangeState
trigger1 = AnimTime = 0
trigger2 = AnimTime > 0
trigger2 = Time >= 9
value = 1221

;Ouke no Sabaki - Transformed - Jump Start - Backwards - Flying
[Statedef 1255]
type = S
movetype = H
physics = N
velset = 0,0

[State 1255, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19058) = 1
value = 19058

[State 1255, 2]
type = AngleDraw
trigger1 = Anim = 19058
scale = -1,1

[State 1255, 2b] ;Backwards
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19058) = 0
value = 1231

[State 1255, 3]
type = PosSet
trigger1 = Time = 0
y = -51

[State 1255, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1255, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 1256

;Ouke no Sabaki - Transformed - Jump - Backwards - Flying
[Statedef 1256]
type = A
movetype = H
physics = N
velset = 0,-9

[State 1256, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19056) = 1
value = 19056

[State 1256, 2]
type = AngleDraw
trigger1 = Vel X < 0
trigger1 = Anim = 19056
scale = -1,1

[State 1256, 2b] ;Backwards
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19056) = 0
value = 1232

[State 1256, 3]
type = VelSet
trigger1 = Time = 0
x = -2

[State 1256, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1256, 5] ;Gravity
type = VelAdd
trigger1 = 1
y = .5

[State 1256, 6]
type = ChangeState
trigger1 = Pos Y >= -51
trigger1 = Vel Y > 0
value = 1257

;Ouke no Sabaki - Transformed - Jump Land - Backwards - Flying
[Statedef 1257]
type = S
movetype = H
physics = N
velset = 0,0

[State 1257, 1] ;Backwards
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19059) = 1
value = 19059

[State 1257, 1]
type = AngleDraw
trigger1 = Anim = 19059
scale = -1,1

[State 1257, 1b] ;Backwards
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19059) = 0
value = 1233

[State 1257, 3]
type = PosSet
trigger1 = Time = 0
y = -51

[State 1257, 4]
type = PlayerPush
trigger1 = 1
value = 0

[State 1257, 5] ;Die
type = ChangeState
trigger1 = Life = 0
value = 1230

[State 1257, 6] ;Stand
type = ChangeState
trigger1 = AnimTime = 0
value = 1231

;Ouke no Sabaki - Transformed - Get Hit - Flying
[Statedef 1238]
type = A
movetype = H
physics = N
velset = -2.5,-6

[State 1238, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19060) = 1
value = 19060

[State 1238, 1b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19060) = 0
value = 1228

[State 1238, 2]
type = PlaySnd
trigger1 = SelfAnimExist(19060) = 1
trigger1 = Time = 0
value = 19030,0

[State 1238, 3] ;Gravity
type = VelAdd
trigger1 = 1
y = .5

[State 1238, 4]
type = HitFallSet
trigger1 = Time = 0
value = 0

[State 1238, 5]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1238, 6]
type = PlayerPush
trigger1 = 1
value = 0

[State 1238, 7] ;Die
type = ChangeState
trigger1 = Pos Y >= -51
trigger1 = Vel Y > 0
trigger1 = Life = 0
value = 1230

[State 1238, 8]
type = ChangeState
trigger1 = Pos Y >= -51
trigger1 = Vel Y > 0
value = 1237

;Ouke no Sabaki - Transformed - End - Flying
[Statedef 1239]
type = S
movetype = H
physics = N
velset = 0,0

[State 1239, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1239, 2]
type = PlayerPush
trigger1 = 1
value = 0

[State 1239, 3]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19050) = 1
value = 19050

[State 1239, 3b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(19050) = 0
value = 1221

[State 1239, 4]
type = PosSet
trigger1 = Time = 14
y = 0

[State 1239, 5]
type = ChangeAnim
trigger1 = Time = 14
value = 0

[State 1239, 6]
type = SelfState
trigger1 = Time >= 24
value = 0
ctrl = 1

;Ouke no Sabaki - Transforming - On Ground - Flying
[Statedef 1242]
movetype = H
velset = 0,0

[State 1242, 1]
type = ChangeState
trigger1 = Pos Y < 0
trigger1 = Time = 0
value = 1243

[State 1242, 2]
type = ChangeAnim2
trigger1 = Time = 0
value = 1220

[State 1242, 3]
type = PlaySnd
trigger1 = SelfAnimExist(19060) = 1
trigger1 = Time = 0
value = 19030,0

[State 1242, 4]
type = PosSet
trigger1 = Anim = 1220
trigger1 = AnimTime = 0
y = -51

[State 1242, 5]
type = ChangeAnim
trigger1 = Anim = 1220
trigger1 = AnimTime = 0
trigger1 = SelfAnimExist(19050) = 1
value = 19050

[State 1242, 5b]
type = ChangeAnim2
trigger1 = Anim = 1220
trigger1 = AnimTime = 0
trigger1 = SelfAnimExist(19050) = 0
value = 1221

[State 1242, 6]
type = HitFallSet
trigger1 = Time = 0
value = 0

[State 1242, 7]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1242, 8]
type = PlayerPush
trigger1 = 1
value = 0

[State 1242, 9]
type = ChangeState
trigger1 = Time = 49
value = 1231

;Ouke no Sabaki - Transforming - In Air - Flying
[Statedef 1243]
movetype= H
velset = 0,0

[State 1243, 1]
type = ChangeAnim2
trigger1 = Time = 0
value = 1230

[State 1243, 2]
type = PosAdd
trigger1 = Anim = 1230
trigger1 = AnimTime = 0
y = -51

[State 1243, 3]
type = ChangeAnim
trigger1 = Anim = 1230
trigger1 = AnimTime = 0
trigger1 = SelfAnimExist(19060) = 1
value = 19060

[State 1243, 3b]
type = ChangeAnim2
trigger1 = Anim = 1230
trigger1 = AnimTime = 0
trigger1 = SelfAnimExist(19060) = 0
value = 1228

[State 1243, 4]
type = HitFallSet
trigger1 = Time = 0
value = 0

[State 1243, 5]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1243, 6]
type = PlayerPush
trigger1 = 1
value = 0

[State 1243, 7]
type = ChangeState
trigger1 = Time = 49
value = 1238

;Ouke no Sabaki - Interrrupted
[Statedef 1244]
movetype = H

[State 1244, 1]
type = SelfState
trigger1 = Pos Y < 0
value = 5020

[State 1244, 1]
type = SelfState
trigger1 = 1
value = 5000

;========================<EX OUKE NO SABAKI>=============================
[StateDef 1270]
type = A
physics = N
moveType = A
anim = 1260
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1270, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1270, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1270, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1270, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 231

[State 1270, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1270, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1270, 1]
type = PosFreeze
trigger1 = 1
value = 1

[State 1270, 2] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 1270, 3] ;Projectile
type = Helper
trigger1 = AnimElem = 5, = 1
name = "Royal Judgement"
ID = 1210
stateno = 1273
pos = 96,-73
ownpal = 1

[State 1270, 4] ;Projectile
type = Helper
trigger1 = AnimElem = 5, = 1
name = "Royal Judgement"
ID = 1210
stateno = 1272
pos = 96,-73
ownpal = 1

[State 1270, 5] ;Projectile
type = Helper
trigger1 = AnimElem = 5, = 1
name = "Royal Judgement"
ID = 1210
stateno = 1274
pos = 96,-73
ownpal = 1

[State 1270, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 1270, 6]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 1270, 7]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;Ouke no Sabaki - Projectile Helper
[Statedef 1271]
type = A
movetype = A
ctrl = 0
juggle = 3
anim = 1210
sprpriority = -1

[State 1271, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1271, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1271, 1]
type = HitDef
trigger1 = Time = 25
attr = A, SP
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 8
getPower = 0,0
givePower = 36, 36
hitflag = MA-
guardflag = MA
priority = 1, Miss
sparkno = -1
hitsound = S1200,1
guardsound = S3,0
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 1215
p2stateno = 1220
ground.velocity = -4,-6
air.velocity = -3,-6
fall = 1
numhits = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd = -255,-255,-255,48
sprPriority = 3

[State 1271, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 1271, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1271, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1271, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 1271, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 1271, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 1271, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1200,1270]
var(18) = 1
persistent = 0

[State 1271, 2]
type = Helper
trigger1 = Time = 0
trigger2 = Time = 8
trigger3 = Time = 16
trigger4 = Time = 24
name = "Ghost"
ID = 1212
stateno = 1275

[State 1271, 3]
type = PosFreeze
trigger1 = Time < 25
value = 1

[State 1271, 4] ;Miss
type = ChangeState
trigger1 = Pos Y >= -30
trigger2 = MoveGuarded
value = 1214

;Ouke no Sabaki - Strong Punch - Init 1
[Statedef 1272]
type = A
movetype = A

[State 1272, 1] ;Transformed Time Left
type = VarSet
trigger1 = 1
v = 1
value = 49 + 200

[State 1272, 2]
type = VelSet
trigger1 = 1
x = 4
y = 2

[State 1272, 3]
type = ChangeState
trigger1 = 1
value = 1271

;Ouke no Sabaki - Strong Punch - Init 2
[Statedef 1273]
type = A
movetype = A

[State 1273, 1] ;Transformed Time Left
type = VarSet
trigger1 = 1
v = 1
value = 49 + 200

[State 1273, 2]
type = VelSet
trigger1 = 1
x = 3.5
y = 2.5

[State 1273, 3]
type = ChangeState
trigger1 = 1
value = 1271

;Ouke no Sabaki - Strong Punch - Init 3
[Statedef 1274]
type = A
movetype = A

[State 1274, 1] ;Transformed Time Left
type = VarSet
trigger1 = 1
v = 1
value = 49 + 200

[State 1274, 2]
type = VelSet
trigger1 = 1
x = 4.5
y = 1.5

[State 1274, 3]
type = ChangeState
trigger1 = 1
value = 1271

;Ouke no Sabaki - Projectile Helper's Helper - Individual Ghost Image
[Statedef 1275]
type = A
movetype = A
ctrl = 0
anim = 1211
sprpriority = 3

[State 1275, BindToParent 1]
type = BindToParent
trigger1 = Anim = 1211
trigger1 = parent, stateno = 1271
pos = 0,0

[State 1275, BindToParent 1]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
pos = 0,0

[State 1275, BindToParent 2]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
pos = 5,0

[State 1275, BindToParent 3]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
pos = 10,-1

[State 1275, BindToParent 4]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
pos = 14,-2

[State 1275, BindToParent 5]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(5) >= 0 && AnimElemTime(6) < 0
pos = 18,-2

[State 1275, BindToParent 6]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
pos = 20,-3

[State 1275, BindToParent 7]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(7) >= 0 && AnimElemTime(8) < 0
pos = 22,-4

[State 1275, BindToParent 8]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(8) >= 0 && AnimElemTime(9) < 0
pos = 23,-5

[State 1275, BindToParent 9]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(9) >= 0 && AnimElemTime(10) < 0
pos = 22,-6

[State 1275, BindToParent 10]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(10) >= 0 && AnimElemTime(11) < 0
pos = 19,-6

[State 1275, BindToParent 11]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(11) >= 0 && AnimElemTime(12) < 0
pos = 17,-7

[State 1275, BindToParent 12]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(12) >= 0 && AnimElemTime(13) < 0
pos = 13,-7

[State 1275, BindToParent 13]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(13) >= 0 && AnimElemTime(14) < 0
pos = 9,-8

[State 1275, BindToParent 14]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(14) >= 0 && AnimElemTime(15) < 0
pos = 4,-9

[State 1275, BindToParent 15]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(15) >= 0 && AnimElemTime(16) < 0
pos = -1,-9

[State 1275, BindToParent 16]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(16) >= 0 && AnimElemTime(17) < 0
pos = -5,-9

[State 1275, BindToParent 17]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(17) >= 0 && AnimElemTime(18) < 0
pos = -9,-9

[State 1275, BindToParent 18]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(18) >= 0 && AnimElemTime(19) < 0
pos = -14,-9

[State 1275, BindToParent 19]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(19) >= 0 && AnimElemTime(20) < 0
pos = -19,-8

[State 1275, BindToParent 20]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(20) >= 0 && AnimElemTime(21) < 0
pos = -23,-7

[State 1275, BindToParent 21]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(21) >= 0 && AnimElemTime(22) < 0
pos = -27,-7

[State 1275, BindToParent 22]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(22) >= 0 && AnimElemTime(23) < 0
pos = -29,-6

[State 1275, BindToParent 23]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(23) >= 0 && AnimElemTime(24) < 0
pos = -32,-6

[State 1275, BindToParent 24]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(24) >= 0 && AnimElemTime(25) < 0
pos = -33,-5

[State 1275, BindToParent 25]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(25) >= 0 && AnimElemTime(26) < 0
pos = -32,-4

[State 1275, BindToParent 26]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(26) >= 0 && AnimElemTime(27) < 0
pos = -30,-3

[State 1275, BindToParent 27]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(27) >= 0 && AnimElemTime(28) < 0
pos = -28,-2

[State 1275, BindToParent 28]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(28) >= 0 && AnimElemTime(29) < 0
pos = -24,-2

[State 1275, BindToParent 29]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(29) >= 0 && AnimElemTime(30) < 0
pos = -20,-1

[State 1275, BindToParent 30]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(30) >= 0 && AnimElemTime(31) < 0
pos = -15,0

[State 1275, BindToParent 31]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(31) >= 0 && AnimElemTime(32) < 0
pos = -10,0

[State 1275, BindToParent 32]
type = BindToParent
trigger1 = Anim = 1212
trigger1 = parent, stateno = 1271
trigger1 = AnimElemTime(32) >= 0
pos = -5,0

[State 1275, ChangeAnim 1]
type = ChangeAnim
trigger1 = Anim = 1211
trigger1 = AnimTime = 0
value = 1212

[State 1275, SprPriority 1]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 5
value = 2

[State 1275, SprPriority 2]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 9
value = 0

[State 1275, SprPriority 3]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 13
value = -1

[State 1275, SprPriority 4]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 17
value = 0

[State 1275, SprPriority 5]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 21
value = 2

[State 1275, SprPriority 6]
type = SprPriority
trigger1 = Anim = 1212
trigger1 = AnimElem = 29
value = 3

;[State 1275, PosAdd]
;type = PosAdd
;trigger1 = Anim = 1212
;trigger1 = parent, stateno != 1271
;x = -5 + 27*cos(2*PI*(AnimElemNo(0)+7)/32)
;y = -5 +  5*sin(2*PI*(AnimElemNo(0)+7)/32)

[State 1275, ChangeAnim 2]
type = ChangeAnim
trigger1 = Anim = 1212
trigger1 = parent, stateno != 1271
value = 1213

[State 1275, Explod 1]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(5) >= 0
trigger1 = AnimElemTime(9) < 0
anim = 1215
sprpriority = 3

[State 1275, Explod 2]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(9) >= 0
trigger1 = AnimElemTime(13) < 0
anim = 1215
sprpriority = 1

[State 1275, Explod 3]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(13) >= 0
trigger1 = AnimElemTime(17) < 0
anim = 1215
sprpriority = 0

[State 1275, Explod 4]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(17) >= 0
trigger1 = AnimElemTime(21) < 0
anim = 1215
sprpriority = 1

[State 1275, Explod 5]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(21) >= 0
trigger1 = AnimElemTime(29) < 0
anim = 1215
sprpriority = 3

[State 1275, Explod 6]
type = Explod
triggerall = Anim = 1212
triggerall = Time % 2 = 1
trigger1 = AnimElemTime(29) > 0
trigger2 = AnimElemTime(1) >= 0
trigger2 = AnimElemTime(5) < 0
anim = 1215
sprpriority = 4

[State 1275, DestroySelf]
type = DestroySelf
trigger1 = Anim = 1213
trigger1 = AnimTime = 0

;=====================<COBRA BLOW>==========================
[StateDef 1300]
type = S
physics = S
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1300, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1300, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1300, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1320, ifElse(var(10) = 1, 1310, 1300))

[State 1300, 1]
type = PlaySnd
trigger1 = Time = 2
value = 1, 2

[State 1300, 2] ;Voice
type = PlaySnd
trigger1 = Time = 1
value = 4, 0
channel = 0

[State 1300, HitDef 1]
type = HitDef
triggerall = var(10) = [0,2]
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 33, ifElse(var(10), 40, 55)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 33, ifElse(var(10), 40, 55)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1300, HitDef 2]
type = HitDef
triggerall = var(10) = [0,2]
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 4 && MoveContact = 0
trigger2 = AnimElem = 4, = 1
trigger3 = AnimElem = 4 && HitPauseTime = 2
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 33, ifElse(var(10), 40, 55)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 33, ifElse(var(10), 40, 55)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1300, HitDef 3]
type = HitDef
triggerall = var(10) = [1,2]
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5 && MoveContact = 0
trigger2 = AnimElem = 5, = 1 && MoveContact != 0
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 32, ifElse(var(10), 40, 55)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 32, ifElse(var(10), 40, 55)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1300, HitDef 4]
type = HitDef
triggerall = var(10) = 2
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6 && MoveContact = 0
trigger2 = AnimElem = 6, = 1 && MoveContact != 0
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 32, ifElse(var(10), 40, 55)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 32, ifElse(var(10), 40, 55)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1300, 6]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<EX COBRA BLOW>=============================
[StateDef 1330]
type = S
physics = S
moveType = A
anim = 1330
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1330, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1330, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1330, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1330, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 224

[State 1330, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1330, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1330, 1]
type = PlaySnd
trigger1 = Time = 2
value = 1, 2
channel = 2

[State 1330, 2] ;Voice
type = PlaySnd
trigger1 = Time = 1
value = 4, 0
channel = 0

[State 1330, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1300, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 4 && MoveContact = 0
trigger2 = AnimElem = 4, = 1 && MoveContact != 0
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1300, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5 && MoveContact = 0
trigger2 = AnimElem = 5, = 1 && MoveContact != 0
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1300, HitDef 4]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6 && MoveContact = 0
trigger2 = AnimElem = 6, = 1 && MoveContact != 0
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 23 < 7, 7, fvar(11) * 23)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1300, HitDef 5]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 7 && MoveContact = 0
trigger2 = AnimElem = 7, = 1 && MoveContact != 0
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 23 < 7, 7, fvar(11) * 23)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1300, HitDef 6]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 8 && MoveContact = 0
trigger2 = AnimElem = 8, = 1 && MoveContact != 0
attr = S, SA
hitFlag = MA
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 23 < 7, 7, fvar(11) * 23)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, -6
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -9, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 257), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48


[State 1330, 9] ;Set win type to ES
type = VarSet
triggerall = numtarget != 0
triggerall = target, Life = 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life = 0
trigger2 = enemynear(1), life = 0
v = 5
value = 1
persistent = 0

[State 1330, 6]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<MIIRA DROP>==========================
[StateDef 1400]
type = S
physics = S
moveType = I
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1400, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1400, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 0, HitOverride]
type = HitOverride
trigger1 = AnimElemTime(1) >= 0
trigger1 = AnimElemTime(5) < 0
attr = SCA,NP,SP,HP
stateno = 1401
time = 3

[State 1410, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Kotodama Gaeshi - Absorb
[Statedef 1401]
type = S
movetype = I
physics = S
poweradd = 110
sprpriority = 7

[State 1401, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 1401
elem = AnimElemNo(0)

[State 1401, 2]
type = NotHitBy
trigger1 = 1
value = ,AP

[State 1401, 3]
type = PlaySnd
trigger1 = Time = 0
value = 1400,1

[State 1401, 4]
type = VarSet
trigger1 = Time = 0
v = 14
value = 1

[State 1401, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Kotodama Gaeshi - Spit Projectile
[Statedef 1402]
type = A
movetype = A
physics = S
juggle  = 4
poweradd = 0
ctrl = 0
velset = 0,0
anim = 1402
sprpriority = 2

[State 1402, 1] ;Voice
type = PlaySnd
trigger1 = AnimElem = 9
value = 1400,2
channel = 0

[State 1402, 2] ;Projectile Sound
type = PlaySnd
trigger1 = AnimElem = 9
value = 1400,3

[State 1402, 3]
type = Projectile
trigger1 = AnimElem = 9, = 1
ProjID = 1402
projanim = 40000
projhitanim = 40001
projremanim = -1
projcancelanim = 40001
offset = 58,-61
velocity = 4,0
attr = S, SP
damage = 70
getpower = ifElse(!var(13), 72, 36) * !var(20) * !var(51), 12 * !var(20) * !var(51)
givePower = 36, 36
guardflag = MA
pausetime = 9,9
sparkno = 1
sparkxy = -10,0
hitsound = S2,6
guardsound = S3,0
ground.type = High
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -8
airguard.velocity = -3.5
air.velocity = -2.5,-5.5
air.juggle = 3
air.fall = 1

[State 1402, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Kotodama Gaeshi - Spit Projectile
[Statedef 1403]
type = A
movetype = A
physics = N
juggle  = 4
poweradd = 0
ctrl = 0
anim = 1402
sprpriority = 2

[State 1403, 1]
type = PosFreeze
trigger1 = 1
value = 1

[State 1403, 2] ;Voice
type = PlaySnd
trigger1 = AnimElem = 9
value = 1400,2
channel = 0

[State 1403, 3] ;Projectile Sound
type = PlaySnd
trigger1 = AnimElem = 9
value = 1400,3

[State 1403, 4]
type = Projectile
trigger1 = AnimElem = 9, = 1
ProjID = 1403
projanim = 40002
projhitanim = 40003
projremanim = -1
projcancelanim = 40003
projheightbound = -240,-19
offset = 58,-61
velocity = 3,4
attr = A, SP
damage = 70
getpower = ifElse(!var(13), 72, 36) * !var(20) * !var(51), 12 * !var(20) * !var(51)
givePower = 36, 36
guardflag = MA
pausetime = 9,9
sparkno = 1
sparkxy = -10,0
hitsound = S2,6
guardsound = S3,0
ground.type = High
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -8
airguard.velocity = -3.5
air.velocity = -2.5,-5.5
air.juggle = 3
air.fall = 1

[State 1403, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 1403, 5]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 1403, 6]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;========================<EX HAKU>=============================
[StateDef 1432]
type = S
physics = S
moveType = A
anim = 1402
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1432, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1432, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1432, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1432, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 224

[State 1432, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1432, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1432, 1] ;Voice
type = PlaySnd
trigger1 = AnimElem = 9
value = 1400,2
channel = 0

[State 1432, 2] ;Projectile Sound
type = PlaySnd
trigger1 = AnimElem = 9
value = 1400,3

[State 1432, 3]
type = Projectile
trigger1 = AnimElem = 9, = 1
ProjID = 1402
projanim = 40004
projhitanim = 40005
projremanim = -1
projcancelanim = 40005
projhits = 3
projmisstime = 0
projpriority = 3
offset = 58,-61
velocity = 7,0
attr = S, HP
damage = 50,7
getpower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 10,10
sparkno = 1
sparkxy = -10,0
hitsound = S2,6
guardsound = S3,0
ground.type = High
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -2,-6
guard.velocity = -8
airguard.velocity = -3.5
air.velocity = -2.5,-5.5
air.juggle = 3
fall = 1
getpower = 0

[State 1432, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<EX AIR HAKU>=============================
[StateDef 1433]
type = A
physics = N
moveType = A
anim = 1402
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1433, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1433, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1433, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1433, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 224

[State 1433, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1433, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1433, 1]
type = PosFreeze
trigger1 = 1
value = 1

[State 1433, 2] ;Voice
type = PlaySnd
trigger1 = AnimElem = 9
value = 1400,2
channel = 0

[State 1433, 3] ;Projectile Sound
type = PlaySnd
trigger1 = AnimElem = 9
value = 1400,3

[State 1419, 4]
type = Projectile
trigger1 = AnimElem = 9, = 1
ProjID = 1403
projanim = 40006
projhitanim = 40007
projremanim = -1
projcancelanim = 40007
projheightbound = -240,-19
projhits = 3
projmisstime = 0
projpriority = 3
offset = 58,-61
velocity = 6,2
attr = S, SP
damage = 50,7
getpower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 10,10
sparkno = 1
sparkxy = -10,0
hitsound = S2,6
guardsound = S3,0
ground.type = High
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -2,-6
guard.velocity = -8
airguard.velocity = -3.5
air.velocity = -2.5,-5.5
air.juggle = 3
fall = 1
getpoewr = 0

[State 1433, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 1433, 5]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 1433, 6]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;========================<TOGAME NO ANA>=============================
[StateDef 1500]
type = S
physics = N
moveType = A
anim = 1500
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1500, 1] ;Voice
type = PlaySnd
trigger1 = Time = 4
value = 1600, 0
channel = 0

[State 1500, 2] ;Top Half Open
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1510
vel = 2,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1500, 3] ;Bottom Half Open
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1520
vel = -2,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1500, 4] ;Top Half Opened
type = Explod
trigger1 = Time = 23
ID = 1510
anim = 1510
pos = 46,0
vel = 0,0
removetime = 20
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1500, 5] ;Bottom Half Opened
type = Explod
trigger1 = Time = 23
ID = 1510
anim = 1520
pos = -46,0
vel = 0,0
removetime = 20
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1500, 6] ;Closing vulnerable
type = ChangeAnim
trigger1 = Time = 43
value = 1501

[State 1500, 7] ;Closing vulnerable
type = PosAdd
trigger1 = Time = 43
x = 46

[State 1500, 8] ;Closing vulnerable
type = PosAdd
trigger1 = Time >= 43
x = -2

[State 1500, 9] ;Closing vulnerable
type = Helper
trigger1 = Time = 0
name = "Camera Holder"
ID  = 1506
pos =  0,0
stateno = 1506

[State 1500, 10] ;Top Half Closing
type = Explod
trigger1 = Time = 43
ID = 1510
anim = 1510
pos = 0,0
vel = -2,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1500, 11] ;Bottom Half Closing
type = Explod
trigger1 = Time = 43
ID = 1510
anim = 1520
pos = -92,0
vel = 2,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1500, 12] ;Pit Helper
type = Helper
trigger1 = Time = 0
name = "Pit of Blame"
ID = 1510
stateno = 1510
pos = 3,-6

[State 1500, 13] ;Miss
type = ChangeState
trigger1 = Time = 66
value = 1505

[State 1500, 14] ;Hit
type = RemoveExplod
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), MoveHit = 1
ID = 1510

[State 1500, 15] ;Hit
type = ChangeState
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), MoveHit = 1
value = 1501

;Togame no Ana - Hit Successful
[Statedef 1501]
type = S
movetype = A
physics = S
anim = 1500
sprpriority = 2

[State 1501, 1] ;Top Half Opened
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1510
pos = 46,0
vel = 0,0
removetime = -1
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1501, 2] ;Bottom Half Opened
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1520
pos = -46,0
vel = 0,0
removetime = -1
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1501, 3]
type = RemoveExplod
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), stateno = 1513
trigger1 = helper(1510), time = 1
ID = 1510

[State 1501, 4] ;Top Half Jump In
type = Explod
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), stateno = 1513
trigger1 = helper(1510), time = 1
ID = 1511
anim = 1511
pos = 46,0
vel = -2,-3
accel = 0,.44
sprpriority = 0
removetime = ifelse(helper(1510),var(40)=1,30,20)
removeongethit = 1

[State 1501, 5] ;Bottom Half Jump In
type = Explod
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), stateno = 1513
trigger1 = helper(1510), time = 1
ID = 1511
anim = 1521
pos = -46,0
vel = 2,-3
accel = 0,.44
removetime = ifelse(helper(1510),var(40)=1,30,20)
sprpriority = 0
removeongethit = 1

[State 1501, 6]
type = ChangeState
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), stateno = 1514
value = 1502

;Pit of Blame - Falling
[Statedef 1502]
type = A
movetype = A
physics = N
anim = 1502
velset = 0,4
sprpriority = 1

[State 1502, 1]
type = PosSet
trigger1 = Time = 0
y = -300 - 9

[State 1502, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1502, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1502, 4]
type = VelSet
trigger1 = Pos Y >= 0 - 9
y = 0

[State 1502, 5]
type = PosSet
trigger1 = Pos Y >= 0 - 9
y = -9

[State 1502, 6]
type = ChangeState
trigger1 = Pos Y >= 0 - 9
value = 1503

;Togame no Ana - Hitting Ground
[Statedef 1503]
type = A
movetype = A
physics = N
anim = 1503
velset = 0,0
sprpriority = 1

[State 1503, 1] ;Crash sound
type = PlaySnd
trigger1 = Time = 0
value = 820, 2

[State 1503, Impact Dust]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 0, floor(-Pos Y)
facing = -1
ownPal = 1

[State 1503, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 1504

;Togame no Ana - Jumping Back
[Statedef 1504]
type = A
movetype = A
physics = A
anim = 1504
velset = -2,-.5
sprpriority = 2

[State 1504, 1] ;Less Gravity
type = VelAdd
trigger1 = 1
y = -Const(movement.yaccel) + .1

;Togame no Ana - Miss
[Statedef 1505]
type = S
movetype = I
physics = S
velset = 0,0
anim = 1505
sprpriority = 2

[State 1505, Var] ;Don't bounce in state 5110
type = VarSet
trigger1 = Time = 0
sysvar(0) = 1

[State 1505, 1]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Togame no Ana - Camera Holder
[Statedef 1506]
type = S
movetype = A
physics = N
sprpriority = 1
velset = 0,0
anim = 108

[State 1506, 1]
type = Screenbound
trigger1 = 1
value = 1
movecamera = 1,1

[State 1506, 2]
type = DestroySelf
trigger1 = parent,stateno != 1500
trigger1 = parent,stateno != 1530

;Togame no Ana - Pit Helper
[Statedef 1510]
type = S
movetype = A
physics = N
juggle = 4
ctrl = 0
velset = 0,0
anim = 1530
sprpriority = -2

[State 1510, 1] ;Whether at absolute bottom of screen
type = VarSet
trigger1 = Time = 0
trigger1 = 239-ScreenPos Y-29 <= 10
v = 40
value = 1 ; At bottom

[State 1510, 1b] ;Whether at absolute bottom of screen
type = VarSet
trigger1 = Time = 0
trigger1 = 239-ScreenPos Y-29 > 10
v = 40
value = 0 ; Not at bottom

[State 1510, 2] ;Place at absolute bottom of screen
type = PosAdd
trigger1 = Time = 0
trigger1 = 239-ScreenPos Y-29 = [0,10]
y = (239-ScreenPos Y)-29

[State 1510, 3] ;Glow
type = Explod
trigger1 = AnimElem = 9
ID = 1520
anim = 1531
bindtime = -1
sprpriority = -1
ownpal = 1

[State 1610, 4]
type = HitDef
Trigger1 = Time = 0
attr = S, HT
hitflag = MA-
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1facing = 1
p2facing = 1
p1stateno = 1511
p2stateno = 1550
guard.dist = 0
fall = 1
fall.yvelocity = 0
fall.damage = 140
fall.envshake.time = 16
fall.envshake.ampl = 5
fall.envshake.freq = 120

[State 1510, 5] ;Glow Miss
type = Explod
trigger1 = AnimElem = 10
ID = 1520
anim = 3124
bindtime = -1
sprpriority = -1
ownpal = 1

[State 1510, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1510, 7]
type = DestroySelf
trigger1 = AnimTime = 0

;Togame no Ana - Pit Helper - Hit Successful
[Statedef 1511]
type = S
movetype = A
physics = N
anim = 3111
sprpriority = -2

[State 1511, 1] ;Remove Glow
type = RemoveExplod
trigger1 = Time = 0
ID = 1520

[State 1511, 2] ;New Glow
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3121
bindtime = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 1511, 3] ;Hit sound
type = PlaySnd
trigger1 = Time = 2
value = 3100,1

[State 1511, 4] ;Extra Frames
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3121
bindtime = -1
removetime = -1
sprpriority = -1

[State 1511, 5] ;Bind X > and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X > 1
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = (target, Pos X - Pos X - 1)*facing, target, Pos Y - Pos Y - 2

[State 1511, 6] ;Bind X > and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X > 1
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = (target, Pos X - Pos X - 1)*facing, -110

[State 1511, 7] ;Bind X < and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X < -1
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = (target, Pos X - Pos X + 1)*facing, target, Pos Y - Pos Y - 2

[State 1511, 8] ;Bind X < and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X < -1
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = (target, Pos X - Pos X + 1)*facing, -110

[State 1511, 9] ;Bind X = and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X = [-1, 1]
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = 0, target, Pos Y - Pos Y - 2

[State 1511, 10] ;Bind X = and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X = [-1, 1]
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = 0, -110

[State 1511, 11] ;Bind X too far away
type = TargetBind
trigger1 = target, Pos X - Pos X > 56
pos = 56*facing, target, Pos Y - Pos Y - 2

[State 1511, 12] ;Bind X too far away
type = TargetBind
trigger1 = target, Pos X - Pos X < -56
pos = -56*facing, target, Pos Y - Pos Y - 2

[State 1511, 13]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1511, 14] ;Remove Glow
type = RemoveExplod
trigger1 = AnimTime = 0
ID = 1520

[State 1511, 15]
type = ChangeState
trigger1 = AnimTime = 0
value = 1512

;Togame no Ana - Pit Helper - Hit Successful - Open Up
[Statedef 1512]
type = S
movetype = A
physics = N
anim = 3112
sprpriority = -2

[State 1512, 1] ;Glow
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3122
bindtime = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 1512, 2] ;Extra Layer Frames
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3114
bindtime = -1
removetime = -1
sprpriority = 3

[State 1512, 3]
type = TargetState
trigger1 = Time = 0
trigger1 = Var(40) = 1 ; At bottom
value = 1555

[State 1512, 4]
type = TargetState
trigger1 = Time = 0
trigger1 = Var(40) = 0 ; Not at bottom
value = 1551

[State 1512, 5]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1512, 6]
type = ChangeState
trigger1 = target, stateno != 1551
trigger1 = target, stateno != 1555
value = 1513

;Togame no Ana - Pit Helper - Hit Successful - Waiting for Player
[Statedef 1513]
type = S
movetype = A
physics = N
sprpriority = -2

[State 1513, 1] ;Remove Glow
type = RemoveExplod
trigger1 = Time = ifelse(var(40)=1,30,20)
ID = 1520

[State 1513, 3]
type = ChangeState
trigger1 = Time = ifelse(var(40)=1,30,20)
value = 1514

;Togame no Ana - Pit Helper - Hit Successful - Close
[Statedef 1514]
type = S
movetype = A
physics = N
anim = 3113
sprpriority = -2

[State 1514, 1]
type = TargetState
trigger1 = Time = 1
value = 1553

[State 1514, 2] ;Remove Extra Layer Frames
type = RemoveExplod
trigger1 = Time = 0
ID = 1520

[State 1514, 3] ;Extra Layer Frames
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3115
bindtime = -1
sprpriority = 3

[State 1514, 4] ;Glow Close
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3123
bindtime = -1
sprpriority = -1
ownpal = 1

[State 1514, 5]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1514, 6]
type = DestroySelf
trigger1 = AnimElem = 12

;Togame no Ana - Get Hit
[Statedef 1550]
type = A
movetype = H
physics = N
sprpriority = 0

[State 1550, 1]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1550, 2]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(7008) = 0
value = 3150

[State 1550, 2b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(7008) = 1
value = 7008

[State 1550, 3]
type = SelfState
trigger1 = !gethitvar(isbound)
value = 5050

;Togame no Ana - Falling
[Statedef 1551]
type = A
movetype = H
physics = N

[State 1551, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5070

[State 1551, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1551, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1551, 4]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1551, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 1551, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1551, 7]
type = ChangeState
trigger1 = Pos Y >= 30
value = 1552

;Togame no Ana - Waiting
[Statedef 1552]
type = A
movetype = H
physics = N
velset = 0,0

[State 1552, 1]
type = ChangeAnim2
trigger1 = Time = 0
value = 1552

[State 1552, 2]
type = PosSet
trigger1 = Time = 0
y = 10

[State 1552, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

;Togame no Ana - Falling Second Time
[Statedef 1553]
type = A
movetype = H
physics = N
velset = 0,4

[State 1553, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5080

[State 1553, 2]
type = PosSet
trigger1 = Time = 0
y = -300

[State 1553, 3] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1553, 4]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1553, 5]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1553, 6]
type = PlayerPush
trigger1 = 1
value = 0

[State 1553, 7]
type = ChangeState
trigger1 = Pos Y >= 0
value = 1554

;Togame no Ana - HIT_BOUNCE (hit ground)
[Statedef 1554]
type = L
movetype = H
physics = N

[State 1554, EnvShake]
type = FallEnvShake
trigger1 = Time = 0

[State 1554, 2] ;Hit ground anim
type = ChangeAnim
trigger1 = Time = 0
value = 5100

[State 1554, 2] ;Lie down
type = ChangeAnim
trigger1 = Time = 3
value = 5110

[State 1554, 2] ;Hit ground anim
type = ChangeAnim
trigger1 = Time = 16
value = 5080

[State 1554, 2] ;Lie down anim
type = ChangeAnim
trigger1 = Time = 26
value = 5110

[State 1554, 4]
type = PosSet
trigger1 = Time = 0
y = 0

[State 1554, 5]
type = VelSet
trigger1 = Time = 0
y = 0

[State 1554, 6]
type = HitFallDamage
trigger1 = Time = 3

[State 1554, 7] ;Freeze last frame of animation
type = ChangeAnim
trigger1 = AnimTime = 0
trigger1 = Anim != 5080
value = Anim
elem = AnimElemNo(-1)

[State 1554, Var] ;Don't bounce in state 5110
type = VarSet
trigger1 = Time = 0
sysvar(0) = 1

[State 1554, 8]
type = SelfState
trigger1 = Time = 50 ;(Anakaris finishes move at Time = 50)
value = 5110

[State 1554, 9]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1554, 10]
type = ForceFeedback
trigger1 = Time = 0
waveform = sinesquare
ampl = 128,-3,-.2,.005
time = 20

;Togame no Ana - Falling - Pit near bottom of screen
[Statedef 1555]
type = A
movetype = H
physics = N

[State 1555, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5070

[State 1555, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1555, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1555, 4]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1555, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 1555, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1555, 7]
type = ChangeState
trigger1 = Pos Y >= 120
value = 1552

;========================<EX TOGAME NO ANA>=============================
[StateDef 1530]
type = S
physics = S
moveType = A
anim = 1500
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1530, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1530, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1530, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1530, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 224

[State 1530, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1530, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1530, 1] ;Voice
type = PlaySnd
trigger1 = Time = 0
value = 1630, 0
channel = 0

[State 1530, 2] ;Top Half Open
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1540
vel = 2,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 2600, 3] ;Bottom Half Open
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1550
vel = -2,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 2600, 4] ;Top Half Opened
type = Explod
trigger1 = Time = 23
ID = 1510
anim = 1540
pos = 46,0
vel = 0,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 2600, 5] ;Bottom Half Opened
type = Explod
trigger1 = Time = 23
ID = 1510
anim = 1550
pos = -46,0
vel = 0,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1530, 6] ;Closing vulnerable
type = ChangeAnim
trigger1 = Time = 43
value = 1501

[State 1530, 7] ;Closing vulnerable
type = PosAdd
trigger1 = Time = 43
x = 46

[State 1530, 8] ;Closing vulnerable
type = PosAdd
trigger1 = Time >= 43
x = -2

[State 1530, 9] ;Closing vulnerable
type = Helper
trigger1 = Time = 0
name = "Camera Holder"
ID  = 1506
pos =  0,0
stateno = 1506

[State 1530, 10] ;Top Half Closing
type = Explod
trigger1 = Time = 43
ID = 1510
anim = 1540
pos = 0,0
vel = -2,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1530, 11] ;Bottom Half Closing
type = Explod
trigger1 = Time = 43
ID = 1510
anim = 1550
pos = -92,0
vel = 2,0
removetime = 23
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1530, 12] ;Pit Helper
type = Helper
trigger1 = Time = 0
name = "Pit of Blame"
ID = 1510
stateno = 1540
pos = 3,-6

[State 1530, 13] ;Miss
type = ChangeState
trigger1 = Time = 66
value = 1536

[State 1530, 14] ;Hit
type = RemoveExplod
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), MoveHit = 1
ID = 1540

[State 1530, 15] ;Hit
type = ChangeState
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), MoveHit = 1
value = 1531

;EX Togame no Ana - Hit Successful
[Statedef 1531]
type = S
movetype = A
physics = S
anim = 1500
sprpriority = 2

[State 1531, 1] ;Top Half Opened
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1540
pos = 46,0
vel = 0,0
removetime = -1
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1531, 2] ;Bottom Half Opened
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1550
pos = -46,0
vel = 0,0
removetime = -1
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1531, 3]
type = RemoveExplod
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), stateno = 1543
trigger1 = helper(1510), time = 1
ID = 1510

[State 1531, 4] ;Top Half Jump In
type = Explod
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), stateno = 1543
trigger1 = helper(1510), time = 1
ID = 1511
anim = 1511
pos = 46,0
vel = -2,-3
accel = 0,.44
sprpriority = 0
removetime = ifelse(helper(1510),var(40)=1,30,20)
removeongethit = 1

[State 1531, 5] ;Bottom Half Jump In
type = Explod
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), stateno = 1543
trigger1 = helper(1510), time = 1
ID = 1511
anim = 1521
pos = -46,0
vel = 2,-3
accel = 0,.44
removetime = ifelse(helper(1510),var(40)=1,30,20)
sprpriority = 0
removeongethit = 1

[State 1531, 6]
type = ChangeState
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), stateno = 1544
value = 1532

;EX Togame no Ana - Falling
[Statedef 1532]
type = A
movetype = A
physics = N
anim = 1502
velset = 0,4
sprpriority = 1

[State 1532, 1]
type = PosSet
trigger1 = Time = 0
y = -300 - 9

[State 1532, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1532, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1532, 4]
type = ChangeState
triggerall = Pos Y >= 10 - 9
trigger1 = numhelper(1510) = 0
trigger2 = numhelper(1510) != 0
trigger2 = helper(1510), var(40) = 0
value = 1533

[State 1532, 5]
type = ChangeState
trigger1 = Pos Y >= 120 - 9
trigger1 = numhelper(1510) != 0
trigger1 = helper(1510), var(40) = 1
value = 1533

;EX Togame no Ana - Falling Second Time
[Statedef 1533]
type = A
movetype = A
physics = N
anim = 1502
velset = 0,4
sprpriority = 1

[State 1533, 1]
type = PosSet
trigger1 = Time = 0
y = -300 - 9

[State 1533, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1533, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1533, 4]
type = VelSet
trigger1 = Pos Y >= 0 - 9
y = 0

[State 1533, 5]
type = PosSet
trigger1 = Pos Y >= 0 - 9
y = -9

[State 1533, 6]
type = ChangeState
trigger1 = Pos Y >= 0 - 9
value = 1534

;EX Togame no Ana - Hitting Ground
[Statedef 1534]
type = A
movetype = A
physics = N
anim = 1503
velset = 0,0
sprpriority = 2

[State 1534, 1] ;Crash sound
type = PlaySnd
trigger1 = Time = 0
value = 820, 2

[State 1534, Impact Dust]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 0, floor(-Pos Y)
facing = -1
ownPal = 1

[State 1534, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 1535

;EX Togame no Ana - Jumping Back
[Statedef 1535]
type = A
movetype = A
physics = A
anim = 1504
velset = -2,-.5
sprpriority = 2

[State 1535, 1] ;Less Gravity
type = VelAdd
trigger1 = 1
y = -Const(movement.yaccel) + .1

;EX Togame no Ana - Miss
[Statedef 1536]
type = S
movetype = I
physics = S
anim = 1536
sprpriority = 2

[State 1536, 1] ;Top Half Closing
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1540
removetime = 5
sprpriority = 2
shadow = 255,255,255
removeongethit = 1

[State 1536, 2] ;Bottom Half Closing
type = Explod
trigger1 = Time = 0
ID = 1510
anim = 1550
removetime = 15
sprpriority = 0
shadow = 255,255,255
removeongethit = 1

[State 1536, Var] ;Don't bounce in state 5110
type = VarSet
trigger1 = Time = 0
sysvar(0) = 1

[State 1536, 3] ;End voice
type = StopSnd
trigger1 = AnimTime = 0
channel = 0

[State 1536, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;EX Togame no Ana - Pit Helper
[Statedef 1540]
type = S
movetype = A
physics = N
juggle  = 4
ctrl = 0
velset = 0,0
anim = 1530
sprpriority = -2

[State 1540, 1] ;Whether at absolute bottom of screen
type = VarSet
trigger1 = Time = 0
trigger1 = 239-ScreenPos Y-29 <= 10
v = 40
value = 1 ; At bottom

[State 1540, 1b] ;Whether at absolute bottom of screen
type = VarSet
trigger1 = Time = 0
trigger1 = 239-ScreenPos Y-29 > 10
v = 40
value = 0 ; Not at bottom

[State 1540, 2] ;Place at absolute bottom of screen
type = PosAdd
trigger1 = Time = 0
trigger1 = 239-ScreenPos Y-29 = [0,10]
y = (239-ScreenPos Y)-29

[State 1540, 3] ;Glow
type = Explod
trigger1 = AnimElem = 9
ID = 1520
anim = 1531
bindtime = -1
sprpriority = -1
ownpal = 1

[State 2610, 4]
type = HitDef
Trigger1 = Time = 0
attr = S, HT
hitflag = MA-
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1facing = 1
p2facing = 1
p1stateno = 1541
p2stateno = 1560
guard.dist = 0
fall = 1
fall.yvelocity = 0
fall.damage = 150
fall.envshake.time = 16
fall.envshake.ampl = 5
fall.envshake.freq = 120
getpower = 0

[State 1540, 5] ;Glow Miss
type = Explod
trigger1 = AnimElem = 10
ID = 1520
anim = 3124
bindtime = -1
sprpriority = -1
ownpal = 1

[State 1540, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1540, 7]
type = DestroySelf
trigger1 = AnimTime = 0

;EX Togame no Ana - Pit Helper - Hit Successful
[Statedef 1541]
type = S
movetype = A
physics = N
anim = 3111
sprpriority = -2

[State 1541, 1] ;Remove Glow
type = RemoveExplod
trigger1 = Time = 0
ID = 1520

[State 1541, 2] ;New Glow
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3121
bindtime = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 1541, 3] ;Extra Frames
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3121
bindtime = -1
removetime = -1
sprpriority = -1

[State 1541, 4] ;Hit sound
type = PlaySnd
trigger1 = Time = 2
value = 3100,1

[State 1541, 5] ;Bind X > and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X > 1
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = (target, Pos X - Pos X - 1)*facing, target, Pos Y - Pos Y - 2

[State 1541, 6] ;Bind X > and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X > 1
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = (target, Pos X - Pos X - 1)*facing, -110

[State 1541, 7] ;Bind X < and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X < -1
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = (target, Pos X - Pos X + 1)*facing, target, Pos Y - Pos Y - 2

[State 1541, 8] ;Bind X < and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X < -1
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = (target, Pos X - Pos X + 1)*facing, -110

[State 1541, 9] ;Bind X = and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X = [-1, 1]
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = 0, target, Pos Y - Pos Y - 2

[State 1541, 10] ;Bind X = and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X = [-1, 1]
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = 0, -110

[State 1541, 11] ;Bind X too far away
type = TargetBind
trigger1 = target, Pos X - Pos X > 56
pos = 56*facing, target, Pos Y - Pos Y - 2

[State 1541, 12] ;Bind X too far away
type = TargetBind
trigger1 = target, Pos X - Pos X < -56
pos = -56*facing, target, Pos Y - Pos Y - 2

[State 1541, 13]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1541, 14] ;Remove Glow
type = RemoveExplod
trigger1 = AnimTime = 0
ID = 1520

[State 1541, 15]
type = ChangeState
trigger1 = AnimTime = 0
value = 1542

;EX Togame no Ana - Pit Helper - Hit Successful - Open Up
[Statedef 1542]
type = S
movetype = A
physics = N
anim = 3112
sprpriority = -2

[State 1542, 1] ;Glow
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3122
bindtime = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 1542, 2] ;Extra Layer Frames
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3114
bindtime = -1
removetime = -1
sprpriority = 3

[State 1542, 3]
type = TargetState
trigger1 = Time = 0
trigger1 = Var(40) = 1 ; At bottom
value = 1566

[State 2612, 4]
type = TargetState
trigger1 = Time = 0
trigger1 = Var(40) = 0 ; Not at bottom
value = 1561

[State 1542, 5]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1542, 6]
type = ChangeState
trigger1 = target, stateno != 1561
trigger1 = target, stateno != 1566
value = 1543

;EX Togame no Ana - Pit Helper - Hit Successful - Waiting for Player
[Statedef 1543]
type = S
movetype = A
physics = N
sprpriority = -2

[State 1543, 1]
type = ChangeState
trigger1 = Time = ifelse(var(40)=1,30,20)
value = 1544

;EX Togame no Ana - Pit Helper - Hit Successful - Waiting for Player Second Fall
[Statedef 1544]
type = S
movetype = A
physics = N
sprpriority = -2

[State 1544, 1]
type = TargetState
trigger1 = Time = 1
trigger1 = Var(40) = 1
value = 1567

[State 2614, 2]
type = TargetState
trigger1 = Time = 1
trigger1 = Var(40) = 0
value = 1563

[State 2614, 3] ;Remove Glow
type = RemoveExplod
trigger1 = target, stateno = 1564
ID = 1520

[State 2614, 4]
type = ChangeState
trigger1 = target, stateno = 1564
value = 1545

;EX Togame no Ana - Pit Helper - Hit Successful - Close
[Statedef 1545]
type = S
movetype = A
physics = N
anim = 3113
sprpriority = -2

[State 1545, 1] ;Remove Extra Layer Frames
type = RemoveExplod
trigger1 = Time = 0
ID = 1520

[State 1545, 2] ;Extra Layer Frames
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3115
bindtime = -1
sprpriority = 3

[State 1545, 3] ;Glow
type = Explod
trigger1 = Time = 0
ID = 1520
anim = 3123
bindtime = -1
sprpriority = -1
ownpal = 1

[State 1545, 4]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1545, 5]
type = ChangeState
trigger1 = AnimElem = 12
value = 1546

;EX Togame no Ana - Pit Helper - Close Waiting
[Statedef 1546]
type = S
movetype = A
physics = N
anim = 3116

[State 1546, 1] ;Set win type to ES
type = ParentVarSet
triggerall = numtarget != 0
triggerall = target, Life = 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life = 0
trigger2 = enemynear(1), life = 0
v = 5
value = 1
persistent = 0

[State 1546, 2]
type = DestroySelf
trigger1 = numtarget = 0
trigger2 = target, stateno != [1560,1565]

;EX Togame no Ana - Get Hit
[Statedef 1560]
type = A
movetype = H
physics = N
sprpriority = 0

[State 1560, 1]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1560, 2]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(7008) = 0
value = 3150

[State 1560, 2b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(7008) = 1
value = 7008

[State 1560, 3]
type = SelfState
trigger1 = !gethitvar(isbound)
value = 5050

;EX Togame no Ana - Falling
[Statedef 1561]
type = A
movetype = H
physics = N

[State 1561, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5070

[State 1561, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1561, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1561, 4]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1561, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 1561, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1561, 7]
type = ChangeState
trigger1 = Pos Y >= 30
value = 1562

;EX Togame no Ana - Waiting
[Statedef 1562]
type = A
movetype = H
physics = N
velset = 0,0

[State 1562, 1]
type = ChangeAnim2
trigger1 = Time = 0
value = 1552

[State 1562, 2]
type = PosSet
trigger1 = Time = 0
y = 10

[State 1562, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1562, 4]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1562, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 1562, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

;EX Togame no Ana - Falling Second Time
[Statedef 1563]
type = A
movetype = H
physics = N
velset = 0,4

[State 1563, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5080

[State 1563, 2]
type = PosSet
trigger1 = Time = 0
y = -300

[State 1563, 3] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1563, 4]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1563, 5]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1563, 6]
type = PlayerPush
trigger1 = 1
value = 0

[State 1563, 7]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1563, 8]
type = ChangeState
trigger1 = Pos Y >= 10
value = 1564

;EX Togame no Ana - Falling Third Time
[Statedef 1564]
type = A
movetype = H
physics = N
velset = 0,4

[State 1564, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5080

[State 1564, 2]
type = PosSet
trigger1 = Time = 0
y = -300

[State 1564, 3] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1564, 4]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1564, 5]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1564, 6]
type = PlayerPush
trigger1 = 1
value = 0

[State 1564, 7]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1564, 8]
type = ChangeState
trigger1 = Pos Y >= 0
value = 1565

;EX Togame no Ana - HIT_BOUNCE (hit ground)
[Statedef 1565]
type = L
movetype = H
physics = N

[State 1565, EnvShake]
type = FallEnvShake
trigger1 = Time = 0

[State 1565, 2] ;Hit ground anim
type = ChangeAnim
trigger1 = Time = 0
value = 5100

[State 1565, 2] ;Lie down
type = ChangeAnim
trigger1 = Time = 3
value = 5110

[State 1565, 2] ;Hit ground anim
type = ChangeAnim
trigger1 = Time = 16
value = 5080

[State 1565, 2] ;Lie down anim
type = ChangeAnim
trigger1 = Time = 26
value = 5110

[State 1565, 4]
type = PosSet
trigger1 = Time = 0
y = 0

[State 1565, 5]
type = VelSet
trigger1 = Time = 0
y = 0

[State 1565, 6]
type = HitFallDamage
trigger1 = Time = 3

[State 1565, 7] ;Freeze last frame of animation
type = ChangeAnim
trigger1 = AnimTime = 0
trigger1 = Anim != 5080
value = Anim
elem = AnimElemNo(-1)

[State 1565, Var] ;Don't bounce in state 5110
type = VarSet
trigger1 = Time = 0
sysvar(0) = 1

[State 1565, 8]
type = SelfState
trigger1 = Time = 50 ;(Anakaris finishes move at Time = 50)
value = 5110

[State 1565, 9]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1565, 10]
type = ForceFeedback
trigger1 = Time = 0
waveform = sinesquare
ampl = 128,-3,-.2,.005
time = 20

;EX Togame no Ana - Falling - Pit near bottom of screen
[Statedef 1566]
type = A
movetype = H
physics = N

[State 1566, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5070

[State 1566, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1566, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1566, 4]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1566, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 1566, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1566, 7]
type = ChangeState
trigger1 = Pos Y >= 120
value = 1562

;EX Togame no Ana - Falling Second Time - Pit near bottom of screen
[Statedef 1567]
type = A
movetype = H
physics = N
velset = 0,4

[State 1567, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5080

[State 1567, 2]
type = PosSet
trigger1 = Time = 0
y = -300

[State 1567, 3] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 1567, 4]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 1567, 5]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1567, 6]
type = PlayerPush
trigger1 = 1
value = 0

[State 1567, 7]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 1567, 8]
type = ChangeState
trigger1 = Pos Y >= 120
value = 1564

;=====================<IMASHIME NO BOHI>==========================
[StateDef 1600]
type = S
physics = S
moveType = A
anim = 1600
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1600, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1600, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1600, 1] ;Pounce Sound
type = PlaySnd
trigger1 = AnimElem = 3
value = 1200, 2

[State 1600, 2] ;Cloud 1
type = Explod
trigger1 = AnimElemTime(3) = 0
anim = 4018
pos = 38,-91
sprpriority = 3

[State 1600, 3] ;Cloud 2
type = Explod
trigger1 = AnimElemTime(3) = 2
anim = 4018
pos = 25,-117
sprpriority = 3

[State 1600, 4] ;Cloud 3
type = Explod
trigger1 = AnimElemTime(3) = 3
anim = 4018
pos = 54,-107
sprpriority = 3

[State 1600, 5] ;Cloud 4
type = Explod
trigger1 = AnimElemTime(3) = 6
anim = 4018
pos = -14,-82
sprpriority = 3

[State 1600, 6] ;Legs
type = Explod
trigger1 = AnimTime = -1
anim = 1605
sprpriority = 0

[State 1600, 7]
type = ChangeState
trigger1 = AnimTime = 0
value = 1601

;Imashime no Bohi - Attacking
[Statedef 1601]
type = A
movetype = A
physics = A
anim = 1601
velset = 0,0
sprpriority = 2

[State 1601, 1]
type = PosAdd
trigger1 = Time = 0
x = P2Dist X
y = -48

[State 1601, 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = A, NA
hitflag = FD
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10), 119, 105)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10), 119, 105)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
guardflag = MA
pausetime = 9,9
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := 0
down.velocity = 0,0
down.hittime = 20
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1601, 3] ;Hit Spark
type = Explod
trigger1 = MoveHit = 1
trigger1 = HitPauseTime = 8
anim = F2
pos = 3,-3
ownpal = 1
ontop = 1
ignorehitpause = 1

[State 1601, 4]
type = ChangeState
trigger1 = MoveContact = 1
value = 1602

[State 1601, 5]
type = PlayerPush
trigger1 = 1
value = 0

;Imashime no Bohi - Jumping Back
[Statedef 1602]
type = A
movetype = I
physics = A
anim = 1602
velset = -2,-.5
sprpriority = 2

[State 1602, 1] ;Less Gravity
type = VelAdd
trigger1 = 1
y = -Const(movement.yaccel) + .1

;========================<EX IMASHIME NO BOHI>=============================
[StateDef 1630]
type = S
physics = S
moveType = A
anim = 1600
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1630, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1630, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1630, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1630, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 224

[State 1630, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1630, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1630, 1] ;Pounce Sound
type = PlaySnd
trigger1 = AnimElem = 3
value = 1200, 2

[State 1630, 2] ;Cloud 1
type = Explod
trigger1 = AnimElemTime(3) = 0
anim = 4018
pos = 38,-91
sprpriority = 3

[State 1630, 3] ;Cloud 2
type = Explod
trigger1 = AnimElemTime(3) = 2
anim = 4018
pos = 25,-117
sprpriority = 3

[State 1630, 4] ;Cloud 3
type = Explod
trigger1 = AnimElemTime(3) = 3
anim = 4018
pos = 54,-107
sprpriority = 3

[State 1630, 5] ;Cloud 4
type = Explod
trigger1 = AnimElemTime(3) = 6
anim = 4018
pos = -14,-82
sprpriority = 3

[State 1630, 6] ;Legs
type = Explod
trigger1 = AnimTime = -1
anim = 1605
sprpriority = 0

[State 1630, 7]
type = ChangeState
trigger1 = AnimTime = 0
value = 1631

;EX Imashime no Bohi - Attacking
[Statedef 1631]
type = A
movetype = A
physics = A
anim = 1601
velset = 0,0
sprpriority = 2

[State 1631, 1]
type = PosAdd
trigger1 = Time = 0
x = P2Dist X
y = -48

[State 1631, 2]
type = HitDef
trigger1 = Time = 4
attr = A, NA
hitflag = FD
damage = ceil(ifElse(fvar(11) * 71 < 7, 7, fvar(11) * 71)), 7
getPower = 0, 0
givePower = 36, 36
guardflag = MA
pausetime = 9,9
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := 0
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 1632
p2stateno = 1652
down.velocity = 0,0
down.hittime = 20
getpower = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1631, 6]
type = PlayerPush
trigger1 = 1
value = 0

;EX Imashime no Bohi - Hitting Again
[Statedef 1632]
type = A
movetype = I
physics = N
anim = 1632
velset = 0,0
sprpriority = 2

[State 1632, 2]
type = NotHitBy
trigger1 = 1
value = SCA

[State 1632, 3] ;Hand in back layer
type = Explod
trigger1 = Time = 0
anim = 1642
bindtime = -1
sprpriority = -1
removeongethit = 1

[State 1632, 4] ;Coffin Falling
type = Explod
trigger1 = Time = 0
anim = 1651
pos = 0,-120
postype = p1
vel = 0,8
removetime = 15
sprpriority = 0
removeongethit = 1

[State 1632, 5] ;Coffin
type = Explod
trigger1 = AnimElem = 2
anim = 1652
bindtime = -1
sprpriority = 0
removeongethit = 1

[State 1632, 6] ;Coffin Rising
type = Explod
trigger1 = AnimTime = 0
anim = 1651
vel = 0,-6
removetime = 10
sprpriority = 0
removeongethit = 1

[State 1632, Hit Spark]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8013
ID = 8000
name = "Spark"
posType = P1
pos = ceil(3 * const(size.xScale)), ceil(-3 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1632, 8] ;Hit Sound
type = PlaySnd
trigger1 = AnimElem = 3
value = 2,5

[State 1632, 9]
type = TargetLifeAdd
trigger1 = AnimElem = 3
value = -68

[State 1632, 10]
type = HitAdd
trigger1 = AnimElem = 3
value = 1

[State 1632, 11] ;Hit Shake State
type = TargetState
trigger1 = AnimElem = 3
value = 1654

[State 1632, 12] ;Set win type to ES
type = VarSet
triggerall = numtarget != 0
triggerall = target, Life = 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life = 0
trigger2 = enemynear(1), life = 0
v = 5
value = 1
persistent = 0

[State 1632, 13]
type = TargetState
trigger1 = AnimTime = 0
value = 1655

[State 1632, 14]
type = ChangeState
trigger1 = AnimTime = 0
value = 1633

;EX Imashime no Bohi - Jumping Back
[Statedef 1633]
type = A
movetype = I
physics = A
anim = 1602
velset = -2,-.5
sprpriority = 2

[State 1633, 1] ;Less Gravity
type = VelAdd
trigger1 = 1
y = -Const(movement.yaccel) + .1

;EX Imashime no Bohi - HITL_SHAKE
[Statedef 1652]
type = L
movetype = H
physics = N
velset = 0,0

[State 1652, 1] ;Set default anim
type = VarSet
trigger1 = time = 0
sysvar(2) = ifelse (GetHitVar(yvel) = 0, 5080, 5090)

[State 1652, 2]
type = VarAdd
trigger1 = time = 0
trigger1 = (anim = [5081,5089]) || (anim = [5111,5119])
trigger1 = SelfAnimExist(sysvar(2) + (anim % 10))
sysvar(2) = anim % 10

[State 1652, 3] ;If 5090 doesn't exist, default to 5030
type = VarSet
trigger1 = time = 0
trigger1 = sysvar(2) = 5090
trigger1 = !SelfAnimExist(5090)
sysvar(2) = 5030

[State 1652, 3] ;Freeze
type = ChangeAnim
trigger1 = 1
value = sysvar(2)

[State 1652, 4]
type = ChangeState
trigger1 = HitShakeOver
value = 1653 ;HITL_SLIDE

;EX Imashime no Bohi - HITL_SLIDE
[Statedef 1653]
type = L
movetype = H
physics = C

[State 2953, 1] ;Don't show hit ground frame
type = VarSet
trigger1 = Time = 0
sysvar(0) = 1

[State 2953, 2] ;In case attacked doesn't finish
type = SelfState
trigger1 = Time = 20
value = 5110

;EX Imashime no Bohi - HITL_SHAKE Second Time
[Statedef 1654]
type = L
movetype = H
physics = N
velset = 0,0

[State 1654, 1] ;Set default anim
type = VarSet
trigger1 = time = 0
sysvar(2) = ifelse (GetHitVar(yvel) = 0, 5080, 5090)

[State 1654, 2]
type = VarAdd
trigger1 = time = 0
trigger1 = (anim = [5081,5089]) || (anim = [5111,5119])
trigger1 = SelfAnimExist(sysvar(2) + (anim % 10))
sysvar(2) = anim % 10

[State 1654, 3] ;If 5090 doesn't exist, default to 5030
type = VarSet
trigger1 = time = 0
trigger1 = sysvar(2) = 5090
trigger1 = !SelfAnimExist(5090)
sysvar(2) = 5030

[State 1654, 3] ;Freeze
type = ChangeAnim
trigger1 = 1
value = sysvar(2)

[State 1654, Custom 1] ;Simulate HitShake
type = Offset
trigger1 = Time % 4 = [0,1]
x = 0

[State 1654, Custom 2] ;Simulate HitShake
type = Offset
trigger1 = Time % 4 = [2,3]
x = -2

[State 1654, 4]
type = ChangeState
trigger1 = Time = 9 ;HitShakeOver
value = 1653 ;HITL_SLIDE

;EX Imashime no Bohi - HITL_SLIDE - End
[Statedef 1655]
type = L
movetype = H
physics = C

[State 1655, 1]
type = SelfState
trigger1 = 1
value = 5110 ;HIT_LIEDOWN

;========================<PUNCH ZERO COUNTER>=============================
[StateDef 2900]
type = S
physics = N
moveType = A
anim = 2900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2900, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2900, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, 2
channel = 0

[State 2900, Woosh]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,2
channel = 1

[State 2900, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = Time = 0
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 62 < 7, 7, fvar(11) * 62)), 0
getpower = 0,0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 175), var(36) := -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2900, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 2900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<KICK ZERO COUNTER>=============================
[StateDef 2910]
type = S
physics = N
moveType = A
anim = 2910
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2910, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2910, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, 2
channel = 0

[State 2910, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,5
channel = 1

[State 2910, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 5
attr = C, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 62 < 7, 7, fvar(11) * 62)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 196), var(36) := -10
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2910, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(8) >= 0
moveType = I

[State 2910, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
