; _________________________________________
;| Anakaris by varo_hades                  |
; �����������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<SHINJITSU NO OSHIE>=============================
[StateDef 3000]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(18 * const(size.xScale)), ceil(-60 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = AnimElem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3000, 2] ;Front Layer
type = Explod
trigger1 = Time = 0
anim = 3020
bindtime = -1
sprpriority = 3
shadow = 255,255,255
removeongethit = 1

[State 3000, 3] ;Khybit Layer
type = Explod
trigger1 = Time = 0
anim = 3010
bindtime = -1
sprpriority = 3
shadow = 255,255,255
removeongethit = 1

[State 3000, 4] ;Khybit Layer 2
type = Explod
trigger1 = Time = 45
anim = 3011
pos = 79,-23
bindtime = -1
sprpriority = 3
shadow = 255,255,255
removeongethit = 1

[State 3000, 5] ;Khybit Layer 3
type = Explod
trigger1 = Time = 59
anim = 3012
pos = 79,-23
removetime = 80
vel = 0,-4
sprpriority = 3

[State 3000, 7] ;Projectile
type = Helper
trigger1 = AnimElem = 3
name = "Royal Judgement"
ID = 3030
stateno = 3030
pos = 0,0
ownpal = 1

[State 3000, 8] ;Set win type to ES
type = VarSet
triggerall = numtarget != 0
triggerall = target, Life = 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life = 0
trigger2 = enemynear(1), life = 0
v = 5
value = 1
persistent = 0

[State 3000, 9]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Royal Judgement - Projectile Helper
[Statedef 3030]
type = A
movetype = A
ctrl = 0
juggle = 3
anim = 3030
sprpriority = -1

[State 3030, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3030, 1]
type = HitDef
trigger1 = Time = 0
attr = A, SP
hitflag = MA-
guardflag = MA
priority = 1, Miss
damage = ceil(ifElse(fvar(11) * 250 < 7, 7, fvar(11) * 250)), 7
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 3015
p2stateno = 1220
numhits = 0
getpower = 0

[State 3030, 2] ;Transformed Time Left
type = VarSet
trigger1 = Time = 0
v = 1
value = 49 + 10

[State 3030, 3] ;Miss
type = DestroySelf
trigger1 = Time = 1
trigger2 = MoveGuarded

;Ouke no Sabaki - Helper - Determine Animation
[Statedef 3015]
type = A
movetype = A

[State 3015, Default]
type = VarSet
trigger1 = 1
v = 40     ;Character animation
value = 0 ;Default animation

[State 3015, Anakaris]
type = VarSet
trigger1 = target, name = "Anakaris"
trigger2 = target, name = "Anakaris By Third"
trigger3 = target, name = "cvsanakaris"
v = 40
value = 1

[State 3015, Morrigan]
type = VarSet
trigger1 = target, name = "Morrigan"
trigger2 = target, name = "Morrigan Aensland"
trigger3 = target, name = "cvsmorrigan"
trigger4 = target, name = "Ultimate Morrigan"
v = 40
value = -1

[State 3015, Demitri]
type = VarSet
trigger1 = target, name = "Demitri"
trigger2 = target, name = "Demitri Maximoff"
trigger3 = target, name = "Demitri(DS)"
trigger4 = target, name = "Demitri-Ex"
trigger5 = target, name = "cvsdemitri"
v = 40
value = -2

[State 3015, Pyron]
type = VarSet
trigger1 = target, name = "Pyron"
trigger2 = target, name = "cvspyron"
v = 40
value = -3

[State 3015, Lilith]
type = VarSet
trigger1 = target, name = "Lilith"
trigger2 = target, name = "cvslilith"
v = 40
value = -4

[State 3015, Q-Bee]
type = VarSet
trigger1 = target, name = "Q-Bee"
trigger2 = target, name = "QBee"
trigger3 = target, name = "Q Bee"
trigger4 = target, name = "cvsqbee"
trigger5 = target, name = "Queen Bee"
v = 40
value = -5

[State 3015, Jedah]
type = VarSet
trigger1 = target, name = "Jedah"
trigger2 = target, name = "cvsjedah"
v = 40
value = -6

[State 3015, Vega]
type = VarSet
trigger1 = target, name = "Vega"
trigger2 = target, name = "M. Bison"
trigger3 = target, name = "M.Bison"
trigger4 = target, name = "MBison"
trigger5 = target, name = "[Necromancer's] M. Bison"
trigger6 = target, name = "cvsvega"
trigger7 = target, name = "cvsmbison"
v = 40
value = -7

[State 3015, Kenji]
type = VarSet
trigger1 = target, name = "Kenji"
trigger2 = target, name = "cvskenji"
v = 40
value = -8

[State 3015, Gallon]
type = VarSet
trigger1 = target, name = "Gallon"
trigger2 = target, name = "Jon Talbain"
trigger3 = target, name = "Talbain"
trigger4 = target, name = "J. Talbain"
trigger5 = target, name = "cvsgallon"
trigger6 = target, name = "cvstalbain"
trigger7 = target, name = "cvsjtalbain"
trigger8 = target, name = "John Talbain"
v = 40
value = 2

[State 3015, Zabel]
type = VarSet
trigger1 = target, name = "Zabel"
trigger2 = target, name = "Zabel Zarock"
trigger3 = target, name = "Lord Raptor"
trigger4 = target, name = "cvsraptor"
trigger5 = target, name = "cvszabel"
v = 40
value = 3

[State 3015, Felicia]
type = VarSet
trigger1 = target, name = "Felicia"
trigger2 = target, name = "Felicia MvC2 Style by MGBenz"
trigger3 = target, name = "cvsfelicia"
v = 40
value = 4

[State 3015, Bishamon]
type = VarSet
trigger1 = target, name = "Bishamon"
trigger2 = target, name = "Oboro"
trigger3 = target, name = "cvsbishamon"
trigger4 = target, name = "cvsoboro"
v = 40
value = 5

[State 3015, Victor]
type = VarSet
trigger1 = target, name = "Victor"
trigger2 = target, name = "cvsvictor"
v = 40
value = 6

[State 3015, Aulbath]
type = VarSet
trigger1 = target, name = "Aulbath"
trigger2 = target, name = "Rikuo"
trigger3 = target, name = "cvsaulbath"
trigger4 = target, name = "cvsrikuo"
v = 40
value = 7

[State 3015, Sasquatch]
type = VarSet
trigger1 = target, name = "Sasquatch"
trigger2 = target, name = "cvssasquatch"
v = 40
value = 8

[State 3015, Phobos]
type = VarSet
trigger1 = target, name = "Phobos"
trigger2 = target, name = "Huitzel"
trigger3 = target, name = "Deimos"
trigger4 = target, name = "cvsphobos"
trigger5 = target, name = "cvshuitzel"
trigger6 = target, name = "cvsdeimos"
v = 40
value = 9

[State 3015, Lei-Lei]
type = VarSet
trigger1 = target, name = "Lei-Lei"
trigger2 = target, name = "Lei Lei"
trigger3 = target, name = "LeiLei"
trigger4 = target, name = "Hsien-Ko"
trigger5 = target, name = "Hsien Ko"
trigger6 = target, name = "HsienKo"
trigger7 = target, name = "cvsleilei"
trigger8 = target, name = "cvshsienko"
v = 40
value = 10

[State 3015, Donovan]
type = VarSet
trigger1 = target, name = "Donovan"
v = 40
value = 11

[State 3015, Bulleta]
type = VarSet
trigger1 = target, name = "Bulleta"
trigger2 = target, name = "B.B. Hood"
trigger3 = target, name = "BB Hood"
trigger4 = target, name = "B.B.Hood"
trigger5 = target, name = "BBHood"
trigger6 = target, name = "Baby Bonnie Hood"
trigger7 = target, name = "Bulleta SXP"
trigger8 = target, name = "cvsbulleta"
trigger9 = target, name = "cvsbbhood"
trigger10 = target, name = "B. B. Hood"
v = 40
value = 12

[State 3015, Alex]
type = VarSet
trigger1 = target, name = "Alex"
trigger2 = target, name = "cvsalex"
v = 40
value = 13

[State 3015, Yun]
type = VarSet
trigger1 = target, name = "Yun"
trigger2 = target, name = "cvsyun"
v = 40
value = 14

[State 3015, Urien]
type = VarSet
trigger1 = target, name = "Urien"
trigger2 = target, name = "cvsurien"
v = 40
value = 15

[State 3015, Ryu]
type = VarSet
trigger1 = target, name = "Ryu"
trigger2 = target, name = "Evil Ryu"
trigger3 = target, name = "Ryu Hoshi"
trigger4 = target, name = "Ryu-X"
trigger5 = target, name = "Ryu Houji"
trigger6 = target, name = "cvsryu"
trigger7 = target, name = "cvsryu_normal"
trigger8 = target, name = "ryusnk"
trigger9 = target, name = "MvC-EoH Evil Ryu"
v = 40
value = 16

[State 3015, Chun-Li]
type = VarSet
trigger1 = target, name = "Chun-Li"
trigger2 = target, name = "Chun Li"
trigger3 = target, name = "ChunLi"
trigger4 = target, name = "Dark Chun Li"
trigger5 = target, name = "cvschunli"
v = 40
value = 17

[State 3015, Guile]
type = VarSet
trigger1 = target, name = "Guile"
trigger2 = target, name = "Guile-XI"
trigger3 = target, name = "Guile-XI Remix"
trigger4 = target, name = "cvsguile"
v = 40
value = 18

[State 3015, Zangief]
type = VarSet
trigger1 = target, name = "Zangief"
trigger2 = target, name = "cvszangief"
trigger3 = target, name = "Mecha Zangief"
trigger4 = target, name = "Mecha-Zangief"
trigger5 = target, name = "MechaZangief"
v = 40
value = 19

[State 3015, Sakura]
type = VarSet
trigger1 = target, name = "Sakura"
trigger2 = target, name = "Sakura Kasugano"
trigger3 = target, name = "cvssakura"
v = 40
value = 20

[State 3015, Gouki]
type = VarSet
trigger1 = target, name = "Gouki"
trigger2 = target, name = "Akuma"
trigger3 = target, name = "Shin Gouki"
trigger4 = target, name = "Shin Akuma"
trigger5 = target, name = "ShinGouki"
trigger6 = target, name = "ShinAkuma"
trigger7 = target, name = "Pocket Shin Gouki"
trigger8 = target, name = "cvsgouki"
trigger9 = target, name = "cvsakuma"
trigger10 = target, name = "Gouki by M.M.R."
trigger11 = target, name = "MvC-EoH Gouki"
v = 40
value = 21

[State 3015, Leo]
type = VarSet
trigger1 = target, name = "Leo"
trigger2 = target, name = "cvsleo"
v = 40
value = 22

[State 3015, Hauzer]
type = VarSet
trigger1 = target, name = "Hauzer"
trigger2 = target, name = "cvshauzer"
v = 40
value = 23

[State 3015, Hydron]
type = VarSet
trigger1 = target, name = "Hydron"
trigger2 = target, name = "Nool"
trigger3 = target, name = "cvshydron"
trigger4 = target, name = "cvsnool"
v = 40
value = 24

[State 3015, Guy]
type = VarSet
trigger1 = target, name = "Guy"
trigger2 = target, name = "cvsguy"
v = 40
value = 25

[State 3015, Rose]
type = VarSet
trigger1 = target, name = "Rose"
trigger2 = target, name = "cvsrose"
v = 40
value = 26

[State 3015, Karin]
type = VarSet
trigger1 = target, name = "Karin"
trigger2 = target, name = "Karin Kanzuki"
trigger3 = target, name = "cvskarin"
v = 40
value = 27

[State 3015, Ingrid]
type = VarSet
trigger1 = target, name = "Ingrid"
trigger2 = target, name = "Ingrid SXP"
trigger3 = target, name = "cvsingrid"
v = 40
value = 28

[State 3015, Super Mario]
type = VarSet
trigger1 = target, name = "Super Mario"
trigger2 = target, name = "Mario"
trigger3 = target, name = "SuperMario"
v = 40
value = 29

[State 3015, Super Luigi]
type = VarSet
trigger1 = target, name = "Super Luigi"
trigger2 = target, name = "Luigi"
trigger3 = target, name = "SuperLuigi"
v = 40
value = 30

[State 3015, Megaman]
type = VarSet
trigger1 = target, name = "Megaman"
trigger2 = target, name = "Rockman"
trigger3 = target, name = "Megaman Plus"
v = 40
value = 31

[State 3015, End State]
type = ChangeState
trigger1 = 1
value = 1212

;========================<MAX SHINJITSU NO OSHIE>=============================
[StateDef 3050]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3050, SuperPause FX]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(18 * const(size.xScale)), ceil(-60 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3050, SuperPause]
type = SuperPause
trigger1 = AnimElem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3050, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3050, 2] ;Front Layer
type = Explod
trigger1 = Time = 0
anim = 3020
bindtime = -1
sprpriority = 3
shadow = 255,255,255
removeongethit = 1

[State 3050, 3] ;Khybit Layer
type = Explod
trigger1 = Time = 0
anim = 3010
bindtime = -1
sprpriority = 3
shadow = 255,255,255
removeongethit = 1

[State 3050, 4] ;Khybit Layer 2
type = Explod
trigger1 = Time = 45
anim = 3011
pos = 79,-23
bindtime = -1
sprpriority = 3
shadow = 255,255,255
removeongethit = 1

[State 3050, 5] ;Khybit Layer 3
type = Explod
trigger1 = Time = 59
anim = 3012
pos = 79,-23
removetime = 80
vel = 0,-4
sprpriority = 3

[State 3050, 7] ;Projectile
type = Helper
trigger1 = AnimElem = 3
name = "Royal Judgement"
ID = 3080
stateno = 3080
pos = 0,0
ownpal = 1

[State 3050, 8] ;Set win type to ES
type = VarSet
triggerall = numtarget != 0
triggerall = target, Life = 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life = 0
trigger2 = enemynear(1), life = 0
v = 5
value = 1
persistent = 0

[State 3050, 9]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Royal Judgement - Projectile Helper
[Statedef 3080]
type = A
movetype = A
ctrl = 0
juggle = 3
anim = 3030
sprpriority = -1

[State 3080, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3080, 1]
type = HitDef
trigger1 = Time = 0
attr = A, SP
hitflag = MA-
guardflag = MA
priority = 1, Miss
damage = ceil(ifElse(fvar(11) * 350 < 7, 7, fvar(11) * 350)), 7
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 3015
p2stateno = 1220
numhits = 0
getpower = 0

[State 3080, 2] ;Transformed Time Left
type = VarSet
trigger1 = Time = 0
v = 1
value = 49 + 10

[State 3080, 3] ;Miss
type = DestroySelf
trigger1 = Time = 1
trigger2 = MoveGuarded

;========================<NARAKU NO ANA>=============================
[StateDef 3100]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 3100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(6) < 0
time = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(15 * const(size.xScale)), ceil(-91 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = AnimElem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 3100,0
channel = 0

[State 3100, 2] ;Extra Animation Appear
type = Explod
trigger1 = Time = 0
anim = 3101
bindtime = -1
sprpriority = 3
removeongethit = 1

[State 3100, 3] ;Overhead Base
type = Explod
trigger1 = AnimElem = 6
ID = 3102
anim = 3102
bindtime = -1
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3100, 4] ;Pit Helper
type = Helper
trigger1 = var(10) = 0
trigger1 = AnimElem = 6
name = "Pit to the Underworld"
ID = 3110
stateno = 3110
pos = 130, -6

[State 3100, 4] ;Pit Helper
type = Helper
trigger1 = var(10) = 1
trigger1 = AnimElem = 6
name = "Pit to the Underworld"
ID = 3110
stateno = 3110
pos = 200, -6

[State 3100, 4] ;Pit Helper
type = Helper
trigger1 = var(10) = 2
trigger1 = AnimElem = 6
name = "Pit to the Underworld"
ID = 3110
stateno = 3110
pos = 270, -6

[State 3100, 5] ;Overhead Base
type = RemoveExplod
trigger1 = AnimElemTime(6) = 52
ID = 3102

[State 3100, 6] ;Overhead Base Disappear
type = Explod
trigger1 = AnimElemTime(6) = 52
ID = 3102
anim = 3103
bindtime = -1
sprpriority = 1
removeongethit = 1

[State 3100, 7] ;Miss
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

[State 3100, 8] ;Hit
type = ChangeState
trigger1 = numhelper(3110) != 0
trigger1 = helper(3110), MoveHit = 1
value = 3101

;Pit to the Underworld - Hit Successful
[Statedef 3101]
type = S
movetype = A
physics = S
anim = 3104
sprpriority = 2

[State 3101, 1]
type = ChangeAnim
trigger1 = numhelper(3110) != 0
trigger1 = helper(3110), stateno = 3113
trigger1 = helper(3110), time = 2
value = 3105

[State 3101, Impact Dust]
type = Helper
trigger1 = Time = 120
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P2
pos = 0,0
facing = -1
ownPal = 1

[State 3101, 2] ;Overhead Base
type = RemoveExplod
trigger1 = Anim = 3105
trigger1 = AnimElem = 1
ID = 3102

[State 3101, 3] ;Overhead Base Disappear
type = Explod
trigger1 = Anim = 3105
trigger1 = AnimElem = 1
ID = 3102
anim = 3106
bindtime = -1
sprpriority = 1
removeongethit = 1

[State 3101, 4] ;Extra Frames Spark
type = Explod
trigger1 = Anim = 3105
trigger1 = AnimElem = 7
ID = 3102
anim = 3107
bindtime = -1
removetime = -1
sprpriority = 3
removeongethit = 1

[State 3101, 5] ;Remove Extra Frames Spark
type = RemoveExplod
trigger1 = Time = 150
ID = 3102

[State 3101, 6]
type = ChangeState
trigger1 = Time = 150
value = 0
ctrl = 1

;Pit to the Underworld - Pit Helper
[Statedef 3110]
type = S
movetype = A
physics = N
juggle = 4
ctrl = 0
velset = 0,0
anim = 3110
sprpriority = -2

[State 3110, 1] ;Place at absolute bottom of screen
type = PosAdd
trigger1 = Time = 0
trigger1 = 239-ScreenPos Y-29 = [0,10]
y = (239-ScreenPos Y)-29

[State 3110, 2] ;Glow
type = Explod
trigger1 = AnimElem = 9
ID = 3120
anim = 3120
bindtime = -1
sprpriority = -1
ownpal = 1

[State 3110, 3]
type = HitDef
Trigger1 = Time = 0
attr = S, HT
hitflag = MA-
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1facing = 1
p2facing = 1
p1stateno = 3111
p2stateno = 3160
guard.dist = 0
fall = 1
fall.yvelocity = -7
fall.damage = 240
fall.envshake.time = 16
fall.envshake.ampl = 5
fall.envshake.freq = 120
getpower = 0

[State 3110, 4] ;Glow Miss
type = Explod
trigger1 = AnimElem = 10
ID = 3120
anim = 3124
bindtime = -1
sprpriority = -1
ownpal = 1

[State 3110, 5] ;Parent get hit
type = ChangeState
trigger1 = parent, stateno != 3100
value = 3114

[State 3110, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3110, 7]
type = DestroySelf
trigger1 = AnimTime = 0

;Pit to the Underworld - Pit Helper - Hit Successful
[Statedef 3111]
type = S
movetype = A
physics = N
anim = 3111
sprpriority = -2

[State 3111, 1] ;Remove Glow
type = RemoveExplod
trigger1 = Time = 0
ID = 3120

[State 3111, 2] ;New Glow
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3121
bindtime = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3111, 2] ;Extra Frames
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3121
bindtime = -1
removetime = -1
sprpriority = -1

[State 3111, 3] ;Hit sound
type = PlaySnd
trigger1 = Time = 2
value = 3100,1

[State 3111, 4] ;Bind X > and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X > 1
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = (target, Pos X - Pos X - 1)*facing, target, Pos Y - Pos Y - 2

[State 3111, 5] ;Bind X > and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X > 1
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = (target, Pos X - Pos X - 1)*facing, -110

[State 3111, 6] ;Bind X < and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X < -1
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = (target, Pos X - Pos X + 1)*facing, target, Pos Y - Pos Y - 2

[State 3111, 7] ;Bind X < and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X < -1
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = (target, Pos X - Pos X + 1)*facing, -110

[State 3111, 8] ;Bind X = and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X = [-1, 1]
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = 0, target, Pos Y - Pos Y - 2

[State 3111, 9] ;Bind X = and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X = [-1, 1]
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = 0, -110

[State 3111, 10] ;Bind X too far away
type = TargetBind
trigger1 = target, Pos X - Pos X > 56
pos = 56*facing, target, Pos Y - Pos Y - 2

[State 3111, 11] ;Bind X too far away
type = TargetBind
trigger1 = target, Pos X - Pos X < -56
pos = -56*facing, target, Pos Y - Pos Y - 2

[State 3111, 12]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3111, 13] ;Remove Glow
type = RemoveExplod
trigger1 = AnimTime = 0
ID = 3120

[State 3111, 14]
type = ChangeState
trigger1 = AnimTime = 0
value = 3112

;Pit to the Underworld - Pit Helper - Hit Successful - Open Up
[Statedef 3112]
type = S
movetype = A
physics = N
anim = 3112
sprpriority = -2

[State 3112, 1] ;Glow
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3122
bindtime = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3112, 2] ;Extra Layer Frames
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3114
bindtime = -1
removetime = -1
sprpriority = 3

[State 3112, 3]
type = TargetState
trigger1 = Time = 0
trigger1 = ScreenPos Y >= (239 - 29)
value = 3164

[State 3112, 4]
type = TargetState
trigger1 = Time = 0
trigger1 = ScreenPos Y < (239 - 29)
value = 3161

[State 3112, 5]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3112, 6] ;Remove Glow
type = RemoveExplod
trigger1 = target, stateno != 3161
trigger1 = target, stateno != 3164
ID = 3120

[State 3112, 7]
type = ChangeState
trigger1 = target, stateno != 3161
trigger1 = target, stateno != 3164
value = 3113

;Pit to the Underworld - Pit Helper - Hit Successful - Close
[Statedef 3113]
type = S
movetype = A
physics = N
anim = 3113
sprpriority = -2

[State 3113, 1] ;Remove Extra Layer Frames
type = RemoveExplod
trigger1 = Time = 0
ID = 3120

[State 3113, 2] ;Extra Layer Frames
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3115
bindtime = -1
sprpriority = 3

[State 3112, 3] ;Glow
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3123
bindtime = -1
sprpriority = -1
ownpal = 1

[State 3113, 4]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3113, 5] ;Crash sound
type = PlaySnd
trigger1 = target, stateno = 3163
value = 1100, 1

[State 3113, 6]
type = ChangeState
trigger1 = target, stateno = 3163
value = 3115

;Pit to the Underworld - Miss
[Statedef 3114]
type = S
movetype = I
physics = N
sprpriority = -2

[State 3114, 1] ;Remove Glow
type = RemoveExplod
trigger1 = Time = 0
ID = 3120

[State 3114, 2] ;Go to miss
type = ChangeAnim
trigger1 = parent, stateno != 3100
trigger1 = AnimElemTime(10) < 0
value = anim
elem = 10

[State 3114, 3] ;Glow Miss
type = Explod
trigger1 = AnimElem = 10
ID = 3120
anim = 3124
bindtime = -1
sprpriority = -1
ownpal = 1

[State 3114, 4]
type = DestroySelf
trigger1 = AnimTime = 0

;Pit to the Underworld - Pit Helper - Close Waiting
[Statedef 3115]
type = S
movetype = A
physics = N
anim = 3116

[State 3115, 1] ;Set win type to ES
type = ParentVarSet
triggerall = numtarget != 0
triggerall = target, Life = 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life = 0
trigger2 = enemynear(1), life = 0
v = 5
value = 1
persistent = 0

[State 3115, 2]
type = DestroySelf
trigger1 = target, stateno != 3163

;Pit to the Underworld - Get Hit
[Statedef 3160]
type = A
movetype = H
physics = N
sprpriority = 0

[State 3160, 1]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 3160, 2]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(7008) = 0
value = 3150

[State 3160, 2b]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(7008) = 1
value = 7008

[State 3160, 3]
type = SelfState
trigger1 = !gethitvar(isbound)
value = 5050

;Pit to the Underworld - Falling
[Statedef 3161]
type = A
movetype = H
physics = N

[State 3161, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5070

[State 3161, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 3161, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 3161, 4]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3161, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 3161, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3161, 7]
type = ChangeState
trigger1 = Pos Y >= 30
value = 3162

;Pit to the Underworld - Falling Second Time
[Statedef 3162]
type = A
movetype = H
physics = N
velset = 0,4

[State 3162, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(5060) = 1
value = 5060

[State 3162, 2]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(5060) = 0
value = 3152

[State 3162, 3]
type = PosSet
trigger1 = Time = 0
y = -300

[State 3162, 4] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 3162, 5]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 3162, 6]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3162, 7]
type = PlayerPush
trigger1 = 1
value = 0

[State 3162, 8]
type = ChangeState
trigger1 = Pos Y >= 0
value = 3163

;Pit to the Underworld - HIT_BOUNCE (hit ground)
[Statedef 3163]
type = L
movetype = H
physics = N

[State 3163, 1]
type = VelSet
trigger1 = Time = 0
trigger1 = GetHitVar(fall.yvel) = 0
trigger1 = vel x > 1
x = 1

[State 3163, EnvShake]
type = FallEnvShake
trigger1 = Time = 0

[State 3163, Var] ;Save fall velocity
type = VarSet
trigger1 = Time = 0
;trigger1 = GetHitVar(fall.yvel)	 = 0
sysvar(1) = floor(vel y)

[State 3163, 2] ;Hit ground anim (normal)
type = ChangeAnim
triggerall = time = 0
trigger1 = !SelfAnimExist(5101)
value = 5100

[State 3163, 3] ;Hit ground anim (for hit up)
type = ChangeAnim
trigger1 = time = 0
trigger1 = SelfAnimExist(5101)
value = 5101

[State 3163, 4]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3163, 5]
type = VelSet
trigger1 = Time = 0
y = 0

[State 3163, 6] ;Reduce speed
type = VelMul
trigger1 = Time = 0
x = 0.75

[State 3163, 7]
type = SelfState
trigger1 = Time = 0
trigger1 = GetHitVar(fall.yvel) = 0
value = 5110 ;HIT_LIEDOWN

[State 3163, 9]
type = HitFallDamage
trigger1 = Time = 3

[State 3163, 11]
type = PosFreeze
trigger1 = 1

[State 3163, 12] ;Freeze last frame of animation
type = ChangeAnim
trigger1 = AnimTime = 0
value = Anim
elem = AnimElemNo(-1)

[State 3163, 12]
type = VelSet
trigger1 = Time = 10
x = -2

[State 3163, 13]
type = ChangeState
trigger1 = Time = 10
value = 1024

[State 3163, 14]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3163, 15]
type = ForceFeedback
trigger1 = Time = 0
waveform = sinesquare
ampl = 128,-3,-.2,.005
time = 20

;Pit to the Underworld - Falling - Pit near bottom of screen
[Statedef 3164]
type = A
movetype = H
physics = N

[State 3164, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5070

[State 3164, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 3164, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 3164, 4]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3164, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 3164, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3164, 7]
type = ChangeState
trigger1 = Pos Y >= 120
value = 3162

;========================<MAX NARAKU NO ANA>=============================
[StateDef 3150]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3150, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" && command = "b"), 0, ifElse((command = "a" && command = "c"), 1, 2))

[State 3150, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 3150, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(6) < 0
time = 1
value = SCA

[State 3150, Super Pause FX]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(15 * const(size.xScale)), ceil(-91 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3150, SuperPause]
type = SuperPause
trigger1 = AnimElem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3150, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 3100,0
channel = 0

[State 3150, 2] ;Extra Animation Appear
type = Explod
trigger1 = Time = 0
anim = 3101
bindtime = -1
sprpriority = 3
removeongethit = 1

[State 3150, 3] ;Overhead Base
type = Explod
trigger1 = AnimElem = 6
ID = 3102
anim = 3102
bindtime = -1
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3150, 4] ;Pit Helper
type = Helper
trigger1 = var(10) = 0
trigger1 = AnimElem = 6
name = "Pit to the Underworld"
ID = 3170
stateno = 3170
pos = 130, -6

[State 3150, 4] ;Pit Helper
type = Helper
trigger1 = var(10) = 1
trigger1 = AnimElem = 6
name = "Pit to the Underworld"
ID = 3170
stateno = 3170
pos = 200, -6

[State 3150, 4] ;Pit Helper
type = Helper
trigger1 = var(10) = 2
trigger1 = AnimElem = 6
name = "Pit to the Underworld"
ID = 3170
stateno = 3170
pos = 270, -6

[State 3150, 5] ;Overhead Base
type = RemoveExplod
trigger1 = AnimElemTime(6) = 52
ID = 3102

[State 3150, 6] ;Overhead Base Disappear
type = Explod
trigger1 = AnimElemTime(6) = 52
ID = 3102
anim = 3103
bindtime = -1
sprpriority = 1
removeongethit = 1

[State 3150, 7] ;Miss
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

[State 3150, 8] ;Hit
type = ChangeState
trigger1 = numhelper(3170) != 0
trigger1 = helper(3170), MoveHit = 1
value = 3151

;Pit to the Underworld - Hit Successful
[Statedef 3151]
type = S
movetype = A
physics = S
anim = 3104
sprpriority = 2

[State 3151, 1]
type = ChangeState
trigger1 = numhelper(3170) != 0
trigger1 = helper(3170), stateno = 3173
trigger1 = helper(3170), time = 2
value = 3181

[State 3151, 2] ;Overhead Base
type = RemoveExplod
trigger1 = Anim = 3105
trigger1 = AnimElem = 1
ID = 3102

[State 3151, Impact Dust]
type = Helper
trigger1 = Time = 120
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P2
pos = 0,0
facing = -1
ownPal = 1

[State 3151, 3] ;Overhead Base Disappear
type = Explod
trigger1 = Anim = 3105
trigger1 = AnimElem = 1
ID = 3102
anim = 3106
bindtime = -1
sprpriority = 1
removeongethit = 1

[State 3151, 4] ;Extra Frames Spark
type = Explod
trigger1 = Anim = 3105
trigger1 = AnimElem = 7
ID = 3102
anim = 3107
bindtime = -1
removetime = -1
sprpriority = 3
removeongethit = 1

[State 3151, 5] ;Remove Extra Frames Spark
type = RemoveExplod
trigger1 = Time = 150
ID = 3102

[State 3151, 6]
type = ChangeState
trigger1 = Time = 150
value = 0
ctrl = 1

;Pit to the Underworld - Pit Helper
[Statedef 3170]
type = S
movetype = A
physics = N
juggle = 4
ctrl = 0
velset = 0,0
anim = 3110
sprpriority = -2

[State 3170, 1] ;Place at absolute bottom of screen
type = PosAdd
trigger1 = Time = 0
trigger1 = 239-ScreenPos Y-29 = [0,10]
y = (239-ScreenPos Y)-29

[State 3170, 2] ;Glow
type = Explod
trigger1 = AnimElem = 9
ID = 3120
anim = 3120
bindtime = -1
sprpriority = -1
ownpal = 1

[State 3170, 3]
type = HitDef
Trigger1 = Time = 0
attr = S, HT
hitflag = MA-
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1facing = 1
p2facing = 1
p1stateno = 3171
p2stateno = 3160
guard.dist = 0
fall = 1
fall.yvelocity = -7
fall.damage = 85
fall.envshake.time = 16
fall.envshake.ampl = 5
fall.envshake.freq = 120
getpower = 0

[State 3170, 4] ;Glow Miss
type = Explod
trigger1 = AnimElem = 10
ID = 3120
anim = 3124
bindtime = -1
sprpriority = -1
ownpal = 1

[State 3170, 5] ;Parent get hit
type = ChangeState
trigger1 = parent, stateno != 3150
value = 3174

[State 3170, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3170, 7]
type = DestroySelf
trigger1 = AnimTime = 0

;Pit to the Underworld - Pit Helper - Hit Successful
[Statedef 3171]
type = S
movetype = A
physics = N
anim = 3111
sprpriority = -2

[State 3171, 1] ;Remove Glow
type = RemoveExplod
trigger1 = Time = 0
ID = 3120

[State 3171, 2] ;New Glow
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3121
bindtime = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3171, 2] ;Extra Frames
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3121
bindtime = -1
removetime = -1
sprpriority = -1

[State 3171, 3] ;Hit sound
type = PlaySnd
trigger1 = Time = 2
value = 3100,1

[State 3171, 4] ;Bind X > and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X > 1
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = (target, Pos X - Pos X - 1)*facing, target, Pos Y - Pos Y - 2

[State 3171, 5] ;Bind X > and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X > 1
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = (target, Pos X - Pos X - 1)*facing, -110

[State 3171, 6] ;Bind X < and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X < -1
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = (target, Pos X - Pos X + 1)*facing, target, Pos Y - Pos Y - 2

[State 3171, 7] ;Bind X < and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X < -1
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = (target, Pos X - Pos X + 1)*facing, -110

[State 3171, 8] ;Bind X = and Y >
type = TargetBind
trigger1 = target, Pos X - Pos X = [-1, 1]
trigger1 = target, Pos Y - Pos Y > -110 - 2
pos = 0, target, Pos Y - Pos Y - 2

[State 3171, 9] ;Bind X = and Y <=
type = TargetBind
trigger1 = target, Pos X - Pos X = [-1, 1]
trigger1 = target, Pos Y - Pos Y <= -110 - 2
pos = 0, -110

[State 3171, 10] ;Bind X too far away
type = TargetBind
trigger1 = target, Pos X - Pos X > 56
pos = 56*facing, target, Pos Y - Pos Y - 2

[State 3171, 11] ;Bind X too far away
type = TargetBind
trigger1 = target, Pos X - Pos X < -56
pos = -56*facing, target, Pos Y - Pos Y - 2

[State 3171, 12]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3171, 13] ;Remove Glow
type = RemoveExplod
trigger1 = AnimTime = 0
ID = 3120

[State 3171, 14]
type = ChangeState
trigger1 = AnimTime = 0
value = 3172

;Pit to the Underworld - Pit Helper - Hit Successful - Open Up
[Statedef 3172]
type = S
movetype = A
physics = N
anim = 3112
sprpriority = -2

[State 3172, 1] ;Glow
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3122
bindtime = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3172, 2] ;Extra Layer Frames
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3114
bindtime = -1
removetime = -1
sprpriority = 3

[State 3172, 3]
type = TargetState
trigger1 = Time = 0
trigger1 = ScreenPos Y >= (239 - 29)
value = 3164

[State 3172, 4]
type = TargetState
trigger1 = Time = 0
trigger1 = ScreenPos Y < (239 - 29)
value = 3191

[State 3172, 5]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3172, 6] ;Remove Glow
type = RemoveExplod
trigger1 = target, stateno != 3191
trigger1 = target, stateno != 3164
ID = 3120

[State 3172, 7]
type = ChangeState
trigger1 = target, stateno != 3191
trigger1 = target, stateno != 3164
value = 3173

;Pit to the Underworld - Pit Helper - Hit Successful - Close
[Statedef 3173]
type = S
movetype = A
physics = N
anim = 3113
sprpriority = -2

[State 3173, 1] ;Remove Extra Layer Frames
type = RemoveExplod
trigger1 = Time = 0
ID = 3120

[State 3173, 2] ;Extra Layer Frames
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3115
bindtime = -1
sprpriority = 3

[State 3172, 3] ;Glow
type = Explod
trigger1 = Time = 0
ID = 3120
anim = 3123
bindtime = -1
sprpriority = -1
ownpal = 1

[State 3173, 4]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3173, 5] ;Crash sound
type = PlaySnd
trigger1 = target, stateno = 1053
value = 1100, 1

[State 3173, 6]
type = ChangeState
trigger1 = target, stateno = 1053
value = 3175

;Pit to the Underworld - Miss
[Statedef 3174]
type = S
movetype = I
physics = N
sprpriority = -2

[State 3174, 1] ;Remove Glow
type = RemoveExplod
trigger1 = Time = 0
ID = 3120

[State 3174, 2] ;Go to miss
type = ChangeAnim
trigger1 = parent, stateno != 3150
trigger1 = AnimElemTime(10) < 0
value = anim
elem = 10

[State 3174, 3] ;Glow Miss
type = Explod
trigger1 = AnimElem = 10
ID = 3120
anim = 3124
bindtime = -1
sprpriority = -1
ownpal = 1

[State 3174, 4]
type = DestroySelf
trigger1 = AnimTime = 0

;Pit to the Underworld - Pit Helper - Close Waiting
[Statedef 3175]
type = S
movetype = A
physics = N
anim = 3116

[State 3175, 1] ;Set win type to ES
type = ParentVarSet
triggerall = numtarget != 0
triggerall = target, Life = 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life = 0
trigger2 = enemynear(1), life = 0
v = 5
value = 1
persistent = 0

[State 3175, 2]
type = DestroySelf
trigger1 = target, stateno != 3163

;EX Miira Drop - Grab Successful, Waiting
[Statedef 3181]
type = S
movetype = A
physics = S
velset = 0,0
sprpriority = 2

[State 3181, 2] ;Overhead Base
type = RemoveExplod
trigger1 = 1
ID = 3102

[State 3181, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3181, 2] ;End hands sound
type = StopSnd
trigger1 = Time = 0
channel = 0

[State 3181, 3] ;Hit
type = ChangeState
trigger1 = helper(3170), ParentDist X > -40
trigger2 = helper(3170), stateno = 3173
value = 3182

;EX Miira Drop - Throwing
[Statedef 3182]
type = S
movetype = A
physics = N
anim = 3160
sprpriority = 0

[State 1043, Crash TargetLifeAdd] ;Crash Sound
type = TargetLifeAdd
trigerall = Anim = 3160
trigger1 = AnimElem = 5, = 1
trigger2 = AnimElem = 11, = 1
trigger3 = AnimElem = 17, = 1
value = -35
kill = 0

[State 3182, Crash Sound] ;Crash Sound
type = PlaySnd
trigger1 = AnimElem = 5, = 1
trigger2 = AnimElem = 11, = 1
trigger3 = AnimElem = 17, = 1
value = 1100, 1

[State 3182, SprPriority 1]
type = SprPriority
trigger1 = AnimElem = 24
value = -1

[State 3182, Explod 1] ;Khybit
type = Explod
trigger1 = AnimElem = 24
anim = 1033
bindtime = -1
sprpriority = 0
shadow = 255,255,255
ownpal = 1

[State 3182, Twang Sound] ;Kick Out Twang Sound
type = PlaySnd
trigger1 = AnimElem = 25
value = 1030, 1

[State 1043, Bind 1]
type = TargetBind
trigger1 = Anim = 3160
trigger1 = AnimElemTime(25) < 0
pos = 0, 0

[State 1043, Bind 2]
type = TargetBind
trigger1 = Anim = 3160
trigger1 = AnimElemTime(25) = 0
pos = 80,0

[State 1043, 3]
type = TargetState
trigger1 = Anim = 3160
trigger1 = AnimElem = 25
value = 1053

[State 3182, Special Khybit] ;Special Khybit
type = Helper
triggerall = AnimElem = 25
trigger1 = command = "holdstart"
trigger2 = Random < 50
pos = 0,-43
stateno = 1060

[State 3182, Kick Out Sound] ;Kick Out Crash Sound
type = PlaySnd
trigger1 = AnimElem = 25
value = 1100, 2

[State 3182, Explod 2] ;Foot
type = Explod
trigger1 = AnimElem = 25
anim = 1032
bindtime = -1
removetime = 30
sprpriority = 1
shadow = 255,255,255

[State 3182, State End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Pit to the Underworld - Falling
[Statedef 3191]
type = A
movetype = H
physics = N

[State 3191, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5070

[State 3191, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 3191, 3]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 3191, 4]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3191, 5]
type = PlayerPush
trigger1 = 1
value = 0

[State 3191, 6]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3191, 7]
type = ChangeState
trigger1 = Pos Y >= 30
value = 3192

;Pit to the Underworld - Falling Second Time
[Statedef 3192]
type = A
movetype = H
physics = N
velset = 0,0

[State 1043, Crash TargetLifeAdd] ;Crash Sound
type = LifeAdd
trigger1 = Time = 28
trigger2 = Time = 50
trigger3 = Time = 72
value = -85
kill = 0

[State 3192, 2]
type = ChangeAnim2
trigger1 = Time = 0
value = 1022

[State 1043, 1]
type = posset
trigger1 = 1
x = -10
y = 10

[State 3192, 5]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,0

[State 3192, 6]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3192, 7]
type = PlayerPush
trigger1 = 1
value = 0

[State 3192, 8]
type = changestate
trigger1 = Time = 100
value = 1053

;========================<PHARAOH SPLIT>=============================
[StateDef 3200]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3200, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(8 * const(size.xScale)), ceil(-84 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, 2] ;Voice
type = PlaySnd
trigger1 = Time = 10
value = 186,0
channel = 0

[State 3200, 3] ;Bottom Half
type = Helper
trigger1 = Time = 0
name = "Anakaris Bottom Half"
ID = 3210
stateno = 3210
pos = 0,0
ownpal = 1

[State 3200, 4] ;Time left in air
type = VarSet
trigger1 = Time = 0
v = 40
value = 500

[State 3200, 9]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3200, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 3201

;Pharaoh Split - Rise
[Statedef 3201]
type = A
movetype = A
physics = N
velset = 0,-1
anim = 3201
sprpriority = 1

[State 3201, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3201, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 3202

;Pharaoh Split - Transform
[Statedef 3202]
type = A
movetype = A
physics = N
velset = 0,0
anim = 3202
sprpriority = 1

[State 3202, 1] ;Set jump type to Pharaoh Split
type = VarSet
trigger1 = Time = 0
v = 1
value = 5

[State 3202, 2]
type = PosAdd
trigger1 = AnimTime = 0
y = -25

[State 3202, 3]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3202, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 3203

;Pharaoh Split - Float
[Statedef 3203]
type = A
physics = N
anim = 61
velset = 0,0
ctrl = 0
sprpriority = 0

[State 3203, 1]
type = ChangeAnim
trigger1 = Anim != 61
trigger1 = !(Anim = 7 && AnimTime != 0)
value = 61

[State 3203, 2]
type = PosAdd
trigger1 = command = "holdfwd"
x = 3

[State 3203, 3]
type = PosAdd
trigger1 = command = "holdback"
x = -3

[State 3203, 4]
type = PosAdd
trigger1 = command = "holdup"
trigger1 = Pos Y >= -85 ;-88 is boundary
y = -3

[State 3203, 5]
type = PosAdd
trigger1 = command = "holddown"
trigger1 = Pos Y <= -3 ;0 is boundary
y = 3

[State 3203, 6]
type = ChangeAnim
trigger1 = P2Dist X < 0
value = 7

[State 3203, 7]
type = Turn
trigger1 = P2Dist X < 0

[State 3203, 8] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3203, 9]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3230

[State 3203, 9]
type = ChangeState
trigger1 = Var(40) <= 0
value = 3207

;Pharaoh Split - Light Kick
[Statedef 3204]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
movehitpersist = 1
sprpriority = 3

[State 3204, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 3204
value = 3204

[State 3204, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 3203
ctrl = 1

[State 3204, 3] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3204, 4]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3230

;Pharaoh Split - Medium Kick
[Statedef 3205]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
movehitpersist = 1
sprpriority = 3

[State 3205, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 3205
value = 3205

[State 3205, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 3203
ctrl = 1

[State 3205, 3] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3205, 4]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3230

;Pharaoh Split - Strong Kick
[Statedef 3206]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
movehitpersist = 1
sprpriority = 3

[State 3206, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 3206
value = 3206

[State 3206, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 3203
ctrl = 1

[State 3206, 3] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3206, 4]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3230

;Pharaoh Split - End
[Statedef 3207]
type = A
movetype = I
physics = N
ctrl = 0
velset = 0,3
sprpriority = 2

[State 3207, 1]
type = ChangeAnim
trigger1 = Anim != 61
value = 61

[State 3207, 3]
type = ChangeState
trigger1 = Pos Y >= 0
value = 52 ;JUMPLAND

;Pharaoh Split - Bottom Split
[Statedef 3210]
type = S
movetype = A
physics = S
ctrl = 0
velset = 0,0
anim = 3210
sprpriority = 2

[State 3210, 1]
type = ChangeState
trigger1 = Time = 70
value = 3211

;Pharaoh Split - Walk Forward
[Statedef 3211]
type = S
movetype = A
physics = N
anim = 3211
sprpriority = 2

[State 3211, 1] ;Set to non-attacking state
type = VarSet
trigger1 = Time = 0
v = 40
value = 0

[State 3211, 2]
type = PosAdd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 18
x = 6

[State 3211, 3]
type = PosAdd
trigger1 = AnimElem = 3
trigger2 = AnimElem = 11
x = 8

[State 3211, 4]
type = PosAdd
trigger1 = AnimElem = 8
trigger2 = AnimElem = 9
trigger3 = AnimElem = 10
x = 7

[State 3211, 5]
type = PosAdd
trigger1 = AnimElem = 7
x = 11

[State 3211, 6]
type = PosAdd
trigger1 = AnimElem = 12
x = 5

[State 3211, 7]
type = PosAdd
trigger1 = AnimElem = 16
trigger2 = AnimTime = 0
x = 9

[State 3211, 8]
type = PosAdd
trigger1 = AnimElem = 17
x = 10

[State 3211, 9] ; Walk off screen
type = ChangeState
trigger1 = ScreenPos X < -50 && facing = -1
trigger2 = ScreenPos X > 370 && facing = 1
value = 3215

[State 3211, 10] ;Turn
type = ChangeState
trigger1 = P2Dist X < 0
value = 3212

[State 2811, 11]
type = ChangeState
trigger1 = parent, command = "a"
trigger1 = parent, stateno = 3203
value = 3220

[State 3211, 12]
type = ChangeState
trigger1 = parent, command = "b"
trigger1 = parent, stateno = 3203
value = 3221

[State 3211, 13]
type = ChangeState
trigger1 = parent, command = "c"
trigger1 = parent, stateno = 3203
value = 3222

[State 3211, 14] ;End
type = ChangeState
trigger1 = parent, stateno != [3200,3299]
value = 3217

;Pharaoh Split - Turn to Backwards
[Statedef 3212]
type = S
movetype = A
physics = N
anim = 3212
sprpriority = 2

[State 3212, 1]
type = Turn
trigger1 = Time = 0

[State 3212, 2]
type = PosAdd
trigger1 = Time = 0
x = -1

[State 3212, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 3213

[State 3212, 4]
type = ChangeState
trigger1 = parent, stateno != [3200,3299]
value = 3217

;Pharaoh Split - Walk Backward
[Statedef 3213]
type = S
movetype = A
physics = N
anim = 3213
sprpriority = 2

[State 3213, 1] ;Set to non-attacking state
type = VarSet
trigger1 = Time = 0
v = 40
value = 0

[State 3213, 2]
type = PosAdd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 18
trigger3 = AnimTime = 0
x = -7

[State 3213, 3]
type = PosAdd
trigger1 = AnimElem = 3
x = -11

[State 3213, 4]
type = PosAdd
trigger1 = AnimElem = 7
trigger3 = AnimElem = 17
x = -8

[State 3213, 5]
type = PosAdd
trigger1 = AnimElem = 8
x = -6

[State 3213, 6]
type = PosAdd
trigger1 = AnimElem = 9
trigger2 = AnimElem = 12
x = -9

[State 3213, 7]
type = PosAdd
trigger1 = AnimElem = 10
trigger2 = AnimElem = 16
x = -5

[State 3213, 8]
type = PosAdd
trigger1 = AnimElem = 11
x = -10

[State 3213, 9] ; Walk off screen
type = ChangeState
trigger1 = ScreenPos X < -50 && facing = 1
trigger2 = ScreenPos X > 370 && facing = -1
value = 3216

[State 3213, 10] ;Turn
type = ChangeState
trigger1 = P2Dist X < 0
value = 3214

[State 3213, 11]
type = ChangeState
trigger1 = parent, command = "a"
trigger1 = parent, stateno = 3203
value = 3220

[State 3213, 12]
type = ChangeState
trigger1 = parent, command = "b"
trigger1 = parent, stateno = 3203
value = 3221

[State 3213, 13]
type = ChangeState
trigger1 = parent, command = "c"
trigger1 = parent, stateno = 3203
value = 3222

[State 3213, 14] ;End
type = ChangeState
trigger1 = parent, stateno != [3200,3299]
value = 3217

;Pharaoh Split - Turn to Forwards
[Statedef 3214]
type = S
movetype = A
physics = N
anim = 3212
sprpriority = 2

[State 3214, 1]
type = Turn
trigger1 = Time = 0

[State 3214, 2]
type = PosAdd
trigger1 = Time = 0
x = -1

[State 3214, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 3211

[State 3214, 3]
type = ChangeState
trigger1 = parent, stateno != [3200,3299]
value = 3217

;Pharaoh Split - Walk Forwards Off Screen
[Statedef 3215]
type = S
movetype = A
physics = N
sprpriority = 2

[State 3215, 1]
type = PosAdd
trigger1 = ScreenPos X < -50 && facing = -1
x = -420

[State 3215, 2]
type = PosAdd
trigger1 = ScreenPos X > 370 && facing = 1
x = -420

[State 3215, 3]
type = ChangeState
trigger1 = 1
value = 3211

;Pharaoh Split - Walk Backwards Off Screen
[Statedef 3216]
type = S
movetype = A
physics = N
sprpriority = 2

[State 3216, 1]
type = PosAdd
trigger1 = ScreenPos X < -50 && facing = 1
x = 420

[State 3216, 2]
type = PosAdd
trigger1 = ScreenPos X > 370 && facing = -1
x = 420

[State 3216, 3]
type = Turn
trigger1 = Time = 0

[State 3216, 4]
type = PosAdd
trigger1 = Time = 0
x = -1

[State 3216, 5]
type = ChangeState
trigger1 = 1
value = 3211

;Pharaoh Split - Bottom Half End
[Statedef 3217]
type = S
movetype = I
physics = S
anim = 3217
sprpriority = 2

[State 3217, 1]
type = DestroySelf
trigger1 = AnimTime = 0

;Pharaoh Split - Bottom Light Kick
[Statedef 3220]
type = S
movetype = A
physics = S
juggle = 4
velset = 0,0
anim = 3220
sprpriority = 2

[State 3220, 1] ;Set to attacking state
type = VarSet
trigger1 = Time = 1
v = 40
value = 1

[State 3220, 1]
type = PlaySnd
trigger1 = Time = 2
value = 1, 3

[State 3220, 2]
type = HitDef
trigger1 = AnimElem = 2
attr = S, HA
animtype  = Medium
damage    = 26
hitflag = MA
guardflag = MA
pausetime = 12,12
hitSound = -1 + 0 * (var(31) := 3)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -23
ground.type = Low
ground.slidetime = 9
ground.hittime  = 9
ground.velocity = -5
air.velocity = -3,-6
getpower = 0

[State 3220, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 3)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3220, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), ceil(P2Dist y-23)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3220, 3]
type = ChangeAnim
trigger1 = HitPauseTime = 10
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 3220
elem = 3

[State 3220, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = PrevStateNo

[State 3220, 5]
type = ChangeState
trigger1 = parent, stateno != [3200,3299]
value = 3217

;Standing Medium Kick
[Statedef 3221]
type = S
movetype = A
physics = S
juggle = 5
velset = 0,0
anim = 3221
sprpriority = 2

[State 3221, 1] ;Set to attacking state
type = VarSet
trigger1 = Time = 1
v = 40
value = 1

[State 3221, 1]
type = PlaySnd
trigger1 = Time = 2
value = 1, 4

[State 3221, 2]
type = HitDef
trigger1 = AnimElem = 2
attr = S, HA
animtype  = Medium
damage    = 50
hitflag = MA
guardflag = MA
pausetime = 12,12
hitSound = -1 + 0 * (var(31) := 4)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -66
ground.type = Low
ground.slidetime = 13
ground.hittime  = 13
ground.velocity = -7
air.velocity = -3,-6
getpower = 0

[State 3221, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 4)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3221, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), ceil(P2Dist y-66)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3221, 3]
type = ChangeAnim
trigger1 = HitPauseTime = 8
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 3221
elem = 3

[State 3221, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = PrevStateNo

[State 3221, 5]
type = ChangeState
trigger1 = parent, stateno != [3200,3299]
value = 3217

;Standing Strong Kick
[Statedef 3222]
type = S
movetype = A
physics = N
juggle  = 5
velset = 0,0
anim = 3222
sprpriority = 2

[State 3222, 1]
type = VarSet
trigger1 = Time = 1
v = 40
value = 1

[State 3222, 1]
type = PlaySnd
trigger1 = Time = 2
value = 1, 5

[State 3222, 2]
type = HitDef
trigger1 = AnimElem = 3
attr = S, HA
animtype  = Medium
damage    = 78
hitflag = MA
guardflag = MA
pausetime = 12,12
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -76
ground.type = Low
ground.slidetime = 19
ground.hittime  = 19
ground.velocity = -9
air.velocity = -3,-6
getpower = 0

[State 3222, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 5)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3222, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), ceil(P2Dist y-96)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3222, 3]
type = ChangeAnim
trigger1 = HitPauseTime = 8
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 3222
elem = 4

[State 3222, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = PrevStateNo

[State 3222, 5]
type = ChangeState
trigger1 = parent, stateno != [3200,3299]
value = 3217

;Pharaoh Split - HitOverride
[Statedef 3230]
type = A
movetype = H
physics = N
velset = 0,0
movehitpersist = 1
sprpriority = 0

[State 3230, 1]
type = LifeAdd
trigger1 = Time = 0
value = -GetHitVar(damage)
ignorehitpause = 1

[State 3230, 2]
type = ChangeState
trigger1 = Life = 0
value = 5020
ignorehitpause = 1

[State 3230, 3]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3230, 4]
type = PalFx
trigger1 = Time = 0
time = 2
add = 256,0,0
mul = 256,0,0

[State 3230, 5]
type = ChangeState
trigger1 = Time = 0
value = Var(57) ;PrevStateNo

;Pharaoh Split - Light Punch
[Statedef 3231]
type = A
movetype = A
juggle = 2
ctrl = 0
movehitpersist = 1
sprpriority = 2
powerAdd = 0

[State 3231, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 600
value = 600

[State 3231, 2]
type = PlaySnd
trigger1 = Time = 1
value = 1, 0

[State 3231, 3]
type = HitDef
trigger1 = Time = 0
trigger1 = MoveContact = 0
attr = A, HA
damage    = 20
hitflag = MA
guardflag = HA
priority = 3
pausetime = 11,11
hitSound = -1 + 0 * (var(31) := 0)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -59
ground.type = High
ground.slidetime = 9
ground.hittime  = 9
ground.velocity = -5
air.velocity = -3,-6
getPower = 0
givePower = 36, 36

[State 3231, 4]
type = ChangeAnim
trigger1 = HitPauseTime = 9
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 600
elem = 4

[State 3231, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 3203

[State 3231, 6] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3231, 7]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3230

;Pharaoh Split - Medium Punch
[Statedef 3232]
type = A
movetype = A
juggle  = 4
ctrl = 0
movehitpersist = 1
sprpriority = 2
powerAdd = 0

[State 3232, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 610
value = 610

[State 3232, 2]
type = PlaySnd
trigger1 = Time = 2
value = 1, 1

[State 3232, 3]
type = HitDef
trigger1 = Time = 0
trigger1 = MoveContact = 0
attr = A, HA
damage = 72
hitflag = MA
guardflag = HA
priority = 4
pausetime = 11,11
hitSound = -1 + 0 * (var(31) := 1)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -52
animtype = Med
ground.type = High
ground.slidetime = 9
ground.hittime  = 9
ground.velocity = -5
air.velocity = -3,-6
getPower = 0
givePower = 36, 36

[State 3232, 4]
type = ChangeAnim
trigger1 = HitPauseTime = 9
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 610
elem = 4

[State 3232, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 3203

[State 3232, 6] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3232, 7]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3230

;Pharaoh Split - Strong Punch
[Statedef 3233]
type = A
movetype = A
juggle = 4
ctrl = 0
movehitpersist = 1
sprpriority = 2
powerAdd = 0

[State 3233, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 620
value = 620

[State 3233, 2]
type = PlaySnd
trigger1 = Time = 2
value = 1, 2

[State 3233, 3]
type = HitDef
trigger1 = Time = 0
trigger1 = MoveContact = 0
attr = A, HA
damage = 72
hitflag = MA
guardflag = HA
priority = 4
pausetime = 12,12
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -28
animtype = Med
ground.type = High
ground.slidetime = 10
ground.hittime  = 10
ground.velocity = -5
air.velocity = -3,-6
getPower = 0
givePower = 36, 36

[State 3233, 4]
type = ChangeAnim
trigger1 = HitPauseTime = 10
trigger1 = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 620
elem = 5

[State 3233, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 3203

[State 3233, 6] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3233, 7]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3230

;========================<PHARAOH MAGIC>=============================
[StateDef 3300]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3300, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3300, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3300, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3300, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3300, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3300, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3300, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3300, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3300, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3300, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3300, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3300, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3305
bindtime = -1
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3300, 3]
type = ChangeAnim
trigger1 = Anim = 3300
trigger1 = AnimTime = 0
value = 3302

[State 3300, 4] ;Projectile
type = Helper
trigger1 = Anim = 3302
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3310
stateno = 3310
ownpal = 1

[State 3300, 5] ;Base
type = RemoveExplod
triggerall = Anim = 3302
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3310) = 0
ID = 3305

[State 3300, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3310) = 0
value = 3301

[State 3300, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3310), MoveHit = 1
value = 3302

;Pharaoh Magic - Miss
[Statedef 3301]
type = S
movetype = A
physics = S
anim = 3301

[State 3301, 1] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3307
bindtime = -1
sprpriority = 1
removeongethit = 1

[State 3301, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Pharaoh Magic - Hit
[Statedef 3302]
type = U
movetype = A
physics = N

[State 3302, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3302, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3302, PosFreeze]
type = PosFreeze
trigger1 = 1

[State 3302, Voice] ;Voice
type = PlaySnd
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 2
value = 1130, 0
channel = 0

[State 3302, 1]
type = ChangeAnim
triggerall = helper(3310), Var(2) = 1
triggerall = helper(3310), stateno = 3312
trigger1 = helper(3310), Time = 9 && AnimTime > 70
trigger2 = AnimTime = 70
value = ifelse(statetype = A,3402,3302)

[State 3302, 2]
type = ChangeAnim
triggerall = helper(3310), Var(2) = 2
triggerall = helper(3310), stateno = 3312
trigger1 = helper(3310), Time = 9 && AnimTime > 60
trigger2 = AnimTime = 60
value = ifelse(statetype = A,3402,3302)

[State 3302, 3]
type = ChangeAnim
triggerall = helper(3310), Var(2) = 3
triggerall = helper(3310), stateno = 3312
trigger1 = helper(3310), Time >= 6 && AnimTime > 60
trigger2 = AnimTime = 60
value = ifelse(statetype = A,3402,3302)

[State 3302, 4] ;Base
type = RemoveExplod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
ID = 3305

[State 3302, 5] ;Base
type = Explod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
anim = 3306
ID = 3305
pos = 0,-floor(Pos Y)
bindtime = -1
sprpriority = 1
removeongethit = 1

[State 3302, 6] ;Base
type = RemoveExplod
trigger1 = helper(3310), Var(2) >= 2
trigger1 = AnimTime = 24
ID = 3305

[State 3302, 7]
type = ChangeState
trigger1 = helper(3310), Var(2) >= 2
trigger1 = AnimTime = 24
value = ifelse(statetype = A,3306,3301)

;Pharaoh Magic - Attempt (Air)
[Statedef 3305]
type = A
movetype = A
physics = N
juggle = 4
poweradd = -1000
ctrl = 0
anim = 3400
sprpriority = 2

[State 3305, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3305, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3305, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3305, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3305, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3305, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3305, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3305, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3305, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-95 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3305, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3305, 1]
type = PosFreeze
trigger1 = 1

[State 3305, 2] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3305, 3] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3305
pos = 0,-floor(Pos Y)
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3305, 4]
type = ChangeAnim
trigger1 = Anim = 3400
trigger1 = AnimTime = 0
value = 3402

[State 3305, 5] ;Projectile
type = Helper
trigger1 = Anim = 3402
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3310
stateno = 3310

[State 3305, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 3305, 6] ;Base
type = RemoveExplod
trigger1 = Anim = 3402
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3310) = 0
ID = 3305

[State 3305, 7] ;Miss
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3310) = 0
value = 3306

[State 3305, 8] ;Hit
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3310), MoveHit = 1
value = 3302

;Pharaoh Magic - Miss (Air)
[Statedef 3306]
type = A
movetype = I
physics = N
anim = 3401

[State 3306, 1]
type = PosFreeze
trigger1 = 1

[State 3306, 2] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3307
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3306, 3]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 3306, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;Pharaoh Magic - Projectile Helper
[Statedef 3310]
type = A
movetype = A
ctrl = 0
juggle = 3
anim = 1210
sprpriority = -1

[State 3310, 1]
type = BindToParent
trigger1 = Time = 0
pos = 101,-96

[State 3300, 1]
type = VarSet
trigger1 = Time = 0
v = 2
value = 0

[State 3310, 2]
type = HitDef
trigger1 = Var(2) = 0
trigger1 = Time = 0
attr = A, HP
hitflag = MA-
guardflag = MA
pausetime = 0,10
priority = 1, Miss
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 3312
p2stateno = 3340
numhits = 0
getpower = 0

[State 3310, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3310, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3310, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3310, VelSet 1]
type = VelSet
trigger1 = Time = 0
x = 4
y = 2

[State 3310, 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3315
stateno = 3315

[State 3310, 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3316
stateno = 3316

[State 3310, 5]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3317
stateno = 3317

[State 3310, 6]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3318
stateno = 3318

[State 3310, 7] ;Miss
type = ChangeState
trigger1 = Time > 0
trigger1 = Pos Y >= -30
trigger2 = MoveGuarded
value = 3314

[State 3310, Fire Logo]
type = Explod
trigger1 = Time >= 1
anim = 3440
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Magic - Projectile Helper - Repeat Trips
[Statedef 3311]
type = A
movetype = A

[State 3311, 1]
type = BindToParent
trigger1 = Time = 0
pos = 101,-96

[State 3311, VelSet 2]
type = VelSet
trigger1 = Var(2) != 0
trigger1 = Time = 0
x = 6
y = 2

[State 3311, 2]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3315
stateno = 3315

[State 3311, 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3316
stateno = 3316

[State 3311, 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3317
stateno = 3317

[State 3311, 5]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3318
stateno = 3318

[State 3310, 8] ;Throwing Hit
type = ChangeState
triggerall = Time > 0
trigger1 = facing = 1 && (target, Pos X - Pos X < 30)
trigger2 = facing = -1 && (target, Pos X - Pos X > -30)
value = 3312

[State 3311, Shock Logo]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time >= 1
anim = 3442
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3311, Ice Logo]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time >= 1
anim = 3445
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Magic - Projectile Helper - Target Transformed
[Statedef 3312]
type = A
movetype = A
anim = 1214

[State 3312, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3312, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3312, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3312, 1]
type = HitAdd
trigger1 = Time = 0
value = 1

[State 3312, 2] ;Fire Spark
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
anim = 4040
postype = p2
bindtime = -1
sprpriority = 3
ownpal = 1

[State 3312, 3] ;Fire Sound
type = PlaySnd
trigger1 = Var(2) = 0
trigger1 = Time = 0
value = 3300, 1

[State 3310, 4] ;Shocked Sound
type = PlaySnd
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3300, 2

[State 3310, 5] ;Shocked State
type = TargetState
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3345

[State 3310, 6] ;P2 Frozen Special Anim
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time = 0
anim = ifelse(target, const(size.height) <= 60,3357,3358)
ID = 3357
postype = p2
bindtime = -1
sprpriority = 3
ownpal = 1

[State 3310, 7] ;Frozen Sound
type = PlaySnd
trigger1 = Var(2) = 1
trigger1 = Time = 0
value = 3300, 3

[State 3310, 8] ;Frozen State
type = TargetState
trigger1 = Var(2) = 1
trigger1 = Time = 0
value = 3346

[State 3310, 9]
type = VelSet
trigger1 = parent, Var(2) > 0
trigger1 = Time = 0
x = 0
y = 0

[State 3312, 10]
type = VarSet
trigger1 = Time = 0
v = 2
value = Var(2) + 1

[State 3312, 11] ;Throw another projectile
type = ChangeState
trigger1 = Var(2) < 2
trigger1 = parent, stateno = 3302
trigger1 = parent, AnimElem = 7, = 4
value = 3311

[State 3312, 12] ;Anakaris interrupted
type = ChangeState
trigger1 = Var(2) = 1
trigger1 = parent, stateno != 3302
trigger1 = Time != 0
value = 3313

[State 3312, 13] ;End, go to coffin drop
type = ChangeState
trigger1 = Var(2) >= 2
trigger1 = parent, stateno = 3302
trigger1 = parent, AnimElem = 7, = 2
value = 3320

;Pharaoh Magic - Projectile Helper - Interrupted
[Statedef 3313]
type = A
movetype = A

[State 3313, 1] ;Anakaris interrupted
type = TargetState
trigger1 = target, stateno = 3344
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
value = 3349

[State 3313, 2]
type = DestroySelf
trigger1 = Time > 0
trigger1 = target, stateno != [3340,3344]

;Pharaoh Magic - Projectile Helper - Miss
[Statedef 3314]
type = A
movetype = A

[State 3314, 1]
type = DestroySelf
trigger1 = Time > 0

;Pharaoh Magic - Projectile Helper - Coffin Falling
[Statedef 3320]
type = A
movetype = A
anim = 3420
ctrl = 0
velset = 0,16
sprpriority = 3

[State 3320, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Random < 100 || parent, command = "holdstart"
value = 3422

[State 3320, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 3422
value = ifelse(Random > 50,3420,3424)

[State 3320, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3424
anim = 3426
ID = 3426
bindtime = -1
removetime = -1

[State 3320, 4] ;Khybit sound
type = PlaySnd
trigger1 = Time = 4
trigger1 = Anim = 3424
value = 3400,0
channel = 1

[State 3320, 5]
type = PosSet
trigger1 = Time = 0
x = target, Pos X
y = -240

[State 3320, 6]
type = ChangeState
trigger1 = Pos Y >= 0
value = 3321

;Pharaoh Magic - Projectile Helper - Coffin Hitting
[Statedef 3321]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 2421, RemoveExplod 1] ;Remove P2 Frozen Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3357

[State 3321, Big Explod 1]
type = Explod
trigger1 = Time = 0
anim = 4051
pos = -28,-72
postype = p2
vel = -5,-2
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3321, Small Explod 1]
type = Explod
trigger1 = Time = 0
anim = 4050
pos = -39,-47
postype = p2
vel = -5,0.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3321, Small Explod 2]
type = Explod
trigger1 = Time = 0
anim = 4050
pos = -2,-91
postype = p2
vel = -0,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3321, Small Explod 3]
type = Explod
trigger1 = Time = 0
anim = 4050
pos = 20,-48
postype = p2
vel = 5,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3321, Big Explod 2]
type = Explod
trigger1 = Time = 0
anim = 4051
pos = -40,-28
postype = p2
vel = -6,-1
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3321, Big Explod Alt 1]
type = Explod
trigger1 = Time = 1
anim = 4051
pos = -19,-63
postype = p2
vel = -4,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3321, Small Explod Alt 1]
type = Explod
trigger1 = Time = 1
anim = 4050
pos = 39,-51
postype = p2
vel = 3,1
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3321, Big Explod Alt 2]
type = Explod
trigger1 = Time = 1
anim = 4051
pos = 19,-80
postype = p2
vel = 0.5,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3321, Small Explod Alt 2]
type = Explod
trigger1 = Time = 1
anim = 4050
pos = 49,-23
postype = p2
vel = 3,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3321, Small Explod Alt 3]
type = Explod
trigger1 = Time = 1
anim = 4050
pos = -21,-43
postype = p2
vel = -3,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3321, 1]
type = ChangeAnim
trigger1 = Time = 0
value = Anim+1

[State 3321, 2] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Time = 0
ID = 3426

[State 3321, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3425
anim = 3427
ID = 3426
bindtime = -1
removetime = -1

[State 3321, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3321, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3321, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3321, 4]
type = HitAdd
trigger1 = Time = 0
trigger1 = Var(2) != 1
value = 1

[State 3321, 5]
type = EnvShake
trigger1 = Time = 0
time = 16
ampl = 5
freq = 120

[State 3321, 6]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3321, 7] ;Remove Royal Judgement Khybits and P2Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3370

[State 3321, 8] ;Crash Sound
type = PlaySnd
trigger1 = Time = 0
value = 1100, 1

[State 3321, 9]
type = TargetState
trigger1 = Time = 0
value = 3347

[State 3321, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 3322

;Pharaoh Magic - Projectile Helper - Coffin Rising
[Statedef 3322]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3322, 1] ;If this move killed target
type = ParentVarSet
trigger1 = Time = 0
trigger1 = target, Life = 0
v = 5 ;Win Type
value = 2

[State 3322, 2]
type = VelSet
triggerall = Time = 0
trigger1 = target, Life != 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life != 0 || enemynear(1), life != 0
y = -8

[State 3322, 3]
type = ChangeAnim
trigger1 = Time = 0
value = Anim-1

[State 3322, 4] ;Remove Riding Khybit
type = StopSnd
trigger1 = Pos Y <= -240
channel = 1

[State 3322, 5] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Pos Y <= -240
ID = 3426

[State 3322, 6]
type = DestroySelf
trigger1 = Pos Y <= -240

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3315]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3315, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 1

[State 3315, 2]
type = ChangeState
trigger1 = Time = 0
value = 3319

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3316]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3316, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 9

[State 3316, 2]
type = ChangeState
trigger1 = Time = 0
value = 3319

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3317]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3317, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 17

[State 3317, 2]
type = ChangeState
trigger1 = Time = 0
value = 3319

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3318]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3318, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 25

[State 3318, 2]
type = ChangeState
trigger1 = Time = 0
value = 3319

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3319]
type = A
movetype = A
ctrl = 0

[State 3319, BindToParent 1]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -4,5

[State 3319, BindToParent 2]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -1,10

[State 3319, BindToParent 3]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 10,-1

[State 3319, BindToParent 4]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 6,19

[State 3319, BindToParent 5]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(5) >= 0 && AnimElemTime(6) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 9,23

[State 3319, BindToParent 6]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 11,25

[State 3319, BindToParent 7]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(7) >= 0 && AnimElemTime(8) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 14,27

[State 3319, BindToParent 8]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(8) >= 0 && AnimElemTime(9) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 16,28

[State 3319, BindToParent 9]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(9) >= 0 && AnimElemTime(10) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 16,26

[State 3319, BindToParent 10]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(10) >= 0 && AnimElemTime(11) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 17,24

[State 3319, BindToParent 11]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(11) >= 0 && AnimElemTime(12) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 17,22

[State 3319, BindToParent 12]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(12) >= 0 && AnimElemTime(13) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 16,18

[State 3319, BindToParent 13]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(13) >= 0 && AnimElemTime(14) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 14,14

[State 3319, BindToParent 14]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(14) >= 0 && AnimElemTime(15) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 13,9

[State 3319, BindToParent 15]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(15) >= 0 && AnimElemTime(16) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 10,4

[State 3319, BindToParent 16]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(16) >= 0 && AnimElemTime(17) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 8,0

[State 3319, BindToParent 17]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(17) >= 0 && AnimElemTime(18) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 4,-4

[State 3319, BindToParent 18]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(18) >= 0 && AnimElemTime(19) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = 1,-9

[State 3319, BindToParent 19]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(19) >= 0 && AnimElemTime(20) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -2,-14

[State 3319, BindToParent 20]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(20) >= 0 && AnimElemTime(21) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -6,-18

[State 3319, BindToParent 21]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(21) >= 0 && AnimElemTime(22) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -9,-22

[State 3319, BindToParent 22]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(22) >= 0 && AnimElemTime(23) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -11,-24

[State 3319, BindToParent 23]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(23) >= 0 && AnimElemTime(24) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -14,-27

[State 3319, BindToParent 24]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(24) >= 0 && AnimElemTime(25) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -16,-28

[State 3319, BindToParent 25]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(25) >= 0 && AnimElemTime(26) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -16,-27

[State 3319, BindToParent 26]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(26) >= 0 && AnimElemTime(27) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -17,-25

[State 3319, BindToParent 27]
type = BindToParent
triggerall r1 = Anim = 3419
triggerall = AnimElemTime(27) >= 0 && AnimElemTime(28) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -17,-23

[State 3319, BindToParent 28]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(28) >= 0 && AnimElemTime(29) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -16,-19

[State 3319, BindToParent 29]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(29) >= 0 && AnimElemTime(30) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -14,-15

[State 3319, BindToParent 30]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(30) >= 0 && AnimElemTime(31) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -13,-10

[State 3319, BindToParent 31]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(31) >= 0 && AnimElemTime(32) < 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -10,-5

[State 3319, BindToParent 32]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(32) >= 0
trigger1 = parent, stateno = 3310
trigger2 = parent, stateno = 3311
pos = -8,0

[State 3319, SprPriority 1]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 5
value = 3

[State 3319, SprPriority 1]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 9
value = 0

[State 3319, SprPriority 2]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 13
value = -1

[State 3319, SprPriority 3]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 17
value = 0

[State 3319, SprPriority 4]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 21
value = 3

[State 3319, SprPriority 5]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 29
value = 4

;[State 3319, PosAdd]
;type = PosAdd
;trigger1 = Anim = 3419
;trigger1 = parent, stateno != 1210
;x = -5 + 27*cos(2*PI*(AnimElemNo(0)+7)/32)
;y = -5 +  5*sin(2*PI*(AnimElemNo(0)+7)/32)

[State 3319, ChangeAnim 2]
type = ChangeAnim
trigger1 = Anim = 3419
trigger1 = parent, stateno != 3310
trigger1 = parent, stateno != 3311
value = 1213

[State 3319, DestroySelf]
type = DestroySelf
trigger1 = Anim = 1213
trigger1 = AnimTime = 0

;Pharaoh Magic - Hit
[Statedef 3340]
type = S
movetype = H
physics = N
velset = 0,0

[State 3340, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3340, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3340, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5010

[State 3340, 2]
type = LifeAdd
trigger1 = Time = 0
value = -50
kill = 0

[State 3340, 3]
type = ChangeState
trigger1 = Time = 5
value = 3342

;Pharaoh Magic - Dizzy
[Statedef 3341]
type = S
movetype = H
physics = N
velset = 0,0

[State 3341, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3341, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3341, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5300

;Pharaoh Magic - Burned Rising
[Statedef 3342]
type = A
movetype = H
physics = N
velset = 0,-3

[State 3342, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3342, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3342, 1]
type = PalFx
trigger1 = SelfAnimExist(7697) = 0
time = 1
add = 144,72,32
mul = 256,224,128
color = 0

[State 3342, 2]
type = ChangeAnim
trigger1 = SelfAnimExist(7697) = 1
trigger1 = Time = 0
value = 7697

[State 3342, 3]
type = ChangeAnim2
trigger1 = SelfAnimExist(7697) = 0
trigger1 = Time = 0
value = 3352

[State 3342, 4] ;Gravity
type = VelAdd
trigger1 = 1
y = .15

[State 3342, 5]
type = ChangeState
trigger1 = Vel Y >= 0
value = 3343

;Pharaoh Magic - Burned Floating
[Statedef 3343]
type = A
movetype = H
physics = N
velset = 0,0

[State 3343, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3343, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3343, 1]
type = PalFx
trigger1 = SelfAnimExist(7697) = 0
time = 1
add = 144,72,32
mul = 256,224,128
color = 0

[State 3343, 2]
type = ChangeState
trigger1 = Time = 22
value = 3344

;Pharaoh Magic - Burned Falling
[Statedef 3344]
type = A
movetype = H
physics = N

[State 3344, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3344, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3344, 1]
type = PalFx
trigger1 = SelfAnimExist(7697) = 0
time = 1
add = 144,72,32
mul = 256,224,128
color = 0

[State 3344, 2] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 3344, 3]
type = ChangeState
trigger1 = Pos Y >= 0
trigger1 = Vel Y >= 0
value = 3341

;Pharaoh Magic - Shocked
[Statedef 3345]
type = A
movetype = H
physics = N
velset = 0,-6

[State 3345, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3345, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3345, 1]
type = LifeAdd
trigger1 = Time = 0
value = -50
kill = 0

[State 3345, 2]
type = PalFx
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time = 0
time = -1
add = 96,72,16
mul = 256,256,128
color = 0

[State 3345, 3]
type = ChangeAnim
trigger1 = SelfAnimExist(7696) = 1
trigger1 = Time = 0
value = 7696

[State 3345, 4]
type = ChangeAnim2
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time = 0
value = 3355

[State 3345, 5] ;Gravity
type = VelAdd
trigger1 = 1
y = .44

[State 3345, 6]
type = Offset
triggerall = Time < 3
trigger1 = Time % 6 = 0
trigger2 = Time % 6 = 1
trigger3 = Time % 6 = 2
x = 0

[State 3345, 7]
type = Offset
triggerall = Time >= 3
trigger1 = Time % 6 = 0
trigger2 = Time % 6 = 1
trigger3 = Time % 6 = 2
x = 8

[State 3345, 8]
type = Offset
trigger1 = Time % 6 = 3
trigger2 = Time % 6 = 4
trigger3 = Time % 6 = 5
x = -8

[State 3345, 9]
type = PalFx
trigger1 = Pos Y >= 0
trigger1 = Vel Y >= 0
time = 0

[State 3345, 10]
type = Offset
trigger1 = Pos Y >= 0
trigger1 = Vel Y >= 0
x = 0

[State 3345, 11]
type = ChangeState
trigger1 = Pos Y >= 0
trigger1 = Vel Y >= 0
value = 3341

;Pharaoh Magic - Frozen
[Statedef 3346]
type = S
movetype = H
physics = N
velset = 0,0

[State 3346, 1]
type = LifeAdd
trigger1 = Time = 0
value = -50
kill = 0

[State 3346, 2]
type = ChangeAnim2
trigger1 = Time = 0
value = 3356

;Pharaoh Magic - Crushed
[Statedef 3347]
type = L
movetype = H
physics = N
velset = 0,0

[State 3347, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3347, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3347, 3]
type = Turn
trigger1 = Time = 0

[State 3347, 1]
type = LifeAdd
trigger1 = Time = 0
value = -150

[State 3347, 2]
type = ChangeAnim
trigger1 = Time = 0
value = 5110

[State 3347, 3]
type = ChangeState
trigger1 = Time = 57
value = 3348

;Pharaoh Magic - Crushed Flying
[Statedef 3348]
type = L
movetype = H
physics = N
velset = 0,0

[State 3348, 1]
type = SelfState
trigger1 = Life = 0
value = 5150

[State 3348, 2]
type = SelfState
trigger1 = 1
value = 5120

;Pharaoh Magic - Target End Custom Hit State
[Statedef 3349]
type = A
movetype = H
physics = N
velset = 0,0

[State 3349, 1]
type = SelfState
trigger1 = Time = 0
value = 5100

;========================<MAX PHARAOH MAGIC>=============================
[StateDef 3350]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3350, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3350, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3350, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3350, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3350, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3350, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3350, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3350, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3350, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3350, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3350, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3350, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3305
bindtime = -1
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3350, 3]
type = ChangeAnim
trigger1 = Anim = 3300
trigger1 = AnimTime = 0
value = 3302

[State 3350, 4] ;Projectile
type = Helper
trigger1 = Anim = 3302
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3360
stateno = 3360
ownpal = 1

[State 3350, 5] ;Base
type = RemoveExplod
triggerall = Anim = 3302
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3360) = 0
ID = 3305

[State 3350, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3360) = 0
value = 3351

[State 3350, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3360), MoveHit = 1
value = 3352

;Pharaoh Magic - Miss
[Statedef 3351]
type = S
movetype = A
physics = S
anim = 3301

[State 3351, 1] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3307
bindtime = -1
sprpriority = 1
removeongethit = 1

[State 3351, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Pharaoh Magic - Hit
[Statedef 3352]
type = U
movetype = A
physics = N

[State 3352, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3352, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3352, PosFreeze]
type = PosFreeze
trigger1 = 1

[State 3352, Voice] ;Voice
type = PlaySnd
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 2
value = 1130, 0
channel = 0

[State 3352, 1]
type = ChangeAnim
triggerall = helper(3360), Var(2) = 1
triggerall = helper(3360), stateno = 3362
trigger1 = helper(3360), Time = 9 && AnimTime > 70
trigger2 = AnimTime = 70
value = ifelse(statetype = A,3402,3302)

[State 3352, 2]
type = ChangeAnim
triggerall = helper(3360), Var(2) = 2
triggerall = helper(3360), stateno = 3362
trigger1 = helper(3360), Time = 9 && AnimTime > 60
trigger2 = AnimTime = 60
value = ifelse(statetype = A,3402,3302)

[State 3352, 3]
type = ChangeAnim
triggerall = helper(3360), Var(2) = 3
triggerall = helper(3360), stateno = 3362
trigger1 = helper(3360), Time >= 6 && AnimTime > 60
trigger2 = AnimTime = 60
value = ifelse(statetype = A,3402,3302)

[State 3352, 4] ;Base
type = RemoveExplod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
ID = 3305

[State 3352, 5] ;Base
type = Explod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
anim = 3306
ID = 3305
pos = 0,-floor(Pos Y)
bindtime = -1
sprpriority = 1
removeongethit = 1

[State 3352, 6] ;Base
type = RemoveExplod
trigger1 = helper(3360), Var(2) >= 3
trigger1 = AnimTime = 24
ID = 3305

[State 3352, 7]
type = ChangeState
trigger1 = helper(3360), Var(2) >= 3
trigger1 = AnimTime = 24
value = ifelse(statetype = A,3356,3351)

;Pharaoh Magic - Attempt (Air)
[Statedef 3355]
type = A
movetype = A
physics = N
juggle = 4
poweradd = -2000
ctrl = 0
anim = 3400
sprpriority = 2

[State 3355, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3355, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3355, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3355, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3355, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3355, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3355, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3355, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3355, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-95 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3355, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3355, 1]
type = PosFreeze
trigger1 = 1

[State 3355, 2] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3355, 3] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3305
pos = 0,-floor(Pos Y)
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3355, 4]
type = ChangeAnim
trigger1 = Anim = 3400
trigger1 = AnimTime = 0
value = 3402

[State 3355, 5] ;Projectile
type = Helper
trigger1 = Anim = 3402
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3360
stateno = 3360

[State 3355, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 3355, 6] ;Base
type = RemoveExplod
trigger1 = Anim = 3402
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3360) = 0
ID = 3305

[State 3355, 7] ;Miss
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3360) = 0
value = 3356

[State 3355, 8] ;Hit
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3360), MoveHit = 1
value = 3352

;Pharaoh Magic - Miss (Air)
[Statedef 3356]
type = A
movetype = I
physics = N
anim = 3401

[State 3356, 1]
type = PosFreeze
trigger1 = 1

[State 3356, 2] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3307
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3356, 3]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 3356, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;Pharaoh Magic - Projectile Helper
[Statedef 3360]
type = A
movetype = A
ctrl = 0
juggle = 3
anim = 1210
sprpriority = -1

[State 3360, 1]
type = BindToParent
trigger1 = Time = 0
pos = 101,-96

[State 3360, 1]
type = VarSet
trigger1 = Time = 0
v = 2
value = 0

[State 3360, 2]
type = HitDef
trigger1 = Var(2) = 0
trigger1 = Time = 0
attr = A, HP
hitflag = MA-
guardflag = MA
pausetime = 0,10
priority = 1, Miss
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 3362
p2stateno = 3340
numhits = 0
getpower = 0

[State 3360, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3360, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3360, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3360, VelSet 1]
type = VelSet
trigger1 = Time = 0
x = 4
y = 2

[State 3360, 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3365
stateno = 3365

[State 3360, 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3366
stateno = 3366

[State 3360, 5]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3367
stateno = 3367

[State 3360, 6]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3368
stateno = 3368

[State 3360, 7] ;Miss
type = ChangeState
trigger1 = Time > 0
trigger1 = Pos Y >= -30
trigger2 = MoveGuarded
value = 3364

[State 3360, Fire Logo]
type = Explod
trigger1 = Time >= 1
anim = 3440
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Magic - Projectile Helper - Repeat Trips
[Statedef 3361]
type = A
movetype = A

[State 3361, 1]
type = BindToParent
trigger1 = Time = 0
pos = 101,-96

[State 3361, VelSet 2]
type = VelSet
trigger1 = Var(2) != 0
trigger1 = Time = 0
x = 6
y = 2

[State 3361, 2]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3365
stateno = 3365

[State 3361, 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3366
stateno = 3366

[State 3361, 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3367
stateno = 3367

[State 3361, 5]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3368
stateno = 3368

[State 3361, 8] ;Throwing Hit
type = ChangeState
triggerall = Time > 0
trigger1 = facing = 1 && (target, Pos X - Pos X < 30)
trigger2 = facing = -1 && (target, Pos X - Pos X > -30)
value = 3362

[State 3361, Shock Logo]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time >= 1
anim = 3442
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3361, Ice Logo]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time >= 1
anim = 3445
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Magic - Projectile Helper - Target Transformed
[Statedef 3362]
type = A
movetype = A
anim = 1214

[State 3362, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3362, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3362, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3362, 1]
type = HitAdd
trigger1 = Time = 0
value = 1

[State 3362, 2] ;Fire Spark
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
anim = 4040
postype = p2
bindtime = -1
sprpriority = 3
ownpal = 1

[State 3362, 3] ;Fire Sound
type = PlaySnd
trigger1 = Var(2) = 0
trigger1 = Time = 0
value = 3300, 1

[State 3360, 4] ;Shocked Sound
type = PlaySnd
trigger1 = Var(2) = 1
trigger1 = Time = 0
value = 3300, 2

[State 3360, 5] ;Shocked State
type = TargetState
trigger1 = Var(2) = 1
trigger1 = Time = 0
value = 3345

[State 3360, 6] ;P2 Frozen Special Anim
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
anim = ifelse(target, const(size.height) <= 60,3357,3358)
ID = 3357
postype = p2
bindtime = -1
sprpriority = 3
ownpal = 1

[State 3360, 7] ;Frozen Sound
type = PlaySnd
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3300, 3

[State 3360, 8] ;Frozen State
type = TargetState
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3346

[State 3360, 9]
type = VelSet
trigger1 = parent, Var(2) > 0
trigger1 = Time = 0
x = 0
y = 0

[State 3362, 10]
type = VarSet
trigger1 = Time = 0
v = 2
value = Var(2) + 1

[State 3362, 11] ;Throw another projectile
type = ChangeState
trigger1 = Var(2) < 3
trigger1 = parent, stateno = 3352
trigger1 = parent, AnimElem = 7, = 4
value = 3361

[State 3362, 12] ;Anakaris interrupted
type = ChangeState
trigger1 = Var(2) = 1
trigger1 = parent, stateno != 3352
trigger1 = Time != 0
value = 3363

[State 3362, 13] ;End, go to coffin drop
type = ChangeState
trigger1 = Var(2) >= 3
trigger1 = parent, stateno = 3352
trigger1 = parent, AnimElem = 7, = 2
value = 3370

;Pharaoh Magic - Projectile Helper - Interrupted
[Statedef 3363]
type = A
movetype = A

[State 3363, 1] ;Anakaris interrupted
type = TargetState
trigger1 = target, stateno = 3344
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
value = 3349

[State 3363, 2]
type = DestroySelf
trigger1 = Time > 0
trigger1 = target, stateno != [3340,3344]

;Pharaoh Magic - Projectile Helper - Miss
[Statedef 3364]
type = A
movetype = A

[State 3364, 1]
type = DestroySelf
trigger1 = Time > 0

;Pharaoh Magic - Projectile Helper - Coffin Falling
[Statedef 3370]
type = A
movetype = A
anim = 3420
ctrl = 0
velset = 0,16
sprpriority = 3

[State 3370, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Random < 100 || parent, command = "holdstart"
value = 3422

[State 3370, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 3422
value = ifelse(Random > 50,3420,3424)

[State 3370, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3424
anim = 3426
ID = 3426
bindtime = -1
removetime = -1

[State 3370, 4] ;Khybit sound
type = PlaySnd
trigger1 = Time = 4
trigger1 = Anim = 3424
value = 3400,0
channel = 1

[State 3370, 5]
type = PosSet
trigger1 = Time = 0
x = target, Pos X
y = -240

[State 3370, 6]
type = ChangeState
trigger1 = Pos Y >= 0
value = 3371

;Pharaoh Magic - Projectile Helper - Coffin Hitting
[Statedef 3371]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3371, RemoveExplod 1] ;Remove P2 Frozen Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3357

[State 3371, Big Explod 1]
type = Explod
trigger1 = Time = 0
anim = 4051
pos = -28,-72
postype = p2
vel = -5,-2
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3371, Small Explod 1]
type = Explod
trigger1 = Time = 0
anim = 4050
pos = -39,-47
postype = p2
vel = -5,0.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3371, Small Explod 2]
type = Explod
trigger1 = Time = 0
anim = 4050
pos = -2,-91
postype = p2
vel = -0,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3371, Small Explod 3]
type = Explod
trigger1 = Time = 0
anim = 4050
pos = 20,-48
postype = p2
vel = 5,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3371, Big Explod 2]
type = Explod
trigger1 = Time = 0
anim = 4051
pos = -40,-28
postype = p2
vel = -6,-1
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3371, Big Explod Alt 1]
type = Explod
trigger1 = Time = 1
anim = 4051
pos = -19,-63
postype = p2
vel = -4,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3371, Small Explod Alt 1]
type = Explod
trigger1 = Time = 1
anim = 4050
pos = 39,-51
postype = p2
vel = 3,1
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3371, Big Explod Alt 2]
type = Explod
trigger1 = Time = 1
anim = 4051
pos = 19,-80
postype = p2
vel = 0.5,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3371, Small Explod Alt 2]
type = Explod
trigger1 = Time = 1
anim = 4050
pos = 49,-23
postype = p2
vel = 3,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3371, Small Explod Alt 3]
type = Explod
trigger1 = Time = 1
anim = 4050
pos = -21,-43
postype = p2
vel = -3,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3371, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3371, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3371, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3371, 1]
type = ChangeAnim
trigger1 = Time = 0
value = Anim+1

[State 3371, 2] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Time = 0
ID = 3426

[State 3371, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3425
anim = 3427
ID = 3426
bindtime = -1
removetime = -1

[State 3371, 4]
type = HitAdd
trigger1 = Time = 0
trigger1 = Var(2) != 1
value = 1

[State 3371, 5]
type = EnvShake
trigger1 = Time = 0
time = 16
ampl = 5
freq = 120

[State 3371, 6]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3371, 7] ;Remove Royal Judgement Khybits and P2Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3370

[State 3371, 8] ;Crash Sound
type = PlaySnd
trigger1 = Time = 0
value = 1100, 1

[State 3371, 9]
type = TargetState
trigger1 = Time = 0
value = 3387

[State 3371, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 3372

;Pharaoh Magic - Projectile Helper - Coffin Rising
[Statedef 3372]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3372, 1] ;If this move killed target
type = ParentVarSet
trigger1 = Time = 0
trigger1 = target, Life = 0
v = 5 ;Win Type
value = 2

[State 3372, 2]
type = VelSet
triggerall = Time = 0
trigger1 = target, Life != 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life != 0 || enemynear(1), life != 0
y = -8

[State 3372, 3]
type = ChangeAnim
trigger1 = Time = 0
value = Anim-1

[State 3372, 4] ;Remove Riding Khybit
type = StopSnd
trigger1 = Pos Y <= -240
channel = 1

[State 3372, 5] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Pos Y <= -240
ID = 3426

[State 3372, 6]
type = DestroySelf
trigger1 = Pos Y <= -240

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3365]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3365, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 1

[State 3365, 2]
type = ChangeState
trigger1 = Time = 0
value = 3369

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3366]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3366, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 9

[State 3366, 2]
type = ChangeState
trigger1 = Time = 0
value = 3369

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3367]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3367, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 17

[State 3367, 2]
type = ChangeState
trigger1 = Time = 0
value = 3369

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3368]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3368, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 25

[State 3368, 2]
type = ChangeState
trigger1 = Time = 0
value = 3369

;Pharaoh Magic - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3369]
type = A
movetype = A
ctrl = 0

[State 3369, BindToParent 1]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -4,5

[State 3369, BindToParent 2]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -1,10

[State 3369, BindToParent 3]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 10,-1

[State 3369, BindToParent 4]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 6,19

[State 3369, BindToParent 5]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(5) >= 0 && AnimElemTime(6) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 9,23

[State 3369, BindToParent 6]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 11,25

[State 3369, BindToParent 7]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(7) >= 0 && AnimElemTime(8) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 14,27

[State 3369, BindToParent 8]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(8) >= 0 && AnimElemTime(9) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 16,28

[State 3369, BindToParent 9]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(9) >= 0 && AnimElemTime(10) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 16,26

[State 3369, BindToParent 10]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(10) >= 0 && AnimElemTime(11) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 17,24

[State 3369, BindToParent 11]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(11) >= 0 && AnimElemTime(12) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 17,22

[State 3369, BindToParent 12]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(12) >= 0 && AnimElemTime(13) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 16,18

[State 3369, BindToParent 13]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(13) >= 0 && AnimElemTime(14) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 14,14

[State 3369, BindToParent 14]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(14) >= 0 && AnimElemTime(15) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 13,9

[State 3369, BindToParent 15]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(15) >= 0 && AnimElemTime(16) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 10,4

[State 3369, BindToParent 16]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(16) >= 0 && AnimElemTime(17) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 8,0

[State 3369, BindToParent 17]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(17) >= 0 && AnimElemTime(18) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 4,-4

[State 3369, BindToParent 18]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(18) >= 0 && AnimElemTime(19) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = 1,-9

[State 3369, BindToParent 19]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(19) >= 0 && AnimElemTime(20) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -2,-14

[State 3369, BindToParent 20]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(20) >= 0 && AnimElemTime(21) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -6,-18

[State 3369, BindToParent 21]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(21) >= 0 && AnimElemTime(22) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -9,-22

[State 3369, BindToParent 22]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(22) >= 0 && AnimElemTime(23) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -11,-24

[State 3369, BindToParent 23]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(23) >= 0 && AnimElemTime(24) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -14,-27

[State 3369, BindToParent 24]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(24) >= 0 && AnimElemTime(25) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -16,-28

[State 3369, BindToParent 25]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(25) >= 0 && AnimElemTime(26) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -16,-27

[State 3369, BindToParent 26]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(26) >= 0 && AnimElemTime(27) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -17,-25

[State 3369, BindToParent 27]
type = BindToParent
triggerall r1 = Anim = 3419
triggerall = AnimElemTime(27) >= 0 && AnimElemTime(28) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -17,-23

[State 3369, BindToParent 28]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(28) >= 0 && AnimElemTime(29) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -16,-19

[State 3369, BindToParent 29]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(29) >= 0 && AnimElemTime(30) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -14,-15

[State 3369, BindToParent 30]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(30) >= 0 && AnimElemTime(31) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -13,-10

[State 3369, BindToParent 31]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(31) >= 0 && AnimElemTime(32) < 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -10,-5

[State 3369, BindToParent 32]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(32) >= 0
trigger1 = parent, stateno = 3360
trigger2 = parent, stateno = 3361
pos = -8,0

[State 3369, SprPriority 1]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 5
value = 3

[State 3369, SprPriority 1]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 9
value = 0

[State 3369, SprPriority 2]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 13
value = -1

[State 3369, SprPriority 3]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 17
value = 0

[State 3369, SprPriority 4]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 21
value = 3

[State 3369, SprPriority 5]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 29
value = 4

;[State 3369, PosAdd]
;type = PosAdd
;trigger1 = Anim = 3419
;trigger1 = parent, stateno != 1210
;x = -5 + 27*cos(2*PI*(AnimElemNo(0)+7)/32)
;y = -5 +  5*sin(2*PI*(AnimElemNo(0)+7)/32)

[State 3369, ChangeAnim 2]
type = ChangeAnim
trigger1 = Anim = 3419
trigger1 = parent, stateno != 3360
trigger1 = parent, stateno != 3361
value = 1213

[State 3369, DestroySelf]
type = DestroySelf
trigger1 = Anim = 1213
trigger1 = AnimTime = 0

;Pharaoh Magic - Crushed
[Statedef 3387]
type = L
movetype = H
physics = N
velset = 0,0

[State 3387, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3387, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3387, 3]
type = Turn
trigger1 = Time = 0

[State 3387, 1]
type = LifeAdd
trigger1 = Time = 0
value = -200

[State 3387, 2]
type = ChangeAnim
trigger1 = Time = 0
value = 5110

[State 3387, 3]
type = ChangeState
trigger1 = Time = 57
value = 3348

;========================<PHARAOH SALVATION>=============================
[StateDef 3400]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3400, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3400, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3400, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3400, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3400, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3400, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3400, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3400, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3400, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3400, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3400, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3400, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3405
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3400, 3]
type = ChangeAnim
trigger1 = Anim = 3300
trigger1 = AnimTime = 0
value = 3302

[State 3400, 4] ;Projectile
type = Helper
trigger1 = Anim = 3302
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3410
stateno = 3410

[State 3400, 5] ;Base
type = RemoveExplod
triggerall = Anim = 3302
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3410) = 0
ID = 3405

[State 3400, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3410) = 0
value = 3401

[State 3400, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3410), MoveHit = 1
value = 3402

;Pharaoh Salvation - Miss
[Statedef 3401]
type = S
movetype = I
physics = S
anim = 3301

[State 3401, 1] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3407
sprpriority = 1
removeongethit = 1

[State 3401, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Pharaoh Salvation - Hit
[Statedef 3402]
type = U
movetype = A
physics = N

[State 3402, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3402, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3402, PosFreeze]
type = PosFreeze
trigger1 = 1

[State 3402, Voice] ;Voice
type = PlaySnd
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 2
value = 1130, 0
channel = 0

[State 3402, 1]
type = ChangeAnim
trigger1 = helper(3410), Var(2) <= 7
trigger1 = helper(3410), Var(2) != 2
trigger1 = helper(3410), stateno = 3412
trigger1 = helper(3410), Time = 9
trigger2 = helper(3410), Var(2) = 1 ; Meteor
trigger2 = helper(3410), stateno = 3411
trigger2 = helper(3410), Time = 24
value = ifelse(statetype = A,3402,3302)

[State 3402, 2] ;Base
type = RemoveExplod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
ID = 3405

[State 3402, 3] ;Base
type = Explod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
anim = 3306
ID = 3405
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3402, 4] ;Base
type = RemoveExplod
trigger1 = helper(3410), Var(2) >= 7
trigger1 = AnimTime = 24
ID = 3405

[State 3402, 5]
type = ChangeState
trigger1 = helper(3410), Var(2) >= 7
trigger1 = AnimTime = 24
value = ifelse(statetype=A,3406,3401)

;Pharaoh Salvation - Attempt (Air)
[Statedef 3405]
type = A
movetype = A
physics = N
juggle = 4
poweradd = -1000
ctrl = 0
anim = 3400
sprpriority = 2

[State 3405, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3405, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3405, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3405, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3405, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3405, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3405, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3405, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3405, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-95 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3405, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3405, 1]
type = PosFreeze
trigger1 = 1

[State 3405, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3405, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3405
pos = 0,-floor(Pos Y)
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3405, 3]
type = ChangeAnim
trigger1 = Anim = 3400
trigger1 = AnimTime = 0
value = 3402

[State 3405, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 3405, 4] ;Projectile
type = Helper
trigger1 = Anim = 3402
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3410
stateno = 3410

[State 3405, 5] ;Base
type = RemoveExplod
trigger1 = Anim = 3402
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3410) = 0
ID = 3405

[State 3405, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3410) = 0
value = 3406

[State 3405, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3410), MoveHit = 1
value = 3402

;Pharaoh Salvation - Miss (Air)
[Statedef 3406]
type = A
movetype = I
physics = N
anim = 3401

[State 3406, 1]
type = PosFreeze
trigger1 = 1

[State 3406, 2] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3407
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3406, 3]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 3406, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;Pharaoh Salvation - Projectile Helper
[Statedef 3410]
type = A
movetype = A
physics = N
ctrl = 0
juggle  = 3
anim = 1210
sprpriority = -1

[State 3410, 1]
type = BindToParent
trigger1 = Time = 0
pos = 96,-93

[State 3410, 1]
type = VarSet
trigger1 = Time = 0
v = 2
value = 0

[State 3410, 2]
type = HitDef
trigger1 = Var(2) = 0
trigger1 = Time = 0
attr = A, HP
hitflag = MA-
guardflag = MA
pausetime = 0,10
priority = 1, Miss
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 1215
p2stateno = 3440
numhits = 0
getpower = 0

[State 3410, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3410, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3410, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3410, VelSet 1]
type = VelSet
trigger1 = Time = 0
x = 4
y = 2

[State 3410, 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3415
stateno = 3415

[State 3410, 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3416
stateno = 3416

[State 3410, 5]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3417
stateno = 3417

[State 2210, 6]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3418
stateno = 3418

[State 3410, 7] ;Miss
type = ChangeState
trigger1 = Time > 0
trigger1 = Pos Y >= -30
trigger2 = MoveGuarded
value = 3414

[State 3410, Fire Logo]
type = Explod
trigger1 = Time >= 1
anim = 3440
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Salvation - Projectile Helper - Repeat Trips
[Statedef 3411]
type = A
movetype = A
physics = N

[State 3411, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 3411, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3411, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3411, BindToParent]
type = BindToParent
trigger1 = Time = 0
pos = 96,-93

[State 3411, VelSet 1]
type = VelSet
trigger1 = Var(2) != 1
trigger1 = Time = 0
x = 6
y = 2

[State 3411, VelSet 2]
type = VelSet
trigger1 = Var(2) = 1
trigger1 = Time = 0
x = 6
y = 2

[State 3411, Ghost 1]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3415
stateno = 3415

[State 3411, Ghost 2]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3416
stateno = 3416

[State 3411, Ghost 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3417
stateno = 3417

[State 3411, Ghost 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3418
stateno = 3418

[State 3411, Meteor 1] ;Meteor State
type = TargetState
trigger1 = Var(2) = 1
trigger1 = Time = 0
value = 3442

[State 3411, Meteor 2] ;Meteor State remove Fire Spark
type = RemoveExplod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 4040

[State 3411, Meteor 3] ;Meteor State remove Fire Khybits
type = RemoveExplod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470

[State 3411, Khybit Meteors 1]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470
anim = 3471
pos = -56,0
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3411, Khybit Meteors 2]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470
anim = 3471
pos = 57,0
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3411, Khybit Meteors 3]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470
anim = 3471
pos = -33,-20
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3411, Khybit Meteors 4]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470
anim = 3471
pos = 34,-20
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3411, Meteor Helper] ;Meteor Helper
type = Helper
triggerall = Var(2) = 1
trigger1 = Time = 2
trigger2 = Time = 5
trigger3 = Time = 8
;trigger4 = Time = 11
;trigger5 = Time = 14
;trigger6 = Time = 17
;trigger7 = Time = 20
;trigger8 = Time = 23
pos = 90+Random/20-25,-240
postype = p2
stateno = 3431
ownpal = 1

[State 3411, HitAdd]
type = HitAdd
triggerall = Var(2) = 1
trigger1 = Time = 6
trigger2 = Time = 9
;trigger3 = Time = 12
;trigger4 = Time = 15
;trigger5 = Time = 18
;trigger6 = Time = 21
;trigger7 = Time = 24
value = 1

[State 3411, Throwing Hit] ;Throwing Hit
type = ChangeState
triggerall = Time > 0
trigger1 = Var(2) != 1
trigger1 = facing = 1 && (target, Pos X - Pos X < 30)
trigger1 = Var(2) != 1
trigger2 = facing = -1 && (target, Pos X - Pos X > -30)
trigger3 = Var(2) = 1
trigger3 = Time >= 25
value = 3412

[State 3411, Meteor Logo]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time >= 1
anim = 3441
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3411, Shock Logo]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time >= 1
anim = 3442
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3411, Rock Logo]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time >= 1
anim = 3443
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3411, Gas Logo]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time >= 1
anim = 3444
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3411, Ice Logo]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time >= 1
anim = 3445
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Salvation - Projectile Helper - Target Transformed
[Statedef 3412]
type = A
movetype = A
physics = N
anim = 1214

[State 3412, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3412, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3412, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3412, HitAdd]
type = HitAdd
trigger1 = Time = 0
value = 1

[State 3412, RemoveExplod] ;Remove Previous Khybit Explod
type = RemoveExplod
trigger1 = Time = 0
trigger1 = Var(2) != 1
ID = 3470

[State 3412, Fire 1] ;Fire Spark
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 4040
anim = 4040
postype = p2
sprpriority = 3
ownpal = 1

[State 3412, Fire 2] ;Fire Sound
type = PlaySnd
trigger1 = Var(2) = 0
trigger1 = Time = 0
value = 3300, 1

[State 3412, Fire Khybit Spark 1]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 4041
pos = -54,24-floor(target, Pos Y)
postype = p2
sprpriority = 5
ownpal = 1

[State 3412, Fire Khybit Spark 2]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 4041
pos = 55,24-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5
ownpal = 1

[State 3412, Fire Khybit Spark 3]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 4041
pos = -30,-4-floor(target, Pos Y)
postype = p2
sprpriority = -1
ownpal = 1

[State 3412, Fire Khybit Spark 4]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 4041
pos = 31,-4-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1
ownpal = 1

[State 3412, Fire Khybit 1]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 3470
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Fire Khybit 2]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 3470
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Fire Khybit 3]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 3470
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Fire Khybit 4]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 3470
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Shock 1] ;Shocked Sound
type = PlaySnd
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3300, 2

[State 3412, Shock 2] ;Shocked State
type = TargetState
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3443

[State 3412, Khybit Shocked 1]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3470
anim = 3472
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Shocked 2]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3470
anim = 3472
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Shocked 3]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3470
anim = 3472
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Khybit Shocked 4]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3470
anim = 3472
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Petrified 1] ;Petrified Sound
type = PlaySnd
trigger1 = Var(2) = 3
trigger1 = Time = 0
value = 2,5

[State 3412, Petrified 2] ;Petrified State
type = TargetState
trigger1 = Var(2) = 3
trigger1 = Time = 0
value = 3444

[State 3412, Khybit Petrified Spark 1]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 4018
pos = -108,-94-floor(target, Pos Y)
postype = p2
sprpriority = 5

[State 3412, Khybit Petrified Spark 2]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 4018
pos = 109,-94-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5

[State 3412, Khybit Petrified Spark 3]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 4018
pos = -84,-114-floor(target, Pos Y)
postype = p2
sprpriority = -1

[State 3412, Khybit Petrified Spark 4]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 4018
pos = 84,-114-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1

[State 3412, Khybit Petrified 1]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 3473
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Petrified 2]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 3473
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Petrified 3]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 3474
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Khybit Petrified 4]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 3474
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Gas 1] ;Gas Sound
type = PlaySnd
trigger1 = Var(2) = 4
trigger1 = Time = 0
value = 2,5

[State 3412, Gas 2] ;Gas State
type = TargetState
trigger1 = Var(2) = 4
trigger1 = Time = 0
value = 3445

[State 3412, Khybit Gas 1]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3470
anim = 3475
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Gas 2]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3470
anim = 3475
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Gas 3]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3470
anim = 3476
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Khybit Gas 4]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3470
anim = 3476
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Frozen 1] ;P2 Frozen Special Anim
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = ifelse(target, const(size.height) <= 60,3357,3358)
ID = 3470
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3412, Frozen 2] ;Frozen Sound
type = PlaySnd
trigger1 = Var(2) = 5
trigger1 = Time = 0
value = 3300, 3

[State 3412, Frozen 3] ;Frozen State
type = TargetState
trigger1 = Var(2) = 5
trigger1 = Time = 0
value = 3446

[State 3412, Khybit Frozen 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
ID = 3470
anim = 3477
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Frozen 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
ID = 3470
anim = 3477
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Frozen 3]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
ID = 3470
anim = 3477
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Khybit Frozen 4]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
ID = 3470
anim = 3477
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Big Ice Explod 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4051
pos = -28,-72
postype = p2
vel = -5,-2
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3412, Small Ice Explod 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = -39,-47
postype = p2
vel = -5,0.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3412, Small Ice Explod 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = -2,-91
postype = p2
vel = -0,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3412, Small Ice Explod 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = 20,-48
postype = p2
vel = 5,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3412, Big Ice Explod 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4051
pos = -40,-28
postype = p2
vel = -6,-1
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3412, Big Ice Explod Alt 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4051
pos = -19,-63
postype = p2
vel = -4,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3412, Small Ice Explod Alt 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = 39,-51
postype = p2
vel = 3,1
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3412, Big Ice Explod Alt 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4051
pos = 19,-80
postype = p2
vel = 0.5,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3412, Small Ice Explod Alt 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = 49,-23
postype = p2
vel = 3,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3412, Small Ice Explod Alt 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = -21,-43
postype = p2
vel = -3,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3412, Judgement 1] ;Royal Judgement P2 Anim
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
trigger1 = target, SelfAnimExist(19030) = 0
trigger1 = target, SelfAnimExist(19050) = 0
anim = 50000 + Var(0)*10
ID = 3470
pos = 0,ifelse(Var(0)<0,-51,0)
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3412, Judgement 2] ;Royal Judgement Sound
type = PlaySnd
trigger1 = Var(2) = 6
trigger1 = Time = 0
value = 1200, 1

[State 3412, Judgement 3] ;Royal Judgement State
type = TargetState
trigger1 = Var(2) = 6
trigger1 = Time = 0
value = 3447

[State 3412, Khybit Judgement Spark 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 4016
pos = 62,-50-floor(target, Pos Y)
postype = p2
sprpriority = 5
ownpal = 1

[State 3412, Khybit Judgement Spark 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4016
pos = -61,-50-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Judgement Spark 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 4016
pos = 38,-70-floor(target, Pos Y)
postype = p2
sprpriority = -1
ownpal = 1

[State 3412, Khybit Judgement Spark 4]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 4016
pos = -37,-70-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1
ownpal = 1

[State 3412, Khybit Judgement 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 6011
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Judgement 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 6011
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3412, Khybit Judgement 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 6011
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, Khybit Judgement 4]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 6011
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3412, VelSet]
type = VelSet
trigger1 = parent, Var(2) > 0
trigger1 = Time = 0
x = 0
y = 0

[State 3412, VarSet] ;Increment Count
type = VarSet
trigger1 = Time = 0
v = 2
value = Var(2) + 1

[State 3412, ChangeState 1] ;Throw another projectile
type = ChangeState
trigger1 = Var(2) < 7
trigger1 = parent, stateno = 3402
trigger1 = parent, AnimElem = 7, = 4
trigger2 = Var(2) = 1
trigger2 = Time = 30
value = 3411

[State 3412, ChangeState 2] ;Anakaris interrupted
type = ChangeState
trigger1 = parent, stateno != 3402
value = 3413

[State 3412, ChangeState 3] ;End, go to coffin drop
type = ChangeState
trigger1 = Var(2) >= 7
trigger1 = parent, stateno = 3402
trigger1 = parent, AnimElem = 7, = 2
value = 3420

;Pharaoh Salvation - Projectile Helper - Interrupted
[Statedef 3413]
type = A
movetype = A

[State 3413, 1] ;Remove Previous Khybit Explod
type = RemoveExplod
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
trigger1 = target, Time >= 30
ID = 3470

[State 3413, 2] ;Anakaris interrupted
type = TargetState
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
trigger1 = target, Time >= 30
value = 3430

[State 3413, 3]
type = DestroySelf
trigger1 = Time > 0
trigger1 = target, stateno != [3440,3449]

;Pharaoh Salvation - Projectile Helper - Miss
[Statedef 3414]
type = A
movetype = A

[State 3414, 1]
type = DestroySelf
trigger1 = Time > 0

;Pharaoh Salvation - Projectile Helper - Coffin Falling
[Statedef 3420]
type = A
movetype = A
anim = 3420
ctrl = 0
velset = 0,16
sprpriority = 3

[State 3420, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Random < 100 || parent, command = "holdstart"
value = 3424

[State 3420, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 3424
value = ifelse(Random > 200,3420,3422)

[State 3420, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3424
anim = 3426
ID = 3426
bindtime = -1
removetime = -1

[State 3420, 4] ;Khybit sound
type = PlaySnd
trigger1 = Time = 4
trigger1 = Anim = 3424
value = 3400,0
channel = 1

[State 3420, 5]
type = PosSet
trigger1 = Time = 0
x = target, Pos X
y = -240

[State 3420, 6]
type = ChangeState
trigger1 = Pos Y >= 0
value = 3421

;Pharaoh Salvation - Projectile Helper - Coffin Hitting
[Statedef 3421]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3421, 1]
type = ChangeAnim
trigger1 = Time = 0
value = Anim+1

[State 3421, 2] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Time = 0
ID = 3426

[State 3421, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3425
anim = 3427
ID = 3426
bindtime = -1
removetime = -1

[State 3421, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3421, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3421, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3421, 4]
type = HitAdd
trigger1 = Time = 0
trigger1 = Var(2) != 1
value = 1

[State 3421, 5]
type = EnvShake
trigger1 = Time = 0
time = 16
ampl = 5
freq = 120

[State 3421, 6]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3421, 7] ;Remove Royal Judgement Khybits and P2Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3470

[State 3421, Khybit Flat 1]
type = Explod
trigger1 = Time = 0
ID = 3470
anim = 6014
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3421, Khybit Flat 2]
type = Explod
trigger1 = Time = 0
ID = 3470
anim = 6014
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3421, Khybit Flat 3]
type = Explod
trigger1 = Time = 0
ID = 3470
anim = 6014
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3421, Khybit Flat 4]
type = Explod
trigger1 = Time = 0
ID = 3470
anim = 6014
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3421, 8] ;Crash Sound
type = PlaySnd
trigger1 = Time = 0
value = 1100, 1

[State 3421, 9]
type = TargetState
trigger1 = Time = 0
value = 3448

[State 3421, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 3422

;Pharaoh Salvation - Projectile Helper - Coffin Rising
[Statedef 3422]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3422, 1] ;If this move killed target
type = ParentVarSet
trigger1 = Time = 0
trigger1 = target, Life = 0
v = 5 ;Win Type
value = 2

[State 3422, 2]
type = VelSet
triggerall = Time = 0
trigger1 = target, Life != 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life != 0 || enemynear(1), life != 0
y = -8

[State 3422, 3]
type = ChangeAnim
trigger1 = Time = 0
value = Anim-1

[State 3422, 4] ;Remove Royal Judgement Khybits
type = RemoveExplod
trigger1 = Time = 0
ID = 3470

[State 3422, Random Variable Khybit 1]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3422, Khybit Fade 1]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = 20
sprpriority = 5
ownpal = 1

[State 3422, Khybit Float 1]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3423
pos = -62,16-floor(target, Pos Y)
postype = p2
ownpal = 1

[State 3422, Random Variable Khybit 2]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3422, Khybit Fade 2]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = 20
sprpriority = 5
ownpal = 1

[State 3422, Khybit Float 2]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3423
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
ownpal = 1

[State 3422, Random Variable Khybit 3]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3422, Khybit Fade 3]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = 20
sprpriority = -1
ownpal = 1

[State 3422, Khybit Float 3]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3423
pos = -38,-4-floor(target, Pos Y)
postype = p2
ownpal = 1

[State 3422, Random Variable Khybit 3]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3422, Khybit Fade 4]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = 20
sprpriority = -1
ownpal = 1

[State 3422, Khybit Float 4]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3423
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
ownpal = 1

[State 3422, 5] ;Remove Riding Khybit
type = StopSnd
trigger1 = Pos Y <= -240
channel = 1

[State 3422, 6] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Pos Y <= -240
ID = 3426

[State 3422, 7]
type = DestroySelf
trigger1 = Pos Y <= -240

;Pharaoh Salvation - Squashed Khybit Rising
[Statedef 3423]
type = A
movetype = I
anim = 6016
ctrl = 0
velset = 0,-6.5

[State 2223, 2]
type = ChangeState
trigger1 = Time = 21
value = 3424

;Pharaoh Salvation - Squashed Khybit Floating
[Statedef 3424]
anim = 6017
velset = 0,3

[State 3424, 1]
type = Offset
trigger1 = 1
x = 16*sin(time*2*pi/24)*(-facing)

[State 3424, 2]
type = DestroySelf
trigger1 = Pos Y > -5

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3415]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3415, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 1

[State 3415, 2]
type = ChangeState
trigger1 = Time = 0
value = 3419

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3416]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3416, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 9

[State 3416, 2]
type = ChangeState
trigger1 = Time = 0
value = 3419

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3417]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3417, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 17

[State 3417, 2]
type = ChangeState
trigger1 = Time = 0
value = 3419

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3418]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3418, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 25

[State 3418, 2]
type = ChangeState
trigger1 = Time = 0
value = 3419

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3419]
type = A
movetype = A
ctrl = 0

[State 3419, BindToParent 1]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -4,5

[State 3419, BindToParent 2]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -1,10

[State 3419, BindToParent 3]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 2,15

[State 3419, BindToParent 4]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 6,19

[State 3419, BindToParent 5]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(5) >= 0 && AnimElemTime(6) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 9,23

[State 3419, BindToParent 6]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 11,25

[State 3419, BindToParent 7]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(7) >= 0 && AnimElemTime(8) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 14,27

[State 3419, BindToParent 8]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(8) >= 0 && AnimElemTime(9) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 16,28

[State 3419, BindToParent 9]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(9) >= 0 && AnimElemTime(10) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 16,26

[State 3419, BindToParent 10]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(10) >= 0 && AnimElemTime(11) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 17,24

[State 3419, BindToParent 11]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(11) >= 0 && AnimElemTime(12) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 17,22

[State 3419, BindToParent 12]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(12) >= 0 && AnimElemTime(13) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 16,18

[State 3419, BindToParent 13]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(13) >= 0 && AnimElemTime(14) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 14,14

[State 3419, BindToParent 14]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(14) >= 0 && AnimElemTime(15) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 13,9

[State 3419, BindToParent 15]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(15) >= 0 && AnimElemTime(16) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 10,4

[State 3419, BindToParent 16]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(16) >= 0 && AnimElemTime(17) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 8,0

[State 3419, BindToParent 17]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(17) >= 0 && AnimElemTime(18) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 4,-4

[State 3419, BindToParent 18]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(18) >= 0 && AnimElemTime(19) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = 1,-9

[State 3419, BindToParent 19]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(19) >= 0 && AnimElemTime(20) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -2,-14

[State 3419, BindToParent 20]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(20) >= 0 && AnimElemTime(21) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -6,-18

[State 3419, BindToParent 21]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(21) >= 0 && AnimElemTime(22) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -9,-22

[State 3419, BindToParent 22]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(22) >= 0 && AnimElemTime(23) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -11,-24

[State 3419, BindToParent 23]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(23) >= 0 && AnimElemTime(24) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -14,-27

[State 3419, BindToParent 24]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(24) >= 0 && AnimElemTime(25) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -16,-28

[State 3419, BindToParent 25]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(25) >= 0 && AnimElemTime(26) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -16,-27

[State 3419, BindToParent 26]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(26) >= 0 && AnimElemTime(27) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -17,-25

[State 3419, BindToParent 27]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(27) >= 0 && AnimElemTime(28) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -17,-23

[State 3419, BindToParent 28]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(28) >= 0 && AnimElemTime(29) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -16,-19

[State 3419, BindToParent 29]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(29) >= 0 && AnimElemTime(30) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -14,-15

[State 3419, BindToParent 30]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(30) >= 0 && AnimElemTime(31) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -13,-10

[State 3419, BindToParent 31]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(31) >= 0 && AnimElemTime(32) < 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -10,-5

[State 3419, BindToParent 32]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(32) >= 0
trigger1 = parent, stateno = 3410
trigger2 = parent, stateno = 3411
pos = -8,0

[State 3419, SprPriority 1]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 4
value = 3

[State 3419, SprPriority 2]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 8
value = 0

[State 3419, SprPriority 3]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 12
value = -1

[State 3419, SprPriority 4]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 16
value = 0

[State 3419, SprPriority 5]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 20
value = 3

[State 3419, SprPriority 6]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 28
value = 4

;[State 3419, 3]
;type = PosAdd
;trigger1 = Anim = 1212
;trigger1 = parent, stateno != 2210
;trigger1 = parent, stateno != 2211
;x = -5 + 27*cos(2*PI*(AnimElemNo(0)+7)/32)
;y = -5 +  5*sin(2*PI*(AnimElemNo(0)+7)/32)

[State 3419, 4]
type = ChangeAnim
trigger1 = Anim = 3419
trigger1 = parent, stateno != 3410
trigger1 = parent, stateno != 3411
value = 1213

[State 3419, 5]
type = DestroySelf
trigger1 = Anim = 1213
trigger1 = AnimTime = 0

;Pharaoh Salvation - Hit
[Statedef 3440]
type = S
movetype = H
physics = N
velset = 0,0

[State 3440, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3440, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3440, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5010

[State 3440, 2]
type = LifeAdd
trigger1 = Time = 0
value = -25
kill = 0

[State 3440, 3] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [0,1]
x = 0

[State 3440, 4] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [2,3]
x = -2

[State 3440, 5]
type = ChangeState
trigger1 = Time = 14
value = 3441

;Pharaoh Salvation - Burned
[Statedef 3441]
movetype = H
physics = N
velset = 0,0

[State 3441, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3441, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3441, Hit in Air 1] ;Gravity
type = VelAdd
trigger1 = Pos Y < 0
y = .66

[State 3441, Hit in Air 2]
type = StateTypeSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
trigger2 = StateType = C
statetype = S

[State 3441, Hit in Air 3]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
y = 0

[State 3441, Hit in Air 4]
type = PosSet
trigger1 = Pos Y > 0
y = 0

;[State 3441, 1]
;type = PalFx
;trigger1 = SelfAnimExist(7697) = 0
;time = 1
;add = 176,64,32
;mul = 240,240,128
;color = 0

[State 3441, 2]
type = ChangeAnim
trigger1 = SelfAnimExist(7697) = 1
trigger1 = Time = 0
value = 7697

[State 3441, 3]
type = ChangeAnim2
trigger1 = SelfAnimExist(7697) = 0
trigger1 = Time = 0
value = 3451

;Pharaoh Salvation - Hit by Meteors
[Statedef 3442]
movetype = H
physics = N

[State 3442, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3442, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3442, Hit in Air 1] ;Gravity
type = VelAdd
trigger1 = Pos Y < 0
y = .66

[State 3442, Hit in Air 2]
type = StateTypeSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
trigger2 = StateType = C
statetype = S

[State 3442, Hit in Air 3]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
y = 0

[State 3442, Hit in Air 4]
type = PosSet
trigger1 = Pos Y > 0
y = 0

[State 3442, 1]
type = PalFx
trigger1 = Time = 0
time = 0

[State 3442, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger2 = Time = 19
value = 5001

[State 3442, 3]
type = ChangeAnim
trigger1 = Time = 16
value = 5011

[State 3442, LifeAdd]
type = LifeAdd
trigger1 = Time = 6
trigger2 = Time = 9
trigger3 = Time = 12
;trigger4 = Time = 15
;trigger5 = Time = 18
;trigger6 = Time = 21
;trigger7 = Time = 24
;trigger8 = Time = 27
value = -3
kill = 0

[State 3442, 5] ;Simulate HitShake
type = Offset
triggerall = Time >= 6
triggerall = Time <= 33
trigger1 = Time % 4 = [0,1]
x = 0

[State 3442, 6] ;Simulate HitShake
type = Offset
triggerall = Time >= 6
triggerall = Time <= 33
trigger1 = Time % 4 = [2,3]
x = -2

;Pharaoh Salvation - Shocked
[Statedef 3443]
movetype = H
physics = N

[State 3443, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3443, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3443, Hit in Air 1] ;Gravity
type = VelAdd
trigger1 = Pos Y < 0
y = .66

[State 3443, Hit in Air 2]
type = StateTypeSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
trigger2 = StateType = C
statetype = S

[State 3443, Hit in Air 3]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
y = 0

[State 3443, Hit in Air 4]
type = PosSet
trigger1 = Pos Y > 0
y = 0

[State 3443, 1]
type = LifeAdd
trigger1 = Time = 0
value = -25
kill = 0

[State 3443, 2]
type = PalFx
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time = 0
time = -1
add = 96,80,16
mul = 256,240,128
color = 0

[State 3443, 3]
type = ChangeAnim
trigger1 = SelfAnimExist(7696) = 1
trigger1 = Time = 0
value = 7696

[State 3443, 4]
type = ChangeAnim2
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time = 0
value = 3453

[State 3443, 5] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [0,1]
x = 0

[State 3443, 6] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [2,3]
x = -2

[State 3442, 7] ;Shocking
type = Offset
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time % 4 = [0,1]
x = 0

[State 3442, 8] ;Shocking
type = Offset
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time % 4 = [2,3]
x = -6

;Pharaoh Salvation - Petrified
[Statedef 3444]
type = S
movetype = H
physics = N
velset = 0,0

[State 3444, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3444, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3444, Hit in Air]
type = PosSet
trigger1 = Pos Y > 0
y = 0

[State 3444, 1]
type = LifeAdd
trigger1 = Time = 0
value = -25
kill = 0

[State 3444, 2]
type = PalFx
trigger1 = Time = 0
time = -1
mul = 205,205,205
color = 0

[State 3444, 3]
type = ChangeAnim
trigger1 = SelfAnimExist(195) = 1
value = 195

[State 3444, 4]
type = ChangeAnim
trigger1 = Anim = 195
trigger1 = AnimElemTime(2) != 0
value = 195
elem = 2

[State 3444, 5]
type = ChangeAnim
trigger1 = Anim != 195
value = 0

[State 3444, 6] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [0,1]
x = 0

[State 3444, 7] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [2,3]
x = -2

;Pharaoh Salvation - Gassed
[Statedef 3445]
type = S
movetype = H
physics = N

[State 3445, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3445, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3445, 1]
type = LifeAdd
trigger1 = Time = 0
value = -25
kill = 0

[State 3445, 2]
type = PalFx
trigger1 = Time = 0
time = -1
mul = 188,171,256
color = 0

[State 3445, 3]
type = ChangeAnim
trigger1 = Time <= 12
value = 5300

[State 3445, 4] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [0,1]
x = 0

[State 3445, 5] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [2,3]
x = -2

;Pharaoh Salvation - Frozen
[Statedef 3446]
type = S
movetype = H
physics = N

[State 3446, 1]
type = LifeAdd
trigger1 = Time = 0
value = -25
kill = 0

[State 3446, 2]
type = PalFx
trigger1 = Time = 0
time = 0

[State 3446, 3]
type = ChangeAnim2
trigger1 = Time = 0
value = 3356

;Pharaoh Salvation - Royal Judgement Transformed
[Statedef 3447]
type = S
movetype = H
physics = N

[State 3447, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3447, 2]
type = PlayerPush
trigger1 = 1
value = 0

[State 3447, 3]
type = LifeAdd
trigger1 = Time = 0
value = -25
kill = 0

[State 3447, 4]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19030) = 1
trigger1 = SelfAnimExist(19050) = 0
value = 19030

[State 3447, 5] ;Royal Judgement P2 Anim
type = Explod
trigger1 = Time = 0
trigger1 = SelfAnimExist(19050) = 1
anim = 19050
ID = 3457
pos = 0,-51
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3447, 6]
type = ChangeAnim2
triggerall = Time = 0
trigger1 = SelfAnimExist(19030) = 0
trigger2 = SelfAnimExist(19050) = 1
value = 3457

[State 3447, 7]
type = PlaySnd
triggerall = Time = 0
trigger1 = SelfAnimExist(19030) = 1
trigger2 = SelfAnimExist(19050) = 1
value = 19030,0

[State 3447, 8] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [0,1]
x = 0

[State 3447, 9] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [2,3]
x = -2

;Pharaoh Salvation - Crushed
[Statedef 3448]
type = L
movetype = H
physics = N
velset = 0,0

[State 2257, 1] ;Royal Judgement P2 Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3457

[State 3448, 2]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3448, 3]
type = LifeAdd
trigger1 = Time = 0
value = -100

[State 3448, 4]
type = ChangeAnim
trigger1 = Time = 0
value = 5110

[State 3448, 5]
type = Turn
trigger1 = Time = 0

[State 3448, 6]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3448, 7]
type = PlayerPush
trigger1 = 1
value = 0

[State 3448, 8]
type = ChangeState
trigger1 = Time = 57
value = 3449

;Pharaoh Salvation - Target End Custom Hit State
[Statedef 3449]
type = L
movetype = H
physics = N
velset = 0,0

[State 3449, 1]
type = SelfState
trigger1 = Life = 0
value = 5150

[State 3449, 2]
type = SelfState
trigger1 = 1
value = 5120

;Pharaoh Salvation - End Custom Hit State Early
[Statedef 3430]
movetype = H
physics = N
velset = 0,0

[State 3430, 1]
type = PalFX
trigger1 = Time = 0
time = 0

[State 3430, 2]
type = SelfState
trigger1 = Life = 0
value = 5150

[State 3430, 3]
type = SelfState
trigger1 = 1
value = ifelse(Pos Y < 0,5050,0)
ctrl = ifelse(Pos Y < 0,0,1)

;Pharaoh Salvation - Meteor
[Statedef 3431]
type = A
movetype = A
anim = 3460
velset = -12,24
sprpriority = 5

[State 3431, 1]
type = PlaySnd
trigger1 = Time = 4
value = 2,6
channel = 1

[State 3431, 2]
type = DestroySelf
trigger1 = Pos Y >= 0

;========================<MAX PHARAOH SALVATION>=============================
[StateDef 3450]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3450, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3450, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3450, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3450, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3450, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3450, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3450, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3450, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3450, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3450, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3450, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3450, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3405
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3450, 3]
type = ChangeAnim
trigger1 = Anim = 3300
trigger1 = AnimTime = 0
value = 3302

[State 3450, 4] ;Projectile
type = Helper
trigger1 = Anim = 3302
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3460
stateno = 3460

[State 3450, 5] ;Base
type = RemoveExplod
triggerall = Anim = 3302
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3460) = 0
ID = 3405

[State 3450, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3460) = 0
value = 3451

[State 3450, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3460), MoveHit = 1
value = 3452

;Pharaoh Salvation - Miss
[Statedef 3451]
type = S
movetype = I
physics = S
anim = 3301

[State 3451, 1] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3407
sprpriority = 1
removeongethit = 1

[State 3451, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Pharaoh Salvation - Hit
[Statedef 3452]
type = U
movetype = A
physics = N

[State 3452, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3452, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3452, PosFreeze]
type = PosFreeze
trigger1 = 1

[State 3452, Voice] ;Voice
type = PlaySnd
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 2
value = 1130, 0
channel = 0

[State 3452, 1]
type = ChangeAnim
trigger1 = helper(3460), Var(2) <= 7
trigger1 = helper(3460), Var(2) != 2
trigger1 = helper(3460), stateno = 3462
trigger1 = helper(3460), Time = 9
trigger2 = helper(3460), Var(2) = 1 ; Meteor
trigger2 = helper(3460), stateno = 3461
trigger2 = helper(3460), Time = 24
value = ifelse(statetype = A,3402,3302)

[State 3452, 2] ;Base
type = RemoveExplod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
ID = 3405

[State 3452, 3] ;Base
type = Explod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
anim = 3306
ID = 3405
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3452, 4] ;Base
type = RemoveExplod
trigger1 = helper(3460), Var(2) >= 7
trigger1 = AnimTime = 24
ID = 3405

[State 3452, 5]
type = ChangeState
trigger1 = helper(3460), Var(2) >= 7
trigger1 = AnimTime = 24
value = ifelse(statetype=A,3456,3451)

;Pharaoh Salvation - Attempt (Air)
[Statedef 3455]
type = A
movetype = A
physics = N
juggle = 4
poweradd = -2000
ctrl = 0
anim = 3400
sprpriority = 2

[State 3455, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3455, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3455, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3455, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3455, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3455, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3455, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3455, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3455, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-95 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3455, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3455, 1]
type = PosFreeze
trigger1 = 1

[State 3455, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3455, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3405
pos = 0,-floor(Pos Y)
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3455, 3]
type = ChangeAnim
trigger1 = Anim = 3400
trigger1 = AnimTime = 0
value = 3402

[State 3455, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 3455, 4] ;Projectile
type = Helper
trigger1 = Anim = 3402
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3460
stateno = 3460

[State 3455, 5] ;Base
type = RemoveExplod
trigger1 = Anim = 3402
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3460) = 0
ID = 3405

[State 3455, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3460) = 0
value = 3456

[State 3405, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3460), MoveHit = 1
value = 3452

;Pharaoh Salvation - Miss (Air)
[Statedef 3456]
type = A
movetype = I
physics = N
anim = 3401

[State 3456, 1]
type = PosFreeze
trigger1 = 1

[State 3456, 2] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3407
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3456, 3]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 3456, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;Pharaoh Salvation - Projectile Helper
[Statedef 3460]
type = A
movetype = A
physics = N
ctrl = 0
juggle  = 3
anim = 1210
sprpriority = -1

[State 3460, 1]
type = BindToParent
trigger1 = Time = 0
pos = 96,-93

[State 3460, 1]
type = VarSet
trigger1 = Time = 0
v = 2
value = 0

[State 3460, 2]
type = HitDef
trigger1 = Var(2) = 0
trigger1 = Time = 0
attr = A, HP
hitflag = MA-
guardflag = MA
pausetime = 0,10
priority = 1, Miss
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 1215
p2stateno = 3440
numhits = 0
getpower = 0

[State 3460, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3460, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3460, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3460, VelSet 1]
type = VelSet
trigger1 = Time = 0
x = 4
y = 2

[State 3460, 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3465
stateno = 3465

[State 3460, 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3466
stateno = 3466

[State 3460, 5]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3467
stateno = 3467

[State 3360, 6]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3468
stateno = 3468

[State 3460, 7] ;Miss
type = ChangeState
trigger1 = Time > 0
trigger1 = Pos Y >= -30
trigger2 = MoveGuarded
value = 3464

[State 3460, Fire Logo]
type = Explod
trigger1 = Time >= 1
anim = 3440
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Salvation - Projectile Helper - Repeat Trips
[Statedef 3461]
type = A
movetype = A
physics = N

[State 3461, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 3461, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3461, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3461, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 3461, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3461, BindToParent]
type = BindToParent
trigger1 = Time = 0
pos = 96,-93

[State 3461, VelSet 1]
type = VelSet
trigger1 = Var(2) != 1
trigger1 = Time = 0
x = 6
y = 2

[State 3461, VelSet 2]
type = VelSet
trigger1 = Var(2) = 1
trigger1 = Time = 0
x = 6
y = 2

[State 3461, Ghost 1]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3465
stateno = 3465

[State 3461, Ghost 2]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3466
stateno = 3466

[State 3461, Ghost 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3467
stateno = 3467

[State 3461, Ghost 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3468
stateno = 3468

[State 3461, Meteor 1] ;Meteor State
type = TargetState
trigger1 = Var(2) = 1
trigger1 = Time = 0
value = 3482

[State 3461, Meteor 2] ;Meteor State remove Fire Spark
type = RemoveExplod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 4040

[State 3461, Meteor 3] ;Meteor State remove Fire Khybits
type = RemoveExplod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470

[State 3461, Khybit Meteors 1]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470
anim = 3471
pos = -56,0
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3461, Khybit Meteors 2]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470
anim = 3471
pos = 57,0
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3461, Khybit Meteors 3]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470
anim = 3471
pos = -33,-20
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3461, Khybit Meteors 4]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time = 6
ID = 3470
anim = 3471
pos = 34,-20
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3461, Meteor Helper] ;Meteor Helper
type = Helper
triggerall = Var(2) = 1
trigger1 = Time = 2
trigger2 = Time = 5
trigger3 = Time = 8
trigger4 = Time = 11
trigger5 = Time = 14
trigger6 = Time = 17
trigger7 = Time = 20
trigger8 = Time = 23
pos = 90+Random/20-25,-240
postype = p2
stateno = 3431
ownpal = 1

[State 3461, HitAdd]
type = HitAdd
triggerall = Var(2) = 1
trigger1 = Time = 6
trigger2 = Time = 9
trigger3 = Time = 12
trigger4 = Time = 15
trigger5 = Time = 18
trigger6 = Time = 21
trigger7 = Time = 24
value = 1

[State 3461, Throwing Hit] ;Throwing Hit
type = ChangeState
triggerall = Time > 0
trigger1 = Var(2) != 1
trigger1 = facing = 1 && (target, Pos X - Pos X < 30)
trigger1 = Var(2) != 1
trigger2 = facing = -1 && (target, Pos X - Pos X > -30)
trigger3 = Var(2) = 1
trigger3 = Time >= 25
value = 3462

[State 3461, Meteor Logo]
type = Explod
trigger1 = Var(2) = 1
trigger1 = Time >= 1
anim = 3441
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3461, Shock Logo]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time >= 1
anim = 3442
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3461, Rock Logo]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time >= 1
anim = 3443
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3461, Gas Logo]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time >= 1
anim = 3444
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3461, Ice Logo]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time >= 1
anim = 3445
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Salvation - Projectile Helper - Target Transformed
[Statedef 3462]
type = A
movetype = A
physics = N
anim = 1214

[State 3462, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3462, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3462, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3462, HitAdd]
type = HitAdd
trigger1 = Time = 0
value = 1

[State 3462, RemoveExplod] ;Remove Previous Khybit Explod
type = RemoveExplod
trigger1 = Time = 0
trigger1 = Var(2) != 1
ID = 3470

[State 3462, Fire 1] ;Fire Spark
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 4040
anim = 4040
postype = p2
sprpriority = 3
ownpal = 1

[State 3462, Fire 2] ;Fire Sound
type = PlaySnd
trigger1 = Var(2) = 0
trigger1 = Time = 0
value = 3300, 1

[State 3462, Fire Khybit Spark 1]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 4041
pos = -54,24-floor(target, Pos Y)
postype = p2
sprpriority = 5
ownpal = 1

[State 3462, Fire Khybit Spark 2]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 4041
pos = 55,24-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5
ownpal = 1

[State 3462, Fire Khybit Spark 3]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 4041
pos = -30,-4-floor(target, Pos Y)
postype = p2
sprpriority = -1
ownpal = 1

[State 3462, Fire Khybit Spark 4]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 4041
pos = 31,-4-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1
ownpal = 1

[State 3462, Fire Khybit 1]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 3470
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Fire Khybit 2]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 3470
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Fire Khybit 3]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 3470
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Fire Khybit 4]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3470
anim = 3470
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Shock 1] ;Shocked Sound
type = PlaySnd
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3300, 2

[State 3462, Shock 2] ;Shocked State
type = TargetState
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3443

[State 3462, Khybit Shocked 1]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3470
anim = 3472
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Shocked 2]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3470
anim = 3472
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Shocked 3]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3470
anim = 3472
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Khybit Shocked 4]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3470
anim = 3472
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Petrified 1] ;Petrified Sound
type = PlaySnd
trigger1 = Var(2) = 3
trigger1 = Time = 0
value = 2,5

[State 3462, Petrified 2] ;Petrified State
type = TargetState
trigger1 = Var(2) = 3
trigger1 = Time = 0
value = 3444

[State 3462, Khybit Petrified Spark 1]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 4018
pos = -108,-94-floor(target, Pos Y)
postype = p2
sprpriority = 5

[State 3462, Khybit Petrified Spark 2]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 4018
pos = 109,-94-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5

[State 3462, Khybit Petrified Spark 3]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 4018
pos = -84,-114-floor(target, Pos Y)
postype = p2
sprpriority = -1

[State 3462, Khybit Petrified Spark 4]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 4018
pos = 84,-114-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1

[State 3462, Khybit Petrified 1]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 3473
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Petrified 2]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 3473
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Petrified 3]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 3474
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Khybit Petrified 4]
type = Explod
trigger1 = Var(2) = 3
trigger1 = Time = 0
ID = 3470
anim = 3474
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Gas 1] ;Gas Sound
type = PlaySnd
trigger1 = Var(2) = 4
trigger1 = Time = 0
value = 2,5

[State 3462, Gas 2] ;Gas State
type = TargetState
trigger1 = Var(2) = 4
trigger1 = Time = 0
value = 3445

[State 3462, Khybit Gas 1]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3470
anim = 3475
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Gas 2]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3470
anim = 3475
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Gas 3]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3470
anim = 3476
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Khybit Gas 4]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3470
anim = 3476
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Frozen 1] ;P2 Frozen Special Anim
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = ifelse(target, const(size.height) <= 60,3357,3358)
ID = 3470
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3462, Frozen 2] ;Frozen Sound
type = PlaySnd
trigger1 = Var(2) = 5
trigger1 = Time = 0
value = 3300, 3

[State 3462, Frozen 3] ;Frozen State
type = TargetState
trigger1 = Var(2) = 5
trigger1 = Time = 0
value = 3446

[State 3462, Khybit Frozen 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
ID = 3470
anim = 3477
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Frozen 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
ID = 3470
anim = 3477
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Frozen 3]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
ID = 3470
anim = 3477
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Khybit Frozen 4]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
ID = 3470
anim = 3477
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Big Ice Explod 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4051
pos = -28,-72
postype = p2
vel = -5,-2
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3462, Small Ice Explod 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = -39,-47
postype = p2
vel = -5,0.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3462, Small Ice Explod 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = -2,-91
postype = p2
vel = -0,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3462, Small Ice Explod 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = 20,-48
postype = p2
vel = 5,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3462, Big Ice Explod 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4051
pos = -40,-28
postype = p2
vel = -6,-1
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3462, Big Ice Explod Alt 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4051
pos = -19,-63
postype = p2
vel = -4,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3462, Small Ice Explod Alt 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = 39,-51
postype = p2
vel = 3,1
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3462, Big Ice Explod Alt 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4051
pos = 19,-80
postype = p2
vel = 0.5,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3462, Small Ice Explod Alt 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = 49,-23
postype = p2
vel = 3,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3462, Small Ice Explod Alt 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4050
pos = -21,-43
postype = p2
vel = -3,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3462, Judgement 1] ;Royal Judgement P2 Anim
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
trigger1 = target, SelfAnimExist(19030) = 0
trigger1 = target, SelfAnimExist(19050) = 0
anim = 50000 + Var(0)*10
ID = 3470
pos = 0,ifelse(Var(0)<0,-51,0)
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3462, Judgement 2] ;Royal Judgement Sound
type = PlaySnd
trigger1 = Var(2) = 6
trigger1 = Time = 0
value = 1200, 1

[State 3462, Judgement 3] ;Royal Judgement State
type = TargetState
trigger1 = Var(2) = 6
trigger1 = Time = 0
value = 3447

[State 3462, Khybit Judgement Spark 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 4016
pos = 62,-50-floor(target, Pos Y)
postype = p2
sprpriority = 5
ownpal = 1

[State 3462, Khybit Judgement Spark 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4016
pos = -61,-50-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Judgement Spark 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 4016
pos = 38,-70-floor(target, Pos Y)
postype = p2
sprpriority = -1
ownpal = 1

[State 3462, Khybit Judgement Spark 4]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 4016
pos = -37,-70-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1
ownpal = 1

[State 3462, Khybit Judgement 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 6011
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Judgement 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 6011
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3462, Khybit Judgement 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 6011
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, Khybit Judgement 4]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3470
anim = 6011
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3462, VelSet]
type = VelSet
trigger1 = parent, Var(2) > 0
trigger1 = Time = 0
x = 0
y = 0

[State 3462, VarSet] ;Increment Count
type = VarSet
trigger1 = Time = 0
v = 2
value = Var(2) + 1

[State 3462, ChangeState 1] ;Throw another projectile
type = ChangeState
trigger1 = Var(2) < 7
trigger1 = parent, stateno = 3452
trigger1 = parent, AnimElem = 7, = 4
trigger2 = Var(2) = 1
trigger2 = Time = 30
value = 3461

[State 3462, ChangeState 2] ;Anakaris interrupted
type = ChangeState
trigger1 = parent, stateno != 3452
value = 3463

[State 3462, ChangeState 3] ;End, go to coffin drop
type = ChangeState
trigger1 = Var(2) >= 7
trigger1 = parent, stateno = 3452
trigger1 = parent, AnimElem = 7, = 2
value = 3470

;Pharaoh Salvation - Projectile Helper - Interrupted
[Statedef 3463]
type = A
movetype = A

[State 3463, 1] ;Remove Previous Khybit Explod
type = RemoveExplod
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
trigger1 = target, Time >= 30
ID = 3470

[State 3463, 2] ;Anakaris interrupted
type = TargetState
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
trigger1 = target, Time >= 30
value = 3430

[State 3463, 3]
type = DestroySelf
trigger1 = Time > 0
trigger1 = target, stateno != [3440,3449]

;Pharaoh Salvation - Projectile Helper - Miss
[Statedef 3464]
type = A
movetype = A

[State 3464, 1]
type = DestroySelf
trigger1 = Time > 0

;Pharaoh Salvation - Projectile Helper - Coffin Falling
[Statedef 3470]
type = A
movetype = A
anim = 3420
ctrl = 0
velset = 0,16
sprpriority = 3

[State 3470, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Random < 100 || parent, command = "holdstart"
value = 3424

[State 3470, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 3424
value = ifelse(Random > 200,3420,3422)

[State 3470, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3424
anim = 3426
ID = 3426
bindtime = -1
removetime = -1

[State 3470, 4] ;Khybit sound
type = PlaySnd
trigger1 = Time = 4
trigger1 = Anim = 3424
value = 3400,0
channel = 1

[State 3470, 5]
type = PosSet
trigger1 = Time = 0
x = target, Pos X
y = -240

[State 3470, 6]
type = ChangeState
trigger1 = Pos Y >= 0
value = 3471

;Pharaoh Salvation - Projectile Helper - Coffin Hitting
[Statedef 3471]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3471, 1]
type = ChangeAnim
trigger1 = Time = 0
value = Anim+1

[State 3471, 2] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Time = 0
ID = 3426

[State 3471, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3425
anim = 3427
ID = 3426
bindtime = -1
removetime = -1

[State 3471, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3471, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3471, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3471, 4]
type = HitAdd
trigger1 = Time = 0
trigger1 = Var(2) != 1
value = 1

[State 3471, 5]
type = EnvShake
trigger1 = Time = 0
time = 16
ampl = 5
freq = 120

[State 3471, 6]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3471, 7] ;Remove Royal Judgement Khybits and P2Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3470

[State 3471, Khybit Flat 1]
type = Explod
trigger1 = Time = 0
ID = 3470
anim = 6014
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3471, Khybit Flat 2]
type = Explod
trigger1 = Time = 0
ID = 3470
anim = 6014
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3471, Khybit Flat 3]
type = Explod
trigger1 = Time = 0
ID = 3470
anim = 6014
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3471, Khybit Flat 4]
type = Explod
trigger1 = Time = 0
ID = 3470
anim = 6014
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3471, 8] ;Crash Sound
type = PlaySnd
trigger1 = Time = 0
value = 1100, 1

[State 3471, 9]
type = TargetState
trigger1 = Time = 0
value = 3488

[State 3471, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 3472

;Pharaoh Salvation - Projectile Helper - Coffin Rising
[Statedef 3472]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3472, 1] ;If this move killed target
type = ParentVarSet
trigger1 = Time = 0
trigger1 = target, Life = 0
v = 5 ;Win Type
value = 2

[State 3472, 2]
type = VelSet
triggerall = Time = 0
trigger1 = target, Life != 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life != 0 || enemynear(1), life != 0
y = -8

[State 3472, 3]
type = ChangeAnim
trigger1 = Time = 0
value = Anim-1

[State 3472, 4] ;Remove Royal Judgement Khybits
type = RemoveExplod
trigger1 = Time = 0
ID = 3470

[State 3472, Random Variable Khybit 1]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3472, Khybit Fade 1]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = 20
sprpriority = 5
ownpal = 1

[State 3472, Khybit Float 1]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3473
pos = -62,16-floor(target, Pos Y)
postype = p2
ownpal = 1

[State 3472, Random Variable Khybit 2]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3472, Khybit Fade 2]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = 20
sprpriority = 5
ownpal = 1

[State 3472, Khybit Float 2]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3473
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
ownpal = 1

[State 3472, Random Variable Khybit 3]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3472, Khybit Fade 3]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = 20
sprpriority = -1
ownpal = 1

[State 3472, Khybit Float 3]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3473
pos = -38,-4-floor(target, Pos Y)
postype = p2
ownpal = 1

[State 3472, Random Variable Khybit 3]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3472, Khybit Fade 4]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = 20
sprpriority = -1
ownpal = 1

[State 3472, Khybit Float 4]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3473
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
ownpal = 1

[State 3472, 5] ;Remove Riding Khybit
type = StopSnd
trigger1 = Pos Y <= -240
channel = 1

[State 3472, 6] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Pos Y <= -240
ID = 3426

[State 3472, 7]
type = DestroySelf
trigger1 = Pos Y <= -240

;Pharaoh Salvation - Squashed Khybit Rising
[Statedef 3473]
type = A
movetype = I
anim = 6016
ctrl = 0
velset = 0,-6.5

[State 2273, 2]
type = ChangeState
trigger1 = Time = 21
value = 3474

;Pharaoh Salvation - Squashed Khybit Floating
[Statedef 3474]
anim = 6017
velset = 0,3

[State 3474, 1]
type = Offset
trigger1 = 1
x = 16*sin(time*2*pi/24)*(-facing)

[State 3474, 2]
type = DestroySelf
trigger1 = Pos Y > -5

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3465]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3465, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 1

[State 3465, 2]
type = ChangeState
trigger1 = Time = 0
value = 3469

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3466]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3466, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 9

[State 3466, 2]
type = ChangeState
trigger1 = Time = 0
value = 3469

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3467]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3467, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 17

[State 3467, 2]
type = ChangeState
trigger1 = Time = 0
value = 3469

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3468]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3468, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 25

[State 3468, 2]
type = ChangeState
trigger1 = Time = 0
value = 3469

;Pharaoh Salvation - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3469]
type = A
movetype = A
ctrl = 0

[State 3419, BindToParent 1]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -4,5

[State 3469, BindToParent 2]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -1,10

[State 3469, BindToParent 3]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 2,15

[State 3469, BindToParent 4]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 6,19

[State 3469, BindToParent 5]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(5) >= 0 && AnimElemTime(6) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 9,23

[State 3469, BindToParent 6]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 11,25

[State 3469, BindToParent 7]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(7) >= 0 && AnimElemTime(8) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 14,27

[State 3469, BindToParent 8]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(8) >= 0 && AnimElemTime(9) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 16,28

[State 3469, BindToParent 9]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(9) >= 0 && AnimElemTime(10) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 16,26

[State 3469, BindToParent 10]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(10) >= 0 && AnimElemTime(11) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 17,24

[State 3469, BindToParent 11]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(11) >= 0 && AnimElemTime(12) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 17,22

[State 3469, BindToParent 12]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(12) >= 0 && AnimElemTime(13) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 16,18

[State 3469, BindToParent 13]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(13) >= 0 && AnimElemTime(14) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 14,14

[State 3469, BindToParent 14]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(14) >= 0 && AnimElemTime(15) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 13,9

[State 3469, BindToParent 15]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(15) >= 0 && AnimElemTime(16) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 10,4

[State 3469, BindToParent 16]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(16) >= 0 && AnimElemTime(17) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 8,0

[State 3469, BindToParent 17]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(17) >= 0 && AnimElemTime(18) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 4,-4

[State 3469, BindToParent 18]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(18) >= 0 && AnimElemTime(19) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = 1,-9

[State 3469, BindToParent 19]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(19) >= 0 && AnimElemTime(20) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -2,-14

[State 3469, BindToParent 20]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(20) >= 0 && AnimElemTime(21) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -6,-18

[State 3469, BindToParent 21]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(21) >= 0 && AnimElemTime(22) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -9,-22

[State 3469, BindToParent 22]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(22) >= 0 && AnimElemTime(23) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -11,-24

[State 3469, BindToParent 23]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(23) >= 0 && AnimElemTime(24) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -14,-27

[State 3469, BindToParent 24]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(24) >= 0 && AnimElemTime(25) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -16,-28

[State 3469, BindToParent 25]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(25) >= 0 && AnimElemTime(26) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -16,-27

[State 3469, BindToParent 26]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(26) >= 0 && AnimElemTime(27) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -17,-25

[State 3469, BindToParent 27]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(27) >= 0 && AnimElemTime(28) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -17,-23

[State 3469, BindToParent 28]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(28) >= 0 && AnimElemTime(29) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -16,-19

[State 3469, BindToParent 29]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(29) >= 0 && AnimElemTime(30) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -14,-15

[State 3469, BindToParent 30]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(30) >= 0 && AnimElemTime(31) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -13,-10

[State 3469, BindToParent 31]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(31) >= 0 && AnimElemTime(32) < 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -10,-5

[State 3469, BindToParent 32]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(32) >= 0
trigger1 = parent, stateno = 3460
trigger2 = parent, stateno = 3461
pos = -8,0

[State 3469, SprPriority 1]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 4
value = 3

[State 3469, SprPriority 2]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 8
value = 0

[State 3469, SprPriority 3]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 12
value = -1

[State 3469, SprPriority 4]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 16
value = 0

[State 3469, SprPriority 5]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 20
value = 3

[State 3469, SprPriority 6]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 28
value = 4

;[State 3469, 3]
;type = PosAdd
;trigger1 = Anim = 1212
;trigger1 = parent, stateno != 2210
;trigger1 = parent, stateno != 2211
;x = -5 + 27*cos(2*PI*(AnimElemNo(0)+7)/32)
;y = -5 +  5*sin(2*PI*(AnimElemNo(0)+7)/32)

[State 3469, 4]
type = ChangeAnim
trigger1 = Anim = 3419
trigger1 = parent, stateno != 3460
trigger1 = parent, stateno != 3461
value = 1213

[State 3469, 5]
type = DestroySelf
trigger1 = Anim = 1213
trigger1 = AnimTime = 0

;Pharaoh Salvation - Hit by Meteors
[Statedef 3482]
movetype = H
physics = N

[State 3482, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3482, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3482, Hit in Air 1] ;Gravity
type = VelAdd
trigger1 = Pos Y < 0
y = .66

[State 3482, Hit in Air 2]
type = StateTypeSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
trigger2 = StateType = C
statetype = S

[State 3482, Hit in Air 3]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
y = 0

[State 3482, Hit in Air 4]
type = PosSet
trigger1 = Pos Y > 0
y = 0

[State 3482, 1]
type = PalFx
trigger1 = Time = 0
time = 0

[State 3482, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger2 = Time = 19
value = 5001

[State 3482, 3]
type = ChangeAnim
trigger1 = Time = 16
value = 5011

[State 3482, LifeAdd]
type = LifeAdd
trigger1 = Time = 6
trigger2 = Time = 9
trigger3 = Time = 12
trigger4 = Time = 15
trigger5 = Time = 18
trigger6 = Time = 21
trigger7 = Time = 24
trigger8 = Time = 27
value = -1
kill = 0

[State 3482, 5] ;Simulate HitShake
type = Offset
triggerall = Time >= 6
triggerall = Time <= 33
trigger1 = Time % 4 = [0,1]
x = 0

[State 3482, 6] ;Simulate HitShake
type = Offset
triggerall = Time >= 6
triggerall = Time <= 33
trigger1 = Time % 4 = [2,3]
x = -2

;Pharaoh Salvation - Crushed
[Statedef 3488]
type = L
movetype = H
physics = N
velset = 0,0

[State 3488, 1] ;Royal Judgement P2 Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3457

[State 3488, 2]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3488, 3]
type = LifeAdd
trigger1 = Time = 0
value = -200

[State 3488, 4]
type = ChangeAnim
trigger1 = Time = 0
value = 5110

[State 3488, 5]
type = Turn
trigger1 = Time = 0

[State 3488, 6]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3488, 7]
type = PlayerPush
trigger1 = 1
value = 0

[State 3488, 8]
type = ChangeState
trigger1 = Time = 57
value = 3449

;========================<PHARAOH DECORATION>=============================
[StateDef 3500]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3500, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3500, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3500, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3500, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3500, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3500, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3500, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3500, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3500, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3500, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3500, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3500, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3505
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3500, 3]
type = ChangeAnim
trigger1 = Anim = 3300
trigger1 = AnimTime = 0
value = 3302

[State 3500, 4] ;Projectile
type = Helper
trigger1 = Anim = 3302
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3510
stateno = 3510

[State 3500, 5] ;Base
type = RemoveExplod
triggerall = Anim = 3302
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3510) = 0
ID = 3505

[State 3500, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3510) = 0
value = 3501

[State 3500, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3510), MoveHit = 1
value = 3502

;Pharaoh Decoration - Miss
[Statedef 3501]
type = S
movetype = I
physics = S
anim = 3301

[State 3501, 1] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3507
sprpriority = 1
removeongethit = 1

[State 3501, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Pharaoh Decoration - Hit
[Statedef 3502]
type = U
movetype = A
physics = N

[State 3502, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3502, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3502, PosFreeze]
type = PosFreeze
trigger1 = 1

[State 3502, Voice] ;Voice
type = PlaySnd
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 2
value = 1130, 0
channel = 0

[State 3502, 1]
type = ChangeAnim
trigger1 = helper(3510), Var(2) <= 3
trigger1 = helper(3510), stateno = 3512
trigger1 = helper(3510), Time = 9
value = ifelse(statetype = A,3402,3302)

[State 3502, 2] ;Base
type = RemoveExplod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
ID = 3505

[State 3502, 3] ;Base
type = Explod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
anim = 3306
ID = 3505
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3502, 4] ;Base
type = RemoveExplod
trigger1 = helper(3510), Var(2) >= 3
trigger1 = AnimTime = 24
ID = 3505

[State 3502, 5]
type = ChangeState
trigger1 = helper(3510), Var(2) >= 3
trigger1 = AnimTime = 24
value = ifelse(statetype=A,3506,3501)

;Pharaoh Decoration - Attempt
[Statedef 3505]
type = A
movetype = A
physics = N
juggle  = 4
poweradd= -1000
ctrl = 0
anim = 3400
sprpriority = 2

[State 3505, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3505, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3505, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3505, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3505, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3505, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3505, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3505, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3505, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-95 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3505, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3505, 1]
type = PosFreeze
trigger1 = 1

[State 3505, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3505, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3505
pos = 0,-floor(Pos Y)
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3505, 3]
type = ChangeAnim
trigger1 = Anim = 3400
trigger1 = AnimTime = 0
value = 3402

[State 3505, 4] ;Projectile
type = Helper
trigger1 = Anim = 3402
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3510
stateno = 3510

[State 3505, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 3505, 5] ;Base
type = RemoveExplod
trigger1 = Anim = 3402
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3510) = 0
ID = 3505

[State 3505, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3510) = 0
value = 3506

[State 3505, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3510), MoveHit = 1
value = 3502

;Pharaoh Decoration - Miss (Air)
[Statedef 3506]
type = A
movetype = I
physics = N
anim = 3401

[State 3506, 1]
type = PosFreeze
trigger1 = 1

[State 3506, 2] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3507
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3506, 4]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 3506, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;Pharaoh Decoration - Projectile Helper
[Statedef 3510]
type = A
movetype = A
physics = N
ctrl = 0
juggle = 3
anim = 1210
sprpriority = -1

[State 3510, 1]
type = BindToParent
trigger1 = Time = 0
pos = 96,-93

[State 3510, 2]
type = VarSet
trigger1 = Time = 0
v = 2
value = 0

[State 3510, 3]
type = HitDef
trigger1 = Var(2) = 0
trigger1 = Time = 0
attr = A, HP
hitflag = MA-
guardflag = MA
pausetime = 0,10
priority = 1, Miss
hitSound = -1 + 0 * (var(31) := 6)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 1215
p2stateno = 3540
numhits = 0
getpower = 0

[State 3510, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3510, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3510, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3510, VelSet 1]
type = VelSet
trigger1 = Time = 0
x = 4
y = 2

[State 3510, 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3516
stateno = 3515

[State 3510, 5]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3516
stateno = 3516

[State 3510, 6]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3517
stateno = 3517

[State 3510, 7]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3518
stateno = 3518

[State 3510, 8] ;Miss
type = ChangeState
trigger1 = Time > 0
trigger1 = Pos Y >= -30
trigger2 = MoveGuarded
value = 3514

[State 3510, Fire Logo]
type = Explod
trigger1 = Time >= 1
anim = 3440
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Decoration - Projectile Helper - Repeat Trips
[Statedef 3511]
type = A
movetype = A
physics = N

[State 3511, BindToParent]
type = BindToParent
trigger1 = Time = 0
pos = 96,-93

[State 3511, VelSet 1]
type = VelSet
trigger1 = Time = 0
x = 6
y = 2

[State 3511, Ghost 1]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3515
stateno = 3515

[State 3511, Ghost 2]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3516
stateno = 3516

[State 3511, Ghost 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3517
stateno = 3517

[State 3511, Ghost 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3518
stateno = 3518

[State 3511, Throwing Hit] ;Throwing Hit
type = ChangeState
triggerall = Time > 0
trigger1 = facing = 1 && (target, Pos X - Pos X < 30)
trigger2 = facing = -1 && (target, Pos X - Pos X > -30)
value = 3512

[State 3511, Heart Logo]
type = Explod
triggerall = Time >= 1
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
anim = 3446
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3511, Shock Logo]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time >= 1
anim = 3442
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3511, Ice Logo]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time >= 1
anim = 3445
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Decoration - Projectile Helper - Target Transformed
[Statedef 3512]
type = A
movetype = A
physics = N
anim = 1214

[State 3512, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3512, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3512, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3512, HitAdd]
type = HitAdd
trigger1 = Time = 0
value = 1

[State 3512, RemoveExplod] ;Remove Previous Khybit Explod
type = RemoveExplod
trigger1 = Time = 0
ID = 3570

[State 3512, Fire 1] ;Fire Spark
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 4040
anim = 4040
postype = p2
sprpriority = 3
ownpal = 1

[State 3512, Fire 2] ;Fire Sound
type = PlaySnd
trigger1 = Var(2) = 0
trigger1 = Time = 0
value = 3300, 1

[State 3512, Fire Khybit Spark 1]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 4041
pos = -54,24-floor(target, Pos Y)
postype = p2
sprpriority = 5
ownpal = 1

[State 3512, Fire Khybit Spark 2]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 4041
pos = 55,24-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5
ownpal = 1

[State 3512, Fire Khybit Spark 3]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 4041
pos = -30,-4-floor(target, Pos Y)
postype = p2
sprpriority = -1
ownpal = 1

[State 3512, Fire Khybit Spark 4]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 4041
pos = 31,-4-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1
ownpal = 1

[State 3512, Fire Khybit 1]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 3470
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Fire Khybit 2]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 3470
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Fire Khybit 3]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 3470
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, Fire Khybit 4]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 3470
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, Midnight Bliss 1] ;Midnight Bliss Transform Sound
type = PlaySnd
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
value = 1200, 2

[State 3512, Midnight Bliss 2] ;Midnight Bliss State
type = TargetState
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
value = 3542

[State 3512, Midnight Bliss 3] ;Midnight Bliss remove Fire Spark
type = RemoveExplod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 4040

[State 3512, Midnight Bliss 4] ;Midnight Bliss remove Fire Khybits
type = RemoveExplod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570

[State 3512, Midnight Bliss 5] ;Midnight Bliss P2 Anim
type = Explod
triggerall = Time = 0
triggerall = target, SelfAnimExist(9021) = 0
triggerall = target, SelfAnimExist(9020) = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
anim = 9021
ID = 3570
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3512, Khybit Midnight Bliss 1]
type = Explod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570
anim = 3571
pos = -56,0
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Khybit Midnight Bliss 2]
type = Explod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570
anim = 3571
pos = 57,0
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Khybit Midnight Bliss 3]
type = Explod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570
anim = 3571
pos = -33,-20
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, Khybit Midnight Bliss 4]
type = Explod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570
anim = 3571
pos = 34,-20
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, Shock 1] ;Shocked Sound
type = PlaySnd
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3300, 2

[State 3512, Shock 2] ;Shocked State
type = TargetState
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3543

[State 3512, Khybit Shocked 1]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3570
anim = 3472
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Khybit Shocked 2]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3570
anim = 3472
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Khybit Shocked 3]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3570
anim = 3472
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, Khybit Shocked 4]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3570
anim = 3472
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, Frozen 1] ;P2 Frozen Special Anim
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
anim = ifelse(target, const(size.height) <= 60,3357,3358)
ID = 3570
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3512, Frozen 2] ;Frozen Sound
type = PlaySnd
trigger1 = Var(2) = 4
trigger1 = Time = 0
value = 3300, 3

[State 3512, Frozen 3] ;Frozen State
type = TargetState
trigger1 = Var(2) = 4
trigger1 = Time = 0
value = 3544

[State 3512, Khybit Frozen 1]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3570
anim = 3477
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Khybit Frozen 2]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3570
anim = 3477
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Khybit Frozen 3]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3570
anim = 3477
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, Khybit Frozen 4]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3570
anim = 3477
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, Big Ice Explod 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4051
pos = -28,-72
postype = p2
vel = -5,-2
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3512, Small Ice Explod 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = -39,-47
postype = p2
vel = -5,0.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3512, Small Ice Explod 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = -2,-91
postype = p2
vel = -0,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3512, Small Ice Explod 3]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = 20,-48
postype = p2
vel = 5,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3512, Big Ice Explod 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4051
pos = -40,-28
postype = p2
vel = -6,-1
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3512, Big Ice Explod Alt 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4051
pos = -19,-63
postype = p2
vel = -4,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3512, Small Ice Explod Alt 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = 39,-51
postype = p2
vel = 3,1
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3512, Big Ice Explod Alt 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4051
pos = 19,-80
postype = p2
vel = 0.5,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3512, Small Ice Explod Alt 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = 49,-23
postype = p2
vel = 3,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3512, Small Ice Explod Alt 3]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = -21,-43
postype = p2
vel = -3,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3512, Judgement 1] ;Royal Judgement P2 Anim
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
trigger1 = target, SelfAnimExist(19030) = 0
trigger1 = target, SelfAnimExist(19050) = 0
anim = 50000 + Var(0)*10
ID = 3570
pos = 0,ifelse(Var(0)<0,-51,0)
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3512, Judgement 2] ;Royal Judgement Sound
type = PlaySnd
trigger1 = Var(2) = 6
trigger1 = Time = 0
value = 1200, 1

[State 3512, Judgement 3] ;Royal Judgement State
type = TargetState
trigger1 = Var(2) = 6
trigger1 = Time = 0
value = 3545

[State 3512, Khybit Judgement Spark 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 4016
pos = 62,-50-floor(target, Pos Y)
postype = p2
sprpriority = 5
ownpal = 1

[State 3512, Khybit Judgement Spark 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4016
pos = -61,-50-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5
ownpal = 1

[State 3512, Khybit Judgement Spark 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 4016
pos = 38,-70-floor(target, Pos Y)
postype = p2
sprpriority = -1
ownpal = 1

[State 3512, Khybit Judgement Spark 4]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 4016
pos = -37,-70-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1
ownpal = 1

[State 3512, Khybit Judgement 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 6011
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Khybit Judgement 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 6011
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3512, Khybit Judgement 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 6011
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, Khybit Judgement 4]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 6011
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3512, VelSet]
type = VelSet
trigger1 = parent, Var(2) > 0
trigger1 = Time = 0
x = 0
y = 0

[State 3512, VarSet] ;Increment Count
type = VarSet
trigger1 = Time = 0
v = 2
value = Var(2) + 1

[State 3512, ChangeState 1] ;Throw another projectile
type = ChangeState
trigger1 = Var(2) < 3
trigger1 = parent, stateno = 3502
trigger1 = parent, AnimElem = 7, = 4
value = 3511

[State 3512, ChangeState 2] ;Anakaris interrupted
type = ChangeState
trigger1 = parent, stateno != 3502
value = 3513

[State 3512, ChangeState 3] ;End, go to coffin drop
type = ChangeState
trigger1 = Var(2) >= 3
trigger1 = parent, stateno = 3502
trigger1 = parent, AnimElem = 7, = 2
value = 3520

;Pharaoh Decoration - Projectile Helper - Interrupted
[Statedef 3513]
type = A
movetype = A

[State 3513, 1] ;Remove Previous Khybit Explod
type = RemoveExplod
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
trigger1 = target, Time >= 30
ID = 3570

[State 3513, 2] ;Anakaris interrupted
type = TargetState
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
trigger1 = target, Time >= 30
value = 3548

[State 3513, 3]
type = DestroySelf
trigger1 = Time > 0
trigger1 = target, stateno != [3540,3549]

;Pharaoh Decoration - Projectile Helper - Miss
[Statedef 3514]
type = A
movetype = A

[State 3514, 1]
type = DestroySelf
trigger1 = Time > 0

;Pharaoh Decoration - Projectile Helper - Coffin Falling
[Statedef 3520]
type = A
movetype = A
anim = 3420
ctrl = 0
velset = 0,16
sprpriority = 3

[State 3520, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Random < 100 || parent, command = "holdstart"
value = 3424

[State 3520, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 3424
value = ifelse(Random > 200,3420,3422)

[State 3520, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3424
anim = 3426
ID = 3526
bindtime = -1
removetime = -1

[State 3520, 4] ;Khybit sound
type = PlaySnd
trigger1 = Time = 4
trigger1 = Anim = 3424
value = 3400,0
channel = 1

[State 3520, 5]
type = PosSet
trigger1 = Time = 0
x = target, Pos X
y = -240

[State 3520, 6]
type = ChangeState
trigger1 = Pos Y >= 0
value = 3521

;Pharaoh Decoration - Projectile Helper - Coffin Hitting
[Statedef 3521]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3521, 1]
type = ChangeAnim
trigger1 = Time = 0
value = Anim+1

[State 3521, 2] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Time = 0
ID = 3526

[State 3521, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3425
anim = 3427
ID = 3526
bindtime = -1
removetime = -1

[State 3521, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3521, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3521, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3521, 4]
type = HitAdd
trigger1 = Time = 0
trigger1 = Var(2) != 1
value = 1

[State 3521, 5]
type = EnvShake
trigger1 = Time = 0
time = 16
ampl = 5
freq = 120

[State 3521, 6]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3521, 7] ;Remove Royal Judgement Khybits and P2Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3570

[State 3521, Khybit Flat 1]
type = Explod
trigger1 = Time = 0
ID = 3570
anim = 6014
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3521, Khybit Flat 2]
type = Explod
trigger1 = Time = 0
ID = 3570
anim = 6014
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3521, Khybit Flat 3]
type = Explod
trigger1 = Time = 0
ID = 3570
anim = 6014
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3521, Khybit Flat 4]
type = Explod
trigger1 = Time = 0
ID = 3570
anim = 6014
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3521, 8] ;Crash Sound
type = PlaySnd
trigger1 = Time = 0
value = 1100, 1

[State 3521, 9]
type = TargetState
trigger1 = Time = 0
value = 3546

[State 3521, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 3522

;Pharaoh Decoration - Projectile Helper - Coffin Rising
[Statedef 3522]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3522, 1] ;If this move killed target
type = ParentVarSet
trigger1 = Time = 0
trigger1 = target, Life = 0
v = 5 ;Win Type
value = 2

[State 3522, 2]
type = VelSet
triggerall = Time = 0
trigger1 = target, Life != 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life != 0 || enemynear(1), life != 0
y = -8

[State 3522, 3]
type = ChangeAnim
trigger1 = Time = 0
value = Anim-1

[State 3522, 4] ;Remove Royal Judgement Khybits
type = RemoveExplod
trigger1 = Time = 0
ID = 3570

[State 3522, Random Variable Khybit 1]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3522, Khybit Fade 1]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = 20
sprpriority = 5
ownpal = 1

[State 3522, Khybit Float 1]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3523
pos = -62,16-floor(target, Pos Y)
postype = p2
ownpal = 1

[State 3522, Random Variable Khybit 2]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3522, Khybit Fade 2]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = 20
sprpriority = 5
ownpal = 1

[State 3522, Khybit Float 2]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3523
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
ownpal = 1

[State 3522, Random Variable Khybit 3]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3522, Khybit Fade 3]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = 20
sprpriority = -1
ownpal = 1

[State 3522, Khybit Float 3]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3523
pos = -38,-4-floor(target, Pos Y)
postype = p2
ownpal = 1

[State 3522, Random Variable Khybit 3]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3522, Khybit Fade 4]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = 20
sprpriority = -1
ownpal = 1

[State 3522, Khybit Float 4]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3523
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
ownpal = 1

[State 3522, 5] ;Remove Riding Khybit
type = StopSnd
trigger1 = Pos Y <= -240
channel = 1

[State 3522, 6] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Pos Y <= -240
ID = 3526

[State 3522, 7]
type = DestroySelf
trigger1 = Pos Y <= -240

;Pharaoh Decoration - Squashed Khybit Rising
[Statedef 3523]
type = A
movetype = I
anim = 6016
ctrl = 0
velset = 0,-6.5

[State 3523, 2]
type = ChangeState
trigger1 = Time = 21
value = 3524

;Pharaoh Decoration - Squashed Khybit Floating
[Statedef 3524]
anim = 6017
velset = 0,3

[State 3524, 1]
type = Offset
trigger1 = 1
x = 16*sin(time*2*pi/24)*(-facing)

[State 3524, 2]
type = DestroySelf
trigger1 = Pos Y > -5

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3515]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3515, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 1

[State 3515, 2]
type = ChangeState
trigger1 = Time = 0
value = 3519

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3516]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3516, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 9

[State 3516, 2]
type = ChangeState
trigger1 = Time = 0
value = 3519

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3517]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3517, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 17

[State 3517, 2]
type = ChangeState
trigger1 = Time = 0
value = 3519

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3518]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3518, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 25

[State 3518, 2]
type = ChangeState
trigger1 = Time = 0
value = 3519

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3519]
type = A
movetype = A
ctrl = 0

[State 3519, BindToParent 1]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -4,5

[State 3519, BindToParent 2]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -1,10

[State 3519, BindToParent 3]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 2,15

[State 3519, BindToParent 4]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 6,19

[State 3519, BindToParent 5]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(5) >= 0 && AnimElemTime(6) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 9,23

[State 3519, BindToParent 6]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 11,25

[State 3519, BindToParent 7]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(7) >= 0 && AnimElemTime(8) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 14,27

[State 3519, BindToParent 8]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(8) >= 0 && AnimElemTime(9) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 16,28

[State 3519, BindToParent 9]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(9) >= 0 && AnimElemTime(10) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 16,26

[State 3519, BindToParent 10]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(10) >= 0 && AnimElemTime(11) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 17,24

[State 3519, BindToParent 11]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(11) >= 0 && AnimElemTime(12) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 17,22

[State 3519, BindToParent 12]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(12) >= 0 && AnimElemTime(13) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 16,18

[State 3519, BindToParent 13]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(13) >= 0 && AnimElemTime(14) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 14,14

[State 3519, BindToParent 14]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(14) >= 0 && AnimElemTime(15) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 13,9

[State 3519, BindToParent 15]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(15) >= 0 && AnimElemTime(16) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 10,4

[State 3519, BindToParent 16]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(16) >= 0 && AnimElemTime(17) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 8,0

[State 3519, BindToParent 17]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(17) >= 0 && AnimElemTime(18) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 4,-4

[State 3519, BindToParent 18]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(18) >= 0 && AnimElemTime(19) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = 1,-9

[State 3519, BindToParent 19]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(19) >= 0 && AnimElemTime(20) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -2,-14

[State 3519, BindToParent 20]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(20) >= 0 && AnimElemTime(21) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -6,-18

[State 3519, BindToParent 21]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(21) >= 0 && AnimElemTime(22) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -9,-22

[State 3519, BindToParent 22]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(22) >= 0 && AnimElemTime(23) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -11,-24

[State 3519, BindToParent 23]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(23) >= 0 && AnimElemTime(24) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -14,-27

[State 3519, BindToParent 24]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(24) >= 0 && AnimElemTime(25) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -16,-28

[State 3519, BindToParent 25]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(25) >= 0 && AnimElemTime(26) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -16,-27

[State 3519, BindToParent 26]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(26) >= 0 && AnimElemTime(27) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -17,-25

[State 3519, BindToParent 27]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(27) >= 0 && AnimElemTime(28) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -17,-23

[State 3519, BindToParent 28]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(28) >= 0 && AnimElemTime(29) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -16,-19

[State 3519, BindToParent 29]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(29) >= 0 && AnimElemTime(30) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -14,-15

[State 3519, BindToParent 30]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(30) >= 0 && AnimElemTime(31) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -13,-10

[State 3519, BindToParent 31]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(31) >= 0 && AnimElemTime(32) < 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -10,-5

[State 3519, BindToParent 32]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(32) >= 0
trigger1 = parent, stateno = 3510
trigger2 = parent, stateno = 3511
pos = -8,0

[State 3519, SprPriority 1]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 4
value = 3

[State 3519, SprPriority 2]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 8
value = 0

[State 3519, SprPriority 3]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 12
value = -1

[State 3519, SprPriority 4]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 16
value = 0

[State 3519, SprPriority 5]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 20
value = 3

[State 3519, SprPriority 6]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 28
value = 4

;[State 3519, 3]
;type = PosAdd
;trigger1 = Anim = 1212
;trigger1 = parent, stateno != 2310
;trigger1 = parent, stateno != 2311
;x = -5 + 27*cos(2*PI*(AnimElemNo(0)+7)/32)
;y = -5 +  5*sin(2*PI*(AnimElemNo(0)+7)/32)

[State 3519, 4]
type = ChangeAnim
trigger1 = Anim = 3419
trigger1 = parent, stateno != 3510
trigger1 = parent, stateno != 3511
value = 1213

[State 3519, 5]
type = DestroySelf
trigger1 = Anim = 1213
trigger1 = AnimTime = 0

;Pharaoh Decoration - Hit
[Statedef 3540]
type = S
movetype = H
physics = N
velset = 0,0

[State 3540, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3540, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3540, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 5010

[State 3540, 2]
type = LifeAdd
trigger1 = Time = 0
value = -50
kill = 0

[State 3540, 3] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [0,1]
x = 0

[State 3540, 4] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [2,3]
x = -2

[State 3540, 5]
type = ChangeState
trigger1 = Time = 14
value = 3541

;Pharaoh Decoration - Burned
[Statedef 3541]
movetype = H
physics = N
velset = 0,0

[State 3541, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3541, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3541, Hit in Air 1] ;Gravity
type = VelAdd
trigger1 = Pos Y < 0
y = .66

[State 3541, Hit in Air 2]
type = StateTypeSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
trigger2 = StateType = C
statetype = S

[State 3541, Hit in Air 3]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
y = 0

[State 3541, Hit in Air 4]
type = PosSet
trigger1 = Pos Y > 0
y = 0

;[State 3541, 1]
;type = PalFx
;trigger1 = SelfAnimExist(7697) = 0
;time = 1
;add = 176,64,32
;mul = 240,240,128
;color = 0

[State 3541, 2]
type = ChangeAnim
trigger1 = SelfAnimExist(7697) = 1
trigger1 = Time = 0
value = 7697

[State 3541, 3]
type = ChangeAnim2
trigger1 = SelfAnimExist(7697) = 0
trigger1 = Time = 0
value = 3451

;Pharaoh Decoration - Hit by Midnight Bliss
[Statedef 3542]
movetype = H
physics = N

[State 3542, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3542, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3542, Hit in Air 1] ;Gravity
type = VelAdd
trigger1 = Pos Y < 0
y = .66

[State 3542, Hit in Air 2]
type = StateTypeSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
trigger2 = StateType = C
statetype = S

[State 3542, Hit in Air 3]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
y = 0

[State 3542, Hit in Air 4]
type = PosSet
trigger1 = Pos Y > 0
y = 0

[State 3542, 1]
type = PalFx
trigger1 = Time = 0
time = 0

[State 3542, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(9021) = 1
value = 9021

[State 3542, 3]
type = ChangeAnim
trigger1 = SelfAnimExist(9021) = 0
trigger1 = SelfAnimExist(9020) = 1
value = 9020

[State 3542, 4]
type = ChangeAnim2
trigger1 = Time = 0
trigger1 = SelfAnimExist(9021) = 0
trigger1 = SelfAnimExist(9020) = 0
value = 3552

[State 3546, 5]
type = LifeAdd
trigger1 = Time = 0
value = -50
kill = 0

[State 3542, 6] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [0,1]
x = 0

[State 3542, 7] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [2,3]
x = -2

;Pharaoh Decoration - Shocked
[Statedef 3543]
movetype = H
physics = N

[State 3543, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3543, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3543, Hit in Air 1] ;Gravity
type = VelAdd
trigger1 = Pos Y < 0
y = .66

[State 3543, Hit in Air 2]
type = StateTypeSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
trigger2 = StateType = C
statetype = S

[State 3543, Hit in Air 3]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
y = 0

[State 3543, Hit in Air 4]
type = PosSet
trigger1 = Pos Y > 0
y = 0

[State 3543, 1]
type = LifeAdd
trigger1 = Time = 0
value = -50
kill = 0

[State 3543, 2]
type = PalFx
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time = 0
time = 45
add = 96,80,16
mul = 256,240,128
color = 0

[State 3543, 3]
type = ChangeAnim
trigger1 = SelfAnimExist(7696) = 1
trigger1 = Time = 0
value = 7696

[State 3543, 4]
type = ChangeAnim2
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time = 0
value = 3453

[State 3543, 5] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [0,1]
x = 0

[State 3543, 6] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [2,3]
x = -2

[State 3543, 5] ;Shocking
type = Offset
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time % 4 = [0,1]
x = 0

[State 3543, 6] ;Shocking
type = Offset
trigger1 = SelfAnimExist(7696) = 0
trigger1 = Time % 4 = [2,3]
x = -6

;Pharaoh Decoration - Frozen
[Statedef 3544]
type = S
movetype = H
physics = N

[State 3544, 1]
type = LifeAdd
trigger1 = Time = 0
value = -25
kill = 0

[State 3544, 2]
type = PalFx
trigger1 = Time = 0
time = 0

[State 3544, 3]
type = ChangeAnim2
trigger1 = Time = 0
value = 3356

;Pharaoh Decoration - Royal Judgement Transformed
[Statedef 3545]
type = S
movetype = H
physics = N

[State 3545, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3545, 2]
type = PlayerPush
trigger1 = 1
value = 0

[State 3545, 3]
type = LifeAdd
trigger1 = Time = 0
value = -25
kill = 0

[State 3545, 4]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(19030) = 1
trigger1 = SelfAnimExist(19050) = 0
value = 19030

[State 3545, 5] ;Royal Judgement P2 Anim
type = Explod
trigger1 = Time = 0
trigger1 = SelfAnimExist(19050) = 1
anim = 19050
ID = 3557
pos = 0,-51
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3545, 6]
type = ChangeAnim2
triggerall = Time = 0
trigger1 = SelfAnimExist(19030) = 0
trigger2 = SelfAnimExist(19050) = 1
value = 3457

[State 3545, 7]
type = PlaySnd
triggerall = Time = 0
trigger1 = SelfAnimExist(19030) = 1
trigger2 = SelfAnimExist(19050) = 1
value = 19030,0

[State 3545, 8] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [0,1]
x = 0

[State 3545, 9] ;Simulate HitShake
type = Offset
triggerall = Time <= 12
trigger1 = Time % 4 = [2,3]
x = -2

;Pharaoh Decoration - Crushed
[Statedef 3546]
type = L
movetype = H
physics = N
velset = 0,0

[State 3546, 1] ;Royal Judgement P2 Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3557

[State 3546, 2]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3546, 3]
type = LifeAdd
trigger1 = Time = 0
value = -110

[State 3546, 4]
type = ChangeAnim
trigger1 = Time = 0
value = 5110

[State 3546, 5]
type = Turn
trigger1 = Time = 0

[State 3546, 6]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3546, 7]
type = PlayerPush
trigger1 = 1
value = 0

[State 3546, 8]
type = ChangeState
trigger1 = Time = 57
value = 3547

;Pharaoh Decoration - Target End Custom Hit State
[Statedef 3547]
type = L
movetype = H
physics = N
velset = 0,0

[State 3547, 1]
type = SelfState
trigger1 = Life = 0
value = 5150

[State 3547, 2]
type = SelfState
trigger1 = 1
value = 5120

;Pharaoh Decoration - End Custom Hit State Early
[Statedef 3548]
movetype = H
physics = N
velset = 0,0

[State 3548, 1]
type = PalFX
trigger1 = Time = 0
time = 0

[State 3548, 2]
type = SelfState
trigger1 = Life = 0
value = 5150

[State 3548, 3]
type = SelfState
trigger1 = 1
value = ifelse(Pos Y < 0,5050,0)
ctrl = ifelse(Pos Y < 0,0,1)

;========================<MAX PHARAOH DECORATION>=============================
[StateDef 3550]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3550, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3550, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3550, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3550, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3550, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3550, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3550, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3550, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3550, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3550, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3550, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3550, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3505
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3550, 3]
type = ChangeAnim
trigger1 = Anim = 3300
trigger1 = AnimTime = 0
value = 3302

[State 3550, 4] ;Projectile
type = Helper
trigger1 = Anim = 3302
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3560
stateno = 3560

[State 3550, 5] ;Base
type = RemoveExplod
triggerall = Anim = 3302
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3560) = 0
ID = 3505

[State 3550, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3560) = 0
value = 3551

[State 3550, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3302
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3560), MoveHit = 1
value = 3552

;Pharaoh Decoration - Miss
[Statedef 3551]
type = S
movetype = I
physics = S
anim = 3301

[State 3551, 1] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3507
sprpriority = 1
removeongethit = 1

[State 3551, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Pharaoh Decoration - Hit
[Statedef 3552]
type = U
movetype = A
physics = N

[State 3552, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3552, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3552, PosFreeze]
type = PosFreeze
trigger1 = 1

[State 3552, Voice] ;Voice
type = PlaySnd
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 2
value = 1130, 0
channel = 0

[State 3552, 1]
type = ChangeAnim
trigger1 = helper(3560), Var(2) <= 7
trigger1 = helper(3560), stateno = 3562
trigger1 = helper(3560), Time = 9
value = ifelse(statetype = A,3402,3302)

[State 3552, 2] ;Base
type = RemoveExplod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
ID = 3505

[State 3552, 3] ;Base
type = Explod
trigger1 = Anim = 3302 || Anim = 3402
trigger1 = AnimElemTime(1) = 0
anim = 3306
ID = 3505
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3552, 4] ;Base
type = RemoveExplod
trigger1 = helper(3560), Var(2) >= 7
trigger1 = AnimTime = 24
ID = 3505

[State 3552, 5]
type = ChangeState
trigger1 = helper(3560), Var(2) >= 7
trigger1 = AnimTime = 24
value = ifelse(statetype=A,3556,3551)

;Pharaoh Decoration - Attempt
[Statedef 3555]
type = A
movetype = A
physics = N
juggle  = 4
poweradd= -2000
ctrl = 0
anim = 3400
sprpriority = 2

[State 3355, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3355, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3355, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3355, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3355, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3355, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3355, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3555, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3555, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-95 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3555, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3555, 1]
type = PosFreeze
trigger1 = 1

[State 3555, 1] ;Voice
type = PlaySnd
trigger1 = Time = 2
value = 1130, 0
channel = 0

[State 3555, 2] ;Base Appear
type = Explod
trigger1 = Time = 0
anim = 3305
ID = 3505
pos = 0,-floor(Pos Y)
removetime = -1
sprpriority = 1
removeongethit = 1

[State 3555, 3]
type = ChangeAnim
trigger1 = Anim = 3400
trigger1 = AnimTime = 0
value = 3402

[State 3555, 4] ;Projectile
type = Helper
trigger1 = Anim = 3402
trigger1 = AnimElem = 7, = 4
name = "Pharaoh Magic"
ID = 3560
stateno = 3560

[State 3555, 4] ;Gravity
type = Varset
trigger1 = 1
v = 1
value = 1

[State 3555, 5] ;Base
type = RemoveExplod
trigger1 = Anim = 3402
triggerall = AnimElemTime(7) > 4
trigger1 = numhelper(3560) = 0
ID = 3505

[State 3555, 6] ;Miss
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = numhelper(3560) = 0
value = 3556

[State 3555, 7] ;Hit
type = ChangeState
trigger1 = Anim = 3402
trigger1 = AnimElemTime(7) > 4
trigger1 = helper(3560), MoveHit = 1
value = 3552

;Pharaoh Decoration - Miss (Air)
[Statedef 3556]
type = A
movetype = I
physics = N
anim = 3401

[State 3556, 1]
type = PosFreeze
trigger1 = 1

[State 3556, 2] ;Base Disappear
type = Explod
trigger1 = Time = 0
anim = 3307
ID = 3507
pos = 0,-floor(Pos Y)
sprpriority = 1
removeongethit = 1

[State 3556, 4]
type = ChangeState
trigger1 = var(1) = 1
trigger1 = AnimTime = 0
value = 70
ctrl = 1
anim = 59

[State 3556, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 59

;Pharaoh Decoration - Projectile Helper
[Statedef 3560]
type = A
movetype = A
physics = N
ctrl = 0
juggle = 3
anim = 1210
sprpriority = -1

[State 3560, 1]
type = BindToParent
trigger1 = Time = 0
pos = 96,-93

[State 3560, 2]
type = VarSet
trigger1 = Time = 0
v = 2
value = 0

[State 3560, 3]
type = HitDef
trigger1 = Var(2) = 0
trigger1 = Time = 0
attr = A, HP
hitflag = MA-
guardflag = MA
pausetime = 0,10
priority = 1, Miss
hitSound = -1 + 0 * (var(31) := 6)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1sprpriority = 1
p1facing = 1
p2facing = 1
p1stateno = 1215
p2stateno = 3540
numhits = 0
getpower = 0

[State 3560, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3560, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3560, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3560, VelSet 1]
type = VelSet
trigger1 = Time = 0
x = 4
y = 2

[State 3560, 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3566
stateno = 3565

[State 3560, 5]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3566
stateno = 3566

[State 3560, 6]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3567
stateno = 3567

[State 3560, 7]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3568
stateno = 3568

[State 3560, 8] ;Miss
type = ChangeState
trigger1 = Time > 0
trigger1 = Pos Y >= -30
trigger2 = MoveGuarded
value = 3564

[State 3560, Fire Logo]
type = Explod
trigger1 = Time >= 1
anim = 3440
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Decoration - Projectile Helper - Repeat Trips
[Statedef 3561]
type = A
movetype = A
physics = N

[State 3561, BindToParent]
type = BindToParent
trigger1 = Time = 0
pos = 96,-93

[State 3561, VelSet 1]
type = VelSet
trigger1 = Time = 0
x = 6
y = 2

[State 3561, Ghost 1]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3565
stateno = 3565

[State 3561, Ghost 2]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3566
stateno = 3566

[State 3561, Ghost 3]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3567
stateno = 3567

[State 3561, Ghost 4]
type = Helper
trigger1 = Time = 0
name = "Ghost"
ID = 3568
stateno = 3568

[State 3561, Throwing Hit] ;Throwing Hit
type = ChangeState
triggerall = Time > 0
trigger1 = facing = 1 && (target, Pos X - Pos X < 30)
trigger2 = facing = -1 && (target, Pos X - Pos X > -30)
value = 3562

[State 3561, Heart Logo]
type = Explod
triggerall = Time >= 1
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
anim = 3446
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3561, Shock Logo]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time >= 1
anim = 3442
pos = 0,0
sprpriority = 3
ownpal = 1

[State 3561, Ice Logo]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time >= 1
anim = 3445
pos = 0,0
sprpriority = 3
ownpal = 1

;Pharaoh Decoration - Projectile Helper - Target Transformed
[Statedef 3562]
type = A
movetype = A
physics = N
anim = 1214

[State 3562, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3562, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3562, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3562, HitAdd]
type = HitAdd
trigger1 = Time = 0
value = 1

[State 3562, RemoveExplod] ;Remove Previous Khybit Explod
type = RemoveExplod
trigger1 = Time = 0
ID = 3570

[State 3562, Fire 1] ;Fire Spark
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 4040
anim = 4040
postype = p2
sprpriority = 3
ownpal = 1

[State 3562, Fire 2] ;Fire Sound
type = PlaySnd
trigger1 = Var(2) = 0
trigger1 = Time = 0
value = 3300, 1

[State 3562, Fire Khybit Spark 1]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 4041
pos = -54,24-floor(target, Pos Y)
postype = p2
sprpriority = 5
ownpal = 1

[State 3562, Fire Khybit Spark 2]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 4041
pos = 55,24-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5
ownpal = 1

[State 3562, Fire Khybit Spark 3]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 4041
pos = -30,-4-floor(target, Pos Y)
postype = p2
sprpriority = -1
ownpal = 1

[State 3562, Fire Khybit Spark 4]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 4041
pos = 31,-4-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1
ownpal = 1

[State 3562, Fire Khybit 1]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 3470
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Fire Khybit 2]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 3470
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Fire Khybit 3]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 3470
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, Fire Khybit 4]
type = Explod
trigger1 = Var(2) = 0
trigger1 = Time = 0
ID = 3570
anim = 3470
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, Midnight Bliss 1] ;Midnight Bliss Transform Sound
type = PlaySnd
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
value = 1200, 2

[State 3562, Midnight Bliss 2] ;Midnight Bliss State
type = TargetState
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
value = 3542

[State 3562, Midnight Bliss 3] ;Midnight Bliss remove Fire Spark
type = RemoveExplod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 4040

[State 3562, Midnight Bliss 4] ;Midnight Bliss remove Fire Khybits
type = RemoveExplod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570

[State 3562, Midnight Bliss 5] ;Midnight Bliss P2 Anim
type = Explod
triggerall = Time = 0
triggerall = target, SelfAnimExist(9021) = 0
triggerall = target, SelfAnimExist(9020) = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
anim = 9021
ID = 3570
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3562, Khybit Midnight Bliss 1]
type = Explod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570
anim = 3571
pos = -56,0
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Khybit Midnight Bliss 2]
type = Explod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570
anim = 3571
pos = 57,0
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Khybit Midnight Bliss 3]
type = Explod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570
anim = 3571
pos = -33,-20
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, Khybit Midnight Bliss 4]
type = Explod
triggerall = Time = 0
trigger1 = Var(2) = 1
trigger2 = Var(2) = 3
trigger3 = Var(2) = 5
ID = 3570
anim = 3571
pos = 34,-20
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, Shock 1] ;Shocked Sound
type = PlaySnd
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3300, 2

[State 3562, Shock 2] ;Shocked State
type = TargetState
trigger1 = Var(2) = 2
trigger1 = Time = 0
value = 3543

[State 3562, Khybit Shocked 1]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3570
anim = 3472
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Khybit Shocked 2]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3570
anim = 3472
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Khybit Shocked 3]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3570
anim = 3472
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, Khybit Shocked 4]
type = Explod
trigger1 = Var(2) = 2
trigger1 = Time = 0
ID = 3570
anim = 3472
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, Frozen 1] ;P2 Frozen Special Anim
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
anim = ifelse(target, const(size.height) <= 60,3357,3358)
ID = 3570
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3562, Frozen 2] ;Frozen Sound
type = PlaySnd
trigger1 = Var(2) = 4
trigger1 = Time = 0
value = 3300, 3

[State 3562, Frozen 3] ;Frozen State
type = TargetState
trigger1 = Var(2) = 4
trigger1 = Time = 0
value = 3544

[State 3562, Khybit Frozen 1]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3570
anim = 3477
pos = -56,0-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Khybit Frozen 2]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3570
anim = 3477
pos = 57,0-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Khybit Frozen 3]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3570
anim = 3477
pos = -33,-20-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, Khybit Frozen 4]
type = Explod
trigger1 = Var(2) = 4
trigger1 = Time = 0
ID = 3570
anim = 3477
pos = 34,-20-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, Big Ice Explod 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4051
pos = -28,-72
postype = p2
vel = -5,-2
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3562, Small Ice Explod 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = -39,-47
postype = p2
vel = -5,0.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3562, Small Ice Explod 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = -2,-91
postype = p2
vel = -0,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3562, Small Ice Explod 3]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = 20,-48
postype = p2
vel = 5,-2.5
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3562, Big Ice Explod 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4051
pos = -40,-28
postype = p2
vel = -6,-1
acc = 0,.44
removetime = 20
sprpriority = 4

[State 3562, Big Ice Explod Alt 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4051
pos = -19,-63
postype = p2
vel = -4,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3562, Small Ice Explod Alt 1]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = 39,-51
postype = p2
vel = 3,1
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3562, Big Ice Explod Alt 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4051
pos = 19,-80
postype = p2
vel = 0.5,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3562, Small Ice Explod Alt 2]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = 49,-23
postype = p2
vel = 3,-2
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3562, Small Ice Explod Alt 3]
type = Explod
trigger1 = Var(2) = 5
trigger1 = Time = 0
anim = 4050
pos = -21,-43
postype = p2
vel = -3,-1.5
acc = 0,.44
removetime = 19
sprpriority = 4

[State 3562, Judgement 1] ;Royal Judgement P2 Anim
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
trigger1 = target, SelfAnimExist(19030) = 0
trigger1 = target, SelfAnimExist(19050) = 0
anim = 50000 + Var(0)*10
ID = 3570
pos = 0,ifelse(Var(0)<0,-51,0)
postype = p2
bindtime = -1
removetime = -1
sprpriority = 3
ownpal = 1

[State 3562, Judgement 2] ;Royal Judgement Sound
type = PlaySnd
trigger1 = Var(2) = 6
trigger1 = Time = 0
value = 1200, 1

[State 3562, Judgement 3] ;Royal Judgement State
type = TargetState
trigger1 = Var(2) = 6
trigger1 = Time = 0
value = 3545

[State 3562, Khybit Judgement Spark 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 4016
pos = 62,-50-floor(target, Pos Y)
postype = p2
sprpriority = 5
ownpal = 1

[State 3562, Khybit Judgement Spark 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
anim = 4016
pos = -61,-50-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = 5
ownpal = 1

[State 3562, Khybit Judgement Spark 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 4016
pos = 38,-70-floor(target, Pos Y)
postype = p2
sprpriority = -1
ownpal = 1

[State 3562, Khybit Judgement Spark 4]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 4016
pos = -37,-70-floor(target, Pos Y)
postype = p2
facing = -1
sprpriority = -1
ownpal = 1

[State 3562, Khybit Judgement 1]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 6011
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Khybit Judgement 2]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 6011
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3562, Khybit Judgement 3]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 6011
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, Khybit Judgement 4]
type = Explod
trigger1 = Var(2) = 6
trigger1 = Time = 0
ID = 3570
anim = 6011
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3562, VelSet]
type = VelSet
trigger1 = parent, Var(2) > 0
trigger1 = Time = 0
x = 0
y = 0

[State 3562, VarSet] ;Increment Count
type = VarSet
trigger1 = Time = 0
v = 2
value = Var(2) + 1

[State 3562, ChangeState 1] ;Throw another projectile
type = ChangeState
trigger1 = Var(2) < 7
trigger1 = parent, stateno = 3552
trigger1 = parent, AnimElem = 7, = 4
value = 3561

[State 3562, ChangeState 2] ;Anakaris interrupted
type = ChangeState
trigger1 = parent, stateno != 3552
value = 3563

[State 3562, ChangeState 3] ;End, go to coffin drop
type = ChangeState
trigger1 = Var(2) >= 7
trigger1 = parent, stateno = 3552
trigger1 = parent, AnimElem = 7, = 2
value = 3570

;Pharaoh Decoration - Projectile Helper - Interrupted
[Statedef 3563]
type = A
movetype = A

[State 3563, 1] ;Remove Previous Khybit Explod
type = RemoveExplod
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
trigger1 = target, Time >= 30
ID = 3570

[State 3563, 2] ;Anakaris interrupted
type = TargetState
trigger1 = target, Pos Y >= 0
trigger1 = target, Vel Y >= 0
trigger1 = target, Time >= 30
value = 3548

[State 3563, 3]
type = DestroySelf
trigger1 = Time > 0
trigger1 = target, stateno != [3540,3549]

;Pharaoh Decoration - Projectile Helper - Miss
[Statedef 3564]
type = A
movetype = A

[State 3564, 1]
type = DestroySelf
trigger1 = Time > 0

;Pharaoh Decoration - Projectile Helper - Coffin Falling
[Statedef 3570]
type = A
movetype = A
anim = 3420
ctrl = 0
velset = 0,16
sprpriority = 3

[State 3570, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Random < 100 || parent, command = "holdstart"
value = 3424

[State 3570, 2]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 3424
value = ifelse(Random > 200,3420,3422)

[State 3570, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3424
anim = 3426
ID = 3526
bindtime = -1
removetime = -1

[State 3570, 4] ;Khybit sound
type = PlaySnd
trigger1 = Time = 4
trigger1 = Anim = 3424
value = 3400,0
channel = 1

[State 3570, 5]
type = PosSet
trigger1 = Time = 0
x = target, Pos X
y = -240

[State 3570, 6]
type = ChangeState
trigger1 = Pos Y >= 0
value = 3571

;Pharaoh Decoration - Projectile Helper - Coffin Hitting
[Statedef 3571]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3571, 1]
type = ChangeAnim
trigger1 = Time = 0
value = Anim+1

[State 3571, 2] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Time = 0
ID = 3526

[State 3571, 3] ;Riding Khybit
type = Explod
trigger1 = Time = 0
trigger1 = Anim = 3425
anim = 3427
ID = 3526
bindtime = -1
removetime = -1

[State 3571, HitSound]
type = PlaySnd
trigger1 = hitcount = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1
persistent = 0

[State 3571, HitSpark]
type = Helper
trigger1 = hitcount = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3571, Counter FX]
type = Helper
trigger1 = hitcount = 1 && var(9)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1
persistent = 0

[State 3571, 4]
type = HitAdd
trigger1 = Time = 0
trigger1 = Var(2) != 1
value = 1

[State 3571, 5]
type = EnvShake
trigger1 = Time = 0
time = 16
ampl = 5
freq = 120

[State 3571, 6]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3571, 7] ;Remove Royal Judgement Khybits and P2Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3570

[State 3571, Khybit Flat 1]
type = Explod
trigger1 = Time = 0
ID = 3570
anim = 6014
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = 5
ownpal = 1

[State 3571, Khybit Flat 2]
type = Explod
trigger1 = Time = 0
ID = 3570
anim = 6014
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = 5
ownpal = 1

[State 3571, Khybit Flat 3]
type = Explod
trigger1 = Time = 0
ID = 3570
anim = 6014
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = -1
sprpriority = -1
ownpal = 1

[State 3571, Khybit Flat 4]
type = Explod
trigger1 = Time = 0
ID = 3570
anim = 6014
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = -1
sprpriority = -1
ownpal = 1

[State 3571, 8] ;Crash Sound
type = PlaySnd
trigger1 = Time = 0
value = 1100, 1

[State 3571, 9]
type = TargetState
trigger1 = Time = 0
value = 3586

[State 3571, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 3572

;Pharaoh Decoration - Projectile Helper - Coffin Rising
[Statedef 3572]
type = A
movetype = A
ctrl = 0
velset = 0,0
sprpriority = 3

[State 3572, 1] ;If this move killed target
type = ParentVarSet
trigger1 = Time = 0
trigger1 = target, Life = 0
v = 5 ;Win Type
value = 2

[State 3572, 2]
type = VelSet
triggerall = Time = 0
trigger1 = target, Life != 0
trigger1 = numenemy < 2
trigger2 = numenemy = 2
trigger2 = enemynear(0), life != 0 || enemynear(1), life != 0
y = -8

[State 3572, 3]
type = ChangeAnim
trigger1 = Time = 0
value = Anim-1

[State 3572, 4] ;Remove Royal Judgement Khybits
type = RemoveExplod
trigger1 = Time = 0
ID = 3570

[State 3572, Random Variable Khybit 1]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3572, Khybit Fade 1]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = -62,16-floor(target, Pos Y)
postype = p2
removetime = 20
sprpriority = 5
ownpal = 1

[State 3572, Khybit Float 1]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3573
pos = -62,16-floor(target, Pos Y)
postype = p2
ownpal = 1

[State 3572, Random Variable Khybit 2]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3572, Khybit Fade 2]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
removetime = 20
sprpriority = 5
ownpal = 1

[State 3572, Khybit Float 2]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3573
pos = 63,16-floor(target, Pos Y)
postype = p2
facing = -1
ownpal = 1

[State 3572, Random Variable Khybit 3]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3572, Khybit Fade 3]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = -38,-4-floor(target, Pos Y)
postype = p2
removetime = 20
sprpriority = -1
ownpal = 1

[State 3572, Khybit Float 3]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3573
pos = -38,-4-floor(target, Pos Y)
postype = p2
ownpal = 1

[State 3572, Random Variable Khybit 3]
type = VarRandom
trigger1 = Time = 0
v = 43
range = 3

[State 3572, Khybit Fade 4]
type = Explod
triggerall = Time = 0
trigger1 = Var(43) != 0
trigger2 = Vel Y = 0
anim = 6015
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
removetime = 20
sprpriority = -1
ownpal = 1

[State 3572, Khybit Float 4]
type = Helper
triggerall = Time = 0
trigger1 = Var(43) = 0
trigger1 = Vel Y < 0
name = "Khybit"
stateno = 3573
pos = 39,-4-floor(target, Pos Y)
postype = p2
facing = -1
ownpal = 1

[State 3572, 5] ;Remove Riding Khybit
type = StopSnd
trigger1 = Pos Y <= -240
channel = 1

[State 3572, 6] ;Remove Riding Khybit
type = RemoveExplod
trigger1 = Pos Y <= -240
ID = 3526

[State 3572, 7]
type = DestroySelf
trigger1 = Pos Y <= -240

;Pharaoh Decoration - Squashed Khybit Rising
[Statedef 3573]
type = A
movetype = I
anim = 6016
ctrl = 0
velset = 0,-6.5

[State 3573, 2]
type = ChangeState
trigger1 = Time = 21
value = 3574

;Pharaoh Decoration - Squashed Khybit Floating
[Statedef 3574]
anim = 6017
velset = 0,3

[State 3574, 1]
type = Offset
trigger1 = 1
x = 16*sin(time*2*pi/24)*(-facing)

[State 3574, 2]
type = DestroySelf
trigger1 = Pos Y > -5

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3565]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3565, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 1

[State 3565, 2]
type = ChangeState
trigger1 = Time = 0
value = 3569

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3566]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3566, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 9

[State 3566, 2]
type = ChangeState
trigger1 = Time = 0
value = 3569

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3567]
type = A
movetype = A
ctrl = 0
sprpriority = 0

[State 3567, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 17

[State 3567, 2]
type = ChangeState
trigger1 = Time = 0
value = 3569

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3568]
type = A
movetype = A
ctrl = 0
sprpriority = 3

[State 3568, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 3419
elem = 25

[State 3568, 2]
type = ChangeState
trigger1 = Time = 0
value = 3569

;Pharaoh Decoration - Projectile Helper's Helper - Individual Ghost Image
[Statedef 3569]
type = A
movetype = A
ctrl = 0

[State 3569, BindToParent 1]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -4,5

[State 3569, BindToParent 2]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -1,10

[State 3569, BindToParent 3]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 2,15

[State 3569, BindToParent 4]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 6,19

[State 3569, BindToParent 5]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(5) >= 0 && AnimElemTime(6) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 9,23

[State 3569, BindToParent 6]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 11,25

[State 3569, BindToParent 7]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(7) >= 0 && AnimElemTime(8) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 14,27

[State 3569, BindToParent 8]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(8) >= 0 && AnimElemTime(9) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 16,28

[State 3569, BindToParent 9]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(9) >= 0 && AnimElemTime(10) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 16,26

[State 3569, BindToParent 10]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(10) >= 0 && AnimElemTime(11) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 17,24

[State 3569, BindToParent 11]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(11) >= 0 && AnimElemTime(12) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 17,22

[State 3569, BindToParent 12]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(12) >= 0 && AnimElemTime(13) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 16,18

[State 3569, BindToParent 13]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(13) >= 0 && AnimElemTime(14) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 14,14

[State 3569, BindToParent 14]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(14) >= 0 && AnimElemTime(15) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 13,9

[State 3569, BindToParent 15]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(15) >= 0 && AnimElemTime(16) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 10,4

[State 3569, BindToParent 16]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(16) >= 0 && AnimElemTime(17) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 8,0

[State 3569, BindToParent 17]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(17) >= 0 && AnimElemTime(18) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 4,-4

[State 3569, BindToParent 18]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(18) >= 0 && AnimElemTime(19) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = 1,-9

[State 3569, BindToParent 19]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(19) >= 0 && AnimElemTime(20) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -2,-14

[State 3569, BindToParent 20]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(20) >= 0 && AnimElemTime(21) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -6,-18

[State 3569, BindToParent 21]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(21) >= 0 && AnimElemTime(22) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -9,-22

[State 3569, BindToParent 22]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(22) >= 0 && AnimElemTime(23) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -11,-24

[State 3569, BindToParent 23]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(23) >= 0 && AnimElemTime(24) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -14,-27

[State 3569, BindToParent 24]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(24) >= 0 && AnimElemTime(25) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -16,-28

[State 3569, BindToParent 25]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(25) >= 0 && AnimElemTime(26) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -16,-27

[State 3569, BindToParent 26]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(26) >= 0 && AnimElemTime(27) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -17,-25

[State 3569, BindToParent 27]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(27) >= 0 && AnimElemTime(28) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -17,-23

[State 3569, BindToParent 28]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(28) >= 0 && AnimElemTime(29) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -16,-19

[State 3569, BindToParent 29]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(29) >= 0 && AnimElemTime(30) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -14,-15

[State 3569, BindToParent 30]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(30) >= 0 && AnimElemTime(31) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -13,-10

[State 3569, BindToParent 31]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(31) >= 0 && AnimElemTime(32) < 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -10,-5

[State 3569, BindToParent 32]
type = BindToParent
triggerall = Anim = 3419
triggerall = AnimElemTime(32) >= 0
trigger1 = parent, stateno = 3560
trigger2 = parent, stateno = 3561
pos = -8,0

[State 3569, SprPriority 1]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 4
value = 3

[State 3569, SprPriority 2]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 8
value = 0

[State 3569, SprPriority 3]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 12
value = -1

[State 3569, SprPriority 4]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 16
value = 0

[State 3569, SprPriority 5]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 20
value = 3

[State 3569, SprPriority 6]
type = SprPriority
trigger1 = Anim = 3419
trigger1 = AnimElem = 28
value = 4

;[State 3569, 3]
;type = PosAdd
;trigger1 = Anim = 1212
;trigger1 = parent, stateno != 2310
;trigger1 = parent, stateno != 2311
;x = -5 + 27*cos(2*PI*(AnimElemNo(0)+7)/32)
;y = -5 +  5*sin(2*PI*(AnimElemNo(0)+7)/32)

[State 3569, 4]
type = ChangeAnim
trigger1 = Anim = 3419
trigger1 = parent, stateno != 3560
trigger1 = parent, stateno != 3561
value = 1213

[State 3569, 5]
type = DestroySelf
trigger1 = Anim = 1213
trigger1 = AnimTime = 0

;Pharaoh Decoration - Crushed
[Statedef 3586]
type = L
movetype = H
physics = N
velset = 0,0

[State 3586, 1] ;Royal Judgement P2 Anim
type = RemoveExplod
trigger1 = Time = 0
ID = 3557

[State 3586, 2]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3586, 3]
type = LifeAdd
trigger1 = Time = 0
value = -60

[State 3586, 4]
type = ChangeAnim
trigger1 = Time = 0
value = 5110

[State 3586, 5]
type = Turn
trigger1 = Time = 0

[State 3586, 6]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3586, 7]
type = PlayerPush
trigger1 = 1
value = 0

[State 3586, 8]
type = ChangeState
trigger1 = Time = 57
value = 3547
