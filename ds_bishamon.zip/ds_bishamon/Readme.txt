                            __________________________________________
===========================| Bishamon by varo_hades	              |===========================
                            ������������������������������������������        [12.08.17]

 - Contact:	varo_hades@hotmail.com
 - Website:	Comming soon
 - Customized version of Capcom's Bishamon character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, Darkstalkers

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.
 (B)   - Only Normal Bishamon 
 (O)   - Only Oboro Bishamon
 (M)   - Only Master Bishamon

<NORMAL>

.Sword combo 1				F + x, F + x
.Sword combo 2				F + y, F + y
.Sword combo 3				F + z, F + z
.Sword thrust 1				F + a			
.Sword thrust 2				F + b
.Sword thrust 3				F + c
.Kesa Nage:	         		F/B + 2p / 2k		(near opponent)
.Mitama Nuki:				F/B + 2p		(Air, near opponent)

<SPECIAL>

.Kien Zan (EX)				F, D, DF, p
.Iaigiri (EX)				(charge) B, F, p
.Iaigiri Low (EX)			(charge) B, F, k
.Hane Ha (EX) (B) (M)			B, D, DF, F, p
.Kareme Dama (EX) (B) (M)		B, D, DF, F, p		(Air only)	
.Tama Yose (B) (M)			B + p			(After Hane Ha/Kareme Dama)
.Tsuji Hayate (EX) (B) (M)		D, DF, F, p		(After Hane Ha/Kareme Dama)
.Kirisute Gomen (EX)			F, D, DB, B, p		
.Shikabanenui (EX) (B) (M)		D, D, k
.Kibi Tsukane (EX) (O) (M)		F, D, DF, k
.Oni Naburi (EX) (O) (M)		B, D, DF, F, k
.Nu Kien Zan (EX) (O) (M)		B, D, DB, p

<SUPER>

.Oni Kubi Hineri (MAX):			D, DB, B, D, DB, B, p
.Enma Ishi (MAX):			D, DF, F, D, DF, F, k
.Togakubi Sarashi (MAX):		D, D, p
.Kimen Kudaki (MAX) (O) (M):		D, DF, F, D, DF, F, p

<Lv3 SUPER>

.Tsurane Giri (B) (M):        		D, DB, B, D, DB, B, 2k
.Devil Spirit (O) (M):               	D, DB, B, D, DB, B, 2k / D, DF, F, D, DB, B, 2p (M) / D, DB, B, D, DF, F, 2p (M)

<SYSTEM>

.Forward Dash:                  	F, F
   .Run:                        	hold
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	a + x
   .Sidestep Attack:            	p / k
.Forward Roll:                  	F + a + x
.Backward Roll:                 	B + a + x
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold b + y
.Zero Counter:                  	B, DB, D, p / k 	(during standing or crouching guard)
.Custom Combo:                  	c + z           	(Air also)
.Fall Recovery:                 	2p / a + x      	(while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

=====<Miscellaneous>=====

- To change his size to TV aspect ratio (a.k.a. CvS scale), open the .def file and replace
  "ConstantsSFZ.cns" with "ConstantsCvS.cns".

=====<Version History>=====

<12/08/17>
 - First release

=====<Special Thanks>=====
 - 3ha for code 
 - P.o.t.S. for code, effects, hitsparks, formatting style
 - Ghostfox12 for sprites
 - Iced for Color separation?
 - Hades for hyper portrait and hyper fonts
 - Everybody at the MUGEN Fighters Guild for feedback

=====<Disclaimer>=====

 - The Bishamon character is property of Capcom
 - Capcom vs SNK is property of Capcom
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes