; _________________________________________
;| Bishamon by varo_hades                  |
; �����������������������������������������
;==============================================================================================
;========================================<SPECIAL MOVES>=======================================
;==============================================================================================

;=====================<KIEN ZAN>==========================
[StateDef 1000]
type = S
physics = S
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1000, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
attr = S, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 130, ifElse(var(10), 120, 110)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 130, ifElse(var(10), 120, 110)))), 7
guardflag = MA
pausetime = 14,14
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -45
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-7.5
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1000, 10]
type = playsnd
trigger1 = animelem = 1
value = 1000,0

[State 1000, 11]
type = NotHitBy
trigger1 = Time = 0
value = SCA
time = 8

[State 1000, 18]
type = MoveHitReset
Trigger1 = 1

[State 1000, 19]
type = ChangeState
trigger1 = animtime = 0
trigger1 = var(10) = 0
value = 1001

[State 1000, 20]
type = ChangeState
trigger1 = animtime = 0
trigger1 = var(10) = 1
value = 1002

[State 1000, 21]
type = ChangeState
trigger1 = animtime = 0
trigger1 = var(10) = 2
value = 1003

;Kien Zan 1
[Statedef 1001]
type = A
movetype = A
physics = N
juggle = 4
poweradd = 100 * !var(20)
velset = 1.2, -4.5
anim = 1010
ctrl = 0
sprpriority = 2
hitdefpersist = 1

[State 1100, Dust Helper]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8100
ID = 8100
name = "Kien Zan Dust"
posType = P1
ownPal = 1

[State 1010, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = time = 0
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 110 < 7, 7, fvar(11) * 110)), 12
guardflag = MA
pausetime = 14,14
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -120
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-7.5
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1010, 2]
type = VelAdd
trigger1 = 1
y = .3

[State 1010, 5]
type = ChangeState
trigger1 = animtime = 0
value = 1004

;Kien Zan 2
[Statedef 1002]
type = A
movetype = A
physics = N
juggle = 4
poweradd = 100 * !var(20)
velset = 2.1, -6.5
anim = 1010
ctrl = 0
sprpriority = 2
hitdefpersist = 1

[State 1100, Dust Helper]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8100
ID = 8100
name = "Kien Zan Dust"
posType = P1
ownPal = 1

[State 1020, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = time = 0
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 120 < 7, 7, fvar(11) * 120)), 12
guardflag = MA
pausetime = 14,14
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -120
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-7.5
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1020, 2]
type = VelAdd
trigger1 = 1
y = .35

[State 1020, 5]
type = ChangeState
trigger1 = animtime = 0
value = 1004

;Kien Zan 3
[Statedef 1003]
type = A
movetype = A
physics = N
juggle = 4
poweradd = 100 * !var(20)
velset = 3.8, -9.5
anim = 1010
ctrl = 0
sprpriority = 2
hitdefpersist = 1

[State 1100, Dust Helper]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8100
ID = 8100
name = "Kien Zan Dust"
posType = P1
ownPal = 1

[State 1030, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = time = 0
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 130 < 7, 7, fvar(11) * 130)), 12
guardflag = MA
pausetime = 14,14
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -120
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-7.5
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1030, 2]
type = VelAdd
trigger1 = 1
y = .40

[State 1030, 5]
type = ChangeState
trigger1 = animtime = 0
value = 1004

;Kien Zan (Coming Down)
[Statedef 1004]
type = A
movetype = A
physics = N
velset = 0, 0
anim = 1020

[State 1040, 1]
type = VelAdd
trigger1 = 1
y = .45

[State 1040, 2]
type = ChangeState
trigger1 = Vel Y > 0 && Pos Y >= 0
value = 1005

;Kien Zan (Landing)
[Statedef 1005]
type = S
physics = S
velset = 0, 0
ctrl = 0
anim = 47

[State 1101, EX Flash Off]
type = VarSet
trigger1 = !Time
var(25) = 0

[State 1101, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 1101, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1101, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0

[State 1101, End]
type = ChangeState
trigger1 = AnimElemTime(2) = 2 && command = "holddown"
value = 11
ctrl = 1

[State 1101, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX KIEN ZAN>=============================
[StateDef 1030]
type = S
physics = S
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1000, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
attr = S, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 37 < 7, 7, fvar(11) * 37)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 5,10
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -45
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -1,-7.5
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1000, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 2 || var(20))
trigger1 = AnimElem = 3
attr = S, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 37 < 7, 7, fvar(11) * 37)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 6,10
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -70
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-10
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1000, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 4
attr = S, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 37 < 7, 7, fvar(11) * 37)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 6,10
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -80
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-10
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1060, 4]
type = playsnd
trigger1 = animelem = 1
value = 1000,0
channel = 0

[State 1060, 6]
type = NotHitBy
trigger1 = Time >= 0
value = SCA
time = 1

[State 1060, 13]
type = ChangeState
trigger1 = animtime = 0
value = 1031

;Ex Air
[Statedef 1031]
type = A
movetype = A
physics = N
velset = 3.8, -9.5
anim = 1030
ctrl = 0
sprpriority = 2
hitdefpersist = 1

[State 1100, Dust Helper]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8100
ID = 8100
name = "Kien Zan Dust"
posType = P1
ownPal = 1

[State 1030, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = time = 0
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 39 < 7, 7, fvar(11) * 39)), 12
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 5,10
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -100
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-10
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1070, 2]
type = VelAdd
trigger1 = 1
y = .4

[State 1070, 3]
type = Explod
trigger1 = time = 0
anim = 1040
postype = p1
pos = 110, -55
bindtime = 1
ownpal = 1
sprpriority = 3
pausemovetime = -1

[State 1070, 6]
type = ChangeState
trigger1 = animtime = 0
value = 1004

;=====================<NU KIEN ZAN>==========================
[StateDef 1050]
type = S
physics = S
moveType = A
anim = 1050
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 2100, 1]
type = PlaySnd
trigger1 = Time = 2
value = 1000, 1

[State 2100, 2]
type = Veladd
triggerall = var(10) = 0
trigger1 = AnimElem = 2
trigger2 = AnimElem = 6
x = 5

[State 2100, 2]
type = Veladd
triggerall = var(10) = 1
trigger1 = AnimElem = 2
trigger2 = AnimElem = 6
x = 10

[State 2100, 2]
type = Veladd
triggerall = var(10) = 2
trigger1 = AnimElem = 2
trigger2 = AnimElem = 6
x = 15

[State 2100, 3]
type = Velset
trigger1 = AnimElem = 3
x = 0

[State 2100, 6] ;Opponent near
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, SA
animtype = Light
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 70, ifElse(var(10), 65, 60)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 75, ifElse(var(10), 70, 65)))), 7
priority = 6
guardflag = MA
pausetime = 5,15
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 100), var(36) := -61
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 12
ground.hittime  = 15
ground.velocity = -4,0
air.velocity = -4,0
fall = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 2100, 8]
type = ChangeState
trigger1 = AnimTime = 0
value = 1060

; Nu Kien Zan (Upward Slash)
[Statedef 1060]
type    = A
movetype= A
physics = S
juggle  = 4
poweradd= 110 * !var(20)
velset = 0,0
anim = 1060
ctrl = 0
sprpriority = 2

[State 1100, Dust Helper]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8100
ID = 8100
name = "Nu Kien Zan Dust"
posType = P1
ownPal = 1

[State 2110, 1]
type = PlaySnd
trigger1 = Time = 2
value = 1000, 0

[State 2110, 2]
type = VelAdd
trigger1 = time = [0, 5]
x = 2

[State 2110, 3]
type = Veladd
trigger1 = var(10) = 0
trigger1 = AnimElem  = 3
y = -5

[State 2110, 3]
type = Veladd
trigger1 = var(10) = 1
trigger1 = AnimElem = 3
y = -7

[State 2110, 3]
type = Veladd
trigger1 = var(10) = 2
trigger1 = AnimElem  =3
y = -9

[State 2110, 4]
type = Veladd
trigger1 = Pos Y < 0
trigger1 = Vel Y < 0
trigger1 = time > 0
y = 0.5

[State 1030, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 1
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 70, ifElse(var(10), 65, 60)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 75, ifElse(var(10), 70, 65)))), 7
guardflag = MA
pausetime = 5,15
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -45
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-8
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1030, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2 && !MoveContact
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 70, ifElse(var(10), 65, 60)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 75, ifElse(var(10), 70, 65)))), 7
guardflag = MA
pausetime = 5,15
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -70
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-8
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1030, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3 && !MoveContact
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 70, ifElse(var(10), 65, 60)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 75, ifElse(var(10), 70, 65)))), 7
guardflag = MA
pausetime = 5,15
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -120
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-8
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 2110, 7]
type = ChangeState
trigger1 = time > 9
trigger1 = Vel Y >= 0
value = 1070

;Nu Kien Zan (Falling)
[Statedef 1070]
type    = A
physics = S
juggle  = 4
anim = 1070
velset = 0,0

[State 2020, 0]
type = ChangeState
trigger1 = AnimTime = 0
value = 1004

;========================<EX NU KIEN ZAN>=============================
[StateDef 1080]
type = S
physics = S
moveType = A
anim = 1050
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 2100, 1]
type = PlaySnd
trigger1 = Time = 2
value = 1000, 1
channel = 0

[State 2100, 2]
type = Veladd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 6
x = 20

[State 2100, 3]
type = Velset
trigger1 = AnimElem = 3
x = 0

[State 2100, 6] ;Opponent near
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, SA
animtype = Light
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
priority = 6
guardflag = MA
pausetime = 5,15
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 100), var(36) := -61
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 12
ground.hittime  = 15
ground.velocity = -4,0
air.velocity = -4,0
fall = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 2100, 8]
type = ChangeState
trigger1 = AnimTime = 0
value = 1090

; Nu Kien Zan (Upward Slash)
[Statedef 1090]
type = A
movetype = A
physics = S
juggle = 4
poweradd= 0
velset = 0,0
anim = 1080
ctrl = 0
sprpriority = 2

[State 1100, Dust Helper]
type = Helper
trigger1 = AnimElem = 4
helperType = Normal
stateNo = 8100
ID = 8100
name = "Nu Kien Zan Dust"
posType = P1
ownPal = 1

[State 2110, 1]
type = PlaySnd
trigger1 = Time = 2
value = 1000, 0

[State 2110, 2]
type = VelAdd
trigger1 = time = [0, 5]
x = 2

[State 2110, 3]
type = Veladd
trigger1 = AnimElem  = 4
y = -11

[State 2110, 4]
type = Veladd
trigger1 = Pos Y < 0
trigger1 = Vel Y < 0
trigger1 = time > 0
y = 0.5

[State 1030, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 2 || var(20))
trigger1 = AnimElem = 1
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 5,10
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -45
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-8
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1030, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 2
trigger2 = AnimElem = 3
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 5,10
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -70
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-8
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1030, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = AnimElem = 4
attr = A, SA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 5,10
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 180), var(36) := -120
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-8
air.velocity = -2,-8
fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 2110, 7]
type = ChangeState
trigger1 = time > 14
trigger1 = Vel Y >= 0
value = 1070

;========================<IAGIRI>=============================
[StateDef 1100]
type = S
physics = S
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 85, ifElse(var(10), 80, 75)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 85, ifElse(var(10), 80, 75)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 11, 10
guard.pauseTime = 11, 10
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -3.5, -7), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -3.5, -7)
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 7
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 85, ifElse(var(10), 80, 75)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 85, ifElse(var(10), 80, 75)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 11, 10
guard.pauseTime = 11, 10
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -3.5, -7), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -3.5, -7)
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, 3]
type = playsnd
trigger1 = animelem = 5
value = 1,6

[State 1100, 4]
type = playsnd
trigger1 = animelem = 1
value = 1100,0

[State 1100, 5]
type = Explod
trigger1 = animelem = 5
anim = 1160
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1160
sprpriority = 3
pausemovetime = -1

[State 1100, 6]
type = Explod
trigger1 = animelem = 7
anim = 1161
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1161
sprpriority = 3
pausemovetime = -1

[State 1100, 7]
type = Explod
trigger1 = animelem = 8
anim = 1162
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1162
sprpriority = 3
pausemovetime = -1

[State 1100, 8]
type = RemoveExplod
trigger1 = animelem = 7
ID = 1160

[State 1100, 9]
type = RemoveExplod
trigger1 = animelem = 8
ID = 1161

[State 1100, 15]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;========================<EX IAIGIRI>=============================
[StateDef 1130]
type = S
physics = S
moveType = A
anim = 1120
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1130, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1130, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1130, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 91

[State 1130, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1130, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1120, 42]
type = VarSet
trigger1 = AnimElem = 2
var(41) = 10

[State 1130, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 6
trigger2 = AnimElem = 15
trigger3 = AnimElem = 19
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 22 < 7, 7, fvar(11) * 22)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 11, 11
guard.pauseTime = 11, 11
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 7
trigger2 = AnimElem = 14
trigger3 = AnimElem = 20
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 22 < 7, 7, fvar(11) * 22)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 11, 11
guard.pauseTime = 11, 11
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -75
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 8
trigger2 = AnimElem = 13
trigger3 = AnimElem = 21
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 22 < 7, 7, fvar(11) * 22)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 11, 13
guard.pauseTime = 11, 13
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1120, 4]
type = playsnd
trigger1 = animelem = 5
value = 1,6
channel = 2

[State 1120, 5]
type = playsnd
trigger1 = animelem = 1
value = 1100,0
Channel = 0

[State 1120, 6]
type = Explod
trigger1 = animelem = 5
anim = 1160
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1160
sprpriority = 3
pausemovetime = -1

[State 1120, 7]
type = Explod
trigger1 = animelem = 7
anim = 1161
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1161
sprpriority = 3
pausemovetime = -1

[State 1120, 8]
type = Explod
trigger1 = animelem = 8
anim = 1163
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1162
sprpriority = 3
pausemovetime = -1

[State 1120, 9]
type = Explod
trigger1 = animelem = 9
anim = 1164
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1163
sprpriority = 3
pausemovetime = -1

[State 1120, 10]
type = Explod
trigger1 = animelem = 13
anim = 1180
postype = p1
pos = 38, -80
bindtime = -1
ownpal = 1
ID = 1160
sprpriority = 1
pausemovetime = -1

[State 1120, 11]
type = Explod
trigger1 = animelem = 14
anim = 1181
postype = p1
pos = 38, -80
bindtime = -1
ownpal = 1
ID = 1161
sprpriority = 3
pausemovetime = -1

[State 1120, 12]
type = Explod
trigger1 = animelem = 15
anim = 1182
postype = p1
pos = 38, -80
bindtime = -1
ownpal = 1
ID = 1162
sprpriority = 3
pausemovetime = -1

[State 1120, 13]
type = Explod
trigger1 = animelem = 16
anim = 1183
postype = p1
pos = 40, -80
bindtime = -1
ownpal = 1
ID = 1163
sprpriority = 3
pausemovetime = -1

[State 1120, 14]
type = Explod
trigger1 = animelem = 18
anim = 1170
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1160
sprpriority = 3
pausemovetime = -1

[State 1120, 15]
type = Explod
trigger1 = animelem = 20
anim = 1171
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1161
sprpriority = 3
pausemovetime = -1

[State 1120, 16]
type = Explod
trigger1 = animelem = 21
anim = 1172
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1162
sprpriority = 3
pausemovetime = -1

[State 1120, 17]
type = Explod
trigger1 = animelem = 22
anim = 1173
postype = p1
pos = 38, -62
bindtime = -1
ownpal = 1
ID = 1163
sprpriority = 3
pausemovetime = -1

[State 1120, 18]
type = RemoveExplod
trigger1 = animelem = 7
trigger2 = animelem = 14
trigger3 = animelem = 20
ID = 1160

[State 1120, 19]
type = RemoveExplod
trigger1 = animelem = 8
trigger2 = animelem = 15
trigger3 = animelem = 21
ID = 1161

[State 1120, 20]
type = RemoveExplod
trigger1 = animelem = 9
trigger2 = animelem = 16
trigger3 = animelem = 22
ID = 1162

[State 1120, 43]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;========================<IAGIRI LOW>=============================
[StateDef 1200]
type = S
physics = S
moveType = A
anim = 1130
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
attr = C, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 85, ifElse(var(10), 80, 75)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 85, ifElse(var(10), 80, 75)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 11, 10
guard.pauseTime = 11, 10
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -3.5, -7), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -3.5, -7)
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -15
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
attr = C, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 85, ifElse(var(10), 80, 75)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 85, ifElse(var(10), 80, 75)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 11, 10
guard.pauseTime = 11, 10
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -3.5, -7), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -3.5, -7)
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -23
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1150, 3]
type = playsnd
trigger1 = animelem = 4
value = 1,6

[State 1150, 4]
type = playsnd
trigger1 = animelem = 1
value = 1100,0

[State 1150, 5]
type = Explod
trigger1 = animelem = 4
anim = 1160
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1160
sprpriority = 3
pausemovetime = -1

[State 1150, 6]
type = Explod
trigger1 = animelem = 6
anim = 1161
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1161
sprpriority = 3
pausemovetime = -1

[State 1150, 7]
type = Explod
trigger1 = animelem = 7
anim = 1162
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1162
sprpriority = 3
pausemovetime = -1

[State 1150, 8]
type = RemoveExplod
trigger1 = animelem = 6
ID = 1160

[State 1150, 9]
type = RemoveExplod
trigger1 = animelem = 7
ID = 1161

[State 1150, 15]
type = ChangeState
trigger1 = animtime = 0
value = 11
ctrl = 1

;========================<EX IAIGIRI LOW>=============================
[StateDef 1230]
type = S
physics = S
moveType = A
anim = 1150
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1130, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1130, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1130, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 91

[State 1130, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1130, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1170, 42]
type = VarSet
trigger1 = AnimElem = 2
var(41) = 10

[State 1130, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 5
trigger2 = AnimElem = 12
trigger3 = AnimElem = 15
attr = C, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 22 < 7, 7, fvar(11) * 22)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 11, 10
guard.pauseTime = 11, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -15
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 6
trigger2 = AnimElem = 11
trigger3 = AnimElem = 16
attr = C, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 22 < 7, 7, fvar(11) * 22)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 11, 10
guard.pauseTime = 11, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -20
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 7
trigger2 = AnimElem = 10
trigger3 = AnimElem = 17
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 22 < 7, 7, fvar(11) * 22)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 11, 13
guard.pauseTime = 11, 13
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -26
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1170, 4]
type = playsnd
trigger1 = animelem = 4
value = 1,6
channel = 2

[State 1170, 5]
type = playsnd
trigger1 = animelem = 1
value = 1100,0
channel = 0

[State 1170, 6]
type = Explod
trigger1 = animelem = 4
anim = 1160
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1160
sprpriority = 3
pausemovetime = -1

[State 1170, 7]
type = Explod
trigger1 = animelem = 6
anim = 1161
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1161
sprpriority = 3
pausemovetime = -1

[State 1170, 8]
type = Explod
trigger1 = animelem = 7
anim = 1163
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1162
sprpriority = 3
pausemovetime = -1

[State 1170, 9]
type = Explod
trigger1 = animelem = 8
anim = 1164
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1163
sprpriority = 3
pausemovetime = -1

[State 1170, 10]
type = Explod
trigger1 = animelem = 10
anim = 1180
postype = p1
pos = 60, -30
bindtime = -1
ownpal = 1
ID = 1160
sprpriority = 1
pausemovetime = -1

[State 1170, 11]
type = Explod
trigger1 = animelem = 11
anim = 1181
postype = p1
pos = 60, -30
bindtime = -1
ownpal = 1
ID = 1161
sprpriority = 3
pausemovetime = -1

[State 1170, 12]
type = Explod
trigger1 = animelem = 12
anim = 1182
postype = p1
pos = 60, -30
bindtime = -1
ownpal = 1
ID = 1162
sprpriority = 3
pausemovetime = -1

[State 1170, 13]
type = Explod
trigger1 = animelem = 13
anim = 1183
postype = p1
pos = 60, -30
bindtime = -1
ownpal = 1
ID = 1163
sprpriority = 3
pausemovetime = -1

[State 1170, 14]
type = Explod
trigger1 = animelem = 14
anim = 1170
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1160
sprpriority = 3
pausemovetime = -1

[State 1170, 15]
type = Explod
trigger1 = animelem = 16
anim = 1171
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1161
sprpriority = 3
pausemovetime = -1

[State 1170, 16]
type = Explod
trigger1 = animelem = 17
anim = 1172
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1162
sprpriority = 3
pausemovetime = -1

[State 1170, 17]
type = Explod
trigger1 = animelem = 18
anim = 1173
postype = p1
pos = 60, -13
bindtime = -1
ownpal = 1
ID = 1163
sprpriority = 3
pausemovetime = -1

[State 1170, 18]
type = RemoveExplod
trigger1 = animelem = 6
trigger2 = animelem = 11
trigger3 = animelem = 16
ID = 1160

[State 1170, 19]
type = RemoveExplod
trigger1 = animelem = 7
trigger2 = animelem = 12
trigger3 = animelem = 17
ID = 1161

[State 1170, 20]
type = RemoveExplod
trigger1 = animelem = 8
trigger2 = animelem = 13
trigger3 = animelem = 18
ID = 1162

[State 1170, 43]
type = ChangeState
trigger1 = animtime = 0
value = 11
ctrl = 1

;=====================<HANE HA>==========================
[StateDef 1300]
type = S
physics = S
moveType = A
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1200, 1]
type = PlaySnd
trigger1 = Time = 0
value = 1200, 0

[State 1200, 2]
type = PlaySnd
trigger1 =  AnimElem = 4
value = 1, 7

[State 1200, 6]
type = Varset
trigger1 = Time = 0
var(28) = 0

[State 1200, 7]
type = VarSet
trigger1 = time = 0
var(29) = 1

[State 1200, 8]
type = ChangeState
triggerall = var(29) = 0
trigger1 = Time > 35
trigger2 = Time > 200
value = 1310

;Hane ha (Hold)
[Statedef 1310]
type = S
movetype = I
physics = S
poweradd = 0
velset = 0,0
anim = 1210
ctrl = 0
sprpriority = 2

[State 1210, 1]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Hane ha (Target Hit1)
[Statedef 1360]
type    = S
movetype= H
physics = S
velset = -3,0
anim = 5011

[State 1260, 1]
type = ChangeAnim2
trigger1 = time = 5
value = 1390

[State 1260, 2]
type = ChangeAnim
trigger1 = time = 5
trigger1 = SelfAnimExist(5300)
value = 5300

[State 1260, 3]
type = SelfState
trigger1 = time = 60
trigger2 = p2movetype = H
value = 0
ctrl = 1

;Hane ha (Target Hit2)
[Statedef 1370]
type    = S
movetype= H
physics = S
velset = -5,0
anim = 5011

[State 1270, 1]
type = ChangeAnim2
trigger1 = time = 10
value = 1390

[State 1270, 2]
type = ChangeAnim
trigger1 = time = 10
trigger1 = SelfAnimExist(5300)
value = 5300

[State 1270, 3]
type = SelfState
trigger1 = time = 75
trigger2 = p2movetype = H
value = 0
ctrl = 1

;Hane ha (Target Hit3)
[Statedef 1380]
type    = S
movetype= H
physics = S
velset = -8,0
anim = 5011

[State 1280, 1]
type = ChangeAnim2
trigger1 = time = 15
value = 1390

[State 1280, 2]
type = ChangeAnim
trigger1 = time = 15
trigger1 = SelfAnimExist(5300)
value = 5300

[State 1280, 3]
type = SelfState
trigger1 = time = 100
trigger2 = p2movetype = H
value = 0
ctrl = 1

;========================<EX HANE HA>=============================
[StateDef 1330]
type = S
physics = S
moveType = A
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1200, 1]
type = PlaySnd
trigger1 = animelem = 1
value = 1200, 0
channel = 0

[State 1250, 2]
type = PlaySnd
trigger1 =  AnimElem = 4
value = 1, 7
channel = 2

[State 1250, 4]
type = Varset
trigger1 = Time = 0
var(28) = 0

[State 1250, 7]
type = VarSet
trigger1 = time = 0
var(29) = 1

[State 1250, 8]
type = ChangeState
triggerall = var(29) = 0
trigger1 = Time > 35
value = 1310

;Karame Dama EX (Target Hit1)
[Statedef 1390]
type    = S
movetype= H
physics = S
velset = -10,0
anim = 5011

[State 1290, 1]
type = ChangeAnim2
trigger1 = time = 20
value = 1390

[State 1290, 2]
type = ChangeAnim
trigger1 = time = 20
trigger1 = SelfAnimExist(5300)
value = 5300

[State 1290, 3]
type = SelfState
trigger1 = time = 130
trigger2 = p2movetype = H
value = 0
ctrl = 1

;=====================<KARAME DAMA>==========================
[StateDef 1400]
type = A
physics = N
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 4, ifElse((command = "y" || command = "rlsy"), 5, 6))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1300, 1]
type = PlaySnd
trigger1 = Time = 0
value = 1200, 0

[State 1300, 2]
type = PlaySnd
trigger1 =  AnimElem = 6
value = 1, 7

[State 1300, 6]
type = Varset
trigger1 = Time = 0
var(28) = 0

[State 1300, 7]
type = VarSet
trigger1 = time = 0
var(29) = 1

[State 1300, 8]
type = velset
trigger1 = AnimElem = 6, 8
x = -3.2
y = -1.9

[State 1300, 9]
type = veladd
trigger1 = AnimElem = 6,>= 8
y = .53

[State 1300, 10]
type = ChangeState
trigger1 = (Pos Y >= -10) && (Vel Y >0)
value = 1005
ctrl = 0

;========================<EX KARAME DAMA>=============================
[StateDef 1430]
type = A
physics = N
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 7

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1350, 1]
type = PlaySnd
trigger1 = animelem = 1
value = 1200, 0
channel = 0

[State 1350, 2]
type = PlaySnd
trigger1 =  AnimElem = 6
value = 1, 7
channel = 2

[State 1350, 4]
type = Varset
trigger1 = Time = 0
var(28) = 0

[State 1350, 6]
type = VarSet
trigger1 = time = 0
var(29) = 1

[State 1350, 7]
type = velset
trigger1 = AnimElem = 6, 8
x = -3.2
y = -1.9

[State 1350, 8]
type = veladd
trigger1 = AnimElem = 6,>= 8
y = .53

[State 1350, 9]
type = ChangeState
trigger1 = (Pos Y >= -10) && (Vel Y >0)
value = 1005
ctrl = 0

;=====================<TAMA YOSE>==========================
[StateDef 1440]
type = S
movetype = I
physics = S
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 1400, 1]
type = Varset
trigger1 = Time = 0
var(28) = 0

[State 1400, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Tama Yose (Target Hit)
[Statedef 1450]
type = A
movetype = H
physics = N
velset = p2dist x / 40,-7

[State 1450, 1]
type = ChangeAnim2
trigger1 = time = 0
value = 1450

[State 1450, 2]
type = VelAdd
trigger1 = Time > 0
y = .1;.45

[State 1450, 3]
type = HitFallSet
trigger1 = Time = 0
value = 1

[State 1450, 4]
type = SelfState
trigger1 = Time > 0
trigger1 = Vel Y > 0 && Pos Y > 20
value = 5100

;=====================<TSUJI HAYATE>==========================
[StateDef 1500]
type = S
physics = N
moveType = A
anim = 1500
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1500, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 1500, 2]
type = ScreenBound
trigger1 = FrontEdgeBodyDist < 1
value = 0

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Time = 0
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 70, ifElse(var(10), 65, 60)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 70, ifElse(var(10), 65, 60)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 0, 17
guard.pauseTime = 0, 17
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -1, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1500, 4]
type = VelSet
trigger1 = AnimElem = 3
x = 9

[State 1500, 5]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1500, 0

[State 1500, 8]
type = Varset
trigger1 = Time = 0
var(28) = 0

[State 1500, 9]
type = ChangeState
trigger1 = Time > 6
trigger1 = P2dist X <= 1
value = 1510

;Tsuji Hayate 1
[Statedef 1510]
type = S
movetype = A
physics = N
anim = 1510
velset = 9,0
ctrl = 0
sprpriority = 3

[State 1510, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 1510, 2]
type = ScreenBound
trigger1 = FrontEdgeBodyDist < 1
value = 0

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Time = 0 && p2life > 0
trigger1 = P2dist X <= 1
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 70, ifElse(var(10), 65, 60)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 70, ifElse(var(10), 65, 60)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 0, 10
guard.pauseTime = 0, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = 5, -5.5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -6.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1510, 4]
type = VelSet
trigger1 = AnimElem = 2
x = 0

[State 1510, 5]
type = VelSet
trigger1 = AnimElem = 4
x = -9

[State 1510, 6]
type = Turn
trigger1 = animelem = 4

[State 1510, 9]
type = ChangeState
trigger1 = AnimElem = 4, > 0
trigger1 = P2dist X <= 1
value = 1520

;Tsuji Hayate 2
[Statedef 1520]
type = S
movetype = A
physics = N
anim = 1520
velset = 10,0
ctrl = 0
sprpriority = 3

[State 1520, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 1520, 2]
type = VelSet
trigger1 = AnimElem = 2
x = 0

[State 1520, 3]
type = Turn
trigger1 = animelem = 4

[State 1520, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<EX TSUJI HAYATE>==========================
[StateDef 1530]
type = S
physics = N
moveType = A
anim = 1530
ctrl = 0
velset = 10,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1550, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 1550, 2]
type = ScreenBound
trigger1 = MoveHit = 1
value = 1
movecamera = 0, 1

[State 1550, 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 2 || var(20))
trigger1 = Time = 0
attr = S, SA
animtype  = Hard
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
guardflag = MA
getPower = 0,0
givePower = 36, 36
pausetime = 15,15
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 100), var(36) := -61
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.slidetime = 15
ground.hittime  = 23
ground.velocity = -5
air.velocity = -2,-7.5
p2stateno = ifelse(var(27) = 0,1580, 3490)
p2getp1state = 1
kill = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1550, 4]
type = VarSet
trigger1 = time = 0 && var(27) = 0
var(11) = 1

[state 1550, 5]
type = Helper
trigger1 = MoveHit = 1
trigger1 = NumHelper(1500) = 0
ID = 1500
pos = 0, 0
postype = back
stateno = 1590
helpertype = player
name = "kabe"
keyctrl = 0
ownpal = 1

[State 1550, 6]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1500, 0
channel = 0

[State 1550, 7]
type = TargetBind
trigger1 = MoveHit = 1
pos = 50, 0

[State 1550, 10]
type = Varset
trigger1 = Time = 0
var(28) = 0

[State 1550, 11]
type = ChangeState
trigger1 = Time > 50 && FrontEdgeBodyDist < 1
value = 0
ctrl = 1

[State 1550, 12]
type = ChangeState
trigger1 = MoveGuarded = 1
value = 1575

[State 1550, 13]
type = ChangeState
trigger1 = MoveHit = 1 ;&& FrontEdgeBodyDist < 50
value = 1560

;Tsuji Hayate EX (Target Hit)
[Statedef 1560]
type = S
movetype = A
physics = N
anim = 1540
velset = 0,0
sprpriority = 2

[State 1560, 1]
type = velset
trigger1 = AnimElem = 2
x = -5.6
y = -7.6

[State 1560, 2]
type = StateTypeSet
trigger1 = AnimElem = 2
;value = A

[State 1560, 3]
type = Explod
trigger1 = Timemod = 6, 0 && AnimElemTime(2) >= 0
trigger1 = facing = 1 && var(27) = 0
anim = 1560
postype = p2
pos = 0, ifelse(Time < 40,-40-time*2,-123)
vel = 0, ifelse(Time < 40,-2, 0)
;time = 6
facing = -1
ownpal = 1
ID = 1560
sprpriority = 1
pausemovetime = -1

[State 1560, 4]
type = Explod
trigger1 = Timemod = 6, 0 && AnimElemTime(2) >= 0
trigger1 = facing = -1 && var(27) = 0
anim = 1560
postype = p2
pos = 0, ifelse(Time < 40,-40-time*2,-123)
vel = 0, ifelse(Time < 40,-2, 0)
;time = 6
facing = 1
ownpal = 1
ID = 1560
sprpriority = 1
pausemovetime = -1

[State 1560, 5]
type = veladd
trigger1 = AnimElemTime(2) >= 0
y = .44

[State 1560, 6]
type = ChangeState
trigger1 = (Pos Y >= -10) && (Vel Y >0) && var(27) = 0
value = 1570

;Tsuji Hayate EX
[Statedef 1570]
type = S
movetype = A
physics = S
anim = 1545
velset = 0,0
sprpriority = 2

[State 1570, 1]
type = Posset
trigger1 = Time = 0
y = 0

[State 1570, 2]
type = Explod
trigger1 = Time = 3
trigger1 = facing = 1
anim = 1570
postype = p2
pos = 0, -123
time = 60
facing = -1
ownpal = 1
ID = 1560
sprpriority = 1
pausemovetime = -1

[State 1570, 3]
type = Explod
trigger1 = Time = 3
trigger1 = facing = -1
anim = 1570
postype = p2
pos = 0, -123
time = 60
facing = 1
ownpal = 1
ID = 1560
sprpriority = 1
pausemovetime = -1

[State 1570, 4]
type = Explod
trigger1 = Time = 20
trigger1 = target, selfanimexist(7694) = 0
anim = 1550
postype = p2
pos = 70, target,Const(size.mid.pos.y)
time = 45
facing = -1
ownpal = 1
ID = 1570
removetime = 45
sprpriority = 1
pausemovetime = -1

[State 1570, 5]
type = Explod
trigger1 = Time = 65
trigger1 = target, selfanimexist(7694) = 0
anim = 1555
postype = p2
pos = 70, target,Const(size.mid.pos.y)
vel = -10, 0
time = 15
facing = -1
ownpal = 1
ID = 1570
sprpriority = 1
pausemovetime = -1

[State 1570, 6]
type = ModifyExplod
trigger1 = Time = 69
trigger1 = target, selfanimexist(7694) = 0
ID = 1570
postype = p2
pos = 5, target,Const(size.mid.pos.y)
facing = -1
removetime = 30

[State 1006, HitSpark]
type = Helper
trigger1 = Time = 65
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8016)
ID = 8000
name = "Spark"
posType = P2
pos = 0, target,Const(size.mid.pos.y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1570, 7]
type = PlaySnd
trigger1 = Time = 0
value = 181, 2

[State 1570, 8]
type = PlaySnd
trigger1 = Time = 69
value = 2, 12

[State 1570, 9]
type = TargetLifeAdd
trigger1 = Time = 69
value = -100

[State 1570, 12]
type = ChangeState
trigger1 = P2Stateno = 5110
value = 1005

;Tsuji Hayate EX (Miss)
[Statedef 1575]
type = S
movetype = A
physics = N
anim = 1540
velset = 0,0
sprpriority = 2

[State 1575, 1]
type = velset
trigger1 = AnimElem = 2
x = -4.5
y = -7.6

[State 1575, 2]
type = StateTypeSet
trigger1 = AnimElem = 2
value = A

[State 1575, 3]
type = veladd
trigger1 = AnimElemTime(2) >= 0
y = .44

[State 1575, 4]
type = ChangeState
trigger1 = (Pos Y >= -10) && (Vel Y >0)
value = 1005

;Tsuji Hayate EX 2
[Statedef 1580]
type    = S
movetype= H
physics = S
velset = 0,0
sprpriority = 3

[State 1580, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1580

[State 1580, 2]
type = ChangeAnim2
Trigger1 = p2stateno = 1560
value = 1590

[State 1580, Seppuku]
type = ChangeAnim
trigger1 = Anim = 1590
trigger1 = AnimElem = 1, = 21
trigger1 = selfanimexist(7694)
value = 7694

[State 1580, 3]
type = SelfState
trigger1 = AnimTime = 0
value = 5110

;Karame Dama (Helper)
[Statedef 1590]
type    = S
movetype= A
physics = N
velset = 0,0
anim = 1395

[State 1590, 1]
type = PosFreeze
trigger1 = time >= 0

[State 1590, 2]
type = DestroySelf
trigger1 = Time = 300
trigger2 = Root, stateno = 0
trigger3 = Root, stateno = 1005

;=====================<KIRISUTE GOMEN>==========================
[StateDef 1600]
type = S
physics = S
moveType = A
anim = 1600
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1600, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = S, ST
getpower = 100
givepower = 100
guardflag =
hitflag = M-
sparkNo = -1 + 0 * (var(33) := 0)
numhits = 0
pausetime = 0, 0
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 1610
p2facing = 1
p2stateno = 1680

[State 910, 8]
type = PlaySnd
trigger1 = AnimElem = 4
value = 800,0

[State 1600, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Kirisute Gomen 1
[Statedef 1610]
type    = S
movetype= A
physics = S
ctrl = 0
anim = 1610
sprpriority = 2

[State 1100, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1630, ifElse(var(10) = 1, 1610, 1610))

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
attr = S, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 33, 40)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 33, 40)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 4, 8
guard.pauseTime = 4, 8
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 2 || var(20))
trigger1 = AnimElem = 6
attr = S, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 33, 40)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 33, 40)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 4, 8
guard.pauseTime = 4, 8
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -45
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 7
attr = S, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 32, 40)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 32, 40)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 4, 8
guard.pauseTime = 4, 8
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, ifelse (var(10) = 0, -8, 0)
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = ifelse (var(10) = 0, 1, 0)
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 4]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 8
trigger1 = var(10) = 2
attr = S, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 32, 40)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 32, 40)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 4, 8
guard.pauseTime = 4, 8
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1610, 4]
type = playsnd
trigger1 = animelem = 2
value = 195,1

[State 1610, 5]
type = NotHitBy
trigger1 = Time >= 0
value = SCA
time = 1

[State 1610, 12]
type = MoveHitReset
Trigger1 = 1

[State 1610, 13]
type = PlayerPush
trigger1 = 1
value = 0

[State 1610, Width]
type = Width
trigger1 = Time > 0
edge = 60,0

[State 1610, Bind]
type = TargetBind
trigger1 = AnimElemTime(2) < 0
pos = 50, 0

[State 1610, Bind]
type = TargetBind
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
pos = 36, 0

[State 1610, Bind]
type = TargetBind
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
pos = 25, -55

[State 1610, Bind]
type = TargetBind
trigger1 = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
pos = 40, 0

[State 1610, 14]
type = ChangeState
trigger1 = animtime = 0
value = 1620

;Kirisute Gomen 2
[Statedef 1620]
type    = A
movetype= A
physics = N
velset = 3.8, -9.6
anim = 1620
ctrl = 0
sprpriority = 2
hitdefpersist = 1

[State 1100, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = Time = 0
trigger1 = var(10) = [1,2]
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 32, 40)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 28, ifElse(var(10), 32, 40)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 6, 14
guard.pauseTime = 6, 14
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -8
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -7.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1620, 4]
type = VelAdd
trigger1 = 1
y = .38

[State 1620, 5]
type = ChangeState
trigger1 = animtime = 0
value = 1004

;Kirisute Gomen (Target Hit EX)
[Statedef 1680]
type    = S
movetype= H
physics = S
velset = 0,0

[State 1680, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1680

[State 1680, 2]
type = SelfState
Trigger1 = p2stateno != [1610,1660]
value = 0
ctrl = 1

;=====================<EX KIRISUTE GOMEN>==========================
[StateDef 1630]
type = S
physics = S
moveType = A
anim = 1600
ctrl = 0
velset = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1600, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = S, ST
getpower = 0, 0
givepower = 100
guardflag =
hitflag = M-
sparkNo = -1 + 0 * (var(33) := 0)
numhits = 0
pausetime = 0, 0
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 1660
p2facing = 1
p2stateno = 1680

[State 910, 8]
type = PlaySnd
trigger1 = AnimElem = 4
value = 800,0
channel = 0

[State 1650, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Kirisute Gomen EX 1
[Statedef 1660]
type    = S
movetype= A
physics = S
ctrl = 0
anim = 1660
sprpriority = 2

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
attr = S, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 5, 10
guard.pauseTime = 5, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 2 || var(20))
trigger1 = AnimElem = 6
attr = S, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 5, 10
guard.pauseTime = 5, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -45
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 7
attr = S, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 5, 10
guard.pauseTime = 5, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 4]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 8
attr = S, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 5, 10
guard.pauseTime = 5, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -45
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 5]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = AnimElem = 9
attr = S, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 5, 10
guard.pauseTime = 5, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1660, 6]
type = playsnd
trigger1 = animelem = 2
value = 195,1

[State 1660, 7]
type = NotHitBy
trigger1 = Time >= 0
value = SCA
time = 1

[State 1660, 18]
type = MoveHitReset
Trigger1 = 1

[State 1660, 19]
type = PlayerPush
trigger1 = 1
value = 0

[State 1660, Width]
type = Width
trigger1 = Time > 0
edge = 60,0

[State 1660, Bind]
type = TargetBind
trigger1 = AnimElemTime(2) < 0
pos = 45, 0

[State 1660, Bind]
type = TargetBind
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
pos = 35, 0

[State 1660, Bind]
type = TargetBind
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
pos = 25, -55

[State 1660, Bind]
type = TargetBind
trigger1 = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
pos = 35, 0

[State 1660, 20]
type = ChangeState
trigger1 = animtime = 0
value = 1670

;Kirisute Gomen EX 2
[Statedef 1670]
type    = A
movetype= A
physics = N
velset = 4.2, -9.6
anim = 1620
ctrl = 0
sprpriority = 2
hitdefpersist = 1

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 6 || var(20))
trigger1 = Time = 0
attr = A, SA
hitFlag = MAF
guardFlag =
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 6, 3
guard.pauseTime = 6, 3
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -8
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -10
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1670, 4]
type = VelAdd
trigger1 = 1
y = .38

[State 1670, 5]
type = ChangeState
trigger1 = animtime = 0
value = 1004

;=====================<SHIKABANENUI>==========================
[StateDef 1700]
type = S
physics = N
moveType = A
anim = 1700
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1700, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 1700, 2]
type = velset
trigger1 = AnimElem = 2
x = p2dist x / 16

[State 1700, 3]
type = veladd
trigger1 = Time = [6, 13]
y = -1.2

[State 1700, 4]
type = StateTypeSet
trigger1 = AnimElem = 2
value = A

[State 1700, 5]
type = velset
trigger1 = AnimElem = 10
x = 0
y = 3

[State 1700, 6]
type = veladd
trigger1 = Time >= 22
y = 1.9

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = A, SA
hitFlag = MAFD
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 80, ifElse(var(10), 70, 60)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 80, ifElse(var(10), 70, 60)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Light
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = 0, 0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = 0, 0
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
p1stateno = 1710
p2stateno = 1780

[State 1700, 8]
type = PlaySnd
trigger1 = Time = 5
value = 4, 0

[State 1700, 9]
type = ChangeState
trigger1 = (Pos Y >= -5) && (Vel Y >0)
value = 1005

;Shikabanenui (HIT)
[Statedef 1710]
type = A
movetype = A
physics = N
anim = 1710
velset = 0,0
sprpriority = 2

[State 1710, 3]
type = posset
trigger1 = Time = 0
y = -10

[State 1710, 4]
type = velset
trigger1 = AnimElem = 3
x = -4.5
y = -7.8

[State 1710, 5]
type = veladd
trigger1 = AnimElemTime(3) >= 0
y = .45

[State 1710, 6]
type = ChangeState
trigger1 = (Pos Y >= -10) && (Vel Y >0)
value = 1005

;=====================<EX SHIKABANENUI>==========================
[StateDef 1730]
type = S
physics = N
moveType = A
anim = 1700
ctrl = 0
velset = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1750, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 1750, 2]
type = velset
trigger1 = AnimElem = 2
x = p2dist x / 16

[State 1750, 3]
type = veladd
trigger1 = Time = [6, 13]
y = -1.2

[State 1750, 4]
type = StateTypeSet
trigger1 = AnimElem = 2
value = A

[State 1750, 5]
type = velset
trigger1 = AnimElem = 10
x = 0
y = 3

[State 1750, 6]
type = veladd
trigger1 = Time >= 22
y = 1.9

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = A, SA
hitFlag = MAFD
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Light
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = 0, 0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = 0, 0
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
p1stateno = 1760
p2stateno = 1780

[State 1750, 9]
type = PlaySnd
trigger1 = Time = 5
value = 4, 0
channel = 0

[State 1750, 10]
type = ChangeState
trigger1 = (Pos Y >= -5) && (Vel Y >0)
value = 1005

;Shikabanenui (HIT)
[Statedef 1760]
type = A
movetype = A
physics = N
anim = 1750
velset = 0,0
poweradd= 0
sprpriority = 2

[State 1760, 3]
type = BindToTarget
trigger1 = Time = 0
pos = 0, -10
time = 1

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 2
trigger2 = AnimElem = 4
trigger3 = AnimElem = 6
trigger4 = AnimElem = 8
attr = A, SA
hitFlag = MAFD
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Light
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = 0, 0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = 0, 0
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = AnimElem = 10
attr = A, SA
hitFlag = MAFD
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Light
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = 0, 0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = 0, 0
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
p1stateno = 1770

[State 1760, 14]
type = MoveHitReset
Trigger1 = 1

[State 1760, 15]
type = ChangeState
trigger1 = AnimTime = 0
value = 1770

;Shikabanenui
[Statedef 1770]
type = A
movetype = A
physics = N
anim = 1710
velset = 0,0
sprpriority = 2

[State 1770, 3]
type = velset
trigger1 = AnimElem = 3
x = -4.5
y = -7.8

[State 1770, 4]
type = veladd
trigger1 = AnimElemTime(3) >= 0
y = .45

[State 1770, 5]
type = ChangeState
trigger1 = (Pos Y >= -10) && (Vel Y >0)
value = 1005

;Shikabanenui
[Statedef 1780]
type = L
movetype = H
physics = S
velset = 0,0

[State 1780, 1]
type = posset
Trigger1 = Time = 0
y = 0

[State 1780, 2]
type = SelfState
Trigger1 = Time = 0
value = 5080

;=====================<KIBI TSUKANE>==========================
[StateDef 1800]
type = S
physics = S
moveType = A
anim = 1800
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1100, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1820, ifElse(var(10) = 1, 1810, 1800))

[State 2000, 2]
type = veladd
trigger1 = Animelem = 3
trigger1 = Var(10) = 0
x = 5

[State 2000, 2]
type = veladd
trigger1 = Animelem = 3
trigger1 = Var(10) = 1
x = 8

[State 2000, 2]
type = veladd
trigger1 = Animelem = 3
trigger1 = Var(10) = 2
x = 10

[State 2000, 2v]
type = velset
trigger1 = Animelem = 13
x = 0

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = var(10) = 0
trigger1 = AnimElem = 4
trigger2 = AnimElem = 5
trigger3 = AnimElem = 6
trigger4 = AnimElem = 7
trigger5 = AnimElem = 8
attr = S, SA
hitFlag = M
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 12, 14
guard.pauseTime = 12, 14
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 6 || var(20))
trigger1 = var(10) = 1
trigger1 = AnimElem = 4
trigger2 = AnimElem = 5
trigger3 = AnimElem = 6
trigger4 = AnimElem = 7
trigger5 = AnimElem = 8
trigger6 = AnimElem = 9
attr = S, SA
hitFlag = M
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 27 < 7, 7, fvar(11) * 27)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 12, 14
guard.pauseTime = 12, 14
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 7 || var(20))
trigger1 = var(10) = 2
trigger1 = AnimElem = 4
trigger2 = AnimElem = 5
trigger3 = AnimElem = 6
trigger4 = AnimElem = 7
trigger5 = AnimElem = 8
trigger6 = AnimElem = 9
trigger7 = AnimElem = 10
attr = S, SA
hitFlag = M
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = 12, 14
guard.pauseTime = 12, 14
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 2000, 11]
type = playsnd
trigger1 = animelem = 3
value = 190,0

[State 2000, GhostHead1]
type = Explod
triggerall = AnimElem = 5
trigger1 = !movecontact
anim = 1801
ID = 11111
postype = p1
pos = 85, -50
removetime = 40
ownpal = 1
sprpriority = 3
ignorehitpause = 1

[State 2000, GhostHead2]
type = Explod
triggerall = AnimElem = 5
trigger1 = movecontact
anim = 1801
ID = 11111
postype = p1
pos = 85, -50
removetime = 50
ownpal = 1
sprpriority = 3
ignorehitpause = 1

[State 2000, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<EX KIBI TSUKANE>==========================
[StateDef 1830]
type = S
physics = S
moveType = A
anim = 1830
ctrl = 0
velset = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 2000, 2]
type = veladd
trigger1 = Animelem = 3
x = 13

[State 2000, 2v]
type = velset
trigger1 = Animelem = 13
x = 0

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 8 || var(20))
trigger1 = AnimElem = 4
trigger2 = AnimElem = 5
trigger3 = AnimElem = 6
trigger4 = AnimElem = 7
trigger5 = AnimElem = 8
trigger6 = AnimElem = 9
trigger7 = AnimElem = 10
trigger8 = AnimElem = 11
attr = S, SA
hitFlag = M
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 18
guard.pauseTime = 12, 18
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 2000, 11]
type = playsnd
trigger1 = animelem = 3
value = 190,0
channel = 0

[State 2000, GhostHead1]
type = Explod
triggerall = AnimElem = 5
trigger1 = !movecontact
anim = 1801
ID = 11111
postype = p1
pos = 85, -50
removetime = 40
ownpal = 1
sprpriority = 3
ignorehitpause = 1

[State 2000, GhostHead2]
type = Explod
triggerall = AnimElem = 5
trigger1 = movecontact
anim = 1801
ID = 11111
postype = p1
pos = 85, -50
removetime = 50
ownpal = 1
sprpriority = 3
ignorehitpause = 1

[State 2000, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<ONI NABURI>==========================
[StateDef 1900]
type = S
physics = S
moveType = A
anim = 1900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 2300, 4]
type = ChangeState
trigger1 = animtime = 0
value = 1901

;Oni Naburi (Light)
[Statedef 1901]
type = S
movetype = A
physics = N
anim = 1910
velset = 0,0
sprpriority = 2
ctrl = 0

[State 2310, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 2310, 2]
type = velset
trigger1 = var(10) = 0
trigger1 = AnimElem = 2
x = ifelse(p2dist x / 15 > 2, 2, p2dist x / 15)
y = -6

[State 2320, 2]
type = velset
trigger1 = var(10) = 1
trigger1 = AnimElem = 2
x = ifelse(p2dist x / 25 > 4, 4, p2dist x / 25)
y = -6

[State 2330, 2]
type = velset
trigger1 = var(10) = 2
trigger1 = AnimElem = 2
x = ifelse(p2dist x / 35 > 6, 6, p2dist x / 35)
y = -6

[State 2310, 3]
type = StateTypeSet
trigger1 = AnimElem = 2
value = A

[State 2310, 4]
type = posset
trigger1 = AnimElem = 3
y = -70

[State 2310, 5]
type = veladd
trigger1 = Time >= 4
y = .51

[State 2310, 7]
type = ChangeState
trigger1 = Pos Y >= 0 && Vel Y > 0
value = 1905 ;change

[State 2310, 8]
type = PlaySnd
trigger1 = Time = 0
value = 4, 2

;Oni Naburi (Falling)
[Statedef 1905]
type = S
physics = S
velset = 0, 0
ctrl = 0
anim = 47

[State 2210, 1]
type = PosSet
trigger1 = Time = 0
y = 0

[State 2210, 4]
type = turn
trigger1 = Time = 0
trigger1 = p2dist x < 0

[State 2210, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 1920
ctrl = 1

;Oni Naburi (Slash)
[Statedef 1910]
type = S
movetype = A
physics = S
juggle = 10
poweradd = 15 * !var(20)
ctrl = 0
anim = 1930
sprpriority = 2

[State 3220, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, NA
animtype = Hard
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 130, ifElse(var(10), 120, 110)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 130, ifElse(var(10), 120, 110)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
guardflag = M
pausetime = 10,10
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 100), var(36) := -61
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = High
ground.slidetime = 15
ground.hittime  = 15
ground.velocity = -5.5
air.velocity = -2.5,-4
fall = 1
fall.recover = 0
envshake.time = 12
envshake.ampl = 6; or 7
fall.envshake.time = 20
fall.envshake.ampl = 8
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 3220, 2]
type = playsnd
trigger1 = Animelem = 6
value = 4,3

[State 3220, 3]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Oni Naburi Decision
[Statedef 1920]
type = S
movetype = A
physics = N
anim = 1920
velset = 0,0
sprpriority = 0
ctrl = 0

[State 2230, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 2230, 5]
type = posset
trigger1 = Time = 0
y = 0

[State 2230, 6]
type = ChangeState
triggerAll = p2statetype != A
triggerAll = p2statetype != L
trigger1 = p2bodydist X < 20
value = 1925
ctrl = 1

[State 2230, 7]
type = ChangeState
trigger1 = stateno != 0
value = 1910
ctrl = 1

;Oni Naburi (Grab)
[Statedef 1925]
type = S
movetype = A
physics = S
anim = 1940
ctrl = 0
facep2 = 1

[State 2240, 1]
type = HitDef
triggerall = !var(16) && (var(15) < 1 || var(20))
triggerall = P2MoveType != H
triggerall = P2StateNo != [150,155]
triggerall = P2bodydist X = [-const(size.ground.front),ifelse(!var(5),87,ifelse(var(5)=1,80,70))]
trigger1 = Time = 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
numhits = 0
attr = S, ST
hitflag = M
priority = 6, Miss
sparkno = -1
sprpriority = 5
p1stateno = 1610
p2facing = 1
p2stateno = 1680
p2facing = 1
kill = 0
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
envshake.time = 12
envshake.ampl = 6; or 7
fall.envshake.time = 20
fall.envshake.ampl = 8
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 910, 8]
type = PlaySnd
trigger1 = AnimElem = 3
value = 800,0

[State 2240, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<EX ONI NABURI>==========================
[StateDef 1930]
type = S
physics = S
moveType = A
anim = 1900
ctrl = 0
velset = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 2300, 4]
type = ChangeState
trigger1 = animtime = 0
value = 1931

;Oni Naburi (Light)
[Statedef 1931]
type = S
movetype = A
physics = N
anim = 1910
velset = 0,0
sprpriority = 2
ctrl = 0

[State 2310, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 2330, 2]
type = velset
trigger1 = AnimElem = 2
x = ifelse(p2dist x / 35 > 6, 6, p2dist x / 35)
y = -6

[State 2310, 3]
type = StateTypeSet
trigger1 = AnimElem = 2
value = A

[State 2310, 4]
type = posset
trigger1 = AnimElem = 3
y = -70

[State 2310, 5]
type = veladd
trigger1 = Time >= 4
y = .51

[State 2310, 7]
type = ChangeState
trigger1 = Pos Y >= 0 && Vel Y > 0
value = 1935 ;change

[State 2310, 8]
type = PlaySnd
trigger1 = Time = 0
value = 4, 2
channel = 0

;Oni Naburi (Falling)
[Statedef 1935]
type = S
physics = S
velset = 0, 0
ctrl = 0
anim = 47

[State 2210, 1]
type = PosSet
trigger1 = Time = 0
y = 0

[State 2210, 4]
type = turn
trigger1 = Time = 0
trigger1 = p2dist x < 0

[State 2210, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 1950
ctrl = 1

;Oni Naburi (Slash)
[Statedef 1960]
type = S
movetype = A
physics = S
juggle = 10
poweradd = 15 * !var(20)
ctrl = 0
anim = 1930
sprpriority = 2

[State 3220, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, NA
animtype = Hard
damage = ceil(ifElse(fvar(11) * 150 < 7, 7, fvar(11) * 150)), 7
getPower = 0, 0
givePower = 36, 36
guardflag = M
pausetime = 10,10
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 100), var(36) := -61
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = High
ground.slidetime = 15
ground.hittime  = 15
ground.velocity = -5.5
air.velocity = -2.5,-4
fall = 1
fall.recover = 0
envshake.time = 12
envshake.ampl = 6; or 7
fall.envshake.time = 20
fall.envshake.ampl = 8
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 3220, 2]
type = playsnd
trigger1 = Animelem = 6
value = 4,3

[State 3220, 3]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Oni Naburi Decision
[Statedef 1950]
type = S
movetype = A
physics = N
anim = 1920
velset = 0,0
sprpriority = 0
ctrl = 0

[State 2230, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 2230, 5]
type = posset
trigger1 = Time = 0
y = 0

[State 2230, 6]
type = ChangeState
triggerAll = p2statetype != A
triggerAll = p2statetype != L
trigger1 = p2bodydist X < 20
value = 1955
ctrl = 1

[State 2230, 7]
type = ChangeState
trigger1 = stateno != 0
value = 1960
ctrl = 1

;Oni Naburi (Grab)
[Statedef 1955]
type = S
movetype = A
physics = S
anim = 1940
ctrl = 0
facep2 = 1

[State 2240, 1]
type = HitDef
triggerall = !var(16) && (var(15) < 1 || var(20))
triggerall = P2MoveType != H
triggerall = P2StateNo != [150,155]
triggerall = P2bodydist X = [-const(size.ground.front),ifelse(!var(5),87,ifelse(var(5)=1,80,70))]
trigger1 = Time = 0
getPower = 0, 0
givePower = 36, 36
numhits = 0
attr = S, ST
hitflag = M
priority = 6, Miss
sparkno = -1
sprpriority = 5
p1stateno = 1660
p2facing = 1
p2stateno = 1680
p2facing = 1
kill = 0
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
envshake.time = 12
envshake.ampl = 6; or 7
fall.envshake.time = 20
fall.envshake.ampl = 8
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 910, 8]
type = PlaySnd
trigger1 = AnimElem = 3
value = 800,0

[State 2240, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<PUNCH ZERO COUNTER>=============================
[StateDef 2900]
type = S
physics = N
moveType = A
anim = 2900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2900, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2900, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 2900, Woosh]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,2
channel = 1

[State 2900, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 82 < 7, 7, fvar(11) * 82)), 0
getpower = 0,0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 185), var(36) := -85
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2900, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 2900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<KICK ZERO COUNTER>=============================
[StateDef 2910]
type = S
physics = N
moveType = A
anim = 2910
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2910, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2910, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, 4
channel = 0

[State 2910, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,5
channel = 1

[State 2910, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 4
attr = C, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 82 < 7, 7, fvar(11) * 82)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 196), var(36) := -8
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2910, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 8 && !MoveContact
attr = C, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 82 < 7, 7, fvar(11) * 82)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 176), var(36) := -8
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2910, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(9) >= 0
moveType = I

[State 2910, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
