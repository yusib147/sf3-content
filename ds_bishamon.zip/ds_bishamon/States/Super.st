; _________________________________________
;| Bishamon by varo_hades                  |
; �����������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<ONI KUBI HINERI>=============================
[StateDef 3000]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-45 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 5
attr = S, HT
hitflag = M-
priority = 4, Miss
getpower = 0
givepower = 100
sparkNo = -1 + 0 * (var(33) := 0)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -75
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sprpriority = 0
p2facing = 1
p1stateno = 3020
p2stateno = 3040
fall = 1

[State 810, HitAdd]
type = HitAdd
trigger1 = AnimElem = 5
value = -1

[State 3000, 2]
type = Explod
trigger1 = AnimElem = 3
anim = 3050
postype = p1
ID = 3000
pos = 30, -60
vel = 5, 0
removetime = 7
ownpal = 1
sprpriority = 1
ignorehitpause = 1

[State 3000, 3]
type = ModifyExplod
trigger1 = time = [12,18]
ID = 3000
scale = (time+2)*0.05, (time+2)*0.05

[State 3000, 7]
type = PlaySnd
trigger1 = AnimElem = 2
value = 3000, 1
channel = 0

[State 3000, ????1]
type = Explod
trigger1 = time >= 10
trigger1 = NumExplod(3010) = 0
anim = 3090
postype = p1
ID = 3010
pos = 45, -85
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, ????2]
type = Explod
trigger1 = time >= 12
trigger1 = NumExplod(3020) = 0
anim = 3090
postype = p1
ID = 3020
pos = 40, -45
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, ????3]
type = Explod
trigger1 = time >= 14
trigger1 = NumExplod(3030) = 0
anim = 3090
postype = p1
ID = 3030
pos = 50, -60
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, ????4]
type = Explod
trigger1 = time >= 16
trigger1 = NumExplod(3040) = 0
anim = 3090
postype = p1
ID = 3040
pos = 30, -75
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, ????5]
type = Explod
trigger1 = time >= 16
trigger1 = NumExplod(3050) = 0
anim = 3090
postype = p1
ID = 3050
pos = 33, -50
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, 8]
type = VarSet
trigger1 = AnimElem = 5
var(41) = 1

[State 3000, 9]
type = Varset
trigger1 = time = 0
var(46) = 0

[State 3000, 11]
type = ChangeState
trigger1 = animtime = 0
value = 3010

;Oni Kubi Hineri 1
[Statedef 3010]
type    = S
movetype= I
physics = S
velset = 0,0
ctrl = 0
anim = 3010
sprpriority = 2

[State 3010, 1]
type = Explod
trigger1 = time = 0 && var(46) = 0
anim = 3060
postype = p1
ID = 3000
pos = 70, -60
removetime = 32
ownpal = 1
sprpriority = 1
ignorehitpause = 1

[State 3010, 2]
type = RemoveExplod
trigger1 = var(46) != 0
trigger1 = time = 0
ID = 3000

[State 3010, 3]
type = RemoveExplod
trigger1 = var(46) != 0
trigger1 = time = 0
ID = 3005

[State 3010, 4]
type = Explod
trigger1 = time = 0 && var(46) != 0
anim = 3065
postype = p1
ID = 3000
pos = 70, -60
removetime = 32
ownpal = 1
sprpriority = -2
ignorehitpause = 1

[State 3010, 5]
type = ModifyExplod
trigger1 = Time = 26
ID = 3000
postype = p1
pos = 70, -60
vel = -5, 0

[State 3010, 6]
type = ModifyExplod
trigger1 = time = [26,36]
ID = 3000
scale = (23-time/2)*0.1, (23-time/2)*0.1

[State 3010, ????1]
type = Explod
trigger1 = time <= 25
trigger1 = NumExplod(3010) = 0
anim = 3090
postype = p1
ID = 3010
pos = 45, -85
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????1]
type = ModifyExplod
trigger1 = Time = 25
ID = 3010
postype = p1
pos = 45, -85
vel = -2, 2

[State 3010, ????2]
type = Explod
trigger1 = time <= 25
trigger1 = NumExplod(3020) = 0
anim = 3090
postype = p1
ID = 3020
pos = 40, -45
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????2]
type = ModifyExplod
trigger1 = Time = 25
ID = 3020
postype = p1
pos = 40, -45
vel = -1.7, -1

[State 3010, ????3]
type = Explod
trigger1 = time <= 25
trigger1 = NumExplod(3030) = 0
anim = 3090
postype = p1
ID = 3030
pos = 50, -60
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????3]
type = ModifyExplod
trigger1 = Time = 25
ID = 3030
postype = p1
pos = 50, -60
vel = -2.2, 0

[State 3010, ????4]
type = Explod
trigger1 = time >= 25
trigger1 = NumExplod(3040) = 0
anim = 3090
postype = p1
ID = 3040
pos = 30, -75
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????4]
type = ModifyExplod
trigger1 = Time = 25
ID = 3040
postype = p1
pos = 30, -75
vel = -1.2, .7

[State 3010, ????5]
type = Explod
trigger1 = time >= 25
trigger1 = NumExplod(3050) = 0
anim = 3090
postype = p1
ID = 3050
pos = 33, -50
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????5]
type = ModifyExplod
trigger1 = Time = 25
ID = 3050
postype = p1
pos = 33, -50
vel = -1.3, -.7

[State 3010, 8]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Oni Kubi Hineri HIT
[Statedef 3020]
type = S
movetype = A
physics = N
anim = 3020

[State 3050, tukami]
type = PlaySnd
trigger1 = AnimElem = 1
value = 3000, 0
channel = 0

[State 3050, nigiri]
type = PlaySnd
trigger1 = AnimElem = 1
value = 2, 13

[State 3050, te1]
type = Explod
trigger1 = AnimElem = 1
anim = 3070
postype = p1
ID = 3000
pos = 70, -60
removetime = 32
bindtime = -1
ownpal = 1
sprpriority = -2
ignorehitpause = 1

[State 3050, te2]
type = Explod
trigger1 = AnimElem = 1
anim = 3080
postype = p1
ID = 3005
pos = 70, -60
removetime = 32
bindtime = -1
ownpal = 1
sprpriority = 2
ignorehitpause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = 110, -75
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 810, HitAdd]
type = HitAdd
trigger1 = AnimElem = 1
value = 1

[State 3050, ????1]
type = Explod
trigger1 = NumExplod(3010) = 0
anim = 3090
postype = p1
ID = 3010
pos = 45, -85
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, ????2]
type = Explod
trigger1 = NumExplod(3020) = 0
anim = 3090
postype = p1
ID = 3020
pos = 40, -45
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, ????3]
type = Explod
trigger1 = NumExplod(3030) = 0
anim = 3090
postype = p1
ID = 3030
pos = 50, -60
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, ????4]
type = Explod
trigger1 = NumExplod(3040) = 0
anim = 3090
postype = p1
ID = 3040
pos = 30, -75
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, ????5]
type = Explod
trigger1 = NumExplod(3050) = 0
anim = 3090
postype = p1
ID = 3050
pos = 33, -50
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, Width]
type = Width
trigger1 = Time > 0
edge = 100,0

[State 3050, Bind]
type = TargetBind
trigger1 = AnimElemTime(2) < 0
pos = 110, -75

[State 3050, Bind]
type = TargetBind
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
pos = 110, -70

[State 3050, Bind]
type = TargetBind
trigger1 = AnimElemTime(3) >= 0
pos = 110, -75

[State 3050, Hurt]
type = TargetLifeAdd
trigger1 = AnimElem = 1
value = -40

[State 3050, *6]
type = Varadd
trigger1 = time = 0
var(46) = 1

[State 3050, State End]
type = ChangeState
triggerall = Time = 32
trigger1 = var(46) < 6 && p2life > 0
value = 3020

[State 3050, State End]
type = ChangeState
triggerall = Time = 7
trigger1 = var(46) = 6
trigger2 = p2life = 0
value = 3010

;Oni Kubi Hineri 2
[Statedef 3040]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = 0

[State 3080, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3030

[State 3080, 4]
type = ChangeState
Trigger1 = p2stateno = 3010
value = 3090

;Oni Kubi Hineri 3
[Statedef 3090]
type = A
movetype = H
physics = N
velset = -4.5, -8.5
anim = 5050

[State 3090, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(5061)
value = 5061

[State 3090, 1]
type = posAdd
Trigger1 = Time = 0
y = 60

[State 3090, 2]
type = VelAdd
Trigger1 = Time >= 0
y = .45

[State 3090, 3]
type = SelfState
trigger1 = Vel Y > 0
trigger1 = Pos Y > -20
value = 5100

;========================<MAX ONI KUBI HINERI>=============================
[StateDef 3050]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-45 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 5
attr = S, HT
hitflag = M-
priority = 4, Miss
getpower = 0
givepower = 100
sparkNo = -1 + 0 * (var(33) := 0)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -75
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sprpriority = 0
p2facing = 1
p1stateno = 3070
p2stateno = 3080
fall = 1

[State 810, HitAdd]
type = HitAdd
trigger1 = AnimElem = 5
value = -1

[State 3000, 2]
type = Explod
trigger1 = AnimElem = 3
anim = 3050
postype = p1
ID = 3000
pos = 30, -60
vel = 5, 0
removetime = 7
ownpal = 1
sprpriority = 1
ignorehitpause = 1

[State 3000, 3]
type = ModifyExplod
trigger1 = time = [12,18]
ID = 3000
scale = (time+2)*0.05, (time+2)*0.05

[State 3000, 7]
type = PlaySnd
trigger1 = AnimElem = 2
value = 3000, 1
channel = 0

[State 3000, ????1]
type = Explod
trigger1 = time >= 10
trigger1 = NumExplod(3010) = 0
anim = 3090
postype = p1
ID = 3010
pos = 45, -85
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, ????2]
type = Explod
trigger1 = time >= 12
trigger1 = NumExplod(3020) = 0
anim = 3090
postype = p1
ID = 3020
pos = 40, -45
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, ????3]
type = Explod
trigger1 = time >= 14
trigger1 = NumExplod(3030) = 0
anim = 3090
postype = p1
ID = 3030
pos = 50, -60
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, ????4]
type = Explod
trigger1 = time >= 16
trigger1 = NumExplod(3040) = 0
anim = 3090
postype = p1
ID = 3040
pos = 30, -75
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, ????5]
type = Explod
trigger1 = time >= 16
trigger1 = NumExplod(3050) = 0
anim = 3090
postype = p1
ID = 3050
pos = 33, -50
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, 8]
type = VarSet
trigger1 = AnimElem = 5
var(41) = 1

[State 3000, 9]
type = Varset
trigger1 = time = 0
var(46) = 0

[State 3000, 11]
type = ChangeState
trigger1 = animtime = 0
value = 3060

;Oni Kubi Hineri 1
[Statedef 3060]
type = S
movetype = I
physics = S
velset = 0,0
ctrl = 0
anim = 3010
sprpriority = 2

[State 3010, 1]
type = Explod
trigger1 = time = 0 && var(46) = 0
anim = 3060
postype = p1
ID = 3000
pos = 70, -60
removetime = 32
ownpal = 1
sprpriority = 1
ignorehitpause = 1

[State 3010, 2]
type = RemoveExplod
trigger1 = var(46) != 0
trigger1 = time = 0
ID = 3000

[State 3010, 3]
type = RemoveExplod
trigger1 = var(46) != 0
trigger1 = time = 0
ID = 3005

[State 3010, 4]
type = Explod
trigger1 = time = 0 && var(46) != 0
anim = 3065
postype = p1
ID = 3000
pos = 70, -60
removetime = 32
ownpal = 1
sprpriority = -2
ignorehitpause = 1

[State 3010, 5]
type = ModifyExplod
trigger1 = Time = 26
ID = 3000
postype = p1
pos = 70, -60
vel = -5, 0

[State 3010, 6]
type = ModifyExplod
trigger1 = time = [26,36]
ID = 3000
scale = (23-time/2)*0.1, (23-time/2)*0.1

[State 3010, ????1]
type = Explod
trigger1 = time <= 25
trigger1 = NumExplod(3010) = 0
anim = 3090
postype = p1
ID = 3010
pos = 45, -85
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????1]
type = ModifyExplod
trigger1 = Time = 25
ID = 3010
postype = p1
pos = 45, -85
vel = -2, 2

[State 3010, ????2]
type = Explod
trigger1 = time <= 25
trigger1 = NumExplod(3020) = 0
anim = 3090
postype = p1
ID = 3020
pos = 40, -45
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????2]
type = ModifyExplod
trigger1 = Time = 25
ID = 3020
postype = p1
pos = 40, -45
vel = -1.7, -1

[State 3010, ????3]
type = Explod
trigger1 = time <= 25
trigger1 = NumExplod(3030) = 0
anim = 3090
postype = p1
ID = 3030
pos = 50, -60
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????3]
type = ModifyExplod
trigger1 = Time = 25
ID = 3030
postype = p1
pos = 50, -60
vel = -2.2, 0

[State 3010, ????4]
type = Explod
trigger1 = time >= 25
trigger1 = NumExplod(3040) = 0
anim = 3090
postype = p1
ID = 3040
pos = 30, -75
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????4]
type = ModifyExplod
trigger1 = Time = 25
ID = 3040
postype = p1
pos = 30, -75
vel = -1.2, .7

[State 3010, ????5]
type = Explod
trigger1 = time >= 25
trigger1 = NumExplod(3050) = 0
anim = 3090
postype = p1
ID = 3050
pos = 33, -50
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3010, ????5]
type = ModifyExplod
trigger1 = Time = 25
ID = 3050
postype = p1
pos = 33, -50
vel = -1.3, -.7

[State 3010, 8]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Oni Kubi Hineri HIT
[Statedef 3070]
type = S
movetype = A
physics = N
anim = 3020

[State 3050, tukami]
type = PlaySnd
trigger1 = AnimElem = 1
value = 3000, 0
channel = 0

[State 3050, nigiri]
type = PlaySnd
trigger1 = AnimElem = 1
value = 2, 13

[State 3050, te1]
type = Explod
trigger1 = AnimElem = 1
anim = 3070
postype = p1
ID = 3000
pos = 70, -60
removetime = 32
bindtime = -1
ownpal = 1
sprpriority = -2
ignorehitpause = 1

[State 3050, te2]
type = Explod
trigger1 = AnimElem = 1
anim = 3080
postype = p1
ID = 3005
pos = 70, -60
removetime = 32
bindtime = -1
ownpal = 1
sprpriority = 2
ignorehitpause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = 110, -75
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 810, HitAdd]
type = HitAdd
trigger1 = AnimElem = 1
value = 1

[State 3050, ????1]
type = Explod
trigger1 = NumExplod(3010) = 0
anim = 3090
postype = p1
ID = 3010
pos = 45, -85
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, ????2]
type = Explod
trigger1 = NumExplod(3020) = 0
anim = 3090
postype = p1
ID = 3020
pos = 40, -45
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, ????3]
type = Explod
trigger1 = NumExplod(3030) = 0
anim = 3090
postype = p1
ID = 3030
pos = 50, -60
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, ????4]
type = Explod
trigger1 = NumExplod(3040) = 0
anim = 3090
postype = p1
ID = 3040
pos = 30, -75
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, ????5]
type = Explod
trigger1 = NumExplod(3050) = 0
anim = 3090
postype = p1
ID = 3050
pos = 33, -50
random = 10, 10
removetime = 18
sprpriority = 2
ignorehitpause = 1

[State 3050, Width]
type = Width
trigger1 = Time > 0
edge = 100,0

[State 3050, Bind]
type = TargetBind
trigger1 = AnimElemTime(2) < 0
pos = 110, -75

[State 3050, Bind]
type = TargetBind
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(3) < 0
pos = 110, -70

[State 3050, Bind]
type = TargetBind
trigger1 = AnimElemTime(3) >= 0
pos = 110, -75

[State 3050, Hurt]
type = TargetLifeAdd
trigger1 = AnimElem = 1
value = -28

[State 3050, *6]
type = Varadd
trigger1 = time = 0
var(46) = 1

[State 3050, State End]
type = ChangeState
triggerall = Time = 32
trigger1 = var(46) < 12 && p2life > 0
value = 3070

[State 3050, State End]
type = ChangeState
triggerall = Time = 7
trigger1 = var(46) = 12
trigger2 = p2life = 0
value = 3060

;Oni Kubi Hineri 2
[Statedef 3080]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = 0

[State 3080, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3030

[State 3080, 4]
type = ChangeState
Trigger1 = p2stateno = 3060
value = 3090

;========================<ENMA ISHI>=============================
[StateDef 3100]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-50 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, 1]
type = Width
trigger1 = Time > 0
edge = 60,0

[State 1000, Width]
type = Width
trigger1 = AnimElemTime(4) = 0
value = 30,0

[state 3100, 2]
type = helper
trigger1 = AnimElem = 4
trigger1 = NumHelper(3100) = 0
ID = 3000
pos = 80, 5
postype = p1
stateno = 3102
helpertype = normal
name = "ita"
ownpal = 1
;ctrl = 0

[state 3100, 3]
type = helper
trigger1 = AnimElem = 4
trigger1 = NumHelper(3010) = 0
ID = 3010
pos = 80, 5
postype = p1
stateno = 3104
helpertype = normal
name = "ita2"
ownpal = 1
;ctrl = 0

[State 3100, 4]
type = Explod
trigger1 = AnimElem = 4
anim = 3140
postype = p1
pos = 90, 0
removetime = 16
ownpal = 1
sprpriority = 2

[State 3100, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 3100, 0

[State 3100, 6]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1, 8

[State 3100, 7]
type = VarSet
trigger1 = time = 0
var(11) = 2

[State 3100, 8]
type = VarSet
trigger1 = Time >= 47
trigger1 = NumHelper(3010) = 0
var(11) = 0

[State 3100, 9]
type = VarSet
trigger1 = AnimElem = 2
var(41) = 10

[State 3100, 10]
type = ChangeState
trigger1 = Time >= 47
trigger1 = NumHelper(3010) = 0
value = 0
ctrl = 1

[State 3100, 11]
type = ChangeState
triggerall = Time >= 47
triggerall = NumHelper(3000) = 1
trigger1 = helper(3000),stateno = 3103
value = 3101

;Enma Ishi Hit
[Statedef 3101]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 3110

[State 3110, 1]
type = Width
trigger1 = Time > 0
edge = 60,0

[State 3110, 2]
type = PlaySnd
trigger1 = AnimElem = 4
value = 3100, 1

[State 3110, 3]
type = VarSet
trigger1 = animtime = 0
var(11) = 0

[State 3110, 4]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Enma Ishi Attack Frame
[Statedef 3102]
type = S
movetype = A
physics = N
anim = 3120
velset = 5,0
SprPriority = 0

[State 3120, 1]
type = HitDef
trigger1 = !var(16) && var(15) < 3
trigger1 = p2statetype != A
attr = A, HP
damage = 0
animtype = Light
hitflag = MA
guardflag = MA
getpower  = 0
givepower = 20
pausetime = 0, 10
sparkNo = -1 + 0 * (var(33) := 0)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 100), var(36) := -61
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.velocity = -6
p2facing = 1
p1stateno = 3103
p2stateno = 3106
kill = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 5)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3120, 2]
type = PlaySnd
trigger1 = Time = 5
value = 1, 9

[State 3120, 3]
type = ParentVarSet
trigger1 = time >= 0
trigger1 = moveHit = 0
fvar(15) = p2dist x

[State 3120, 4]
type = DestroySelf
trigger1 = time = 60
trigger2 = movecontact = 1
trigger3 = Root, stateno = [5000,5100]
trigger4 = Root, movetype = H

;Enma Ishi Helper1
[Statedef 3103]
type = A
movetype = A
physics = N
anim = 1395

[State 3130, 1]
type = posadd
trigger1 = Time = 0
x = root, fvar(15)
y = -60

[State 3130, 2]
type = TargetBind
trigger1 = Time >= 0
pos = 0, 0

[State 3130, 3]
type = velset
trigger1 = Time = 0
x = - root, fvar(15) / 35
y = - 8

[State 3130, 4]
type = veladd
trigger1 = Time > 0
y = .5

[State 3130, 5]
type = velset
trigger1 = Pos Y > -10 &&  Vel Y > 0
x = 0
y = 0

[State 3130, 6]
type = posset
trigger1 = Pos Y > -10 &&  Vel Y > 0
y = -10

[State 3130, 7]
type = VelSet
trigger1 = Time = 154
x = 4
y = -5

;Stone Slab1
[state 3130, 8]
type = helper
trigger1 = Time = 60
trigger1 = !Enemy,SelfAnimExist(7699)
ID = 3110
pos = 0, -300
postype = p1
stateno = 3180
helpertype = normal
name = "isi1"
ownpal = 1
;ctrl = 0

[state 3130, 8]
type = helper
trigger1 = Time = 60
trigger1 = Enemy,SelfAnimExist(7699)
ID = 3111
pos = 0, -300
postype = p1
stateno = 3181
helpertype = normal
name = "isi1"
ownpal = 1

[State 3130, 11]
type = DestroySelf
trigger1 = Time = 155

;Wooden Board Helper
[Statedef 3104]
type = S
movetype= A
physics = N
anim = 3125
velset = 5,0
SprPriority = 0

[State 3140, 1]
type = velset
trigger1 = p2stateno = 3106
trigger2 = p2stateno = 150 || p2stateno = 152
x = 0

[State 3140, 2]
type = posadd
trigger1 = vel x= 0
trigger1 = FrontEdgeDist < 10
x = -5

[State 3140, 3]
type = ChangeState
trigger1 = NumHelper(3000) = 0
value = 3105

;Wooden Board Dissapper
[Statedef 3105]
type = S
movetype= A
physics = N
velset = 0, 0
anim = 3129

[State 3150, 1]
type = DestroySelf
trigger1 = animtime = 0

;Enma Ishi P2 state 1
[Statedef 3106]
type = A
movetype = H
physics = N
ctrl = 0
sprpriority = 1

[State 3160, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = AnimExist(3180)
value = 3180

[State 3160, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = !AnimExist(3180)
value = 5050

;Send target to default animation if it doesn't have the 7699 custom animation.
[State 3160, 2]
type = ChangeState
trigger1 = Pos Y > -10 &&  Vel Y > 0
trigger1 = !AnimExist(7699)
value = 3107

;If the target has the 7699 custom animation
[State 3160, 2]
type = ChangeState
trigger1 = Pos Y > -10 &&  Vel Y > 0
trigger1 = AnimExist(7699)
value = 3108

;Enma Ishi Default Target Animation
[Statedef 3107]
type = U
movetype = H
physics = N
ctrl = 0
velset = 0, 0
sprpriority = 1

[State 3170, 1] ;Default
type = ChangeAnim
trigger1 = Time = 0
trigger1 = AnimExist(3190)
value = 3190

[State 3170, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = !AnimExist(3190)
value = 5080

[State 3170, 2]
type = LifeAdd
trigger1 = Time = 47
value = ifelse(Life > 240, -240, -(Life-1))

[State 3170, 3]
type = LifeAdd
trigger1 = Time = 117
value = -20

[State 3170, 4]
type = SelfState
trigger1 = time = 200
trigger1 = Pos Y > -20 &&  Vel Y > 0
value = 5100

;Enma Ishi Target Custom Animation
[Statedef 3108]
type = U
movetype = H
physics = N
ctrl = 0
velset = 0, 0
sprpriority = 1

[State 3171, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 7699;5040

[State 3171, 2]
type = LifeAdd
trigger1 = Time = 47
value = ifelse(Life > 240, -240, -(Life-1))

[State 3171, 3]
type = LifeAdd
trigger1 = Time = 117
value = -20

[State 3171, 4]
type = SelfState
trigger1 = time = 200
trigger1 = Pos Y > -20 &&  Vel Y > 0
value = 5100

;Stone Slabs (Default Version)
[Statedef 3180]
type = A
anim = 3130
velset = 0,6
SprPriority = 2

[State 3180, 1]
type = posadd
trigger1 = Time = 0
x = (random % 20) - 10

[State 3180, 2]
type = veladd
trigger1 = Time = [0, 23]
y = .5

[State 3180, 3]
type = velset
trigger1 = Time = 23
y = 0

[State 3180, 4]
type = posset
trigger1 = Time = 23
y = -20

[State 3180, 5]
type = PlaySnd
trigger1 = Time = 23
value = 2, 14

[State 3180, 6]
type = EnvShake
trigger1 = Time = 23
time = 5

[State 3180, 7]
type = velset
trigger1 = Time = 93
y = -9

[State 3180, 8]
type = DestroySelf
trigger1 = Time = 113

;Stone Slabs (Custom Version)
[Statedef 3181]
type = A
anim = 3131
velset = 0,6
SprPriority = 2

[State 3180, 1]
type = posadd
trigger1 = Time = 0
x = (random % 20) - 10

[State 3180, 2]
type = veladd
trigger1 = Time = [0, 23]
y = .5

[State 3180, 3]
type = velset
trigger1 = Time = 23
y = 0

[State 3180, 4]
type = posset
trigger1 = Time = 23
y = -20

[State 3180, 5]
type = PlaySnd
trigger1 = Time = 23
value = 2, 14

[State 3180, 6]
type = EnvShake
trigger1 = Time = 23
time = 5

[State 3180, 7]
type = velset
trigger1 = Time = 93
y = -9

[State 3180, 8]
type = DestroySelf
trigger1 = Time = 113

;Stone Slabs2 (Default Version)
[Statedef 3190]
type = A
anim = 3130
velset = 0,6
SprPriority = 3

[State 3190, 1]
type = posadd
trigger1 = Time = 0
x = (random % 20) - 10

[State 3190, 2]
type = veladd
trigger1 = Time = [0, 22]
y = .5

[State 3190, 3]
type = velset
trigger1 = Time = 22
y = 0

[State 3190, 4]
type = posset
trigger1 = Time = 22
y = -45

[State 3190, 5]
type = PlaySnd
trigger1 = Time = 22
value = 2, 14

[State 3190, 6]
type = EnvShake
trigger1 = Time = 22
time = 5

[State 3190, 7]
type = velset
trigger1 = Time = 81
y = -9

[State 3190, 8]
type = DestroySelf
trigger1 = Time = 101

;Stone Slabs2 (Custom Version)
[Statedef 3191]
type = A
anim = 3131
velset = 0,6
SprPriority = 3

[State 3190, 1]
type = posadd
trigger1 = Time = 0
x = (random % 20) - 10

[State 3190, 2]
type = veladd
trigger1 = Time = [0, 22]
y = .5

[State 3190, 3]
type = velset
trigger1 = Time = 22
y = 0

[State 3190, 4]
type = posset
trigger1 = Time = 22
y = -35;45

[State 3190, 5]
type = PlaySnd
trigger1 = Time = 22
value = 2, 14

[State 3190, 6]
type = EnvShake
trigger1 = Time = 22
time = 5

[State 3190, 7]
type = velset
trigger1 = Time = 81
y = -9

[State 3190, 8]
type = DestroySelf
trigger1 = Time = 101

;Stone Slabs3 (Default Version)
[Statedef 3195]
type = A
anim = 3130
velset = 0,6
SprPriority = 4

[State 3195, 1]
type = posadd
trigger1 = Time = 0
x = (random % 20) - 10

[State 3195, 2]
type = veladd
trigger1 = Time = [0, 20]
y = .5

[State 3195, 3]
type = velset
trigger1 = Time = 20
y = 0

[State 3195, 4]
type = posset
trigger1 = Time = 20
y = -70

[State 3195, 5]
type = PlaySnd
trigger1 = Time = 20
value = 2, 14

[State 3195, 6]
type = EnvShake
trigger1 = Time = 20
time = 5

[State 3195, 7]
type = velset
trigger1 = Time = 70
y = -9

[State 3195, 8]
type = DestroySelf
trigger1 = Time = 90

;Stone Slabs3 (Custom Version)
[Statedef 3196]
type = A
anim = 3132
velset = 0,6
SprPriority = 4

[State 3195, 1]
type = posadd
trigger1 = Time = 0
x = (random % 20) - 10

[State 3195, 2]
type = veladd
trigger1 = Time = [0, 20]
y = .5

[State 3195, 3]
type = velset
trigger1 = Time = 20
y = 0

[State 3195, 4]
type = posset
trigger1 = Time = 20
y = -50;70

[State 3195, 5]
type = PlaySnd
trigger1 = Time = 20
value = 2, 14

[State 3195, 6]
type = EnvShake
trigger1 = Time = 20
time = 5

[State 3195, 7]
type = velset
trigger1 = Time = 70
y = -9

[State 3195, 8]
type = DestroySelf
trigger1 = Time = 90

;========================<MAX ENMA ISHI>=============================
[StateDef 3150]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-50 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, 1]
type = Width
trigger1 = Time > 0
edge = 60,0

[State 1000, Width]
type = Width
trigger1 = AnimElemTime(4) = 0
value = 30,0

[state 3100, 2]
type = helper
trigger1 = AnimElem = 4
trigger1 = NumHelper(3100) = 0
ID = 3000
pos = 80, 5
postype = p1
stateno = 3152
helpertype = normal
name = "ita"
ownpal = 1
;ctrl = 0

[state 3100, 3]
type = helper
trigger1 = AnimElem = 4
trigger1 = NumHelper(3010) = 0
ID = 3010
pos = 80, 5
postype = p1
stateno = 3154
helpertype = normal
name = "ita2"
ownpal = 1
;ctrl = 0

[State 3100, 4]
type = Explod
trigger1 = AnimElem = 4
anim = 3140
postype = p1
pos = 90, 0
removetime = 16
ownpal = 1
sprpriority = 2

[State 3100, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 3100, 0

[State 3100, 6]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1, 8

[State 3100, 7]
type = VarSet
trigger1 = time = 0
var(11) = 2

[State 3100, 8]
type = VarSet
trigger1 = Time >= 47
trigger1 = NumHelper(3010) = 0
var(11) = 0

[State 3100, 9]
type = VarSet
trigger1 = AnimElem = 2
var(41) = 10

[State 3100, 10]
type = ChangeState
trigger1 = Time >= 47
trigger1 = NumHelper(3010) = 0
value = 0
ctrl = 1

[State 3100, 11]
type = ChangeState
triggerall = Time >= 47
triggerall = NumHelper(3000) = 1
trigger1 = helper(3000),stateno = 3153
value = 3151

;Enma Ishi Hit
[Statedef 3151]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 3110

[State 3110, 1]
type = Width
trigger1 = Time > 0
edge = 60,0

[State 3110, 2]
type = PlaySnd
trigger1 = AnimElem = 4
value = 3100, 1

[State 3110, 3]
type = VarSet
trigger1 = animtime = 0
var(11) = 0

[State 3110, 4]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Enma Ishi Attack Frame
[Statedef 3152]
type = S
movetype = A
physics = N
anim = 3120
velset = 5,0
SprPriority = 0

[State 3120, 1]
type = HitDef
trigger1 = !var(16) && var(15) < 3
trigger1 = p2statetype != A
attr = A, HP
damage = 0
animtype = Light
hitflag = MA
guardflag = MA
getpower  = 0
givepower = 20
pausetime = 0, 10
sparkNo = -1 + 0 * (var(33) := 0)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 100), var(36) := -61
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.velocity = -6
p2facing = 1
p1stateno = 3153
p2stateno = 3156
kill = 0
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 5)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3120, 2]
type = PlaySnd
trigger1 = Time = 5
value = 1, 9

[State 3120, 3]
type = ParentVarSet
trigger1 = time >= 0
trigger1 = moveHit = 0
fvar(15) = p2dist x

[State 3120, 4]
type = DestroySelf
trigger1 = time = 60
trigger2 = movecontact = 1
trigger3 = Root, stateno = [5000,5100]
trigger4 = Root, movetype = H

;Enma Ishi Helper1
[Statedef 3153]
type = A
movetype = A
physics = N
anim = 1395

[State 3130, 1]
type = posadd
trigger1 = Time = 0
x = root, fvar(15)
y = -60

[State 3130, 2]
type = TargetBind
trigger1 = Time >= 0
pos = 0, 0

[State 3130, 3]
type = velset
trigger1 = Time = 0
x = - root, fvar(15) / 35
y = - 8

[State 3130, 4]
type = veladd
trigger1 = Time > 0
y = .5

[State 3130, 5]
type = velset
trigger1 = Pos Y > -10 &&  Vel Y > 0
x = 0
y = 0

[State 3130, 6]
type = posset
trigger1 = Pos Y > -10 &&  Vel Y > 0
y = -10

[State 3130, 7]
type = VelSet
trigger1 = Time = 154
x = 4
y = -5

;Stone Slab1
[state 3130, 8]
type = helper
trigger1 = Time = 60
trigger1 = !Enemy,SelfAnimExist(7699)
ID = 3110
pos = 0, -300
postype = p1
stateno = 3180
helpertype = normal
name = "isi1"
ownpal = 1
;ctrl = 0

[state 3130, 8]
type = helper
trigger1 = Time = 60
trigger1 = Enemy,SelfAnimExist(7699)
ID = 3111
pos = 0, -300
postype = p1
stateno = 3181
helpertype = normal
name = "isi1"
ownpal = 1

;Stone Slab2
[state 3130, 9]
type = helper
trigger1 = Time = 72
trigger1 = !Enemy,SelfAnimExist(7699)
ID = 3120
pos = 0, -300
postype = p1
stateno = 3190
helpertype = normal
name = "isi2"
ownpal = 1
;ctrl = 0

[state 3130, 9]
type = helper
trigger1 = Time = 72
trigger1 = Enemy,SelfAnimExist(7699)
ID = 3121
pos = 0, -300
postype = p1
stateno = 3191
helpertype = normal
name = "isi2"
ownpal = 1

;Stone Slab3
[state 3130, 10]
type = helper
trigger1 = Time = 83
trigger1 = !Enemy,SelfAnimExist(7699)
ID = 3130
pos = 0, -300
postype = p1
stateno = 3195
helpertype = normal
name = "isi3"
ownpal = 1
;ctrl = 0

[state 3130, 10]
type = helper
trigger1 = Time = 83
trigger1 = Enemy,SelfAnimExist(7699)
ID = 3131
pos = 0, -300
postype = p1
stateno = 3196
helpertype = normal
name = "isi3"
ownpal = 1

[State 3130, 11]
type = DestroySelf
trigger1 = Time = 155

;Wooden Board Helper
[Statedef 3154]
type = S
movetype= A
physics = N
anim = 3125
velset = 5,0
SprPriority = 0

[State 3140, 1]
type = velset
trigger1 = p2stateno = 3156
trigger2 = p2stateno = 150 || p2stateno = 152
x = 0

[State 3140, 2]
type = posadd
trigger1 = vel x= 0
trigger1 = FrontEdgeDist < 10
x = -5

[State 3140, 3]
type = ChangeState
trigger1 = NumHelper(3000) = 0
value = 3155

;Wooden Board Dissapper
[Statedef 3155]
type = S
movetype= A
physics = N
velset = 0, 0
anim = 3129

[State 3150, 1]
type = DestroySelf
trigger1 = animtime = 0

;Enma Ishi P2 state 1
[Statedef 3156]
type = A
movetype = H
physics = N
ctrl = 0
sprpriority = 1

[State 3160, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = AnimExist(3180)
value = 3180

[State 3160, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = !AnimExist(3180)
value = 5050

;Send target to default animation if it doesn't have the 7699 custom animation.
[State 3160, 2]
type = ChangeState
trigger1 = Pos Y > -10 &&  Vel Y > 0
trigger1 = !AnimExist(7699)
value = 3157

;If the target has the 7699 custom animation
[State 3160, 2]
type = ChangeState
trigger1 = Pos Y > -10 &&  Vel Y > 0
trigger1 = AnimExist(7699)
value = 3158

;Enma Ishi Default Target Animation
[Statedef 3157]
type = U
movetype = H
physics = N
ctrl = 0
velset = 0, 0
sprpriority = 1

[State 3170, 1] ;Default
type = ChangeAnim
trigger1 = Time = 0
trigger1 = AnimExist(3190)
value = 3190

[State 3170, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = !AnimExist(3190)
value = 5080

[State 3170, 2]
type = LifeAdd
trigger1 = Time = 47
trigger2 = Time = 57
trigger3 = Time = 67
value = ifelse(Life > 115, -115, -(Life-1))

[State 3170, 3]
type = LifeAdd
trigger1 = Time = 117
value = -20

[State 3170, 4]
type = SelfState
trigger1 = time = 200
trigger1 = Pos Y > -20 &&  Vel Y > 0
value = 5100

;Enma Ishi Target Custom Animation
[Statedef 3158]
type = U
movetype = H
physics = N
ctrl = 0
velset = 0, 0
sprpriority = 1

[State 3171, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 7699;5040

[State 3171, 2]
type = LifeAdd
trigger1 = Time = 47
trigger2 = Time = 57
trigger3 = Time = 67
value = ifelse(Life > 115, -115, -(Life-1))

[State 3171, 3]
type = LifeAdd
trigger1 = Time = 117
value = -20

[State 3171, 4]
type = SelfState
trigger1 = time = 200
trigger1 = Pos Y > -20 &&  Vel Y > 0
value = 5100

;========================<DEVIL SPIRIT>=============================
[StateDef 3200]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3200, Super Pause FX]
type = Helper
trigger1 = Time = 2
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(8 * const(size.xScale)), ceil(-64 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = !Time
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 2
value = 3100,1
channel = 0

[State 52, PosSet]
type = PosSet
trigger1 = facing = 1
trigger1 = animelem = 37
x = 240

[State 52, PosSet]
type = PosSet
trigger1 = facing = -1
trigger1 = animelem = 37
x = -240

[State 3000, ????1]
type = Explod
trigger1 = animelem = 37
anim = 3090
postype = p1
ID = 3010
pos = -5, -40
scale = 2, 2
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3000, ????1]
type = Explod
trigger1 = animelem = 37
anim = 3090
postype = p1
ID = 3010
pos = -5, -80
scale = 2, 2
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3200, Tsurane Giri Projectile]
type = Helper
trigger1 = AnimElem = 15
helperType = Normal
stateNo = 3205
ID = 3205
name = "Tsurane Giri Projectile"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(0 * const(size.yScale))
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3200, Tsurane Giri Projectile]
type = Helper
trigger1 = AnimElem = 20
helperType = Normal
stateNo = 3205
ID = 3205
name = "Tsurane Giri Projectile"
posType = P1
pos = ceil(60 * const(size.xScale)), ceil(0 * const(size.yScale))
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3200, Tsurane Giri Projectile]
type = Helper
trigger1 = AnimElem = 25
helperType = Normal
stateNo = 3205
ID = 3205
name = "Tsurane Giri Projectile"
posType = P1
pos = ceil(120 * const(size.xScale)), ceil(0 * const(size.yScale))
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3200, Tsurane Giri Projectile]
type = Helper
trigger1 = AnimElem = 30
helperType = Normal
stateNo = 3205
ID = 3205
name = "Tsurane Giri Projectile"
posType = P1
pos = ceil(180 * const(size.xScale)), ceil(0 * const(size.yScale))
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3200, Tsurane Giri Projectile]
type = Helper
trigger1 = AnimElem = 35
helperType = Normal
stateNo = 3205
ID = 3205
name = "Tsurane Giri Projectile"
posType = P1
pos = ceil(240 * const(size.xScale)), ceil(0 * const(size.yScale))
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3201, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<TOGAKUBI SARASHI>=============================
[StateDef 3300]
type = S
physics = N
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3300, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3300, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3300, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3300, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3300, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3300, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3300, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3300, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3300, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3300, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 3200, 2]
type = velset
trigger1 = AnimElem = 2
x = ifelse(p2dist x / 20 > 8, 8, p2dist x / 20)
y = -4

[State 3200, 3]
type = StateTypeSet
trigger1 = AnimElem = 2
value = A

[State 3200, 4]
type = posset
trigger1 = AnimElem = 3
y = -60

[State 3200, 5]
type = veladd
trigger1 = Time >= 39
y = .51

[State 3200, 6]
type = VarSet
trigger1 = time = 0
var(11) = 2

[State 3200, 7]
type = ChangeState
trigger1 = Pos Y >= -15 && Vel Y > 0
value = 3310

;Togakubi Sarashi
[Statedef 3310]
type = S
movetype = A
physics = N
anim = 3310
velset = 0,0
sprpriority = 0
ctrl = 0

[State 3210, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 3210, 2]
type = HitDef
triggerall = !var(16) && var(15) < 2
triggerall = Time = 0
trigger1 = p2stateno != 3330
attr = S, SA
hitflag = MAFD
damage = ceil(ifElse(fvar(11) * 220 < 7, 7, fvar(11) * 220)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 15,15
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := 0
animtype  = Light
p2stateno = 3380
down.hittime = 30

[State 3210, 3]
type = HitDef
triggerall = !var(16) && var(15) < 2
triggerall = Time = 0
trigger1 = p2stateno = 3330
attr = S, SA
hitflag = MAFD
damage = ceil(ifElse(fvar(11) * 90 < 7, 7, fvar(11) * 90)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 12,12
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := 0
ground.type = Trip
sprpriority = -1
ground.hittime  = 20
air.velocity = 5,-4
p2facing = -1
fall = 1
fall.recover = 0

[State 3210, 4]
type = PlaySnd
trigger1 = Time = 0
value = 195, 0

[State 3210, 5]
type = posset
trigger1 = Time = 0
y = 0

[state 3210, 6]
type = helper
triggerall = moveHit = 1 && var(27) = 0
trigger1 = P2Life <= 0
trigger1 = NumHelper(3300) = 0
ID = 3300
pos = 160, 3
postype = left
stateno = 3340
helpertype = normal
name = "dai"
ownpal = 1
ctrl = 0

[State 3210, 7]
type = VarSet
trigger1 = animtime = 0
var(11) = 0

[State 3210, 8]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Togakubi Sarashi
[Statedef 3330]
type    = L
movetype= H
physics = N
velset = 0,0
anim = 5110
sprpriority = 2

[State 2330, 1]
type = posSet
trigger1 = Time = 0
y = 0

[State 2330, 2]
type = SelfState
trigger1 = Time = 200
value = 5110

;Togakubi Sarashi
[Statedef 3340]
type = S
movetype = I
physics = S
anim = 3350
velset = 0,0
sprpriority = -5
ctrl = 0

[State 3250, 1]
type = ScreenBound
trigger1 = 1
value = 0

[State 3250, 2]
type = Explod
trigger1 = Time = 40
anim = 3140
postype = left
pos = 160, 120
random = 50, 50
removetime = 16
ownpal = 1
sprpriority = 5

[State 3250, 3]
type = Explod
trigger1 = Time = 44
anim = 3140
postype = left
pos = 160, 120
random = 50, 50
removetime = 16
ownpal = 1
sprpriority = 5

[State 3250, 4]
type = Explod
trigger1 = Time = 48
anim = 3140
postype = left
pos = 160, 120
random = 50, 50
removetime = 16
ownpal = 1
sprpriority = 5

[State 3250, 5]
type = Explod
trigger1 = Time = 52
anim = 3140
postype = left
pos = 160, 120
random = 50, 50
removetime = 16
ownpal = 1
sprpriority = 5

[State 3250, 6]
type = Explod
trigger1 = Time = 56
anim = 3140
postype = left
pos = 160, 120
random = 50, 50
removetime = 16
ownpal = 1
sprpriority = 5

[State 3250, 7]
type = PlaySnd
trigger1 = Time = 39
value = 0, 6

[State 3250, 8]
type = DestroySelf
trigger1 = Time = 700

;Togakubi Sarashi
[Statedef 3380]
type = A
movetype = H
physics = N
anim = 5080
ctrl = 0
sprpriority = 2

[State 3280, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 3280, 2]
type = SelfState
trigger1 = Time = 20
trigger1 = Life > 0
value = 5080

[State 3280, 3]
type = velset
trigger1 = Time = 20
x = (FrontEdgeDist - BackEdgeDist) / 52
y = -10

[State 3280, 4]
type = veladd
trigger1 = Time = [20,50]
trigger2 = Time = [60,70]
y = .45

[State 3280, 5]
type = velset
trigger1 = Time = 50
trigger2 = Time = 72
x = 0
y = 0

[State 3280, 6]
type = ChangeAnim2
trigger1 = Time = 50
value = 3390

[State 3280, 7]
type = Posset
trigger1 = Time = 74
y = -45

[State 3280, 8]
;type = SelfState
type = ChangeState
trigger1 = Time = 130
value = 5150

;HIT_LIEDEAD
[Statedef 5150]
type    = L
movetype= H
physics = N
sprpriority = -3

[State 5150, 1] ;Normal anim
type = ChangeAnim
triggerall = Time = 0
triggerall = anim != 3390
triggerall = SelfAnimExist(5140)
trigger1 = (anim != [5111,5119]) && (anim != [5171,5179])
trigger2 = !SelfAnimExist(5140 + (anim % 10))
value = 5140

[State 5150, 3] ;Hit up type anim
type = ChangeAnim
trigger1 = Time = 0
triggerall = anim != 3290
trigger1 = (anim = [5111,5119]) || (anim = [5171,5179])
trigger1 = SelfAnimExist(5140 + (anim % 10))
value = 5140 + (anim % 10)

[State 5150, 4] ;Match over anim
type = ChangeAnim
persistent = 0
;trigger1 = Time = 0
triggerall = anim != 3390
trigger1 = MatchOver = 1
trigger1 = Anim = [5140,5149]
trigger1 = SelfAnimExist(anim+10)
value = anim+10

[State 5150, 5] ;Switch to 5110 if liedead anim does not exist
type = ChangeAnim
trigger1 = Time = 0
triggerall = anim != 3390
trigger1 = Anim != [5140,5159]
trigger1 = Anim != [5110,5119]
value = 5110

[State 5150, 6] ;Friction
type = VelMul
trigger1 = 1
x = 0.85

[State 5150, 7] ;Friction
type = VelSet
trigger1 = Vel x < .05
persistent = 0
x = 0

[State 5150, 8]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

;========================<MAX TOGAKUBI SARASHI>=============================
[StateDef 3350]
type = S
physics = N
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3350, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3350, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3350, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3350, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3350, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3350, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3350, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3350, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3300, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3300, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 3200, 2]
type = velset
trigger1 = AnimElem = 2
x = ifelse(p2dist x / 20 > 8, 8, p2dist x / 20)
y = -4

[State 3200, 3]
type = StateTypeSet
trigger1 = AnimElem = 2
value = A

[State 3200, 4]
type = posset
trigger1 = AnimElem = 3
y = -60

[State 3200, 5]
type = veladd
trigger1 = Time >= 39
y = .51

[State 3200, 6]
type = VarSet
trigger1 = time = 0
var(11) = 2

[State 3200, 7]
type = ChangeState
trigger1 = Pos Y >= -15 && Vel Y > 0
value = 3360

;Togakubi Sarashi
[Statedef 3360]
type = S
movetype = A
physics = N
anim = 3360
velset = 0,0
sprpriority = 0
ctrl = 0

[State 3210, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 3210, 2]
type = HitDef
triggerall = !var(16) && var(15) < 2
trigger1 = p2stateno != 3330
trigger1 = Animelem = 5
trigger2 = Animelem = 6
attr = A, SA
hitflag = MAFD
damage = ceil(ifElse(fvar(11) * 160 < 7, 7, fvar(11) * 160)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 15,15
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := 0
animtype  = Light
p2stateno = 3380
down.hittime = 30

[State 3210, 3]
type = HitDef
triggerall = !var(16) && var(15) < 2
triggerall = Time = 0
trigger1 = p2stateno = 3330
attr = A, SA
hitflag = MAFD
damage = ceil(ifElse(fvar(11) * 90 < 7, 7, fvar(11) * 90)), 7
getPower = 0,0
givePower = 36, 36
guardflag = MA
pausetime = 12,12
hitSound = -1 + 0 * (var(31) := 12)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := 0
ground.type = Trip
sprpriority = -1
ground.hittime  = 20
air.velocity = 5,-4
p2facing = -1
fall = 1
fall.recover = 0

[State 3210, 4]
type = PlaySnd
trigger1 = Time = 0
value = 195, 0

[State 3210, 5]
type = posset
trigger1 = Time = 0
y = 0

[state 3210, 6]
type = helper
triggerall = moveHit = 1 && var(27) = 0
trigger1 = P2Life <= 0
trigger1 = NumHelper(3300) = 0
ID = 3300
pos = 160, 3
postype = left
stateno = 3340
helpertype = normal
name = "dai"
ownpal = 1
ctrl = 0

[State 3210, 7]
type = VarSet
trigger1 = animtime = 0
var(11) = 0

[State 3210, 8]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;========================<KIMEN KUDAKI>=============================
[StateDef 3400]
type = S
physics = S
moveType = A
anim = 3400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-45 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, 7]
type = PlaySnd
trigger1 = AnimElem = 2
value = 3000, 1
channel = 0

[State 1000, Projectile]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 3405
ID = 3405
name = "Kimen Kudaki Projectile"
posType = P1
pos = ceil(30 * const(size.xScale)), ceil(-60 * const(size.yScale))
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 1000, Width]
type = Width
trigger1 = AnimElemTime(3) = 0
value = 30,0

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<MAX KIMEN KUDAKI>=============================
[StateDef 3450]
type = S
physics = S
moveType = A
anim = 3400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-45 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, 7]
type = PlaySnd
trigger1 = AnimElem = 2
value = 3000, 1
channel = 0

[State 1000, Projectile]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 3455
ID = 3455
name = "Kimen Kudaki Projectile"
posType = P1
pos = ceil(30 * const(size.xScale)), ceil(-60 * const(size.yScale))
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 1000, Width]
type = Width
trigger1 = AnimElemTime(3) = 0
value = 30,0

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<DEVIL SPIRIT>=============================
[StateDef 3500]
type = S
physics = S
moveType = A
anim = 3500
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3200, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(0 * const(size.xScale)), ceil(-70 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, 7]
type = PlaySnd
trigger1 = AnimElem = 1
value = 5000, 2
channel = 0

[State 3000, ????1]
type = Explod
trigger1 = Animelem = 3
anim = 3140
postype = p1
ID = 3510
pos = 0, -60
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 3201, End]
type = ChangeState
trigger1 = Time = 48
value = 3501

;========================<DEVIL SPIRIT ATTACK>=============================
[StateDef 3501]
type = S
movetype = A
physics = N
anim = 3505
velset = 0,0
sprpriority = 2
ctrl = 0

[State 3000, 7]
type = PlaySnd
trigger1 = AnimElem = 2
value = 5000, 1
channel = 1

[State 1700, 1]
type = PlayerPush
trigger1 = 1
value = 0

[State 1700, 2]
type = velset
trigger1 = AnimElem = 2
x = p2dist x / 16

[State 1700, 3]
type = veladd
trigger1 = Time = [6, 13]
y = -1.2

[State 1700, 4]
type = StateTypeSet
trigger1 = AnimElem = 2
value = A

[State 1700, 5]
type = velset
trigger1 = AnimElem = 5
x = 0
y = 3

[State 1700, 6]
type = veladd
trigger1 = Time >= 30
y = 1.9

[State 1600, 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = Time = 0
attr = S, ST
getpower = 0
givepower = 100
guardflag =
hitflag = M-
sparkNo = -1 + 0 * (var(33) := 0)
numhits = 0
pausetime = 0, 0
hitSound = s181,5
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 3510
p2facing = 1
p2stateno = 3520
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 1700, 9]
type = ChangeState
trigger1 = (Pos Y >= -5) && (Vel Y >0)
value = 3502

;Landing
[StateDef 3502]
type = S
anim = 3501
physics = N
moveType = I
velSet = 0,0

[State 3000, ????1]
type = Explod
trigger1 = Animelem = 1
anim = 3140
postype = p1
ID = 3510
pos = 0, -60
removetime = 18
sprpriority = 3
ignorehitpause = 1

[State 1101, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 1101, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;--- PLAYER ---
[Statedef 3510]
type = S
physics = N
movetype = A
anim = 1
ctrl = 0
velset = 0, 0
sprpriority = -1

[State 4001, fadeout]
type = allpalfx
trigger1 = animelem = 1
time = 50
sinadd = -255, -255, -255, 120

[State 4001, BG PalFX]
type = bgpalfx
trigger1 = Animelem = 1
invertall = 1
add = 255, 255, 255
sinadd = -1000, -1000, -1000, 80
mul = 256, 128, 256
color = 0
time = 50

[State 4001, palfx]
type = palfx
trigger1 = Animelem = 1
add = -50, -50, -50
sinadd = -155, -155, -155, 80
mul = 256, 128, 256
color = 0
time = 50

[State 4001, black]
type = envcolor
trigger1 = Animelem = 1
time = 50
value = 0, 0, 0

[State 4001, palfx]
type = palfx
trigger1 = Animelem = 1
add = 0, 0, 0
sinadd = 0, 0, 0, 1
time = 50

[State 4001, BG PalFX]
type = bgpalfx
trigger1 = Animelem = 1
add = 0, 0, 0
sinadd = 0, 0, 0, 1
color = 256
time = 50

[State 810, Damage]
type = TargetLifeAdd
trigger1 = Time = 30
value = floor(ifElse(420 * fvar(11) < 7, -7, -420 * fvar(11)))

[State 4001, throw]
type = targetstate
trigger1 = Time = 48 && numtarget
value = 3521

[State 3000, 7]
type = PlaySnd
trigger1 = Time = 0
value = 181, 2
channel = 0

[State 3201, End]
type = ChangeState
trigger1 = Time = 50
value = 3502
ctrl = 1

;--- TARGET ---
[Statedef 3520]
type = S
physics = N
movetype = H
velset = 0, 0
ctrl = 0
sprpriority = 0

[State 1000, Snd]
type = playsnd
trigger1 = Time = 10
value = 11, 0

[State 1114001, Anim]
type = changeanim2
trigger1 = !time
value = 3510

;
[Statedef 3521]
type = L
physics = C
movetype = H
velset = 0, 0
ctrl = 0
sprpriority = 0

[State 1114003, Anim]
type = changeanim2
trigger1 = !time
value = 3515

[State 1114003, palfx]
type = palfx
trigger1 = !time
add = 0, 0, 0
sinadd = 0, 0, 0, 1
time = 1

[State 1114003, End]
type = selfstate
trigger1 = !alive
value = 5150

[State 1114003, End]
type = selfstate
trigger1 = time >= 80 && alive
value = 5120

