

[Command]
name = "Change_Immortal"
command = ~D, DB, B, D, DB, B, x
time = 30

[Command]
name = "Change_Immortal"
command = ~D, DB, B, D, DB, B, y
time = 30

[Command]
name = "Change_Immortal"
command = ~D, DB, B, D, DB, B, z
time = 30

[Command]
name = "Change_Immortal"
command = ~D, DB, B, D, DB, B, a
time = 30

[Command]
name = "Change_Immortal"
command = ~D, DB, B, D, DB, B, b
time = 30

[Command]
name = "Change_Immortal"
command = ~D, DB, B, D, DB, B, c
time = 30

[Command]
name = "Change_Immortal"
command = ~D, DB, B, D, DB, B, s
time = 30

[Command]
name = "Press_of_Death_a"
command = ~B, DB, D, DF, F, a
time = 20

[Command]
name = "Press_of_Death_b"
command = ~B, DB, D, DF, F, b
time = 20

[Command]
name = "Press_of_Death_c"
command = ~B, DB, D, DF, F, c
time = 20


[Command]
name = "Dark_Force"
command = c+z
time = 1


[Command]
name = "Kill_Shred_a"
command = ~D, DB, B, a
time = 20

[Command]
name = "Kill_Shred_b"
command = ~D, DB, B, b
time = 20

[Command]
name = "Kill_Shred_c"
command = ~D, DB, B, c
time = 20

[Command]
name = "ES_Kill_Shred"
command = ~D, DB, B, a+b
time = 20

[Command]
name = "ES_Kill_Shred"
command = ~D, DB, B, b+c
time = 20

[Command]
name = "ES_Kill_Shred"
command = ~D, DB, B, a+c
time = 20

[Command]
name = "Ifrit_Sword"
command = ~F, D, DF, x
time = 20

[Command]
name = "Ifrit_Sword"
command = ~F, D, DF, y
time = 20

[Command]
name = "Ifrit_Sword"
command = ~F, D, DF, z
time = 20

[Command]
name = "ES_Ifrit_Sword"
command = ~F, D, DF, x+y
time = 20

[Command]
name = "ES_Ifrit_Sword"
command = ~F, D, DF, x+z
time = 20

[Command]
name = "ES_Ifrit_Sword"
command = ~F, D, DF, y+z
time = 20

[Command]
name = "Blizzard_Sword_x"
command = ~B, DB, D, DF, F, x
time = 20

[Command]
name = "Blizzard_Sword_y"
command = ~B, DB, D, DF, F, y
time = 20

[Command]
name = "Blizzard_Sword_z"
command = ~B, DB, D, DF, F, z
time = 20

[Command]
name = "ES_Blizzard_Sword"
command = ~B, DB, D, DF, F, x+y
time = 20

[Command]
name = "ES_Blizzard_Sword"
command = ~B, DB, D, DF, F, y+z
time = 20

[Command]
name = "ES_Blizzard_Sword"
command = ~B, DB, D, DF, F, x+z
time = 20

[Command]
name = "Lightning_Sword_x"
command = ~B, D, DB, x
time = 20

[Command]
name = "Lightning_Sword_y"
command = ~B, D, DB, y
time = 20

[Command]
name = "Lightning_Sword_z"
command = ~B, D, DB, z
time = 20

[Command]
name = "ES_Lightning_Sword"
command = ~B, D, DB, x+y
time = 20

[Command]
name = "ES_Lightning_Sword"
command = ~B, D, DB, x+z
time = 20

[Command]
name = "ES_Lightning_Sword"
command = ~B, D, DB, y+z
time = 20

[Command]
name = "Lightning_Fall_x"
command = ~D, DB, B, x
time = 20

[Command]
name = "Lightning_Fall_y"
command = ~D, DB, B, y
time = 20

[Command]
name = "Lightning_Fall_z"
command = ~D, DB, B, z
time = 20

[Command]
name = "ES_Lightning_Fall"
command = ~D, DB, B, x+y
time = 20

[Command]
name = "ES_Lightning_Fall"
command = ~D, DB, B, x+z
time = 20

[Command]
name = "ES_Lightning_Fall"
command = ~D, DB, B, y+z
time = 20

[Command]
name = "Sword_Grapple"
command = ~F, DF, D, DB, B, y
time = 20

[Command]
name = "Sword_Grapple"
command = ~F, DF, D, DB, B, z
time = 20

[Command]
name = "Pounce"
command = ~D, D, x

[Command]
name = "Pounce"
command = ~D, D, y

[Command]
name = "Pounce"
command = ~D, D, z

[Command]
name = "Pounce"
command = ~D, D, a

[Command]
name = "Pounce"
command = ~D, D, b

[Command]
name = "Pounce"
command = ~D, D, c

[Command]
name = "ES_Pounce"
command = ~D, D, x+y

[Command]
name = "ES_Pounce"
command = ~D, D, x+z

[Command]
name = "ES_Pounce"
command = ~D, D, y+z

[Command]
name = "ES_Pounce"
command = ~D, D, a+b

[Command]
name = "ES_Pounce"
command = ~D, D, a+c

[Command]
name = "ES_Pounce"
command = ~D, D, b+c

[Command]
name = "adv_guard"
command = x,x,x
time = 20

[Command]
name = "adv_guard"
command = y,y,y
time = 20

[Command]
name = "adv_guard"
command = z,z,z
time = 20

[Command]
name = "412p"
command = ~B, DB, D, x
time = 16

[Command]
name = "412p"
command = ~B, DB, D, y
time = 16

[Command]
name = "412p"
command = ~B, DB, D, z
time = 16

[Command]
name = "412p"
command = ~B, DB, D, ~x
time = 16

[Command]
name = "412p"
command = ~B, DB, D, ~y
time = 16

[Command]
name = "412p"
command = ~B, DB, D, ~z
time = 16

[Command]
name = "412k"
command = ~B, DB, D, a
time = 16

[Command]
name = "412k"
command = ~B, DB, D, b
time = 16

[Command]
name=  "412k"
command = ~B, DB, D, c
time = 16

[Command]
name = "412k"
command = ~B, DB, D, ~a
time = 16

[Command]
name = "412k"
command = ~B, DB, D, ~b
time = 16

[Command]
name = "412k"
command = ~B, DB, D, ~c
time = 16


[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10


[Command]
name = "recovery"
command = x+y
time = 1

[Command]
name = "pp"
command = x+y
time = 1


[Command]
name = "kk"
command = a+b
time = 1

[Command]
name = "a+x"
command = a+x
time=1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1


[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1


[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1



[Command]
name = "hold_s"
command = /s
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdy"
command = /y
time = 1



[Command]
name = "rlsfwd"
command = ~$F
time = 1

[Command]
name = "rlsback"
command = ~$B
time = 1

[Command]
name = "rlsup"
command = ~$U
time = 1

[Command]
name = "rlsdown"
command = ~$D
time = 1



[Command]
name = "rlsx"
command = ~x
time = 1

[Command]
name = "rlsy"
command = ~y
time = 1

[Command]
name = "rlsz"
command = ~z
time = 1

[Command]
name = "rlsa"
command = ~a
time = 1

[Command]
name = "rlsb"
command = ~b
time = 1

[Command]
name = "rlsc"
command = ~c
time = 1





;   --- Uno Tag System [Type-R] Command definition ---

[Command]
name = "aHsoNn"
command = ~D, D, D, z+c
Time = 25

[Command]
name = "sheoun"
command = ~D, DF, F, z+c
Time = 25

[Command]
name = "palit"
command = z+c
Time = 2

[Command]
name = "turtleuno"
command = s
Time = 2


[Statedef -1]


[State -1, Partner Assist]
type = VarSet
sysvar(4) = 10
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 60 && Time > 0
triggerall = teammode = Simul
triggerall = StateNo != [3000,1251199]
triggerall = hitdefattr != SCA, HA, HP, HT
triggerAll = StateNo != [130,152]
triggerall = !(StateNo = [5000,5500])
triggerall = Power >= 500
trigger1 = command = "turtleuno"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = !ctrl && Movetype = A
trigger2 = Random < (((2 * ifelse(MoveContact, ifelse(MoveHit, 2, 3),1)) + (UniqHitCount * 2)) *(AILevel**2/64.0))
trigger3 = AILevel >  0
trigger3 = StateNo = [190,199]
trigger3 = AnimElemNo(0) = 2
ignorehitpause = 1

[State -1, Team Hyper Attack]
type = ChangeState
value = 1251125
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = Partner, life > 0
triggerall = power >= 3000
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 9		
triggerall= (StateType != A)
trigger1 = command = "sheoun"
trigger1 = (Ctrl = 1)
trigger1 = AILevel <=  0
trigger2 = command = "sheoun"
trigger2 = Anim = [200,1000]
trigger2 = movetype = A
trigger2 = hitdefattr = SC, NA
trigger2 = MoveContact
trigger2 = AILevel <=  0
trigger3 = AILevel > 0 && ctrl
trigger3 = Random < (10 + ((Life < Lifemax/6)*3))
trigger3 = NumEnemy && enemy, pos x = [0,200]
trigger4 = AILevel >  0
trigger4 = Anim = [200,1000]
trigger4 = movetype = A
trigger4 = hitdefattr = SC, NA
trigger4 = MoveContact
trigger4 = Random < (11 + ((MoveHit)*5) + ((Life < Lifemax/6)*5))
ignorehitpause = 1

[State -1, Delayed Hyper]
type = ChangeState
value = 1251127
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0
triggerall = power >= 1000
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time > 1 && Time > 45
triggerall = movetype = A
triggerall = StateNo = [2000,1251100]
triggerall = hitdefattr = SCA, HA, HP, HT || (StateNo >= 2000 && StateNo < 4000 && (hitcount < 8 || NumTarget && Target, GetHitVar(hitTime) >= 0))
trigger1 = command = "sheoun"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = NumTarget && MoveContact
trigger2 = Random < (10*(AILevel**2/64.0) + (Uniqhitcount*((Life < Partner,Life)*2)))
trigger2 = Partner, Time > 35
trigger3 = AILevel >  0
trigger3 = Partner, Time > 30 && Time > 25
trigger3 = HitCount >= 6
trigger3 = Random < (2 * Uniqhitcount * ifelse(hitcount > 9, 2, 1))
ignorehitpause = 1

[State -1, UNO Mode]
type = ChangeState
value = 1251128
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0 && Power >= 1000
triggerall = Life <= (Lifemax/8)
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 20
triggerall = (StateType != A) && ((Ctrl = 1) || StateNo = 0 || (Movetype = A && hitdefattr = SC, NA))
trigger1 = command = "aHsoNn"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Partner, Life < Lifemax/4
trigger2 = Random < ((25 + ifelse((Partner, Life < Lifemax/6), 25, 5))*(AILevel**2/64.0))

[State -1, Change Attack]
type = ChangeState
value = 1251126
triggerall = NumPartner
triggerall = (sysvar(4) = 1 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),250,500)) || (sysvar(4) = 15 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),500,1000))
triggerall = Partner, life > 0
triggerall = movetype = A && !MoveReversed
triggerall = (Partner, StateNo = 1251112 || Partner, StateNo = 1251114)  && Time > 1
triggerall = StateNo = [200,4850]
triggerall = StateNo != [1251102,1251105]
triggerall = NumTarget > 0 && Target, pos Y > -160
triggerall = (Target, StateNo != [5110,5955])
triggerall = Hitdefattr != SCA, NT && ((Target, Statetype = A || (Hitdefattr != A, NA && Target, Statetype != A)) && ((!Target, HitOver || EnemyNear, StateNo = [5000,5900]) && (MoveContact || ProjContactTime(0) < 8)))
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = UniqHitCount >= 2
trigger2 = Random < (((ifelse(sysvar(4)=15,25,50)*(AILevel**2/64.0)) + ((hitdefattr = SCA, SA, HA)*15) + ifelse(lifemax/life > 15, 15, lifemax/life)))
trigger2 = Partner, Life > Lifemax/10 || Life <= Partner, Life
trigger2 = Partner, Time > 25
trigger3 = AILevel >  0
trigger3 = Partner, Time > 27
trigger3 = Random < (25*(2*(Life = (Lifemax/4) && Life < Partner, Life)) *(AILevel**2/64.0))
trigger3 = MoveContact
ignorehitpause = 1

[State -1, TagIn]
type = ChangeState
value = 1251110
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner && NumEnemy
triggerall = RoundState = 2 
triggerall = Partner, life > 0
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 40	
triggerall = (MoveType != A && StateType != A) && (Ctrl = 1) || StateNo = 0
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Random < (ifelse((LifeMax/Life > 120), 120, LifeMax/Life)+((EnemyNear,statetype=L)*25))
trigger2 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond
trigger2 = EnemyNear, movetype != A
trigger3 = AILevel >  0
trigger3 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond && Life < LifeMax * (LifeMax*0.55)
trigger3 = Random < ((ifelse(LifeMax/Life > 10, 10, LifeMax/Life) + (10+ifelse((EnemyNear, StateNo > 5000),25,1))) * ifelse((Life < Partner, Life), 1.45, 0.5))
trigger3 = Partner, Time > 1 * TicksPerSecond
trigger3= EnemyNear, statetype = L || p2bodydist x > 250 && EnemyNear, movetype != A
trigger4 = AILevel >  0
trigger4 = Life < 150 && Life < Partner, Life
trigger4 = EnemyNear, statetype = L || p2bodydist x > 200 && EnemyNear, movetype != A
trigger4 = Random < (125*(AILevel**2/64.0))

[State -1, C_6]
type = CtrlSet
value = 1
triggerall = RoundState = 2 && NumPartner
triggerall = NumTarget && Target, StateNo != [200,4999]
triggerall = StateNo != 1251106 && !Ctrl
triggerall = (Partner, StateNo != [1251128,1251129]) && (Partner, PrevStateNo != [1251128,1251129])
trigger1 = command="x"||command="y"||command="z"||command="a"||command="b"||command="c"
trigger1 = sysvar(4) = 7
trigger1 = Movetype = A
trigger1 = MoveContact
trigger1 = hitdefattr = SCA, NA, SA
trigger1 = StateNo != PrevStateNo
trigger1 = Time > 3
trigger2 = PrevStateNo = 1251106
ignorehitpause = 0

; ------ Uno Tag System [Type-R] END LINE -------

;  ;]





[state 0]
type=selfstate
trigger1=ctrl && numpartner && !ishelper && roundstate=2 && pos y=0
trigger1=sysfvar(4)>0 && sysfvar(0)>0 && playeridexist(floor(sysfvar(0)))
trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(22)=4
value=190190
ctrl=0
ignorehitpause=1







[state -1]
type = varset
trigger1 = AIlevel > 0
v = 59
value = 1

[state -1]
type = varset
trigger1 = AIlevel = 0
v = 59
value = 0




[State -1, Press_of_Death_a]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3000
triggerall = command = "Press_of_Death_a"
triggerall = var(9) != 1
triggerall = power >= 1000
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Press_of_Death_b]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3010
triggerall = command = "Press_of_Death_b"
triggerall = var(9) != 1
triggerall = power >= 1000
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Press_of_Death_c]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3020
triggerall = command = "Press_of_Death_c"
triggerall = var(9) != 1
triggerall = power >= 1000
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Change_Immortal]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3100
triggerall = command = "Change_Immortal"
triggerall = var(9) != 1
triggerall = power >= 3000
trigger1 = statetype = S
trigger1 = ctrl





[State -1, Dark Force]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3200 + 50*(var(12)=1)
triggerall = command = "Dark_Force"
triggerall = !var(1)
triggerall = power >= 2000 || var(12)=1
triggerall = var(9) != 1
trigger1 = statetype = S
trigger1 = ctrl





[State -1, ES_Kill Shred]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1005
triggerall = command = "ES_Kill_Shred"
triggerall = !var(1)
triggerall = !var(12)
triggerall = var(9) != 1
triggerall = power >= 500
triggerall = NumHelper(7000) = 1
triggerall = statetype = S
triggerall = ctrl
trigger1 = Helper(7000), stateno = 7000
trigger2 = Helper(7000), stateno = 7100
trigger3 = Helper(7000), stateno = 7105


[State -1, ES_Ifrit_Sword]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1150+10*(stateno=[150,153])
triggerall = command = "ES_Ifrit_Sword"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
triggerall = power >= 500
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = [150,151]
trigger3 = stateno = [152,153]


[State -1, ES_Blizzard_Sword]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1250
triggerall = command = "ES_Blizzard_Sword"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
triggerall = power >= 500
trigger1 = statetype = S
trigger1 = ctrl


[State -1, ES_Lightning_Sword]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1350
triggerall = command = "ES_Lightning_Sword"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
triggerall = power >= 500
trigger1 = statetype = S
trigger1 = ctrl


[State -1, ES_Lightning_Fall]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1650
triggerall = command = "ES_Lightning_Fall"
triggerall = var(1)
triggerall = var(9) != 1
triggerall = power >= 500
triggerall = NumHelper(7000) = 1
triggerall = statetype = S
triggerall = ctrl
trigger1 = Helper(7000), stateno = 7100
trigger2 = Helper(7000), stateno = 7105





[State -1, Sword_Grapple]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1500
triggerall = command = "Sword_Grapple"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = p2bodydist X<10
triggerall = var(9) != 1
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Kill Shred_a]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1000+10*var(1)
triggerall = command = "Kill_Shred_a"
triggerall = !var(12)
triggerall = var(9) != 1
triggerall = NumHelper(7000) = 1
triggerall = statetype = S
triggerall = ctrl
trigger1 = Helper(7000), stateno = 7000
trigger2 = Helper(7000), stateno = 7100
trigger3 = Helper(7000), stateno = 7105


[State -1, Kill Shred_b]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1001+10*var(1)
triggerall = command = "Kill_Shred_b"
triggerall = !var(12)
triggerall = var(9) != 1
triggerall = NumHelper(7000) = 1
triggerall = statetype = S
triggerall = ctrl
trigger1 = Helper(7000), stateno = 7000
trigger2 = Helper(7000), stateno = 7100
trigger3 = Helper(7000), stateno = 7105


[State -1, Kill Shred_c]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1002+10*var(1)
triggerall = command = "Kill_Shred_c"
triggerall = !var(12)
triggerall = var(9) != 1
triggerall = NumHelper(7000) = 1
triggerall = statetype = S
triggerall = ctrl
trigger1 = Helper(7000), stateno = 7000
trigger2 = Helper(7000), stateno = 7100
trigger3 = Helper(7000), stateno = 7105


[State -1, Ifrit_Sword]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1100+10*(stateno=[150,153])
triggerall = command = "Ifrit_Sword"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = [150,151]
trigger3 = stateno = [152,153]


[State -1, Blizzard_Sword_x]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1200
triggerall = command = "Blizzard_Sword_x"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Blizzard_Sword_y]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1210
triggerall = command = "Blizzard_Sword_y"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Blizzard_Sword_z]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1220
triggerall = command = "Blizzard_Sword_z"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Lightning_Sword_x]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1300
triggerall = command = "Lightning_Sword_x"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Lightning_Sword_y]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1310
triggerall = command = "Lightning_Sword_y"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Lightning_Sword_z]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1320
triggerall = command = "Lightning_Sword_z"
triggerall = !var(1)
triggerall = !var(12) || (var(12) && !var(3))
triggerall = var(9) != 1
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Lightning_Fall_x]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1600
triggerall = command = "Lightning_Fall_x"
triggerall = var(1)
triggerall = var(9) != 1
triggerall = NumHelper(7000) = 1
triggerall = statetype = S
triggerall = ctrl
trigger1 = Helper(7000), stateno = 7100
trigger2 = Helper(7000), stateno = 7105


[State -1, Lightning_Fall_y]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1610
triggerall = command = "Lightning_Fall_y"
triggerall = var(1)
triggerall = var(9) != 1
triggerall = NumHelper(7000) = 1
triggerall = statetype = S
triggerall = ctrl
trigger1 = Helper(7000), stateno = 7100
trigger2 = Helper(7000), stateno = 7105


[State -1, Lightning_Fall_z]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1620
triggerall = command = "Lightning_Fall_z"
triggerall = var(1)
triggerall = var(9) != 1
triggerall = NumHelper(7000) = 1
triggerall = statetype = S
triggerall = ctrl
trigger1 = Helper(7000), stateno = 7100
trigger2 = Helper(7000), stateno = 7105


[State -1, Pounce]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1400 + 50*(command = "ES_Pounce" && power >= 1000)
triggerall = command = "Pounce" || command = "ES_Pounce"
triggerall = p2statetype = L
trigger1 = statetype = S
trigger1 = ctrl





[State -1, Advancing_guard]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1700
triggerall = command = "adv_guard"
triggerall = !var(12)
trigger1 = stateno = [150,151]


[State -1, Advancing_guard]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1701
triggerall = command = "adv_guard"
triggerall = !var(12)
trigger1 = stateno = [152,153]


[State -1,Advancing_guard]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1702
triggerall = command = "adv_guard"
triggerall = !var(12)
trigger1 = stateno = 154
trigger2 = stateno = 155
trigger2 = Time <= 10

[State -1, Roll Forward]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 710
triggerAll = !AILevel
triggerAll = command = "a+x"
triggerAll = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdfwd"
trigger2 = var(20) && var(4)

[State -1, Roll Backward]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 715
triggerAll = !AILevel
triggerAll = command = "a+x"
triggerAll = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdback"

[State -1, Dodge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 700
triggerAll = !AILevel
triggerAll = command = "a+x"
triggerAll = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))

[State -1, Power Charge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 730
triggerAll = !AILevel
trigger1 = command = "holdb" && command = "holdy"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (StateNo = [100,101])
ignorehitpause = 0

[State -1, Zero Counter]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 750
triggerAll = !AILevel
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = command = "412p" || command = "412k"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)




[State -1, Run Fwd]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 100
triggerall = command = "FF"
trigger1 = ctrl
trigger1 = statetype = S


[State -1, Run Back]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 105
triggerall = command = "BB"
trigger1 = ctrl
trigger1 = statetype = S





[State -1, Throw]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 800
triggerall = command = "y" || command = "z"
triggerall = command = "holdfwd"
triggerall = command != "holddown"
triggerall = p2bodydist X<10
triggerall = p2statetype != A
triggerall = p2movetype != H
trigger1 = statetype = S
trigger1 = ctrl






[State -1, Stand Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 200 + var(1) + var(12)
triggerall = command = "x"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 200 + var(1) + var(12)
trigger2 = Time > 5
trigger3 = stateno = 400
trigger3 = Time > 4


[State -1, Stand Medium Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 210 + var(1) + var(12)
triggerall = command = "y"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 200 + var(1) + var(12)
trigger2 = movecontact
trigger3 = stateno = 250
trigger3 = movecontact
trigger4 = stateno = 400
trigger4 = movecontact
trigger5 = stateno = 450
trigger5 = movecontact


[State -1, Stand Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 220  + var(1) + var(12)
triggerall = command = "z"
triggerall = command != "holddown"
trigger1  = statetype = S
trigger1  = ctrl
trigger2  = stateno = 200 + var(1) + var(12)
trigger2  = movecontact
trigger3  = stateno = 210 + var(1) + var(12)
trigger3  = movecontact
trigger4  = stateno = 250
trigger4  = movecontact
trigger5  = stateno = 260
trigger5  = movecontact
trigger6  = stateno = 400
trigger6  = movecontact
trigger7  = stateno = 410 + var(1) + var(12)
trigger7  = movecontact
trigger8  = stateno = 450
trigger8  = movecontact
trigger9  = stateno = 460
trigger9  = movecontact


[State -1, Stand Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 250
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 200 + var(1) + var(12)
trigger2 = movecontact
trigger3 = stateno = 400
trigger3 = movecontact
trigger4 = stateno = 250
trigger4 = time > 4


[State -1, Standing Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 260
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 200 + var(1) + var(12)
trigger2 = movecontact
trigger3 = stateno = 210 + var(1) + var(12)
trigger3 = movecontact
trigger4 = stateno = 250
trigger4 = movecontact
trigger5 = stateno = 400
trigger5 = movecontact
trigger6 = stateno = 410 + var(1) + var(12)
trigger6 = movecontact
trigger7 = stateno = 450
trigger7 = movecontact


[State -1, Stand Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 270
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = command != "holdfwd"
trigger1 = statetype = S
trigger1 = ctrl
trigger2  = stateno = 200 + var(1) + var(12)
trigger2  = movecontact
trigger3  = stateno = 210 + var(1) + var(12)
trigger3  = movecontact
trigger4  = stateno = 220 + var(1) + var(12)
trigger4  = movecontact
trigger5  = stateno = 250
trigger5  = movecontact
trigger6  = stateno = 260
trigger6  = movecontact
trigger7  = stateno = 400
trigger7  = movecontact
trigger8  = stateno = 410 + var(1) + var(12)
trigger8  = movecontact
trigger9  = stateno = 420 + var(1) + var(12)
trigger9  = movecontact
trigger10 = stateno = 450
trigger10 = movecontact
trigger11 = stateno = 460
trigger11 = movecontact


[State -1, Stand Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 280
triggerall = command = "c"
triggerall = command = "holdfwd"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2  = stateno = 200 + var(1) + var(12)
trigger2  = movecontact
trigger3  = stateno = 210 + var(1) + var(12)
trigger3  = movecontact
trigger4  = stateno = 220 + var(1) + var(12)
trigger4  = movecontact
trigger5  = stateno = 250
trigger5  = movecontact
trigger6  = stateno = 260
trigger6  = movecontact
trigger7  = stateno = 270
trigger7  = movecontact
trigger8  = stateno = 400
trigger8  = movecontact
trigger9  = stateno = 410 + var(1) + var(12)
trigger9  = movecontact
trigger10 = stateno = 420 + var(1) + var(12)
trigger10 = movecontact
trigger11 = stateno = 450
trigger11 = movecontact
trigger12 = stateno = 460
trigger12 = movecontact
trigger13 = stateno = 470
trigger13 = movecontact



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 195
triggerall = command = "s"
trigger1 = statetype != A
trigger1 = ctrl






[State -1, Crouching Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 400
triggerall = command = "x"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 200 + var(1) + var(12)
trigger2 = Time > 5
trigger3 = stateno = 400
trigger3 = Time > 4


[State -1, Crouching Medium Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 410 + var(1) + var(12)
triggerall = command = "y"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 200 + var(1) + var(12)
trigger2 = movecontact
trigger3 = stateno = 250
trigger3 = movecontact
trigger4 = stateno = 400
trigger4 = movecontact
trigger5 = stateno = 450
trigger5 = movecontact


[State -1, Crouching Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 420 + var(1) + var(12)
triggerall = command = "z"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2  = stateno = 200 + var(1) + var(12)
trigger2  = movecontact
trigger3  = stateno = 210 + var(1) + var(12)
trigger3  = movecontact
trigger4  = stateno = 250
trigger4  = movecontact
trigger5  = stateno = 260
trigger5  = movecontact
trigger6  = stateno = 400
trigger6  = movecontact
trigger7  = stateno = 410 + var(1) + var(12)
trigger7  = movecontact
trigger8  = stateno = 450
trigger8  = movecontact
trigger9  = stateno = 460
trigger9  = movecontact



[State -1, Crouching Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 450
triggerall = command = "a"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 200 + var(1) + var(12)
trigger2 = movecontact
trigger3 = stateno = 400
trigger3 = movecontact
trigger4 = stateno = 450
trigger4 = Time > 3


[State -1, Crouching Medium Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 460
triggerall = command = "b"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 200 + var(1) + var(12)
trigger2 = movecontact
trigger3 = stateno = 210 + var(1) + var(12)
trigger3 = movecontact
trigger4 = stateno = 250
trigger4 = movecontact
trigger5 = stateno = 400
trigger5 = movecontact
trigger6 = stateno = 410 + var(1) + var(12)
trigger6 = movecontact
trigger7 = stateno = 450
trigger7 = movecontact


[State -1, Crouching Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 470
triggerall = command = "c"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2  = stateno = 200 + var(1) + var(12)
trigger2  = movecontact
trigger3  = stateno = 210 + var(1) + var(12)
trigger3  = movecontact
trigger4  = stateno = 220 + var(1) + var(12)
trigger4  = movecontact
trigger5  = stateno = 250
trigger5  = movecontact
trigger6  = stateno = 260
trigger6  = movecontact
trigger7  = stateno = 400
trigger7  = movecontact
trigger8  = stateno = 410 + var(1) + var(12)
trigger8  = movecontact
trigger9  = stateno = 420 + var(1) + var(12)
trigger9  = movecontact
trigger10 = stateno = 450
trigger10 = movecontact
trigger11 = stateno = 460
trigger11 = movecontact






[State -1, Jump Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 600
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl


[State -1, Jump Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 610
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl


[State -1, Jump Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 620
triggerall = command = "z"
trigger1 = statetype = A
trigger1 = ctrl



[State -1, Jump Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 650
triggerall = command = "a"
triggerall = var(1) || command != "holddown"
trigger1 = statetype = A
trigger1 = ctrl


[State -1, Jump Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 660
triggerall = command = "b"
triggerall = var(1) || command != "holddown"
trigger1 = statetype = A
trigger1 = ctrl


[State -1, Jump Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 670
triggerall = command = "c"
triggerall = var(1) || command != "holddown"
trigger1 = statetype = A
trigger1 = ctrl


[State -1, Surf Kick a]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 705
triggerall = command = "a"
triggerall = !var(1)
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl


[State -1, Surf Kick b]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 706
triggerall = command = "b"
triggerall = !var(1)
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl


[State -1, Surf Kick c]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 707
triggerall = command = "c"
triggerall = !var(1)
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl





[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 900
trigger1 = command = "holdfwd"
trigger1 = stateno = 5120
trigger1 = Time = 1


[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 901
trigger1 = command = "holdback"
trigger1 = stateno = 5120
trigger1 = Time = 1

