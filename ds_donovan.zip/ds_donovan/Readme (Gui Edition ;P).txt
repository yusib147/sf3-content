_____________________________________________________________________
=======================|             Donovan by Zelgadis296
                                   POTS Style Edit by gui0007        |==========================
                       �����������������������������������������������         [26.06.2019]

- Contact: guiaugustosantos0007@gmail.com

- YouTube Channel: https://www.youtube.com/user/TheGUTAA/

- Customized version of Capcom's Donovan Baine character, for usage in Mugen 1.0+


=====<Features>=====

- All the essential stuff
- Gameplay mix between CvS & Darkstalkers
- Modernized POTS Stuff
- Zero Counter, from SFZ3
- Dark Force and Chain Combos, from Darkstalkers
- Dodge, Roll, and Power Charge, from CvS2
- EX moves
- Cancels and Super Cancels
- POTS Hi-res effects fixed
- Sounds from the original Darkstalkers 3/Vampire Savior
- Blood effects
- Various intros, win poses and special animations
- Some unnecessary sprites retired and missing sprites for proper POTS treatment added/fixed
- Small portrait by NDSilva
- A.I. tweaked


=====<Movelist>=====

U - up          x - weak punch         a - weak kick
D - down        y - medium punch       b - medium kick
F - forward     z - strong punch       c - strong kick
B - back        p - any punch          k - any kick
s - start       2p- two punches        2k- two kicks

(Air)- Move must be performed in the air.
(EX)- Move with an EX version. EX moves are performed by pressing two punch/kick buttons.
EX moves are more powerful than regular Special moves, but consume half of a power stock.



<NORMAL>

.Hop Kick:   	        F + c
.Killshread Surf:       D + x or y (Air)
.Killshread Dive:	D + z (Air)
.Sharirum Luna (Throw): F/B + y or z (near opponent)


<SPECIAL>

.Killshread Plant:      D, DB, B, k (EX)
               During Killshread Plant:
               - Killshread Summon:    D, DB, B, k (Air also)
               - Killshread Lightning: D, DB, B, p
.Ifrit Sword:           F, D, DF, p (EX)
.Blizzard Sword:        B, DB, D, DF, F, p (EX)
.Lightning Sword:       B, D, DB, p (EX)
.Sword Grapple:         F, DF, D, DB, B + p (near opponent)


<Lv1 SUPER>

.Press of Death:        B, DB, D, DF, F, k


<Lv2 SUPER>

.Slay Shred (Dark Force): c + z


<Lv3 SUPER>

.Change Immortal:        D, DB, B, D, DB, B, p


<SYSTEM>

.Forward Dash:                  	F, F
.Backward Dash:                 	B, B
.Dodge:                                 a + x
.Forward Dodge:                         F, a + x
.Backward Dodge:                        B, a + x
.Power Charge:                          b + y
.Strategic Wake-Up:			F or B (while knocked down)


=====<What's Missing>=====

- Parry
- Zero Counter
- Low, Long-Low and High Jumps


=====<Version History>=====

<26.06.2019>
- Level 3 Portrait and Super KO Texts fixed
- Slay Shred bug when it's finished is fixed
- Some misaligned sprites, specially the dust effect are fixed
- Taunt fixed
- A.I. tweaked again
- Power Charge now works properly

<07.03.2018>
- POTS Edit released
- Major bugs fixed
- A.I. rearranged
- Fixed small portrait by NDSilva
- SFX and effects fixed
- Unnecessary sprites retired

<04.05.2008>
- Original Zelgadis296's Donovan released


=====<Special Thanks>=====

- Zelgadis296 for the original character
- P.o.t.S. & Jmorphman for the source material
- All the great people around the MUGEN forums and communities!
- My sweet subscribers of my YouTube channel for the huge support!
- And YOU for downloading and enjoying the unstoppable hunter! >:)


=====<Disclaimer>=====

- Donovan Baine and Darkstalkers are property of Capcom
- This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes