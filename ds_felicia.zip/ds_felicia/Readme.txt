                            __________________________________________
===========================| Felicia by varo_hades	              |===========================
                            ������������������������������������������        [01.09.19]

 - Contact:	varo_hades@hotmail.com
 - Website:	https://varohades.wixsite.com/varohadesmugen
 - Customized version of Capcom's Felicia character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, including CvS2, Darkstalkers and MVC 2
 - Special intros versus Duck King

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

<NORMAL>

.Cat attack				DF + y
.Panic Nail:	         		F/B + 2p		(near opponent)
.Tumble Cat:				F/B + 2k		(near opponent)
.Flip Cat:				F/B + 2p		(Air, near opponent)

<SPECIAL>

.Rolling Buckler (EX)			D, DF, F, p		(tap any punch for more hits)
.Sand Splash (EX)			D, DF, F, k
.Cat Spike (EX)				F, DF, F, p
.Delta Kick (EX)			B, DB, B, k
.Rolling Scratch (EX)			D, DB, B, p
.Hellcat Attempt (EX)			F, D, DB, k
.Toy Touch (EX)				D, D, p
.Pursuit (EX)				D, D, k                  (while opponent is downed)

<SUPER>

.Dancing Flash (MAX):			D, DF, F, D, DF, F, p
.Kitty's Helper (MAX):			D, DB, B, D, DB, B, k


<Lv3 SUPER>

.Please Help Me!:                	D, DF, F, D, DF, F, 2k

<SYSTEM>

.Forward Dash:                  	F, F
   .Run:                        	hold
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	a + x
   .Sidestep Attack:            	p / k
.Forward Roll:                  	F + a + x
.Backward Roll:                 	B + a + x
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold b + y
.Zero Counter:                  	B, DB, D, p / k 	(during standing or crouching guard)
.Custom Combo:                  	c + z           	(Air also)
.Fall Recovery:                 	2p / a + x      	(while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

=====<Miscellaneous>=====

- To change his size to TV aspect ratio (a.k.a. CvS scale), open the .def file and replace
  "ConstantsSFZ.cns" with "ConstantsCvS.cns".

=====<Special Thanks>=====
 - Jesuszilla for code, anims, effects
 - P.o.t.S. for code, effects, hitsparks, formatting style
 - Everybody at the MUGEN for feedback

=====<Disclaimer>=====

 - The Felicia character is property of Capcom
 - Capcom vs SNK is property of Capcom
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes