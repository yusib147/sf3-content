; _________________________________________
;| Felicia by varo_hades                   |
; �����������������������������������������
;==============================================================================================
;=======================================<HELPER STATES>========================================
;==============================================================================================

;====================<PARRY HELPER>=========================
[StateDef 765]
type = A
physics = N
moveType = I
anim = ifElse(Root, StateType = C, 766, ifElse(Root, StateType = A, 767, 765))
velSet = 0,0
ctrl = 0

[State 765, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 765, BindToRoot]
type = BindToRoot
trigger1 = 1
time = -1

[State 765, Change to Crouching]
type = ChangeAnim
triggerAll = !Time
trigger1 = !(Root, AILevel) && Root, command = "down"
trigger2 = Root, AILevel && (Root, StateType != A) && P2StateType = C
value = 766

[State 765, Change to Standing / Jumping]
type = ChangeAnim
triggerAll = !Time
trigger1 = !(Root, AILevel) && Root, command = "fwd"
trigger2 = Root, AILevel && Anim != 766
value = ifElse((Root, StateType = A), 767, 765)

[State 765, Change to Standing / Jumping]
type = ChangeAnim
trigger1 = Anim = 765 || Anim = 767
value = ifElse((Root, StateType = A), 767, 765)

[State 765, Disable]
type = VarSet
trigger1 = Time >= ifElse((Root, StateType = A), 7, 8)
trigger2 = Facing != (Root, Facing)
trigger3 = !(Root, ctrl)
trigger3 = (Root, StateNo != [760,762]) && (Root, StateNo != 5120)
var(0) = 1

[State 765, Disable]
type = VarSet
triggerAll = !(Root, AILevel)
trigger1 = (Root, command = "holdback")
trigger2 = Time < 4 && (Root, command = "holdfwd" + Root, command = "holddown") > 1
trigger3 = Time >= 4 && (Root, command = "holdfwd" || Root, command = "holddown")
trigger4 = Time >= 1 && (((Anim = 765 || Anim = 767) && Root, command = "fwd") || (Anim = 766 && Root, command = "down"))
var(0) = 1

[State 765, Disable]
type = ChangeAnim
trigger1 = var(0) = 1
value = 1

[State 765, Standing/Air]
type = ReversalDef
trigger1 = !var(0) && (Anim = 765 || Anim = 767)
trigger1 = (Root, StateNo != 5120) || !(Root, AnimTime)
reversal.attr = SCA,AA
p1StateNo = 766
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, Crouching]
type = ReversalDef
trigger1 = !var(0) && Anim = 766
reversal.attr = SC,AA
p1StateNo = 766
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, Disable]
type = ReversalDef
trigger1 = var(0) = 1
reversal.attr =
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, End]
type = DestroySelf
trigger1 = Time >= 18
trigger2 = (Root, MoveType != I)
trigger3 = !(Root, ctrl) && (Root, StateNo != [760,762]) && (Root, StateNo != 5120)
trigger4 = (Root, StateNo = [760,762]) && (Root, Time <= 1)


;Success
[StateDef 766]
moveType = I
ctrl = 0

[State 766, Disable]
type = VarSet
trigger1 = 1
var(0) = 1

[State 766, End]
type = DestroySelf
trigger1 = Root, StateNo = [760,762]
trigger2 = Time >= 2

;=====================<SAND SPLASH PROJECTILE>=========================
[StateDef 1105]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
anim = 1

[State 1105, ChangeAnim]
type = ChangeAnim
trigger1 = Time = 1
value = 1101+Var(10)

[State 1105, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1

[State 1105, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
stateno = 1107
time = -1
ignorehitpause = 1

[State 1105, Explod]
type = Explod
trigger1 = Time = 1
anim = 1105
ID = 600
pos = 0,0
postype = p1
removetime = -2;ifElse(!Var(22),12,18)
bindtime = 1
vel = 0,0
accel = 0,0
scale = Const(Size.XScale),Const(Size.YScale)
ownpal = 0
sprpriority = 5
persistent = 0

[State 1105, Explod]
type = Explod
trigger1 = Time = 3 && Var(10)
anim = 1105
ID = 601
pos = Ceil(Const(size.xscale)*32),Ceil(Const(size.Yscale)*-12)
postype = p1
removetime = -2
bindtime = 1
vel = 0,0
accel = 0,0
scale = Const(Size.XScale),Const(Size.YScale)
ownpal = 0
sprpriority = 4
persistent = 0

[State 1105, Explod]
type = Explod
trigger1 = Time = 5 && Var(10)=2
anim = 1105
ID = 602
pos = Ceil(Const(size.xscale)*64),Ceil(Const(size.Yscale)*-24)
postype = p1
removetime = -2
bindtime = 1
vel = 0,0
accel = 0,0
scale = Const(Size.XScale),Const(Size.YScale)
ownpal = 0
sprpriority = 3
persistent = 0

[State 1105, RemoveExplod]
type = RemoveExplod
trigger1 = (root, StateNo != 1100) || Time = 0
ID = 600

[State 1105, RemoveExplod]
type = RemoveExplod
trigger1 = (root, StateNo != 1100) || Time = 0
ID = 601

[State 1105, RemoveExplod]
type = RemoveExplod
trigger1 = (root, StateNo != 1100) || Time = 0
ID = 602

[State 1105, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[State 1105, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1105, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1105, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 1105, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1105, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = 1
attr = S,SP
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 125, ifElse(var(10), 114, 102)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 125, ifElse(var(10), 114, 102)))), ifElse(var(10) >= 2, 8, 7)
getPower = ifElse(Root, var(10) = 3, 0, ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)) * !(Root, var(51))), ifElse(Root, var(10) = 3, 0, 36 * !(Root, var(20)) * !(Root, var(51)))
givePower = 36, 36
pauseTime = 0, ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 0, ifElse((Root, var(20)), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1105, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 1106
ignoreHitPause = 1

[State 1105, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1107
ignoreHitPause = 1

[State 1105, DestroySelf]
type = DestroySelf
trigger1 = AnimTime = 0 ;&& parent, Anim = 1120
trigger2 = (parent, StateNo != 1100)
trigger3 = (parent, movetype = H)
trigger4 = MoveReversed

;Hit Pause
[StateDef 1106]
type = A
physics = N
moveType = A
ctrl = 0
sprPriority = 3
moveHitPersist = 1

[State 1106, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 1106, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1106, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifelse(((facing*((Target, Pos X)-Pos X))<0),ceil((facing*((Target, Pos X)-Pos X))+4),ceil((facing*((Target, Pos X)-Pos X))-12)),-21
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1106, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifelse(((facing*((Target, Pos X)-Pos X))<0),ceil((facing*((Target, Pos X)-Pos X))+4),ceil((facing*((Target, Pos X)-Pos X))-12)),-21
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1106, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1106, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1106, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1106, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1100,1130]
var(18) = 1

[State 1106, End]
type = ChangeState
trigger1 = Time >= 0
value = ifElse(var(12) < 5 && var(10) = 3, 1135, 1107)

;DEAD SAND
[Statedef 1109]
type = ScreenBound
movetype = AssertSpecial
physics = Null
ctrl = 0
anim = 1

[State 1109, DestroySelf]
type = DestroySelf
trigger1 = Time

;Disappear
[StateDef 1107]
type = A
physics = N
moveType = A
anim = 1
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 1107, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 2,6
channel = 3
volume = -128
lowPriority = 1

[State 1107, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 1107, End]
type = ChangeState
trigger1 = !AnimTime
value = 1008

;Wait
[StateDef 1108]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 1108, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)

;=====================<EX SAND SPLASH PROJECTILE>=========================
[StateDef 1135]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
anim = 1

[State 1135, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = ifElse(var(2) < 5, 1135, 1107)
ignoreHitPause = 1

[State 1135, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 1135, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && Anim != 1103
value = 1103

[State 1135, Explod]
type = Explod
trigger1 = Time = 0
anim = 1105
ID = 600
pos = Ceil(Const(size.xscale)*32),0
postype = p1
removetime = -2;ifElse(!Var(22),12,18)
bindtime = 1
vel = 0,0
accel = 0,0
scale = Const(Size.XScale),Const(Size.Yscale)
ownpal = 1
sprpriority = 5
persistent = 0
ignorehitpause = 0

[State 1135, Explod]
type = Explod
trigger1 = Time = 1
anim = 1105
ID = 601
pos = Ceil(Const(size.xscale)*64),Ceil(Const(size.Yscale)*-12)
postype = p1
removetime = -2
bindtime = 1
vel = 0,0
accel = 0,0
scale = Const(Size.XScale),Const(Size.Yscale)
ownpal = 1
sprpriority = 4
persistent = 0
ignorehitpause = 0

[State 1135, RemoveExplod]
type = RemoveExplod
trigger1 = root, StateNo != 1100 && root, StateNo != 1130
ID = 600

[State 1135, RemoveExplod]
type = RemoveExplod
trigger1 = root, StateNo != 1100 && root, StateNo != 1130
ID = 601

[State 1135, VarAdd]
type = VarAdd
trigger1 = !Time
var(2) = 1

[State 1135, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1135, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1135, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 1135, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1135, Hit 1]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = var(2) < 5
attr = S, SP
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 27 < 7, 7, fvar(11) * 27)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 4 * (var(2) < 5), ifElse((Root, var(20)), 2, 4)
guard.pauseTime = 4 * (var(2) < 5), ifElse((Root, var(20)), 2, 4)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4.52
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1135, Hit 2]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = var(2) >= 5
attr = S, SP
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 27 < 7, 7, fvar(11) * 27)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 4 * (var(2) < 5), ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 4 * (var(2) < 5), ifElse((Root, var(20)), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd = -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1135, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 1135, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifelse(((facing*((Target, Pos X)-Pos X))<0),ceil((facing*((Target, Pos X)-Pos X))+4),ceil((facing*((Target, Pos X)-Pos X))-12)),-21
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1135, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifelse(((facing*((Target, Pos X)-Pos X))<0),ceil((facing*((Target, Pos X)-Pos X))+4),ceil((facing*((Target, Pos X)-Pos X))-12)),-21
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1135, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 1135, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 1135, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 1135, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1100,1130]
var(18) = 1
persistent = 0

[State 1135, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = ifElse(var(2) < 5, 1135, 1107)
ignoreHitPause = 1

[State 1135, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1107
ignoreHitPause = 1

[State 1135, DestroySelf]
type = DestroySelf
trigger1 = AnimTime = 0 ;&& parent, Anim = 1120
trigger2 = (parent, StateNo != 1130)
trigger3 = (parent, movetype = H)
trigger4 = MoveReversed

;========================<CAT SPIKE PROJECTILE>=============================
[Statedef 1205]
type = A
movetype = I
physics = N
poweradd = 0
ctrl = 0
sprpriority = 0

[State 1205, COMPATIBILITY]
type = VarSet
trigger1 = !Time
sysvar(0) = 131072

[State 1205, REFLECTED STATE]
type = VarSet
trigger1 = !Time
sysvar(1) = 1207

[State 1205, VarSet]
type = VarSet
trigger1 = root, MoveType = H
var(1) = 1
ignorehitpause = 1
persistent = 0

[State 1205, StateTypeSet]
type = StateTypeSet
trigger1 = isHelper(1250)
movetype = A

[State 1205, priority]
type = SprPriority
trigger1 = 1
value = isHelper(1250)*3

[State 1205, BindToParent]
type = BindToParent
triggerall = parent, StateNo = 1200
trigger1 = ParentDist X >= (Ceil((Const(size.xscale))*78))
pos = (Ceil((Const(size.xscale))*78)),(Ceil((Const(size.yscale))*-49))
facing = 1
time = 1

[State 1205, Ball]
type = ChangeAnim
trigger1 = !Time
value = 1205

[State 1205, VarSet]
type = VarSet
trigger1 = 1
fvar(0) = (Ceil((Const(size.xscale))*ifElse(IsHelper(8411),8,ifElse(IsHelper(84112),7.25,8.5))))

[State 1205, VelSet]
type = VelSet
triggerall = !IsHelper(1250)
trigger1 = Anim = 1205 && !Time
x = (FVar(0) + (root, FVar(3)*root, Var(12)))
y = (Ceil((Const(size.yscale))*ifElse(IsHelper(8411),-3.75,ifElse(IsHelper(84112),-4.75,-7.5))))

[State 1205, VelAdd]
type = VelAdd
triggerall = !IsHelper(1250)
triggerall = Anim != 1206
trigger1 = Time > 3
y = .47

[State 1205, ChangeState]
type = ChangeState
trigger1 = Vel Y + Pos Y >= 0
value = 1206

[State 1205, Pop]
type = ChangeAnim
trigger1 = root, Anim = 1200
trigger1 = root, AnimElemTime(6) = 0
trigger2 = root, Anim = 1210 || root, Anim = 1220
trigger2 = root, AnimElemTime(9) >= 0
trigger3 = prevStateNo = 1205
trigger4 = MoveContact = 1
value = 1206
persistent = 0

[State 1205, VelSet]
type = VelSet
trigger1 = Anim = 1206
x = 0
y = 0

[State 1205, PosFreeze]
type = PosFreeze
trigger1 = Anim = 1206
value = 1

[State 1205, ES - Start]
type = VelSet
triggerall = isHelper(1250)
triggerall = !Var(0)
trigger1 = Anim = 1205 && Time = 1
x = 2*(5.0/4.0)*Const(Size.XScale)
y = -7.5*(5.0/4.0)*Const(Size.YScale)
;x = 2.15
;y = -8.4;-7

[State 1205, ES - Start]
type = VelAdd
triggerall = isHelper(1250)
triggerall = Anim != 1206
trigger1 = !Var(0)
trigger1 = Time = [2,30] ;|| Time > 33
trigger2 = Var(1)
y = 0.1875*(25.0/16.0)*Const(Size.YScale);.25

[State 1205, ES - Attack]
type = VelAdd
triggerall = isHelper(1250)
triggerall = Anim != 1206
triggerall = !Var(1)
trigger1 = !Var(0) && Time > 30
trigger2 = Var(0)
y = 0.25*(25.0/16.0)*Const(Size.YScale);.5

[State 1205, ES - Attack]
type = VelSet
triggerall = root, StateNo = 1230
triggerall = isHelper(1250)
triggerall = Anim != 1206
triggerall = !Var(1)
trigger1 = Time = 30;var(0)
x = 6*(5.0/4.0)*Const(Size.XScale)
y = 7*(5.0/4.0)*Const(Size.YScale)

[State 1205, NotHitBy]
type = NotHitBy
trigger1 = !isHelper(1250) || MoveType = I
value = SCA

[State 1205, HitBy]
type = HitBy
trigger1 = isHelper(1250) && MoveType = A
value = SCA,AP

[State 1205, HitOverride]
type = HitOverride
trigger1 = isHelper(1250) && MoveType = A
attr = SCA,AA,AP,AT
slot = 0
stateno = stateNo
time = 1
ignorehitpause = 1

[State 1205, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1206 && isHelper(1250)
value = S1200,0
channel = 5
persistent = 0

[State 1205, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1205, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1205, Projectile]
type = HitDef
triggerall = Time > 29 || prevStateNo = 1206
triggerall = !MoveContact
triggerall = isHelper(1250)
triggerall = !NumTarget(sysvar(0))
trigger1 = P2StateNo != 5040 && ((FVar(19) != 0 && FVar(19) != 256) || P2StateType != A || P2MoveType != H)
attr = A, SP
damage = ceil(ifElse(fvar(11) * 145 < 7, 7, fvar(11) * 145)), 7
animtype = Heavy
air.animtype = Back
fall.animtype = Back
guardflag = M
hitflag = MAF
priority = 3, Hit
pausetime = 0,12
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
ground.type = Low
ground.slidetime = 16
ground.hittime  = 16
ground.velocity = -12.52
guard.velocity = -12.52
guard.ctrltime = 16
air.type = Low
air.velocity = -2.96875,-7.53125
airguard.velocity = -6,-3
air.hittime = 120
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getpower = 0,0
givepower = 36,36
yaccel = .46875
air.fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0

ID = sysvar(0)

[State 1205, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignoreHitPause = 1

[State 1205, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifelse(((facing*((Target, Pos X)-Pos X))<0),ceil((facing*((Target, Pos X)-Pos X))+4),ceil((facing*((Target, Pos X)-Pos X))-12)),-21
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1205, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifelse(((facing*((Target, Pos X)-Pos X))<0),ceil((facing*((Target, Pos X)-Pos X))+4),ceil((facing*((Target, Pos X)-Pos X))-12)),-21
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1205, Parent Hit Count]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1205, Self Hit Count]
type = VarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1205, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1205, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1205, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [1200,1230]
var(18) = 1

[State 1205, MoveHitReset]
type = MoveHitReset
trigger1 = MoveContact = 1
ignorehitpause = 1

[State 1205, DestroySelf]
type = DestroySelf
trigger1 = Anim = 1206 && AnimTime = 0
trigger2 = BackEdgeBodyDist <= -40
trigger3 = FrontEdgeBodyDist <= -40
;trigger1 = root, Anim = 1200
;trigger1 = root, AnimElemTime(6) = 0
;trigger2 = root, Anim = 1210 || root, Anim = 1220
;trigger2 = root, AnimElemTime(9) >= 0

;Ball Bounce
[Statedef 1206]
type = A
movetype = I
physics = N
poweradd = 0
ctrl = 0
sprpriority = 0
velset = 0,0

[State 1206, VarSet]
type = VarSet
trigger1 = isHelper(1250) && !Time
var(0) = 1

[State 1206, PosSet]
type = PosSet
trigger1 = !Time
y = 0

[State 1206, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = 1207+isHelper(1250)

[State 1206, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = S1200,1
;persistent = 0

[State 1206, VelSet]
type = VelSet
trigger1 = Anim = 1207 || Var(1)
trigger1 = AnimElemTime(2) = 0
x = 2*(5.0/4.0)*Const(Size.XScale)
y = -2.4375*(5.0/4.0)*Const(Size.YScale)

[State 1206, VelSet]
type = VelAdd
trigger1 = Anim = 1207 || Var(1)
trigger1 = AnimElemTime(2) > 0
y = 0.0625*(25.0/16.0)*Const(Size.YScale)

[State 1206, VelSet]
type = VelSet
triggerall = !Var(1)
trigger1 = Anim = 1208
trigger1 = AnimElemTime(2) = 0
x = 6*(5.0/4.0)*Const(Size.XScale)
y = -6.375*(5.0/4.0)*Const(Size.YScale)
;x = 7.7143
;y = -9.75

[State 1206, VelSet]
type = VelAdd
triggerall = Anim = 1208 && !Var(1)
trigger1 = AnimElemTime(2) > 0
y = .25*(25.0/16.0)*Const(Size.YScale)

[State 1206, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = prevStateNo

;Ball (Reflected)
[Statedef 1207]
type = A
movetype = A
physics = N
poweradd = 0
ctrl = 0
sprpriority = 0

[State 1207, COMPATIBILITY]
type = VarSet
trigger1 = !Time
sysvar(0) = 131072

[State 1207, REFLECTED STATE]
type = VarSet
trigger1 = !Time
sysvar(1) = 1207

[State 1207, Turn]
type = Turn
trigger1 = Time = 0 && prevStateNo != 1206

[State 1207, ES - Attack]
type = VelSet
trigger1 = Time = 0 && prevStateNo != 1206
x = 6*(5.0/4.0)*Const(Size.XScale)
y = 7*(5.0/4.0)*Const(Size.YScale)

[State 1207, VarSet]
type = VarSet
trigger1 = root, MoveType = H
var(1) = 1
ignorehitpause = 1
persistent = 0

[State 1207, priority]
type = SprPriority
trigger1 = 1
value = 3

[State 1207, Ball]
type = ChangeAnim
trigger1 = !Time
value = 1205

[State 1207, ChangeState]
type = ChangeState
trigger1 = Vel Y + Pos Y >= 0
value = 1206

[State 1207, Pop]
type = ChangeAnim
trigger1 = prevStateNo = 1207
trigger2 = MoveContact = 1
value = 1206
persistent = 0

[State 1207, VelSet]
type = VelSet
trigger1 = Anim = 1206
x = 0
y = 0

[State 1207, PosFreeze]
type = PosFreeze
trigger1 = Anim = 1206
value = 1

[State 1207, NotHitBy]
type = NotHitBy
trigger1 = MoveType = I
value = SCA

[State 1207, HitBy]
type = HitBy
trigger1 = MoveType = A
value = SCA,AP

[State 1207, HitOverride]
type = HitOverride
trigger1 = isHelper(1250) && MoveType = A
attr = SCA,AA,AP,AT
slot = 0
stateno = stateNo
time = 1
ignorehitpause = 1

[State 1207, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1206
value = S1200,0
channel = 5
persistent = 0

[State 1207, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1207, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1207, Projectile]
type = HitDef
triggerall = !MoveContact
triggerall = !NumTarget(sysvar(0))
trigger1 = P2StateNo != 5040 && ((FVar(19) != 0 && FVar(19) != 256) || P2StateType != A || P2MoveType != H)
attr = A, SP
damage = ceil(ifElse(fvar(11) * 145 < 7, 7, fvar(11) * 145)), 7
animtype = Heavy
air.animtype = Back
fall.animtype = Back
guardflag = M
hitflag = MAF
priority = 3, Hit
pausetime = 0,12
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
ground.type = Low
ground.slidetime = 16
ground.hittime  = 16
ground.velocity = -12.52
guard.velocity = -12.52
guard.ctrltime = 16
air.type = Low
air.velocity = -2.96875,-7.53125
airguard.velocity = -6,-3
air.hittime = 120
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getpower = 0,0
givepower = 36,36
yaccel = .46875
air.fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0

affectTeam = F
ID = sysvar(0)

[State 1207, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignoreHitPause = 1

[State 1207, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifelse(((facing*((Target, Pos X)-Pos X))<0),ceil((facing*((Target, Pos X)-Pos X))+4),ceil((facing*((Target, Pos X)-Pos X))-12)),-21
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1207, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
pos = (facing*-EnemyNear(0),facing)*Ceil(enemy,Const(size.ground.front)+Var(26)),Ceil(Pos Y-enemy,Pos Y+Var(27))
postype = P2
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1207, Parent Hit Count]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1207, Self Hit Count]
type = VarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1207, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1207, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1207, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [1200,1230]
var(18) = 1

[State 1207, MoveHitReset]
type = MoveHitReset
trigger1 = MoveContact = 1
ignorehitpause = 1

[State 1207, DestroySelf]
type = DestroySelf
trigger1 = Anim = 1206 && AnimTime = 0
trigger2 = BackEdgeBodyDist <= -40
trigger3 = FrontEdgeBodyDist <= -40
;trigger1 = root, Anim = 1200
;trigger1 = root, AnimElemTime(6) = 0
;trigger2 = root, Anim = 1210 || root, Anim = 1220
;trigger2 = root, AnimElemTime(9) >= 0

;=====================<KITTY'S HELPER PROJECTILE>=========================
;Alto
[Statedef 3300]
type = S
physics = N
movetype = I
ctrl = 0
sprpriority = 3
velset = 0,0
anim = 3215

[State 3300, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3300, Attack]
type = ChangeState
triggerall = root, Var(43)
triggerall = root, StateNo != 3100
triggerall = root, StateNo != 3150
trigger1 = root, command = "x" || root, command = "y" || root, command = "z"
trigger2 = root, command = "a" || root, command = "b" || root, command = "c"
trigger3 = root, StateNo = 3001
value = 3310

[State 3300, VelSet]
type = VelSet
trigger1 = 1
x = 3.5*Const(Size.XScale)*(5.0/4.0)

[State 3300, Turn]
type = ChangeState
triggerall = rootDist X < -64
trigger1 = root,Var(43)
value = stateNo+1

[State 3300, DTC]
type = DisplayToClipboard
trigger1 = 1
text = "rootDist X = %f"
params = rootDist X

[State 3300, DestroySelf]
type = DestroySelf
triggerall = FrontEdgeBodyDist < -40
trigger1 = !root,Var(43)

;TURN
[Statedef 3301]
type = S
physics = N
movetype = I
ctrl = 0
sprpriority = 3

[State 3301, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3301, Attack]
type = ChangeState
triggerall = root, Var(43)
triggerall = root, StateNo != 3100
triggerall = root, StateNo != 3150
trigger1 = root, command = "x" || root, command = "y" || root, command = "z"
trigger2 = root, command = "a" || root, command = "b" || root, command = "c"
trigger3 = root, StateNo = 3001
value = 3310

[State 3101, Turn]
type = Turn
trigger1 = !Time && prevStateNo = 3300

[State 3301, DTC]
type = DisplayToClipboard
trigger1 = 1
text = "rootDist X = %f"
params = rootDist X

[State 3301, ChangeState]
type = ChangeState
triggerall = rootDist X > 64
trigger1 = root,Var(43)
value = stateNo-1

[State 3301, DestroySelf]
type = DestroySelf
triggerall = FrontEdgeBodyDist < -40
trigger1 = !root,Var(43)

;ATTACK
[Statedef 3310]
type = S
physics = N
movetype = A
ctrl = 0
sprpriority = 3
facep2 = 1

[State 3310, ChangeAnim]
type = ChangeAnim
trigger1 = Time = 0 && prevStateNo != stateNo
value = 3218

[State 3310, VelSet]
type = VelSet
trigger1 = Time = 0 && prevStateNo != stateNo
x = 0
y = 0

[State 3310, VelSet]
type = VelSet
trigger1 = AnimElemTime(3) = 0
x = (abs((root,Pos X+(64.0*root,Facing))-Pos X)/32.0)*Const(Size.XScale)*(5.0/4.0)
y = -11*Const(Size.YScale)*(5.0/4.0)

[State 3310, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(3) > 0
y = 0.6875*(25.0/16.0)

[State 3310, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3310, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3310, 1]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = Vel Y >= 0
attr = , SA
damage = ceil(ifElse(fvar(11) * 49 < 7, 7, fvar(11) * 49)), 8
animtype = Heavy
air.animtype = Back
fall.animtype = Back
guardflag = M
hitflag = MAF
priority = 3, Hit
pausetime = 8,8
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -42
ground.type = Low
ground.slidetime = 10
ground.hittime  = 10
ground.velocity = -5.49
guard.velocity = -5.49
guard.ctrltime = 10
air.type = Low
air.velocity = -2.96875,-7.53125
airguard.velocity = -6,-3
air.hittime = 120
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getpower = 0,0
givepower = 36,36
yaccel = .46875
air.fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0

[State 3310, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 9)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3310, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8017)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3310, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
pos = ceil(P2Dist x), 0
postype = P1
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3310, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 3310, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 3310, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 3310, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1
persistent = 0

[State 3310, ChangeState]
type = ChangeState
trigger1 = AnimElemTime(3) > 1
trigger1 = Vel Y + Pos Y >= 0
value = stateNo+5

;LAND
[Statedef 3315]
type = S
physics = N
movetype = A
ctrl = 0
sprpriority = 3
anim = 3219
velset = 0,0

[State 3315, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3315, PosSet]
type = PosSet
trigger1 = !Time
y = 0

[State 3315, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 3300

;========================<PLEASE HELP ME! PROJECTILE>=============================
;Pico
[Statedef 3203]
type = S
physics = N
movetype = A
anim = 3203
ctrl = 0

[State 3203, VarSet]
type = VarSet
trigger1 = !Time
var(1) = 0

[State 3203, VarAdd]
type = VarAdd
trigger1 = MoveHit = 1
trigger1 = P2MoveType != H
trigger2 = MoveGuarded = 1
trigger2 = !NumTarget
trigger3 = Parent, MoveType = H
var(1) = 1

[State 3203, TargetDrop]
type = TargetDrop
triggerall = NumTarget(3200)
trigger1 = Var(1)

[State 3203, VarSet]
type = VarSet
trigger1 = !Time
var(46) = 2

[State 3203, NotHitBy]
type = NotHitBy
triggerall = Var(1)
trigger1 = 1
value = SCA

[State 3203, HitOverRide]
type = HitOverRide
trigger1 = 1
stateno = 3250
attr = SCA,NP,SP,HP,NA,SA,HA

[State 3203, HitBy]
type = HitBy
trigger1 = !Var(1)
value = SCA,NP,SP,HP,NA,SA,HA

[State 3203, VelSet]
type = VelSet
trigger1 = !Time
x = 7*Const(Size.XScale)*(5.0/4.0)

[State 3203, StateTypeSet]
type = StateTypeSet
trigger1 = Var(1)
movetype = I

[State 3203, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3203, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3203, 1]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
triggerall = !NumHelper(3220) && !NumHelper(3230) && !NumHelper(3206)
trigger1 = !Var(1)
attr = S,SA
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 8
animtype = Heavy
air.animtype = Back
fall.animtype = Back
guardflag = M
hitflag = MAF
priority = 3, Hit
pausetime = 0,8
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -28
ground.type = Low
ground.slidetime = 10
ground.hittime  = 10
ground.velocity = 0
guard.velocity = 0
guard.ctrltime = 10
air.type = Low
air.velocity = 0, 0
airguard.velocity = -6,-3
air.hittime = 120
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getpower = 0,0
givepower = 36,36
yaccel = .46875
air.fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0
ID = 3200

[State 3203, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 2)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3203, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3203, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
pos = ceil(P2Dist x), 0
postype = P1
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3203, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 3203, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 3203, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 3203, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [3200,3299]
var(18) = 1
persistent = 0

[State 3203, TargetState]
type = TargetState
trigger1 = MoveHit && P2MoveType = H
value = 3260

[State 3203, ChangeState]
type = ChangeState
triggerall = !Var(1)
triggerall = NumTarget(3200)
trigger1 = MoveHit && P2MoveType = H
value = 3204

[State 3203, ChangeState]
type = ChangeState
trigger1 = MoveGuarded
trigger2 = Parent, MoveType = H
trigger3 = Var(1)
value = 3250
ignorehitpause = 1

[State -2, MoveHitReset]
type = MoveHitReset
trigger1 = MoveContact = 1
ignorehitpause = 1

[State 3203, DestroySelf]
type = DestroySelf
triggerall = Time > 10
trigger1 = FrontEdgeBodyDist < -112

;Continue
[Statedef 3204]
type = S
physics = S
movetype = I
anim = 3204
ctrl = 0
velset = 0,0

[State 3204, ParentVarSet]
type = ParentVarSet
trigger1 = !Time
fvar(12) = 1

[State 3204, VarSet]
type = VarSet
trigger1 = !Time
var(40) = 0

[State 3204, Helper]
type = Helper
trigger1 = Time = 1
helpertype = Normal
name = "Grace"
ID = 3230
stateno = 3230
pos = -50,-25
postype = Back
facing = 1
keyctrl = 0
ownpal = 1
size.XScale = Const(size.XScale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3204, Helper]
type = Helper
trigger1 = Time = 1
helpertype = Normal
name = "Lucy"
ID = 3220
stateno = 3220
pos = 42,0
postype = Front
facing = -1
keyctrl = 0
ownpal = 1
size.XScale = Const(size.XScale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3204, Helper]
type = Helper
trigger1 = Time = 1
helpertype = Normal
name = "Nana,Mimi"
ID = 3206
stateno = 3208
pos = -14,ceil((enemy, Const(Size.Head.Pos.Y))-100)
postype = P2
facing = -1
keyctrl = 0
ownpal = 1
size.XScale = Const(size.XScale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3204, BindToTarget]
type = BindToTarget
trigger1 = !Time
pos = floor(Const(size.XScale)*44),0

[State 3204, PosSet]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3204, ChangeState]
type = ChangeState
trigger1 = Var(40) = 3 ;&& numHelper(3231) && numHelper (3209)
value = 3205

;Conect
[Statedef 3205]
type = S
physics = S
movetype = A
anim = 3205
ctrl = 0
velset = 0,0

[State 3205, ParentVarSet]
type = ParentVarSet
trigger1 = !Time
fvar(12) = 2

[State 3205, TargetLifeAdd]
type = TargetLifeAdd
trigger1 = Time = 4
trigger2 = Time = 13
trigger3 = Time = 22
trigger4 = Time = 31
trigger5 = Time = 40
trigger6 = Time = 49
trigger7 = Time = 58
trigger8 = Time = 67
trigger9 = Time = 76
trigger10 = Time = 5
trigger11 = Time = 14
trigger12 = Time = 21
trigger13 = Time = 29
trigger14 = Time = 37
trigger15 = Time = 45
trigger16 = Time = 53
trigger17 = Time = 61
trigger18 = Time = 69
trigger19 = Time = 77
trigger20 = Time = 3
trigger21 = Time = 7
trigger22 = Time = 11
trigger23 = Time = 15
trigger24 = Time = 19
trigger25 = Time = 23
trigger26 = Time = 27
trigger27 = Time = 32
;trigger28 = Time = 35
;trigger29 = Time = 39
trigger28 = Time = 50
value = -13
kill = 0
persistent = 1

[State 3205, TargetLifeAdd3]
type = TargetLifeAdd
trigger1 = Time = 85
value = -30
kill = 1
persistent = 1

[State 3205, HitAdd]
type = HitAdd
triggerall = Anim != 3203
trigger1 = AnimElem = 2
trigger2 = AnimElem = 6
trigger3 = AnimElem = 10
trigger4 = AnimElem = 14
trigger5 = AnimElem = 18
trigger6 = AnimElem = 22
trigger7 = AnimElem = 26
trigger8 = AnimElem = 30
trigger9 = AnimElem = 34
trigger10 = AnimElem = 38
value = 1

[State 3205, PlaySnd]
type = PlaySnd
triggerall = Anim != 3203
trigger1 = AnimElem = 2
trigger2 = AnimElem = 6
trigger3 = AnimElem = 10
trigger4 = AnimElem = 14
trigger5 = AnimElem = 18
trigger6 = AnimElem = 22
trigger7 = AnimElem = 26
trigger8 = AnimElem = 30
trigger9 = AnimElem = 34
trigger10 = AnimElem = 38
value = S2,2
channel = 1

[State 3205, Turn]
type = Turn
trigger1 = AnimTime = 0
persistent = 0

[State 3205, TargetState]
type = TargetState
trigger1 = AnimTime = 0
value = 3261
persistent = 0

[State 3205, ChangeAnim]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 3203
persistent = 0

[State 3205, VelSet]
type = VelSet
trigger1 = Anim = 3203
x = 7

[State 3205, DestroySelf]
type = DestroySelf
trigger1 = FrontEdgeBodyDist < -112

;Conect
[Statedef 3211]
type = S
physics = S
movetype = A
anim = 3203
ctrl = 0

[State 3211, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3211, VarSet]
type = VarSet
trigger1 = !Time
var(46) = 2

[State 3211, VelSet]
type = VelSet
trigger1 = 1
x = ParentDist X/16

[State 3211, ParentVarAdd]
type = ParentVarAdd
trigger1 = ParentDist X <= 55
var(40) = 1
persistent = 0

[State 3211, BindToTarget]
type = BindToParent
trigger1 = ParentDist X <= 55
pos = floor(Const(size.XScale)*-55),-(Parent, Pos Y)

[State 3211, ChangeState]
type = ChangeState
trigger1 = parent, Var(40) = 3
trigger1 = parent, numHelper(3203)
trigger1 = parent, numHelper(3220)
trigger1 = parent, numHelper(3230)  ;&& numHelper(3231) && numHelper (3209)
value = 3212

;Conect
[Statedef 3212]
type = S
physics = S
movetype = A
anim = 3205
ctrl = 0
velset = 0,0

[State 3212, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3212, BindToTarget]
type = BindToParent
trigger1 = !Time
pos = floor(Const(size.XScale)*-55),-(Parent, Pos Y)

[State 3212, HitAdd]
type = HitAdd
triggerall = Anim = 3205
trigger1 = AnimElem = 2
trigger2 = AnimElem = 6
trigger3 = AnimElem = 10
trigger4 = AnimElem = 14
trigger5 = AnimElem = 18
trigger6 = AnimElem = 22
trigger7 = AnimElem = 26
trigger8 = AnimElem = 30
trigger9 = AnimElem = 34
trigger10 = AnimElem = 38
value = 1

[State 3212, PlaySnd]
type = PlaySnd
triggerall = Anim != 3203
trigger1 = AnimElem = 2
trigger2 = AnimElem = 6
trigger3 = AnimElem = 10
trigger4 = AnimElem = 14
trigger5 = AnimElem = 18
trigger6 = AnimElem = 22
trigger7 = AnimElem = 26
trigger8 = AnimElem = 30
trigger9 = AnimElem = 34
trigger10 = AnimElem = 38
value = S2,2
channel = 1

[State 3212, Turn]
type = Turn
trigger1 = AnimTime = 0
persistent = 0

[State 3212, TargetState]
type = TargetState
triggerall = Anim = 3205
trigger1 = AnimTime = 0
value = 3261
persistent = 0

[State 3212, ChangeAnim]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 3203
persistent = 0

[State 3205, VelSet]
type = VelSet
trigger1 = Anim = 3203
x = 7

[State 3212, DestroySelf]
type = DestroySelf
trigger1 = FrontEdgeBodyDist < -112

;Pico (hurt)
[Statedef 3250]
type = U
physics = S
movetype = I
ctrl = 0
anim = 3206

[State 3250, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3250, VelSet]
type = VelSet
trigger1 = Time > 0
x = -7*Const(Size.XScale)*(4.0/3.0)

[State 3250, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = S5950,0

[State 3250, DestroySelf]
type = DestroySelf
triggerall = Time > 10
trigger1 = FrontEdgeBodyDist < -112
trigger2 = BackEdgeBodyDist < -112

;Nana, Mimi
[Statedef 3206]
type = A
physics = N
movetype = A
anim = 3210
ctrl = 0

[State 3206, VarSet]
type = VarSet
trigger1 = !Time
var(10) = root,var(10)

[State 3206, VarSet]
type = VarSet
trigger1 = !Time
var(1) = 0

[State 3206, VarAdd]
type = VarAdd
trigger1 = MoveHit = 1
trigger1 = P2MoveType != H
trigger2 = MoveContact
trigger2 = !NumTarget
trigger3 = Parent, MoveType = H
var(1) = 1

[State 3206, TargetDrop]
type = targetdrop
triggerall = NumTarget(3200)
trigger1 = Var(1)

[State 3203, VarSet]
type = VarSet
trigger1 = !Time
var(40) = 0

[State 3206, StateTypeSet]
type = StateTypeSet
trigger1 = Var(1)
movetype = I

[State 3206, VarSet]
type = VarSet
trigger1 = !Time
var(46) = 1

[State 3206, NotHitBy]
type = NotHitBy
triggerall = Var(1)
trigger1 = 1
value = SCA

[State 3206, HitOverRide]
type = HitOverRide
trigger1 = 1
stateno = 3251
attr = SAC,NP,SP,HP,NA,SA,HA

[State 3206, HitBy]
type = HitBy
trigger1 = !Var(1)
value = SAC,NP,SP,HP,NA,SA,HA

[State 3206, VelSet]
type = VelSet
trigger1 = !Time
x = 7*Const(Size.XScale)*(5.0/4.0)
y = ifElse(Var(10)=2,-5.28125,.5)*Const(Size.YScale)*(5.0/4.0)

[State 3206, Gravity]
type = VelAdd
trigger1 = Time
y = ifElse(Var(10)=2,0.21875,.25)*Const(Size.YScale)*(25.0/16.0)

[State 3206, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3206, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3206, 1]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
triggerall = !NumHelper(3220) && !NumHelper(3230) && !NumHelper(3203)
trigger1 = !Var(1)
attr = ,SA
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 8
animtype = Heavy
air.animtype = Back
fall.animtype = Back
guardflag = M
hitflag = MAF
priority = 3, Hit
pausetime = 8,8
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -28
ground.type = Low
ground.slidetime = 10
ground.hittime  = 10
ground.velocity = 0
guard.velocity = 0
guard.ctrltime = 10
air.type = Low
air.velocity = 0, 0
airguard.velocity = -6,-3
air.hittime = 120
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getpower = 0,0
givepower = 36,36
yaccel = .46875
air.fall = 1
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0
ID = 3200

[State 3206, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 9)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3206, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8017)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3206, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
pos = ceil(P2Dist x), 0
postype = P1
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3206, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 3206, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 3206, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 3206, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [3200,3299]
var(18) = 1
persistent = 0

[State 3206, TargetState]
type = TargetState
trigger1 = MoveHit = 1 && P2MoveType = H;&& NumTarget(3200)
value = 3260

[State 3206, ChangeState]
type = ChangeState
triggerall = !Var(1)
triggerall = NumTarget(3200)
trigger1 = MoveHit = 1 && P2MoveType = H
value = 3207

[State 3206, ChangeState]
type = ChangeState
trigger1 = Var(1)
trigger2 = MoveGuarded
value = 3251
ignorehitpause = 1

[State 3206, ChangeState]
type = ChangeState
trigger1 = Vel Y + Pos Y >= 0
value = 3214

;Conect
[Statedef 3207]
type = A
physics = N
movetype = I
anim = 3212
ctrl = 0
velset = 0,0

[State 3207, ParentVarSet]
type = ParentVarSet
trigger1 = !Time
fvar(12) = 1

[State 3207, VarSet]
type = VarSet
trigger1 = Time = 0
var(40) = 0

[State 3207, BindToTarget]
type = BindToTarget
trigger1 = Time = 1
pos = -14,0,Head

[State 3207, Helper]
type = Helper
trigger1 = Time = 1
helpertype = Normal
name = "Pico"
ID = 3203
stateno = 3211
pos = -50,0
postype = Back
facing = 1
keyctrl = 0
ownpal = 1
size.XScale = Const(size.XScale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3207, Helper]
type = Helper
trigger1 = Time = 1
helpertype = Normal
name = "Grace"
ID = 3230
stateno = 3230
pos = -50,-25
postype = Back
facing = 1
keyctrl = 0
ownpal = 1
size.XScale = Const(size.XScale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3207, Helper]
type = Helper
trigger1 = Time = 1
helpertype = Normal
name = "Lucy"
ID = 3220
stateno = 3220
pos = 42,0
postype = Front
facing = -1
keyctrl = 0
ownpal = 1
size.XScale = Const(size.XScale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3207, ChangeState]
type = ChangeState
trigger1 = Var(40) = 3 && numHelper(3203) && numHelper(3220) && numHelper(3230)
value = 3213

;Conect
[Statedef 3208]
type = A
physics = N
movetype = I
anim = 3214
ctrl = 0
sprpriority = 0

[State 3208, VarSet]
type = VarSet
trigger1 = !Time
var(33) = (enemy, Const(Size.Head.Pos.Y))

[State 3208, VelSet]
type = VelSet
trigger1 = !Time
y = (abs(Pos Y)-abs(Var(33)))/6

[State 3208, ChangeAnim]
type = ChangeAnim
trigger1 = Pos Y >= Var(33)
value = 3212
persistent = 0

[State 3208, ParentVarAdd]
type = ParentVarAdd
trigger1 = Anim = 3212;Pos Y = -60
var(40) = 1
persistent = 0

[State 3208, VelSet]
type = VelSet
trigger1 = Pos Y >= Var(33)
y = 0

[State 3208, PosSet]
type = PosSet
trigger1 = Pos Y >= Var(33)
y = Var(33)

[State 3208, ChangeState]
type = ChangeState
trigger1 = parent,Var(40) = 3 ;&& numHelper(3231) && numHelper (3209)
value = 3209

;Conect
[Statedef 3209]
type = A
physics = N
movetype = A
anim = 3213
ctrl = 0
sprpriority = 0
velset = 0,0

[State 3209, PosSet]
type = PosSet
trigger1 = !Time
y = Var(33)

[State 3209, Hit Sound]
type = PlaySnd
triggerall = Anim = 3213
trigger1 = AnimElemTime(7) = 0
trigger2 = AnimElemTime(14) = 0
trigger3 = AnimElemTime(21) = 0
trigger4 = AnimElemTime(28) = 0
value = S2,2
channel = 2
ignorehitpause = 1

[State 3209, Sparks]
type = Helper
triggerall = Anim = 3213
trigger1 = AnimElemTime(7) = 0
trigger2 = AnimElemTime(14) = 0
trigger3 = AnimElemTime(21) = 0
trigger4 = AnimElemTime(28) = 0
helpertype = normal
stateno = 8014
ID = 8000
name = "Spark"
postype = P1
pos = 7,-4
facing = -1
ownpal = 1
pausemovetime = 65535
supermovetime = 65535
ignorehitpause = 1

[State 3209, HitAdd]
type = HitAdd
triggerall = Anim = 3213
trigger1 = AnimElem = 7
trigger2 = AnimElem = 14
trigger3 = AnimElem = 21
trigger4 = AnimElem = 28
value = 1

[State 3209, ChangeAnim]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 3210
persistent = 0

[State 3206, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3209, VelSet2]
type = VelSet
trigger1 = Anim = 3210
x = 3
y = -2.5
persistent = 0

[State 3209, Gravity]
type = Gravity
trigger1 = Anim = 3210

[State 3209, PosSet2]
type = PosSet
trigger1 = Vel Y + Pos Y >= 0
y = 0

[State 3209, WTF]
type = VelSet
trigger1 =Vel Y + Pos Y >= 0
y = 0

[State 3209, Turn]
type = Turn
trigger1 = Vel Y + Pos Y >= 0
persistent = 0

[State 3209, ChangeAnim]
type = ChangeAnim
trigger1 = Vel Y + Pos Y >= 0
value = 3215
persistent = 0

[State 3209, VelSet4]
type = VelSet
trigger1 = Anim = 3215
x = 4

[State 3209, DestroySelf]
type = DestroySelf
triggerall = Anim = 3215
trigger1 = FrontEdgeBodyDist < -112

;TERMINATE= TIME = 52

;Conect
[Statedef 3213]
type = A
physics = N
movetype = A
anim = 3213
ctrl = 0
sprpriority = 0
velset = 0,0

[State 3213, PosSet]
type = PosSet
trigger1 = !Time
y = Pos Y;-90

[State 3213, ParentVarSet]
type = ParentVarSet
trigger1 = !Time
fvar(12) = 2

[State 3213, VarSet]
type = VarSet
trigger1 = 1
var(40) = 3

[State 3213, TargetLifeAdd]
type = TargetLifeAdd
trigger1 = Time = 4
trigger2 = Time = 13
trigger3 = Time = 22
trigger4 = Time = 31
trigger5 = Time = 40
trigger6 = Time = 49
trigger7 = Time = 58
trigger8 = Time = 67
trigger9 = Time = 76
trigger10 = Time = 5
trigger11 = Time = 14
trigger12 = Time = 21
trigger13 = Time = 29
trigger14 = Time = 37
trigger15 = Time = 45
trigger16 = Time = 53
trigger17 = Time = 61
trigger18 = Time = 69
trigger19 = Time = 77
trigger20 = Time = 3
trigger21 = Time = 7
trigger22 = Time = 11
trigger23 = Time = 15
trigger24 = Time = 19
trigger25 = Time = 23
trigger26 = Time = 27
trigger27 = Time = 32
trigger28 = Time = 50
value = -13
kill = 0
persistent = 1

[State 3213, TargetLifeAdd3]
type = TargetLifeAdd
trigger1 = Time = 85
value = -30
kill = 1
persistent = 1

[State 3213, Hit Sound]
type = PlaySnd
triggerall = Anim = 3213
trigger1 = AnimElemTime(7) = 0
trigger2 = AnimElemTime(14) = 0
trigger3 = AnimElemTime(21) = 0
trigger4 = AnimElemTime(28) = 0
value = S2,5
channel = 2
ignorehitpause = 1

[State 3213, Sparks]
type = Helper
triggerall = Anim = 3213
trigger1 = AnimElemTime(7) = 0
trigger2 = AnimElemTime(14) = 0
trigger3 = AnimElemTime(21) = 0
trigger4 = AnimElemTime(28) = 0
helpertype = normal
stateno = 8014
ID = 8000
name = "Spark"
postype = P1
pos = 7,-4
facing = -1
ownpal = 1
pausemovetime = 65535
supermovetime = 65535
ignorehitpause = 1

[State 3213, HitAdd]
type = HitAdd
triggerall = Anim = 3213
trigger1 = AnimElem = 7
trigger2 = AnimElem = 14
trigger3 = AnimElem = 21
trigger4 = AnimElem = 28
value = 1

[State 3213, TargetState]
type = TargetState
triggerall = Anim != 3210
trigger1 = AnimTime = 0
value = 3261
persistent = 0

[State 3213, ChangeAnim]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 3210
persistent = 0

[State 3213, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3213, VelSet2]
type = VelSet
trigger1 = Anim = 3210
x = 3
y = -2.5
persistent = 0

[State 3213, Gravity]
type = Gravity
trigger1 = Anim = 3210

[State 3213, PosSet2]
type = PosSet
trigger1 = Vel Y + Pos Y >= 0
y = 0

[State 3213, WTF]
type = VelSet
trigger1 = Vel Y + Pos Y >= 0
y = 0

[State 3213, Turn]
type = Turn
trigger1 = Vel Y + Pos Y >= 0
persistent = 0

[State 3213, ChangeAnim]
type = ChangeAnim
trigger1 = Vel Y + Pos Y >= 0
value = 3215
persistent = 0

[State 3213, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 3215
movetype = I

[State 3213, VelSet4]
type = VelSet
trigger1 = Anim = 3215
x = 4

[State 3213, DestroySelf]
type = DestroySelf
triggerall = Anim = 3215
trigger1 = FrontEdgeBodyDist < -112

;Conect
[Statedef 3214]
type = S
physics = N
movetype = I
ctrl = 0
sprpriority = 0
anim = 3217
velset = 0,0

[State 3214, PosSet]
type = PosSet
trigger1 = !Time
y = 0

[State 3214, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 3217 && AnimTime = 0
value = 3215

[State 3214, Turn]
type = Turn
trigger1 = Anim = 3215
persistent = 0

[State 3214, VelSet4]
type = VelSet
trigger1 = Anim = 3215
x = 4

[State 3214, DestroySelf]
type = DestroySelf
triggerall = Anim = 3215
trigger1 = FrontEdgeBodyDist < -112

;Nana, Mimi (hurt)
[Statedef 3251]
type = U;S
physics = N;S
movetype = I;H
anim = 3216
velset = 0,0
ctrl = 0

[State 3251, PosFreeze]
type = ChangeAnim
trigger1 = Time = [0,10]
value = anim

[State 3251, PosFreeze]
type = PosFreeze
trigger1 = Time = [0,10]
value = 1

[State 3251, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3251, VelSet]
type = VelSet
trigger1 = Time = 11
x = 3*Const(Size.XScale)*(5.0/4.0)
y = -4*Const(Size.YScale)*(5.0/4.0)

[State 3251, Gravity]
type = VelAdd
trigger1 = Time > 10
y = .25*Const(Size.YScale)*(25.0/16.0)

[State 3251, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 3216 && AnimTime = 0
value = 3210

[State 3251, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = S5950,0

[State 3251, DestroySelf]
type = ChangeState
trigger1 = Vel Y + Pos Y >= 0
value = 3214

;Nonno/Tama
[Statedef 3210]
type = A
physics = N
movetype = I
anim = 1205
ctrl = 0

[State 3210, Loop]
type = VarAdd
trigger1 = !Time
var(40) = 1

[State 3210, Gravity]
type = Gravity
trigger1 = Var(40) = 1

[State 3210, VelAdd]
type = VelAdd
trigger1 = Var(40) > 1
y = .5

[State 3210, VelSet]
type = ChangeState
trigger1 = Pos Y + Vel Y >= 0
value = 3215

;Conect
[Statedef 3215]
type = S
physics = N
movetype = I
anim = 1207
ctrl = 0
velset = 0,0

[State 3215, PosSet]
type = PosSet
trigger1 = !Time
y = 0

[State 3215, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(Var(40)=4,3240,1207)

[State 3215, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = S1200,1

[State 3215, VelSet]
type = VelSet
trigger1 = Anim = 1207 && AnimElemTime(2) = 4
y = -9/Var(40)

[State 3215, ChangeAnim]
type = ChangeState
trigger1 = Anim = 1207 && AnimElemTime(2) = 4
value = 3210

[State 3215, DestroySelf]
type = DestroySelf
trigger1 = roundstate < 4

;Lucy
[Statedef 3220]
type = S
physics = N
movetype = I
anim = 3220
ctrl = 0
sprpriority = 2

[State 3220, VelSet]
type = VelSet
trigger1 = 1
x = ParentDist X/16;7

[State 3220, VelSet]
type = VelSet
trigger1 = !Time
y = -1.5

[State 3220, Gravity]
type = Gravity
trigger1 = Time > 7

[State 3220, PosSet]
type = PosSet
triggerall = Time > 1
trigger1 = Pos Y >= 0
y = 0

[State 3220, VelSet]
type = VelSet
triggerall = Time > 1
trigger1 = Pos Y >= 0
x = 0
y = 0

[State 3220, BindToTarget]
type = BindToParent
triggerall = Time > 1
trigger1 = Pos Y = 0
pos = (ifElse((Parent, Var(46) = 2),(floor(Const(size.XScale)*88)),(floor(Const(size.XScale)*42)))),(ifElse((Parent, Var(46) = 2),0,-(Parent, Pos Y)))

[State 3220, ChangeState]
type = ChangeState
triggerall = Time > 1
trigger1 = Pos Y = 0
value = 3221

;Conect
[Statedef 3221]
type = S
physics = N
movetype = I
anim = 3221
ctrl = 0
sprpriority = 2
velset = 0,0

[State 3221, BindToTarget]
type = BindToParent
trigger1 = !Time
pos = (ifElse((Parent, Var(46) = 2),(floor(Const(size.XScale)*88)),(floor(Const(size.XScale)*42)))),(ifElse((Parent, Var(46) = 2),0,-(Parent, Pos Y)))

[State 3221, ParentVarSet]
type = ParentVarAdd
trigger1 = !Time
var(40) = 1
persistent = 0

[State 3221, ChangeAnim]
type = ChangeAnim
trigger1 = Parent, Var(40) = 3
value = 3222
persistent = 0

[State 3221, HitAdd]
type = HitAdd
triggerall = Anim = 3222
trigger1 = AnimElem = 1
trigger2 = AnimElem = 5
trigger3 = AnimElem = 9
trigger4 = AnimElem = 13
trigger5 = AnimElem = 17
trigger6 = AnimElem = 21
trigger7 = AnimElem = 25
trigger8 = AnimElem = 29
trigger9 = AnimElem = 33
trigger10 = AnimElem = 37
value = 1

[State 3221, Hit Sound]
type = PlaySnd
triggerall = Anim = 3222
trigger1 = AnimElemTime(1) = 0
trigger2 = AnimElemTime(5) = 0
trigger3 = AnimElemTime(9) = 0
trigger4 = AnimElemTime(13) = 0
trigger5 = AnimElemTime(17) = 0
trigger6 = AnimElemTime(21) = 0
trigger7 = AnimElemTime(25) = 0
trigger8 = AnimElemTime(29) = 0
trigger9 = AnimElemTime(33) = 0
trigger10 = AnimElemTime(37) = 0
value = S2,2
channel = 2
ignorehitpause = 1

[State 3221, Sparks]
type = Helper
triggerall = Anim = 3222
trigger1 = AnimElemTime(1) = 0
trigger2 = AnimElemTime(5) = 0
trigger3 = AnimElemTime(9) = 0
trigger4 = AnimElemTime(13) = 0
trigger5 = AnimElemTime(17) = 0
trigger6 = AnimElemTime(21) = 0
trigger7 = AnimElemTime(25) = 0
trigger8 = AnimElemTime(29) = 0
trigger9 = AnimElemTime(33) = 0
trigger10 = AnimElemTime(37) = 0
helpertype = normal
stateno = 8014
ID = 8000
name = "Spark"
postype = P1
pos = 53,-41
facing = -1
ownpal = 1
pausemovetime = 65535
supermovetime = 65535
ignorehitpause = 1

[State 3221, Turn]
type = Turn
triggerall = Anim != 3221
trigger1 = AnimTime = 0
persistent = 0

[State 3221, TargetState]
type = TargetState
triggerall = Anim != 3221
trigger1 = AnimTime = 0
value = 3261
persistent = 0

[State 3221, ChangeAnim]
type = ChangeAnim
triggerall = Anim != 3221
trigger1 = AnimTime = 0
value = 3220
persistent = 0

[State 3221, VelSet]
type = VelSet
trigger1 = Anim = 3220
x = 7

[State 3221, DestroySelf]
type = DestroySelf
triggerall = Anim = 3220
trigger1 = FrontEdgeBodyDist < -112

;Grace
[Statedef 3230]
type = S
physics = N
movetype = I
anim = 3230
ctrl = 0
sprpriority = 1

[State 3230, PosSet]
type = PosSet
trigger1 = Time <= 3
y = -25

[State 3230, VarSet]
type = VarSet
trigger1 = !Time
fvar(0) = abs(ParentDist X)

[State 3230, VarSet]
type = VarSet
trigger1 = 1
fvar(1) = abs(ParentDist X)

[State 3230, VelSet]
type = VelSet
trigger1 = 1
x = ParentDist X/16;7

[State 3230, VelSet]
type = VelSet
trigger1 = !Time
y = -1.5

[State 3230, Gravity]
type = Gravity
trigger1 = Time >= 8;Time > 10

[State 3230, PosSet]
type = PosSet
trigger1 = Pos Y + Vel Y >= 0
y = 0

[State 3230, VelSet]
type = VelSet
trigger1 = Pos Y + Vel Y >= 0
x = 0
y = 0

[State 3230, BindToTarget]
type = BindToParent
trigger1 = Pos Y = 0
pos = (ifElse((Parent, Var(46) = 2),(floor(Const(size.XScale)*-24)),(floor(Const(size.XScale)*-66)))),(ifElse((Parent, Var(46) = 2),0,-(Parent, Pos Y)))

[State 3230, ChangeState]
type = ChangeState
trigger1 = Pos Y = 0
value = 3231

;Conect
[Statedef 3231]
type = S
physics = N
movetype = I
anim = 3231
ctrl = 0

[State 3231, BindToTarget]
type = BindToParent;Target
trigger1 = !Time
pos = (ifElse((Parent, Var(46) = 2),(floor(Const(size.XScale)*-24)),(floor(Const(size.XScale)*-66)))),(ifElse((Parent, Var(46) = 2),0,-(Parent, Pos Y)))

[State 3231, ParentVarSet]
type = ParentVarAdd
trigger1 = !Time
var(40) = 1
persistent = 0

[State 3231, ChangeAnim]
type = ChangeAnim
triggerall = Anim = 3231
trigger1 = Parent, Var(40) = 3;AnimTime = 0
value = 3232
;persistent = 0

[State 3231, Hit Sound]
type = PlaySnd
triggerall = Anim = 3232
trigger1 = AnimElemTime(2) = 0
trigger2 = AnimElemTime(5) = 0
trigger3 = AnimElemTime(8) = 0
trigger4 = AnimElemTime(11) = 0
trigger5 = AnimElemTime(14) = 0
trigger6 = AnimElemTime(17) = 0
trigger7 = AnimElemTime(20) = 0
trigger8 = AnimElemTime(23) = 0
trigger9 = AnimElemTime(26) = 0
trigger10 = AnimElemTime(29) = 0
value = S2,2
channel = 2
ignorehitpause = 1

[State 3231, Sparks]
type = Helper
triggerall = Anim = 3232
trigger1 = AnimElemTime(2) = 0
trigger2 = AnimElemTime(5) = 0
trigger3 = AnimElemTime(8) = 0
trigger4 = AnimElemTime(11) = 0
trigger5 = AnimElemTime(14) = 0
trigger6 = AnimElemTime(17) = 0
trigger7 = AnimElemTime(20) = 0
trigger8 = AnimElemTime(23) = 0
trigger9 = AnimElemTime(26) = 0
trigger10 = AnimElemTime(29) = 0
helpertype = normal
stateno = 8014
ID = 8000
name = "Spark"
postype = P1
pos = 63,-40
facing = -1
ownpal = 1
pausemovetime = 65535
supermovetime = 65535
ignorehitpause = 1

[State 3231, HitAdd]
type = HitAdd
triggerall = Anim = 3232
trigger1 = AnimElem = 2
trigger2 = AnimElem = 5
trigger3 = AnimElem = 8
trigger4 = AnimElem = 11
trigger5 = AnimElem = 14
trigger6 = AnimElem = 17
trigger7 = AnimElem = 20
trigger8 = AnimElem = 23
trigger9 = AnimElem = 26
trigger10 = AnimElem = 29
value = 1

[State 3231, Explod]
type = Explod
triggerall = Anim = 3232
trigger1 = AnimElemTime(14) = 0
trigger2 = AnimElemTime(30) = 6
anim = 7020
pos = 36,-80
postype = p1
ownpal = 1
bindtime = 1
pausemovetime = -2
supermove = 1
ignorehitpause = 1
sprpriority = 3
scale = 0.5*const(Size.XScale),0.5*const(Size.Yscale)

[State 3231, Turn]
type = Turn
triggerall = Anim != 3231
trigger1 = AnimTime = 0
persistent = 0

[State 3231, TargetState]
type = TargetState
triggerall = Anim != 3231
trigger1 = AnimTime = 0
value = 3261
persistent = 0

[State 3231, ChangeAnim]
type = ChangeAnim
triggerall = Anim != 3231
trigger1 = AnimTime = 0
value = 3230
persistent = 0

[State 3231, VelSet]
type = VelSet
trigger1 = Anim = 3230
x = 7

[State 3231, DestroySelf]
type = DestroySelf
triggerall = Anim = 3230
trigger1 = FrontEdgeBodyDist < -112

;========================<SPARKS>=============================
;Guard Spark (Normal)
[StateDef 8000]
type = A
physics = N
moveType = I
anim = 8000
velset = 0,0
sprPriority = 5

[State 8000, Assert: No Shadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8000, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.125 + (0.046875 * Time), 0.125 + (0.046875 * Time)
ignoreHitPause = 1

[State 8000, Transparency]
type = Trans
trigger1 = Time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8000, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8000, End]
type = DestroySelf
trigger1 = Time >= 8


;Guard Spark (Special)
[StateDef 8001]
type = A
physics = N
moveType = I
anim = 8001
velSet = 0,0
sprPriority = 5

[State 8001, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8001, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
ignoreHitPause = 1

[State 8001, Transparency]
type = Trans
trigger1 = time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8001, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8001, End]
type = DestroySelf
trigger1 = Time >= 8


;Weak Hit Spark
[StateDef 8010]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8010, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8010, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8010, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8010, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.3 - (Time * 0.03), 0.3 - (Time * 0.03)
ignoreHitPause = 1

[State 8010, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8010, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8010, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.15 + (0.009375 * Time), 0.15 + (0.009375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time),256

[State 8010, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.15 + (0.009375 * Time), 0.15 + (0.009375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8010, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.3 - (0.0375 * Time), 0.3 - (0.0375 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8010, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8010, End]
type = DestroySelf
trigger1 = Time >= 16


;Medium Hit Spark
[StateDef 8011]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8011, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8011, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8011, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8011, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.35 - (Time * 0.035), 0.35 - (Time * 0.035)
ignoreHitPause = 1

[State 8011, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8011, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8011, Center]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removetime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.175 + (0.0109375 * Time), 0.175 + (0.0109375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8011, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.175 + (0.0109375 * Time), 0.175 + (0.0109375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8011, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.35 - (0.04375 * Time), 0.35 - (0.04375 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8011, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8011, End]
type = DestroySelf
trigger1 = Time >= 16


;Strong Hit Spark
[StateDef 8012]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8012, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8012, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8012, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8012, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.4 - (Time * 0.04), 0.4 - (Time * 0.04)
ignoreHitPause = 1

[State 8012, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8012, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8012, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8012, Streaks Explod]
type = Explod
trigger1 = !time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8012, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.4 - (0.05 * Time), 0.4 - (0.05 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8012, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8012, End]
type = DestroySelf
trigger1 = Time >= 16


;Special Move Hit Spark
[StateDef 8013]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8013, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8013, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8013, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8013, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.45 - (Time * 0.045), 0.45 - (Time * 0.045)
ignoreHitPause = 1

[State 8012, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8013, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8013, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8013, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8013, P2 Back Explod]
type = Explod
trigger1 = !Time
anim = 8013
ID = 3
posType = P1
facing = -1
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = -3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale P2 Back Explod]
type = ModifyExplod
trigger1= NumExplod(3)
ID = 3
scale = 0.4, 0.4
trans = AddAlpha
alpha = 256 - (32 * Time), 256

[State 8013, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(random < 500, -1, 1)
vFacing = ifElse(random < 500, -1, 1)
sprPriority=3
removeTime=8
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.45 - (0.05625 * Time), 0.45 - (0.05625 * Time)
trans = AddAlpha
alpha = 192 - (24 * Time), 256

[State 8013, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8013, End]
type = DestroySelf
trigger1 = Time >= 16


;Super Hit Spark
[StateDef 8014]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8014, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8014, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8014, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8014, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.5 - (Time * 0.05), 0.5 - (Time * 0.05)
ignoreHitPause = 1

[State 8014, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8014, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8014, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8014, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8014, P2 Back Explod]
type = Explod
trigger1 = !Time
anim = 8013
ID = 3
posType = P1
facing = ifElse((Parent, StateNo = [3000,3999]), -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = -3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale P2 Back Explod]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 0.5,0.5
trans = AddAlpha
alpha = 256 - (32 * Time), 256

[State 8014, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.5 - (0.0625 * Time), 0.5 - (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (32 * Time),256

[State 8014, Remove Explods]
type = RemoveExplod
trigger1 = time >= 16

[State 8014, End]
type = DestroySelf
trigger1 = Time >= 16

;Normal Slash Spark
[StateDef 8015]
type = A
physics = N
moveType = I
anim = 8015
velSet = 0,0
sprPriority = 5

[State 8015, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8015, AngleSet]
type = AngleSet
trigger1 = !Time
value = 15 * (Random % 24)

[State 8015, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = (0.5 + (Time * 0.15)) / 2, (1 - (Time * 0.1)) / 2
ignoreHitPause = 1

[State 8015, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8015, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8015, Streaks Explod]
type = Explod
trigger1 = !time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8015, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8015, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8015, End]
type = DestroySelf
trigger1 = Time >= 16

;Special Move Slash Spark
[StateDef 8016]
type = A
physics = N
moveType = I
anim = 8015
velSet = 0,0
sprPriority = 5

[State 8016, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8016, AngleSet]
type = AngleSet
trigger1 = !Time
value = 15 * (Random % 24)

[State 8016, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = (0.5 + (Time * 0.15)) / 2, (1 - (Time * 0.1)) / 2
ignoreHitPause = 1

[State 8016, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8016, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8016, Circle]
type = Explod
trigger1 = !Time
anim = 8016
ID = 8016
posType = p1
removeTime = 10
sprPriority = 5
pauseMoveTime = -1
superMoveTime = -1

[State 8016, Circle Scale]
type = ModifyExplod
trigger1 = NumExplod(8016)
ID = 8016
scale = 0.25 + (0.025 * Time), 0.25 + (0.025 * Time)
trans = AddAlpha
alpha = ceil(256 - 25.6 * Time), 256

[State 8016, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8016, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8016, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8016, End]
type = DestroySelf
trigger1 = Time >= 16

;Super Move Slash Spark
[StateDef 8017]
type = A
physics = N
moveType = I
anim = 8015
velSet = 0,0
sprPriority = 5

[State 8017, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8017, AngleSet]
type = AngleSet
trigger1 = !Time
value = 15 * (Random % 24)

[State 8017, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = (0.5 + (Time * 0.15)) / 2, (1 - (Time * 0.1)) / 2
ignoreHitPause = 1

[State 8017, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8017, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8017, Circle]
type = Explod
trigger1 = !Time
anim = 8016
ID = 8016
posType = p1
removeTime = 10
sprPriority = 5
pauseMoveTime = -1
superMoveTime = -1

[State 8017, Circle Scale]
type = ModifyExplod
trigger1 = NumExplod(8016)
ID = 8016
scale = 0.3 + (0.03 * Time), 0.3 + (0.03 * Time)
trans = AddAlpha
alpha = ceil(256 - 25.6 * Time), 256

[State 8017, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8017, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8017, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8017, End]
type = DestroySelf
trigger1 = Time >= 16

;Reversal Spark
[StateDef 8020]
type = A
physics = N
moveType = I
anim = 8020
velSet = 0,0
sprPriority = 5

[State 8020, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8020, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.09375 * Time), 0.25 + (0.09375 * Time)
ignoreHitPause = 1

[State 8020, Transparency]
type = Trans
trigger1 = Time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8020, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8020, End]
type = DestroySelf
trigger1 = Time >= 8



;======================<JUMP DUST>===========================
[StateDef 8100]
type = S
anim = 1
velSet = 0,0

[State 8100, Bind]
type = BindToRoot
trigger1 = Time

[State 8100, Floor Dust]
type = Explod
trigger1 = !Time
anim = 8100
sprPriority = 3
posType = P1
pos = 0, ceil(pos y)
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8100, Player Dust]
type = Explod
trigger1 = !Time || Time = 2 || Time = 6
anim = 8101
sprPriority = 3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8100, End]
type = DestroySelf
trigger1 = Time >= 7



;======================<DASH DUST>===========================
[StateDef 8103]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8103, posSet]
type = PosSet
trigger1 = !Time = 0
y = 0

[State 8103, Dash Dust]
type = Explod
trigger1 = Time = 0 || Time = 3 || Time = 6
anim = 8103
ID = ifElse((Time = 6), 3, ifElse((Time = 3), 2, 1))
posType = P1
pos = 0,-4
random = 8,8
vel = -3 - (Random / 1000.0), -2 - (Random / 2000.0)
facing = ifElse(Random < 500,-1,1)
vFacing = ifElse(Random < 500,-1,1)
removeTime = 16
sprPriority = 3
pauseMoveTime = -1
superMoveTime = -1

[State 8103, Scale Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.1 + (0.025 * Time), 0.1 + (0.025 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8103, Scale Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.1 + (0.025 * (Time - 3)), 0.1 + (0.025 * (Time - 3))
trans = AddAlpha
alpha = 256 - (16 * (Time - 3)), 256

[State 8103, Scale Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 0.1 + (0.025 * (Time - 6)), 0.1 + (0.025 * (Time - 6))
trans = AddAlpha
alpha = 256 - (16 * (Time - 6)), 256

[State 8103, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 22

[State 8103, End]
type = DestroySelf
trigger1 = !NumExplod


;======================<IMPACT DUST>===========================
[StateDef 8110]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8110, Impact Dust Explod 1]
type = Explod
trigger1 = !Time
anim = 8110
ID = ifElse(Time = 8, 3, ifElse(Time = 4, 2, 1))
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8110, Impact Dust Explod 2]
type = Explod
trigger1 = !Time
anim = 8120
ID = 2
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8110, Scale]
type = ModifyExplod
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 256, 256 - (64 * (Time - 4))), 256

[State 8110, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 8

[State 8110, End]
type = DestroySelf
trigger1 = !NumExplod


;======================<WALL IMPACT DUST>===========================
[StateDef 8111]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8111, Impact Dust Explod 1]
type = Explod
trigger1 = !Time
anim = 8111
ID = ifElse(Time = 8, 3, ifElse(Time = 4, 2, 1))
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8111, Impact Dust Explod 2]
type = Explod
trigger1 = !Time
anim = 8121
ID = 2
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8111, Scale]
type = ModifyExplod
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 256, 256 - (64 * (Time - 4))), 256

[State 8111, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 8

[State 8111, End]
type = DestroySelf
trigger1 = !NumExplod



;========================<RECOVER FX>=============================
[StateDef 8200]
type = A
velSet = 0,0
anim = 8200
sprPriority = 5

[State 8200, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8200, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.017 * Time), 0.25 + (0.017 * Time)
ignoreHitPause = 1

[State 8200, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = ceil(256 - 17.1 * Time), 256
ignoreHitPause = 1

[State 8200, End]
type = DestroySelf
trigger1 = Time >= 15



;========================<COUNTER FX>=============================
[StateDef 8290]
type = A
physics = N
velSet = 0,0
anim = 1

[State 8290, "Counter!" Text Explod]
type = Explod
trigger1 = !NumExplod(8290)
anim = 8290
ID = 8290
sprPriority = 64
posType = P1
facing = Facing
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8290, Scale]
type = ModifyExplod
trigger1 = Time < 8
ID = 8290
scale = 0.5, .5
trans = AddAlpha
alpha = 256,0

[State 8290, Scale]
type = ModifyExplod
trigger1 = Time >= 8
ID = 8290
scale = 0.5 + 0.0625 * (Time - 8), 0.5 + 0.0625 * (Time - 8)
trans = AddAlpha
alpha = 256 - 32 * (Time - 8), 32 * (Time - 8)

[State 8290, Safety]
type = RemoveExplod
trigger1 = Time >= 16

[State 8290, End]
type = DestroySelf
trigger1 = Time >= 16



;==================<POWER CHARGE FX>==================
;Aura and Dust
[StateDef 8330]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velset = 0,0

[State 8330, BindToRoot]
type = BindToRoot
trigger1 = (Root, StateNo = 730)
pos = 0,0

[State 8330, Charging Sound]
type = PlaySnd
trigger1 = !Time
value = 730,0
channel = 0

[State 8330, Power Charge Aura]
type = Explod
trigger1 = !NumExplod(8330)
ID = 8330
anim = 8330
sprPriority = 3
posType = P1
bindTime = -1
removeTime = -1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8330, Power Charge Dust]
type = Explod
trigger1 = !(Time % 6)
anim = 8105
sprPriority = -3
posType = P1
pos = 0, -ceil(pos y)
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8330, Modify Aura 1]
type = ModifyExplod
trigger1 = Numexplod(8330) && Root, Power < 3000
ID = 8330
scale = 0.5, 0.1 + 0.4 * (Root, Power / 3000.0)

[State 8330, Modify Aura 2]
type = ModifyExplod
trigger1 = NumExplod(8330) && Root, Power >= 3000
ID = 8330
scale = 0.5, 0.5

[State 8330, StopSnd]
type = StopSnd
trigger1 = Root, StateNo != 730
channel = 0

[State 8330, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 730

[State 8330, End]
type = DestroySelf
trigger1 = Root, StateNo != 730


;Particles
[StateDef 8331]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8331, BindToRoot]
type = BindToRoot
trigger1 = !(Time % 8)
pos = ceil(-151 + (Random / 3.125)), ceil(98 - (Random / 3.125))

[State 8331, Particle]
type = Explod
trigger1 = (Time % 8) = 1
anim = 8331
sprPriority = ifElse(Random < 750, 5, -1)
posType = P1
vel = ((RootDist x + 10) / 32.0), ((RootDist y - 30) / 32.0)
scale = ifElse(Random < 500, 0.5, -0.5), ifElse(Random < 500, 0.5, -0.5)
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8331, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 730

[State 8331, End]
type = DestroySelf
trigger1 = Root, StateNo != 730


;==================<VIOLENT WIN VS VEGA PARTICLES>==================
[StateDef 8332]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8332, BindToRoot]
type = BindToRoot
trigger1 = !(Time % 4)
pos = ceil(-40 + (Random /10.25)), ceil(-17 - (Random / 10.25))

[State 8332, Particles]
type = Explod
trigger1 = (Time % 4) = 1
anim = 8332
sprPriority = ifElse(Random < 750,5,-1)
posType = P1
vel = (-(RootDist x + 4) / 10.0),(-(RootDist y - 85) / 10.0)
scale = ifElse(random < 500 ,0.5, -0.5),ifElse(random < 500, 0.5, -0.5)
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8332, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 187 || Root, AnimElemTime(60) >= 0

[State 833, End]
type = DestroySelf
trigger1 = Root, StateNo != 187 || Root, AnimElemTime(60) >= 0



;==================<ZERO COUNTER FX>==================
[StateDef 8350]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8350, bgPalFX]
type = bgPalFX
trigger1 = 1
time = 1
color = 16 * Time
mul = 16 * Time, 16 * Time, 16 * Time

[State 8350, Circle Explod]
type = Explod
trigger1 = !Time
anim = 8350
ID = 1
sprPriority = 3
posType = P1
removeTime = 16
superMoveTime = -1
ownPal = 1

[State 8350, Scale]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = (0.0625 * Time), (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8350, Lightning Explod]
type = Explod
trigger1 = !Time
anim = 8351
ID = 2
sprPriority = -2
posType = P1
pos = 0, -ceil(pos y)
superMoveTime = -1
ownPal = 1

[State 8350, End]
type = DestroySelf
trigger1 = Time >= 16



;========================<CUSTOM COMBO>=============================
[StateDef 8400]
type = A
physics = N
moveType = I
anim = 8400
ctrl = 0
velSet = 0,0
sprPriority = 5

[State 8400, NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8400, BGpalFX]
type = BGpalFX
trigger1 = Time < 25
time = 1
mul = 128,128,128

[State 8400, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8400, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8400, Scale]
type = AngleDraw
trigger1 = Time < 8
scale = (0.0625 * Time), (0.0625 * Time)
ignoreHitPause = 1

[State 8400, Scale]
type = AngleDraw
trigger1 = Time >= 8
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8400, Transparency]
type = Trans
trigger1 = Time < 16
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8400, Transparency]
type = Trans
trigger1 = Time >= 16
trans = AddAlpha
alpha = ceil(256 - 25.6 * (Time - 16)), 256
ignoreHitPause = 1

[State 8400, Lines Explod]
type = Explod
trigger1 = !Time
anim = 8401
ID = 1
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8400, Scale Lines Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 2 - (0.125 * Time), 2 - (0.125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8400, Circle Explod]
type = Explod
trigger1 = Time = 16
anim = 8402
ID = 2
sprPriority = 5
posType = P1
removeTime = 32
superMoveTime = -1

[State 8400, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = (0.1 * (Time - 16)), (0.1 * (Time - 16))
trans = AddAlpha
alpha = ceil(256 - 25.6 * (Time - 16)), 256

[State 8400, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 26

[State 8400, End]
type = DestroySelf
trigger1 = Time >= 26



;========================<SUPER PAUSE FX>=============================
;Level 1 Super FX
[StateDef 8500]
type = A
velSet = 0,0
anim = 8500
sprPriority = 5

[State 8500, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8500, BGpalFX]
type = BGpalFX
trigger1 = Time < 39
time = 1
color = 0
mul = 0,0,256

[State 8500, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8500, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8500, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8500, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5,0.5
ignoreHitPause = 1

[State 8500, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8500, Lines Explod]
type = Explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8501
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8500, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8500, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1 - (0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8500, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8500, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 - (0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8500, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8502
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 32
superMoveTime = -1

[State 8500, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8500, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8500, End]
type = DestroySelf
trigger1 = Time >= 40


;Level 2 Super FX
[StateDef 8510]
type = A
velSet = 0,0
anim = 8510
sprPriority = 5

[State 8510, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8510, BGpalFX]
type = BGpalFX
trigger1 = Time < 39
time = 1
color = 0
mul = 192,0,256

[State 8510, Rotate]
type = AngleSet
trigger1 = !Time
value =6 * (Random % 60)

[State 8510, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8510, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8510, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8510, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8510, Lines Explod]
type = Explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8511
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8510, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8510, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1 - (0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8510, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8510, Scale Lines Explod 4]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 -(0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8510, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8512
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500,-1,1)
vFacing = ifElse(Random < 500,-1,1)
removeTime = 32
superMoveTime = -1

[State 8510, Scale]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24)<4, 64 * (Time - 24), 256), 256

[State 8510, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8510, End]
type = DestroySelf
trigger1 = Time >= 40


;Level 3 Super FX
[StateDef 8520]
type = A
velset = 0,0
anim = 8520
sprPriority = 5

[State 8520, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8520, Assert: NoBarDisplay, NoBG, NoFG]
type = AssertSpecial
trigger1 = Time < 40
flag = NoBarDisplay
flag2 = NoBG
flag3 = NoFG

[State 8520, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8520, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8520, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8520, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8520, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8520, Portrait 1]
type = Explod
trigger1 = !Time
anim = 8525
ID = 20
sprPriority = -16
posType = Back
removeTime = 40
superMoveTime = -1

[State 8520, Portrait 2]
type = Explod
trigger1 = !Time
anim = 8525
ID = 21
sprPriority = -16
posType = Back
removeTime = 40
superMoveTime = -1

[State 8520, Scale Portrait 1a]
type = ModifyExplod
trigger1 = NumExplod(20) && Time < 16
ID = 20
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 1 - (0.03125 * Time), 1 - (0.03125 * Time)
trans = AddAlpha
alpha = (8 * Time), 256

[State 8520, Scale Portrait 2a]
type = ModifyExplod
trigger1 = NumExplod(21) && Time < 16
ID = 21
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 2 - (0.09375 * Time), 2 - (0.09375 * Time)
trans = AddAlpha
alpha = (8 * Time), 256

[State 8520, Scale Portrait 1b]
type = ModifyExplod
trigger1 = NumExplod(20) && (Time = [16,32])
ID = 20
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 256, 256

[State 8520, Scale Portrait 2b]
type = ModifyExplod
trigger1 = NumExplod(21) && (Time = [16,32])
ID = 21
scale = 0,0

[State 8520, Scale Portrait 1c]
type = ModifyExplod
trigger1 = NumExplod(20) && Time >= 32
ID = 20
posType = Back
pos = 160 + (8 * (Time - 32)), floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 128 - 16 * (Time - 32), 256

[State 8520, Scale Portrait 2c]
type = ModifyExplod
trigger1 = NumExplod(21) && Time >= 32
ID = 21
posType = Back
pos = 160 - (8 * (Time - 32)), floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 128 - 16 * (Time - 32), 256

[State 8520, Lines Explod]
type = explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8521
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8520, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8520, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1-(0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8520, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8520, Scale Lines Explod 4]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 - (0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8520, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8522
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1 ,1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 32
superMoveTime = -1

[State 8520, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8520, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8520, End]
type = DestroySelf
trigger1 = Time >= 40



;========================<SUPER FINISH>=============================
[StateDef 8600]
type = A
velSet = 0,0
anim = 1

[State 8600, Super Finish Sound]
type = PlaySnd
trigger1 = !Time
value = 8600,0
channel = 0

[State 8600, SndPan]
type = SndPan
trigger1 = Time <= 80
channel = 1
absPan = ceil(sin(GameTime / 20.0 * pi) * 160)

[State 8600, BG PalFX]
type = BGpalFX
trigger1 = Time < 16
time = 1
mul = 0, 0, 0

[State 8600, BG PalFX]
type = BGpalFX
trigger1 = Time = [16,24)
time = 1
mul = 32 * (Time - 16), 32 * (Time - 16), 32 * (Time - 16)

[State 8600, Move Name: Custom Combo]
type = VarSet
trigger1= !Time && Root, var(23) = 900
var(0) = 1

[State 8600, Move Name: Somersault Strike]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3000,3099])
var(0) = 2

[State 8600, Move Name: Total Wipeout]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3100,3199])
var(0) = 3

[State 8600, Move Name: Sonic Hurricane]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3200,3299])
var(0) = 4

[State 8600, Move Name: Opening Gambit]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3300,3399])
var(0) = 5

[State 8600, Super Finish Explod]
type = Explod
trigger1 = !Time
anim = 8600
ID = 8600
ontop = 1
postype = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Super Finish Explod Fade]
type = ModifyExplod
trigger1 = NumExplod(8600)
ID = 8600
trans = AddAlpha
alpha = ifElse(Time < 16, 256, 256 - 32 * (Time - 16)), 256

[State 8600, Text 1]
type = Explod
trigger1 = !Time && var(0)
anim = 8610 + var(0)
ID = 10
onTop = 1
posType = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Text 2]
type = Explod
trigger1 = !Time && var(0)
anim = 8610 + var(0)
ID = 11
onTop = 1
posType = left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Text 1 Fade]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
trans = AddAlpha
alpha = ifElse(Time < 16, 256, 256 - 32 * (Time - 16)), ifElse(Time < 16, 0, 32 * (Time - 16))

[State 8600, Text 2 Fade]
type = ModifyExplod
trigger1 = NumExplod(11)
ID = 11
scale = 0.5 + (0.0625 * Time), 0.5 + (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (32 * Time), 32 * Time

[State 8600, Circle Explod]
type = Explod
trigger1 = !Time
anim = 8601
ID = 8601
under = 1
posType = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
bindTime = -1
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Circle Fade]
type = ModifyExplod
trigger1 = NumExplod(8601)
ID = 8601
scale = (0.25 * Time) * (1.3333333 * GameHeight / GameWidth), (0.25 * Time) * (1.3333333 * GameHeight / GameWidth)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8600, Assert: NoFG]
type = AssertSpecial
trigger1 = Time < 16
flag = NoFG

[State 8600, Assert: NoBarDisplay]
type = AssertSpecial
trigger1 = Time < 24
flag = NoBarDisplay

[State 8600, RemoveExplod]
type = RemoveExplod
trigger1 = Time >= 24
trigger2 = RoundState < 3

[State 8600, End]
type = DestroySelf
trigger1 = RoundState < 3



;========================<CAMERA CONTROL>=============================
[StateDef 8999]
type = S
velSet = 0,0
anim = 1

[State 8999, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
moveCamera = 1,1
ignoreHitPause = 1

[State 8999, End]
type = DestroySelf
trigger1 = RoundState = 2
