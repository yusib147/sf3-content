; _________________________________________
;| Felicia by varo_hades                   |
; �����������������������������������������
;==============================================================================================
;========================================<SPECIAL MOVES>=======================================
;==============================================================================================

;=====================<ROLLING BUCLER>==========================
[StateDef 1000]
type = S
physics = N
moveType = I
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 10'0, Width]
type = Width
trigger1 = Anim = 1005
value = -3,-3

[State 1000, PlaySnd]
type = PlaySnd
trigger1 = Time = 5
value = S1000,0

[State 1000, 1]
type = ChangeAnim
triggerall = Anim = 1000
trigger1 = AnimTime = 0
value = 1005

[State 1000, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 1005 && (!(P2StateType = A && P2MoveType != A) || Var(20))
movetype = A

[State 1000, StateTypeSet]
type = StateTypeSet
triggerall = !Var(20)
trigger1 = Anim = 1005 && P2StateType = A && P2MoveType != A
trigger2 = Anim != 1005
movetype = I

[State 1000, 2]
type = VelSet
trigger1 = Anim = 1005 && AnimElemTime(1) >= 0
x = (Vel X)+(1*Const(size.Xscale))
persistent = 1

[State 1000, VelSet]
type = VelSet
triggerall = Anim = 1005
trigger1 = Vel X >= 9+(Var(10)*2)
x = 9+(Var(10)*2)*Const(size.Xscale)

[State 1000, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = !MoveContact
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 63 < 7, 7, fvar(11) * 63)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.52
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
air.fall = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, ChangeState]
type = ChangeState
triggerall = Time > 1
trigger1 = MoveContact = 1
value = 1406

[State 1000, ChangeState]
type = ChangeState
trigger1 = Time = ifElse(!Var(10),28,29)
value = 1305

[State 1000, Dust Helper]
type = Helper
trigger1 = Time = 5
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000, ChangeState]
type = ChangeState
triggerall = Anim = 1005
trigger1 = command = "a" || command = "b" || command = "c"
value = 1035
ignorehitpause = 1
ctrl = 0

[State 1000, ChangeState]
type = ChangeState
triggerall = Anim = 1005
trigger1 = command = "z"
value = 1015
ignorehitpause = 1
ctrl = 0

[State 1000, ChangeState]
type = ChangeState
triggerall = Anim = 1005
trigger1 = command = "y"
value = 1010
ignorehitpause = 1
ctrl = 0

[State 1000, ChangeState]
type = ChangeState
triggerall = Anim = 1005
trigger1 = command = "x"
value = 1025
ignorehitpause = 1
ctrl = 0

;Rolling Uppercut (Medium)
[Statedef 1010]
type = A
movetype = A
physics = S
ctrl = 0
anim = 1015
sprpriority = 2
velset = 0,0
poweradd = 72 * !var(20)
juggle = 0

[State 1010, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 2
value = S4,2
persistent = 0

[State 1010, VelSet]
type = VelSet
trigger1 = Anim = 1015 && AnimElem = 2
x = 6*(5.0/4.0)*Const(Size.XScale)
y = -8*(5.0/4.0)*Const(Size.YScale)

[State 1010, VelAdd]
type = VelAdd
trigger1 = Anim = 1015 && AnimElemTime(2) > 0 || Anim = 1016
x = ifElse(Vel X <= 0,0,-0.34375*(25.0/16.0))*Const(Size.XScale)
y = .5*(25.0/16.0)*Const(Size.YScale)

[State 1010, VelSet]
type = VelSet
trigger1 = Time > 3 && Vel X <= 0
x = 0

[State 1010, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2 || AnimElem = 3
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, -12.3125*(5.0/4.0)
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -12.3125*(5.0/4.0)
air.cornerPush.velOff = 0
yAccel = .6875*(25.0/16.0)
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -42
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1010, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 2 || var(20))
trigger1 = AnimElem = 4
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -4.921875
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -4, -4.921875
air.cornerPush.velOff = 0
yAccel = 0.46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1010, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 5
movetype = I

[State 1010, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 1015 && AnimTime = 0
value = 1016

[State 1010, ChangeState]
type = ChangeState
triggerall = Anim = 1016
trigger1 = Pos Y + Vel Y >= 0
value = 1305;50

;Rolling Uppercut (Heavy)
[Statedef 1015]
type = A
movetype = A
physics = S
ctrl = 0
anim = 1025
sprpriority = 2
velset = 0,0
poweradd = 72 * !var(20)
juggle = 0

[State 1015, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 2
value = S4,2
persistent = 0

[State 1015, VelSet]
type = VelSet
trigger1 = Anim = 1025 && AnimElem = 2
x = 7.5*(5.0/4.0)*Const(Size.XScale)
y = -10*(5.0/4.0)*Const(Size.YScale)

[State 1015, VelAdd]
type = VelAdd
trigger1 = Anim = 1025 && AnimElemTime(2) > 0 || Anim = 1016
x = ifElse(Vel X <= 0,0,-0.34375*(25.0/16.0))*Const(Size.XScale)
y = .5*(25.0/16.0)*Const(Size.YScale)

[State 1015, VelSet]
type = VelSet
trigger1 = Time > 3 && Vel X <= 0
x = 0

[State 1015, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2 || AnimElem = 3
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, -12.3125*(5.0/4.0)
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -12.3125*(5.0/4.0)
air.cornerPush.velOff = 0
yAccel = .6875*(25.0/16.0)
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -42
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1010, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 2 || var(20))
trigger1 = AnimElem = 4
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -4.921875
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -4, -4.921875
air.cornerPush.velOff = 0
yAccel = 0.46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1015, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 5
movetype = I

[State 1015, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 1025 && AnimTime = 0
value = 1016

[State 1015, ChangeState]
type = ChangeState
triggerall = Anim = 1016
trigger1 = Pos Y + Vel Y >= 0
value = 1305;50

;Neko Punch
[Statedef 1025]
type = S
movetype = A
physics = N;S
ctrl = 0
anim = 1035
sprpriority = 2
poweradd = 72 * !var(20)
juggle = 0

[State 1025, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = S1000,1
persistent = 0

[State 1025, VelSet]
type = VelSet
trigger1 = !Time
x = 5.125

[State 1025, VelAdd]
type = VelAdd
trigger1 = Time
x = ifElse(Vel X <= 0,0,-0.25)

[State 1025, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 4
movetype = I

[State 1025, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 41 < 7, 7, fvar(11) * 41)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -42
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1025, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Sliding Kick
[Statedef 1035]
type = S
movetype = A
physics = N;S
ctrl = 0
anim = 1045
sprpriority = 2
poweradd = 72 * !var(20)
juggle = 0

[State 1035, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = S101,0
persistent = 0

[State 1035, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 3
value = S1,5
channel = 1

[State 1035, VelSet]
type = VelSet
trigger1 = !Time
x = 5.125

[State 1035, VelAdd]
type = VelAdd
trigger1 = Time
x = ifElse(Vel X <= 0,0,-0.25)

[State 1035, VelSet]
type = VelSet
trigger1 = Time && Vel X <=0
x = 0

[State 1035, Dust]
type = Helper
trigger1 = AnimElemTime(2) = 0
helpertype = normal
stateno = 8103
ID = 8100
name = "Dash Dust"
postype = p1
pausemovetime = 255
supermovetime = 255
ownpal = 1

[State 1035, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 5
movetype = I

[State 1035, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
trigger2 = AnimElem = 4
attr = S, SA
hitFlag = MAF
guardFlag = L
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1035, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<EX ROLLING BUCLER>=============================
[StateDef 1030]
type = S
physics = N
moveType = I
anim = 1030
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(-32 * const(size.xScale)), ceil(-67 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, VarSet]
type = VarSet
trigger1 = !Time
var(53) = 0

[State 1030, VarSet]
type = VarSet
trigger1 = Time = 0
var(11) = 29

[State 1030, VarSet]
type = VarAdd
trigger1 = Time > 0
trigger1 = var(11)
var(11) = -1
ignorehitpause = 0

[State 1030, Width]
type = Width
trigger1 = Anim = 1005
value = -3,-3

[State 1030, PlaySnd]
type = PlaySnd
trigger1 = Time = 5
value = S1000,0

[State 1030, 1]
type = ChangeAnim
triggerall = Anim = 1030
trigger1 = AnimTime = 0
value = 1005

[State 1030, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 1005
movetype = A

[State 1030, 2]
type = VelAdd
trigger1 = Anim = 1005 && AnimElemTime(1) >= 0
x = 1.5*Const(Size.XScale)*(5.0/4.0)
persistent = 1

[State 1030, VelSet]
type = VelSet
triggerall = Anim = 1005
trigger1 = Vel X >= 15.5*Const(Size.XScale)*(5.0/4.0)
x = 15.5*Const(Size.XScale)*(5.0/4.0)

[State 1030, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = Var(53) < 3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 22 < 7, 7, fvar(11) * 22)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.49
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yaccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1030, VarAdd]
type = VarAdd
trigger1 = MoveContact = 1 || MoveReversed = 1
var(53) = 1

[State 1030, ChangeState]
type = ChangeState
triggerall = MoveContact = 1 || MoveReversed = 1
trigger1 = Var(53) > 3
trigger2 = !Enemy, Alive
value = 1406

[State 1030, ChangeState]
type = ChangeState
trigger1 = Time && !var(11)
value = 1305

[State 1030, ChangeState]
type = ChangeState
triggerall = Anim = 1005
trigger1 = command = "a" || command = "b" || command = "c"
value = 1060
ignorehitpause = 1
ctrl = 0

[State 1030, ChangeState]
type = ChangeState
triggerall = Anim = 1005
trigger1 = command = "y" || command = "z"
value = 1040
ignorehitpause = 1
ctrl = 0

[State 1030, ChangeState]
type = ChangeState
triggerall = Anim = 1005
trigger1 = command = "x"
value = 1050
ignorehitpause = 1
ctrl = 0

;EX Rolling Uppercut
[Statedef 1040]
type = A
movetype = A
physics = N
ctrl = 0
anim = 1040
sprpriority = 2
velset = 0,0
poweradd = 0
juggle = 0

[State 1040, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1040 && AnimElemTime(2) = 0
value = S1000,2
persistent = 0

[State 1040, VelSet]
type = VelSet
trigger1 = Anim = 1040 && AnimElemTime(2) = 0
x = 9*Const(Size.XScale)*(5.0/4.0)
y = -12*Const(Size.YScale)*(5.0/4.0)

[State 1040, VelAdd]
type = VelAdd
trigger1 = Time > 2
x = ifElse(Vel X <= 0,0,-0.34375)*Const(Size.XScale)*(25.0/16.0)
y = .5*Const(Size.YScale)*(25.0/16.0)

[State 1040, VelSet]
type = VelSet
trigger1 = Time > 3 && Vel X <= 0
x = 0

[State 1040, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 2 || var(20))
trigger1 = AnimElem = 2
trigger2 = AnimElem = 3
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 15 < 7, 7, fvar(11) * 15)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, -12.3125*(5.0/4.0)
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -12.3125*(5.0/4.0)
air.cornerPush.velOff = 0
yAccel = .6875*(25.0/16.0)
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -42
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1040, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 4
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -4.921875*(5.0/4.0)
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -4, -4.921875
air.cornerPush.velOff = 0
yAccel = 0.46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1040, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 5
movetype = I

[State 1040, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 1040 && AnimTime = 0
value = 1016

[State 1005, ChangeState]
type = ChangeState
triggerall = Anim = 1016
trigger1 = Pos Y + Vel Y >= 0
value = 1305;50

;EX Neko Punch
[Statedef 1050]
type = S
movetype = A
physics = N
ctrl = 0
anim = 1050
sprpriority = 2
poweradd = 0
juggle = 0

[State 1050, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 3
value = S1000,1
channel = 0

[State 1050, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 3 || AnimElem = 9
value = S1,2
channel = 1

[State 1050, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(11) = 0
value = S40,0
channel=1

[State 1050, VelSet]
type = VelSet
trigger1 = !Time
x = 7.25*Const(Size.XScale)*(5.0/4.0)

[State 1050, VelAdd]
type = VelAdd
trigger1 = Time > 1
x = ifElse(Vel X <= 0,0,-0.25)*Const(Size.XScale)*(25.0/16.0)

[State 1050, VelSet]
type = VelSet
trigger1 = Time > 0 && Vel X <=0
x = 0

[State 1050, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 10
movetype = I

[State 1050, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 21 < 7, 7, fvar(11) * 21)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -42
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1050, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 9
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1050, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;EX Sliding Kick
[Statedef 1060]
type = S
movetype = A
physics = N
ctrl = 0
anim = 1060
sprpriority = 2
poweradd = 0
juggle = 0

[State 1060, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = S101,0
persistent = 0

[State 1060, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 3
value = S1,5
channel = 1

[State 1060, VelSet]
type = VelSet
trigger1 = !Time
x = 4.125*Const(Size.XScale)*(5.0/4.0)

[State 1060, VelAdd]
type = VelAdd
trigger1 = Time > 1
x = ifElse(Vel X <= 0,0,-0.25)*Const(Size.XScale)*(25.0/16.0)

[State 1060, VelSet]
type = VelSet
trigger1 = Time > 0 && Vel X <=0
x = 0

[State 1060, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 5
movetype = I

[State 1060, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 2 || var(20))
trigger1 = AnimElem = 3
trigger2 = AnimElem = 4
attr = S, SA
hitFlag = MAF
guardFlag = L
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 49 < 7, 7, fvar(11) * 49)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Trip
air.type = Trip
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yaccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1035, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<SAND SPLASH>=============================
[StateDef 1100]
type = S
physics = S
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "c" || command = "rlsc"), 2, ifElse((command = "b" || command = "rlsb"), 1, 0))

[State 1100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1100, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1120, ifElse(var(10) = 1, 1110, 1100))

[State 1100, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(4) = 0
value = S1100,0

[State 1100, Helper]
type = Helper
trigger1 = AnimElemTime(4) = 0
helpertype = Normal
name = "Sand"
ID = 1105
stateno = 1105
pos = ceil(28*Const(Size.Xscale)),0
postype = p1
facing = 1
keyctrl = 0
ownpal = 1
size.xscale = 0.5*Const(Size.YScale)
size.yscale = 0.5*Const(Size.YScale)
persistent = 0

[State 1100, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<EX SAND SPLASHK>=============================
[StateDef 1130]
type = S
physics = N
moveType = A
anim = 1130
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1130, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1130, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1130, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 111

[State 1130, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(4 * const(size.xScale)), ceil(-51 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1130, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1130, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(4) = 0
value = S181,0
channel = 0

[State 1130, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(4) = 0
value = S1100,0

[State 1130, Helper]
type = Helper
trigger1 = AnimElemTime(4) = 0
helpertype = Normal
name = "Sand"
ID = 1105
stateno = 1135
pos = ceil(28*Const(Size.Xscale)),0
postype = p1
facing = 1
keyctrl = 0
ownpal = 1
size.XScale = 0.5*Const(size.XScale)
size.yscale = 0.5*Const(size.yscale)
persistent = 0

[State 1130, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<LP CAT SPIKE>==========================
[StateDef 1200]
type = S
physics = N
moveType = A
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1200, VarSet]
type = VarSet
trigger1 = Time = 0
var(10) = 0

[State 1200, Ball]
type = Helper
trigger1 = !Time
ID = 8411
stateno = 1205
pos = (Ceil((Const(size.xscale))*8)),(Ceil((Const(size.yscale))*-30))
postype = p1
size.xscale = (Const(size.xscale))
size.yscale = (Const(size.yscale))
ownpal = 1

[State 1200, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 6
value = S1200,0
channel = 5

[State 1200, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 8
movetype = I

[State 1200, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5 || AnimElem = 6 || AnimElem = 7
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 112 < 7, 7, fvar(11) * 112)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.52
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -49
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0
ID = 1200

[State 1200, VelSet]
type = PosAdd
trigger1 = AnimElemTime(5) = 0
x = 32*Const(Size.XScale)

[State 1200, VelSet]
type = PosAdd
trigger1 = AnimElemTime(13) = 0
x = 24*Const(Size.XScale)

[State 1200, VelSet]
type = VelSet
trigger1 = AnimElemTime(7) = 0
x = 4*(5.0/4.0)

[State 1200, VelSet]
type = VelAdd
trigger1 = AnimElemTime(7) > 0
x = -.03125*Const(Size.XScale)

[State 1200, VelSet]
type = VelSet
trigger1 = AnimElemTime(12) = 0
x = 0

[State 1200, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<MP CAT SPIKE>==========================
[StateDef 1210]
type = S
physics = N
moveType = A
anim = 1210
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1210, VarSet]
type = VarSet
trigger1 = Time = 0
var(10) = 1

[State 1210, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElemTime(4) = 1
statetype = A

[State 1210, VelSet]
type = VelSet
trigger1 = AnimElemTime(4) = 1
x = 4.5*(5.0/4.0)*Const(Size.XScale)
y = -3*(5.0/4.0)*Const(Size.YScale)

[State 1210, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(4) > 1
x = ifElse(Vel X <= 0, 0, -0.0078125)*(25.0/16.0)*Const(Size.XScale)
y = 0.25*(25.0/16.0)*Const(Size.YScale)

[State 1210, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(4) = 0
value = S41,0
channel = 13

[State 1210, Dust]
type = Helper
trigger1 = AnimElemTime(4) = 1
helpertype = normal
stateno = 8100
ID = 8100
name = "Jump Dust"
postype = P1
ownpal = 1

[State 1210, Ball]
type = Helper;Explod
trigger1 = !Time
stateno = 1205
ID = 84112
pos = ceil(Const(Size.XScale)*8),ceil(Const(Size.YScale)*-32)
postype = p1
size.xscale = Const(Size.XScale)
size.yscale = Const(Size.YScale)
ownpal = 1

[State 1210, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElemTime(9) >= 0
trigger2 = MoveContact
ID = 8411

[State 1210, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 9
value = S1200,0
channel = 5

[State 1210, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 11
movetype = I

[State 1210, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 9 || AnimElem = 10
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 122 < 7, 7, fvar(11) * 122)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.52
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -49
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0
ID = 3

[State 1210, ChangeState]
type = ChangeState
triggerall = AnimElemTime(4) > 1
trigger1 = Pos Y + Vel Y >= 0
value = 1305

;=====================<HP CAT SPIKE>==========================
[StateDef 1220]
type = S
physics = N
moveType = A
anim = 1220
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1220, VarSet]
type = VarSet
trigger1 = Time = 0
var(10) = 2

[State 1220, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElemTime(4) = 0
statetype = A

[State 1220, VelSet]
type = VelSet
trigger1 = AnimElemTime(4) = 0
x = 7.5*(5.0/4.0)*Const(Size.XScale)
y = -4*(5.0/4.0)*Const(Size.YScale)

[State 1220, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(4) > 0
x = ifElse(Vel X <= 0, 0, -0.03125)*(25.0/16.0)*Const(Size.XScale)
y = 0.25*(25.0/16.0)*Const(Size.YScale)

[State 1220, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(4) = 0
value = S41,0
channel = 13

[State 1220, Dust]
type = Helper
trigger1 = AnimElemTime(4) = 1
helpertype = normal
stateno = 8100
ID = 8100
name = "Jump Dust"
postype = P1
ownpal = 1

[State 1220, Ball]
type = Helper
trigger1 = !Time
stateno = 1205
ID = 84113
pos = ceil(Const(Size.XScale)*8),ceil(Const(Size.YScale)*-32)
postype = p1
size.xscale = (Const(size.xscale))
size.yscale = (Const(size.yscale))
ownpal = 1

[State 1220, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 9
value = S1200,0
channel = 5

[State 1220, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 11
movetype = I

[State 1220, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 9 || AnimElem = 10
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 132 < 7, 7, fvar(11) * 132)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.52
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -49
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0
ID = 3

[State 1220, ChangeState]
type = ChangeState
triggerall = AnimElemTime(4) > 1
trigger1 = Pos Y + Vel Y >= 0
value = 1305

;========================<EX CAT SPIKE>=============================
[StateDef 1230]
type = S
physics = N
moveType = A
anim = 1230
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1230, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1230, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1230, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1230, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1230, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(Const(Size.XScale)*8),ceil(Const(Size.YScale)*-32)
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1230, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1230, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElemTime(4) = 0
statetype = A

[State 1230, VelSet]
type = VelSet
trigger1 = AnimElemTime(4) = 0
x = 1*(5.0/4.0)*Const(Size.XScale)
y = -7*(5.0/4.0)*Const(Size.YScale)

[State 1230, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(4) > 0
y = .25*(25.0/16.0)*Const(Size.YScale)

[State 1230, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(4) = 0
value = S41,0
channel = 13

[State 1230, Dust]
type = Helper
trigger1 = AnimElemTime(4) = 0
helpertype = normal
stateno = 8100
ID = 8100
name = "Jump Dust"
postype = P1
ownpal = 1

[State 1230, Ball]
type = Helper
trigger1 = !Time
stateno = 1205
ID = 1250
pos = ceil(Const(Size.XScale)*8),ceil(Const(Size.YScale)*-32)
postype = p1
size.xscale = Const(Size.XScale)
size.yscale = Const(Size.YScale)
ownpal = 1

[State 1230, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(7) = 0
value = S1000,1
channel = 0

[State 1230, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 16
movetype = I

[State 1230, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 15
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 91 < 7, 7, fvar(11) * 91)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.52
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -49
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0

[State 1230, ChangeState]
type = ChangeState
triggerall = AnimElemTime(4) > 1
trigger1 = Pos Y + Vel Y >= 0
value = 1305

;=====================<DELTA KICK>==========================
[StateDef 1300]
type = S
movetype = A
physics = S
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1300, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1300, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1300, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = 1300+10*(Var(10)>0)

[State 1300, VelSet]
type = VelSet
triggerall = Anim = 1300 || Anim = 1310
trigger1 = AnimElemTime(3) = 0
y = -ifElse(Var(10)=2,11.5,8+Var(10))*Const(Size.YScale)*(5.0/4.0)

[State 1300, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElemTime(3) = 0
statetype = A
physics = N

[State 1300, VelAdd]
type = VelAdd
triggerall = AnimElemTime(3) > 1
trigger1 = !Var(10) && (Vel Y < 3.5)
trigger2 = Var(10)=1 && (Vel Y < 3)
trigger3 = Var(10)=2 && (Vel Y < 4.5)
y = .5625*(25.0/16.0);.8

[State 1300, PlaySnd]
type = PlaySnd
trigger1 = Anim != 1301 && (AnimElem = 3 || AnimElem = 11)
trigger2 = Anim = 1301 && AnimElem = 2
value = S1,5
channel = 1

[State 1300, Dust]
type = Helper
trigger1 = AnimElemTime(3) = 0
helpertype = normal
stateno = 8100
ID = 8100
name = "Jump Dust"
postype = P1
ownpal = 1

[State 1300, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim != 1301
trigger1 = AnimElem = 3
trigger2 = AnimElem = 4
trigger3 = AnimElem = 5
trigger4 = AnimElem = 6
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0

[State 1300, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim != 1301
trigger1 = AnimElem = 9
trigger2 = AnimElem = 10
trigger3 = AnimElem = 11
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0
ID = 1300

[State 1300, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1301
trigger1 = AnimElem = 2
trigger2 = AnimElem = 3
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0

[State 1300, PlaySnd]
type = PlaySnd
triggerall = Anim != 1301
trigger1 = AnimElem = 10
value = S860,0
channel = 0

[State 1300, VelSet]
type = VelSet
trigger1 = Anim != 1301 && AnimElemTime(9) = 0
x = (3.5+(Var(10)*.5))*Const(Size.XScale)*(5.0/4.0)
y = (1.75+(Var(10)*.25))*Const(Size.YScale)*(5.0/4.0)

[State 1300, 3]
type = VelAdd
trigger1 = Anim != 1301 && AnimElemTime(9) > 0
trigger2 = Anim = 1301
x = (.34765625+(Var(10)*.05078125))*Const(Size.XScale)*(5.0/4.0)

[State 1300, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 1301 && AnimElemTime(11) > 0 && NumTarget(1300)
value = 1301

[State 1300, ChangeState]
type = ChangeState
triggerall = AnimElemTime(3) > 0
trigger1 = Vel Y + Pos Y >= 0
value = 1305

;Custom Land State
[Statedef 1305]
type = S
physics = S
ctrl = 0
anim = 47
velset = 0,0

[State 1305, 2]
type = PosSet
trigger1 = Time = 0
y = 0

[State 1305, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0

[State 1305, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1305, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<EX DELTA KICK>=============================
[StateDef 1330]
type = S
physics = N
moveType = A
anim = 1330
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1330, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1330, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1330, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1330, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1330, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(-10 * const(size.xScale)), ceil(-57 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1330, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1330, VelSet]
type = VelSet
triggerall = Anim = 1330
trigger1 = AnimElemTime(3) = 0
x = 0
y = -14*(5.0/4.0)

[State 1330, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 1330
trigger1 = AnimElemTime(3) = 0
statetype = A
physics = N

[State 1330, VelAdd]
type = VelAdd
triggerall = Anim = 1330
trigger1 = AnimElemTime(3) > 0 && AnimElemTime(9) < 0
y = 0.96875*(25.0/16.0)

[State 1330, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
triggerall = Anim = 1330
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(9) < 0
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 84 < 7, 7, fvar(11) * 84)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0

[State 1330, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
triggerall = Anim = 1330
trigger1 = AnimElemTime(11) >= 0
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 0

[State 1330, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
triggerall = Anim = 1331
trigger1 = AnimElem = 2
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1330, HitDef 4]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
triggerall = Anim = 1331
trigger1 = AnimElem = 6 || AnimElem = 10
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1330, HitDef 5]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1331
trigger1 = AnimElem = 4 || AnimElem = 8
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 14 < 7, 7, fvar(11) * 14)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1330, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1330
trigger1 = AnimElemTime(10) = 0
value = S1300,0

[State 1330, VelSet]
type = VelSet
trigger1 = Anim = 1330 && AnimElemTime(9) = 0
x = 4*(5.0/4.0)
y = 1.875*(5.0/4.0)

[State 1330, 3]
type = VelAdd
trigger1 = Anim = 1330 && AnimElemTime(9) > 0 || Anim = 1331
x = 0.44921875*(25.0/16.0)

[State 1330,4]
type = VelAdd
trigger1 = Anim = 1330 && AnimElemTime(9) > 0 || Anim = 1331
trigger1 = Vel Y < 3.75*(5.0/4.0)
y = 0.2265625*(25.0/16.0)

[State 1330,4]
type = VelSet
trigger1 = Anim = 1330 && AnimElemTime(9) > 0 || Anim = 1331
trigger1 = Vel Y >= 3.75*(5.0/4.0)
y = 3.75*(5.0/4.0)

[State 1330, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 1330 && AnimElemTime(11) > 0 && MoveContact = 1
value = 1331

[State 1330, ChangeState]
type = ChangeState
triggerall = StateType = A
trigger1 = Vel Y + Pos Y >= 0
value = 1305

;=====================<ROLLING SCRATCH>==========================
[StateDef 1400]
type = A
physics = N
moveType = A
anim = ifElse(Var(11),1400,1000)
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1400, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1400, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1400, Loop]
type = VarSet
trigger1 = !Var(11) && Time = 0
var(11) = var(10)

[State 1400, Loop]
type = VarAdd
trigger1 = !Time && PrevStateNo = StateNo
var(11) = -1

[State 1400, PosSet]
type = PosSet
trigger1 = !Time
y = 0

[State 1400, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1000 && AnimTime = 0
value = S1000,0
channel = 1

[State 1400, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1400 && !Time
value = S1400,0

[State 1400, Dust]
type = Helper
trigger1 = (Anim = 1000 || Anim = 1400) && AnimTime = 0
helpertype = normal
stateno = 8100
ID = 8100
name = "Jump Dust"
postype = P1
ownpal = 1

[State 1400, VelSet]
type = VelSet
trigger1 = Anim = 1005 && AnimElemTime(1) = 1
x = 5*(5.0/4.0)
y = -15*Const(Size.YScale)*(5.0/4.0)
persistent = 0

[State 1400, ChangeAnim]
type = ChangeAnim
trigger1 = (Anim = 1000 || Anim = 1400) && AnimTime = 0
value = 1005

[State 1400, VelAdd]
type = VelAdd
trigger1 = Anim = 1005
y = 1.25*Const(Size.YScale)*(25.0/16.0)

[State 1400, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Anim = 1005
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12.52
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1400, ChangeState]
type = ChangeState
triggerall = Time > 7
trigger1 = MoveContact = 1
trigger1 = Command = "x" || Command = "y" || Command = "z"
value = 1405
ignorehitpause = 0
ctrl = 0

[State 1400, ChangeState]
type = ChangeState
triggerall = Time > 1
trigger1 = MoveContact = 1
value = 1406
ignorehitpause = 0

[State 1400, ChangeAnim]
type = ChangeState
triggerall = Anim = 1005 && !MoveContact
trigger1 = Time > 6
trigger1 = Pos Y + Vel Y >= 0
value = ifElse(Var(11),stateNo,1305)

;Rolling Scratch Follow-Up
[Statedef 1405]
type = A
physics = N
movetype = A
anim = 1405
ctrl = 0
poweradd = 0

[State 1405, VarSet]
type = VarSet
trigger1 = Time = 0
var(11) = 4

[State 1405, VelSet]
type = VelSet
trigger1 = Time = 0
x = 3.25*Const(Size.XScale)*(5.0/4.0);3.25 ;1.25, increased to prevent whiffing
y = -1.25*Const(Size.YScale)*(5.0/4.0)

[State 1405, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 9
movetype = I

[State 1405, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1405 && AnimElem = 2
trigger2 = Anim = 1406 && AnimElem = 1
value = S1,0
channel = 1

[State 1405, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1407 && AnimElem = 4
value = S1,2
channel = 1

[State 1405, VarAdd]
type = VarAdd
trigger1 = Time && AnimTime = 0
var(11) = -1

[State 1405, Anim]
type = ChangeAnim
triggerall = (Var(0)&8) > 0 && Var(11)>0
trigger1 = Anim = 1405 && AnimTime = 0
value = 1406

[State 1405, Anim]
type = ChangeAnim
triggerall = (Var(0)&8) > 0 && Var(11)>0
trigger1 = Anim = 1406 && AnimTime = 0
value = 1405
elem = 2

[State 1405, Anim]
type = ChangeAnim
triggerall = Anim != 1407
trigger1 = !Var(11)
trigger2 = (Var(0)&8) = 0 && AnimTime = 0
value = 1407

[State 1405, VelSet]
type = VelSet
trigger1 = Var(11) < 4
trigger1 = Anim = 1405 && AnimElemTime(2) = 0
trigger2 = Anim = 1406 && AnimElemTime(1) = 0
x = 3.25*Const(Size.XScale)*(4.0/3.0);3.25 ;1.25, increased to prevent whiffing
y = -1.25*Const(Size.YScale)*(4.0/3.0)

[State 1405, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1405
trigger1 = AnimElem = 2
trigger2 = AnimElem = 3 && !NumTarget(1405)
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 14 < 7, 7, fvar(11) * 14)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.49
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 1
ID = 1405

[State 1405, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1406
trigger1 = AnimElem = 1
trigger2 = AnimElem = 2 && !NumTarget(1406)
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 21 < 7, 7, fvar(11) * 21)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.49
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -7
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 1
ID = 1406

[State 1405, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1407
trigger1 = AnimElem = 4
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 42 < 7, 7, fvar(11) * 42)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 1

[State 1405, Play Anim]
type = ChangeAnim
triggerall = NumTarget(1405)
triggerall = Anim = 1405
triggerall = AnimElemTime(4) >= 0
trigger1 = HitPauseTime > 0
value = 1405
elem = 4
ignorehitpause = 1

[State 1405, Play Anim]
type = ChangeAnim
triggerall = NumTarget(1406)
triggerall = Anim = 1406
triggerall = AnimElemTime(3) >= 0
trigger1 = HitPauseTime > 0
value = 1406
elem = 3
ignorehitpause = 1

[State 1405, Gravity]
type = VelAdd
triggerall = Time > 0
trigger1 = Var(11) = 4
trigger1 = Anim = 1405 && Time > 0
trigger2 = Var(11) < 4
trigger2 = Anim = 1405 && AnimElemTime(2) > 0
trigger3 = Anim = 1406 && AnimElemTime(1) > 0
trigger4 = Anim = 1407
y = 0.46875*Const(Size.YScale)*(25.0/16.0)
ignorehitpause = 0

[State 1405, ChangeState]
type = ChangeState
triggerall = Time > 1
trigger1 = MoveGuarded = 1
value = 1406

[State 1405, ChangeState]
type = ChangeState
trigger1 = Pos Y + Vel Y >= 0
value = 1305

;Hit Off
[Statedef 1406]
type = A
physics = N
movetype = I
anim = 1016
ctrl = 0

[State 1406, VelSet]
type = VelSet
trigger1 = !Time && ((PrevStateNo = [1000,1099]) || (PrevStateNo = 3000) || (PrevStateNo = 3050))
x = -.25*(Var(50)=1);1.25+(Var(50)=2)
y = -12

[State 1406, VelSet]
type = VelSet
trigger1 = !Time && PrevStateNo = [1400,1421]
x = -3.25
y = -13.125

[State 1406, 0]
type = VelAdd
trigger1 = PrevStateNo != [1400,1421]
y = 0.875;1.1666666666666666666666666666667;.5625

[State 1406, 0]
type = VelAdd
trigger1 = PrevStateNo = [1400,1421]
y = 1.1666666666666666666666666666667;.5625

[State 1406, ChangeState]
type = ChangeState
trigger1 = Pos Y + Vel Y >= 0
value = 1305

;========================<EX ROLLING SCRATCH>=============================
[StateDef 1430]
type = A
physics = N
movetype = A
anim = ifElse(Var(11),1400,1000)
ctrl = 0
velSet = 0,0
sprPriority = 1
faceP2 = !Var(11)

[State 1430, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1430, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1430, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1430, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1430, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(-32 * const(size.xScale)), ceil(-67 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1430, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1430, PowerAdd]
type = PowerAdd
trigger1 = !Time && Anim = 1000
value= -500

[State 1430, VarSet]
type = VarSet
trigger1 = !Time && Anim = 1000
var(53) = 0

[State 1430, Loop]
type = VarSet
trigger1 = !Var(11) && Time = 0
var(11) = 3

[State 1430, Loop]
type = VarAdd
trigger1 = !Time && PrevStateNo = StateNo
var(11) = -1

[State 1430, PosSet]
type = PosSet
trigger1 = !Time
y = 0

[State 1430, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1000 && AnimTime = 0
value = S1000,0
channel = 1

[State 1430, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1400 && !Time
value = S40,0

[State 1430, VelSet]
type = VelSet
trigger1 = (Anim = 1000 || Anim = 1400) && AnimTime = 0
x = 5*(4.0/3.0) ; Again, ain't Turbo a bitch?
y = -15*Const(Size.YScale)*(4.0/3.0)
persistent = 0

[State 1430, ChangeAnim]
type = ChangeAnim
trigger1 = (Anim = 1000 || Anim = 1400) && AnimTime = 0
value = 1005

[State 1430, VelAdd]
type = VelAdd
trigger1 = Anim = 1005
y = 1.25*Const(Size.YScale)*(16.0/9.0)

[State 1430, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
triggerall = Var(53) < 3
triggerall = Anim = 1005
trigger1 = AnimElemTime(2)>=0 && AnimElemTime(3) < 0
trigger2 = AnimElemTime(4)>=0 && AnimElemTime(5) < 0
trigger3 = AnimElemTime(6)>=0 && AnimElemTime(7) < 0
trigger4 = AnimElemTime(8)>=0
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.49
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1430, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
triggerall = Var(53) < 3
triggerall = Anim = 1005
trigger1 = AnimElemTime(1)>=0 && AnimElemTime(2) < 0
trigger2 = AnimElemTime(3)>=0 && AnimElemTime(4) < 0
trigger3 = AnimElemTime(5)>=0 && AnimElemTime(6) < 0
trigger4 = AnimElemTime(7)>=0 && AnimElemTime(8) < 0
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.49
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 1

[State 1430, VarAdd]
type = VarAdd
trigger1 = MoveContact = 1 || MoveReversed = 1
var(53) = 1

[State 1430, ChangeState]
type = ChangeState
trigger1 = MoveContact >= 1
trigger1 = Command = "x" || Command = "y" || Command = "z"
value = 1435
ignorehitpause = 0
ctrl = 0

[State 1430, ChangeState]
type = ChangeState
triggerall = MoveContact = 1 || MoveReversed = 1
trigger1 = Var(53) > 3
trigger2 = !Enemy, Alive
value = 1406;50
ignorehitpause = 0

[State 1430, ChangeAnim]
type = ChangeState
triggerall = Anim = 1005
trigger1 = Time > 6
trigger1 = Pos Y + Vel Y >= 0
value = ifElse(Var(11),stateNo,1305)

;EX Rolling Scratch Follow-Up
[Statedef 1435]
type = A
physics = N
movetype = A
anim = 1405
ctrl = 0
poweradd = 0

[State 1435, VarSet]
type = VarSet
trigger1 = Time = 0
var(11) = 4

[State 1435, VelSet]
type = VelSet
trigger1 = Time = 0
x = 3.25*Const(Size.XScale)*(5.0/4.0);3.25 ;1.25, increased to prevent whiffing
y = -1.25*Const(Size.YScale)*(5.0/4.0)

[State 1435, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 9
movetype = I

[State 1435, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1405 && AnimElem = 2
trigger2 = Anim = 1406 && AnimElem = 1
value = S1,0
channel = 1

[State 1435, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1407 && AnimElem = 4
value = S1,2
channel = 1

[State 1435, VarAdd]
type = VarAdd
trigger1 = Time && AnimTime = 0
var(11) = -1

[State 1435, Anim]
type = ChangeAnim
triggerall = (Var(0)&8) > 0 && Var(11)>0
trigger1 = Anim = 1405 && AnimTime = 0
value = 1406

[State 1435, Anim]
type = ChangeAnim
triggerall = (Var(0)&8) > 0 && Var(11)>0
trigger1 = Anim = 1406 && AnimTime = 0
value = 1405
elem = 2

[State 1435, Anim]
type = ChangeAnim
triggerall = Anim != 1407
trigger1 = !Var(11)
trigger2 = (Var(0)&8) = 0 && AnimTime = 0
value = 1407

[State 1435, VelSet]
type = VelSet
trigger1 = Var(11) < 4
trigger1 = Anim = 1405 && AnimElemTime(2) = 0
trigger2 = Anim = 1406 && AnimElemTime(1) = 0
x = 3.25*Const(Size.XScale)*(4.0/3.0);3.25 ;1.25, increased to prevent whiffing
y = -1.25*Const(Size.YScale)*(4.0/3.0)

[State 1435, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1405
trigger1 = AnimElem = 2
trigger2 = AnimElem = 3 && !NumTarget(1405)
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.49
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -14
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 1
ID = 1405

[State 1435, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1406
trigger1 = AnimElem = 1
trigger2 = AnimElem = 2 && !NumTarget(1406)
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.49
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -7
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 1
ID = 1406

[State 1435, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1407
trigger1 = AnimElem = 4
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
persistent = 1

[State 1435, Play Anim]
type = ChangeAnim
triggerall = NumTarget(1405)
triggerall = Anim = 1405
triggerall = AnimElemTime(4) >= 0
trigger1 = HitPauseTime > 0
value = 1405
elem = 4
ignorehitpause = 1

[State 1435, Play Anim]
type = ChangeAnim
triggerall = NumTarget(1406)
triggerall = Anim = 1406
triggerall = AnimElemTime(3) >= 0
trigger1 = HitPauseTime > 0
value = 1406
elem = 3
ignorehitpause = 1

[State 1435, Gravity]
type = VelAdd
triggerall = Time > 0
trigger1 = Var(11) = 4
trigger1 = Anim = 1405 && Time > 0
trigger2 = Var(11) < 4
trigger2 = Anim = 1405 && AnimElemTime(2) > 0
trigger3 = Anim = 1406 && AnimElemTime(1) > 0
trigger4 = Anim = 1407
y = 0.46875*Const(Size.YScale)*(25.0/16.0)
ignorehitpause = 0

[State 1435, ChangeState]
type = ChangeState
triggerall = Time > 1
trigger1 = MoveGuarded = 1
value = 1406

[State 1435, ChangeState]
type = ChangeState
trigger1 = Pos Y + Vel Y >= 0
value = 1305

;=====================<HELL CAT>==========================
[StateDef 1500]
type = S
physics = N
movetype = A
anim = 1500
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1500, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1500, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1500, ChangeAnim]
type = ChangeAnim
trigger1 = Time = 0
value = 1500+10*Var(10)

[State 1500, 1]
type = HitDef
triggerall = !Var(20)
triggerall = P2MoveType != H
triggerall = P2StateNo != [130,155]
triggerall = P2BodyDist X = [-(ifElse(Var(10)=2,88,ifElse(Var(10)=1,72,40))*Const(Size.XScale) - Const(Size.Ground.Front)), ifElse(Var(10)=2,88,ifElse(Var(10)=1,72,40))*Const(Size.XScale) - Const(Size.Ground.Front)]
trigger1 = AnimElem = 2
attr = S, ST
hitflag = M-
priority = 3, Miss
sparkno = -1
getpower = 0,0
p1facing = 1
p2facing = 1
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1stateno = 1501
p2stateno = 1502
guard.dist = 0
fall = 1
givepower = 0,0

[State 1500, 1]
type = HitDef
triggerall = Var(20)
triggerall = P2StateNo != [130,155]
triggerall = P2BodyDist X = [-(ifElse(Var(10)=2,88,ifElse(Var(10)=1,72,40))*Const(Size.XScale) - Const(Size.Ground.Front)), ifElse(Var(10)=2,88,ifElse(Var(10)=1,72,40))*Const(Size.XScale) - Const(Size.Ground.Front)]
trigger1 = AnimElem = 2
attr = S, ST
hitflag = M
priority = 3, Miss
sparkno = -1
getpower = 0,0
p1facing = 1
p2facing = 1
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1stateno = 1501
p2stateno = 1502
guard.dist = 0
fall = 1
givepower = 0,0

[State 1500, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 3
movetype = I

[State 1500, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 3
value = S5000,0
channel = 0

[State 1500, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Hellcat (P1)
[Statedef 1501]
type = S
physics = N
movetype = A
anim = 1540
poweradd = 0
ctrl = 0

[State 1501, SprPriority]
type = SprPriority
triggerall = Anim = 1540
trigger1 = AnimElem = 5
trigger2 = AnimElem = 11
trigger3 = AnimElem = 17
value = 0

[State 1501, SprPriority]
type = SprPriority
triggerall = Anim = 1540
trigger1 = AnimElem = 1
trigger2 = AnimElem = 8
trigger3 = AnimElem = 14
trigger4 = AnimElem = 20
value = 2

[State 1501, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 1501, PlayerPush]
type = ScreenBound
trigger1 = Anim = 1540
value = 0
movecamera = 0,0

[State 1501, Bind 1]
type = BindtoTarget
triggerall = Anim = 1540
trigger1 = AnimElemTime(1) = 0
time = 4
pos = ceil(54*Const(Size.XScale)),0,Foot

[State 1501, Bind 2]
type = BindtoTarget
triggerall = Anim = 1540
trigger1 = AnimElemTime(2) = 0
time = 5
pos = 0,0, Foot

[State 1501, Bind 5]
type = BindtoTarget
triggerall = Anim = 1540
trigger1 = AnimElemTime(3) = 0
time = 1
pos = 0,ceil(-40*Const(Size.YScale)),Foot

[State 1501, Bind 5]
type = BindtoTarget
triggerall = (target,Const(Size.Head.Pos.Y)/60.0) >= -.8
triggerall = Anim = 1540
trigger1 = AnimElemTime(4) = 0
time = 1
pos = 0,target,Const(Size.Mid.Pos.Y),Foot

[State 1501, PosFreeze]
type = VelSet
triggerall = Anim = 1540
trigger1 = AnimElemTime(4) > 0 && AnimElemTime(5) < 0
trigger2 = AnimElemTime(10) > 0 && AnimElemTime(11) < 0
trigger3 = AnimElemTime(16) > 0 && AnimElemTime(17) < 0
x = 0
y = 0

[State 1501, PosFreeze]
type = PosFreeze
triggerall = Anim = 1540
trigger1 = AnimElemTime(4) > 0 && AnimElemTime(5) < 0
trigger2 = AnimElemTime(10) > 0 && AnimElemTime(11) < 0
trigger3 = AnimElemTime(16) > 0 && AnimElemTime(17) < 0
value = 1
persistent = 1

[State 1501, VelSet]
type = VelSet
triggerall = (target,Const(Size.Head.Pos.Y)/60.0) < -.8
triggerall = Anim = 1540
trigger1 = AnimElemTime(5) = 0
x = facing*((target,Pos X+(target,Const(Size.Mid.Pos.X)*target,facing))-Pos X)/11.0
y = (target, Const(Size.Mid.Pos.Y)+40)/11.0
ignorehitpause = 1

[State 1501, VelSet]
type = VelSet
triggerall = (target,Const(Size.Head.Pos.Y)/60.0) < -.8
triggerall = Anim = 1540
trigger1 = AnimElemTime(11) = 0
x = facing*((target,Pos X+(target,Const(Size.Head.Pos.X)*target,facing))-Pos X)/12.0
y = ((target,Pos Y+target,Const(Size.Head.Pos.Y)+14)-Pos Y)/12.0
ignorehitpause = 1

[State 1501, VelSet]
type = VelSet
triggerall = (target,Const(Size.Head.Pos.Y)/60.0) < -.8
triggerall = Anim = 1540
trigger1 = AnimElemTime(17) = 0
x = facing*(target,Pos X-Pos X)/11.0
y = (-60-Pos Y)/12.0
ignorehitpause = 1

[State 1501, VelSet]
type = VelSet
trigger1 = Anim = 1540 && AnimTime = 0
x = 0
y = 0

[State 1501, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 1540 && AnimTime = 0
value = 1550

[State 1501, PosSet]
type = PosSet
trigger1 = Anim = 1550 && AnimElemTime(1) = 0
y = 0

[State 1501, PosSet]
type = PosAdd
trigger1 = Anim = 1550 && AnimElemTime(1) = 0
x = 100*Const(Size.Xscale)

[State 1501, TargetBind]
type = TargetBind
triggerall = Anim = 1550
trigger1 = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
time = 1
pos = ceil(-81*Const(Size.XScale)),ceil(-65*Const(Size.YScale))
persistent = 1

[State 1501, TargetBind]
type = TargetBind
triggerall = Anim = 1550
trigger1 = AnimElem = 2
time = 1
pos = ceil(-34*Const(Size.XScale)),ceil(-78*Const(Size.YScale))

[State 1501, TargetBind]
type = TargetBind
triggerall = Anim = 1550
trigger1 = AnimElem = 3
time = 1
pos = ceil(3*Const(Size.XScale)),ceil(-80*Const(Size.YScale))

[State 1501, TargetBind]
type = TargetBind
triggerall = Anim = 1550
trigger1 = AnimElem = 4
time = 1
pos = ceil(36*Const(Size.XScale)),ceil(-21*Const(Size.YScale))

[State 1501, PlaySnd]
type = PlaySnd
triggerall = Anim = 1540
trigger1 = AnimElem = 4
trigger2 = AnimElem = 10
trigger3 = AnimElem = 16
value = S2,9
channel = 2

[State 1501, Sparks]
type = Helper
triggerall = Anim = 1540
trigger1 = AnimElemTime(4) = 0
trigger2 = AnimElemTime(10) = 0
trigger3 = AnimElemTime(16) = 0
helpertype = normal
stateno = 8016
ID = 8000
name = "Spark"
postype = P1
pos = 0,0
facing = -1
ownpal = 1
pausemovetime = 65535
supermovetime = 65535
ignorehitpause = 1

[State 1501, Damage]
type = TargetLifeAdd
triggerall = Anim = 1540
trigger1 = AnimElem = 4
trigger2 = AnimElem = 10
trigger3 = AnimElem = 16
value = floor(ifElse(21 * fvar(11) < 7, -7, -21 * fvar(11)))
kill = 0

[State 1501, Damage]
type = TargetLifeAdd
triggerall = Anim = 1550
trigger1 = AnimElem = 4
value = floor(ifElse(70 * fvar(11) < 7, -7, -70 * fvar(11)))

[State 1501, TargetPowerAdd]
type = TargetPowerAdd
triggerall = Anim = 1540
trigger1 = AnimElem = 4
trigger2 = AnimElem = 10
trigger3 = AnimElem = 16
value = 36

[State 1501, Power]
type = PowerAdd
triggerall = Anim = 1540
trigger1 = AnimElem = 4 && !var(20)
trigger2 = AnimElem = 10 && !var(20)
trigger3 = AnimElem = 16 && !var(20)
value = 72

[State 1501, HitAdd]
type = HitAdd
triggerall = Anim = 1540
trigger1 = AnimElem = 4
trigger2 = AnimElem = 10
trigger3 = AnimElem = 16
value = 1

[State 1501, HitCount]
type = VarAdd
triggerall = Anim = 1540
trigger1 = AnimElem = 4
trigger2 = AnimElem = 10
trigger3 = AnimElem = 16
var(13) = 1

[State 1501, Juggle]
type = VarAdd
triggerall = Anim = 1540
trigger1 = AnimElem = 4
trigger2 = AnimElem = 10
trigger3 = AnimElem = 16
var(15) = 1
ignoreHitPause = 1

[State 1501, Juggle]
type = VarSet
triggerall = Anim = 1540
trigger1 = AnimElem = 4
trigger2 = AnimElem = 10
trigger3 = AnimElem = 16
var(16) = 1
ignoreHitPause = 1

[State 1501, PlaySnd]
type = PlaySnd
triggerall = Anim = 1550
trigger1 = AnimElem = 4
value = S4,4
channel=0

[State 1501, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 1305
ctrl = 1

;Hellcat (P2)
[Statedef 1502]
type = A
physics = N
movetype = H
sprpriority = 1
ctrl = 0

[State 1502, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1502, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time
value = 1555

[State 1502, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time && Name = "Gill" && AuthorName = "GM" && Facing = -1
value = 1560

[State 1502, Down]
type = ChangeAnim2
triggerall = Anim = 1555
triggerall = AnimTime = 0
trigger1 = Name = "Felicia" || Name = "Felicia MvC2 Style by MGBenz"
trigger2 = Name = "Zabel" || Name = "Zabel Zarock" || Name = "cvszabel" || Name = "Raptor" || Name = "Lord Raptor"
trigger2 = Name = "Rapter" || Name = "Lord Rapter" || Name = "L Raptor" || Name = "L Rapter" || Name = "L. Raptor" || Name = "L. Rapter" ; OK
trigger3 = (Name = "Demitri" && Enemy, AuthorName != "Bad Darkness") || Name = "Demitri Maximoff" || Name = "Demitri Maximov" || Name = "Demitri(DS)"
trigger4 = Name = "Anakaris" || Name = "cvsanakaris" || Name = "Anakaris By Third"
trigger5 = Name = "Victor"
trigger6 = Name = "Sasquatch"
value = 1559

[State 1502, Felicia]
type = ChangeAnim2
triggerall = AuthorName = "Jesuszilla" && (Name = "Felicia_LG" || Name = "cvsfelicia" || Name = "Felicia")
trigger1 = Anim = 1555
trigger1 = AnimTime = 0
value = 1558

[State 1502, Gill]
type = ChangeAnim2
trigger1 = Anim = 1560
trigger1 = AnimTime = 0
value = 1557

[State 1502, Normal]
type = ChangeAnim2
triggerall = !(AuthorName = "Jesuszilla" && Name = "Felicia_LG" && Name = "cvsfelicia")
triggerall = Name != "Felicia" && Name != "Felicia MvC2 Style by MGBenz"
triggerall = Name != "Zabel" && Name != "Zabel Zarock" && Name != "cvszabel" && Name != "Raptor" && Name != "Lord Raptor"
triggerall = Name != "Rapter" && Name != "Lord Rapter" && Name != "L Raptor" && Name != "L Rapter" && Name != "L. Raptor" && Name != "L. Rapter" ; OK
triggerall = !(Name = "Demitri" && Enemy, AuthorName != "Bad Darkness") && Name != "Demitri Maximoff" && Name != "Demitri Maximov" && Name != "Demitri(DS)"
triggerall = Name != "Anakaris" && Name != "cvsanakaris" && Name != "Anakaris By Third"
triggerall = Name != "Victor"
triggerall = Name != "Sasquatch"
trigger1 = Anim = 1555
trigger1 = AnimTime = 0
value = 1556

[State 1502, Turn]
type = Turn
trigger1 = Anim = [1556,1557]
trigger1 = AnimElemTime(3) = 0
trigger2 = Anim = [1558,1559]
trigger2 = AnimElemTime(4) = 0

[State 1502, VelSet]
type = VelSet
trigger1 = Anim = [1556,1557]
trigger1 = AnimElemTime(3) = 0
trigger2 = Anim = [1558,1559]
trigger2 = AnimElemTime(4) = 0
x = 4
y = -10.707489013671875
persistent = 0

[State 1502, VelAdd]
type = VelAdd
trigger1 = Anim = [1556,1557]
trigger1 = AnimElemTime(3) > 0
trigger2 = Anim = [1558,1559]
trigger2 = AnimElemTime(4) > 0
y = .58048502604167

[State 2502, ChangeState]
type = SelfState
trigger1 = (Anim = [1556,1559]) && AnimElemTime(3) >= 0
trigger1 = Pos Y + Vel Y >= 0
value = 5100
ctrl = 0

;========================<EX ROLLING BUCLER>=============================
[StateDef 1530]
type = S
physics = N
movetype = A
anim = 1530
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1530, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1530, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1530, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1530, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1530, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(Const(Size.XScale)*36),ceil(Const(Size.YScale)*-58)
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1530, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1530, 1]
type = HitDef
triggerall = P2MoveType != H
triggerall = P2StateNo != [130,155]
;triggerall = P2BodyDist X = [30-Const(Size.Ground.Front),46-Const(Size.Ground.Front)]
triggerall = AnimElem = 2
trigger1 = P2BodyDist X <= (46*Const(Size.XScale))-Const(Size.Ground.Front)
trigger1 = P2Dist X >= -EnemyNear(0),Const(Size.Ground.Back) + (30*Const(Size.XScale))
trigger2 = NumEnemy > 1
attr = S, ST
hitflag = M-
priority = 3, Miss
sparkno = -1
p1facing = 1
p2facing = 1
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1stateno = 1531
p2stateno = 1532
guard.dist = 0
fall = 1

[State 1530, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 3
value = S5000,0
channel = 0

[State 1530, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 3
movetype = I

[State 1530, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;EX Hellcat (P1)
[Statedef 1531]
type = S
physics = N
movetype = A
anim = 1531
poweradd = 0
ctrl = 0

[State 1531, SprPriority]
type = SprPriority
triggerall = Anim = 1531
trigger1 = AnimElem = 5
trigger2 = AnimElem = 11
trigger3 = AnimElem = 17
value = 0

[State 1531, SprPriority]
type = SprPriority
triggerall = Anim = 1531
trigger1 = AnimElem = 8
trigger2 = AnimElem = 14
trigger3 = AnimElem = 20
value = 2

[State 1531, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 1531, PlayerPush]
type = ScreenBound
trigger1 = Anim = 1531
value = 0
movecamera = 0,0

[State 1531, Width]
type = Width
trigger1 = Anim = 1550 && AnimElemTime(4) > 0
edge = 30,0

[State 1531, Bind 1]
type = BindtoTarget
triggerall = Anim = 1531
trigger1 = AnimElemTime(1) = 0
time = 5
pos = ceil(33*Const(Size.XScale)),0,Foot

[State 1531, Bind 1]
type = BindtoTarget
triggerall = Anim = 1531
trigger1 = AnimElemTime(2) = 0
time = 6
pos = ceil(54*Const(Size.XScale)),0,Foot

[State 1531, Bind 2]
type = BindtoTarget
triggerall = Anim = 1531
trigger1 = AnimElemTime(3) = 0
time = 3
pos = 0,0,Foot

[State 1531, Bind 5]
type = BindtoTarget
triggerall = Anim = 1531
trigger1 = AnimElemTime(4) = 0
time = 2
pos = 0,ceil(-40*Const(Size.YScale)),Foot

[State 1531, Bind 5]
type = BindtoTarget
triggerall = (target,Const(Size.Head.Pos.Y)/60.0) >= -.8
triggerall = Anim = 1531
trigger1 = AnimElemTime(5) = 0
time = 1
pos = 0,target,Const(Size.Mid.Pos.Y),Foot

[State 1531, VelSet]
type = VelSet
triggerall = (target,Const(Size.Head.Pos.Y)/60.0) < -.8
triggerall = Anim = 1531
trigger1 = AnimElemTime(6) = 0
x = facing*((target,Pos X+(target,Const(Size.Mid.Pos.X)*target,facing))-Pos X)/19.0
y = (target, Const(Size.Mid.Pos.Y)+40)/19.0
ignorehitpause = 1

[State 1531, VelSet]
type = VelSet
triggerall = (target,Const(Size.Head.Pos.Y)/60.0) < -.8
triggerall = Anim = 1531
trigger1 = AnimElemTime(18) = 0
x = facing*((target,Pos X+(target,Const(Size.Head.Pos.X)*target,facing))-Pos X)/20.0
y = ((target,Pos Y+target,Const(Size.Head.Pos.Y)+14)-Pos Y)/20.0
ignorehitpause = 1

[State 1531, VelSet]
type = VelSet
triggerall = (target,Const(Size.Head.Pos.Y)/60.0) < -.8
triggerall = Anim = 1531
trigger1 = AnimElemTime(36) = 0
x = facing*(target,Pos X-Pos X)/9.0
y = (-60-Pos Y)/9.0
ignorehitpause = 1

[State 1531, VelSet]
type = VelSet
trigger1 = AnimTime = 0
x = 0
y = 0

[State 1531, ChangeAnim]
type = ChangeAnim
triggerall = Anim = 1531
trigger1 = AnimTime = 0
value = 1550

[State 1531, PosSet]
type = PosSet
trigger1 = Anim = 1550 && AnimElemTime(1) = 0
y = 0

[State 1531, PosSet]
type = PosAdd
trigger1 = Anim = 1550 && AnimElemTime(1) = 0
x = 100*Const(Size.XScale)

[State 1531, TargetBind]
type = TargetBind
triggerall = Anim = 1550
trigger1 = AnimElemTime(1) >= 0 && AnimElemTime(2) < 0
time = 1
pos = ceil(-81*Const(Size.XScale)),ceil(-65*Const(Size.YScale))
persistent = 1

[State 1531, TargetBind]
type = TargetBind
triggerall = Anim = 1550
trigger1 = AnimElem = 2
time = 1
pos = ceil(-34*Const(Size.XScale)),ceil(-78*Const(Size.YScale))

[State 1531, TargetBind]
type = TargetBind
triggerall = Anim = 1550
trigger1 = AnimElem = 3
time = 1
pos = ceil(3*Const(Size.XScale)),ceil(-80*Const(Size.YScale))

[State 1531, TargetBind]
type = TargetBind
triggerall = Anim = 1550
trigger1 = AnimElem = 4
time = 1
pos = ceil(36*Const(Size.XScale)),ceil(-21*Const(Size.YScale))

[State 1531, PlaySnd]
type = PlaySnd
triggerall = Anim = 1531
trigger1 = AnimElem = 5
trigger2 = AnimElem = 11
trigger3 = AnimElem = 16
trigger4 = AnimElem = 23
trigger5 = AnimElem = 29
trigger6 = AnimElem = 35
value = S2,9
channel=1

[State 1531, Sparks]
type = Helper
triggerall = Anim = 1531
trigger1 = AnimElemTime(5) = 0
trigger2 = AnimElemTime(11) = 0
trigger3 = AnimElemTime(16) = 0
trigger4 = AnimElemTime(23) = 0
trigger5 = AnimElemTime(29) = 0
trigger6 = AnimElemTime(35) = 0
helpertype = normal
stateno = 8016
ID = 8000
name = "Spark"
postype = P1
pos = 0,0
facing = -1
ownpal = 1
pausemovetime = 65535
supermovetime = 65535
ignorehitpause = 1

[State 1531, Damage]
type = TargetLifeAdd
triggerall = Anim = 1531
trigger1 = AnimElem = 5
trigger2 = AnimElem = 11
trigger3 = AnimElem = 16
trigger4 = AnimElem = 23
trigger5 = AnimElem = 29
trigger6 = AnimElem = 35
value = floor(ifElse(14 * fvar(11) < 7, -7, -14 * fvar(11)))
kill = 0

[State 1531, Damage]
type = TargetLifeAdd
triggerall = Anim = 1550
trigger1 = AnimElem = 4
value = floor(ifElse(64 * fvar(11) < 7, -7, -64 * fvar(11)))

[State 1531, TargetPowerAdd]
type = TargetPowerAdd
triggerall = Anim = 1531
trigger1 = AnimElem = 5
trigger2 = AnimElem = 11
trigger3 = AnimElem = 16
trigger4 = AnimElem = 23
trigger5 = AnimElem = 29
trigger6 = AnimElem = 35
value = 36

[State 1531, Power]
type = PowerAdd
triggerall = Anim = 1531
trigger1 = AnimElem = 5 && !var(20)
trigger2 = AnimElem = 11 && !var(20)
trigger3 = AnimElem = 16 && !var(20)
trigger4 = AnimElem = 23 && !var(20)
trigger5 = AnimElem = 29 && !var(20)
trigger6 = AnimElem = 35 && !var(20)
value = 0

[State 1531, HitAdd]
type = HitAdd
triggerall = Anim = 1531
trigger1 = AnimElem = 5
trigger2 = AnimElem = 11
trigger3 = AnimElem = 16
trigger4 = AnimElem = 23
trigger5 = AnimElem = 29
trigger6 = AnimElem = 35
value = 1

[State 1531, HitCount]
type = VarAdd
triggerall = Anim = 1531
trigger1 = AnimElem = 5
trigger2 = AnimElem = 11
trigger3 = AnimElem = 16
trigger4 = AnimElem = 23
trigger5 = AnimElem = 29
trigger6 = AnimElem = 35
var(13) = 1

[State 1531, Juggle]
type = VarAdd
triggerall = Anim = 1531
trigger1 = AnimElem = 5
trigger2 = AnimElem = 11
trigger3 = AnimElem = 16
trigger4 = AnimElem = 23
trigger5 = AnimElem = 29
trigger6 = AnimElem = 35
var(15) = 1
ignoreHitPause = 1

[State 1531, Juggle]
type = VarSet
triggerall = Anim = 1531
trigger1 = AnimElem = 5
trigger2 = AnimElem = 11
trigger3 = AnimElem = 16
trigger4 = AnimElem = 23
trigger5 = AnimElem = 29
trigger6 = AnimElem = 35
var(16) = 1
ignoreHitPause = 1

[State 1531, TargetLifeAdd]
type = PlaySnd
triggerall = Anim = 1550
trigger1 = AnimElem = 4
value = S4,4
channel=0

[State 1531, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 1305
ctrl = 1

;EX Hellcat (P2)
[Statedef 1532]
type = A
physics = N
movetype = H
sprpriority = 1
ctrl = 0
velset = 0,0

[State 1532, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1532, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time
value = 1535

[State 2502, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time && Name = "Gill" && AuthorName = "GM" && Facing = -1
value = 1536

[State 1502, Gill]
type = ChangeAnim2
triggerall = Name = "Gill" && AuthorName = "GM"
trigger1 = Anim = 1535
trigger1 = AnimTime = 0
value = 1561

[State 1502, Down]
type = ChangeAnim2
triggerall = Anim = 1535
triggerall = AnimTime = 0
trigger1 = Name = "Felicia" || Name = "Felicia MvC2 Style by MGBenz"
trigger2 = Name = "Zabel" || Name = "Zabel Zarock" || Name = "cvszabel" || Name = "Raptor" || Name = "Lord Raptor"
trigger2 = Name = "Rapter" || Name = "Lord Rapter" || Name = "L Raptor" || Name = "L Rapter" || Name = "L. Raptor" || Name = "L. Rapter" ; OK
trigger3 = (Name = "Demitri" && Enemy, AuthorName != "Bad Darkness") || Name = "Demitri Maximoff" || Name = "Demitri Maximov" || Name = "Demitri(DS)"
trigger4 = Name = "Anakaris" || Name = "cvsanakaris" || Name = "Anakaris By Third"
trigger5 = Name = "Victor"
trigger6 = Name = "Sasquatch"
value = 1559

[State 1502, Felicia]
type = ChangeAnim2
triggerall = AuthorName = "Jesuszilla" && (Name = "Felicia_LG" || Name = "cvsfelicia")
trigger1 = Anim = 1535
trigger1 = AnimTime = 0
value = 1558

[State 1502, Gill]
type = ChangeAnim2
trigger1 = Anim = 1536
trigger1 = AnimTime = 0
value = 1557

[State 1502, Normal]
type = ChangeAnim2
triggerall = !(AuthorName = "Jesuszilla" && Name = "Felicia_LG" && Name = "cvsfelicia")
triggerall = Name != "Felicia" && Name != "Felicia MvC2 Style by MGBenz"
triggerall = Name != "Zabel" && Name != "Zabel Zarock" && Name != "cvszabel" && Name != "Raptor" && Name != "Lord Raptor"
triggerall = Name != "Rapter" && Name != "Lord Rapter" && Name != "L Raptor" && Name != "L Rapter" && Name != "L. Raptor" && Name != "L. Rapter" ; OK
triggerall = !(Name = "Demitri" && Enemy, AuthorName != "Bad Darkness") && Name != "Demitri Maximoff" && Name != "Demitri Maximov" && Name != "Demitri(DS)"
triggerall = Name != "Anakaris" && Name != "cvsanakaris" && Name != "Anakaris By Third"
triggerall = Name != "Victor"
triggerall = Name != "Sasquatch"
triggerall = !(Name = "Gill" && AuthorName = "GM")
trigger1 = Anim = 1535
trigger1 = AnimTime = 0
value = 1556

[State 1502, Turn]
type = Turn
trigger1 = Anim = 1561 || Anim = [1556,1557]
trigger1 = AnimElemTime(3) = 0
trigger2 = Anim = [1558,1559]
trigger2 = AnimElemTime(4) = 0

[State 0, VelSet]
type = VelSet
trigger1 = Anim = 1561 || Anim = [1556,1557]
trigger1 = AnimElemTime(3) = 0
trigger2 = Anim = [1558,1559]
trigger2 = AnimElemTime(4) = 0
x = 4.46875
y = -11.40625

[State 1502, VelAdd]
type = VelAdd
trigger1 = Anim = 1561 || Anim = [1556,1557]
trigger1 = AnimElemTime(3) > 0
trigger2 = Anim = [1558,1559]
trigger2 = AnimElemTime(4) > 0
x = ifElse(vel X <= 0, 0, -0.04167)
y = 0.79167

[State 1502, ChangeState]
type = SelfState
trigger1 = (Anim = 1561 || (Anim = [1556,1559])) && AnimElemTime(4) >= 0
trigger1 = Pos Y + Vel Y >= 0
value = 5100
ctrl = 0

;=====================<TOY TOUCH>==========================
[StateDef 1600]
type = S
movetype = A
physics = N
anim = 1600
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1600, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1600, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1600, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 4
value = S1,2
channel = 1

[State 1600, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 4
value = S4,1
channel = 0

[State 1600, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 5
movetype = I

[State 1600, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 4
attr = C, SA
hitflag = FD
guardflag =
damage = ceil(ifElse(fvar(11) * 42 < 7, 7, fvar(11) * 42)), 7
priority = 6, Hit
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -7
down.velocity = 0,0
down.hittime = 18
down.bounce = 0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
p2stateno = 3880

[State 1600, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<EX TOY TOUCH>=============================
[StateDef 1630]
type = S
movetype = A
physics = N
anim = 1630
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1630, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1630, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1630, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1630, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1630, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(4*Const(size.xscale)),ceil(-51*Const(size.yscale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1630, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1630, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 6
trigger2 = AnimElem = 9
trigger3 = AnimElem = 12
trigger4 = AnimElem = 15
value = S4,1
channel = 0

[State 1630, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElem = 16
movetype = I

[State 1630, Rat 1]
type = Explod
trigger1 = !Time
anim = 1918
ID = 1918
pos = ceil(44*Const(Size.XScale)),0
postype = p1
removetime = -2
scale = const(Size.XScale),const(Size.Yscale)
sprpriority = 2
ownpal = 1
removeongethit = 1

[State 1630, Rat 2]
type = Explod
trigger1 = AnimElemTime(5) = 0
anim = 1919
ID = 1918
pos = 0,0
postype = p1
removetime = -2
scale = const(Size.XScale),const(Size.Yscale)
sprpriority = 1
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1630, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
trigger2 = AnimElem = 9
trigger3 = AnimElem = 12
trigger4 = AnimElem = 15
attr = C, SA
hitflag = FD
guardflag =
damage = ceil(ifElse(fvar(11) * 21 < 7, 7, fvar(11) * 21)), 7
priority = 6, Hit
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -7
down.velocity = 0,0
down.hittime = 18
down.bounce = 0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getpower = 0
givepower = 36,36
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
p2stateno = 3880

[State 1630, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<PURSUIT>==========================
[StateDef 1700]
type = A
movetype = A
physics = N
anim = 1700
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1700, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 0

[State 1700, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1700 && AnimElemTime(4) = 0
value = S4,1
channel = 0

[State 1700, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 1700 && AnimElemTime(4) = 0
statetype = A

[State 1700, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignorehitpause = 1

[State 1700, 6]
type = VelSet
trigger1 = Anim = 1700 && AnimElemTime(4) = 0
x = p2Dist X/30.0 * (4.0/3.0)
y = -13*(5.0/4.0)

[State 1700, 1]
type = VelAdd
trigger1 = Anim = 1700 && AnimElemTime(4) > 0
y = 0.8125*(25.0/16.0);1.0833

[State 1700, 1]
type = VelAdd
trigger1 = Anim = 41 && AnimElemTime(1) > 0 && !Var(10)
trigger2 = Anim = 1730 && AnimElemTime(3) < 0
x = ifElse(Vel X <= 0, 0, -0.0625)*(25.0/16.0)
y = 0.5*(25.0/16.0)

[State 1700, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1700
trigger1 = Vel Y >= 0
attr = A, NA
hitflag = FD
guardflag =
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 7
priority = 6, Hit
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := 0
down.velocity = 0,0
down.hittime = 18+(3*Var(10))
down.bounce = 0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
persistent = 0
p2stateno = 3880
kill = !Var(10)
ID = 1700
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1700, 1]
type = VelSet
trigger1 = Anim = 1730 && NumTarget(1730) && AnimElemTime(3) >= 0
y = 0

[State 1700, ChangeAnim]
type = ChangeAnim
trigger1 = MoveHit
value = anim+5
persistent = 0
ignorehitpause = 1

[State 1700, PosSet]
type = PosSet
trigger1 = Anim = 1705
trigger2 = Anim = 1730 && NumTarget(1730)
y = -16

[State 1700, PosFreeze]
type = PosFreeze
trigger1 = Anim = 1705
trigger2 = Anim = 1730 && NumTarget(1730)
value = 1

[State 1700, VelSet]
type = VelSet
triggerall = !Var(10)
trigger1 = Anim = 1705 && !AnimTime
x = 6*(4.0/3.0)
y = -9*(5.0/4.0)
persistent = 0

[State 1700, VelSet]
type = VelSet
triggerall = Var(10)
trigger1 = Anim = 1705 && !AnimTime
x = 0
y = -6*(5.0/4.0)
persistent = 0

[State 1700, VelSet]
type = VelSet
trigger1 = Anim = 1730 && !AnimTime
x = 7*(4.0/3.0)
y = -8*(5.0/4.0)
persistent = 0

[State 1700, VelSet]
type = ChangeAnim
triggerall = Var(10)
trigger1 = Anim = 41 && Vel Y >= 0
value = 1730
persistent = 0

[State 1700, VelSet]
type = VelAdd
trigger1 = Anim = 41 && Var(10)
x = ifElse(Vel X <= 0, 0, -0.0625)*(25.0/16.0)
y = 0.625*(25.0/16.0)

[State 1700, VelSet]
type = ChangeAnim
trigger1 = Anim = 1730 && !AnimTime
value = 41
elem = 3

[State 1700, NotHitBy]
type = NotHitBy
trigger1 = Anim = 41 && Var(10)
value = SCA

[State 1700, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 1705 && !AnimTime
value = 41
elem = ifElse(Var(10),5,0)

[State 1700, ChangeState]
type = ChangeState
triggerall = Time > 8
triggerall = Vel Y > 0
triggerall = Pos Y >= 0
trigger1 = !MoveHit && Anim = 1700
trigger2 = Anim = 41
value = 52

;========================<EX PURSUIT>=============================
[StateDef 1730]
type = A
movetype = A
physics = N
anim = 1700
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1730, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1730, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1730, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1730, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1730, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(4*Const(size.xscale)),ceil(-51*Const(size.yscale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1730, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1730, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1700 && AnimElemTime(4) = 0
value = S4,1
channel = 0

[State 1730, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 1700 && AnimElemTime(4) = 0
statetype = A

[State 1730, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignorehitpause = 1

[State 1730, 6]
type = VelSet
trigger1 = Anim = 1700 && AnimElemTime(4) = 0
x = p2Dist X/30.0 * (4.0/3.0)
y = -13*(5.0/4.0)

[State 1730, 1]
type = VelAdd
trigger1 = Anim = 1700 && AnimElemTime(4) > 0
y = 0.8125*(25.0/16.0);1.0833

[State 1730, 1]
type = VelAdd
trigger1 = Anim = 41 && AnimElemTime(1) > 0 && !Var(10)
trigger2 = Anim = 1730 && AnimElemTime(3) < 0
x = ifElse(Vel X <= 0, 0, -0.0625)*(25.0/16.0)
y = 0.5*(25.0/16.0)

[State 1700, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1700
trigger1 = Vel Y >= 0
attr = A, NA
hitflag = FD
guardflag =
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 7
priority = 6, Hit
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := 0
down.velocity = 0,0
down.hittime = 18+(3*Var(10))
down.bounce = 0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getPower = 0,0
givePower = 36, 36
persistent = 0
p2stateno = 3880
kill = !Var(10)
ID = 1700
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1700, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1730
trigger1 = AnimElem = 2
trigger2 = AnimElem = 3
trigger3 = AnimElem = 5
trigger4 = AnimElem = 8
trigger5 = AnimElem = 11
attr = A, SA
hitflag = FD+
guardflag =
damage = ceil(ifElse(fvar(11) * 7 < 7, 7, fvar(11) * 7)), 7
priority = 6, Hit
pausetime = 4,4
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := 0
down.velocity = 0,0
down.hittime = 18
down.bounce = 0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getpower = 0
givepower = 36,36
p2stateno = 3880
ID = 1730
kill = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1730, 1]
type = VelSet
trigger1 = Anim = 1730 && NumTarget(1730) && AnimElemTime(3) >= 0
y = 0

[State 1700, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = Anim = 1730
trigger1 = AnimElem = 16
attr = A, SA
hitflag = FD+
guardflag =
damage = 7,0
priority = 6, Hit
pausetime = 4,4
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -7
down.velocity = 0,0
down.hittime = 18
down.bounce = 0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
airguard.cornerpush.veloff = 0
getpower = 0
givepower = 36,36
persistent = 0
kill = 1 || (var(10) := 3)

[State 1730, ChangeAnim]
type = ChangeAnim
trigger1 = MoveHit
value = anim+5
persistent = 0
ignorehitpause = 1

[State 1730, PosSet]
type = PosSet
trigger1 = Anim = 1705
trigger2 = Anim = 1730 && NumTarget(1730)
y = -16

[State 1730, PosFreeze]
type = PosFreeze
trigger1 = Anim = 1705
trigger2 = Anim = 1730 && NumTarget(1730)
value = 1

[State 1730, VelSet]
type = VelSet
triggerall = !Var(10)
trigger1 = Anim = 1705 && !AnimTime
x = 6*(4.0/3.0)
y = -9*(5.0/4.0)
persistent = 0

[State 1730, VelSet]
type = VelSet
triggerall = Var(10)
trigger1 = Anim = 1705 && !AnimTime
x = 0
y = -6*(5.0/4.0)
persistent = 0

[State 1730, VelSet]
type = VelSet
trigger1 = Anim = 1730 && !AnimTime
x = 7*(4.0/3.0)
y = -8*(5.0/4.0)
persistent = 0

[State 1730, VelSet]
type = ChangeAnim
triggerall = Var(10)
trigger1 = Anim = 41 && Vel Y >= 0
value = 1730
persistent = 0

[State 1730, VelSet]
type = VelAdd
trigger1 = Anim = 41 && Var(10)
x = ifElse(Vel X <= 0, 0, -0.0625)*(25.0/16.0)
y = 0.625*(25.0/16.0)

[State 1730, VelSet]
type = ChangeAnim
trigger1 = Anim = 1730 && !AnimTime
value = 41
elem = 3

[State 1730, NotHitBy]
type = NotHitBy
trigger1 = Anim = 41 && Var(10)
value = SCA

[State 1730, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 1705 && !AnimTime
value = 41
elem = ifElse(Var(10),5,0)

[State 1730, ChangeState]
type = ChangeState
triggerall = Time > 8
triggerall = Vel Y > 0
triggerall = Pos Y >= 0
trigger1 = !MoveHit && Anim = 1700
trigger2 = Anim = 41
value = 52

;HITG_SHAKE_High
[Statedef 3800]
type = S
movetype = H
physics = N
velset = 0,0

[State 1000, 0]
type = HitFallSet
trigger1 = time = 0
value = 0

[State 5000, 1] ;Anim for HIT_LIGHT to HIT_HARD
type = ChangeAnim
trigger1 = Time = 0
value = 5000+100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1)

[State 5000, 4] ;Freeze anim
type = ChangeAnim
trigger1 = Time > 0
value = anim

[State 5000, 6]
type = ChangeState
trigger1 = HitShakeOver
value = 3801 ;HITG_SLIDE

;HITG_SHAKE_Low
[Statedef 3805]
type = S
movetype = H
physics = N
velset = 0,0

[State 1000, 0]
type = HitFallSet
trigger1 = time = 0
value = 0

[State 5000, 1] ;Anim for HIT_LIGHT to HIT_HARD
type = ChangeAnim
trigger1 = Time = 0
value = 5010+100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1)

[State 5000, 4] ;Freeze anim
type = ChangeAnim
trigger1 = Time > 0
value = anim

[State 5000, 6]
type = ChangeState
trigger1 = HitShakeOver
value = 3806 ;HITG_SLIDE

;HITG_SLIDE_High
[Statedef 3801]
type = S
movetype = H
physics = S

[State 5001, 1]
type = HitVelSet
trigger1 = Time = 0
x = 1

[State 5001, 2]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 5005+100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1)

[State 5001, 3] ;Stop sliding back
type = VelMul
trigger1 = Time >= GetHitVar(slidetime)
x = .6

[State 5001, 4]
type = VelSet
trigger1 = HitOver
x = 0

[State 5001, 5]
type = DefenceMulSet
trigger1 = HitOver
value = 1

[State 5001, 6]
type = SelfState
trigger1 = HitOver
value = 0
ctrl = 1

;HITG_SLIDE_Low
[Statedef 3806]
type = S
movetype = H
physics = S

[State 5001, 1]
type = HitVelSet
trigger1 = Time = 0
x = 1

[State 5001, 2]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 5015+100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1)

[State 5001, 3] ;Stop sliding back
type = VelMul
trigger1 = Time >= GetHitVar(slidetime)
x = .6

[State 5001, 4]
type = VelSet
trigger1 = HitOver
x = 0

[State 5001, 5]
type = DefenceMulSet
trigger1 = HitOver
value = 1

[State 5001, 6]
type = SelfState
trigger1 = HitOver
value = 0
ctrl = 1

;HITA_SHAKE
[Statedef 3820]
type = A
movetype = H
physics = N
velset = 0,0

[State 5020, 1] ;Anim for HIT_LIGHT to HIT_HARD
type = ChangeAnim
trigger1 = Time = 0
trigger1 = GetHitVar(animtype) != [3,5]
value = ifelse((GetHitVar(airtype) = 1),5000,5010) + GetHitVar(animtype) + 100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1)

[State 5020, 2] ;Anim for HIT_BACK
type = ChangeAnim
trigger1 = Time = 0
trigger1 = GetHitVar(animtype) = [3,5]
value = 5030+100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1)

[State 5020, 3] ;Anim for HIT_UP/HIT_DIAGUP (only if it exists)
type = ChangeAnim
trigger1 = Time = 0
trigger1 = (GetHitVar(animtype) = [4,5]) && ((SelfAnimExist(5047 + GetHitVar(animtype))) || (SelfAnimExist(105047 + GetHitVar(animtype)) && Name = "Gill" && AuthorName = "GM" && Facing = -1))
value = 5047 + GetHitVar(animtype) + 100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1) ;5051 - 4 + type

[State 5020, 4] ;Freeze anim
type = ChangeAnim
trigger1 = Time > 0
value = anim

[State 5020, 5]
type = ChangeState
trigger1 = HitShakeOver
value = 3830

;HITA_UP (initial going up)
[Statedef 3830]
type = A
movetype = H
physics = N
ctrl = 0

[State 5030, 1]
type = VelAdd;Gravity
trigger1 = 1
y = GetHitVar(yaccel)

[State 5030, 2]
type = HitVelSet
trigger1 = Time = 0
x = 1
y = 1

[State 5030, 4]
type = ChangeState
trigger1 = HitOver
trigger2 = Vel Y > 0 ;Hit ground
trigger2 = Pos Y >= 10  ;.
value = 3850 ;HITA_FALL

[State 5030, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 3835 ;HITA_UP (transition)

;HITA_UP_T (transition)
[Statedef 3835]
type = A
movetype = H
physics = N

[State 5035, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = SelfAnimExist(5035)
trigger1 = Anim != [5051,5059] ;Not if in hit up anim
trigger1 = Anim != 5090 ;Not if hit off ground anim
value = 5035

[State 5035, 1]
type = ChangeAnim
trigger1 = Name = "Gill" && AuthorName = "GM" && Facing = -1
trigger1 = Time = 0
trigger1 = SelfAnimExist(105035)
trigger1 = Anim != [105051, 105059] ;Not if in hit up anim
trigger1 = Anim != 105090 ;Not if hit off ground anim
trigger1 = Anim != [10501, 105059)
value = 105035

[State 5035, 2]
type = VelAdd
trigger1 = 1
y = GetHitVar(yaccel)

[State 5035, 4]
type = ChangeState
trigger1 = HitOver  ;Hit is over
trigger2 = AnimTime = 0 ;Anim is over
trigger3 = Vel Y > 0 ;Hit ground
trigger3 = Pos Y >= 10  ;.
trigger4 = Time = 0  ;No transition anim
trigger4 = Anim != 5035 ;.
value = 3850 ;HITA_FALL

;HITA_FALL (knocked up, falling)
[Statedef 3850]
type = A
movetype = H
physics = N

[State 5050, 1] ;Change anim when done with transition
type = ChangeAnim
trigger1 = AnimTime = 0
trigger1 = Anim = 5035
trigger2 = Time = 0  ;If no transition anim
trigger2 = Anim != 5035
trigger2 = (Anim != [5051, 5059]) && (Anim != [5061, 5069])
trigger2 = Anim != 5090 ;Not if hit off ground anim
value = 5050

[State 5050, 1] ;Change anim when done with transition
type = ChangeAnim
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
trigger1 = AnimTime = 0
trigger1 = Anim = 105035
trigger2 = Time = 0  ;If no transition anim
trigger2 = Anim != 105035
trigger2 = (Anim != [105051, 105059]) && (Anim != [105061, 105069])
trigger2 = Anim != 105090 ;Not if hit off ground anim
value = 105050

[State 5050, 2] ;Coming down anim
type = ChangeAnim
trigger1 = (anim = [5050,5059]) || (Name = "Gill" && AuthorName = "GM" && Facing = -1 && anim = [105050, 105059])
trigger1 = Vel Y >= ifelse(anim = 5050+(Name = "Gill" && AuthorName = "GM" && Facing = -1)*100000, 1, -2)
trigger1 = SelfAnimExist(anim+10)
value = anim+10
persistent = 0

[State 5050, 3] ;Gravity
type = VelAdd
trigger1 = 1
y = GetHitVar(yaccel)

[State 5050, 6]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= ifelse((anim = [5051,5059]) || (anim = [5061,5069]), 0, 25)
value = 3900 ;HIT_BOUNCE

;HITL_SHAKE
[Statedef 3880]
type = L
movetype = H
physics = N
velset = 0,0

[State 5080, 1] ;Set default anim
type = VarSet
trigger1 = time = 0
sysvar(2) = ifelse(GetHitVar(yvel) = 0, 5080, 5090)

[State 5080, 2]
type = VarAdd
trigger1 = time = 0
trigger1 = (anim = [5081,5089]) || (anim = [5111,5119])
trigger1 = SelfAnimExist(sysvar(2) + (anim % 10))
sysvar(2) = anim % 10

[State 5080, 2]
type = VarAdd
trigger1 = Name = "Gill" && AuthorName = "GM" && Facing = -1
trigger1 = time = 0
trigger1 = (anim = [105081,105089]) || (anim = [105111,105119])
trigger1 = SelfAnimExist(sysvar(2) + (anim % 10))
sysvar(2) = anim % 10

[State 5080, 3] ;If 5090 doesn't exist, default to 5030
type = VarSet
trigger1 = time = 0
trigger1 = sysvar(2) = 5090+100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1)
trigger1 = !SelfAnimExist(5090+100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1))
sysvar(2) = 5030

[State 5080, 3] ;Freeze
type = ChangeAnim
trigger1 = 1
value = sysvar(2)

[State 5080, 4]
type = ChangeState
trigger1 = HitShakeOver
trigger1 = GetHitVar(yvel) = 0
value = 3881 ;HITL_SLIDE

[State 5080, 5]
type = ChangeState
trigger1 = HitShakeOver
trigger1 = GetHitVar(yvel) != 0
value = 3830 ;HITA_UP

;HITL_SLIDE
[Statedef 3881]
type = L
movetype = H
physics = C

[State 5081, 1]
type = HitVelSet
trigger1 = Time = 0
x = 1

[State 5081, 2]
type = VelSet
trigger1 = HitOver
x = 0

[State 5081, 3] ;Don't show hit ground frame
type = VarSet
trigger1 = Time = 0
sysvar(0) = 1

[State 5081, 4]
type = ChangeState
trigger1 = HitOver
value = 3910 ;HIT_LIEDOWN

;HIT_BOUNCE (hit ground)
[Statedef 3900]
type = L
movetype = H
physics = N

[State 5100, 1]
type = VelSet
trigger1 = Time = 0
trigger1 = GetHitVar(fall.yvel) = 0
trigger1 = vel x > 1
x = 1

[State 5100, EnvShake]
type = FallEnvShake
trigger1 = Time = 0

[State 5100, Var] ;Save fall velocity
type = VarSet
trigger1 = Time = 0
sysvar(1) = floor(vel y)

[State 5100, 2] ;Hit ground anim (normal)
type = ChangeAnim
triggerall = time = 0
trigger1 = ((anim != [5051,5059]) && (anim != [5061,5069]))
trigger2 = !SelfAnimExist(5100 + (anim % 10))
value = 5100

[State 5100, 2] ;Hit ground anim (normal)
type = ChangeAnim
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
triggerall = time = 0
trigger1 = ((anim != [105051,105059]) && (anim != [105061,105069]))
trigger2 = !SelfAnimExist(105100 + (anim % 10))
value = 105100

[State 5100, 3] ;Hit ground anim (for hit up)
type = ChangeAnim
trigger1 = time = 0
trigger1 = ((anim != [5051,5059]) && (anim != [5061,5069]))
trigger1 = SelfAnimExist(5100 + (anim % 10))
value = 5100 + (anim % 10)

[State 5100, 3] ;Hit ground anim (for hit up)
type = ChangeAnim
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
trigger1 = time = 0
trigger1 = ((anim != [105051,105059]) && (anim != [105061,105069]))
trigger1 = SelfAnimExist(105100 + (anim % 10))
value = 105100 + (anim % 10)

[State 5100, 4]
type = PosSet
trigger1 = Time = 0
y = 0

[State 5100, 5]
type = VelSet
trigger1 = Time = 0
y = 0

[State 5100, 6] ;Reduce speed
type = VelMul
trigger1 = Time = 0
x = 0.75

[State 5100, 7]
type = ChangeState
trigger1 = Time = 0
trigger1 = GetHitVar(fall.yvel) = 0
value = 3910 ;HIT_LIEDOWN

[State 5100, 8]
type = GameMakeAnim
trigger1 = Time = 1
value = 60 + (sysvar(1) > 5) + (sysvar(1) > 14)
pos = 0, 0
under = sysvar(1) <= 14

[State 5100, 9]
type = HitFallDamage
trigger1 = Time = 3

[State 5100, 10]
type = PlaySnd
trigger1 = Time = 1
value = F7, (sysvar(1) > 5) + (sysvar(1) > 14)

[State 5100, 11]
type = PosFreeze
trigger1 = 1

[State 5100, 12]
type = ChangeState
trigger1 = AnimTime = 0
value = 3901

;HIT_BOUNCE (bounce into air)
[Statedef 3901]
type = L
movetype = H
physics = N

[State 5101, 1] ;Coming hit ground anim (normal)
type = ChangeAnim
triggerall = time = 0
trigger1 = anim != [5101,5109]
trigger2 = !SelfAnimExist(5160 + (anim % 10))
value = 5160

[State 5101, 2] ;Coming hit ground anim (for hit up)
type = ChangeAnim
triggerall = time = 0
trigger1 = anim = [5101,5109]
trigger1 = SelfAnimExist(5160 + (anim % 10))
value = 5160 + (anim % 10)

[State 5101, 1] ;Coming hit ground anim (normal)
type = ChangeAnim
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
triggerall = time = 0
trigger1 = anim != [105101,105109]
trigger2 = !SelfAnimExist(105160 + (anim % 10))
value = 105160

[State 5101, 2] ;Coming hit ground anim (for hit up)
type = ChangeAnim
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
triggerall = time = 0
trigger1 = anim = [105101,105109]
trigger1 = SelfAnimExist(105160 + (anim % 10))
value = 105160 + (anim % 10)

[State 5101, 3]
type = HitFallVel
trigger1 = Time = 0

[State 5101, 4]
type = PosSet
trigger1 = Time = 0
y = 20

[State 5101, 5] ;Acceleration
type = VelAdd
trigger1 = 1
y = .4

[State 5101, 6] ;Hit ground
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 12
type = ChangeState
value = 3910

;HIT_LIEDOWN
[Statedef 3910]
type = L
movetype = H
physics = N

[State 5110, EnvShake]
type = FallEnvShake
trigger1 = Time = 0

[State 5110, 1] ;For hit up/up-diag type (from state 5081)
type = ChangeAnim
persistent = 0
trigger1 = SelfAnimExist(5110 + (anim % 10))
trigger1 = anim = [5081,5089]
value = 5110 + (anim % 10)

[State 5110, 2] ;Hit ground anim (normal)
type = ChangeAnim
triggerall = time = 0
triggerall = anim != [5110,5119] ;Not already changed anim
trigger1 = anim != [5161,5169]
trigger2 = !SelfAnimExist(5170 + (anim % 10))
value = 5170

[State 5110, 3] ;Hit ground anim (for hit up)
type = ChangeAnim
triggerall = time = 0
triggerall = anim != [5110,5119] ;Not already changed anim
trigger1 = anim = [5161,5169]
trigger1 = SelfAnimExist(5170 + (anim % 10))
value = 5170 + (anim % 10)

[State 5110, 1] ;For hit up/up-diag type (from state 5081)
type = ChangeAnim
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
persistent = 0
trigger1 = SelfAnimExist(105110 + (anim % 10))
trigger1 = anim = [105081,105089]
value = 105110 + (anim % 10)

[State 5110, 2] ;Hit ground anim (normal)
type = ChangeAnim
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
triggerall = time = 0
triggerall = anim != [105110,105119] ;Not already changed anim
trigger1 = anim != [105161,105169]
trigger2 = !SelfAnimExist(105170 + (anim % 10))
value = 105170

[State 5110, 3] ;Hit ground anim (for hit up)
type = ChangeAnim
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
triggerall = time = 0
triggerall = anim != [105110,105119] ;Not already changed anim
trigger1 = anim = [105161,105169]
trigger1 = SelfAnimExist(105170 + (anim % 10))
value = 105170 + (anim % 10)

[State 5110, 4]
type = HitFallDamage
trigger1 = Time = 0

[State 5110, 5]
type = PosSet
trigger1 = Time = 0
y = 0

[State 5110, Var] ;Get fall velocity
type = VarSet
trigger1 = Time = 0
trigger1 = GetHitVar(fall.yvel) != 0
sysvar(1) = floor(vel y)

[State 5110, 6]
type = PlaySnd
trigger1 = Time = 0
trigger1 = !SysVar(0)
value = F7, (sysvar(1) > 5) + (sysvar(1) > 14)

[State 5110, 7]
type = GameMakeAnim
trigger1 = Time = 0
trigger1 = !SysVar(0)
value = 60 + (sysvar(1) > 5) + (sysvar(1) > 14)
pos = 0, 0
under = sysvar(1) <= 14

[State 5110, 8]
type = VelSet
trigger1 = Time = 0
y = 0

[State 5110, 9]
type = ChangeAnim
persistent = 0
triggerall = anim = [5171,5179]
triggerall = SelfAnimExist(5110 + (anim % 10))
trigger1 = AnimTime = 0
trigger2 = SysVar(0)
value = 5110 + (anim % 10)

[State 5110, 10]
type = ChangeAnim
persistent = 0
triggerall = Anim != [5111,5119]
trigger1 = AnimTime = 0
trigger2 = SysVar(0)
value = 5110

[State 5110, 9]
type = ChangeAnim
persistent = 0
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
triggerall = anim = [105171,105179]
triggerall = SelfAnimExist(105110 + (anim % 10))
trigger1 = AnimTime = 0
trigger2 = SysVar(0)
value = 105110 + (anim % 10)

[State 5110, 10]
type = ChangeAnim
persistent = 0
triggerall = Name = "Gill" && AuthorName = "GM" && Facing = -1
triggerall = Anim != [105111,105119]
trigger1 = AnimTime = 0
trigger2 = SysVar(0)
value = 105110

[State 5110, 11]
type = SelfState
triggerall = !alive
trigger1 = AnimTime = 0
trigger2 = SysVar(0)
trigger3 = (Anim = [5110,5119]) || (Name = "Gill" && AuthorName = "GM" && Facing = -1 && Anim = [105111,105119])
value = 5150

[State 5110, 11]
type = SelfState
trigger1 = time = 70
value = 5120

[State 5110, 12]
type = VarSet
trigger1 = SysVar(0)
trigger1 = Time = 0
sysvar(0) = 0

[State 5110, 13] ;Friction
type = VelMul
trigger1 = 1
x = 0.85

;========================<PUNCH ZERO COUNTER>=============================
[StateDef 2900]
type = S
physics = N
moveType = A
anim = 2900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2900, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2900, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 2900, Woosh]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,2
channel = 1

[State 2900, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 72 < 7, 7, fvar(11) * 72)), 0
getpower = 0,0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 165), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2900, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 2900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<KICK ZERO COUNTER>=============================
[StateDef 2910]
type = S
physics = N
moveType = A
anim = 2910
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2910, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2910, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, 4
channel = 0

[State 2910, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,5
channel = 1

[State 2910, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 3
attr = C, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 72 < 7, 7, fvar(11) * 72)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 196), var(36) := -21
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2910, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(4) >= 0
moveType = I

[State 2910, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
