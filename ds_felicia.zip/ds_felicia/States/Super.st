; _________________________________________
;| Felicia by varo_hades                   |
; �����������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<DANCING FLASH>=============================
[StateDef 3000]
type = S
physics = N
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-2 * const(size.xScale)), ceil(-67 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Width]
type = Width
trigger1 = Anim = 1005
value = -3,-3

[State 3000, VarSet]
type = VarSet
trigger1 = Time = 0
var(10) = 2

[State 3000, PosAdd]
type = PosAdd
trigger1 = Anim = 3000 && AnimElemTime(5) = 0
x = 32*Const(size.XScale)

[State 3000, 1]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 1005

[State 3000, PlaySnd]
type = PlaySnd
triggerall = Anim = 1005
trigger1 = AnimElemTime(1) = 0
value = S1000,0
persistent = 0

[State 3000, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 1005 && !(P2StateType = A && P2MoveType != A)
movetype = A

[State 3000, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 1005 && P2StateType = A && P2MoveType != A
trigger2 = Anim != 1005
movetype = I

[State 3000, 2]
type = VelSet
trigger1 = Time = 46
x = 5*Const(Size.XScale)*(5.0/4.0)

[State 3000, 2]
type = VelSet
trigger1 = Time > 46
x = ((Vel X)+.75)*Const(Size.XScale)*(5.0/4.0)
persistent = 1

[State 3000, VelSet]
type = VelSet
triggerall = Anim = 1005
trigger1 = Vel X >= 13.5*Const(Size.XScale)*(5.0/4.0)
x = 13.5*Const(Size.XScale)*(5.0/4.0)

[State 3000, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = Anim = 1005 && !NumTarget(9)
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 21 < 7, 7, fvar(11) * 21)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
ID = 9
persistent = 0
p1facing = 1
p2facing = 1
kill = 0

[State 3000, TargetState]
type = TargetState
triggerall = Time > 1
triggerall = P2StateType != A
trigger1 = MoveHit && P2MoveType = H
value = 3805

[State 3000, ChangeState]
type = ChangeState
triggerall = Time > 1
triggerall = NumTarget(9)
triggerall = P2BodyDist X < 16
triggerall = target, StateNo = 3805
trigger1 = MoveHit && P2MoveType = H
value = 3001

[State 3000, ChangeState]
type = ChangeState
triggerall = Time > 1 && Anim = 1005
trigger1 = MoveGuarded
value = 1406

[State 3000, VelSet]
type = VelSet
trigger1 = Time = 88 && !MoveContact
x = 0

[State 3000, ChangeState]
type = ChangeState
trigger1 = Time = 88 && !MoveContact
value = 1305

[State 3000, Dust Helper]
type = Helper
trigger1 = Time = 46
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

;Conect
[Statedef 3001]
type = S
physics = N
movetype = A
anim = 3010
velset = 0,0
ctrl = 0
sprpriority = 2

[State 3001, Width]
type = Width
trigger1 = 1
edge = 30,30

[State 3001, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3001, TargetBind]
type = TargetBind
trigger1 = Time = 0
pos = 40,0

[State 3001, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3010 && AnimElem = 6
trigger2 = Anim = 3011 && AnimElem = 4
trigger3 = Anim = 3012 && AnimElem = 3
trigger4 = Anim = 3013 && AnimElem = 4
value = S1,0
channel = 1

[State 3001, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3014 && AnimElem = 3
value = S1,3
channel = 1

[State 3001, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3015 && AnimElem = 3
value = S1,1
channel = 1

[State 3001, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3016 && AnimElem = 4
value = S1,4
channel = 1

[State 3001, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3017 && AnimElem = 3
value = S1,5
channel = 1

[State 3001, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3010
trigger2 = Anim = 3011
trigger3 = Anim = 3012
trigger4 = Anim = 3013
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 21 < 7, 7, fvar(11) * 21)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,8
guard.pauseTime = 2,8
animType = Light
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3001, HitDef 2]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3015
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,8
guard.pauseTime = 2,8
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3001, HitDef 3]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3014
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,8
guard.pauseTime = 2,8
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -84
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3001, HitDef 4]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3016
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,11
guard.pauseTime = 2,11
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3001, HitDef 5]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3017
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 21 < 7, 7, fvar(11) * 21)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,11
guard.pauseTime = 2,11
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3001, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 3014 && AnimTime = 0
value = 3040

[State 3001, ChangeAnim]
type = ChangeAnim
triggerall = (Var(0)&32) > 0
trigger1 = Anim = 3040 && AnimElemTime(7) >= 0
value = 3041

[State 3001, PlaySnd]
type = PlaySnd
triggerall = Anim = 3040
trigger1 = AnimElemTime(1) = 1
value = S1000,2
persistent = 0
channel = 0

[State 3001, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3041 && AnimElemTime(7) = 0
value = S1000,1
channel = 0

[State 3001, VelSet]
type = VelSet
triggerall = Anim = 3040
trigger1 = AnimElemTime(2) = 0
x = 8*Const(Size.XScale)*(5.0/4.0)
y = -11*Const(Size.YScale)*(5.0/4.0)

[State 3001, VelAdd]
type = VelAdd
trigger1 = Anim = 3040 && AnimElemTime(2) > 0
trigger2 = Anim = 3041 && AnimElemTime(13) > 0
x = ifElse(Vel X <= 0,0,-0.34375)*Const(Size.XScale)*(25.0/16.0)
y = .5*Const(Size.YScale)*(25.0/16.0)

[State 3001, VelSet]
type = VelSet
trigger1 = Anim = 3040 && AnimElemTime(2) > 0 && Vel X <= 0
x = 0

[State 3001, HitDef 6]
type = HitDef
trigger1 = !var(16) && var(15) < 5
triggerall = Anim = 3040
trigger1 = AnimElem = 3
attr = A, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 63 < 7, 7, fvar(11) * 63)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 8,8
guard.pauseTime = 8,8
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3001, HitDef 7]
type = HitDef
trigger1 = !var(16) && var(15) < 6
triggerall = Anim = 3040
trigger1 = AnimElem = 4
attr = A, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 8,8
guard.pauseTime = 8,8
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 1

[State 3001, HitDef 8]
type = HitDef
trigger1 = !var(16) && var(15) < 7
triggerall = Anim = 3041
trigger1 = AnimElem = 11
attr = A, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 7,8
guard.pauseTime = 7,8
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -12, 16.125
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -12, 16.125
air.cornerPush.velOff = 0
yAccel = 0.125*(25.0/16.0)
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 1

[State 3001, ChangeAnim]
type = ChangeAnim
triggerall = Anim < 3017
trigger1 = MoveContact && AnimTime = 0
value = anim+1

[State 3001, MoveHitReset]
type = MoveHitReset
triggerall = Anim <= 3017
trigger1 = AnimElemTime(1) = 0

[State 3001, Play Anim]
type = ChangeAnim
triggerall = HitPauseTime = [1,2]
trigger1 = Anim = 3010
trigger1 = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
trigger2 = Anim = 3012
trigger2 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
value = anim
elem = ifElse(Anim=3010, 7, 4)
ignorehitpause = 1

[State 3001, VelSet]
type = VelSet
triggerall = Anim = 3041
trigger1 = AnimElemTime(13) < 0
x = 0
y = 0

[State 3001, ChangeState]
type = ChangeState
triggerall = Anim <= 3017
trigger1 = AnimTime = 0
value = 0
ctrl = 1

[State 3001, ChangeState]
type = ChangeState
triggerall = Pos Y + Vel Y >= 0
trigger1 = Anim = 3040 && AnimElemTime(6) > 0
trigger2 = Anim = 3041
value = 1305

;========================<MAX DANCING FLASH>=============================
[StateDef 3050]
type = S
physics = N
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3050, SuperPause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-2 * const(size.xScale)), ceil(-67 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3050, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3050, Width]
type = Width
trigger1 = Anim = 1005
value = -3,-3

[State 3050, VarSet]
type = VarSet
trigger1 = Time = 0
var(10) = 2

[State 3050, PosAdd]
type = PosAdd
trigger1 = Anim = 3000 && AnimElemTime(5) = 0
x = 32*Const(size.XScale)

[State 3050, 1]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 1005

[State 3050, PlaySnd]
type = PlaySnd
triggerall = Anim = 1005
trigger1 = AnimElemTime(1) = 0
value = S1000,0
persistent = 0

[State 3050, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 1005 && !(P2StateType = A && P2MoveType != A)
movetype = A

[State 3050, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 1005 && P2StateType = A && P2MoveType != A
trigger2 = Anim != 1005
movetype = I

[State 3050, 2]
type = VelSet
trigger1 = Time = 46
x = 5*Const(Size.XScale)*(5.0/4.0)

[State 3050, 2]
type = VelSet
trigger1 = Time > 46
x = ((Vel X)+.75)*Const(Size.XScale)*(5.0/4.0)
persistent = 1

[State 3050, VelSet]
type = VelSet
triggerall = Anim = 1005
trigger1 = Vel X >= 13.5*Const(Size.XScale)*(5.0/4.0)
x = 13.5*Const(Size.XScale)*(5.0/4.0)

[State 3050, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = Anim = 1005 && !NumTarget(9)
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 21 < 7, 7, fvar(11) * 21)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
ID = 9
persistent = 0
p1facing = 1
p2facing = 1
kill = 0

[State 3050, TargetState]
type = TargetState
triggerall = Time > 1
triggerall = P2StateType != A
trigger1 = MoveHit && P2MoveType = H
value = 3805

[State 3050, ChangeState]
type = ChangeState
triggerall = Time > 1
triggerall = NumTarget(9)
triggerall = P2BodyDist X < 16
triggerall = target, StateNo = 3805
trigger1 = MoveHit && P2MoveType = H
value = 3051

[State 3050, ChangeState]
type = ChangeState
triggerall = Time > 1 && Anim = 1005
trigger1 = MoveGuarded
value = 1406

[State 3050, VelSet]
type = VelSet
trigger1 = Time = 88 && !MoveContact
x = 0

[State 3050, ChangeState]
type = ChangeState
trigger1 = Time = 88 && !MoveContact
value = 1305

[State 3050, Dust Helper]
type = Helper
trigger1 = Time = 46
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

;Conect
[Statedef 3051]
type = S
physics = N
movetype = A
anim = 3010
velset = 0,0
ctrl = 0
sprpriority = 2

[State 3051, Width]
type = Width
trigger1 = 1
edge = 30,30

[State 3051, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3051, TargetBind]
type = TargetBind
trigger1 = Time = 0
pos = 40,0

[State 3001, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3010 && AnimElem = 6
trigger2 = Anim = 3011 && AnimElem = 4
trigger3 = Anim = 3012 && AnimElem = 3
trigger4 = Anim = 3013 && AnimElem = 4
value = S1,0
channel = 1

[State 3051, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3014 && AnimElem = 3
value = S1,3
channel = 1

[State 3051, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3015 && AnimElem = 3
value = S1,1
channel = 1

[State 3051, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3016 && AnimElem = 4
value = S1,4
channel = 1

[State 3051, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3017 && AnimElem = 3
value = S1,5
channel = 1

[State 3051, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3010
trigger2 = Anim = 3011
trigger3 = Anim = 3012
trigger4 = Anim = 3013
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 21 < 7, 7, fvar(11) * 21)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,8
guard.pauseTime = 2,8
animType = Light
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3051, HitDef 2]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3015
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,8
guard.pauseTime = 2,8
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3051, HitDef 3]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3014
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,8
guard.pauseTime = 2,8
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -84
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3051, HitDef 4]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3016
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,11
guard.pauseTime = 2,11
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3051, HitDef 5]
type = HitDef
trigger1 = !var(16) && var(15) < 1
triggerall = !MoveContact
trigger1 = Anim = 3017
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 21 < 7, 7, fvar(11) * 21)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,11
guard.pauseTime = 2,11
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3051, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 3017 && AnimTime = 0
value = 3040

[State 3051, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 3040 && AnimElemTime(7) >= 0
value = 3041

[State 3051, PlaySnd]
type = PlaySnd
triggerall = Anim = 3040
trigger1 = AnimElemTime(1) = 1
value = S1000,2
persistent = 0
channel = 0

[State 3051, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3041 && AnimElemTime(7) = 0
value = S1000,1
channel = 0

[State 3051, VelSet]
type = VelSet
triggerall = Anim = 3040
trigger1 = AnimElemTime(2) = 0
x = 8*Const(Size.XScale)*(5.0/4.0)
y = -11*Const(Size.YScale)*(5.0/4.0)

[State 3051, VelAdd]
type = VelAdd
trigger1 = Anim = 3040 && AnimElemTime(2) > 0
trigger2 = Anim = 3041 && AnimElemTime(13) > 0
x = ifElse(Vel X <= 0,0,-0.34375)*Const(Size.XScale)*(25.0/16.0)
y = .5*Const(Size.YScale)*(25.0/16.0)

[State 3051, VelSet]
type = VelSet
trigger1 = Anim = 3040 && AnimElemTime(2) > 0 && Vel X <= 0
x = 0

[State 3051, HitDef 6]
type = HitDef
trigger1 = !var(16) && var(15) < 5
triggerall = Anim = 3040
trigger1 = AnimElem = 3
attr = A, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 63 < 7, 7, fvar(11) * 63)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 8,8
guard.pauseTime = 8,8
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -2.96875, -7.53125
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -2.96875, -7.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3051, HitDef 7]
type = HitDef
trigger1 = !var(16) && var(15) < 6
triggerall = Anim = 3040
trigger1 = AnimElem = 4
attr = A, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 2,8
guard.pauseTime = 2,8
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -0.96875, -8.53125
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -0.96875, -8.53125
air.cornerPush.velOff = 0
yAccel = .46875
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3051, HitDef 8]
type = HitDef
trigger1 = !var(16) && var(15) < 7
triggerall = Anim = 3041
trigger1 = AnimElem = 11
attr = A, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 7,8
guard.pauseTime = 7,8
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -12, 16.125
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -12, 16.125
air.cornerPush.velOff = 0
yAccel = 0.125*(25.0/16.0)
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8017)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -56
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 1

[State 3051, ChangeAnim]
type = ChangeAnim
triggerall = Anim < 3017
trigger1 = MoveContact && AnimTime = 0
value = anim+1

[State 3051, MoveHitReset]
type = MoveHitReset
triggerall = Anim <= 3017
trigger1 = AnimElemTime(1) = 0

[State 3051, Play Anim]
type = ChangeAnim
triggerall = HitPauseTime = [1,2]
trigger1 = Anim = 3010
trigger1 = AnimElemTime(6) >= 0 && AnimElemTime(7) < 0
trigger2 = Anim = 3012
trigger2 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
value = anim
elem = ifElse(Anim=3010, 7, 4)
ignorehitpause = 1

[State 3051, VelSet]
type = VelSet
triggerall = Anim = 3041
trigger1 = AnimElemTime(13) < 0
x = 0
y = 0

[State 3051, ChangeState]
type = ChangeState
triggerall = Anim <= 3017
trigger1 = AnimTime = 0
value = 0
ctrl = 1

[State 3051, ChangeState]
type = ChangeState
triggerall = Pos Y + Vel Y >= 0
trigger1 = Anim = 3040 && AnimElemTime(6) > 0
trigger2 = Anim = 3041
value = 1305

;========================<KITTY'S THE HELPER>=============================
[StateDef 3100]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-7 * const(size.xScale)), ceil(-24 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, VarSet]
type = VarSet
trigger1 = AnimElemTime(7) < 0
var(43) = 360

[State 3100, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(2) = 0
value = S3100,0
channel = 0

[State 3100, Helper]
type = Helper
trigger1 = !numHelper(3207)
helpertype = Normal
name = "Alto"
ID = 3207
stateno = 3300
pos = -32,0
postype = Back
facing = 1
keyctrl = 0
ownpal = 1
size.XScale = Const(size.XScale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3100, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Kitty the Helper (END)
[Statedef 3105]
type = S
physics = S
movetype = I
anim = 3100
ctrl = 0
velset = 0,0
sprpriority = 2

[State 3105, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<MAX KITTI'S THE HELPER>=============================
[StateDef 3150]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3150, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3150, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-7 * const(size.xScale)), ceil(-24 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3150, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3150, VarSet]
type = VarSet
trigger1 = AnimElemTime(7) < 0
var(43) = 720

[State 3150, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(2) = 0
value = S3100,0
channel = 0

[State 3150, Helper]
type = Helper
trigger1 = !numHelper(3207)
helpertype = Normal
name = "Alto"
ID = 3207
stateno = 3300
pos = -32,0
postype = Back
facing = 1
keyctrl = 0
ownpal = 1
size.XScale = Const(size.XScale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3150, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<PLEASE HELP ME!>=============================
[StateDef 3200]
type = S
physics = S
moveType = I
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3200, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" && command = "b"), 0, ifElse((command = "a" && command = "c"), 1, 2))

[State 3200, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(3 * const(size.xScale)), ceil(-70 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = !Time
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, VarSet]
type = VarSet
trigger1 = !Time
fvar(12) = 0

[State 3200, Helper]
type = Helper
triggerall = !Var(10)
trigger1 = Time = 1
helpertype = Normal
name = "Pico"
ID = 3203
stateno = 3203
pos = -42,0
postype = Back
facing = 1
keyctrl = 0
ownpal = 1
size.xscale = Const(size.xscale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3200, Helper]
type = Helper
triggerall = Var(10)
trigger1 = Time = 1
helpertype = Normal
name = "Nana,Mimi"
ID = 3206
stateno = 3206
pos = -48,ifElse(Var(10)=1,-120,-35)
postype = Back
facing = 1
keyctrl = 0
ownpal = 1
size.xscale = Const(size.xscale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 3200, ChangeAnim]
type = ChangeAnim
trigger1 = FVar(12)
value = 3201
persistent = 0

[State 3200, ChangeAnim]
type = ChangeAnim
trigger1 = FVar(12) = 2
value = 3202
persistent = 0

[State 3200, PlaySnd]
type = PlaySnd
trigger1 = Anim = 3202 && AnimElemTime(2) = 0
value = S3200,1
channel = 0
persistent = 0

[State 3200, PlaySnd]
type = PlaySnd
trigger1 = Anim= 3202 && AnimElemTime(20) = 0
value = S3200,0
channel = 0

[State 3200, ChangeState]
type = ChangeState
triggerall = Time > 4
trigger1 = Anim != 3202 && !numHelper(3203) && !numHelper(3206)
trigger2 = Anim = 3202 && AnimTime = 0
value = 0
ctrl = 1

;Hit by Please Help Me!
[Statedef 3260]
type = S
movetype = H
physics = N
velset = 0,0

[State 3260, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 3203, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3260, 0]
type = PosSet
trigger1 = !Time
y = 0

[State 3260, 1]
type = ChangeAnim
trigger1 = !Time
value = 5000+100000*(Name = "Gill" && AuthorName = "GM" && Facing = -1)

;Player 2
[Statedef 3261]
type = A
movetype = H
physics = N

[State 3261, NHB]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3261, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && SelfAnimExist(7697)
value = 7697

[State 3261, ChangeAnim]
type = ChangeAnim2
trigger1 = !Time && !SelfAnimExist(7697)
value = 3260

[State 3261, ChangeAnim]
type = ChangeAnim
trigger1 = Time = 34
value = ifElse(SelfAnimExist(5061), 5061, 5050)

[State 3261, VelSet]
type = VelSet
trigger1 = Time = 34
x = -4*(5.0/4.0)
y = -4.0625*(5.0/4.0)

[State 3261, VelAdd]
type = VelAdd
trigger1 = Time > 34
y = 0.328125*(25.0/16.0)

[State 3261, ChangeState]
type = SelfState
trigger1 = Time > 34
trigger1 = Pos Y + Vel Y >= 0
value = 5100
