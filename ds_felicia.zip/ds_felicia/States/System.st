; ADD004 BASIC PIEs ReBuilded CNS (18/10/2019)
;==============================================
; This file is Made by PIE.
; there is a backup of this file in the same folder, named "<samename>.a4bk".
; to Restore, use assist tool, or delete this file, then remove ".a4bk" from the neme of backup.
;==============================================

; _________________________________________
;| Felicia by varo_hades                   |
; �����������������������������������������
;==============================================================================================
;=======================================<SYSTEM STATES>========================================
;==============================================================================================

;====================<STANDING>====================
[StateDef 0]
type = S
physics = S
moveType = I
velSet = 0,0
sprPriority = 0

[State 0, Remove Explods]
type = RemoveExplod
trigger1 = IsHelper

[State 0, Destroy Helpers]
type = DestroySelf
trigger1 = IsHelper

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 0 && Anim != 5
trigger2 = Anim = 5 && !AnimTime
value = 0

[State 0, Dead]
type = ChangeState
trigger1 = !Alive
value = 5050

[State 0, Skywalker]
type = ChangeState
triggerall = pos y < 0
trigger1 = !NumEnemy
trigger2 = NumEnemy = 1
trigger2 = (Enemy, Name = "M -NES Game 1" + Enemy, Name = "M -NES Game 2" + Enemy, Name = "M -GB Game 1" + Enemy, AuthorName = "Bane84") < 2
trigger3 = Numenemy >= 2
trigger3 = (Enemy(0), Name = "M -NES Game 1" + Enemy(0), Name = "M -NES Game 2" + Enemy(0), Name = "M -GB Game 1" + Enemy(0), AuthorName = "Bane84") < 2
trigger3 = (Enemy(1), Name = "M -NES Game 1" + Enemy(1), Name = "M -NES Game 2" + Enemy(1), Name = "M -GB Game 1" + Enemy(1), AuthorName = "Bane84") < 2
value = 50



;====================<CROUCHING>====================
;Stand to Crouch
[StateDef 10]
type = C
physics = C
moveType = I
velSet = 0,0
sprPriority = 0

[State 10, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && Anim = 12
value = 10
elem = 3 - AnimElemNo(0)

[State 10, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 10
value = 10

[State 10, End]
type = ChangeState
trigger1 = !AnimTime
value = 11


;Crouching
[StateDef 11]
type = C
physics = C
moveType = I
anim = 11
velSet = 0,0
sprPriority = 0

[State 11, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 6 && !AnimTime
value = 11


;Crouch to Stand
[StateDef 12]
type = S
physics = S
moveType = I
velSet = 0,0
sprPriority = 0

[State 12, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && Anim = 10
value = 12
elem = 3 - AnimElemNo(0)

[State 12, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 12
value = 12

[State 12, End]
type = ChangeState
trigger1 = command = "holddown" && command != "holdup"
value = 10

[State 12, End]
type = ChangeState
trigger1 = !AnimTime
value = 0



;====================<WALKING>====================
[StateDef 20]
type = S
physics = S
moveType = I
sprPriority = 0

[State 20, VelSet]
type = VelSet
trigger1 = command = "holdfwd"
x = const(velocity.walk.fwd.x)

[State 20, VelSet]
type = VelSet
trigger1 = command = "holdback"
x = const(velocity.walk.back.x)

[State 20, ChangeAnim]
type = ChangeAnim
triggerAll = vel x > 0
trigger1 = Anim != 20 && Anim != 5
trigger2 = Anim = 5 && AnimElemTime(1) >= 1
value = 20

[State 20, ChangeAnim]
type = ChangeAnim
triggerAll = vel x < 0
trigger1 = Anim != 21 && Anim != 5
trigger2 = Anim = 5 && AnimElemTime(1) >= 1
value = 21



;====================<JUMPING>====================
;Jumping
[StateDef 40]
type = S
physics = S
moveType = I
anim = 40
ctrl = 0
velSet = 0,0
sprPriority = 1
faceP2 = 1

[State 40, Direction]
type = VarSet
trigger1 = !AILevel
sysvar(1) = ifElse(!Time, 0, ifElse(command = "holdfwd", 1, ifElse(command = "holdback", -1, sysvar(1))))

[State 40, Direction (AI)]
type = VarSet
trigger1 = AILevel
sysvar(1) = ifElse((EnemyNear, MoveType != A || BackEdgeBodyDist <= 10), 1, ifElse((EnemyNear, MoveType = A), -1, 0))

[State 40, High Jump]
type = VarSet
trigger1 = !Time && !AILevel
var(3) = ifElse(command = "highjump", 3, 0)

[State 40, High Jump (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(3) = ifElse((P2BodyDist x >= 160 || Random < (125 * (AILevel ** 2 / 64.0))), 3, 0)

[State 40, High Jump]
type = VarSet
trigger1 = !Time && PrevStateNo = 100
var(3) = 3

[State 40, Low Jump]
type = VarSet
trigger1 = !AILevel && command != "holdup" && (var(3) != [1,2])
var(3) = ifElse((var(3) = 3 && sysvar(1)), 2, 1)

[State 40, Low Jump (AI)]
type = VarSet
trigger1 = AILevel && (var(3) != [1,2])
trigger1 = (EnemyNear, StateType = C) && Random < 500
var(3) = ifElse((var(3) = 3 && sysvar(1)), 2, 1)

[State 40, Jump Sound]
type = PlaySnd
trigger1 = !AnimTime
value = ifElse((var(3) = [2,3]), 41, 40), 0

[State 40, Dust Helper]
type = Helper
trigger1 = !AnimTime
helperType = Normal
stateNo = 8100
ID = 8100
name = "Jump Dust"
posType = P1
ownPal = 1

[State 40, Velocity: Normal Jump]
type = VelSet
trigger1 = !AnimTime
x = ifElse(!sysvar(1), const(velocity.jump.neu.x), ifElse(sysvar(1) = 1, const(velocity.jump.fwd.x), const(velocity.jump.back.x)))
y = const(velocity.jump.y)

[State 40, Velocity: Low Jump]
type = VelSet
trigger1 = !AnimTime && var(3) = 1
x = ifElse(!sysvar(1), const(velocity.jump.neu.x), ifElse(sysvar(1) = 1, const(velocity.jump.fwd.x), const(velocity.jump.back.x)))
y = 0.75 * const(velocity.jump.y)

[State 40, Velocity: Long Low Jump]
type = VelSet
trigger1 = !AnimTime && var(3) = 2
x = ifElse(!sysvar(1), const(velocity.jump.neu.x), ifElse(sysvar(1) = 1, const(velocity.runjump.fwd.x), const(velocity.runjump.back.x)))
y = 0.75 * const(velocity.jump.y)

[State 40, Velocity: Long Jump]
type = VelSet
trigger1 = !AnimTime && var(3) = 3
x = ifElse(!sysvar(1), const(velocity.jump.neu.x), ifElse(sysvar(1) = 1, const(velocity.runjump.fwd.x), const(velocity.runjump.back.x)))
y = ifElse(!sysvar(1), const(velocity.runjump.y), const(velocity.jump.y))

[State 40, End]
type = ChangeState
trigger1 = !AnimTime
value = 50
ctrl = 1


;In Air
[StateDef 50]
type = A
physics = N
moveType = I
sprPriority = 1

[State 50, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(!vel x , 41, ifElse(vel x > 0, 42, 43)) + 10 * (var(3) = [1,2])
persistent = 0

[State 50, Assert: No Guard]
type = AssertSpecial
trigger1 = var(3) = [1,2]
flag = NoAirGuard
ignoreHitPause = 1

[State 50, Grounded Frame]
type = PosFreeze
trigger1 = Time < 1 && PrevStateNo = 40
value = 1

[State 50, Gravity]
type = Gravity
trigger1 = Time >= 1 || PrevStateNo != 40

[State 50, StateTypeSet]
type = StateTypeSet
triggerall = prevStateNo != [600,899]
triggerall = Time
trigger1 = P2StateType = S
trigger1 = Vel Y > 6.0
movetype = A
persistent = 0

[State 50, No Guard]
type = AttackDist
trigger1 = 1
value = 0

[State 50, 1]
type = HitDef
triggerall = P2MoveType != H
triggerall = P2StateNo != [130,155]
;triggerall = P2BodyDist X = [-(24*Const(Size.XScale)),(36*Const(Size.XScale))-Const(Size.Ground.Front)]
triggerall = P2Dist X <= 24; [-24,24]
triggerall = EnemyNear(0), Anim != 5
triggerall = RoundState = 2
trigger1 = NumEnemy = 1
trigger1 = P2BodyDist Y-56 <= EnemyNear(0), Const(Size.Height)
;trigger1 = NumEnemy = 1
;trigger1 = P2BodyDist X <= (36*Const(Size.XScale))-Const(Size.Ground.Front)
;trigger2 = NumEnemy > 1 ; Fuck you, simul
attr = A, ST
hitflag = M-
priority = 3, Miss
sparkno = -1
p1facing = 1
p2facing = 1
p1stateno = 60
p2stateno = 65
ID = 60
guard.dist = 0
numhits = 0
persistent = 0

[State 50, Landing]
type = ChangeState
trigger1 = pos y > -vel y
value = 52


[StateDef 51]
type = A
physics = N
moveType = I
sprPriority = 1

[State 51, Gravity]
type = Gravity
trigger1 = 1

[State 51, Landing]
type = ChangeState
trigger1 = pos y > -vel y
value = 52


;Landing
[StateDef 52]
type = S
physics = S
moveType = I
anim = 47
ctrl = 0
velSet = 0,0
sprPriority = 1

[State 52, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && (var(3) = 1 || var(3) = 2)
trigger1 = (PrevStateNo = [600,699])
value = 57

[State 52, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 52, CtrlSet]
type = CtrlSet
trigger1 = !Time && (PrevStateNo != [600,699])
trigger2 = Time = 1 && Anim != 57
value = 1

[State 52, ChangeState to Guarding]
type = ChangeState
trigger1 = ctrl && command = "holdback"
trigger1 = InGuardDist && (PrevStateNo != [600,699])
value = 120

[State 52, Assert: NoWalk]
type = AssertSpecial
trigger1 = Anim != 5
flag = NoWalk
ignoreHitPause = 1

[State 52, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 1400,0

[State 52, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 52, ChangeAnim to Turning]
type = ChangeAnim
trigger1 = ctrl && P2Dist x < 0
trigger1 = Anim != 5
value = 5

[State 52, Turn]
type = Turn
trigger1 = Anim = 5 && AnimElem = 1

[State 52, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;Cat Ride
[Statedef 60]
type = A
physics = N
movetype = I
anim = 147
ctrl = 1
velset = 0,0

[State 60, PlaySnd]
type = PlaySnd
trigger1 = Time = 0
value = S182,0
channel = 0

[State 60, VarSet]
type = VarSet
trigger1 = NumTarget(60)
var(41) = Target(60),SysVar(0)

[State 60, BindToTarget]
type = BindToTarget
triggerall = NumTarget(60)
trigger1 = !target(60), SelfAnimExist(9545)
trigger2 = !Var(41)
pos = 0, (target(60), Const(Size.head.pos.y)-5),Foot

[State 60, BindToTarget]
type = BindToTarget
triggerall = NumTarget(60) && Var(41)
trigger1 = target(60), SelfAnimExist(9545)
pos = ceil(((var(41)&65535) | ifElse(var(41)&32768,-65536,0)) * target(60),Const(Size.XScale)), ceil((var(41)/65536) * target(60),Const(Size.YScale)), Foot
;pos = ceil(((target(60),sysvar(0)&65535)|ifElse(target(60),sysvar(0)&32768,-65536,0))*target(60),Const(Size.XScale)), ceil((target(60),sysvar(0)/65536)*target(60),Const(Size.YScale)), Foot

[State 60, 1]
type = VarSet
triggerall = !AILevel
triggerall = command = "x" || command = "y" || command = "z" || command = "a" || command = "b" || command = "c" || command = "start" || command = "holdup" || command = "holddown" || command = "holdback" || command = "holdfwd"
trigger1 =  var(3) = 3
sysvar(1) = facing * helper(10371),facing * (((helper(10371), Var(3) = 3) > 0) - ((helper(10371), Var(3) = 3) > 0))

[State 60, 6]
type = VelSet
trigger1 = !NumTarget(60)
x = ifelse(!sysvar(1), 0, ifelse(sysvar(1)=1, const(velocity.jump.fwd.x), const(velocity.jump.back.x)))*(4.0/3.0)*Const(Size.XScale)
y = (const(velocity.jump.y)-ifelse(!sysvar(1), 0, ifelse(sysvar(1)=1, .25, .5)))*(4.0/3.0)
persistent = 0

[State 60, Buffered Jump]
type = ChangeState
triggerall = command = "holdup" || command = "holddown" || command = "holdback" || command = "holdfwd"
triggerall = !AILevel
triggerall = roundstate = 2
triggerall = !isHelper
triggerall = StateNo != 40 ;&& StateNo != 52
trigger1 = statetype != A && statetype != L
trigger1 = Ctrl && (StateNo != [120,132]) && (StateNo != [150,155]) && (StateNo != [700,720])
trigger2 = StateNo = 60 && Time
value = 40

[State 60, ChangeState]
type = ChangeState
trigger1 = !NumTarget(60)
value = 50
ctrl = 1

;Cat Ride (P2)
[Statedef 65]
type = S
movetype = H
physics = N
sprpriority = -1
velset = 0,0
ctrl = 1

[State 148, Command]
type = SelfState
triggerall = Time >= 1
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
trigger3 = command = "start"
trigger4 = command = "holdup" || command = "holddown" || command = "holdback" || command = "holdfwd"
value = 0
ctrl = 1

[State 148, Command]
type = null;SelfState
triggerall = Time >= 1
triggerall = !(AuthorName = "Jesuszilla")
triggerall = !(AuthorName = "N64Mario" && Name = "Zero" && FVar(17) = 1)
triggerall = !(AuthorName = "Vans")
triggerall = !(AuthorName = ".\/.")
triggerall = !(AuthorName = "Neon Tiger")
triggerall = !(AuthorName = "The_None")
triggerall = !(AuthorName = "Most Mysterious")
triggerall = !(AuthorName = "Most Mysterious (also, TN'79)")
triggerall = !(AuthorName = "Warusaki3")
triggerall = !(AuthorName = "H?")
triggerall = !(AuthorName = "David Demianoff")
triggerall = !(AuthorName = "OrochiKOF97")
trigger1 = command = "y"
value = 200

[State 148, Command]
type = null;SelfState
triggerall = Time >= 1
triggerall = command = "y"
trigger1 = (AuthorName = "Jesuszilla" && FVar(17) = 1)
trigger2 = (AuthorName = "N64Mario" && Name = "Zero" && FVar(17) = 1)
trigger3 = (AuthorName = "Vans")
trigger4 = (AuthorName = ".\/.")
trigger5 = (AuthorName = "Neon Tiger")
trigger6 = (AuthorName = "The_None")
trigger7 = (AuthorName = "Most Mysterious")
trigger8 = (AuthorName = "Most Mysterious (also, TN'79)")
trigger9 = (AuthorName = "Warusaki3")
trigger10 = (AuthorName = "H?")
trigger11 = (AuthorName = "David Demianoff")
trigger12 = (AuthorName = "OrochiKOF97")
value = 210

[State 148, Command]
type = null;SelfState
triggerall = Time >= 1
triggerall = !(AuthorName = "Jesuszilla")
triggerall = !(AuthorName = "N64Mario" && Name = "Zero" && FVar(17) = 1)
triggerall = !(AuthorName = "Vans")
triggerall = !(AuthorName = ".\/.")
triggerall = !(AuthorName = "Neon Tiger")
triggerall = !(AuthorName = "The_None")
triggerall = !(AuthorName = "Most Mysterious")
triggerall = !(AuthorName = "Most Mysterious (also, TN'79)")
triggerall = !(AuthorName = "Warusaki3")
triggerall = !(AuthorName = "H?")
triggerall = !(AuthorName = "David Demianoff")
triggerall = !(AuthorName = "OrochiKOF97")
trigger1 = command = "z"
value = 200

[State 148, Command]
type = null;SelfState
triggerall = Time >= 1
triggerall = command = "z"
trigger1 = (AuthorName = "Jesuszilla" && FVar(17) = 1)
trigger2 = (AuthorName = "N64Mario" && Name = "Zero" && FVar(17) = 1)
trigger3 = (AuthorName = "Vans" && FVar(17) = 1)
trigger4 = (AuthorName = ".\/." && FVar(17) = 1)
trigger5 = (AuthorName = "Neon Tiger")
trigger6 = (AuthorName = "The_None")
trigger7 = (AuthorName = "Most Mysterious")
trigger8 = (AuthorName = "Most Mysterious (also, TN'79)")
trigger9 = (AuthorName = "Warusaki3" && FVar(39) = 1)
trigger10 = (AuthorName = "H?" && Name = "cvsiori")
trigger11 = (AuthorName = "H?" && Name = "cvsmaki")
trigger12 = (AuthorName = "H?" && Name = "cvsraiden")
trigger13 = (AuthorName = "H?" && Name = "cvskyosuke")
trigger14 = (AuthorName = "H?" && Name = "cvsvega")
trigger15 = (AuthorName = "H?" && Name = "cvsmai")
value = 220

[State 148, Command]
type = null;SelfState
triggerall = Time >= 1
trigger1 = command = "a"
value = 230

[State 148, Command]
type = null;SelfState
triggerall = Time >= 1
triggerall = !(AuthorName = "Jesuszilla")
triggerall = !(AuthorName = "N64Mario" && Name = "Zero" && FVar(17) = 1)
triggerall = !(AuthorName = "Vans")
triggerall = !(AuthorName = ".\/.")
triggerall = !(AuthorName = "Neon Tiger")
triggerall = !(AuthorName = "The_None")
triggerall = !(AuthorName = "Most Mysterious")
triggerall = !(AuthorName = "Most Mysterious (also, TN'79)")
triggerall = !(AuthorName = "Warusaki3")
triggerall = !(AuthorName = "H?")
triggerall = !(AuthorName = "David Demianoff")
triggerall = !(AuthorName = "OrochiKOF97")
trigger1 = command = "b"
value = 230

[State 148, Command]
type = null;SelfState
triggerall = Time >= 1
triggerall = command = "b"
trigger1 = (AuthorName = "Jesuszilla" && FVar(17) = 1)
trigger2 = (AuthorName = "N64Mario" && Name = "Zero" && FVar(17) = 1)
trigger3 = (AuthorName = "Vans")
trigger4 = (AuthorName = ".\/.")
trigger5 = (AuthorName = "Neon Tiger")
trigger6 = (AuthorName = "The_None")
trigger7 = (AuthorName = "Most Mysterious")
trigger8 = (AuthorName = "Most Mysterious (also, TN'79)")
trigger9 = (AuthorName = "Warusaki3")
trigger10 = (AuthorName = "H?")
trigger11 = (AuthorName = "David Demianoff")
trigger12 = (AuthorName = "OrochiKOF97")
value = 240

[State 148, Command]
type = null;SelfState
triggerall = Time >= 1
triggerall = !(AuthorName = "Jesuszilla")
triggerall = !(AuthorName = "N64Mario" && Name = "Zero" && FVar(17) = 1)
triggerall = !(AuthorName = "Vans")
triggerall = !(AuthorName = ".\/.")
triggerall = !(AuthorName = "Neon Tiger")
triggerall = !(AuthorName = "The_None")
triggerall = !(AuthorName = "Most Mysterious")
triggerall = !(AuthorName = "Most Mysterious (also, TN'79)")
triggerall = !(AuthorName = "Warusaki3")
triggerall = !(AuthorName = "H?")
triggerall = !(AuthorName = "David Demianoff")
triggerall = !(AuthorName = "OrochiKOF97")
trigger1 = command = "c"
value = 230

[State 148, Command]
type = null;SelfState
triggerall = Time >= 1
triggerall = command = "c"
trigger1 = (AuthorName = "Jesuszilla" && FVar(17) = 1)
trigger2 = (AuthorName = "N64Mario" && Name = "Zero" && FVar(17) = 1)
trigger3 = (AuthorName = "Vans" && FVar(17) = 1)
trigger4 = (AuthorName = ".\/." && FVar(17) = 1)
trigger5 = (AuthorName = "Neon Tiger")
trigger6 = (AuthorName = "The_None")
trigger7 = (AuthorName = "Most Mysterious")
trigger8 = (AuthorName = "Most Mysterious (also, TN'79)")
trigger9 = (AuthorName = "Warusaki3" && FVar(39) = 1)
trigger10 = (AuthorName = "H?" && Name = "cvsiori")
trigger11 = (AuthorName = "H?" && Name = "cvsmaki")
trigger12 = (AuthorName = "H?" && Name = "cvsraiden")
trigger13 = (AuthorName = "H?" && Name = "cvskyosuke")
trigger14 = (AuthorName = "H?" && Name = "cvsvega")
trigger15 = (AuthorName = "H?" && Name = "cvsmai")
value = 250

[State 0, Helper]
type = null;Helper
triggerall = !NumHelper(14324)
trigger1 = !Time
helpertype = normal ;player
name = "negative one"
ID = 14324
stateno = -1
pos = 65535,65535
postype = p1    ;p2,front,back,left,right
facing = 1
keyctrl = 1
ownpal = 1
supermove = 65535
pausemove = 65535

[State 50, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 148, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 148, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = NoWalk

[State 65, ChangeAnim2]
type = ChangeAnim
triggerall = SelfAnimExist(9545)
trigger1 = Time = 0
value = 9545

[State 65, ChangeAnim2]
type = ChangeAnim
trigger1 = !SelfAnimExist(9545)
value = 5010

;Cat Ride (P2)
[Statedef 66]
type = S
movetype = H
physics = N
sprpriority = -1
velset = 0,0
ctrl = 1

[State 66, SelfState]
type = SelfState
trigger1 = !Time
value = 0
ctrl = 1

;Wall Cling (back)
[Statedef 88]
type = A
physics = N
movetype = I
velset = 0,0
ctrl = 0

[State 88, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = 871

[State 88, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = NoAutoTurn

[State 88, PlaySnd]
type = PlaySnd
trigger1 = Time = 0
value = S181,0

[State 88, PlaySnd]
type = PlaySnd
trigger1 = Anim = 881
value = S88,0
channel=1
persistent = 0

[State 88, ChangeState]
type = ChangeState
triggerall = Time > 0
trigger1 = command != "holdback"
trigger2 = Pos Y >= -37
trigger3 = backedgebodydist > 4
value = 812

[State 88, ChangeAnim]
type = ChangeAnim
triggerall = Anim = 871
trigger1 = AnimTime = 0
trigger2 = command = "holddown"
value = 881
persistent = 0

[State 88, PosAdd]
type = PosAdd
trigger1 = 1;Anim = [860,866]
x = -(ScreenPos X + 7)

[State 88, PosAdd]
type = PosAdd
triggerall = Pos Y < -37
trigger1 = Anim = [880,886]
y = 1.5

[State 88, ChangeAnim]
type = ChangeAnim
trigger1 = Time = 75
value = 881
persistent = 0

;Wall Cling (forward)
[Statedef 89]
type = A
physics = N
movetype = I
velset = 0,0
ctrl = 0

[State 88, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = 870

[State 89, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = NoAutoTurn
flag2 = NoAirGuard

[State 89, PlaySnd]
type = PlaySnd
trigger1 = Time = 0
value = S181,0

[State 89, PlaySnd]
type = PlaySnd
trigger1 = Anim = 880
value = S88,0
channel=1
persistent = 0

[State 89, ChangeState]
type = ChangeState
triggerall = Time > 0
trigger1 = command != "holdfwd"
trigger2 = Pos Y >= -37
trigger3 = frontedgebodydist > 4
value = 812

[State 89, ChangeAnim]
type = ChangeAnim
triggerall = Anim = 870
trigger1 = AnimTime = 0
trigger2 = command = "holddown"
value = 880

[State 89, PosAdd]
type = PosAdd
trigger1 = 1;Anim = [880,886]
x = (ScreenPos X + 7)

[State 89, PosAdd]
type = PosAdd
triggerall = Pos Y < -37
trigger1 = Anim = [880,886]
y = 1

[State 89, PosAdd]
type = PosAdd
triggerall = Anim = 880
trigger1 = !Time
x = 3

[State 89, ChangeAnim]
type = ChangeAnim
trigger1 = Time = 75
value = 880
persistent = 0

;======================<RUN>===========================
[StateDef 100]
type = S
physics = N
moveType = I
anim = 100
ctrl = 0
sprPriority = 1

[State 100, VelSet]
type = VelSet
trigger1 = 1
x = const(velocity.run.fwd.x)

[State 100, Step Sound]
type = PlaySnd
trigger1 = (AnimElem = 1 || AnimElem = 3 || AnimElem = 6)
value = 100, ifElse((AnimElem = 1 || AnimElem = 6), 0, 1)

[State 100, Jump]
type = ChangeState
trigger1 = !AILevel
trigger1 = command = "holdfwd" && command = "holdup"
value = 40

[State 100, Jump (AI)]
type = ChangeState
trigger1 = AILevel && Random < 25
value = 40

[State 100, End]
type = ChangeState
trigger1 = !AILevel && command != "holdfwd"
trigger2 = AILevel && P2BodyDist x <= 90
value = 101


;Stop Running
[StateDef 101]
type = S
physics = S
moveType = I
anim = 101
ctrl = 0
sprPriority = 1

[State 101, Stopping Sound]
type = PlaySnd
trigger1 = !Time
value = 101,0

[State 101, Skid Dust]
type = Explod
trigger1 = !Time
anim = 8104
sprPriority = 3
posType = P1
pos = 0,0
vel = 0,0
scale = 0.5,0.5
pauseMovetime = -1
superMoveTime = -1
ownpal = 1

[State 101, Jump]
type = ChangeState
trigger1 = !AILevel && command = "holdup"
value = 40

[State 101, End]
type = ChangeState
trigger1 = !AnimTime
value = ifElse(command = "holddown", 10, 0)
ctrl = 1



;========================<DASH BACKWARDS>==========================
[StateDef 105]
type = A
physics = N
moveType = I
velSet = 0,0
anim = 105
ctrl = 0
sprPriority = 1

[State 105, Back Dash Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 105,0

[State 105, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = -7
y = -5

[State 105, VelMul]
type = VelMul
trigger1 = AnimElemTime(2) > 0
x = 0.98

[State 105, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(2) > 0
y = 0.65

[State 105, End]
type = ChangeState
trigger1 = AnimElemTime(2) >= 0
trigger1 = pos y > -vel y
value = 106


;Stop Dashing Backwards
[StateDef 106]
type = S
physics = S
ctrl = 0
anim = 106
velSet = 0,0

[State 106, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 106, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 100,1

[State 106, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprpriority = -3
postype = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 106, CtrlSet]
type = CtrlSet
trigger1 = Time >= 2
value = 1

[State 106, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1



;=================<DASH FORWARD>=================
[StateDef 110]
type = A
physics = N
moveType = I
anim = 110
ctrl = 0
sprPriority = 1

[State 110, Dash Sound]
type = PlaySnd
trigger1 = !Time
value = 110,0

[State 110, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 110, VarSet -> Running]
type = VarSet
trigger1 = !Time
sysvar(1) = 1

[State 110, VarSet -> Not Running]
type = VarSet
triggerAll = AnimElemTime(2) < 0
trigger1 = !AILevel && command != "holdfwd"
sysvar(1) = 0

[State 110, ChangeState to Running]
type = ChangeState
trigger1 = AnimElemTime(2) = 0 && sysvar(1)
value = 100

[State 110, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 9
y = -4

[State 110, VelMul]
type = VelMul
trigger1 = AnimElemTime(2) > 0
x = 0.98

[State 110, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(2) > 0
y = 0.65

[State 110, End]
type = ChangeState
trigger1 = AnimElemTime(2) >= 0
trigger1 = pos y > -vel y
value = 111


;Stop Dashing Forward
[StateDef 111]
type = S
physics = S
ctrl = 1
anim = 111
velSet = 0,0

[State 111, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 111, Dash End Sound]
type = PlaySnd
trigger1 = !Time
value = 100,0

[State 111, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
pos = ceil(16 * const(size.xScale)),0
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 111, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1



;====================<DODGE>====================
[StateDef 700]
type = S
physics = S
moveType = I
anim = 700
ctrl = 0
velSet = 0,0
sprPriority = -2

[State 700, Voice]
type = PlaySnd
trigger1 = !Time
value = 4,0
channel = 0

[State 700, Dodge Sound]
type = PlaySnd
trigger1 = !Time
value = 1,3
channel = 1

[State 700, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignoreHitPause = 1

[State 700, HitBy]
type = HitBy
trigger1 = 1
value = SCA,AT
time = 1

[State 700, Attack]
type = ChangeState
trigger1 = !AILevel && Time = [15,25]
trigger1 = command = "x" || command = "y" || command = "z" || command = "a" || command = "b" || command = "c"
value = ifElse((command = "x" || command = "y" || command = "z"), 220, 240)

[State 700, Attack (AI)]
type = ChangeState
trigger1 = AILevel && (Time = [15,25]) && NumEnemy
trigger1 = (EnemyNear, MoveType != A) && (P2BodyDist x = [-60,60]) && (P2Dist y >= -60)
value = ifElse(Random < 666, 220, 240)

[State 700, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1



;================<ROLL FORWARD>================
[StateDef 710]
type = S
physics = N
moveType = I
anim = 710
ctrl = 0
velSet = 0,0
sprPriority = 1

[State 710, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignoreHitPause = 1

[State 710, HitBy]
type = HitBy
trigger1 = AnimElemTime(7) < 0
value = SCA,AT
time = 1

[State 710, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 1, 0)
channel = 0

[State 710, Roll Sound]
type = PlaySnd
trigger1 = Time = 1
value = 110,0
channel = 1

[State 710, Start Roll]
type = VelSet
trigger1 = AnimElem = 3
x = 8

[State 710, End Roll]
type = VelSet
trigger1 = AnimElem = 11
x = 0

[State 710, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1



;===============<ROLL BACKWARDS>===============
[StateDef 715]
type = S
physics = N
moveType = I
anim = 715
ctrl = 0
velSet = 0,0
sprPriority = 1

[State 715, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignoreHitPause = 1

[State 715, HitBy]
type = HitBy
trigger1 = AnimElemTime(7) < 0
value = SCA,AT
time = 1

[State 715, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 1, 0)
channel = 0

[State 715, Roll Sound]
type = PlaySnd
trigger1 = Time = 1
value = 110,0
channel = 1

[State 715, Start Roll]
type = VelSet
trigger1 = AnimElem = 3
x = -8

[State 715, End Roll]
type = VelSet
trigger1 = AnimElem = 11
x = 0

[State 715, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1



;==========<POWER CHARGE>==========
[StateDef 730]
type = S
physics = S
moveType = I
anim = 730
velSet = 0,0
ctrl = 0

[State 730, PowerAdd]
type = PowerAdd
triggerAll = Power < const(data.power) && Power < PowerMax
trigger1 = !AILevel && (command = "holdb" && command = "holdy")
trigger2 = AILevel
value = 2 + ifElse(time < 60, 0, (time - 60) / 12)

[State 730, Voice]
type = PlaySnd
trigger1 = !Time
value = 196,1
channel = 0

[State 730, Character Flash]
type = PalFX
trigger1 = 1
time = 1
add = 75 + ceil(sin(Time / 6.0 * pi) * 75),25 + ceil(sin(Time / 6.0 * pi) * 25),0

[State 730, Power Charge Helper]
type = Helper
trigger1 = !NumHelper(8330)
helperType = Normal
stateNo = 8330
ID = 8330
name = "Power Charge"
posType = P1
pauseMoveTime = 65535
superMoveTime = 65535
ownPal = 1

[State 730, Particles]
type = Helper
trigger1 = !NumHelper(8331)
helperType = Normal
stateNo = 8331
ID = 8331
name = "Particles"
postype = P1
pauseMoveTime = 65535
superMoveTime = 65535
ownPal = 1

[State 730, End]
type = ChangeState
trigger1 = Power >= const(data.power) || Power >= PowerMax || RoundState != 2
trigger2 = !AILevel && (command != "holdb" || command != "holdy")
trigger3 = AILevel && (InGuardDist || P2BodyDist x <= 120)
value = 731
ctrl = 1


;Power Charge End
[StateDef 731]
type = S
physics = S
moveType = I
anim = 731
velSet = 0,0
ctrl = 1

[State 731, StopSnd]
type = StopSnd
trigger1 = !Time
channel = 0

[State 730, Full Power Voice]
type = PlaySnd
trigger1 = !Time && Power >= const(data.power)
value = 900,1
channel = 0
persistent = 0

[State 730, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;====================<ZERO COUNTER>====================
[StateDef 750]
type = S
physics = S
moveType = I
anim = 750
velSet = 0,0
ctrl = 0
sprPriority = 2
powerAdd = -1000
faceP2 = 1

[State 750, Button]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = (command = "412k")
ignoreHitPause = 1

[State 750, Button (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2StateType = A), 0, ifElse((P2StateType = C), 1, ifElse(Random < 500, 0, 1)))
ignoreHitPause = 1

[State 750, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 750, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 750, Voice]
type = PlaySnd
trigger1 = !Time
value = 4,2
channel = 0

[State 750, Zero Counter FX Helper]
type = Helper
trigger1 = !Time
helperType = Normal
stateNo = 8350
ID = 8350
name = "Zero Counter"
posType = P1
pos = ceil(-20 * const(size.xScale)), ceil(-57 * const(size.yScale))
superMoveTime = 255
ownPal = 1

[State 750, SuperPause]
type = SuperPause
trigger1 = !Time
time = 15
moveTime = 15
p2DefMul = 1
anim = -1
sound = s750,0
darken = 0

[State 750, End]
type = ChangeState
trigger1 = Time >= 15
value = ifElse(var(10) = 1, 2910, 2900)



;====================<PARRY>====================
;Standing Parry
[StateDef 760]
type = S
physics = S
moveType = I
anim = 760
velSet = 0,0
ctrl = 0
sprPriority = 2
powerAdd = 78
faceP2 = 1

[State 760, HitBy]
type = HitBy
trigger1 = 1
value = SCA,AT
time = 1

[State 760, Pause]
type = Pause
trigger1 = !Time
time = 15
moveTime = 15
endCmdBufTime = 15
pauseBg = 0

[State 760, Stop]
type = PosFreeze
trigger1 = 1
value = 1

[State 760, No Walking]
type = VarSet
trigger1 = 1
var(26) = 7

[State 760, Voice]
type = PlaySnd
trigger1= !Time
value = 4,2
channel = 0

[State 760, Parry Sound]
type = PlaySnd
trigger1 = !Time
value = 760,0
channel = 1

[State 760, Player Flash]
type = PalFX
trigger1 = !Time
add = 0,64,255
sinadd = 0,-64,-255,60
time = 15

[State 760, FX]
type = Explod
trigger1 = !Time
anim = 8360
sprPriority = 5
posType = P1
pos = ceil(50 * const(size.xscale)), ceil(-65 * const(size.yscale))
pauseMoveTime = -1
superMoveTime = -1
scale = 0.5,0.5
ownPal = 1

[State 760, EnvShake]
type = EnvShake
trigger1 = !Time
time = 0
ampl = 0

[State 760, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;Crouching Parry
[StateDef 761]
type = C
physics = C
moveType = I
anim = 761
velSet = 0,0
ctrl = 0
sprPriority = 2
powerAdd = 78
faceP2 = 1

[State 761, HitBy]
type = HitBy
trigger1 = 1
value = SCA,AT
time = 1

[State 761, Pause]
type = Pause
trigger1 = !Time
time = 15
moveTime = 15
endCmdBufTime = 15
pauseBg = 0

[State 761, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 761, No Walk]
type = VarSet
trigger1 = 1
var(26) = 7

[State 761, Voice]
type = PlaySnd
trigger1 = !Time
value = 4,2
channel = 0

[State 761, Parry Sound]
type = PlaySnd
trigger1 = !Time
value = 760,0
channel = 1

[State 761, Player Flash]
type = PalFX
trigger1 = !Time
add = 0,64,255
sinAdd = 0,-64,-255,60
time = 15

[State 761, Parry FX]
type = Explod
trigger1 = !Time
anim = 8360
sprpriority = 5
postype = P1
pos = ceil(45 * const(size.xscale)), ceil(-35 * const(size.yscale))
pauseMovetime = -1
superMovetime = -1
scale = 0.5,0.5
ownpal = 1

[State 761, EnvShake]
type = EnvShake
trigger1 = !time
time = 0
ampl = 0

[State 761, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1


;Jumping Parry
[StateDef 762]
type = A
physics = N
moveType = I
anim = 762
ctrl = 0
sprPriority = 2
powerAdd = 78
faceP2 = 1

[State 762, HitBy]
type = HitBy
trigger1 = 1
value = SCA,AT
time = 1

[State 762, Pause]
type = Pause
trigger1 = !Time
time = 15
moveTime = 15
endCmdBufTime = 15
pauseBg = 0

[State 762, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 762, Voice]
type = PlaySnd
trigger1 = !Time
value = 4,2
channel = 0

[State 762, Parry Sound]
type = PlaySnd
trigger1 = !Time
value = 760,0
channel = 1

[State 762, Player Flash]
type = PalFX
trigger1 = !Time
add = 0,64,255
sinadd = 0,-64,-255,60
time = 15

[State 762, Parry FX]
type = Explod
trigger1 = !Time
anim = 8360
sprPriority = 5
posType = P1
pos = ceil(20 * const(size.xscale)), ceil(-40 * const(size.yscale))
pauseMoveTime = -1
superMoveTime = -1
scale = 0.5,0.5
ownpal = 1

[State 762, EnvShake]
type = EnvShake
trigger1 = !Time
time = 0
ampl = 0

[State 762, End]
type = ChangeState
trigger1 = !AnimTime
value = 763
ctrl = 1


;Falling
[StateDef 763]
type = A
physics = N
movetype = I
anim = 763
ctrl = 1

[State 763, VelSet]
type = VelSet
trigger1 = !Time
x = ifElse(vel x > 2, 2, ifElse(vel x < -2, -2, vel x))
y = ifElse(vel y < -2, vel y, -2)

[State 763, Gravity]
type = Gravity
trigger1 = 1

[State 763, Landing]
type = ChangeState
trigger1 = pos y > -vel y
value = 52



;====================<CUSTOM COMBO>====================
;Ground Version
[StateDef 900]
type = S
physics = S
moveType = A
anim = 900
velSet = 0,0
ctrl = 0
sprPriority = 2
powerAdd = -1000

[State 900, Corner Push]
type = VarSet
trigger1 = Time = 4
fvar(5) = 0

[State 900, Unguardable]
type = VarSet
trigger1 = Time = 4 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 30

[State 900, NotHitBy]
type = NotHitBy
trigger1 = !time
value = SCA
time = 38

[State 900, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 900, Custom Combo Time]
type = VarSet
trigger1 = Time >= 4
var(20) = 180

[State 900, Voice]
type = PlaySnd
trigger1 = Time = 4
value = 900,1
channel = 0

[State 900, Custom Combo FX Helper]
type = Helper
trigger1 = Time = 4
helperType = Normal
stateNo = 8400
ID = 8400
name = "Custom Combo FX"
posType = P1
pos = ceil(0 * const(size.xscale)), ceil(-60 * const(size.yscale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 900, SuperPause]
type = SuperPause
trigger1 = Time = 4
time = 30
moveTime = 30
anim = -1
sound = s900,0
p2DefMul = 1
darken = 0

[State 900, AfterImage]
type = AfterImage
trigger1= !AnimTime
time = 2
timeGap = 1
frameGap = 4
length = 13
palBright = 0,0,0
palContrast = 64,128,192
palPostBright = 0,0,0
palAdd = 0,0,0
palMul = 0.75,0.75,0.75
trans = add1

[State 900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;Air Version
[Statedef 905]
type = A
physics = N
moveType = A
anim = 905
ctrl = 0
sprPriority = 2
powerAdd = -1000

[State 905, Corner Push]
type = VarSet
trigger1 = Time = 4
fvar(5) = 0

[State 905, Unguardable]
type = VarSet
trigger1 = Time = 4 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 30

[State 905, NotHitBy]
type = NotHitBy
trigger1 = !Time
value = SCA
time = 38

[State 905, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 905, Custom Combo Timer]
type = VarSet
trigger1 = Time >= 4
var(20) = 180

[State 905, Voice]
type = PlaySnd
trigger1 = Time = 4
value = 900,1
channel = 0

[State 905, Custom Combo FX Helper]
type = Helper
trigger1 = Time = 4
helperType = Normal
stateNo = 8400
ID = 8400
name = "Custom Combo Startup"
posType = P1
pos = ceil(0 * const(size.xscale)), ceil(-60 * const(size.yscale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 905, SuperPause]
type = SuperPause
trigger1 = Time = 4
time = 30
moveTime = 30
anim = -1
sound = s900,0
p2DefMul = 1
darken = 0

[State 905, AfterImage]
type = AfterImage
trigger1 = !AnimTime
time = 2
timeGap = 1
frameGap = 4
length = 13
palBright = 0,0,0
palContrast = 64,128,192
palPostBright = 0,0,0
palAdd = 0,0,0
palMul = 0.75,0.75,0.75
trans = add1

[State 905, End]
type = ChangeState
trigger1 = !AnimTime
value = 906
ctrl = 1


;Air Finish
[StateDef 906]
type = A
physics = N
moveType = I
anim = 906
ctrl = 1

[State 906, Gravity]
type = Gravity
trigger1 = 1

[State 906, Land]
type = ChangeState
trigger1 = pos y > -vel y
value = 52



;==========<TARGET SAFE FALL>==========
[StateDef 5205]
type = A
physics = N
moveType = H

[State 5205, ChangeAnim]
type = ChangeAnim
trigger1 = !AnimTime
trigger1 = Anim = 5035
value = 5050

[State 5205, VelAdd]
type = VelAdd
trigger1 = 1
y = GetHitVar(yAccel)

[State 5205, SelfState (Ground)]
type = SelfState
trigger1 = vel y > 0
trigger1 = pos y >= const(movement.air.getHit.groundRecover.ground.threshold)
value = 5200

[State 5205, SelfState (Air)]
type = SelfState
trigger1 = Time >= 60
value = 5210




;==========<FALL RECOVERY>==========
[StateDef 5200]
type = A
moveType = H
physics = N

[State 5200, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 5035 && !AnimTime
value = 5050

[State 5200, VelAdd]
type = VelAdd
trigger1 = 1
y = GetHitVar(yAccel)

[State 5200, End]
type = SelfState
trigger1 = vel y > 0 && pos y >= 10
value = 5201


[StateDef 5201]
type = S
moveType = I
physics = N
anim = 5200
ctrl = 0
faceP2 = 1

[State 5201, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 5201, VelSet]
type = VelSet
trigger1 = !Time
x = -8
y = 0

[State 5201, VelMul]
type = VelMul
trigger1 = 1
x = 0.9

[State 5201, Voice]
type = PlaySnd
trigger1 = !Time
value = 4,1
channel = 0

[State 5201, Recover Sound]
type = PlaySnd
trigger1 = !Time
value = 5200,0
channel = 1

[State 5201, Flash]
type = PalFX
trigger1 = !Time
add = 255,255,255
sinAdd = -255,-255,-255,40
time = 10

[State 5201, Recover FX]
type = Helper
trigger1 = !Time
helperType = Normal
stateNo = 8200
ID = 8200
name = "Recover FX"
posType = P1
pos = 0, ceil(-18 * const(size.yScale))
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 5201, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 5201, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;Air Recover
[StateDef 5210]
type = A
moveType = I
physics = N
anim = 5210
ctrl = 0

[State 5210, VelAdd]
type = VelAdd
trigger1 = 1
y = 0.6

[State 5210, VelSet]
type = VelSet
trigger1 = !Time
x = ifElse((command = "holdfwd" && command != "holdback"), 4, ifElse((command != "holdfwd" && command = "holdback"), -4, 0))
y = -7.55

[State 5210, Voice]
type = PlaySnd
trigger1 = !Time
value = 4,1
channel = 0

[State 5210, Recover Sound]
type = PlaySnd
trigger1 = !Time
value  = 5200,0

[State 5210, Flash]
type = PalFX
trigger1 = !Time
add = 255,255,255
sinAdd = -255,-255,-255,40
time = 10

[State 5210, Recover FX]
type = Helper
trigger1 = !Time
helperType = Normal
stateNo = 8200
ID = 8200
name = "Recover FX"
posType = P1
pos = ceil(8 * const(size.xscale)), ceil(-65 * const(size.yscale))
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 5210, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
value = SCA
time = 1

[State 5210, CtrlSet]
type = CtrlSet
trigger1 = AnimElemTime(5) >= 0
value = 1

[State 5210, Land]
type = ChangeState
trigger1 = vel y > 0
trigger1 = pos y > -vel y
value = 52



;===================<GUARD>================
;Guard Start
[StateDef 120]
type = U
physics = U
anim = 120 + (StateType = C) + (StateType = A) * 2

[State 120, StateTypeSet: Standing]
type = StateTypeSet
trigger1 = !Time && StateType = S
physics = S

[State 120, StateTypeSet: Crouching]
type = StateTypeSet
trigger1 = !Time && StateType = C
physics = C

[State 120, StateTypeSet: Jumping]
type = StateTypeSet
trigger1 = !Time && StateType = A
physics = A

[State 120, VelSet]
type = VelSet
trigger1 = !Time && StateType != A
x = 0
y = 0

[State 120, Stand to Crouching]
type = StateTypeSet
trigger1 = !AILevel && StateType = S && command = "holddown"
trigger2 = AILevel && StateType = S && (EnemyNear, MoveType = A) && (EnemyNear, StateType = C)
stateType = C
physics = C

[State 120, Crouching to Stand]
type = StateTypeSet
trigger1 = !AILevel && StateType = C && command != "holddown"
trigger2 = AILevel && StateType = C && (EnemyNear, MoveType = A) && (EnemyNear, StateType != C)
stateType = S
physics = S

[State 120, AI Fix]
type = CtrlSet
trigger1 = AILevel && NumEnemy
value = (EnemyNear, Time >= 120 || Time >= 180)

[State 120, Change to Guard State]
type = ChangeState
trigger1 = !AnimTime || AILevel
value = 130 + (StateType = C) + (StateType = A) * 2

[State 120, Stop Guarding]
type = ChangeState
trigger1 = (!AILevel && command != "holdback")
trigger2 = !InGuardDist
trigger3 = AILevel && NumEnemy
trigger3 = EnemyNear, HitDefAttr = SCA, AT
value = 140


;Standing Guard
[StateDef 130]
type = S
physics = S

[State 130, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 130
value = 130

[State 130, AI Fix]
type = CtrlSet
trigger1 = AILevel && NumEnemy
value = (EnemyNear, Time >= 120 || Time >= 180)

[State 130, Standing to Crouch]
type = ChangeState
trigger1 = !AILevel && command = "holddown"
trigger2 = AILevel && Random < (250 * (AILevel ** 2 / 64.0))
trigger2 = (EnemyNear, MoveType = A) && (EnemyNear, StateType = C)
value = 131

[State 130, Stop Guarding]
type = ChangeState
trigger1 = (!AILevel && command != "holdback")
trigger2 = !InGuardDist
trigger3 = AILevel && NumEnemy
trigger3 = EnemyNear, HitDefAttr = SCA, AT
value = 140

[State 130, Landing Sound]
type = PlaySnd
trigger1 = !Time
trigger1 = PrevStateNo = 132 || (PrevStateNo = [154,155])
value = 52,0

[State 130, Landing Dust Expod]
type = Explod
trigger1 = !Time
trigger1 = PrevStateNo = 132 || (PrevStateNo = [154,155])
anim = 8102
sprpriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1


;Crouch Guarding
[StateDef 131]
type = C
physics = C

[State 131, ChangeAnim]
type = ChangeAnim
trigger1 = anim != 131
value = 131

[State 131, Crouching to Standing]
type = ChangeState
trigger1 = !AILevel && command != "holddown"
trigger2 = AILevel && Random < (125 * (AILevel ** 2 / 64.0))
trigger2 = (EnemyNear, MoveType = A) && (EnemyNear, StateType != C)
value = 130

[State 131, AI Fix]
type = CtrlSet
trigger1 = AILevel && NumEnemy
value = (EnemyNear, Time >= 120 || Time >= 180)

[State 131, Stop Guarding]
type = ChangeState
trigger1 = (!AILevel && command != "holdback")
trigger2 = !InGuardDist
trigger3 = AILevel && NumEnemy
trigger3 = EnemyNear, HitDefAttr = SCA, AT
value = 140


;Air Guard
[StateDef 132]
type = A
physics = N

[State 132, ChangeAnim]
type = ChangeAnim
trigger1 = anim != 132
value = 132

[State 132, VelAdd]
type = VelAdd
trigger1 = 1
y = const(movement.yAccel)

[State 132, VarSet]
type = VarSet
trigger1 = 1
sysvar(0) = (pos y >= 0 && vel y > 0)

[State 132, VelSet]
type = VelSet
trigger1 = sysvar(0)
y = 0

[State 132, PosSet]
type = PosSet
trigger1 = sysvar(0)
y = 0

[State 132, AI Fix]
type = CtrlSet
trigger1 = AILevel && NumEnemy
value = (EnemyNear, Time >= 120 || Time >= 180)

[State 132, Jumping to Standing]
type = ChangeState
trigger1 = sysvar(0) && InGuardDist
trigger1 = (!AILevel && command = "holdback") || AILevel
value = 130

[State 132, Change to Falling]
type = ChangeState
trigger1 = sysvar(0)
value = 52

[State 132, Stop Guarding]
type = ChangeState
trigger1 = (!AILevel && command != "holdback")
trigger2 = !InGuardDist
trigger3 = AILevel && NumEnemy
trigger3 = EnemyNear, HitDefAttr = SCA, AT
value = 140


;Guard End
[StateDef 140]
type = U
physics = U
ctrl = 1

[State 140, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = 140 + (StateType = C) + (StateType = A) * 2

[State 140, StateTypeSet: Standing]
type = StateTypeSet
trigger1 = !Time && StateType = S
physics = S

[State 140, StateTypeSet: Crouching]
type = StateTypeSet
trigger1 = !Time && StateType = C
physics = C

[State 140, StateTypeSet: Jumping]
type = StateTypeSet
trigger1 = !Time && StateType = A
physics = A

[State 140, Standing to Crouching]
type = StateTypeSet
trigger1 = !AILevel && StateType = S && command = "holddown"
trigger2 = AILevel && Random < (250 * (AILevel ** 2 / 64.0))
trigger2 = StateType = S && (EnemyNear, MoveType = A) && (EnemyNear, StateType = C)
stateType = C
physics = C

[State 140, Crouching to Standing]
type = StateTypeSet
trigger1 = !AILevel && StateType = C && command != "holddown"
trigger2 = AILevel && Random < (125 * (AILevel ** 2 / 64.0))
trigger2 = StateType = C && (EnemyNear, MoveType = A) && (EnemyNear, StateType != C)
stateType = S
physics = S

[State 140, End]
type = ChangeState
trigger1 = !AnimTime
value = (StateType = C) * 11 + (StateType = A) * 51


;Hit while Guarding (Standing)
[StateDef 150]
type = S
movetype = H
physics = N
velSet = 0,0

[State 150, ChangeAnim]
type = ChangeAnim
trigger1 = 1
value = 150

[State 150, End]
type = ChangeState
trigger1 = HitShakeOver
value = 151 + 2 * ((!AILevel && command = "holddown") || (AILevel && (EnemyNear, MoveType = A) && (EnemyNear, StateType = C)))

[State 150, Standing to Crouching]
type = StateTypeSet
trigger1 = !AILevel && StateType = S && command = "holddown"
trigger2 = AILevel && Random < (250 * (AILevel ** 2 / 64.0))
stateType = C
physics = C

[State 150, Crouching to Standing]
type = StateTypeSet
trigger1 = !AILevel && StateType = C && command != "holddown"
trigger2 = AIlevel && Random < (125 * (AILevel ** 2 / 64.0))
trigger2 = StateType = C && (EnemyNear, MoveType = A) && (EnemyNear, StateType != C)
stateType = S
physics = S


;Knocked Back while Guarding (Standing)
[StateDef 151]
type = S
moveType = H
physics = S
anim = 150

[State 151, HitVelSet]
type = HitVelSet
trigger1 = !Time
x = 1

[State 151, VelSet]
type = VelSet
trigger1 = Time = GetHitVar(SlideTime)
trigger2 = HitOver
x = 0

[State 151, CtrlSet]
type = CtrlSet
trigger1 = time = GetHitVar(CtrlTime)
value = 1

[State 151, Standing to Crouching]
type = StateTypeSet
trigger1 = !AILevel && StateType = S && command = "holddown"
trigger2 = AILevel && Random < (250 * (AILevel ** 2 / 64.0))
trigger2 = StateType = S && (EnemyNear, MoveType = A) && (EnemyNear, StateType = C)
stateType = C
physics = C

[State 151, Crouching to Standing]
type = StateTypeSet
trigger1 = !AILevel && StateType = C && command != "holddown"
trigger2 = AILevel && Random < (125 * (AILevel ** 2 / 64.0))
trigger2 = StateType = C && (EnemyNear, MoveType = A) && (EnemyNear, StateType != C)
stateType = S
physics = S

[State 151, End]
type = ChangeState
trigger1 = HitOver
value = 130
ctrl = 1


;Hit while Guarding (Crouching)
[StateDef 152]
type = C
moveType = H
physics = N
velSet = 0,0

[State 152, ChangeAnim]
type = ChangeAnim
trigger1 = 1
value = 151

[State 152, End]
type = ChangeState
trigger1 = HitShakeOver
value = 151 + 2 * ((!AILevel && command = "holddown") || (AILevel && (EnemyNear, MoveType = A) && (EnemyNear, StateType = C)))

[State 152, Standing to Crouching]
type = StateTypeSet
trigger1 = !AILevel && statetype = S && command = "holddown"
trigger2 = AILevel && Random < (250 * (AILevel ** 2 / 64.0))
trigger2 = StateType = S && (EnemyNear, MoveType = A) && (EnemyNear, StateType = C)
stateType = C
physics = C

[State 152, Crouching to Standing]
type = StateTypeSet
trigger1 = !AILevel && StateType = C && command != "holddown"
trigger2 = AILevel && Random < (125 * (AILevel ** 2 / 64.0))
trigger2 = StateType = C && (EnemyNear, MoveType = A) && (EnemyNear, StateType != C)
stateType = S
physics = S


;Knocked Back while Guarding (Crouching)
[StateDef 153]
type = C
moveType = H
physics = C
anim = 151

[State 153, HitVelSet]
type = HitVelSet
trigger1 = !Time
x = 1

[State 153, VelSet]
type = VelSet
trigger1 = Time = GetHitVar(SlideTime)
trigger2 = HitOver
x = 0

[State 153, CtrlSet]
type = CtrlSet
trigger1 = Time = GetHitVar(CtrlTime)
value = 1

[State 153, Standing to Crouching]
type = StateTypeSet
trigger1 = !AILevel && StateType = S && command = "holddown"
trigger2 = AILevel && Random < (250 * (AILevel ** 2 / 64.0))
trigger2 = StateType = S && (EnemyNear, MoveType = A) && (EnemyNear, StateType = C)
stateType = C
physics = C

[State 153, Crouching to Standing]
type = StateTypeSet
trigger1 = !AILevel && StateType = C && command != "holddown"
trigger2 = AILevel && Random < (125 * (AILevel ** 2 / 64.0))
trigger2 = StateType = C && (EnemyNear, MoveType = A) && (EnemyNear, StateType != C)
stateType = S
physics = S

[State 153, End]
type = ChangeState
trigger1 = HitOver
value = 131
ctrl = 1


;Hit while Guarding (Jumping)
[StateDef 154]
type = A
moveType = H
physics = N
velSet = 0,0

[State 154, ChangeAnim]
type = ChangeAnim
trigger1 = 1
value = 152

[State 154, End]
type = ChangeState
trigger1 = HitShakeOver
value = 155


;Knocked Back while Guarding (Jumping)
[StateDef 155]
type = A
moveType = H
physics = N
anim = 152

[State 155, HitVelSet]
type = HitVelSet
trigger1 = !Time
x = 1
y = 1

[State 155, VelAdd]
type = VelAdd
trigger1 = 1
y = const(movement.yAccel)

[State 155, CtrlSet]
type = CtrlSet
trigger1 = Time = GetHitVar(CtrlTime)
value = 1

[State 155, VarSet]
type = VarSet
trigger1 = 1
sysvar(0) = (pos y >= 0 && vel y > 0)

[State 155, VelSet]
type = VelSet
trigger1 = sysvar(0)
y = 0

[State 155, PosSet]
type = PosSet
trigger1 = sysvar(0)
y = 0

[State 155, End]
type = ChangeState
trigger1 = sysvar(0) && InGuardDist
trigger1 = (!AILevel && command = "holdback") || AILevel
value = 130

[State 155, End]
type = ChangeState
trigger1 = sysvar(0)
value = 52



;====================<LOSE>====================
[StateDef 170]
type = S
ctrl = 0
anim = 170
velSet = 0,0

[State 170, Assert: RoundNotOver]
type = AssertSpecial
trigger1 = Time < 200
flag = RoundNotOver



;====================<DRAW GAME>====================
[StateDef 175]
type = S
ctrl = 0
velSet = 0,0

[State 175, ChangeState]
type = ChangeState
trigger1 = !Time
value = 170



;====================<CONTINUE?>====================
[StateDef 5500]
type = S
anim = 5500
velSet = 0,0
ctrl = 0

[State 5500, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = 5500



;====================<INITIALIZE>====================
[StateDef 5900]
type = S

[State 5900, Intro vs Charlie/Leona]
type = ChangeState
triggerAll = NumEnemy
triggerAll = RoundNo = 1 || (!(Enemy, RoundsExisted) && !(TeamMode = Simul) && !(Enemy, TeamMode = Simul))
triggerall = enemy, Name = "Duck_WLS" && enemy, AuthorName = "Vans"
trigger1 = RoundState = 0
value = 196

[State 5900, Turns Intro]
type = ChangeState
trigger1 = TeamMode = Turns
trigger1 = !RoundsExisted && RoundNo >= 2
value = 6900

[State 5900, Intro Decider]
type = ChangeState
trigger1 = RoundNo = 1
value = 190 + (Random % 4)

[State 5900, End]
type = ChangeState
trigger1 = 1
value = 0

;====================<INTRO 1>====================
[StateDef 190]
type = S
physics = S
anim = 190

[State 190, Assert: Intro]
type = AssertSpecial
trigger1 = 1
flag = Intro

[State 190, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 18
value = S190,2

[State 190, End]
type = ChangeState
trigger1 = !AnimTime
value = 0

;====================<INTRO 2>====================
[StateDef 191]
type = S
physics = S
anim = 191

[State 191, Assert: Intro]
type = AssertSpecial
trigger1 = 1
flag = Intro

[State 191, Explod]
type = Explod
triggerall = !NumExplod(1910)
trigger1 = Time = 0
ID = 1910
anim = 1910
postype = p1
scale = (Const(size.xscale)),(Const(size.yscale))
shadow = -1
bindtime = -1
removetime = -1
persistent = 0

[State 191, RemoveExplod]
type = RemoveExplod
triggerall = NumExplod(1910)
trigger1 = AnimElemTime(2) = 0
ID = 1910

[State 191, Explod]
type = Helper
triggerall = !NumHelper(1911)
trigger1 = Time = 0
ID = 1911
stateno = 1911
postype = P1
pos = (Ceil(-96*(Const(size.xscale)))),0
size.xscale = (Const(size.xscale))
size.yscale = (Const(size.yscale))
shadow = -1
bindtime = 1
persistent = 0

[State 191, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 2
value = S191,0

[State 191, End]
type = ChangeState
trigger1 = !AnimTime
value = 0

;====================<INTRO 3>====================
[StateDef 192]
type = S
physics = S
anim = 192
ctrl = 0

[State 192, Assert: Intro]
type = AssertSpecial
trigger1 = 1
flag = Intro

[State 192, PlaySnd];!
type = PlaySnd
trigger1 = AnimElemTime(4) = 2
value = S190,3
volume = 250

[State 192, PlaySnd];Cloth
type = PlaySnd
trigger1 = AnimElemTime(11) = 0
value = S190,0

[State 192, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(11) = 0
value = S191,0

[State 192, End]
type = ChangeState
trigger1 = !Animtime
value = 0

;====================<INTRO 4>====================
[StateDef 193]
type = S
physics = S
anim = 193

[State 193, Assert: Intro]
type = AssertSpecial
trigger1 = 1
flag = Intro

[State 193, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0

[State 193, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 28
trigger2 = AnimElem = 36
trigger3 = AnimElem = 44
trigger4 = AnimElem = 52
trigger5 = AnimElem = 55
value = S1400,0

[State 193, End]
type = ChangeState
trigger1 = !AnimTime
value = 0

;====================<RAT>====================
[Statedef 1911]
type = S
ctrl = 0
anim = 1911
velset = 0,0
sprpriority = 1

[State 1911, VelSet]
type = VelSet
trigger1 = Parent, AnimElemTime(2) = 0
x = -3

[State 1911, DestroySelf]
type = DestroySelf
trigger1 = FrontEdgeBodyDist < -20

;====================<INTRO VS DUCK KING>====================
[Statedef 196]
type = S
movetype = A
physics = N
ctrl = 0
anim = 1
velset = 0,0
sprpriority = 1

[State 196, ChangeAnim]
type = ChangeAnim
trigger1 = RoundState = 0
value = Anim

[State 196, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = Intro

[State 196, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1

[State 196, VarSet]
type = VarSet
trigger1 = Time = 1
var(55) = floor(Pos X)

[State 196, PosAdd]
type = PosAdd
trigger1 = Time = 98
x = -160

[State 196, ChangeAnim]
type = ChangeAnim
trigger1 = Time = 98
value = 110

[State 196, PlaySnd]
type = PlaySnd
trigger1 = Time = 98
value = S40,0
channel=1

[State 196, 1]
type = VelSet
trigger1 = Anim = 110 && AnimElem = 3
x = 6.4
y = -4.0625;-4.5

[State 196, 1]
type = VelMul
trigger1 = Anim = 110 && AnimElemTime(3) > 0
x = .98

[State 196, 1]
type = VelAdd
trigger1 = Anim = 110 && AnimElemTime(3) > 0
y = .65

[State 196, 1]
type = HitDef
trigger1 = Pos Y + Vel Y >= 0;;!Time
attr = A, HT
hitflag = MAFL
priority = 7, Miss
sparkno = -1
p2stateno = 30026
p2getp1state = 0
guard.dist = 0
numhits = 0
ID = 196

[State 196, ChangeAnim]
type = ChangeAnim
triggerall = Anim = 110 && AnimElemTime(3) > 0
trigger1 = Pos Y + Vel Y >= 0
trigger1 = NumTarget(196)
value = 194

[State 196, PosSet]
type = VelSet
trigger1 = Pos Y + Vel Y >= 0
x = 0
y = 0

[State 196, PosSet]
type = PosSet
trigger1 = Anim = 194
x = Var(55)
y = 0

[State 196, TargetBind]
type = TargetBind
trigger1 = NumTarget(196)
trigger1 = Anim = 110
time = -1
id = 196
pos = 68,-18

[State 196, TargetBind]
type = TargetBind
trigger1 = NumTarget(196)
trigger1 = Anim = 194 && AnimElem = 1
time = -1
id = 196
pos = 40,0

[State 196, TargetBind]
type = TargetBind
trigger1 = NumTarget(196)
trigger1 = Anim = 194 && AnimElem = 2
time = -1
id = 196
pos = 33,-22

[State 196, StateTypeSet]
type = StateTypeSet
trigger1 = Anim = 194
;statetype = L
movetype = I

[State 196, Explod]
type = Explod
triggerall = !NumExplod(1910)
trigger1 = Anim = 194 && AnimElemTime(2) = 0
ID = 1910
anim = 1940
postype = p1
scale = (Const(size.xscale)),(Const(size.yscale))
pos = ceil(-37*Const(size.xscale)),ceil(4*Const(size.yscale))
shadow = -1
bindtime = -1
removetime = -1
removeongethit = 1
persistent = 0

;Duck Intro - Hit & End
[Statedef 1960]
type = S
movetype = I
physics = N
ctrl = 0
anim = 1941
velset = 0,0
sprpriority = 1

[State 1960, TargetDrop]
type = TargetDrop
trigger1 = !Time

[State 1960, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = Intro

[State 1960, PlaySnd]
type = PlaySnd
trigger1 = Time = 1
value = S5000,0
channel = 0

[State 1960, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 26
value = S196,1
channel = 0

[State 1960, PlaySnd]
type = PlaySnd
trigger1 = AnimTime = 0
value = S196,0
channel = 0

[State 1960, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0

;====================<TURNS INTRO>====================
[StateDef 6900]
type = A
anim = 42
velSet = 0,0
ctrl = 0

[State 6900, Assert: Intro]
type = AssertSpecial
trigger1 = 1
flag = Intro

[State 6900, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
moveCamera = 0,0
ignoreHitPause = 1

[State 6900, Camera Helper]
type = Helper
trigger1 = !NumHelper(8999)
helpertype = Normal
stateNo = 8999
ID = 8999
name = "Camera"
posType = P1

[State 6900, PosSet]
type = PosSet
trigger1 = !Time
x = (-320 + abs(pos x)) * Facing

[State 6900, VelSet]
type = VelSet
trigger1 = !Time
x = (Helper(8999), RootDist x) / -40.0
y = -10.25

[State 6900, VelAdd]
type = VelAdd
trigger1 = 1
y = 0.5

[State 6900, End]
type = ChangeState
trigger1 = Time
trigger1 = pos y > -vel y
value = 6901


;Landing
[StateDef 6901]
type = S
physics = S
anim = 6901
velSet = 0,0

[State 6901, Assert: Intro]
type = AssertSpecial
trigger1 = 1
flag = Intro

[State 6901, PosSet]
type = PosSet
trigger1 = !Time && NumHelper(8999)
x = ceil(Helper(8999), pos x)

[State 6901, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0
channel = 1

[State 6901, Landing Dust Expod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 6901, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 5
value = 4, 1
channel = 0

[State 6901, End]
type = ChangeState
trigger1 = !AnimTime
value = 0

;====================<WIN POSE DECIDER>====================
[StateDef 180]
type = S

[State 180, Generic Victory Quote (Normal/Master mode)]
type = VictoryQuote
trigger1 = 1
value = Random % 50

[State 180, Victory Quote vs. Adon]
type = VictoryQuote
trigger1 = Enemy, Name = "Adon" || Enemy, Name = "cvsadon"
value = 50

[State 180, Victory Quote vs. Akuma]
type = VictoryQuote
trigger1 = Enemy, Name = "Akuma" || Enemy, Name = "cvsgouki" || Enemy, Name = "Gouki" || Enemy, Name = "Shin Akuma" || Enemy, Name = "Shin Gouki" || Enemy, Name = "ShinAkuma" || Enemy, Name = "ShinGouki" || Enemy, Name = "Pocket Shin Gouki"
value = 51 + Random % 2

[State 180, Victory Quote vs. Balrog]
type = VictoryQuote
trigger1 = Enemy, Name = "Balrog" || Enemy, Name = "cvsbison"
value = 53 + Random % 2

[State 180, Victory Quote vs. Blanka]
type = VictoryQuote
trigger1 = Enemy, Name = "Blanka" || Enemy, Name = "cvsblanka"
value = 55 + Random % 2

[State 180, Victory Quote vs. Cammy]
type = VictoryQuote
trigger1 = Enemy, Name = "Cammy" || Enemy, Name = "cvscammy"
value = 57 + Random % 2

[State 180, Victory Quote vs. Chun-Li]
type = VictoryQuote
trigger1 = Enemy, Name = "Chun-Li" || Enemy, Name = "cvschunli" || Enemy, Name = "Chun Li" || Enemy, Name = "ChunLi"
value = 59 + Random % 2

[State 180, Victory Quote vs. Cody]
type = VictoryQuote
trigger1 = Enemy, Name = "Cody" || Enemy, Name = "cvscody"
value = 61

[State 180, Victory Quote vs. Dan]
type = VictoryQuote
trigger1 = Enemy, Name = "Dan" || Enemy, Name = "cvsdan" || Enemy, Name = "Dan Hibiki"
value = 62 + Random % 2

[State 180, Victory Quote vs. Dee Jay]
type = VictoryQuote
trigger1 = Enemy, Name = "Dee Jay" || Enemy, Name = "DeeJay"
value = 64

[State 180, Victory Quote vs. Dhalsim]
type = VictoryQuote
trigger1 = Enemy, Name = "Dhalsim" || Enemy, Name = "cvsdhalsim" || Enemy, Name = "RajaaDhalsim"
value = 65 + Random % 2

[State 180, Victory Quote vs. Dudley]
type = VictoryQuote
trigger1 = Enemy, Name = "Dudley"
value = 67

[State 180, Victory Quote vs. E. Honda]
type = VictoryQuote
trigger1 = Enemy, Name = "E. Honda" || Enemy, Name = "cvshonda" || Enemy, Name = "E.Honda" || Enemy, Name = "Honda"
value = 68 + Random % 2

[State 180, Victory Quote vs. Fei Long]
type = VictoryQuote
trigger1 = Enemy, Name = "Fei Long" || Enemy, Name = "cvsfeilong" || Enemy, Name = "FeiLong" || Enemy, Name = "Fei-Long"
value = 70 + Random % 2

[State 180, Victory Quote vs. Gen]
type = VictoryQuote
trigger1 = Enemy, Name = "Gen"
value = 72 + Random % 2

[State 180, Victory Quote vs. Gouken]
type = VictoryQuote
trigger1 = Enemy, Name = "Gouken"
value = 74 + Random % 2

[State 180, Victory Quote vs. Guy]
type = VictoryQuote
trigger1 = Enemy, Name = "Guy" || Enemy, Name = "cvsguy"
value = 76

[State 180, Victory Quote vs. Hugo]
type = VictoryQuote
trigger1 = Enemy, Name = "Hugo"
value = 77

[State 180, Victory Quote vs. Hydron]
type = VictoryQuote
trigger1 = Enemy, Name = "Hydron" || Enemy, Name = "Nool"
value = 78

[State 180, Victory Quote vs. Ibuki]
type = VictoryQuote
trigger1 = Enemy, Name = "Ibuki"
value = 79

[State 180, Victory Quote vs. Ken]
type = VictoryQuote
trigger1 = Enemy, Name = "Ken" || Enemy, Name = "cvsken" || Enemy, Name = "Ken Masters"
value = 80 + Random % 2

[State 180, Victory Quote vs. Makoto]
type = VictoryQuote
trigger1 = Enemy, Name = "Makoto"
value = 82

[State 180, Victory Quote vs. Mars People / Zero]
type = VictoryQuote
trigger1 = Enemy, Name = "Mars People" || Enemy, Name = "MarsPeople" || Enemy, Name = "Zero" || Enemy, Name = "cvszero"
value = 83

[State 180, Victory Quote vs. M. Bison]
type = VictoryQuote
trigger1 = Enemy, Name = "M. Bison" || Enemy, Name = "cvsvega" || (Enemy, Name = "Vega" && Enemy, AuthorName = "Phantom.of.the.Server") || Enemy, Name = "M.Bison" || Enemy, Name = "Bison"
value = 84 + Random % 2

[State 180, Victory Quote vs. Rolento]
type = VictoryQuote
trigger1 = Enemy, Name = "Rolento" || Enemy, Name = "Rolento Schugerg" || Enemy, Name = "cvsrolento"
value = 86

[State 180, Victory Quote vs. Rose]
type = VictoryQuote
trigger1 = Enemy, Name = "Rose"
value = 87 + Random % 2

[State 180, Victory Quote vs. Ryu]
type = VictoryQuote
trigger1 = (Enemy, Name = "Ryu" && !(Enemy, AuthorName = "Phantom.of.the.Server")) || (Enemy, Name = "cvsryu" && PalNo = [1,6]) || Enemy, Name = "cvsryu_normal"
trigger2 = (Enemy, Name = "Ryu" && Enemy, AuthorName = "Phantom.of.the.Server")
trigger2 = Enemy, var(1) != 2
value = 89 + Random % 2

[State 180, Victory Quote vs. Sagat]
type = VictoryQuote
trigger1 = Enemy, Name = "Sagat" || Enemy, Name = "cvssagat" || Enemy, Name = "SagatMG"
value = 91 + Random % 2

[State 180, Victory Quote vs. Sakura]
type = VictoryQuote
trigger1 = Enemy, Name = "Sakura" || Enemy, Name = "cvssakura" || Enemy, Name = "Sakura Kasugano"
value = 93 + Random % 2

[State 180, Victory Quote vs. T. Hawk]
type = VictoryQuote
trigger1 = Enemy, Name = "T. Hawk" || Enemy, Name = "T.Hawk"
value = 95

[State 180, Victory Quote vs. Vega]
type = VictoryQuote
trigger1 = Enemy, AuthorName != "Phantom.of.the.Server"
trigger1 = Enemy, Name = "Vega" || Enemy, Name = "cvsbalrog"
value = 96 + Random % 2

[State 180, Victory Quote vs. Zangief]
type = VictoryQuote
trigger1 = Enemy, Name = "Zangief" || Enemy, Name = "cvszangief"
value = 98 + Random % 2

[State 180, Win 1]
type = ChangeState
trigger1 = command = "holdstart"
value = 181

[State 180, Win 2]
type = ChangeState
trigger1 = command = "holdx"
value = 182

[State 180, Win 3]
type = ChangeState
trigger1 = command = "holdy"
value = 183

[State 180, Win 4]
type = ChangeState
trigger1 = command = "holdz"
value = 184

[State 180, Win 5]
type = ChangeState
trigger1 = command = "holda"
value = 185

[State 180, Win 6]
type = ChangeState
trigger1 = command = "holdb"
value = 186

[State 180, Win 7]
type = ChangeState
trigger1 = command = "holdc"
value = 187

[State 180, Win 8]
type = ChangeState
trigger1 = command = "holdx" && command = "holda"
value = 188

[State 180, Win 9]
type = ChangeState
trigger1 = command = "holdy" && command = "holdb"
value = 189

[State 180, Win Decider]
type = ChangeState
trigger1 = 1
value = 181 + (Random % 9)

;====================<WIN 1>====================
[StateDef 181]
type = S
ctrl = 0
anim = 180
velset = 0,0

[State 181, Assert: RoundNotOver]
type = AssertSpecial
trigger1 = Time < 250
flag = RoundNotOver

[State 181, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 181, Voice]
type = PlaySnd
trigger1 = AnimElem = 6
value = S181,0
channel = 0

;====================<WIN 2>====================
[StateDef 182]
type = S
ctrl = 0
anim = 181
velset = 0,0

[State 182, Assert: RoundNotOver]
type = AssertSpecial
trigger1 = Time < 250
flag = RoundNotOver

[State 182, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 182, Voice]
type = PlaySnd
trigger1 = AnimElem = 17
value = S183,0
channel = 0

;====================<WIN 3>====================
[StateDef 183]
type = S
ctrl = 0
anim = ifElse(Random%2=0,185,182)
velset = 0,0

[State 183, Assert: RoundNotOver]
type = AssertSpecial
trigger1 = Time < 250
flag = RoundNotOver

[State 183, Helper]
type = Helper
trigger1 = Anim = 182 && Time = 0
trigger2 = Anim = 185 && AnimElemTime(10) = 14
helpertype = Normal ;player
name = "Nonno/Tama"
ID = 3210
stateno = 3210
pos = ifElse(Anim=185,-65,60)*Const(Size.Xscale),-220
postype = p1    ;p2,front,back,left,right
facing = 1
keyctrl = 0
ownpal = 1
size.xscale = Const(size.xscale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 183, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

;====================<WIN 4>====================
[StateDef 184]
type = S
ctrl = 0
anim = 183
velset = 0,0

[State 184, Assert: RoundNotOver]
type = AssertSpecial
trigger1 = Time < 250
flag = RoundNotOver

[State 184, Voice]
type = PlaySnd
trigger1 = AnimElemTime(39) = 0
value = S184,0
channel = 0

[State 184, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

;====================<WIN 5>====================
[StateDef 185]
type = S
ctrl = 0
anim = 188
velset = 0,0
sprpriority = 1

[State 185, ChangeState]
type = ChangeState
trigger1 = !Time
trigger1 = FrontEdgeDist < ceil(160*Const(Size.Xscale))
value = ifElse((FrontEdgeDist > 36 && random%2),186,181+(random%4))

[State 186, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 185, StateTypeSet]
type = StateTypeSet
trigger1 = Time = 147
statetype = A

[State 185, VelSet]
type = VelSet
trigger1 = Time = 147;AnimElemTime(15) = 0
x = 4
y = -5

[State 185, VelAdd]
type = VelAdd
trigger1 = Anim = 188 && Time > 147
y = .625

[State 185, PlaySnd]
type = PlaySnd
trigger1 = Time = 147
value = S40,0
channel = 1

[State 186, Helper]
type = Helper
trigger1 = !Time
helpertype = Normal
name = "Rat"
ID = 1870
stateno = 1870
facing = -1
pos = ceil(160*Const(Size.Xscale)),0
postype = p1
keyctrl = 0
ownpal = 1
size.xscale = Const(size.xscale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 185, ChangeAnim]
type = ChangeState
trigger1 = Time > 147 && Pos Y + Vel Y >= 0
value = 1850

[State 184, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = RoundNotOver

;Land
[Statedef 1850]
type = A
physics = N
sprpriority = 1
velset = 0,0

[State 1850, PosSet]
type = PosSet
trigger1 = !Time
y = 0

[State 185, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = S52,0
channel = 1

[State 1850, Anim]
type = ChangeAnim
trigger1 = !Time
value = 1880

[State 1850, PosAdd]
type = PosAdd
trigger1 = !Time
x = 8*Const(Size.Xscale)

[State 1850, PosAdd]
type = PosAdd
trigger1 = AnimElemTime(2) = 0
x = 24*Const(Size.Xscale)

[State 192, Explod]
type = Explod
trigger1 = AnimElemTime(3) = 0
ID = 1940
anim = 1940
postype = p1
pos = ceil(-42*Const(size.xscale)),ceil(3*Const(size.yscale))
scale = (Const(size.xscale)),(Const(size.yscale))
shadow = -1
bindtime = -1
removetime = -1
persistent = 0

[State 184, AssertSpecial]
type = AssertSpecial
trigger1 = Time < 250
flag = RoundNotOver

;Finish
[Statedef 1870]
type = A
physics = N
anim = 1913
sprpriority = 0

[State 1870, VarSet]
type = Null
triggerall = NumHelper(247) && !Time
trigger1 = e|| var(40) := helper(247),var(25)

[State 1870, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 1870, Explod]
type = Explod
trigger1 = Anim = 1913 && AnimElemTime(27)=3
ID = 1917
anim = 1917
postype = p1
scale = (Const(size.xscale)),(Const(size.yscale))
shadow = -1
bindtime = -1
removetime = 15
persistent = 0

[State 1870, Anim]
type = ChangeAnim
trigger1 = parent, Anim = 1880 && parent, AnimElemTime(2)=0
value = 1914

[State 1870, Anim]
type = ChangeAnim
trigger1 = parent, Anim = 1881 && parent, AnimElemTime(1)=0
value = 1915

[State 1870, VelSet]
type = VelSet
trigger1 = Anim = 1915 && AnimElemTime(1)=0
x = 2.4
y = -7.5
persistent = 0

[State 1870, VelAdd]
type = VelAdd
trigger1 = Anim = 1915
y = .5

[State 1870, BindToParent]
type = BindToParent
trigger1 = Anim = 1914 && AnimElemTime(2)=0
time = 1
pos = 0,0
persistent = 0

[State 1870, ChangeAnim]
type = ChangeAnim
triggerall = Time > 179
trigger1 = Anim = 1915 && Pos Y + Vel Y >= -52
value = anim+1

[State 1870, VelSet]
type = VelSet
trigger1 = Anim = 1916
x = 0
y = 0

[State 1870, PosSet]
type = PosSet
trigger1 = Anim = 1916
y = -52

[State 1870, BindToParent]
type = BindToParent
trigger1 = Anim = 1916; && AnimElemTime(1)=0
time = 1
facing = parent,Facing
pos = 2,-52
persistent = 0

[State 1850, SprPriority]
type = SprPriority
trigger1 = Anim = 1914 && AnimElemTime(3)=0
trigger2 = Anim = 1915
value = 2

[State 1870, DTC]
type = DisplayToClipboard
trigger1 = 1
text = "PDist = %f"
params = ParentDist X

[State 1911, DestroySelf]
type = DestroySelf
trigger1 = FrontEdgeBodyDist < -40
trigger2 = RoundState = 0

;====================<WIN 6>====================
[StateDef 186]
type = S
ctrl = 0
anim = 186
velset = 0,0
sprpriority = 1

[State 186, 2]
type = ChangeState
trigger1 = !Time
trigger1 = FrontEdgeDist < 36
value = 187

[State 186, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 186, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 186 && AnimTime = 0
value = 1870

[State 186, Helper]
type = Helper
trigger1 = Time = 1
helpertype = Normal ;player
name = "Butterfly"
ID = 1860
stateno = 1860
pos = -300,-63
postype = p1
keyctrl = 0
ownpal = 1
size.xscale = Const(size.xscale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 186, Explod]
type = Explod
trigger1 = Anim = 1870 && AnimElemTime(4) = 0
ID = 1940
anim = 1940
postype = p1
pos = ceil(-42*Const(size.xscale)),ceil(3*Const(size.yscale))
scale = (Const(size.xscale)),(Const(size.yscale))
shadow = -1
bindtime = -1
removetime = -1
persistent = 0

[State 186, VelSet]
type = VelSet
trigger1 = Anim = 186 && AnimElemTime(17) = 0
x = 2

[State 186, VelSet]
type = VelSet
trigger1 = Anim = 1870 && AnimElemTime(1) = 2
trigger2 = Anim = 1871 && AnimElemTime(2) = 2
x = 0

[State 186, PlaySnd]
type = PlaySnd
trigger1 = Anim = 186 && AnimElemTime(5) = 0
value = S184,0
channel = 0

[State 186, PlaySnd]
type = PlaySnd
trigger1 = Anim = 186 && AnimElemTime(15) = 0
value = S4,1
channel = 0

[State 186, PlaySnd]
type = PlaySnd
trigger1 = Anim = 1870 && AnimElemTime(1) = 0
trigger2 = Anim = 1871 && AnimElemTime(2) = 0
value = S40,0
channel = 1

[State 186, AssertSpecial]
type = AssertSpecial
trigger1 = Time < 500
flag = RoundNotOver

;====================<WIN 7>====================
[Statedef 187]
type = S
ctrl = 0
anim = 1874
velset = 0,0
sprpriority = 1

[State 187, 0]
type = ChangeState
trigger1 = !Time
trigger1 = BackEdgeDist < 24
trigger1 = FrontEdgeDist >= 36
value = 186

[State 187, 0]
type = ChangeState
trigger1 = !Time
trigger1 = BackEdgeDist < 24
trigger1 = FrontEdgeDist < 36
value = 181+(Random%4)

[State 187, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 187, Helper]
type = Helper
trigger1 = Time = 1
helpertype = Normal ;player
name = "Butterfly"
ID = 1860
stateno = 1860
pos = 268,-98
facing = -1
postype = p1
keyctrl = 0
ownpal = 1
size.xscale = Const(size.xscale)
size.yscale = Const(size.yscale)
ignorehitpause = 1

[State 187, Explod]
type = Explod
trigger1 = AnimElemTime(7)=0
ID = 1917
anim = 1917
postype = p1
facing = -1
pos = ceil(29*(Const(size.xscale))),ceil(-95*(Const(size.yscale)))
scale = (Const(size.xscale)),(Const(size.yscale))
shadow = -1
bindtime = -1
removetime = 11
persistent = 0

[State 187, VelSet]
type = VelSet
trigger1 = AnimElemTime(11) = 0
x = -5
y = -6

[State 187, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(11) > 0 && AnimElemTime(12) < 0
y = 0.83333333333333333333333333333333;Fib avg of 0.625

[State 187, VelSet]
type = VelSet
trigger1 = AnimElemTime(12) = 0
x = 0
y = 0

[State 187, VelSet]
type = PosSet
trigger1 = AnimElemTime(12) = 0
y = 0

[State 187, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(11) = 0
value = S40,0
channel = 1

[State 187, AssertSpecial]
type = AssertSpecial
trigger1 = Time < 500
flag = RoundNotOver

;Helper
[Statedef 1860]
type = A
physics = N
anim = 1872
sprpriority = 2

[State 1860, VelSet]
type = VelSet
trigger1 = Anim = 1872 && parent, StateNo = 186
x = 1+(abs(ParentDist X)/200)
y = sin((pi*time)/60)-(fvar(1)*((Time%8)=0))
;y = sin((pi*time)/60)-(1.75*((Time%8)=0))

[State 1860, VelSet]
type = VelSet
trigger1 = Anim = 1872 && parent, StateNo = 187 && parent, AnimElemTime(11) < 0
x = 4+(abs(ParentDist X)/200)
y = sin((pi*time)/60)-(fvar(1)*((Time%8)=0))

[State 1860, PosAdd]
type = PosAdd
triggerall = Anim = 1872
trigger1 = (Time%24)=0 && ifElse((parent,StateNo=187), (parent,AnimElemTime(11)<0), 1)
x = 2.5

[State 1860, VelSet]
type = VelSet
trigger1 = Anim = 1
x = 0
y = 0

[State 1860, Priority]
type = SprPriority
trigger1 = parent, Anim=1870 && parent, AnimElemTime(3)=0
value = 0

[State 1860, BindToParent]
type = BindToParent
trigger1 = parent, Anim=1870 && parent, AnimElemTime(3)=0
time = 1
pos = ceil(37*parent,Const(Size.Xscale)),ceil(-35*parent,Const(Size.Yscale))

[State 1860, BindToParent]
type = BindToParent
trigger1 = parent, Anim=1874 && parent, AnimElemTime(14)=0
time = 1
pos = ceil(-21*parent,Const(Size.Xscale)),ceil(-48*parent,Const(Size.Yscale))

[State 1860, Anim]
type = ChangeAnim
triggerall = Var(40) = 0
trigger1 = parent, Anim=186 && parent, AnimElemTime(15)=1
trigger2 = parent, Anim=1874 && parent, AnimElemTime(11)=1
value = 1

[State 1860, Anim]
type = ChangeAnim
trigger1 = parent, Anim=1870 && parent, AnimElemTime(3)=0
value = 1873

[State 1860, Anim]
type = ChangeAnim
trigger1 = parent, Anim=1874 && parent, AnimElemTime(14)=0
value = 1872

[State 1860, DestroySelf]
type = DestroySelf
trigger1 = FrontEdgeBodyDist < -40
trigger2 = RoundState = 0

;====================<WIN 8>====================
[Statedef 188]
type = S
ctrl = 0
anim = 184
velset = 0,0

[State 188, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 188, Explod]
type = Explod
triggerall = !NumExplod(185)
trigger1 = AnimElemTime(4) = 0
anim = 1840
postype = p1
scale = (Const(size.xscale)),(Const(size.yscale))
shadow = -1
bindtime = -1
removetime = -1
pos = 0,0
ID = 185
sprpriority = 2

[State 188, PlaySnd]
type = NULL;PlaySnd
trigger1 = AnimElemTime(4) = 0
value = S181,0
channel = 4

[State 188, PlaySnd]
type = PlaySnd
trigger1 = AnimElemTime(4) = 0
value = S181,0
channel = 4
volume = 300 ; SPARTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

[State 188, AssertSpecial]
type = AssertSpecial
trigger1 = Time < 250
flag = RoundNotOver

;====================<WIN 9>====================
[Statedef 189]
type = S
ctrl = 0
anim = 189
velset = 0,0

[State 189, PlaySnd]
type = PlaySnd
trigger1 = Time = 0
value = S185,0

[State 189, ChangeAnim]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 0

[State 189, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 183, AssertSpecial]
type = AssertSpecial
trigger1 = Time < 250
flag = RoundNotOver

;==========<TAUNT>==========
[StateDef 195]
type = S
moveType = I
physics = S
anim = 195
velSet  = 0,0
sprPriority = 1
ctrl = 0

[State 195, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 5
value = S195,0
channel = 0

[State 195, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;====================<CHEAP K.O.>====================
[StateDef 5950]
type = S
moveType = H
physics = S
anim = 5950
velSet = 0,0

[State 5950, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 5950, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 5950, Assert: NoKOsnd]
type = AssertSpecial
trigger1 = 1
flag = NoKOsnd

[State 5950, StopSnd]
type = StopSnd
trigger1 = !Time && !Alive
channel = 0

[State 5950, KO Sound]
type = PlaySnd
trigger1 = AnimElem = 2 && !Alive
value = 5950,0

[State 5981, Hitting the Floor Sound]
type = PlaySnd
trigger1 = AnimElem = 10
value = F7,0

[State 5981, Hitting the Floor Explod]
type = Explod
trigger1 = AnimElem = 10
anim = F60
posType = P1
pos = 0,0
sprPriority = -3

[State 5950, End]
type = ChangeState
trigger1= !AnimTime
value = ifElse(Alive, 5110, 5150)




;====================<AIR HIT TRANSITION>====================
[Statedef 5035]
type = A
movetype = H
physics = N

[State 5035, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
trigger1 = SelfAnimExist(5035)
trigger1 = Anim = [5000,5029]
value = 5035

[State 5035, VelAdd]
type = VelAdd
trigger1 = 1
y = GetHitVar(yAccel)

[State 5035, Recover]
type = ChangeState
triggerAll = !HitFall
trigger1 = HitOver
trigger2 = !AnimTime
trigger3 = vel y > 0 && pos y >= 10
trigger4 = !Time
trigger4 = Anim != 5035
value = 5040

[State 5035, Fall]
type = ChangeState
triggerAll = HitFall
trigger1 = HitOver
trigger2 = !AnimTime
trigger3 = vel y > 0 && pos y >= 10
trigger4 = !Time
trigger4 = Anim != 5035
value = 5050

;====================<LAND>====================
[Statedef 247]
anim = 1

[State -2, VarSet]
type = VarSet
trigger1 = !Parent, Var(52)
trigger2 = !Parent, MoveContact
trigger3 = Enemy,MoveReversed = 1
var(1) = 0

[State -2, VarSet]
type = VarSet
triggerall = Parent, NumTarget
trigger1 = Parent, Var(52) = [1,2]
trigger2 = Parent, MoveContact
var(1) = 1

[State -2, Combo]
type = VarSet
trigger1 = !parent, NumTarget
trigger2 = Var(40) && parent, HitPauseTime > 0
trigger3 = !root, Var(52)
trigger4 = Enemy,MoveReversed = 1
var(40) = 0
ignorehitpause = 1

[State -2, Combo]
type = VarAdd
trigger1 = Var(1)
var(40) = 1
ignorehitpause = 1

[State -2, DTC]
type = DisplayToClipboard
trigger1 = NumHelper(247)
text = "MoveContact = %d"
params = Var(40)

;===========================================================================
;===============================<-2 STATES>=================================
;===========================================================================
[StateDef -2]

;#ADD004BASIC PIEs#
;//==========================
;// add004-sctrls-start
;//==========================
;sys::-2::partners_standby ; ???????
[state 0]
	type=selfstate
	triggerall=!ishelper && numpartner && roundstate=2 && alive && sysfvar(0)>0 && playeridexist(floor(sysfvar(0)))
	triggerall=(stateno!=[190190,190199]) && playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(22)=4
	;;---// switch / change ;(??)
	trigger1=sysfvar(4)<1 && ( ctrl || (time<2 && stateno<600) ) && playerid(floor(sysfvar(0))),var(48)=11
	trigger1=(pos y>=0) && movetype!=h && gethitvar(isbound)=0 && (stateno!=5120) && (stateno!=[5200,5210])
	;;---// assist ;(??)
	trigger2=sysfvar(4)=1 && ( ctrl || (stateno-playerid(floor(sysfvar(0))),var(53+id-playerid(floor(sysfvar(0))),sysvar(0))!=[0,999]) )
	trigger2=(pos y>=0) && movetype!=h && gethitvar(isbound)=0 && (stateno!=5120) && (stateno!=[5200,5210])
	;;---// switch-canceling ;(??????)
	trigger3=sysfvar(4)=2 && ( ctrl || stateno<160 )
	trigger3=(pos y>=0) && movetype!=h && gethitvar(isbound)=0 && (stateno!=5120) && (stateno!=[5200,5210])
	;;---// player-priority ;(??)
	trigger4=sysfvar(4)<1 && playerid(floor(sysfvar(0))),var(15)!=id
	;;---
	value=190190
	ctrl=0
	ignorehitpause=1

;sys::-2::partners_change_interrupted ; ??????
[state 0]
	type=varset
	trigger1=!ishelper && numpartner && roundstate=2 && alive && sysfvar(0)>0 && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(48)=21 && sysfvar(4)<1
	sysfvar(4)=2 ;; (0:main / 1:assist / 2:switch-canceling)

;sys::-2::helper::bar004 ; ?????
[state 0]
	type=helper
	triggerall=!ishelper && !numhelper(90900)
	trigger1=numpartner
	trigger1=id<(partner,id) && partner,numhelper(90900)=0
	trigger2=!numpartner
	id=90900
	stateno=90900
	helpertype=normal
	ownpal=1
	size.air.front=1701220 ;; <<-version
	size.height=0
	ignorehitpause=1
	supermovetime=88888
	pausemovetime=88888
	pos=0,88888

;sys::-2::get_helper::bar004_id ; ID??
[state 0]
	type=varset
	trigger1=!ishelper && numhelper(90900)
	trigger1=(helper(90900),var(0)=90900) && (sysfvar(0)!=helper(90900),id)
	sysfvar(0)=(helper(90900),id)
;sys::-2::get_players_id2
[state 0]
	type=varset
	trigger1=!ishelper && numpartner
	trigger1=!numhelper(90900) && (partner,numhelper(90900)) && (sysfvar(0)!=(partner,sysfvar(0)))
	sysfvar(0)=(partner,sysfvar(0))

;sys::-2::bk/jd_system ; ?????/????D
[state 0]
	type=hitoverride
	trigger1=(numprojid(195502)||numprojid(195503)) && !ishelper && roundstate=2 && alive && (ctrl || stateno=52)
	attr=sca,na,sa,ha,np,sp,hp
	stateno=195500
	time=1
	ignorehitpause=1

;//==========================
;;>>@Config.Face>>
;sys::-2::face_d ; portrait (?)
[state 0]
	type=explod
	trigger1=!ishelper && alive && !numexplod(490600) && selfanimexist(909002)
	trigger1=sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),numexplod(490600)
	trigger1=movetype!=h || (stateno=[120,159]) || (stateno=[5000,5199]) || (stateno=[190190,190196])
	id=490600
	anim=909002
	space=screen
	postype=left
	facing=ifelse(teamside=1,1,-1)
	ownpal=1
	bindtime=-1
	removetime=-1
	scale=playerid(floor(sysfvar(0))),fvar(32-(id=playerid(floor(sysfvar(0))),var(15))*10), playerid(floor(sysfvar(0))),fvar(33-(id=playerid(floor(sysfvar(0))),var(15))*10)
	pos=floor(const240p(playerid(floor(sysfvar(0))),fvar(30-(id=playerid(floor(sysfvar(0))),var(15))*10))), floor(const240p(playerid(floor(sysfvar(0))),fvar(31-(id=playerid(floor(sysfvar(0))),var(15))*10)))
	sprpriority=floor(playerid(floor(sysfvar(0))),fvar(36-(id=playerid(floor(sysfvar(0))),var(15))*10))
	trans=addalpha
	alpha=floor(playerid(floor(sysfvar(0))),fvar(34-(id=playerid(floor(sysfvar(0))),var(15))*10)), floor(playerid(floor(sysfvar(0))),fvar(35-(id=playerid(floor(sysfvar(0))),var(15))*10))
	ignorehitpause=1
	supermovetime=-1
	pausemovetime=-1
;sys::-2::face_d_mod
[state 0]
	type=removeexplod
	trigger1=sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=(playerid(floor(sysfvar(0))),var(0)=90900)
	trigger1=(playerid(floor(sysfvar(0))),var(9)&262144) || !(playerid(floor(sysfvar(0))),var(9)&4)
	trigger2=roundstate!=2 || (stateno=5150 && time=5 && !alive)
	id=490600
	ignorehitpause=1

;//==========================
;;>>@Config.Camera>>
;sys::-2::camera_nc ; ????
[state 0]
	type=screenbound
	trigger1=!ishelper && sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && numpartner && (sysfvar(4)>0 || stateno=5150)
	value=0
	movecamera=0,0
	ignorehitpause=1
;sys::-2::camera_np
[state 0]
	type=playerpush
	trigger1=!ishelper && sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && numpartner && (sysfvar(4)>0 || stateno=5150)
	value=0
	ignorehitpause=1
;sys::-2::camera_nc2
[state 0]
	type=screenbound
	trigger1=!ishelper && sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && (playerid(floor(sysfvar(0))),var(7)&65536) ;; system_switch
	value= ((numpartner && sysfvar(4)<1) || !numpartner) ;; [def=0]
	movecamera=0,0 ;; [x,y]
	ignorehitpause=1

;//==========================
;sys::-2::add.option2-noko
[state 0] ;; opt-noko
	type=assertspecial
	trigger1=!ishelper && sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900
	trigger1=id=playerid(floor(sysfvar(0))),var(15) && (playerid(floor(sysfvar(0))),var(9)&65536) ;; opt-noko
	flag=noko
	ignorehitpause=1
;sys::-2::add.option3-life-mod
[state 0] ;; opt-life-mod
	type=lifeadd
	trigger1=!ishelper && sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900
	trigger1=id=playerid(floor(sysfvar(0))),var(15) && playerid(floor(sysfvar(0))),var(23)!=0 ;; opt-mod-life
	value=playerid(floor(sysfvar(0))),var(23)
	kill=0
	ignorehitpause=1

;//==========================
;// optional settings
;sys::-2::guard_crush_fx ; ????????
[state 0]
	type=palfx
	trigger1=(stateno=150 || stateno=152) && alive && !ishelper && (gametime%5=0) && sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(36)>=40
	time=2
	add=200,0,0
;sys::-2::guard_crush_cs
[state 0]
	type=changestate
	trigger1=(stateno=150 || stateno=152) && alive && !ishelper && sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(36)>=50
	value=190010
	ignorehitpause=1
;;--- dizzy
;sys::-2::goto-dizzy_s/c
[state 0] ;[.03-2d1]
	type=selfstate
	trigger1=(stateno=5001 || stateno=5011) && hitover     && alive && !ishelper && life>1 && roundstate=2 && sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(50)>=1000
	value=195201 ;; (goto-dizzy:190116)
;sys::-2::goto-dizzy_a/l
[state 0] ;[.03-2d2]
	type=selfstate
	trigger1=(stateno=5030 || stateno=5071) && hitshakeover && alive && !ishelper && life>1 && roundstate=2 && sysfvar(0)>id && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(50)>=1000
	value=195050
;;--- fadeout when KOed ; KO????
;sys::-2::st5150-1
[state 0]
	type=varset
	trigger1=stateno=5150 && time=1 && alive=0 && !ishelper && numpartner
	sysvar(1)=(roundstate<=2)
;sys::-2::st5150-2
[state 0]
	type=assertspecial
	trigger1=stateno=5150 && alive=0 && !ishelper && numpartner && sysvar(1) && (((time=[80,150]) && time%10<5) || time>150)
	flag=invisible
	flag2=noshadow
;;sys::-2::st5150-3
;[state 0]
;	type=posset
;	trigger1=stateno=5150 && time>=80 && alive=0 && !ishelper && numpartner && sysvar(1)
;	y=800 *(((time=[80,150]) && time%10<5) || time>150)
;;--- intro-pos-reset
;sys::-2::st5900-p3
[state 0]
	type=turn
	trigger1=stateno=5900 && time=0
	trigger1=!ishelper && numpartner>1 && facing=ifelse(teamside=1,-1,1)
;sys::-2::st5900-p4
[state 0]
	type=posset
	trigger1=stateno=5900 && time=0
	trigger1=!ishelper && numpartner>1 && playeridexist(id-2)
	trigger1=playerid(id-2),ishelper=0 && playerid(id-2),teamside=teamside
	x=const240p(120)*ifelse(teamside=1,-1,1)
;sys::-2::st5900-p5
[state 0]
	type=posset
	trigger1=stateno=5900 && time=0
	trigger1=!ishelper && numpartner>2 && playeridexist(id-3)
	trigger1=playerid(id-3),ishelper=0 && playerid(id-3),teamside=teamside
	x=const240p(144)*ifelse(teamside=1,-1,1)

;//==========================
;// add004-sctrls-end
;//==========================


[State -2, Hit Detection]
type = VarSet
trigger1 = MoveContact = 1 && var(30) < 0
var(30) = HitPauseTime
ignoreHitPause = 1

[State -2, Hit Sound]
type = PlaySnd
trigger1 = MoveContact = 1 && var(30) = HitPauseTime
trigger1 = MoveHit = 1 && var(31) >= 0
value = 2, var(31)
channel = 2
ignoreHitPause = 1

[State -2, Guard Sound]
type = PlaySnd
trigger1 = MoveContact = 1 && var(30) = HitPauseTime
trigger1 = MoveGuarded = 1 && var(32) >= 0
value = 3, var(32)
channel = 2
ignoreHitPause = 1

[State -2, Hit Sparks]
type = Helper
triggerAll = MoveContact = 1 && var(30) = HitPauseTime
trigger1 = MoveHit = 1 && NumEnemy
trigger1 = var(33) = 8010 || var(33) = 8011 || var(33) = 8012 || var(33) = 8013 || var(33) = 8014 || var(33) = 8001
trigger2 = MoveGuarded = 1 && NumEnemy
trigger2 = var(34) = 8000 || var(34) = 8001
trigger3 = MoveHit = 1 && NumEnemy
trigger3 = var(33) = 8015 || var(33) = 8016 || var(33) = 8017
helperType = Normal
stateNo = ifElse(MoveGuarded, var(34), var(33))
ID = 8000
name = "Spark"
postype = P1
pos = ceil(ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < var(35), ceil(P2Dist x), var(35))) * const(size.xScale)), ceil(var(36) * const(size.yScale))
facing = -1
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State -2, Counter FX]
type = Helper
trigger1 = MoveHit = 1 && var(30) = HitPauseTime
trigger1 = NumEnemy && var(9)
trigger1 = !(HitDefAttr = SCA, AT) && (EnemyNear, MoveReversed != 1)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ceil(ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < var(35), ceil(P2Dist x), var(35))) * const(size.xScale)), ceil(var(36) * const(size.yScale))
facing = -1
ownPal = 1
pauseMoveTime = 255
superMoveTime = 255
ignoreHitPause = 1

[State -2, Counter Flag]
type = VarSet
trigger1 = NumEnemy
var(9) = (EnemyNear, MoveType = A)
ignoreHitPause = 1

[State -2, Hit Detection]
type = VarSet
trigger1 = 1
var(30) = -1

[State -2, Hit Detection]
type = VarRangeSet
trigger1 = MoveType = I
trigger2 = MoveType = H && Time
first = 30
last = 36
value = -1
ignoreHitPause = 1

[State -2, P2 Facing]
type = TargetFacing
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver) && !(Target, HitFall) && (Target, Time <= 1)
trigger2 = MoveContact = 1 && NumTarget(1232)
trigger2 = !(Target, HitShakeOver) && (Target, Time <= 1)
value = ifElse(P2Dist x >= 0, -1, 1)
ignoreHitPause = 1

[State -2, P2 Safe Fall]
type = TargetState
trigger1 = NumTarget = 1
trigger1 = Target, command = "recovery"
trigger1 = Target, pos y >= -48 && Target, vel y > 0
trigger1 = Target, Alive && Target, HitFall && Target, GetHitVar(fall.recover)
trigger1 = Target, StateNo = 5030 || Target, StateNo = 5035 || Target, StateNo = 5050 || Target, StateNo = 5071
value = 5205
ignoreHitPause = 1

[State -2, Assert: UnGuardable]
type = AssertSpecial
trigger1 = var(17) > 0
trigger1 = var(17) := (var(17) - 1)
flag = UnGuardable
ignoreHitPause = 1

[State -2, Hit Count]
type = VarAdd
trigger1 = MoveHit = 1
trigger1 = !(HitDefAttr = SCA, AT)
var(13) = 1

[State -2, Hit Count Reset]
type = VarSet
trigger1 = NumEnemy && var(13)
trigger1 = (EnemyNear, MoveType != H) && (EnemyNear, StateNo != 5300)
var(13) = 0
ignoreHitPause = 1

[State -2, Juggle Count]
type = VarAdd
trigger1 = MoveHit = 1
trigger1 = !(HitDefAttr = SCA,AT)
var(15) = 1

[State -2, Juggle Reset Single]
type = VarSet
triggerAll = NumEnemy = 1 && var(15)
trigger1 = (Enemy, StateType != A) && (Enemy, StateNo != [5100,5109]) && (Enemy, Time >= 1)
trigger2 = (Enemy, MoveType != H) || (Enemy, StateNo = [120,155]) || (Enemy, Ctrl)
var(15) = 0
ignoreHitPause = 1

[State -2, Juggle Reset Simul]
type = VarSet
triggerAll = NumEnemy >= 2 && var(15)
trigger1 = (EnemyNear(0), StateType != A) && (EnemyNear(0), Time >= 1)
trigger2 = (EnemyNear(0), MoveType != H) || (EnemyNear(0), StateNo = [120,155]) || (EnemyNear(0), Ctrl)
trigger3 = (EnemyNear(1), StateType != A) && (EnemyNear(0), Time >= 1)
trigger4 = (EnemyNear(1), MoveType != H) || (EnemyNear(0), StateNo = [120,155]) || (EnemyNear(0), Ctrl)
var(15) = 0
ignoreHitPause = 1

[State -2, Free Juggling]
type = VarSet
trigger1 = RoundState != 2
var(15) = 0
ignoreHitPause = 1

[State -2, Juggle Flag]
type = VarSet
trigger1 = NumEnemy && !var(16)
trigger1 = (EnemyNear, StateNo = 5040) && !(EnemyNear, Ctrl)
var(16) = 1
ignorehitpause = 1

[State -2, Juggle Flag Reset Single]
type = VarSet
triggerAll = NumEnemy = 1 && var(16)
trigger1 = (Enemy, MoveType != H) && (Enemy, StateNo != 5040)
trigger2 = !(Enemy, HitShakeOver) || (Enemy, StateType = L) || (Enemy, Ctrl)
var(16) = 0
ignoreHitPause = 1

[State -2, Juggle Flag Reset Simul]
type = VarSet
triggerAll = NumEnemy >= 2 && var(16)
trigger1 = (EnemyNear(0), MoveType != H) && (EnemyNear(0), StateNo != 5040)
trigger2 = !(EnemyNear(0), HitShakeOver) || (EnemyNear(0), StateType = L) || (EnemyNear(0), Ctrl)
trigger3 = (EnemyNear(1), MoveType != H) && (EnemyNear(1), StateNo != 5040)
trigger4 = !(EnemyNear(1), HitShakeOver) || (EnemyNear(1), StateType = L) || (EnemyNear(1), Ctrl)
var(16) = 0
ignoreHitPause = 1

[State -2, Custom Combo End]
type = VarSet
trigger1 = var(20) < 0
trigger2 = MoveType = H
trigger3 = RoundState != 2
trigger4 = (StateNo = [3000,4999])
var(20) = 0
ignoreHitPause=1

[State -2, Custom Combo Time]
type = VarAdd
trigger1 = var(20) > 0
var(20) = -1
ignoreHitPause = 1

[State -2, Custom Combo Asserts]
type = AssertSpecial
trigger1 = var(20) > 0
flag = NoStandGuard
flag2 = NoCrouchGuard
flag3 = NoAirGuard
ignoreHitPause = 1

[State -2, Custom Combo PalFX]
type = PalFX
trigger1 = var(20) > 60
time = 2
add = 32 + ceil(sin(var(20) / 16.0 * pi) * 32), 32 + ceil(sin(var(20) / 16.0 * pi) * 32), 32 + ceil(sin(var(20) / 16.0 * pi) * 32)
ignoreHitPause = 1

[State -2, Custom Combo PalFX]
type = PalFX
trigger1 = var(20) = [1,60]
time = 2
add = 64 + ceil(sin(var(20) / 8.0 * pi) * 64), 64 + ceil(sin(var(20) / 8.0 * pi) * 64), 64 + ceil(sin(var(20) / 8.0 * pi) * 64)
ignoreHitPause = 1

[State -2, Throws Allowed]
type = VarSet
trigger1 = EnemyNear, MoveType != H
trigger1 = EnemyNear, StateNo != 140
trigger1 = (EnemyNear, ctrl && EnemyNear, Time >= 1) || (EnemyNear, Time >= 8)
trigger2 = EnemyNear, MoveType = A
trigger3 = (EnemyNear, StateNo != [0,52]) && (EnemyNear, StateNo != [120,155]) && (EnemyNear, StateNo != [5000,5120])
trigger4 = var(20) || var(21) || var(22)
var(38) = 0

[State -2, Throws Disallowed]
type = VarSet
triggerAll = NumEnemy
trigger1 = EnemyNear, StateNo = [150,155]
trigger2 = (EnemyNear, StateNo = 51 || EnemyNear, StateNo = 140) && (EnemyNear, PrevStateNo = [150, 155])
trigger3 = EnemyNear, MoveType = H && EnemyNear, StateType != A && !var(20) && !var(21) && !var(22)
trigger4 = (EnemyNear, StateNo = [5020,5040]) && EnemyNear, HitFall = 0
trigger5 = EnemyNear, StateNo = 40 && EnemyNear, PrevStateNo != 52 && (EnemyNear, Anim != [0, 29])
var(38) = 1
ignoreHitPause = 1

[State -2, Dampener]
type = VarSet
trigger1 = 1
fvar(10) = ifElse(var(13) < 6, 24, ifElse(var(13) >= 23, 1, 29 - var(13))) / 24.0
ignoreHitPause = 1

[State -2, Dampener - Custom Combo]
type = VarSet
trigger1 = var(20)
fvar(10) = 0.72 * (10 - ifElse(var(13) >= 10, 10, var(13))) / 10.0
ignoreHitPause = 1

[State -2, Dampener - Custom Combo Limiter]
type = VarSet
trigger1 = var(20)
trigger1 = StateNo = 250
fvar(10) = ifElse(var(13), 0, 0.72)
ignoreHitPause = 1

[State -2, Dampener - Supers]
type = VarSet
trigger1 = (StateNo = [3000,4999])
fvar(10) = ifElse(var(22), 0.6, ifElse(var(21), 0.8, 1.0))
ignoreHitPause = 1

[State -2, Dampener Limit]
type = VarSet
trigger1 = fvar(10) < 0
fvar(10) = 0
ignoreHitPause = 1

[State -2, Root Dampener]
type = VarSet
trigger1 = 1
fvar(11) = fvar(10) * ifElse(var(9), 1.2, 1)
ignoreHitPause = 1

[State -2, Back Charge Increment]
type = VarAdd
trigger1 = command = "holdback"
var(47) = 1

[State -2, Back Charge Reset]
type = VarSet
trigger1 = command != "holdback"
var(47) = 0

[State -2, Back Charge Buffer Activation]
type = VarSet
trigger1 = var(47) >= 45
var(48) = 32

[State -2, Back Charge Buffer Decrement]
type = VarAdd
trigger1 = var(47) < 45 && var(48) > 0
var(48) = -1

[State -2, Down Charge Increment]
type = VarAdd
trigger1 = command = "holddown"
var(49) = 1

[State -2, Down Charge Reset]
type = VarSet
trigger1 = command != "holddown"
var(49) = 0

[State -2, Down Charge Buffer Activation]
type = VarSet
trigger1 = var(49) >= 45
var(50) = 32

[State -2, Down Charge Buffer Decrement]
type = VarAdd
trigger1 = var(49) < 45 && var(50) > 0
var(50) = -1

[State -2, Voice Position]
type = SndPan
trigger1 = 1
channel = 0
pan = 0
ignoreHitPause = 1

[State -2, Debug]
type = DisplayToClipboard
trigger1 = 1
text = "AI = %d Attack = %f Hits = %d Juggle = %d"
params = AILevel, fvar(11), var(13), var(15)
ignoreHitPause = 1

[State -2, Debug]
type = AppendToClipboard
trigger1 = 1
text = "\nBy Jmorphman"
ignoreHitPause = 1

; Reset Timer, Loop Variable
[State -2, VarSet]
type = VarSet
trigger1 = StateNo != 255
trigger1 = StateNo != 1000
trigger1 = StateNo != [1400,1405]
trigger1 = StateNo != 1030
trigger1 = StateNo != [1430,1435]
trigger1 = StateNo != 3000
trigger2 = StateNo = 255 && Time = 0
var(11) = 0

[State -2, Drop]
type = VarSet
triggerall = FVar(39)
trigger1 = !NumTarget
trigger2 = cond(numHelper(1250), (helper(1250), MoveContact), 0)
trigger3 = MoveContact = 1
fvar(39) = 0

[State -2, Kitty the Helper Timer]
type = VarSet
triggerall = Var(43)
trigger1 = RoundState != 2
var(43) = 0

[State -2, Kitty the Helper Timer]
type = VarAdd
trigger1 = Var(43) > 0
var(43) = -1

[State -2, Hit]
type = VarSet
triggerall = Var(46) < 0
trigger1 = MoveContact = 1
var(46) = HitPauseTime
ignorehitpause = 1

[State -2, Hit]
type = VarSet
trigger1 = 1
var(46) = -1

[State -2, GIMMIE ALL YOUR MONEY]
type = VarSet
trigger1 = (StateNo = [600,650]) && PrevStateNo = 102
var(1) = 0

[State -2, AAAAAAAAAAAAAAAAAARGH]
type = VarSet
trigger1 = MoveType = H
trigger2 = StateNo = 52
trigger3 = StateNo = 1305
var(1) = 1

[State 147, TargetDrop]
type = TargetState
triggerall = NumTarget(60)
trigger1 = StateNo != 60
trigger2 = RoundState != 2
value = 66

[State -2, TargetDrop]
type = TargetDrop
trigger1 = StateNo != 60 && NumTarget(60)
trigger2 = RoundState != 2

[State -2, Cat Ride Pos]
type = VarSet
trigger1 = (Enemy, Name = "Felicia_LG" || Enemy, Name = "Felicia") && Enemy, AuthorName = "Jesuszilla"
trigger1 = StateNo != 132 && StateNo != 155 ; Air guard
trigger1 = StateNo != [5000,5999]           ; Gethits
sysvar(0) = (7 & 65535) | (-65 * 65536)

;===========================================================================
;===============================<-3 STATES>=================================
;===========================================================================
[StateDef -3]

[State -3, GameTime]
type = VarSet
trigger1 = 1
var(58) = GameTime
ignoreHitPause = 1

[State -3, ProjContact Reset]
type = VarSet
triggerAll = var(18)
trigger1 = (StateNo != [1000,1030])
trigger1 = StateNo != 3200
var(18) = 0

[State -3, Projectile Flag Off]
type = VarSet
trigger1 = 1
var(39) = 0
ignoreHitPause = 1

[State -3, Projectile Flag On]
type = VarSet
triggerAll = var(20) <= 0
trigger1 = NumHelper(1005)
trigger1 = Helper(1005), StateNo = 1005
trigger2 = NumHelper(1005)
trigger2 = Helper(1005), StateNo = 1035
trigger3 = NumHelper(3205)
trigger3 = Helper(3205), StateNo = 3205
var(39) = 1
ignoreHitPause = 1

[State -3, Chain Combo Reset]
type = VarSet
trigger1 = 1
var(4) = 0
ignoreHitPause = 1

[State -3, Chain Combo Check]
type = VarSet
trigger1 = var(20) && (StateNo = [200,699]) && MoveContact
trigger2 = var(20) && (StateNo = [1000,2999]) && StateType != A && (MoveContact || var(18))
var(4) = 1
ignoreHitPause = 1

[State -3, Cancel Reset]
type = VarSet
trigger1 = 1
var(6) = 0
ignoreHitPause = 1

[State -3, Cancel Check]
type = VarSet
trigger1 = var(20) && (StateNo = [200,699])
trigger2 = var(20) && (StateNo = [1000,2999]) && (MoveContact || var(18))
trigger3 = (StateNo = [200,699]) && Time <= 2
trigger4 = StateNo = 200
trigger5 = StateNo = 205
trigger6 = StateNo = 210
trigger7 = StateNo = 215
trigger8 = StateNo = 230
trigger9 = StateNo = 235
trigger10 = StateNo = 240
trigger11 = StateNo = 245
trigger12 = StateNo = 400
trigger13 = StateNo = 410
trigger14 = StateNo = 419
trigger15 = StateNo = 430
trigger16 = StateNo = 440
var(6) = 1
ignoreHitPause = 1

[State -3, Super Cancel Reset]
type = VarSet
trigger1 = 1
var(7) = 0
ignoreHitPause = 1

[State -3, Super Cancel Check]
type = VarSet
trigger1 = var(20) && (StateNo = [200,699])
trigger2 = var(20) && (StateNo = [1000,2999]) && (MoveContact || var(18))
trigger3 = (StateNo = [200,699]) && Time <= 2
trigger4 = StateNo = 200
trigger5 = StateNo = 205
trigger6 = StateNo = 210
trigger7 = StateNo = 215
trigger8 = StateNo = 230
trigger9 = StateNo = 235
trigger10 = StateNo = 240
trigger11 = StateNo = 245
trigger12 = StateNo = 400
trigger13 = StateNo = 410
trigger14 = StateNo = 419
trigger15 = StateNo = 430
trigger16 = StateNo = 440
var(7) = 1
ignoreHitPause = 1

[State -3, Hyper Cancel Reset]
type = VarSet
trigger1 = 1
var(8) = 0
ignoreHitPause = 1

[State -3, Hyper Cancel Reset]
type = VarSet
trigger1 = StateNo = 3000 && MoveContact
var(8) = 1
ignoreHitPause = 1

[State -3, Super Cancel Flag Reset]
type = VarSet
trigger1 = var(21)
trigger1 = (StateNo != [3000,4999]) || MoveType = H
var(21) = 0
ignoreHitPause = 1

[State -3, Hyper Cancel Flag Reset]
type = VarSet
trigger1 = var(22)
trigger1 = (StateNo != [3000,4999]) || MoveType = H
var(22) = 0
ignoreHitPause = 1

[State -3, Parry Detection]
type = Helper
triggerAll = RoundState = 2 && !NumHelper(765) && !var(20)
triggerAll = (MoveType = I && ctrl) || (StateNo = [760, 762]) || StateNo = 5120
triggerAll = (command != "rlsfwd" && command != "rlsback" && command != "rlsup" && command != "rlsdown") || AILevel
trigger1 = !AILevel && (StateType = S || StateType = C || StateNo = 5120) && (command = "fwd" || command = "down")
trigger2 = !AILevel && StateType = A && (var(3) != 1 && var(3) != 2) && command = "fwd"
trigger3 = AILevel && (StateNo != [760,762]) && InGuardDist && Random < 50
trigger4 = AILevel && (StateNo = [760,762]) && Time = 14 && Random < 667
helperType = Normal
stateNo = 765
ID = 765
name = "Parry Detection"
posType = P1
pauseMoveTime = 65535
superMoveTime = 65535

[State -3, Parry Attacks]
type = ChangeState
trigger1 = (StateNo != [760,762]) && NumHelper(765)
trigger1 = Helper(765), StateNo = 766
value = ifElse((Helper(765), Anim = 767), 762, ifElse((Helper(765), Anim = 766), 761, 760))
ignoreHitPause = 1

[State -3, Parry Projectiles]
type = HitOverride
trigger1 = (StateNo != [760,762]) && NumHelper(765)
trigger1 = !(Helper(765), var(0)) && (Helper(765), Anim = 765)
attr = SA, AP
stateNo = 760
slot = 0
time = 1
ignoreHitPause = 1

[State -3, Parry Projectiles]
type = HitOverride
trigger1 = (StateNo != [760,762]) && NumHelper(765)
trigger1 = !(Helper(765), var(0)) && (Helper(765), Anim = 766)
attr = C, AP
stateNo = 761
slot = 0
time = 1
ignoreHitPause = 1

[State -3, Parry Projectiles]
type = HitOverride
trigger1 = (StateNo != [760,762]) && NumHelper(765)
trigger1 = !(Helper(765), var(0)) && (Helper(765), Anim = 767)
attr = SCA, AP
stateNo = 762
slot = 0
time = 1
ignoreHitPause = 1

[State -3, Assert: NoWalk after Parry]
type = AssertSpecial
trigger1 = var(26) > 0
trigger1 = var(26) := (var(26)-1)
flag = NoWalk
ignoreHitPause = 1

[State -3, Corner Push]
type = VarSet
trigger1 = fvar(5)
trigger1 = NumTarget
trigger1 = Target, HitOver || (Target, GetHitVar(HitShakeTime) > 0 && Target, Time <= 0)
fvar(5) = 0

[State -3, Corner Push]
type = VarSet
trigger1 = MoveContact = 1 && NumTarget
fvar(5) = Target, GetHitVar(xVel)
ignoreHitPause = 1

[State -3, Corner Push]
type = PosAdd
triggerAll = fvar(5)
triggerAll = (StateType = S || StateType = C) && NumTarget
triggerAll = !HitPauseTime && Target, GetHitVar(HitShakeTime) <= 0
triggerAll = (Target, StateType = S || Target, StateType = C) && !(Target, GetHitVar(yvel)) && !(Target, HitFall)
trigger1 = Target, FrontEdgeBodyDist <= abs(Target, vel x)
trigger1 = (Target, GetHitVar(xvel) * Target, Facing) > 0
trigger2 = Target, BackEdgeBodyDist <= abs(target, vel x)
trigger2 = (Target, GetHitVar(xvel) * Target, Facing) < 0
x = ifElse(Target, FrontEdgeBodyDist <= 0, -1, 1) * (Target, Facing) * fvar(5)

[State -3, Corner Push]
type = VarSet
trigger1 = fvar(5)
trigger1 = abs(fvar(5)) < 1.0
fvar(5) = 0

[State -3, Corner Push]
type = VarSet
trigger1 = NumTarget
trigger1 = Target, GetHitVar(HitShakeTime) <= 0
fvar(5) = fvar(5) * 0.85

[State -3, EX FX Decrement]
type = VarAdd
trigger1 = var(25) > 0
var(25) = -1

[State -3, EX FX Reset]
type = VarSet
trigger1 = (StateNo != [1000,2999]) || MoveType = H
var(25) = 0

[State -3, EX Flash]
type = PalFX
trigger1 = !(GameTime % 2) && var(25)
time = 1
color = 0
mul = 256, 224, 0
add = 128, 128, 128
ignoreHitPause = 1

[State -3, Movement AfterImage]
type = AfterImage
triggerAll = Time = 1 && !var(20)
trigger1 = StateNo = 50 && (var(3) = 2 || var(3) = 3)
trigger2 = (StateNo = [700,715])
time = 2
timeGap = 1
frameGap = 4
length = 9
palBright = 0,0,0
palContrast = 128,128,128
palPostBright = 0,0,0
palAdd = 0,0,0
palMul = 0.9,0.9,0.9
trans = Add1

[State -3, Level 1 Super AfterImage]
type = AfterImage
trigger1 = (StateNo = 3000 || StateNo = 3100 || StateNo = 3300) && Time = 43
time = 2
timeGap = 1
frameGap = 10
length = 21
palBright = 0,0,0
palContrast = 128,128,128
palPostBright = 0,0,0
palAdd = 0,0,0
palMul = 0.75,0.75,0.75
trans = Add1

[State -3, Level 2 Super AfterImage]
type = AfterImage
trigger1 = StateNo = 3050 && Time = 43
trigger2 = StateNo = 3150 && Time = 43
trigger3 = StateNo = 3350 && Time = 43
time = 2
timeGap = 1
frameGap = 10
length = 21
palBright = 0,0,0
palContrast = 32,32,160
palPostBright = 0,0,0
palAdd = 0,0,0
palMul = 0.75,0.75,0.75
trans = Add1

[State -3, Level 3 Super AfterImage]
type = AfterImage
trigger1 = StateNo = 3200 && Time = 43
time = 2
timeGap = 1
frameGap = 10
length = 21
palBright = 0,0,0
palContrast = 160,32,32
palPostBright = 0,0,0
palAdd = 0,0,0
palMul= 0.75,0.75,0.75
trans = Add1

[State -3, AfterImage Persist]
type = AfterImageTime
trigger1 = StateNo = 50 || (StateNo = [600,699])
trigger1 = (var(3) = 2 || var(3) = 3) && vel y < -1
trigger2 = var(20)
trigger3 = StateNo = [700,715]
trigger4 = (StateNo = [3000,4999])
time = 2

[State -3, Underground Juggle Prevention]
type = TargetBind
trigger1 = MoveContact = 1
trigger1 = NumTarget && NumEnemy
trigger1 = (Target, Time = 0) && (Target, ID = EnemyNear, ID)
trigger1 = !(Target, HitShakeOver) && (Target, pos y > 0)
pos = ceil(P2Dist x), ceil(-pos y)
ignoreHitPause = 1

[State -3, Prevent Crossup]
type = Width
trigger1 = MoveType != H
edge = 8, 0
ignoreHitPause = 1

[State -3, Variable Height]
type = PlayerPush
triggerAll = StateType = A && MoveType != H && NumEnemy
triggerAll = P2BodyDist x = [-(EnemyNear, const(size.ground.back) + EnemyNear, const(size.ground.front)), 0]
trigger1 = P2StateType = S
trigger1 = P2Dist y >= (EnemyNear, const(size.height) - 12)
trigger2 = P2StateType = C
trigger2 = P2Dist y >= (EnemyNear, const(size.height) - 28)
trigger3 = P2StateType = L
trigger3 = P2Dist y >= 12
value = 0
ignoreHitPause = 1

[State -3, Get Hit Sound]
type = PlaySnd
triggerall = Alive && Time = 1
triggerall = StateNo = 5000 || StateNo = 5010
trigger1 = GetHitVar(AnimType) >= 2 && Random < 500
trigger2 = GetHitVar(AnimType) = 1 && Random < 375
trigger3 = GetHitVar(AnimType) = 0 && Random < (250 * (AILevel ** 2 / 64.0))
value = 5000,(Random % 3)
channel = 0
ignoreHitPause = 1

[State -3, Get Hit Sound]
type = PlaySnd
triggerAll = Alive && Time = 1
trigger1 = (StateNo = 5000 || StateNo = 5010) && NumEnemy
trigger1 = GetHitVar(fall) || (EnemyNear, HitDefAttr = SCA,SA,HA)
trigger2 = (StateNo = 5020 || StateNo = 5070 || StateNo = 5080)
trigger3 = (StateNo = 5050 || StateNo = 5100) && (PrevStateNo != [5000,5199])
value = 5000,(Random % 3)
channel = 0
ignoreHitPause = 1

[State -3, Cheap KO]
type = ChangeState
trigger1 = !Alive && (StateNo = [5000,5010])
trigger1 = (PrevStateNo = [130,131]) || (PrevStateNo = [140,141]) || (PrevStateNo = [150,153])
value = 5950
ignoreHitPause = 1

[State -3, Assert: NoKOsnd (Cheap KO)]
type = AssertSpecial
trigger1 = (StateNo = [5000,5010])
trigger1 = (PrevStateNo = [130,131]) || (PrevStateNo = [140,141]) || (PrevStateNo=[150,153])
flag = NoKOsnd
ignoreHitPause = 1

[State -3, Custom Combo Finish]
type = Helper
triggerAll = WinKO && var(20)
triggerAll = RoundState = 3 && !NumHelper(8600)
trigger1 = MoveHit = [1,4]
trigger2 = NumHelper(1005)
trigger2 = (Helper(1005), StateNo = [1005,1007]) && (Helper(1005), var(18))
trigger3 = StateNo = 811
trigger4 = StateNo = 820 && (AnimElemTime(14) = [0,1])
trigger5 = StateNo = 860 && (AnimElemTime(14) = [0,1])
trigger6 = NumHelper(1105)
trigger7 = StateNo = 1501
helperType = Normal
stateNo = 8600
ID = 8600 + 0 * (var(23) := 900)
name = "Super Finish"
posType = left
pos = 160, -120
ownPal = 1
pauseMoveTime = 255
superMoveTime = 255
ignoreHitPause = 1

[State -3, Super Finish]
type = Helper
triggerAll = WinKO
triggerAll = RoundState = 3 && !NumHelper(8600)
trigger1 = MoveHit = 1 && (StateNo = [3000,4999])
trigger1 = var(23) := StateNo
trigger2 = (StateNo = [3000,3099])
trigger2 = var(23) := 3000
trigger3 = numHelper(3207)
trigger3 = (helper(3207), moveHit = 1)
trigger3 = var(23) := 3100
trigger4 = (StateNo = [3200,3299])
trigger4 = var(23) := 3200
helperType = Normal
stateNo = 8600
ID = 8600
name = "Super Finish"
posType = left
pos = 160,-120
ownPal = 1
pauseMoveTime = 255
superMoveTime = 255
ignoreHitPause = 1

