                            _________________________________________________________________
===========================| Hsien-Ko by Phantom.of.the.Server, edit by varo_hades & gui0007 |===========================
                            �����������������������������������������������������������������       [24.06.19]

 - Contact:	varo_hades@hotmail.com
 - Website:	https://varohades.wixsite.com/varohadesmugen
 - Customized version of Capcom's Hsien-Ko character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Modernized POTS Style
 - Details and moves taken from her Darkstalkers & Namco x Capcom appearances
 - Gameplay mixed from several games, including Darkstalkers and Capcom vs. SNK
 - Special intro versus Servbot

=====<Update Log>=====

 - varo_hades
 * Modernized POTS Style stuff inserted (hitboxes, FXs, sounds, Level 3 Portrait etc.)

 - gui0007
 * New Level 3 Portrait (thanks Hades!)
 * Level 3 Portrait fixed/centered
 * Supers KO Texts now are the correct ones (thanks 2Dee4ever for the texts!)
 * Misaligned sprites fixed
 * A serious issue on Tenrai Ha is fixed

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

<NORMAL>

.Rantetsu 				F + y
.Edoga					F + z
.Hourei:	         		F/B + 2p		(near opponent)
.Hourei:				F/B + 2k		(near opponent)
.Houten:				F/B + 2p		(Air, near opponent)

<SPECIAL>

.Anki Hou (EX)				D, DF, F, p
.Senpuu Bu (EX)				F, D, DF, p
.Henkyou Ki (EX)			D, DB, B, p
.Houten Geki (EX)			F, DF, D, DB, B, p
.Zanpa (EX)				D, D, k			(while opponent is downed)

<SUPER>

.Chuukadan (MAX):			D, DF, F, D, DF, F, p
.Chireitou (MAX):			D, DF, F, D, DF, F, k
.Rimoukon (MAX):			D, DB, B, D, DB, B, k

<Lv3 SUPER>

.Tenrai Ha:                		D, DB, B, D, DB, B, 2p / a, c, y, y, U

<SYSTEM>

.Forward Dash:                  	F, F
   .Run:                        	hold
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	a + x
   .Sidestep Attack:            	p / k
.Forward Roll:                  	F + a + x
.Backward Roll:                 	B + a + x
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold b + y
.Zero Counter:                  	B, DB, D, p / k 	(during standing or crouching guard)
.Custom Combo:                  	c + z           	(Air also)
.Fall Recovery:                 	2p / a + x      	(while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

=====<Miscellaneous>=====

- To change his size to TV aspect ratio (a.k.a. CvS scale), open the .def file and replace
  "Constants.cns" with "ConstantsCvS.cns".

=====<Special Thanks>=====
 - P.o.t.S. for code, effects, hitsparks, formatting style
 - Everybody at the MUGEN for feedback

=====<Disclaimer>=====

 - The Hsien-Ko character, Darkstalkers� and Capcom vs. SNK� are property of Capcom�
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes