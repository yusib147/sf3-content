; ________________________________________________
;| Hsien-Ko by Phantom.of.the.Server & varo_hades |
; ������������������������������������������������
;==============================================================================================
;=======================================<HELPER STATES>========================================
;==============================================================================================

;====================<PARRY HELPER>=========================
[StateDef 765]
type = A
physics = N
moveType = I
anim = ifElse(Root, StateType = C, 766, ifElse(Root, StateType = A, 767, 765))
velSet = 0,0
ctrl = 0

[State 765, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 765, BindToRoot]
type = BindToRoot
trigger1 = 1
time = -1

[State 765, Change to Crouching]
type = ChangeAnim
triggerAll = !Time
trigger1 = !(Root, AILevel) && Root, command = "down"
trigger2 = Root, AILevel && (Root, StateType != A) && P2StateType = C
value = 766

[State 765, Change to Standing / Jumping]
type = ChangeAnim
triggerAll = !Time
trigger1 = !(Root, AILevel) && Root, command = "fwd"
trigger2 = Root, AILevel && Anim != 766
value = ifElse((Root, StateType = A), 767, 765)

[State 765, Change to Standing / Jumping]
type = ChangeAnim
trigger1 = Anim = 765 || Anim = 767
value = ifElse((Root, StateType = A), 767, 765)

[State 765, Disable]
type = VarSet
trigger1 = Time >= ifElse((Root, StateType = A), 7, 8)
trigger2 = Facing != (Root, Facing)
trigger3 = !(Root, ctrl)
trigger3 = (Root, StateNo != [760,762]) && (Root, StateNo != 5120)
var(0) = 1

[State 765, Disable]
type = VarSet
triggerAll = !(Root, AILevel)
trigger1 = (Root, command = "holdback")
trigger2 = Time < 4 && (Root, command = "holdfwd" + Root, command = "holddown") > 1
trigger3 = Time >= 4 && (Root, command = "holdfwd" || Root, command = "holddown")
trigger4 = Time >= 1 && (((Anim = 765 || Anim = 767) && Root, command = "fwd") || (Anim = 766 && Root, command = "down"))
var(0) = 1

[State 765, Disable]
type = ChangeAnim
trigger1 = var(0) = 1
value = 1

[State 765, Standing/Air]
type = ReversalDef
trigger1 = !var(0) && (Anim = 765 || Anim = 767)
trigger1 = (Root, StateNo != 5120) || !(Root, AnimTime)
reversal.attr = SCA,AA
p1StateNo = 766
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, Crouching]
type = ReversalDef
trigger1 = !var(0) && Anim = 766
reversal.attr = SC,AA
p1StateNo = 766
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, Disable]
type = ReversalDef
trigger1 = var(0) = 1
reversal.attr =
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, End]
type = DestroySelf
trigger1 = Time >= 18
trigger2 = (Root, MoveType != I)
trigger3 = !(Root, ctrl) && (Root, StateNo != [760,762]) && (Root, StateNo != 5120)
trigger4 = (Root, StateNo = [760,762]) && (Root, Time <= 1)

;Success
[StateDef 766]
moveType = I
ctrl = 0

[State 766, Disable]
type = VarSet
trigger1 = 1
var(0) = 1

[State 766, End]
type = DestroySelf
trigger1 = Root, StateNo = [760,762]
trigger2 = Time >= 2

;=====================<ANKI HOU PROJECTILE>=========================
[Statedef 1005]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0, 0
sprpriority = 2

[State 1005, HitOverride]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AA, AP, AT
stateno = 1006
ignorehitpause = 1

[State 1005, HB]
type = hitby
trigger1 = anim != 1004
time = -1
value = SCA, NP, SP, HP
ignorehitpause = 1

[State 1005, HB]
type = hitby
trigger1 = anim = 1004
time = -1
value = SCA, NA, SA, HA, NP, SP, HP
ignorehitpause = 1

[State 1005, animvar]
type = varrandom
trigger1 = !time && !prevstateno && !(root, var(40)) && root, stateno != 196
v = 0
range = 1, 6

[State 1005, Anim]
type = changeanim
trigger1 = !time && !prevstateno && !(root, var(40)) && root, stateno != 196
value = ifelse(random < 200, 1019, 1004 + var(0))

[State 1005, Anim]
type = changeanim
trigger1 = !time && !prevstateno && (root, var(40) = 1) && root, stateno != 196
value = ifelse(random < 500, 1018, 1019)

[State 1005, Anim]
type = changeanim
trigger1 = !time && !prevstateno && (root, var(40) = 2) && root, stateno != 196
value = ifelse(random < 333, 1020, ifelse(random < 500, 1021, 1023))

[State 1005, pandaanim]
type = changeanim
trigger1 = !time && !prevstateno && root, stateno = 196
value = 1004

[State 1005, shurikenvar]
type = parentvarset
trigger1 = !time
trigger1 = playerIDexist(parent, ID)
trigger1 = anim = 1018 || anim = 1019
var(40) = ifelse(!(parent, var(30)), 1, 2)

[State 1005, dizzyingvar]
type = parentvarset
trigger1 = !time
trigger1 = playerIDexist(parent, ID)
trigger1 = anim = 1020 || anim = 1021 || anim = 1023
var(40) = 0

[State 1005, Strength]
type = varset
trigger1 = !time
var(10) = root, var(10)

[State 1005, Vel]
type = velset
trigger1 = !time && anim != 1004
x = ifelse(var(10) = 2, 0.5, ifelse(var(10) = 1, 6, 5))
y = ifelse(var(10) = 2, -15, ifelse(var(10) = 1, -9, -5))

[State 1005, Vel]
type = velset
trigger1 = !time && anim = 1004
x = 6
y = -9

[State 1005, Accel]
type = gravity
trigger1 = 1

[State 1005, spinsnd]
type = playsnd
trigger1 = anim = 1005 || anim = 1006 || anim = 1019
trigger1 = !(time % 12)
value = 1, 7
channel = 1

[State 1005, spinsnd]
type = playsnd
trigger1 = anim = 1007 || anim = 1009 || anim = 1010 || anim = 1018
trigger1 = !(time % 12)
value = 1, 1
channel = 1

[State 1005, spinsnd]
type = playsnd
trigger1 = anim = 1008
trigger1 = !(time % 9)
value = 1, 1
channel = 1

[State 1005, spinsnd]
type = playsnd
trigger1 = anim = 1004 || anim = 1020 || anim = 1021 || anim = 1023
trigger1 = !(time % 12)
value = 1, 2
channel = 1

[State 1005, HitSound]
type = playsnd
trigger1 = anim = 1010 || anim = 1018
trigger1 = movehit && numtarget
trigger1 = !(target, time) && target, movetype = H
value = 2, 2
persistent = 0
ignorehitpause = 1

[State 1005, HitSound]
type = playsnd
trigger1 = anim = 1020 || anim = 1023 || anim = 1009
trigger1 = movehit && numtarget
trigger1 = !(target, time) && target, movetype = H
value = 2, 4
persistent = 0
ignorehitpause = 1

[State 1005, HitSound]
type = playsnd
trigger1 = anim = 1004
trigger1 = movehit && numtarget
trigger1 = !(target, time) && target, movetype = H
value = 2, 3
persistent = 0
ignorehitpause = 1

[State 1005, HitSound]
type = playsnd
trigger1 = anim = 1021
trigger1 = movehit && numtarget
trigger1 = !(target, time) && target, movetype = H
value = 2, 5
persistent = 0
ignorehitpause = 1

[State 1005, HitSound]
type = playsnd
trigger1 = anim = 1005 || anim = 1006 || anim = 1007 || anim = 1008 || anim = 1019
trigger1 = movehit && numtarget
trigger1 = !(target, time) && target, movetype = H
value = 2, 8
persistent = 0
ignorehitpause = 1

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1005, Hit]
type = hitdef
trigger1 = var(10) != 2
trigger1 = anim < 1020
priority = 4, Hit
attr = S, SP
damage = ceil(83 * root, fvar(11)), 7
animtype = Hard
hitflag = MAF
guardflag = MA
pausetime = 0, 10
sparkno = -1
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkxy = -10, 0
guardsound = s3, 0
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -1.5 * vel x, 0
ground.cornerpush.veloff = 0
air.velocity = -vel x, -2
down.velocity = 0, 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
sprpriority = 2
air.fall = 1
fall.recover = 1
fall.recovertime = 28
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1005, Hit]
type = hitdef
trigger1 = var(10) = 2
trigger1 = anim < 1020
priority = 4, Hit
attr = S, SP
damage = ceil(83 * root, fvar(11)), 7
animtype = Hard
hitflag = MAF
guardflag = HA
pausetime = 0, 10
sparkno = -1
sparkxy = -10, 0
guard.sparkNo = -1 + 0 * (var(34) := 8001)
guardsound = s3, 0
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -1.5 * vel x, 0
ground.cornerpush.veloff = 0
air.velocity = -vel x, -2
down.velocity = 0, 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
sprpriority = 2
air.fall = 1
fall.recover = 1
fall.recovertime = 28
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1005, Hit]
type = hitdef
trigger1 = var(10) != 2
trigger1 = anim >= 1020
priority = 4, Hit
attr = S, SP
damage = ceil(83 * root, fvar(11)), 7
animtype = Back
hitflag = MAF
guardflag = MA
pausetime = 0, 10
sparkno = -1
sparkxy = -10, 0
guard.sparkNo = -1 + 0 * (var(34) := 8001)
guardsound = s3, 0
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -4.5, -3
ground.cornerpush.veloff = 0
air.velocity = -4.5, -3
down.velocity = 0, 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
sprpriority = 2
guard.velocity = -12.97
fall = 1
fall.recover = 0
ID = 1020
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1005, Hit]
type = hitdef
trigger1 = var(10) = 2
trigger1 = anim >= 1020
priority = 4, Hit
attr = S, SP
damage = ceil(83 * root, fvar(11)), 7
animtype = Back
hitflag = MAF
guardflag = HA
pausetime = 0, 10
sparkno = -1
sparkxy = -10, 0
guard.sparkNo = -1 + 0 * (var(34) := 8001)
guardsound = s3, 0
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -4.5, -3
ground.cornerpush.veloff = 0
air.velocity = -4.5, -3
down.velocity = 0, 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envshake.time = 18
envshake.freq = 120
envshake.ampl = 6
sprpriority = 2
guard.velocity = -12.97
fall = 1
fall.recover = 0
ID = 1020
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1005, p2state]
type = targetstate
trigger1 = var(10) = 2 && anim >= 1020
trigger1 = movehit && numtarget
trigger1 = (target, stateno = 5000) || (target, stateno = 5010) || (target, stateno = 5020)
value = 1115020
ignorehitpause = 1

[State 1005, target]
type = targetstate
trigger1 = movehit && numtarget(1020)
trigger1 = !(target(1020), ishelper)
value = 1115020
persistent = 0
ignorehitpause = 1

[State 1005, Hit]
type = hitdef
trigger1 = anim = 1004
priority = 1, Hit
attr = S, SP
damage = ceil(28 * root, fvar(11)), 7
animtype = Hard
hitflag = MAF
guardflag = MA
pausetime = 0, 10
sparkno = -1
sparkxy = -10, 0
guard.sparkNo = -1 + 0 * (var(34) := 8001)
guardsound = s3, 0
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -1.5 * vel x, 0
ground.cornerpush.veloff = 0
air.velocity = -vel x, -2
down.velocity = 0, 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
sprpriority = 2
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1
air.fall = 1
fall.recover = 1
fall.recovertime = 28

[State 1005, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && (anim = 1004 || anim = 1009 || anim = 1010 || anim = 1018 || anim = 1020 || anim = 1021 || anim = 1023)
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), -floor(p2dist y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1005, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && (anim = 1005 || anim = 1006 || anim = 1007 || anim = 1008 || anim = 1019)
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8016)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), -floor(p2dist y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1005, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1005, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1005, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1005, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1000,1030]
var(18) = 1

[State 1005, End]
type = changestate
trigger1 = movecontact || pos y >= -10
value = 1006
ignorehitpause = 1

[State 1005, End]
type = destroyself
trigger1 = pos x != [ -200, 200]

;Destroy
[Statedef 1006]
type = A
physics = N
movetype = I
velset = -.66 * vel x, vel y
ctrl = 0
sprpriority = 1

[State 1006, Anim]
type = changeanim
trigger1 = anim = 1021
value = 1022
persistent = 0

[State 1006, Accel]
type = gravity
trigger1 = 1

[State 1006, End]
type = destroyself
trigger1 = pos y >= -10

;=====================<EX ANKI HOU PROJECTILE>=========================
[Statedef 1035]
type = C
physics = N
movetype = A
anim = 1035
ctrl = 0
velset = 0, 0
sprpriority = 2

[State 1035, HB]
type = hitby
trigger1 = 1
time = -1
value = SCA, NP, SP, HP
ignorehitpause = 1

[State 1035, HitOverride]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AA, AP, AT
stateno = 1036
ignorehitpause = 1

[State 1035, Strength]
type = varset
trigger1 = !time
var(10) = root, var(10)

[State 1035, Push]
type = playerpush
trigger1 = 1
value = 0

[State 1035, Vel]
type = velset
trigger1 = 1
x = 5
y = 0

[State 1035, HitSound]
type = playsnd
trigger1 = movehit && numtarget
trigger1 = !(target, time) && target, movetype = H
value = 2, 2
persistent = 0
ignorehitpause = 1

[State 1035, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1035, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1035, Hit]
type = hitdef
trigger1 = 1
priority = 4, Hit
attr = S, SP
damage = ceil(ifelse(p2statetype = L, 7, 46) * root, fvar(11)), 7
animtype = Hard
hitflag = MAFD
guardflag = L
pausetime = 0, 10
sparkno = -1
sparkxy = -10, 0
guard.sparkno = -1 + 0 * (var(34) := 8001)
guardsound = s3, 0
ground.type = Low
ground.slidetime = 20
ground.hittime = 20
ground.velocity = -7, 0
ground.cornerpush.veloff = 0
air.velocity = -3, -3
down.hittime = 20
down.velocity = 0, 0
getpower = 0
givepower = 36, 36
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
sprpriority = 2
air.fall = 1
fall.recover = 0
yaccel = 0.5
forcestand = 1

[State 1035, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), -floor(p2dist y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1035, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1035, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1035, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1035, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1000,1030]
var(18) = 1

[State 1035, End]
type = changestate
trigger1 = movecontact
value = 1036
ignorehitpause = 1

[State 1035, End]
type = destroyself
trigger1 = pos x != [ -200, 200]

;Finish
[Statedef 1036]
type = A
physics = N
movetype = I
anim = 1036
velset = -.33 * vel x, 0
ctrl = 0
sprpriority = 1

[State 1036, fadeout]
type = trans
trigger1 = time >= 12
trans = addalpha
alpha = ceil(256 -10.7 * (time -12)), ceil(10.7 * (time -12))

[State 1036, End]
type = destroyself
trigger1 = time >= 36

;========================<SENPUU BU PROJECTILE>=============================
[Statedef 1105]
type = A
physics = N
movetype = A
anim = 1105
ctrl = 0
velset = 0, 0
sprpriority = -1

[State 1105, No Reversals]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AT
stateno = 5000
ignorehitpause = 1

[State 1105, Strength]
type = varset
trigger1 = !time
var(10) = parent, var(10)

[State 1105, Bind]
type = bindtoroot
trigger1 = 1
pos = 2, -65

[State 1105, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1105, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1105, Hit]
type = hitdef
trigger1 = var(10) <= 2 && !(time % 20) && hitcount < 4
priority = 4, Hit
attr = A, SA
damage = ceil(35 * root, fvar(11)), 7
animtype = Hard
hitflag = MAFD
guardflag = MA
pausetime = 0, 6
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -15, 0
hitsound = s2, 9
guardsound = s3, 0
ground.type = High
ground.slidetime = 20
ground.hittime = 20
ground.velocity = ifelse(p2dist x > 0, -10, 10), 0
ground.cornerpush.veloff = 0
air.velocity = ifelse(p2dist x > 0, -5, 5), -5
down.velocity = 0, 0
p2facing = ifelse(p2dist x >= 0, 1, -1)
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
sprpriority = -1
air.fall = 1
fall.recover = 1
fall.recovertime = 20
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1105, Hit]
type = hitdef
trigger1 = var(10) = 3 && !(time % 16) && hitcount < 8
priority = 4, Hit
attr = A, SA
damage = ceil(35 * root, fvar(11)), 7
animtype = Hard
hitflag = MAFD
guardflag = MA
pausetime = 0, 6
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -15, 0
hitsound = s2, 9
guardsound = s3, 0
ground.type = High
ground.slidetime = 20
ground.hittime = 20
ground.velocity = ifelse(p2dist x > 0, -10, 10), 0
ground.cornerpush.veloff = 0
air.velocity = ifelse(p2dist x > 0, -5, 5), -5
down.velocity = 0, 0
p2facing = ifelse(p2dist x >= 0, 1, -1)
getpower = 0
givepower = 36, 36
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
sprpriority = -1
air.fall = 1
fall.recover = 0
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1105, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8016)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), -floor(p2dist y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1105, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1105, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1105, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1105, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1100,1130]
var(18) = 1

[State 1105, End]
type = destroyself
trigger1 = var(10) <= 2 && (root, stateno != 1101 || root, anim != 1101)
trigger2 = var(10) = 3 && (root, stateno != 1131 || root, anim != 1101)

;========================<HENKYOU KI PROJECTILE>=============================
[Statedef 1205]
type = S
physics = N
movetype = A
ctrl = 0
sprpriority = 4

[State 1205, nothitby]
type = nothitby
trigger1 = 1
time = -1
value = SCA
ignorehitpause = 1

[State 1205, HB]
type = hitby
trigger1 = !var(5) && (time % 2)
time = 1
value = SCA, NP, SP, HP
ignorehitpause = 1

[State 1205, HitOverride]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AA, AP, AT, HP
stateno = 1206
ignorehitpause = 1

[State 1205, HitOverride]
type = hitoverride
trigger1 = !var(5) && (time % 2)
time = 1
attr = SCA, NP, SP
stateno = 1208
ignorehitpause = 1

[State 1205, Anim]
type = changeanim
trigger1 = anim != 1205
value = 1205

[State 1205, Assert]
type = trans
trigger1 = 1
trans = addalpha
alpha = 256, 256
ignorehitpause = 1

[State 1205, Strength]
type = varset
trigger1 = !time
var(10) = root, var(10)

[State 1205, timevar]
type = varadd
trigger1 = 1
var(44) = 1

[State 1205, Vel]
type = velset
trigger1 = !time && !prevstateno
x = ifelse(var(10) = 2, 6, ifelse(var(10) = 1, 4.5, 3))
y = 0

[State 1205, Vel]
type = velmul
trigger1 = 1
x = 0.9
y = 0

[State 1205, particles]
type = explod
trigger1 = 1
vel = -.5 + (random < 500), 0
accel = 0, 0.05
anim = 1208
sprpriority = 3
postype = p1
pos = -15, 0
random = 30, 60
removetime = -2
scale = 0.5, 0.5
ignorehitpause = 1

[State 1205, Shadows]
type = afterimage
trigger1 = !time && !prevstateno
time = 999
timegap = 1
framegap = 4
length = 12
palcontrast = 30, 60, 120
trans = add

[State 1205, Type]
type = statetypeset
trigger1 = movecontact
movetype = I

[State 1205, HitSound]
type = playsnd
trigger1 = movehit && numtarget
trigger1 = !(target, time) && target, movetype = H
value = 2, 6
persistent = 0
ignorehitpause = 1

[State 1205, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1205, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1205, Hit]
type = hitdef
trigger1 = 1
priority = 7, Hit
attr = S, SA
damage = ceil(111 * root, fvar(11)), 14
animtype = Hard
hitflag = MAF
guardflag = MA
pausetime = 0, 10
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, 0
guardsound = s3, 0
ground.type = Low
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -7, 0
ground.cornerpush.veloff = 0
air.velocity = -3, -3
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
sprpriority = 4
air.fall = 1
fall.recover = 1
fall.recovertime = 46
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1205, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), -floor(p2dist y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1205, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1205, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1205, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1205, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1200,1230]
var(18) = 1

[State 1205, Reversal]
type = reversaldef
trigger1 = !var(5) && (time % 2)
reversal.attr = SCA, NP, SP
priority = 7, Hit
p1stateno = 1208
p2stateno = 1220
sparkno = -1
pausetime = 0, 0
numhits = 0
p1sprpriority = 4

[State 1205, End]
type = changestate
trigger1 = var(44) >= 20
value = 1206

[State 1205, End]
type = destroyself
trigger1 = pos x != [ -200, 200]

;Reflect
[Statedef 1206]
type = A
physics = N
movetype = I
velset = 0, 0
ctrl = 0
sprpriority = 1

[State 1206, nothitby]
type = hitby
trigger1 = 1
time = -1
value = SCA
ignorehitpause = 1

[State 1206, Assert]
type = trans
trigger1 = 1
trans = addalpha
alpha = 256, 256
ignorehitpause = 1

[State 1206, Shadows]
type = afterimagetime
trigger1 = 1
time = 0

[State 1206, palfx]
type = palfx
trigger1 = !time
time = 24
sinadd = -255, -255, -255, 106

[State 1206, End]
type = destroyself
trigger1 = time >= 24

;--- Reflect ---
[Statedef 1208]
type = A
physics = N
movetype = I
ctrl = 0

[State 1208, nothitby]
type = nothitby
trigger1 = 1
time = -1
value = SCA
ignorehitpause = 1

[State 1208, Assert]
type = trans
trigger1 = 1
trans = addalpha
alpha = 256, 256
ignorehitpause = 1

[State 1208, reflected]
type = helper
trigger1 = !time
helpertype = normal
stateno = 1215
ID = 1215
name = "Reflected"
postype = p1
pos = 25, 0
ownpal = 1
size.xscale = 1
size.yscale = 1

[State 1208, End]
type = changestate
trigger1 = 1
value = 1205

;========================<RANDOM PROJECTILE>=============================
[Statedef 1215]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0, 0
sprpriority = 4

[State 1215, HitOverride]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AA, AP, AT
stateno = 1216
ignorehitpause = 1

[State 1215, HB]
type = hitby
trigger1 = 1
time = -1
value = SCA, NP, SP, HP
ignorehitpause = 1

[State 1215, Assert]
type = trans
trigger1 = 1
trans = addalpha
alpha = 256, 256
ignorehitpause = 1

[State 1215, Anim]
type = changeanim
trigger1 = !time && !prevstateno
value = 1215

[State 1215, Strength]
type = varset
trigger1 = !time
var(10) = 2

[State 1215, Vel]
type = velset
trigger1 = 1
x = 6

[State 1215, particles]
type = explod
trigger1 = !(time % 3)
vel = -.5 + (random < 500), 0
accel = 0, 0.05
anim = 1217
sprpriority = 3
postype = p1
pos = -15, 0
random = 30, 60
removetime = -2
scale = 0.5, 0.5
ignorehitpause = 1

[State 1215, HitSound]
type = playsnd
trigger1 = movehit && numtarget
trigger1 = !(target, time) && target, movetype = H
value = 2, 6
persistent = 0
ignorehitpause = 1

[State 1215, Hit]
type = hitdef
trigger1 = 1
priority = 4, Hit
attr = S, SP
damage = 83, 7
animtype = Hard
hitflag = MAF
guardflag = MA
pausetime = 0, 10
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, 0
guardsound = s3, 0
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -10, 0
ground.cornerpush.veloff = 0
air.velocity = -4, -2
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
air.fall = 1
fall.recover = 1
fall.recovertime = 16
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1215, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), -floor(p2dist y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1215, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1215, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1215, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1215, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1200,1230]
var(18) = 1

[State 1215, End]
type = changestate
trigger1 = movecontact
value = 1216
ignorehitpause = 1

[State 1215, End]
type = destroyself
trigger1 = pos x != [ -200, 200]

;Finish
[Statedef 1216]
type = A
physics = N
movetype = I
velset = 0, 0
ctrl = 0
anim = 1216
sprpriority = 4

[State 1216, Assert]
type = trans
trigger1 = 1
trans = addalpha
alpha = 256, 256
ignorehitpause = 1

[State 1216, End]
type = destroyself
trigger1 = !animtime

;========================<REFLECTED HELPER>=============================
[Statedef 1220]
type = S
movetype = A
ctrl = 0
sprpriority = 4
hitdefpersist = 1

[State 1220, nothelper]
type = selfstate
trigger1 = !ishelper
value = 5000
ignorehitpause = 1

[State 1220, nothelperprojectile]
type = selfstate
trigger1 = !(hitdefattr = SCA, NP, SP, HP)
value = prevstateno
ignorehitpause = 1

[State 1220, removefx]
type = removeexplod
trigger1 = numexplod
ignorehitpause = 1

[State 1220, End]
type = destroyself
trigger1 = 1
ignorehitpause = 1

;========================<EX HENKYOU KI PROJECTILE>=============================
[Statedef 1235]
type = S
physics = N
movetype = A
ctrl = 0
sprpriority = 4

[State 1235, nothitby]
type = nothitby
trigger1 = 1
time = -1
value = SCA
ignorehitpause = 1

[State 1235, HB]
type = hitby
trigger1 = !var(5) && (time % 2)
time = 1
value = SCA, NP, SP, HP
ignorehitpause = 1

[State 1235, HitOverride]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AA, AP, AT
stateno = 1236
ignorehitpause = 1

[State 1235, HitOverride]
type = hitoverride
trigger1 = !var(5) && (time % 2)
time = 1
attr = SCA, AP
stateno = 1238
ignorehitpause = 1

[State 1235, Anim]
type = changeanim
trigger1 = !time && !prevstateno
value = 1205

[State 1235, Assert]
type = trans
trigger1 = 1
trans = addalpha
alpha = 256, 256
ignorehitpause = 1

[State 1235, hitvar]
type = varadd
trigger1 = !time
var(2) = 1

[State 1235, timevar]
type = varadd
trigger1 = 1
var(44) = 1

[State 1235, Vel]
type = velset
trigger1 = !time && !prevstateno
x = 6

[State 1235, Vel]
type = velmul
trigger1 = 1
x = 0.95

[State 1235, Shadows]
type = afterimage
trigger1 = !time && !prevstateno
time = 999
timegap = 1
framegap = 4
length = 12
palcontrast = 30, 60, 120
trans = add

[State 1235, particles]
type = explod
trigger1 = 1
vel = -.5 + (random < 500), 0
accel = 0, 0.05
anim = 1208
sprpriority = 3
postype = p1
pos = -15, 0
random = 30, 60
removetime = -2
scale = 0.5, 0.5
ignorehitpause = 1

[State 1235, Type]
type = statetypeset
trigger1 = movecontact && var(2) >= 4
movetype = I

[State 1235, HitSound]
type = playsnd
trigger1 = movehit && numtarget
trigger1 = !(target, time) && target, movetype = H
value = 2, 6
channel = 1
persistent = 0
ignorehitpause = 1

[State 1235, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1235, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1235, Hit]
type = hitdef
trigger1 = var(2) <= 3
priority = 4, Hit
attr = S, SA
damage = ceil(56 * root, fvar(11)), 7
animtype = Hard
hitflag = MAF
guardflag = MA
pausetime = 6, 10
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, 0
guardsound = s3, 0
ground.type = Low
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -10, 0
ground.cornerpush.veloff = 0
air.velocity = -4, -4
getpower = 0
givepower = 36, 36
envshake.time = 14
envshake.freq = 120
envshake.ampl = 4
sprpriority = 4
air.fall = 1
fall.recover = 0
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1235, Reversal]
type = reversaldef
trigger1 = !var(5) && (time % 2)
reversal.attr = SCA, AP
priority = 7, Hit
p1stateno = 1238
p2stateno = 1220
sparkno = -1
pausetime = 0, 0
numhits = 0
p1sprpriority = 4

[State 1235, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), -floor(p2dist y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1235, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1235, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1235, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1235, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1200,1230]
var(18) = 1

[State 1235, End]
type = changestate
trigger1 = movecontact
value = 1235
ignorehitpause = 1

[State 1235, End]
type = changestate
trigger1 = var(44) >= 45
value = 1206
ignorehitpause = 1

[State 1235, End]
type = destroyself
trigger1 = pos x != [ -200, 200]

;--- Reflect ---
[Statedef 1238]
type = A
physics = N
movetype = I
ctrl = 0

[State 1238, nothitby]
type = nothitby
trigger1 = 1
time = -1
value = SCA
ignorehitpause = 1

[State 1238, Assert]
type = trans
trigger1 = 1
trans = addalpha
alpha = 256, 256
ignorehitpause = 1

[State 1238, reflected]
type = helper
trigger1 = !time
helpertype = normal
stateno = 1215
ID = 1215
name = "Reflected"
postype = p1
pos = 25, 0
ownpal = 1
size.xscale = 1
size.yscale = 1

[State 1238, End]
type = changestate
trigger1 = 1
value = 1235

;========================<CHUUKADAN PROJECTILE>=============================
[Statedef 3004]
type = A
physics = N
movetype = I
ctrl = 0
velset = 3, -3
sprpriority = 2

[State 3004, Strength]
type = varset
trigger1 = !time
var(10) = root, var(10)

[State 3004, Vel]
type = velset
trigger1 = !time && var(10) = 6
x = 2 + (random / 250.0)
y = -2 -(random / 250.0)

[State 3004, colorvar]
type = varset
trigger1 = !time
var(1) = ifelse((random < 750 || var(10) = 6), 1, 2)

[State 3004, Anim]
type = changeanim
trigger1 = !time
value = ifelse(var(1) = 1, 3005, 3035)

[State 3004, Snd]
type = playsnd
trigger1 = !time
value = 5, 13
channel = 2
loop = 1

[State 3004, HitOverride]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AA, AP, AT
stateno = 3015
ignorehitpause = 1

[State 3004, HB]
type = hitby
trigger1 = 1
time = -1
value = SCA, AA
ignorehitpause = 1

[State 3004, timervar]
type = varset
trigger1 = !time
var(0) = ifelse(var(1) = 1, 599, 239)

[State 3004, timervar]
type = varadd
trigger1 = time
var(0) = -1
ignorehitpause = 1

[State 3004, timer]
type = helper
trigger1 = !time
helpertype = normal
stateno = 3090
ID = 3090
name = "Timer"
postype = p1
facing = ifelse(facing = 1, 1, -1)
ownpal = 1

[State 3004, hit by Lei-Lei]
type = changestate
triggerall = root, movetype = A
triggerall = (root, stateno = [200, 650]) || root, stateno = 1101
trigger1 = ((pos x - root, pos x) * (root, facing) = [0, 100])
trigger1 = ((pos y - root, pos y) = [ -50, 50])
value = 3016

[State 3004, hit by partner]
type = changestate
trigger1 = numpartner
trigger1 = partner, movetype = A && partner, hitdefattr = SCA, AA
trigger1 = ((pos x - partner, pos x) * (partner, facing) = [0, 80])
trigger1 = ((pos y - partner, pos y) = [ -50, 50])
value = 3017

[State 3004, Accel]
type = gravity
trigger1 = 1

[State 3004, Turn]
type = velmul
trigger1 = vel x > 0 && frontedgedist <= 18
trigger2 = vel x < 0 && backedgedist <= 18
x = -1

[State 3004, bounce]
type = changestate
trigger1 = vel y >= 0 && pos y >= -5
value = 3010

[State 3004, detonate]
type = changestate
triggerall = roundstate < 4
trigger1 = var(0) <= 0
trigger2 = root, stateno = 3002 && root, animelemtime(3) >= 10
value = 3020

;--- IDLE ---
[Statedef 3005]
type = S
physics = N
movetype = I
ctrl = 0
velset = 0, 0
sprpriority = 2

[State 3005, timervar]
type = varadd
trigger1 = time
var(0) = -1
ignorehitpause = 1

[State 3005, hit by Lei-Lei]
type = changestate
triggerall = root, movetype = A
triggerall = (root, stateno = [200, 650]) || root, stateno = 1101
trigger1 = ((pos x - root, pos x) * (root, facing) = [0, 100])
trigger1 = ((pos y - root, pos y) = [ -50, 50])
value = 3016

[State 3005, hit by partner]
type = changestate
trigger1 = numpartner
trigger1 = partner, movetype = A && partner, hitdefattr = SCA, AA
trigger1 = ((pos x - partner, pos x) * (partner, facing) = [0, 80])
trigger1 = ((pos y - partner, pos y) = [ -50, 50])
value = 3017

[State 3005, Pos]
type = posset
trigger1 = 1
y = 0

[State 3005, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) >= 420) && anim != 3005
value = 3005

[State 3005, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [180, 419]) && anim != 3006
value = 3006

[State 3005, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [1, 179]) && anim != 3007
value = 3007

[State 3005, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) >= 120) && anim != 3035
value = 3035

[State 3005, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) = [1, 119]) && anim != 3036
value = 3036

[State 3005, poing]
type = playsnd
trigger1 = !time
value = 5, 7

[State 3005, Dust]
type = explod
trigger1 = !time
anim = 8102
ID = 8102
sprpriority = -2
postype = p1
removetime = -2
ownpal = 1
scale = 0.5, 0.5

[State 3005, detonate]
type = changestate
triggerall = roundstate < 4
trigger1 = var(0) <= 0
trigger2 = root, stateno = 3002 && root, animelemtime(3) >= 10
value = 3020

[State 3005, detonate]
type = changestate
trigger1 = roundstate = 4 && var(0) <= 0
value = 3030

;--- BOUNCING ---
[Statedef 3010]
type = S
physics = N
movetype = I
ctrl = 0
sprpriority = 2

[State 3010, timervar]
type = varadd
trigger1 = time
var(0) = -1
ignorehitpause = 1

[State 3010, xvar]
type = varset
trigger1 = !time
fvar(1) = vel x

[State 3010, yvar]
type = varset
trigger1 = !time
fvar(2) = vel y

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) >= 420) && anim != 3010 && time < 6
value = 3010

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [180, 419]) && anim != 3011 && time < 6
value = 3011

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [1, 179]) && anim != 3012 && time < 6
value = 3012

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) >= 120) && anim != 3040 && time < 6
value = 3040

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) = [1, 119]) && anim != 3041 && time < 6
value = 3041

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) >= 420) && anim != 3005 && time >= 6
value = 3005

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [180, 419]) && anim != 3006 && time >= 6
value = 3006

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [1, 179]) && anim != 3007 && time >= 6
value = 3007

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) >= 120) && anim != 3035 && time >= 6
value = 3035

[State 3010, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) = [1, 119]) && anim != 3036 && time >= 6
value = 3036

[State 3010, Vel]
type = velset
trigger1 = time < 6
x = 0
y = 0

[State 3010, Pos]
type = posset
trigger1 = time < 6
y = 0

[State 3010, Vel]
type = velset
trigger1 = time = 6
x = 0.5 * fvar(1)
y = -.5 * fvar(2)

[State 3010, Accel]
type = gravity
trigger1 = time >= 6

[State 3010, Turn]
type = velmul
trigger1 = vel x > 0 && frontedgedist <= 18
trigger2 = vel x < 0 && backedgedist <= 18
x = -1

[State 3010, poing]
type = playsnd
trigger1 = !time
value = 5, 7

[State 3010, Dust]
type = explod
trigger1 = !time
anim = 8102
ID = 8102
sprpriority = -2
postype = p1
removetime = -2
ownpal = 1
scale = 0.5, 0.5

[State 3010, land]
type = changestate
trigger1 = vel y >= 0 && pos y >= -5 && time > 6
value = 3005

[State 3010, detonate]
type = changestate
triggerall = roundstate < 4
trigger1 = var(0) <= 0
trigger2 = root, stateno = 3002 && root, animelemtime(3) >= 10
value = 3020

;--- HIT by Enemy ---
[Statedef 3015]
type = A
physics = N
movetype = H
anim = ifelse(var(1) = 1, 3015, 3045)
ctrl = 0
sprpriority = 2

[State 3015, timervar]
type = varadd
trigger1 = 1
var(0) = -1
ignorehitpause = 1

[State 3015, Turn]
type = turn
trigger1 = !time && p2dist x >= 0

[State 3015, hitvel]
type = velset
trigger1 = !time
x = 5
y = -5

[State 3015, hit by Lei-Lei]
type = changestate
triggerall = root, movetype = A && time
triggerall = (root, stateno = [200, 650]) || root, stateno = 1101
trigger1 = ((pos x - root, pos x) * (root, facing) = [0, 100])
trigger1 = ((pos y - root, pos y) = [ -50, 50])
value = 3016

[State 3015, hit by partner]
type = changestate
trigger1 = numpartner && time
trigger1 = partner, movetype = A && partner, hitdefattr = SCA, AA
trigger1 = ((pos x - partner, pos x) * (partner, facing) = [0, 80])
trigger1 = ((pos y - partner, pos y) = [ -50, 50])
value = 3017

[State 3015, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) >= 420) && anim != 3005 && vel y >= 0
value = 3005

[State 3015, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [180, 419]) && anim != 3006 && vel y >= 0
value = 3006

[State 3015, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [1, 179]) && anim != 3007 && vel y >= 0
value = 3007

[State 3015, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) >= 120) && anim != 3035 && vel y >= 0
value = 3035

[State 3015, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) = [1, 119]) && anim != 3036 && vel y >= 0
value = 3036

[State 3015, Accel]
type = gravity
trigger1 = 1

[State 3015, Turn]
type = velmul
trigger1 = vel x > 0 && frontedgedist <= 18
trigger2 = vel x < 0 && backedgedist <= 18
x = -1

[State 3015, bounce]
type = changestate
trigger1 = vel y >= 0 && pos y >= -5
value = 3010

[State 3015, detonate]
type = changestate
triggerall = roundstate < 4
trigger1 = var(0) <= 0
trigger2 = root, stateno = 3002 && root, animelemtime(3) >= 10
value = 3020

;--- HIT by Lei-Lei ---
[Statedef 3016]
type = A
physics = N
movetype = H
anim = ifelse(var(1) = 1, 3015, 3045)
ctrl = 0
sprpriority = 2

[State 3016, timervar]
type = varadd
trigger1 = time
var(0) = -1
ignorehitpause = 1

[State 3016, Turn]
type = turn
trigger1 = !time && rootdist x >= 0

[State 3016, hitvel]
type = velset
trigger1 = !time
x = 5
y = -5

[State 3016, hit by partner]
type = changestate
trigger1 = numpartner && time
trigger1 = partner, movetype = A && partner, hitdefattr = SCA, AA
trigger1 = ((pos x - partner, pos x) * (partner, facing) = [0, 80])
trigger1 = ((pos y - partner, pos y) = [ -50, 50])
value = 3017

[State 3016, HitSpark]
type = Helper
trigger1 = !time
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
postype = p2
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), -22
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3016, Snd]
type = playsnd
trigger1 = !time
value = 2, ifelse((root, stateno = [3000, 4999]), 3, ifelse((root, stateno = [1000, 1999]), 2, 1))

[State 3016, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) >= 420) && anim != 3005 && vel y >= 0
value = 3005

[State 3016, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [180, 419]) && anim != 3006 && vel y >= 0
value = 3006

[State 3016, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [1, 179]) && anim != 3007 && vel y >= 0
value = 3007

[State 3016, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) >= 120) && anim != 3035 && vel y >= 0
value = 3035

[State 3016, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) = [1, 119]) && anim != 3036 && vel y >= 0
value = 3036

[State 3016, Accel]
type = gravity
trigger1 = 1

[State 3016, Turn]
type = velmul
trigger1 = vel x > 0 && frontedgedist <= 18
trigger2 = vel x < 0 && backedgedist <= 18
x = -1

[State 3016, bounce]
type = changestate
trigger1 = vel y >= 0 && pos y >= -5
value = 3010

[State 3016, detonate]
type = changestate
triggerall = roundstate < 4
trigger1 = var(0) <= 0
trigger2 = root, stateno = 3002 && root, animelemtime(3) >= 10
value = 3020

;--- HIT by Partner ---
[Statedef 3017]
type = A
physics = N
movetype = H
anim = ifelse(var(1) = 1, 3015, 3045)
ctrl = 0
sprpriority = 2

[State 3017, timervar]
type = varadd
trigger1 = time
var(0) = -1
ignorehitpause = 1

[State 3017, Turn]
type = turn
trigger1 = !time && ((partner, pos x) -pos x) >= 0

[State 3017, hitvel]
type = velset
trigger1 = !time
x = 5
y = -5

[State 3017, hit by Lei-Lei]
type = changestate
triggerall = root, movetype = A && time
triggerall = (root, stateno = [200, 650]) || root, stateno = 1101
trigger1 = ((pos x - root, pos x) * (root, facing) = [0, 100])
trigger1 = ((pos y - root, pos y) = [ -50, 50])
value = 3016

[State 3017, Sparks]
type = explod
trigger1 = !time
anim = f0 + ifelse((partner, hitdefattr = SCA, HA), 3, ifelse((partner, hitdefattr = SCA, SA), 2, 1))
sprpriority = 5
postype = p1
pos = 10, -22
removetime = -2
ownpal = 1
ignorehitpause = 1
persistent = 0
pausemovetime = 100
supermovetime = 100

[State 3017, Snd]
type = playsnd
trigger1 = !time
value = f5, ifelse((partner, hitdefattr = SCA, HA), 2, ifelse((partner, hitdefattr = SCA, SA), 1, 0))

[State 3017, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) >= 420) && anim != 3005 && vel y >= 0
value = 3005

[State 3017, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [180, 419]) && anim != 3006 && vel y >= 0
value = 3006

[State 3017, Anim]
type = changeanim
trigger1 = var(1) = 1 && (var(0) = [1, 179]) && anim != 3007 && vel y >= 0
value = 3007

[State 3017, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) >= 120) && anim != 3035 && vel y >= 0
value = 3035

[State 3017, Anim]
type = changeanim
trigger1 = var(1) = 2 && (var(0) = [1, 119]) && anim != 3036 && vel y >= 0
value = 3036

[State 3017, Accel]
type = gravity
trigger1 = 1

[State 3017, Turn]
type = velmul
trigger1 = vel x > 0 && frontedgedist <= 18
trigger2 = vel x < 0 && backedgedist <= 18
x = -1

[State 3017, bounce]
type = changestate
trigger1 = vel y >= 0 && pos y >= -5
value = 3010

[State 3017, detonate]
type = changestate
triggerall = roundstate < 4
trigger1 = var(0) <= 0
trigger2 = root, stateno = 3002 && root, animelemtime(3) >= 10
value = 3020

;--- EXPLODE ---
[Statedef 3020]
type = U
physics = N
movetype = A
anim = ifelse(var(1) = 1, 3020, 3050)
ctrl = 0
velset = 0, 0
sprpriority = 2

[State 3020, Snd]
type = playsnd
trigger1 = animelem = 5
value = 5, 8
channel = 2

[State 3020, explosion]
type = helper
trigger1 = animelem = 5
helpertype = normal
stateno = 3025
ID = 3025
name = "Explosion"
postype = p1
pos = 0, 0
ownpal = 1

[State 3020, End]
type = destroyself
trigger1 = !animtime

;--- ROUND OVER ---
[Statedef 3030]
type = S
physics = N
movetype = I
anim = ifelse(var(1) = 1, 3030, 3060)
ctrl = 0
velset = 0, 0
sprpriority = 2

[State 3020, Snd]
type = stopsnd
trigger1 = !time
value = 5, 8
channel = 2

[State 3030, Pos]
type = posset
trigger1 = 1
y = 0

;--- TIMER ---
[Statedef 3090]
type = A
physics = N
movetype = I
anim = 3090
ctrl = 0
sprpriority = 5

[State 3090, End]
type = destroyself
trigger1 = parent, var(0) <= 0
trigger2 = root, stateno = 3002 && root, animelemtime(3) >= 10

[State 3090, Assert]
type = assertspecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 3090, Anim]
type = changeanim
trigger1 = anim != (3090 + floor(parent, var(0) / 60))
value = 3090 + floor(parent, var(0) / 60)

[State 3090, Bind]
type = bindtoparent
trigger1 = 1
pos = ifelse((parent, facing = 1), 14, -14), -7

;========================<BOMB EXPLOSION>=============================
[Statedef 3025]
type = A
physics = N
movetype = A
ctrl = 0
velset = 0, 0
sprpriority = 4

[State 3025, HitOverride]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AA, AP, AT
stateno = 3025
ignorehitpause = 1

[State 3025, HB]
type = nothitby
trigger1 = 1
time = -1
value = SCA
ignorehitpause = 1

[State 3025, Strength]
type = varset
trigger1 = !time
var(10) = parent, var(10)

[State 3025, Anim]
type = changeanim
trigger1 = !time && !prevstateno
value = 3025

[State 3025, Strength]
type = varset
trigger1 = !time
var(1) = 4

[State 3025, Shadows]
type = afterimage
trigger1 = !time && !prevstateno
time = 999
timegap = 1
framegap = 1
length = 2
palmul = 0.5, 0.5, 0.5
palcontrast = 90, 0, 0
trans = add

[State 3025, Shake]
type = envshake
trigger1 = !time && !prevstateno
time = 12
freq = 120
ampl = 12

[State 3025, Dust]
type = explod
trigger1 = animelem = 3
anim = 8102
ID = 8102
sprpriority = -2
postype = p1
pos = 0, -40
vel = 0, -4
removetime = -2
ownpal = 1
scale = 3, 1

[State 3025, Assert]
type = trans
trigger1 = 1
trans = addalpha
alpha = 256, 256
ignorehitpause = 1

[State 3025, HitSound]
type = playsnd
trigger1 = movehit && numtarget
trigger1 = target, time = 0 && target, movetype = H
value = 2, 6
persistent = 0
ignorehitpause = 1

[State 3025, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3025, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3025, Hit]
type = hitdef
trigger1 = !time && !prevstateno
priority = 4, Hit
attr = S, SA
damage = ceil(243 * root, fvar(11)), 30
animtype = Up
hitflag = MAFD
guardflag = M
affectteam = B
pausetime = 0, 6
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
guardsound = s3, 0
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = 0, -15
ground.cornerpush.veloff = 0
air.velocity = 0, -15
guard.velocity = -12.97
fall = 1
fall.recover = 0
getpower = 0
givepower = 36, 36
envshake.time = 18
envshake.freq = 120
envshake.ampl = 6
palfx.color = 32
palfx.sinadd = 80, 25, 0, 8
palfx.mul = 512, 256, 128
palfx.time = 70
sprpriority = 4
ID = 3025
yaccel = 0.5
forcestand = 1

[State 3025, target]
type = targetstate
trigger1 = movehit && numtarget(3025)
trigger1 = !(target(3025), ishelper)
trigger1 = (target(3025), stateno != 7697) && (target(3025), selfanimexist(7697))
value = 7697
ignorehitpause = 1

[State 3025, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), target, const(size.mid.pos.y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3025, flames]
type = helper
trigger1 = movehit && numtarget && numhelper(7180) < 1
trigger1 = (target, ID) != (root, ID)
trigger1 = (target, time = 0) && (target, movetype = H)
helpertype = normal
stateno = 7180
ID = 7180
name = "flames"
postype = p2
bindtime = 1000
ownpal = 1
facing = -1
size.ground.front = 0
size.ground.back = 0
ignorehitpause = 1
persistent = 0

[State 3025, flames]
type = helper
trigger1 = movehit && numtarget && numhelper(7181) < 1
trigger1 = (target, ID) = (root, ID)
trigger1 = (root, time = 0) && (root, movetype = H)
helpertype = normal
stateno = 7181
ID = 7181
name = "flames"
postype = p2
bindtime = 1000
ownpal = 1
facing = -1
size.ground.front = 0
size.ground.back = 0
ignorehitpause = 1
persistent = 0

[State 3025, flames]
type = helper
trigger1 = movehit && numtarget && numhelper(7182) < 1 && numpartner
trigger1 = (target, ID) = (partner, ID)
trigger1 = (partner, time = 0) && (partner, movetype = H)
helpertype = normal
stateno = 7182
ID = 7182
name = "flames"
postype = p2
bindtime = 1000
ownpal = 1
facing = -1
size.ground.front = 0
size.ground.back = 0
ignorehitpause = 1
persistent = 0

[State 3025, End]
type = destroyself
trigger1 = !animtime

;========================<CHIREITOU PROJECTILE>=============================
[Statedef 3105]
type = S
physics = N
movetype = I
ctrl = 0
anim = 1

[State 3105, Strength]
type = varset
trigger1 = !time
var(10) = root, var(10)

[State 3105, Vel]
type = velset
trigger1 = 1
x = 7.2

[State 3105, Pos]
type = posset
trigger1 = 1
y = 0

[State 3105, Var]
type = varset
trigger1 = !time
var(0) = 4

[State 3105, Mashing]
type = varadd
trigger1 = (root, command = "a") || (root, command = "b") || (root, command = "c")
var(2) = 1

[State 3105, Var]
type = varadd
trigger1 = var(0) > 0
trigger1 = var(2) >= 3 && var(1) < 4
var(0) = 1

[State 3105, Var]
type = varadd
trigger1 = var(2) >= 3 && var(1) < 4
var(1) = 1

[State 3105, Var]
type = varset
trigger1 = var(2) >= 3
var(2) = 0

[State 3105, Snd]
type = playsnd
trigger1 = !(time % 10) && var(0) > 0
value = 5, 5
channel = 2

[State 3105, Blade]
type = helper
trigger1 = !(time % 10) && var(0) > 0
helpertype = normal
stateno = 3106
ID = 3106
name = "Blade"
postype = p1
ownpal = 1
size.shadowoffset = -3

[State 3105, Var]
type = varadd
trigger1 = !(time % 10) && var(0) > 0
var(0) = -1

[State 3105, End]
type = destroyself
trigger1 = var(0) <= 0
trigger1 = !numhelper(3106)

;========================<CHIREITOU BLADE>=============================
[Statedef 3106]
type = S
physics = S
movetype = A
ctrl = 0
anim = 3105
velset = 0, 0
sprpriority = -1

[State 3106, spr]
type = sprpriority
trigger1 = 1
value = -1
ignorehitpause = 1

[State 3106, No Reversals]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AT
stateno = 5000
ignorehitpause = 1

[State 3106, Kanji]
type = explod
trigger1 = !time
anim = 3106
ID = 3106
postype = p1
facing = ifelse(facing = 1, 1, -1)
pos = ifelse(facing = 1, 0, 5)
removetime = -2
bindtime = -1

[State 3106, Strength]
type = varset
trigger1 = !time
var(10) = parent, var(10)

[State 3106, Pos]
type = posset
trigger1 = 1
y = 0

[State sts]
type = statetypeset
trigger1 = animelemtime(11) >= 0
movetype = I

[State 3106, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3106, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3106, Hit]
type = hitdef
trigger1 = !movecontact && !movereversed
attr = S, HA
damage = ceil(60 * root, fvar(11)), 7
animtype = Back
guardflag = MA
hitflag = MAF
priority = 4, Hit
pausetime = 0, 4
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, ceil(p2dist y - 60)
hitsound = s2, 9
guardsound = s3, 0
ground.type = Low
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -9, -2.5
ground.cornerpush.veloff = 0
air.velocity = -9, -2.5
down.velocity = 0, 0
getpower = 0
givepower = 36, 36
sprpriority = -1
envshake.time = 18
envshake.freq = 120
envshake.ampl = 6
guard.velocity = -12.97
fall = 1
fall.recover = 0
forcestand = 1
airguard.ctrltime = 16
airguard.velocity = -8, -1.5

[State 3106, Hit]
type = hitdef
trigger1 = playerIDexist(parent, ID)
trigger1 = parent, var(0) <= 0
trigger1 = !movecontact && !movereversed
attr = S, HA
damage = ceil(60 * root, fvar(11)), 7
animtype = Up
guardflag = MA
hitflag = MAF
priority = 4, Hit
pausetime = 0, 4
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, ceil(p2dist y - 60)
hitsound = s2, 9
guardsound = s3, 0
ground.type = Low
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -4, -8
ground.cornerpush.veloff = 0
air.velocity = -4, -8
down.velocity = 0, 0
getpower = 0
givepower = 36, 36
sprpriority = -1
envshake.time = 18
envshake.freq = 120
envshake.ampl = 6
guard.velocity = -12.97
fall = 1
fall.recover = 0
forcestand = 1
airguard.ctrltime = 16
airguard.velocity = -8, -1.5

[State 3106, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8017)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), target, const(size.mid.pos.y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3106, End]
type = destroyself
trigger1 = !animtime

;========================<MAX CHIREITOU PROJECTILE>=============================
[Statedef 3155]
type = S
physics = N
movetype = I
ctrl = 0
anim = 1

[State 3155, Strength]
type = varset
trigger1 = !time
var(10) = root, var(10)

[State 3155, Vel]
type = velset
trigger1 = 1
x = 7.2

[State 3155, Pos]
type = posset
trigger1 = 1
y = 0

[State 3155, Var]
type = varset
trigger1 = !time
var(0) = 6

[State 3155, Mashing]
type = varadd
trigger1 = (root, command = "a") || (root, command = "b") || (root, command = "c")
var(2) = 1

[State 3155, Var]
type = varadd
trigger1 = var(0) > 0
trigger1 = var(2) >= 3 && var(1) < 6
var(0) = 1

[State 3155, Var]
type = varadd
trigger1 = var(2) >= 3 && var(1) < 6
var(1) = 1

[State 3155, Var]
type = varset
trigger1 = var(2) >= 3
var(2) = 0

[State 3155, Snd]
type = playsnd
trigger1 = !(time % 8) && var(0) > 0
value = 5, 5
channel = 2

[State 3155, Blade]
type = helper
trigger1 = !(time % 8) && var(0) > 0
helpertype = normal
stateno = 3156
ID = 3156
name = "Blade"
postype = p1
ownpal = 1
size.shadowoffset = -3

[State 3155, Var]
type = varadd
trigger1 = !(time % 8) && var(0) > 0
var(0) = -1

[State 3155, End]
type = destroyself
trigger1 = var(0) <= 0
trigger1 = !numhelper(3156)

;========================<CHIREITOU BLADE>=============================
[Statedef 3156]
type = S
physics = S
movetype = A
ctrl = 0
anim = 3105
velset = 0, 0
sprpriority = -1

[State 3156, spr]
type = sprpriority
trigger1 = 1
value = -1
ignorehitpause = 1

[State 3156, No Reversals]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AT
stateno = 5000
ignorehitpause = 1

[State 3156, Kanji]
type = explod
trigger1 = !time
anim = 3106
ID = 3156
postype = p1
facing = ifelse(facing = 1, 1, -1)
pos = ifelse(facing = 1, 0, 5)
removetime = -2
bindtime = -1

[State 3156, Strength]
type = varset
trigger1 = !time
var(10) = parent, var(10)

[State 3156, Pos]
type = posset
trigger1 = 1
y = 0

[State sts]
type = statetypeset
trigger1 = animelemtime(11) >= 0
movetype = I

[State 3156, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3156, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3156, Hit]
type = hitdef
trigger1 = !movecontact && !movereversed
attr = S, HA
damage = ceil(57 * root, fvar(11)), 7
animtype = Back
guardflag = MA
hitflag = MAF
priority = 4, Hit
pausetime = 0, 4
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, ceil(p2dist y - 60)
hitsound = s2, 9
guardsound = s3, 0
ground.type = Low
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -9, -2.5
ground.cornerpush.veloff = 0
air.velocity = -9, -2.5
down.velocity = 0, 0
getpower = 0
givepower = 36, 36
sprpriority = -1
envshake.time = 18
envshake.freq = 120
envshake.ampl = 6
guard.velocity = -12.97
fall = 1
fall.recover = 0
forcestand = 1
airguard.ctrltime = 16
airguard.velocity = -8, -1.5

[State 3156, Hit]
type = hitdef
trigger1 = playerIDexist(parent, ID)
trigger1 = parent, var(0) <= 0
trigger1 = !movecontact && !movereversed
attr = S, HA
damage = ceil(57 * root, fvar(11)), 7
animtype = Up
guardflag = MA
hitflag = MAF
priority = 4, Hit
pausetime = 0, 4
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, ceil(p2dist y - 60)
hitsound = s2, 9
guardsound = s3, 0
ground.type = Low
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -4, -8
ground.cornerpush.veloff = 0
air.velocity = -4, -8
down.velocity = 0, 0
getpower = 0
givepower = 36, 36
sprpriority = -1
envshake.time = 18
envshake.freq = 120
envshake.ampl = 6
guard.velocity = -12.97
fall = 1
fall.recover = 0
forcestand = 1
airguard.ctrltime = 16
airguard.velocity = -8, -1.5

[State 3156, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8017)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), target, const(size.mid.pos.y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3156, End]
type = destroyself
trigger1 = !animtime

;========================<TENRAI HA PROJECTILE>=============================
[Statedef 3205]
type = C
physics = N
movetype = A
ctrl = 0
anim = 3205
velset = 0, 0

[State 3205, No Reversals]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AT
stateno = 5000
ignorehitpause = 1

[State 3205, Strength]
type = varset
trigger1 = !time
var(10) = root, var(10)

[State 3205, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3205, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3205, Hit]
type = hitdef
trigger1 = !time
priority = 4, Hit
attr = C, HA
damage = ceil(28 * root, fvar(11)), 7
animtype = Hard
hitflag = MFD
guardflag = L
pausetime = 0, 0
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, 0
hitsound = -1
guardsound = s3, 0
ground.type = Trip
ground.slidetime = 16
ground.hittime = 16
ground.velocity = 0, -8
ground.cornerpush.veloff = 0
air.type = Trip
air.velocity = 0, -8
getpower = 0
givepower = 36, 36
guard.velocity = -12.97
fall = 1
fall.recover = 0
yaccel = 0.5
forcestand = 1

[State 3205, ball]
type = helper
trigger1 = !(time % 9) && !(root, movecontact)
helpertype = normal
stateno = 3210
ID = 3210
name = "Spiked Ball"
postype = p1
pos = ceil((random / 4.0) -125), 0
facing = 2 * (random < 500) -1
ownpal = 1

[State 3205, ball]
type = helper
trigger1 = !(time % 9) && (root, movecontact)
helpertype = normal
stateno = 3210
ID = 3210
name = "Spiked Ball"
postype = p1
pos = ceil((random / 10.0) -50), 0
facing = 2 * (random < 500) -1
ownpal = 1

[State 3205, End]
type = destroyself
trigger1 = root, movetype = H
trigger2 = time >= 90

;========================<TENRAIHA SPIKED BALL>=============================
[Statedef 3210]
type = A
physics = N
movetype = A
anim = 3210
ctrl = 0
velset = 0, 0
sprpriority = 2

[State 3210, HitOverride]
type = hitoverride
trigger1 = 1
time = -1
attr = SCA, AA, AP, AT
stateno = 3210
ignorehitpause = 1

[State 3210, HB]
type = hitby
trigger1 = 1
time = -1
value = SCA, NP, SP, HP
ignorehitpause = 1

[State 3210, Strength]
type = varset
trigger1 = !time
var(10) = root, var(10)

[State 3210, Push]
type = playerpush
trigger1 = 1
value = 0

[State 3210, Pos]
type = posset
trigger1 = !time
y = -ceil(screenpos y) -20

[State 3210, Accel]
type = gravity
trigger1 = 1

[State 3210, poing]
type = playsnd
trigger1 = vel y > 0 && pos y >= 0 && anim = 3210
value = 5, 10
volume = -150

[State 3210, Dust]
type = explod
trigger1 = vel y > 0 && pos y >= 0 && anim = 3210
anim = 8102
ID = 8102
sprpriority = -2
postype = p1
removetime = -2
ownpal = 1
scale = 0.5, 0.5

[State 3210, Vel]
type = velset
trigger1 = vel y > 0 && pos y >= 0 && !var(0)
trigger1 = var(0) := 1
x = 1 + (random / 333)
y = -.5 * vel y

[State 3210, Vel]
type = velmul
trigger1 = vel y > 0 && pos y >= 0 && var(0)
x = 0.75
y = -.75

[State 3210, Vel]
type = velmul
trigger1 = movecontact
x = ifelse(p2dist x >= 0, -1, 1)
y = ifelse((vel y > 0 && p2dist y > 0), -.5, 0.75)
persistent = 0

[State 3210, HitSound]
type = playsnd
trigger1 = movehit && numtarget
trigger1 = target, time = 0 && target, movetype = H
value = 2, 2
persistent = 0
ignorehitpause = 1

[State sts]
type = statetypeset
trigger1 = root, movetype = H
trigger2 = movecontact || movereversed
movetype = I

[State 3210, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3210, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3210, Hit]
type = hitdef
trigger1 = !movecontact && !var(0)
priority = 4, Hit
attr = S, HP
damage = ceil(26 * root, fvar(11)), 7
animtype = Back
hitflag = MAFD
guardflag = HA
pausetime = 0, 6
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, -16
guardsound = s3, 0
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = 0, -5
ground.cornerpush.veloff = 0
air.velocity = 0, -5
down.velocity = 0, 0
getpower = 0
givepower = 36, 36
envshake.time = 18
envshake.freq = 120
envshake.ampl = 6
sprpriority = 2
guard.velocity = -12.97
fall = 1
fall.recover = 0
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 3210, Hit]
type = hitdef
trigger1 = !movecontact && var(0)
priority = 4, Hit
attr = S, HP
damage = ceil(26 * root, fvar(11)), 7
animtype = Back
hitflag = MAFD
guardflag = M
pausetime = 0, 6
sparkno = -1
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkxy = -10, -16
guardsound = s3, 0
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = 0, -5
ground.cornerpush.veloff = 0
air.velocity = 0, -5
down.velocity = 0, 0
getpower = 0
givepower = 36, 36
envshake.time = 18
envshake.freq = 120
envshake.ampl = 6
sprpriority = 2
guard.velocity = -12.97
fall = 1
fall.recover = 0
yaccel = 0.5
forcestand = 1

[State 3210, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1= (target,movetype=H) && !(target,time)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
postype = p2
pos = (target, const(size.ground.front) -10), -floor(p2dist y)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3210, Anim]
type = changeanim
trigger1 = anim = 3210 && time >= 90
value = 3211

[State 3210, fadeout]
type = trans
trigger1 = anim = 3211
trans = addalpha
alpha = ceil(256 -7.1 * (animelemtime(1))), ceil(7.1 * animelemtime(1))

[State 3210, Assert]
type = assertspecial
trigger1 = anim = 3211
flag = noshadow

[State 3210, End]
type = destroyself
trigger1 = anim = 3211 && !animtime

;========================<RED DUST>=============================
[Statedef 3206]
physics = N
anim = 1

[State 3206, Assert]
type = assertspecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 3206, Dust]
type = explod
trigger1 = !time
anim = 7501;3406
ID = 3206
sprpriority = -2
postype = p1
removetime = 16
pausemovetime = ifelse((parent, stateno = 6100), 300, 0)
supermovetime = ifelse((parent, stateno = 6100), 300, 0)

[State 3206, Fade]
type = palfx
trigger1 = !time
mul = 384, 384, 384
sinadd = -255, -255, -255, 64
time = 16

[State 3206, Shrink]
type = modifyexplod
trigger1 = 1
ID = 3206
scale = 0.2 + (0.05 * time) * const(size.xscale), 0.05 + (0.0125 * time) * const(size.yscale)

[State 3206, End]
type = destroyself
trigger1 = time >= 17

;========================< DIZZY >=============================
[Statedef 5300]
type = S
movetype = I
physics = S
velset = 0, 0
anim = 5300

[State 5300, Timer]
type = varset
trigger1 = !time
sysfvar(4) = 180

[State 5300, Timer]
type = varadd
trigger1 = time
sysfvar(4) = -1

[State 5300, Timer]
type = varadd
trigger1 = sysfvar(4) > 0
trigger1 = command = "up" || command = "down" || command = "back" || command = "fwd"
sysfvar(4) = -2

[State 5300, Timer]
type = varadd
trigger1 = sysfvar(4) > 0
trigger1 = command = "x" || command = "y" || command = "z" || command = "a" || command = "b" || command = "c"
sysfvar(4) = -1

[State 5300, Skip]
type = varset
trigger1 = !time
sysfvar(3) = 0

[State 5300, Skip]
type = varadd
trigger1 = command = "up" || command = "down" || command = "back" || command = "fwd"
trigger2 = command = "a" || command = "b" || command = "c" || command = "x" || command = "y" || command = "z"
sysfvar(3) = 1

[State 5300, Skip]
type = changeanim
trigger1 = animelemtime(animelemno(0)) > 0 && animelemtime(animelemno(0) + 1) < 0
trigger1 = animelemtime(animelemno(0) + 1) >= -sysfvar(3)
value = 5300
elem = animelemno(0) + 1

[State 5300, Skip]
type = varset
trigger1 = animelemtime(1) >= 0 && !animelemtime(animelemno(0))
sysfvar(3) = 0

[State 5300, End]
type = varset
trigger1 = sysfvar(4) < 0
sysfvar(4) = 0

[State 5300, End]
type = selfstate
trigger1 = sysfvar(4) <= 0 || time >= 300 || roundstate != 2
value = 0
ctrl = 1

;========================< HIT BACK, then dizzy >=============================
[Statedef 1115020]
type = A
movetype = H
physics = N
velset = 0, 0

[State 1115020, Anim]
type = changeanim
trigger1 = !time && (gethitvar(animtype) != [3, 5])
value = ifelse((gethitvar(airtype) = 1), 5000, 5010) + gethitvar(animtype)

[State 1115020, Anim]
type = changeanim
trigger1 = !time && (gethitvar(animtype) = [3, 5])
value = 5030

[State 1115020, Anim]
type = changeanim
trigger1 = !time && (gethitvar(animtype) = [4, 5]) && (selfanimexist(5047 + gethitvar(animtype)))
value = 5047 + gethitvar(animtype)

[State 1115020, Anim]
type = changeanim
trigger1 = 1
value = anim

[State 1115020, End]
type = changestate
trigger1 = hitshakeover
value = 1115030

[Statedef 1115030]
type = A
movetype = H
physics = N
ctrl = 0

[State 1115030, Accel]
type = veladd
trigger1 = 1
y = gethitvar(yaccel)

[State 1115030, Vel]
type = hitvelset
trigger1 = !time
x = 1
y = 1

[State 1115030, End]
type = changestate
trigger1 = hitover
trigger2 = vel y > 0 && pos y >= 10
value = 1115050

[State 1115030, End]
type = changestate
trigger1 = !animtime
value = 1115035

[Statedef 1115035]
type = A
movetype = H
physics = N

[State 1115035, Anim]
type = changeanim
trigger1 = !time && selfanimexist(5035)
trigger1 = anim != 5090 && (anim != [5051, 5059])
value = 5035

[State 1115035, Accel]
type = veladd
trigger1 = 1
y = gethitvar(yaccel)

[State 1115035, End]
type = changestate
trigger1 = hitover
trigger2 = !animtime
trigger3 = vel y > 0 && pos y >= 10
trigger4 = !time && anim != 5035
value = 1115050

[Statedef 1115050]
type = A
movetype = H
physics = N

[State 1115050, Anim]
type = changeanim
trigger1 = anim = 5035 && !animtime
trigger2 = anim != 5035 && !time
value = 5050

[State 1115050, Anim]
type = changeanim
trigger1 = anim = 5035 && !animtime
trigger2 = anim != 5035 && !time
trigger2 = (anim != [5051, 5059]) && (anim != [5061, 5069])
trigger2 = anim != 5090
value = 5050

[State 1115050, Anim]
type = changeanim
trigger1 = anim = [5050, 5059]
trigger1 = vel y >= ifelse(anim = 5050, 1, -2)
trigger1 = selfanimexist(anim + 10)
value = anim + 10
persistent = 0

[State 1115050, Accel]
type = veladd
trigger1 = 1
y = gethitvar(yaccel)

[State 1115050, End]
type = changestate
trigger1 = vel y > 0
trigger1 = pos y >= ifelse((anim = [5051, 5059]) || (anim = [5061, 5069]), 0, 25)
value = 1115100

[Statedef 1115100]
type = L
movetype = H
physics = N
[State 1115100, 1]
type = velset
trigger1 = !time && gethitvar(fall.yvel) = 0 && vel x > 1
x = 1

[State 1115100, Shake]
type = fallenvshake
trigger1 = !time

[State 1115100, Var]
type = varset
trigger1 = !time
sysvar(1) = floor(vel y)

[State 1115100, Anim]
type = ChangeAnim
trigger1 = !time
value = 5100

[State 1115100, Pos]
type = posset
trigger1 = !time
y = 0

[State 1115100, Vel]
type = velset
trigger1 = !time
y = 0

[State 1115100, Vel]
type = velmul
trigger1 = !time
x = 0.75

[State 1115100, End]
type = changestate
trigger1 = !time
trigger1 = gethitvar(fall.yvel) = 0
value = 1115110

[State 1115100, FX]
type = gamemakeanim
trigger1 = time = 1
value = 60 + (sysvar(1) > 5) + (sysvar(1) > 14)
pos = 0, 0
under = sysvar(1) <= 14

[State 1115100, hurt]
type = hitfalldamage
trigger1 = time = 3

[State 1115100, snd]
type = playsnd
trigger1 = Time = 1
value = F7, (sysvar(1) > 5) + (sysvar(1) > 14)

[State 1115100, freeze]
type = posfreeze
trigger1 = 1

[State 1115100, End]
type = changestate
trigger1 = !animtime
value = 1115101

[State 1115100, FFB]
type = forcefeedback
trigger1 = !time
waveform = sinesquare
ampl = 128, -3, -.2, 0.005
time = 20

[Statedef 1115101]
type = L
movetype = H
physics = N

[State 1115101, Anim]
type = changeanim
trigger1 = !time
value = 5160

[State 1115101, Vel]
type = hitfallvel
trigger1 = !time

[State 1115101, Pos]
type = posset
trigger1 = !time
y = 20

[State 1115101, accel]
type = veladd
trigger1 = 1
y = 0.4

[State 1115101, End]
type = changestate
trigger1 = vel y > 0 && pos y >= 12
value = 1115110

[Statedef 1115110]
type = L
movetype = H
physics = N

[State 1115110, Shake]
type = fallenvshake
trigger1 = !time

[State 1115110, 2]
type = changeanim
trigger1 = !time
value = 5170

[State 1115110, hurt]
type = hitfalldamage
trigger1 = !time

[State 1115110, Pos]
type = posset
trigger1 = !time
y = 0
[State 1115110, Var]
type = varset
trigger1 = !time
trigger1 = gethitvar(fall.yvel) != 0
sysvar(1) = floor(vel y)

[State 1115110, snd]
type = playsnd
trigger1 = !time && !sysvar(0)
value = F7, (sysvar(1) > 5) + (sysvar(1) > 14)

[State 1115110, FX]
type = gamemakeanim
trigger1 = !time && !sysvar(0)
value = 60 + (sysvar(1) > 5) + (sysvar(1) > 14)
pos = 0, 0
under = sysvar(1) <= 14

[State 1115110, Vel]
type = velset
trigger1 = !time
y = 0

[State 1115110, Anim]
type = changeanim
persistent = 0
triggerall = anim != [5111, 5119]
trigger1 = !animtime
trigger2 = sysvar(0)
value = 5110

[State 1115110, ko]
type = selfstate
triggerall = !alive
trigger1 = !animtime
trigger2 = sysvar(0)
trigger3 = anim = [5110, 5119]
value = 5150

[State 1115110, Var]
type = varset
trigger1 = sysvar(0)
trigger1 = !time
sysvar(0) = 0

[State 1115110, Vel]
type = velmul
trigger1 = 1
x = 0.85

[State 1115110, FFB]
type = forcefeedback
trigger1 = alive && !time
time = 8
ampl = 240
waveform = sine

[State 1115110, FFB]
type = forcefeedback
trigger1 = !alive && !time
ampl = 200, 7, -.467
time = 30
waveform = sine

[State 1115110, getup]
type = changestate
trigger1 = alive && time >= 9;const(data.liedown.time)
value = 1115120
persistent = 0

[Statedef 1115120]
type = L
movetype = I
physics = N

[State 1115120, Anim]
type = changeanim
trigger1 = !time
value = 5120

[State 1115120, Vel]
type = velset
trigger1 = !time
x = 0

[State 1115120, NHB]
type = nothitby
trigger1 = 1
value = SCA
time = 1

[State 1115120, Vel]
type = hitfallset
trigger1 = !animtime
value = 1

[State 1115120, NHB]
type = nothitby
trigger1 = 1
value = SCA
time = 1

[State 1115120, dizzy]
type = changestate
trigger1 = !animtime
value = 5300

;========================<LIN-LIN>=============================
;--- < FLASH > ---
[Statedef 6005]
physics = N
anim = 1

[State 6005, FX]
type = explod
trigger1 = !time
anim = 7500
ID = 6005
sprpriority = 3
postype = p1
removetime = 15

[State 6005, Fade]
type = palfx
trigger1 = !time
time = 15
sinadd = -280, -280, -280, 60

[State 6005, Shrink]
type = modifyexplod
trigger1 = 1
ID = 6005
scale = 1.5 -.1 * time, 1.5 -.1 * time

[State 6005, Safety]
type = removeexplod
trigger1 = time >= 15

[State 6005, End]
type = destroyself
trigger1 = time >= 15

;--- <INTRO 2> ---
[Statedef 6015]
type = A
physics = N
anim = 6015
sprpriority = -1

[State 6015, Snd]
type = playsnd
trigger1 = anim = 6015 && animelem = 2
value = 6, 0

[State 6015, Vel]
type = velset
trigger1 = anim = 6001
x = 1.7
y = -12
persistent = 0

[State 6015, Pos]
type = posadd
trigger1 = anim = 6015 && !animtime
y = -65

[State 6015, Accel]
type = veladd
trigger1 = anim = 6001
y = 0.75

[State 6015, Anim]
type = changeanim
trigger1 = anim = 6015 && !animtime
value = 6001

[State 6015, Snd]
type = playsnd
trigger1 = anim = 6015 && animelem = 6
value = 5, 9

[State 6015, Flash]
type = helper
trigger1 = anim = 6015 && animelem = 6
helpertype = normal
stateno = 6005
ID = 6005
name = "Lin -Lin Flash"
postype = p1
pos = 0, -65
ownpal = 1
persistent = 0

[State 6015, Shadows]
type = afterimage
trigger1 = anim = 6001
time = 999
timegap = 1
framegap = 1
length = 12
palbright = 0, 0, 0
paladd = 0, 0, 0
palmul = 0.9, 0.9, 0.9
palcontrast = 120, 120, 120
palpostbright = 0, 0, 0
trans = add
persistent = 0

[State 6015, spr]
type = sprpriority
trigger1 = anim = 6001
value = 1
ignorehitpause = 1

[State 6015, Type]
type = statetypeset
trigger1 = anim = 6015
type = S
physics = S

[State 6015, Type]
type = statetypeset
trigger1 = anim = 6001
type = A
physics = N

[State 6015, End]
type = destroyself
trigger1 = anim = 6001 && time >= 109

;--- <WIN 3> ---
[Statedef 6010]
type = A
physics = N
anim = 6000
sprpriority = -1

[State 6010, Vel]
type = velset
trigger1 = !time && anim = 6000
x = 3
y = -12

[State 6010, Accel]
type = veladd
trigger1 = anim = 6000
y = 0.75

[State 6010, Anim]
type = changeanim
trigger1 = anim = 6000 && animelemtime(8) < 0 && vel y > 0 && pos y >= -70
value = 6000
elem = 8

[State 6010, Snd]
type = playsnd
trigger1 = anim = 6000 && animelemtime(8) = 5
value = 5, 9

[State 6010, Flash]
type = helper
trigger1 = anim = 6000 && animelemtime(8) = 5
helpertype = normal
stateno = 6005
ID = 6005
name = "Lin -Lin Flash"
postype = p1
ownpal = 1
persistent = 0

[State 6010, Anim]
type = changeanim
trigger1 = anim = 6000 && animelemtime(8) >= 10
value = 6010

[State 6010, Pos]
type = posset
trigger1 = anim = 6010
y = 0

[State 6010, Vel]
type = velset
trigger1 = anim = 6000 && animelemtime(8) >= 0
trigger2 = anim = 6010
x = 0
y = 0

[State 6010, Type]
type = statetypeset
trigger1 = anim = 6010
type = S
physics = S

[State 6010, Snd]
type = playsnd
trigger1 = anim = 6010 && animelem = 9
value = 6, 1

[State 6010, Shadows]
type = afterimage
trigger1 = !time && anim = 6000
time = 999
timegap = 1
framegap = 1
length = 12
palbright = 0, 0, 0
paladd = 0, 0, 0
palmul = 0.9, 0.9, 0.9
palcontrast = 120, 120, 120
palpostbright = 0, 0, 0
trans = add

[State 6010, Shadows]
type = afterimagetime
trigger1 = anim = 6010
time = 0

;========================<LIN-LIN HELPER>=============================
[Statedef 6020]
type = A
physics = N
anim = 6000
sprpriority = -1

[State 6020, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 232
moveTime = 232
p2DefMul = 1
unHittable = 1
anim = -1
darken = 0

[State 6020, Vel]
type = velset
trigger1 = !time && anim = 6000
x = 3
y = -12

[State 6020, Accel]
type = veladd
trigger1 = anim = 6000
y = 0.75

[State 6020, Anim]
type = changeanim
trigger1 = anim = 6000 && animelemtime(8) < 0 && vel y > 0 && pos y >= -70
value = 6000
elem = 8

[State 6020, Snd]
type = playsnd
trigger1 = anim = 6000 && animelemtime(8) = 5
value = 5, 9

[State 6020, Flash]
type = helper
trigger1 = anim = 6000 && animelemtime(8) = 5
helpertype = normal
stateno = 6005
ID = 6005
name = "Lin -Lin Flash"
postype = p1
ownpal = 1
persistent = 0

[State 6020, Anim]
type = changeanim
trigger1 = anim = 6000 && animelemtime(8) >= 10
value = 3305

[State 6020, Pos]
type = posset
trigger1 = anim = 3305
y = 0

[State 6020, Vel]
type = velset
trigger1 = anim = 6000 && animelemtime(8) >= 0
trigger2 = anim = 3305
x = 0
y = 0

[State 6020, Type]
type = statetypeset
trigger1 = anim = 3305
type = S
physics = S

[State 6020, Snd]
type = playsnd
trigger1 = anim = 3305 && animelem = 9
value = 6, 1

[State 6020, Shadows]
type = afterimage
trigger1 = !time && anim = 6000
time = 999
timegap = 1
framegap = 1
length = 12
palbright = 0, 0, 0
paladd = 0, 0, 0
palmul = 0.9, 0.9, 0.9
palcontrast = 120, 120, 120
palpostbright = 0, 0, 0
trans = add

[State 6020, Shadows]
type = afterimagetime
trigger1 = anim = 3305
time = 0

[State 6020, Flash]
type = helper
trigger1 = anim = 3305 && animelemtime(12) = 0
helpertype = normal
stateno = 6021
ID = 6005
name = "Lin -Lin Flash"
postype = p1
ownpal = 1
persistent = 0

[State 6015, End]
type = destroyself
trigger1 = !animtime

;Lin-Lin Out
[Statedef 6021]
type = A
physics = N
anim = 3306
sprpriority = -1

[State 6021, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 30
moveTime = 30
p2DefMul = 1
unHittable = 1
anim = -1
darken = 0

[State 6021, Snd]
type = playsnd
trigger1 = anim = 3306 && animelem = 2
value = 6, 0

[State 6021, Vel]
type = velset
trigger1 = anim = 6001
x = -3
y = -12
persistent = 0

[State 6021, Pos]
type = posadd
trigger1 = anim = 3306 && !animtime
y = -65

[State 6021, Accel]
type = veladd
trigger1 = anim = 6001
y = 0.75

[State 6021, Anim]
type = changeanim
trigger1 = anim = 3306 && !animtime
value = 6001

[State 6021, Snd]
type = playsnd
trigger1 = anim = 3306 && animelem = 6
value = 5, 9

[State 6021, Flash]
type = helper
trigger1 = anim = 3306 && animelem = 6
helpertype = normal
stateno = 6005
ID = 6005
name = "Lin -Lin Flash"
postype = p1
pos = 0, -65
ownpal = 1
persistent = 0

[State 6021, Shadows]
type = afterimage
trigger1 = anim = 6001
time = 999
timegap = 1
framegap = 1
length = 12
palbright = 0, 0, 0
paladd = 0, 0, 0
palmul = 0.9, 0.9, 0.9
palcontrast = 120, 120, 120
palpostbright = 0, 0, 0
trans = add
persistent = 0

[State 6021, spr]
type = sprpriority
trigger1 = anim = 6001
value = 1
ignorehitpause = 1

[State 6021, Type]
type = statetypeset
trigger1 = anim = 3306
type = S
physics = S

[State 6021, Type]
type = statetypeset
trigger1 = anim = 6001
type = A
physics = N

[State 6021, End]
type = destroyself
trigger1 = anim = 6001 && time >= 59

;====================<ARMOR STATE>====================
[StateDef 7000]
ctrl = 0
physics = N
velset = 0
sprpriority = -5

[State 7000, Bind]
type = BindToRoot
trigger1 = 1
facing = 1
pos = 0,0

[State 7000, Hit]
type = ChangeAnim
trigger1 = SelfAnimExist(Root,Anim)
value = Root,Anim
elem = Root,AnimElemNo(0)

[State 7000, STypsetS]
type = StateTypeSet
trigger1 = Root,StateType = S
StateType = S

[State 7000, STypsetC]
type = StateTypeSet
trigger1 = Root,StateType = C
StateType = C

[State 7000, STypsetA]
type = StateTypeSet
trigger1 = Root,StateType = A
StateType = A

[State 7000, STypsetL]
type = StateTypeSet
trigger1 = Root,StateType = L
StateType = L

[State 7000, MTypsetA]
type = StateTypeSet
trigger1 = Root,MoveType = A
MoveType = A

[State 7000, MTypsetI]
type = StateTypeSet
trigger1 = Root,MoveType = I
MoveType = I

[State 7000, MTypsetH]
type = StateTypeSet
trigger1 = Root,MoveType = H
MoveType = H

[State 7000, No-show]
type = AssertSpecial
trigger1 = 1
flag = invisible
flag2 = NoShadow
ignorehitpause = 1

[State 7000, NotHitBy]
type = NotHitBy
trigger1 = parent, var(14) = 2
value = SCA
ignorehitpause = 1

[State 7000, NHB]
type = NotHitBy
trigger1 = 1
value = ,AT,SA,SP,HA,HP
time = -1
ignorehitpause = 1

[State 7000, HO]
type = HitOverride
trigger1 = 1
attr = SCA, AA,AP,AT
time = -1
stateno = 7005
ignorehitpause = 1

[State 7000, destroyself]
type = destroyself
trigger1 = parent, stateno = [120,155]
trigger2 = stateno = [5000,5150]
trigger3 = root,var(45)=0
trigger4 = root,Movetype=H
ignorehitpause = 1

;Armor part 2
[StateDef 7005]
ctrl = 0
physics = N
velset = 0
sprpriority = -5

[State 7005, PVA]
type = ParentVarAdd
trigger1 =!time
var(56) = 1
ignorehitpause = 1

[State 7005, PVA]
type = ParentVarAdd
trigger1 =!time
var(14) = 1
ignorehitpause = 1

[State 7005, PVS]
type = ParentVarSet
triggerall = parent,var(14)!=2
trigger1 = 1
var(24) = GetHitVar(damage)
ignorehitpause = 1

[State 7005, Change]
type = ChangeState
trigger1 = 1
value = 7000

;========================<RED FIRE>=============================
[Statedef 7180]
physics = N
velset = 0, 0
anim = 1
sprpriority = 4

[State 7180, Assert]
type = assertspecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 7180, flames]
type = explod
trigger1 = 1
anim = 7180
ID = 7180
sprpriority = 3
postype = p2
vel = -.2, -.75
pos = (enemynear, const(size.mid.pos.x)), ifelse((enemynear, statetype = L), 0, (enemynear, const(size.mid.pos.y) + 10))
random = 40, 40
removetime = -2
scale = 0.5, 0.5
ownpal = 1

[State 7180, Pos]
type = posadd
trigger1 = 1
x = ceil(p2dist x)
y = ceil(p2dist y)

[State End]
type = destroyself
triggerall = numenemy
trigger1 = enemynear, ctrl
trigger2 = enemynear, movetype != H || enemynear, stateno = 5300
trigger3 = enemynear, statetype = L && (enemynear, stateno != [5080, 5081])

[State End]
type = destroyself
trigger1 = !numenemy || time >= 120

;--- < Lei-Lei > ---
[Statedef 7181]
physics = N
velset = 0, 0
anim = 1
sprpriority = 4

[State 7181, Assert]
type = assertspecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 7181, flames]
type = explod
trigger1 = 1
anim = 7180
ID = 7181
sprpriority = 3
postype = p1
random = 40, 40
vel = -.2, -.75
removetime = -2
scale = 0.5, 0.5
ownpal = 1

[State 7181, Pos]
type = bindtoroot
trigger1 = 1
pos = 0, -33

[State 7181, End]
type = destroyself
trigger1 = time >= 120
trigger2 = root, ctrl || (root, movetype != H) || (root, statetype = L)

;--- <PARTNER> ---
[Statedef 7182]
physics = N
velset = 0, 0
anim = 1
sprpriority = 4

[State 7182, Assert]
type = assertspecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 7182, flames]
type = explod
trigger1 = 1
anim = 7180
ID = 7181
sprpriority = 3
postype = p2
vel = -.2, -.75
pos = (partner, const(size.mid.pos.x)), (partner, const(size.mid.pos.y)) + 10
random = 40, 40
vel = -.2, -.75
removetime = -2
scale = 0.5, 0.5
ownpal = 1

[State 7182, Pos]
type = posadd
trigger1 = 1
x = ceil(pos x -(partner, pos x))
y = ceil(pos x -(partner, pos x))

[State 7182, End]
type = destroyself
trigger1 = time >= 120
trigger2 = !numpartner
trigger3 = numpartner
trigger3 = partner, ctrl || (partner, movetype != H) || (partner, statetype = L)

;========================<CAMERA CONTROL>=============================
[Statedef 7650]
physics = N
velset = 0, 0
anim = 1

[State 7650, bound]
type = screenbound
trigger1 = 1
value = 0
movecamera = 1, 1

[State 7650, End]
type = destroyself
trigger1 = roundstate = 2

;========================<BURNED>=============================
[Statedef 7697]
type = A
movetype = H
physics = N
velset = 0, 0

[State 7697, Anim]
type = changeanim
trigger1 = !time && selfanimexist(7697)
value = 7697

[State 7697, End]
type = selfstate
trigger1 = !time && !selfanimexist(7697)
value = 5030

[State 7697, Accel]
type = veladd
trigger1 = 1
y = gethitvar(yaccel)

[State 7697, Vel]
type = hitvelset
trigger1 = !time
x = 1
y = 1

[State 7697, End]
type = selfstate
;trigger1 = hitover
trigger1 = vel y > 0 && pos y >= -10
value = 5100

;========================<CAMERA FOCUS>=============================
[Statedef 6009]
type = S
physics  = S
anim = 0
ctrl = 0

[state 6009,TURN]
type = turn
trigger1 = ishelper(6009)
trigger1 = facing!=root,facing
ignorehitpause = 1

[State 6009,vel]
type = VelSet
trigger1 = parent,pos X > 0
x = ifelse(facing = 1,4,-4)

[State 6009,vel]
type = VelSet
trigger1 = parent,pos X < 0
x = ifelse(facing = 1,-4,4)

[State 6009,vel]
type = VelSet
trigger1 = parent,pos X = [-5,5]
x = 0

[State 6009, WIDTH]
type = Width
trigger1 = 1
value = 1,1

[State 6009, NHB]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 6009,AS]
type = AssertSpecial
Trigger1 = 1
flag = invisible
flag2 = noshadow

[State 6009,Bound]
type = ScreenBound
trigger1 = 1
value =1
movecamera = 320,0

[State 6009,push]
type = PlayerPush
trigger1 = 1
value = 0

[State 6009, Destroyself]
type = destroyself
trigger1 = Time = 50
trigger1 = enemy, Life >= 1
trigger2 = numhelper(6009)>=2

;========================<SPARKS>=============================
;Guard Spark (Normal)
[StateDef 8000]
type = A
physics = N
moveType = I
anim = 8000
velset = 0,0
sprPriority = 5

[State 8000, Assert: No Shadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8000, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.125 + (0.046875 * Time), 0.125 + (0.046875 * Time)
ignoreHitPause = 1

[State 8000, Transparency]
type = Trans
trigger1 = Time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8000, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8000, End]
type = DestroySelf
trigger1 = Time >= 8


;Guard Spark (Special)
[StateDef 8001]
type = A
physics = N
moveType = I
anim = 8001
velSet = 0,0
sprPriority = 5

[State 8001, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8001, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
ignoreHitPause = 1

[State 8001, Transparency]
type = Trans
trigger1 = time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8001, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8001, End]
type = DestroySelf
trigger1 = Time >= 8


;Weak Hit Spark
[StateDef 8010]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8010, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8010, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8010, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8010, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.3 - (Time * 0.03), 0.3 - (Time * 0.03)
ignoreHitPause = 1

[State 8010, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8010, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8010, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.15 + (0.009375 * Time), 0.15 + (0.009375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time),256

[State 8010, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.15 + (0.009375 * Time), 0.15 + (0.009375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8010, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.3 - (0.0375 * Time), 0.3 - (0.0375 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8010, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8010, End]
type = DestroySelf
trigger1 = Time >= 16


;Medium Hit Spark
[StateDef 8011]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8011, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8011, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8011, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8011, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.35 - (Time * 0.035), 0.35 - (Time * 0.035)
ignoreHitPause = 1

[State 8011, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8011, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8011, Center]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removetime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.175 + (0.0109375 * Time), 0.175 + (0.0109375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8011, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.175 + (0.0109375 * Time), 0.175 + (0.0109375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8011, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.35 - (0.04375 * Time), 0.35 - (0.04375 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8011, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8011, End]
type = DestroySelf
trigger1 = Time >= 16


;Strong Hit Spark
[StateDef 8012]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8012, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8012, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8012, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8012, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.4 - (Time * 0.04), 0.4 - (Time * 0.04)
ignoreHitPause = 1

[State 8012, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8012, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8012, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8012, Streaks Explod]
type = Explod
trigger1 = !time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8012, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.4 - (0.05 * Time), 0.4 - (0.05 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8012, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8012, End]
type = DestroySelf
trigger1 = Time >= 16


;Special Move Hit Spark
[StateDef 8013]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8013, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8013, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8013, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8013, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.45 - (Time * 0.045), 0.45 - (Time * 0.045)
ignoreHitPause = 1

[State 8012, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8013, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8013, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8013, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8013, P2 Back Explod]
type = Explod
trigger1 = !Time
anim = 8013
ID = 3
posType = P1
facing = -1
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = -3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale P2 Back Explod]
type = ModifyExplod
trigger1= NumExplod(3)
ID = 3
scale = 0.4, 0.4
trans = AddAlpha
alpha = 256 - (32 * Time), 256

[State 8013, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(random < 500, -1, 1)
vFacing = ifElse(random < 500, -1, 1)
sprPriority=3
removeTime=8
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.45 - (0.05625 * Time), 0.45 - (0.05625 * Time)
trans = AddAlpha
alpha = 192 - (24 * Time), 256

[State 8013, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8013, End]
type = DestroySelf
trigger1 = Time >= 16


;Super Hit Spark
[StateDef 8014]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8014, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8014, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8014, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8014, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.5 - (Time * 0.05), 0.5 - (Time * 0.05)
ignoreHitPause = 1

[State 8014, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8014, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8014, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8014, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8014, P2 Back Explod]
type = Explod
trigger1 = !Time
anim = 8013
ID = 3
posType = P1
facing = ifElse((Parent, StateNo = [3000,3999]), -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = -3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale P2 Back Explod]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 0.5,0.5
trans = AddAlpha
alpha = 256 - (32 * Time), 256

[State 8014, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.5 - (0.0625 * Time), 0.5 - (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (32 * Time),256

[State 8014, Remove Explods]
type = RemoveExplod
trigger1 = time >= 16

[State 8014, End]
type = DestroySelf
trigger1 = Time >= 16

;Normal Slash Spark
[StateDef 8015]
type = A
physics = N
moveType = I
anim = 8015
velSet = 0,0
sprPriority = 5

[State 8015, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8015, AngleSet]
type = AngleSet
trigger1 = !Time
value = 15 * (Random % 24)

[State 8015, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = (0.5 + (Time * 0.15)) / 2, (1 - (Time * 0.1)) / 2
ignoreHitPause = 1

[State 8015, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8015, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8015, Streaks Explod]
type = Explod
trigger1 = !time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8015, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8015, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8015, End]
type = DestroySelf
trigger1 = Time >= 16

;Special Move Slash Spark
[StateDef 8016]
type = A
physics = N
moveType = I
anim = 8015
velSet = 0,0
sprPriority = 5

[State 8016, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8016, AngleSet]
type = AngleSet
trigger1 = !Time
value = 15 * (Random % 24)

[State 8016, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = (0.5 + (Time * 0.15)) / 2, (1 - (Time * 0.1)) / 2
ignoreHitPause = 1

[State 8016, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8016, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8016, Circle]
type = Explod
trigger1 = !Time
anim = 8016
ID = 8016
posType = p1
removeTime = 10
sprPriority = 5
pauseMoveTime = -1
superMoveTime = -1

[State 8016, Circle Scale]
type = ModifyExplod
trigger1 = NumExplod(8016)
ID = 8016
scale = 0.25 + (0.025 * Time), 0.25 + (0.025 * Time)
trans = AddAlpha
alpha = ceil(256 - 25.6 * Time), 256

[State 8016, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8016, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8016, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8016, End]
type = DestroySelf
trigger1 = Time >= 16

;Super Move Slash Spark
[StateDef 8017]
type = A
physics = N
moveType = I
anim = 8015
velSet = 0,0
sprPriority = 5

[State 8017, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8017, AngleSet]
type = AngleSet
trigger1 = !Time
value = 15 * (Random % 24)

[State 8017, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = (0.5 + (Time * 0.15)) / 2, (1 - (Time * 0.1)) / 2
ignoreHitPause = 1

[State 8017, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8017, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8017, Circle]
type = Explod
trigger1 = !Time
anim = 8016
ID = 8016
posType = p1
removeTime = 10
sprPriority = 5
pauseMoveTime = -1
superMoveTime = -1

[State 8017, Circle Scale]
type = ModifyExplod
trigger1 = NumExplod(8016)
ID = 8016
scale = 0.3 + (0.03 * Time), 0.3 + (0.03 * Time)
trans = AddAlpha
alpha = ceil(256 - 25.6 * Time), 256

[State 8017, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8017, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8017, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8017, End]
type = DestroySelf
trigger1 = Time >= 16

;Reversal Spark
[StateDef 8020]
type = A
physics = N
moveType = I
anim = 8020
velSet = 0,0
sprPriority = 5

[State 8020, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8020, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.09375 * Time), 0.25 + (0.09375 * Time)
ignoreHitPause = 1

[State 8020, Transparency]
type = Trans
trigger1 = Time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8020, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8020, End]
type = DestroySelf
trigger1 = Time >= 8



;======================<JUMP DUST>===========================
[StateDef 8100]
type = S
anim = 1
velSet = 0,0

[State 8100, Bind]
type = BindToRoot
trigger1 = Time

[State 8100, Floor Dust]
type = Explod
trigger1 = !Time
anim = 8100
sprPriority = 3
posType = P1
pos = 0, ceil(pos y)
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8100, Player Dust]
type = Explod
trigger1 = !Time || Time = 2 || Time = 6
anim = 8101
sprPriority = 3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8100, End]
type = DestroySelf
trigger1 = Time >= 7



;======================<DASH DUST>===========================
[StateDef 8103]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8103, posSet]
type = PosSet
trigger1 = !Time = 0
y = 0

[State 8103, Dash Dust]
type = Explod
trigger1 = Time = 0 || Time = 3 || Time = 6
anim = 8103
ID = ifElse((Time = 6), 3, ifElse((Time = 3), 2, 1))
posType = P1
pos = 0,-4
random = 8,8
vel = -3 - (Random / 1000.0), -2 - (Random / 2000.0)
facing = ifElse(Random < 500,-1,1)
vFacing = ifElse(Random < 500,-1,1)
removeTime = 16
sprPriority = 3
pauseMoveTime = -1
superMoveTime = -1

[State 8103, Scale Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.1 + (0.025 * Time), 0.1 + (0.025 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8103, Scale Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.1 + (0.025 * (Time - 3)), 0.1 + (0.025 * (Time - 3))
trans = AddAlpha
alpha = 256 - (16 * (Time - 3)), 256

[State 8103, Scale Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 0.1 + (0.025 * (Time - 6)), 0.1 + (0.025 * (Time - 6))
trans = AddAlpha
alpha = 256 - (16 * (Time - 6)), 256

[State 8103, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 22

[State 8103, End]
type = DestroySelf
trigger1 = !NumExplod


;======================<IMPACT DUST>===========================
[StateDef 8110]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8110, Impact Dust Explod 1]
type = Explod
trigger1 = !Time
anim = 8110
ID = ifElse(Time = 8, 3, ifElse(Time = 4, 2, 1))
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8110, Impact Dust Explod 2]
type = Explod
trigger1 = !Time
anim = 8120
ID = 2
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8110, Scale]
type = ModifyExplod
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 256, 256 - (64 * (Time - 4))), 256

[State 8110, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 8

[State 8110, End]
type = DestroySelf
trigger1 = !NumExplod


;======================<WALL IMPACT DUST>===========================
[StateDef 8111]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8111, Impact Dust Explod 1]
type = Explod
trigger1 = !Time
anim = 8111
ID = ifElse(Time = 8, 3, ifElse(Time = 4, 2, 1))
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8111, Impact Dust Explod 2]
type = Explod
trigger1 = !Time
anim = 8121
ID = 2
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8111, Scale]
type = ModifyExplod
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 256, 256 - (64 * (Time - 4))), 256

[State 8111, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 8

[State 8111, End]
type = DestroySelf
trigger1 = !NumExplod



;========================<RECOVER FX>=============================
[StateDef 8200]
type = A
velSet = 0,0
anim = 8200
sprPriority = 5

[State 8200, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8200, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.017 * Time), 0.25 + (0.017 * Time)
ignoreHitPause = 1

[State 8200, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = ceil(256 - 17.1 * Time), 256
ignoreHitPause = 1

[State 8200, End]
type = DestroySelf
trigger1 = Time >= 15



;========================<COUNTER FX>=============================
[StateDef 8290]
type = A
physics = N
velSet = 0,0
anim = 1

[State 8290, "Counter!" Text Explod]
type = Explod
trigger1 = !NumExplod(8290)
anim = 8290
ID = 8290
sprPriority = 64
posType = P1
facing = Facing
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8290, Scale]
type = ModifyExplod
trigger1 = Time < 8
ID = 8290
scale = 0.5, .5
trans = AddAlpha
alpha = 256,0

[State 8290, Scale]
type = ModifyExplod
trigger1 = Time >= 8
ID = 8290
scale = 0.5 + 0.0625 * (Time - 8), 0.5 + 0.0625 * (Time - 8)
trans = AddAlpha
alpha = 256 - 32 * (Time - 8), 32 * (Time - 8)

[State 8290, Safety]
type = RemoveExplod
trigger1 = Time >= 16

[State 8290, End]
type = DestroySelf
trigger1 = Time >= 16



;==================<POWER CHARGE FX>==================
;Aura and Dust
[StateDef 8330]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velset = 0,0

[State 8330, BindToRoot]
type = BindToRoot
trigger1 = (Root, StateNo = 730)
pos = 0,0

[State 8330, Charging Sound]
type = PlaySnd
trigger1 = !Time
value = 730,0
channel = 0

[State 8330, Power Charge Aura]
type = Explod
trigger1 = !NumExplod(8330)
ID = 8330
anim = 8330
sprPriority = 3
posType = P1
bindTime = -1
removeTime = -1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8330, Power Charge Dust]
type = Explod
trigger1 = !(Time % 6)
anim = 8105
sprPriority = -3
posType = P1
pos = 0, -ceil(pos y)
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8330, Modify Aura 1]
type = ModifyExplod
trigger1 = Numexplod(8330) && Root, Power < 3000
ID = 8330
scale = 0.5, 0.1 + 0.4 * (Root, Power / 3000.0)

[State 8330, Modify Aura 2]
type = ModifyExplod
trigger1 = NumExplod(8330) && Root, Power >= 3000
ID = 8330
scale = 0.5, 0.5

[State 8330, StopSnd]
type = StopSnd
trigger1 = Root, StateNo != 730
channel = 0

[State 8330, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 730

[State 8330, End]
type = DestroySelf
trigger1 = Root, StateNo != 730


;Particles
[StateDef 8331]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8331, BindToRoot]
type = BindToRoot
trigger1 = !(Time % 8)
pos = ceil(-151 + (Random / 3.125)), ceil(98 - (Random / 3.125))

[State 8331, Particle]
type = Explod
trigger1 = (Time % 8) = 1
anim = 8331
sprPriority = ifElse(Random < 750, 5, -1)
posType = P1
vel = ((RootDist x + 5) / 32.0), ((RootDist y - 71) / 32.0)
scale = ifElse(Random < 500, 0.5, -0.5), ifElse(Random < 500, 0.5, -0.5)
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8331, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 730

[State 8331, End]
type = DestroySelf
trigger1 = Root, StateNo != 730


;==================<VIOLENT WIN VS VEGA PARTICLES>==================
[StateDef 8332]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8332, BindToRoot]
type = BindToRoot
trigger1 = !(Time % 4)
pos = ceil(-40 + (Random /10.25)), ceil(-17 - (Random / 10.25))

[State 8332, Particles]
type = Explod
trigger1 = (Time % 4) = 1
anim = 8332
sprPriority = ifElse(Random < 750,5,-1)
posType = P1
vel = (-(RootDist x + 4) / 10.0),(-(RootDist y - 85) / 10.0)
scale = ifElse(random < 500 ,0.5, -0.5),ifElse(random < 500, 0.5, -0.5)
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8332, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 187 || Root, AnimElemTime(60) >= 0

[State 833, End]
type = DestroySelf
trigger1 = Root, StateNo != 187 || Root, AnimElemTime(60) >= 0



;==================<ZERO COUNTER FX>==================
[StateDef 8350]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8350, bgPalFX]
type = bgPalFX
trigger1 = 1
time = 1
color = 16 * Time
mul = 16 * Time, 16 * Time, 16 * Time

[State 8350, Circle Explod]
type = Explod
trigger1 = !Time
anim = 8350
ID = 1
sprPriority = 3
posType = P1
removeTime = 16
superMoveTime = -1
ownPal = 1

[State 8350, Scale]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = (0.0625 * Time), (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8350, Lightning Explod]
type = Explod
trigger1 = !Time
anim = 8351
ID = 2
sprPriority = -2
posType = P1
pos = 0, -ceil(pos y)
superMoveTime = -1
ownPal = 1

[State 8350, End]
type = DestroySelf
trigger1 = Time >= 16



;========================<CUSTOM COMBO>=============================
[StateDef 8400]
type = A
physics = N
moveType = I
anim = 8400
ctrl = 0
velSet = 0,0
sprPriority = 5

[State 8400, NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8400, BGpalFX]
type = BGpalFX
trigger1 = Time < 25
time = 1
mul = 128,128,128

[State 8400, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8400, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8400, Scale]
type = AngleDraw
trigger1 = Time < 8
scale = (0.0625 * Time), (0.0625 * Time)
ignoreHitPause = 1

[State 8400, Scale]
type = AngleDraw
trigger1 = Time >= 8
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8400, Transparency]
type = Trans
trigger1 = Time < 16
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8400, Transparency]
type = Trans
trigger1 = Time >= 16
trans = AddAlpha
alpha = ceil(256 - 25.6 * (Time - 16)), 256
ignoreHitPause = 1

[State 8400, Lines Explod]
type = Explod
trigger1 = !Time
anim = 8401
ID = 1
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8400, Scale Lines Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 2 - (0.125 * Time), 2 - (0.125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8400, Circle Explod]
type = Explod
trigger1 = Time = 16
anim = 8402
ID = 2
sprPriority = 5
posType = P1
removeTime = 32
superMoveTime = -1

[State 8400, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = (0.1 * (Time - 16)), (0.1 * (Time - 16))
trans = AddAlpha
alpha = ceil(256 - 25.6 * (Time - 16)), 256

[State 8400, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 26

[State 8400, End]
type = DestroySelf
trigger1 = Time >= 26



;========================<SUPER PAUSE FX>=============================
;Level 1 Super FX
[StateDef 8500]
type = A
velSet = 0,0
anim = 8500
sprPriority = 5

[State 8500, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8500, BGpalFX]
type = BGpalFX
trigger1 = Time < 39
time = 1
color = 0
mul = 0,0,256

[State 8500, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8500, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8500, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8500, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5,0.5
ignoreHitPause = 1

[State 8500, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8500, Lines Explod]
type = Explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8501
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8500, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8500, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1 - (0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8500, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8500, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 - (0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8500, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8502
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 32
superMoveTime = -1

[State 8500, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8500, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8500, End]
type = DestroySelf
trigger1 = Time >= 40


;Level 2 Super FX
[StateDef 8510]
type = A
velSet = 0,0
anim = 8510
sprPriority = 5

[State 8510, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8510, BGpalFX]
type = BGpalFX
trigger1 = Time < 39
time = 1
color = 0
mul = 192,0,256

[State 8510, Rotate]
type = AngleSet
trigger1 = !Time
value =6 * (Random % 60)

[State 8510, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8510, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8510, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8510, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8510, Lines Explod]
type = Explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8511
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8510, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8510, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1 - (0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8510, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8510, Scale Lines Explod 4]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 -(0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8510, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8512
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500,-1,1)
vFacing = ifElse(Random < 500,-1,1)
removeTime = 32
superMoveTime = -1

[State 8510, Scale]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24)<4, 64 * (Time - 24), 256), 256

[State 8510, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8510, End]
type = DestroySelf
trigger1 = Time >= 40


;Level 3 Super FX
[StateDef 8520]
type = A
velset = 0,0
anim = 8520
sprPriority = 5

[State 8520, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8520, Assert: NoBarDisplay, NoBG, NoFG]
type = AssertSpecial
trigger1 = Time < 40
flag = NoBarDisplay
flag2 = NoBG
flag3 = NoFG

[State 8520, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8520, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8520, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8520, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8520, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8520, Portrait 1]
type = Explod
trigger1 = !Time
anim = 8525
ID = 20
sprPriority = -16
posType = Back
removeTime = 40
superMoveTime = -1

[State 8520, Portrait 2]
type = Explod
trigger1 = !Time
anim = 8525
ID = 21
sprPriority = -16
posType = Back
removeTime = 40
superMoveTime = -1

[State 8520, Scale Portrait 1a]
type = ModifyExplod
trigger1 = NumExplod(20) && Time < 16
ID = 20
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 1 - (0.03125 * Time), 1 - (0.03125 * Time)
trans = AddAlpha
alpha = (8 * Time), 256

[State 8520, Scale Portrait 2a]
type = ModifyExplod
trigger1 = NumExplod(21) && Time < 16
ID = 21
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 2 - (0.09375 * Time), 2 - (0.09375 * Time)
trans = AddAlpha
alpha = (8 * Time), 256

[State 8520, Scale Portrait 1b]
type = ModifyExplod
trigger1 = NumExplod(20) && (Time = [16,32])
ID = 20
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 256, 256

[State 8520, Scale Portrait 2b]
type = ModifyExplod
trigger1 = NumExplod(21) && (Time = [16,32])
ID = 21
scale = 0,0

[State 8520, Scale Portrait 1c]
type = ModifyExplod
trigger1 = NumExplod(20) && Time >= 32
ID = 20
posType = Back
pos = 160 + (8 * (Time - 32)), floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 128 - 16 * (Time - 32), 256

[State 8520, Scale Portrait 2c]
type = ModifyExplod
trigger1 = NumExplod(21) && Time >= 32
ID = 21
posType = Back
pos = 160 - (8 * (Time - 32)), floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 128 - 16 * (Time - 32), 256

[State 8520, Lines Explod]
type = explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8521
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8520, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8520, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1-(0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8520, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8520, Scale Lines Explod 4]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 - (0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8520, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8522
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1 ,1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 32
superMoveTime = -1

[State 8520, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8520, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8520, End]
type = DestroySelf
trigger1 = Time >= 40



;========================<SUPER FINISH>=============================
[StateDef 8600]
type = A
velSet = 0,0
anim = 1

[State 8600, Super Finish Sound]
type = PlaySnd
trigger1 = !Time
value = 8600,0
channel = 0

[State 8600, SndPan]
type = SndPan
trigger1 = Time <= 80
channel = 1
absPan = ceil(sin(GameTime / 20.0 * pi) * 160)

[State 8600, BG PalFX]
type = BGpalFX
trigger1 = Time < 16
time = 1
mul = 0, 0, 0

[State 8600, BG PalFX]
type = BGpalFX
trigger1 = Time = [16,24)
time = 1
mul = 32 * (Time - 16), 32 * (Time - 16), 32 * (Time - 16)

[State 8600, Move Name: Custom Combo]
type = VarSet
trigger1= !Time && Root, var(23) = 900
var(0) = 1

[State 8600, Move Name: Somersault Strike]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3000,3099])
var(0) = 2

[State 8600, Move Name: Total Wipeout]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3100,3199])
var(0) = 3

[State 8600, Move Name: Sonic Hurricane]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3200,3299])
var(0) = 4

[State 8600, Move Name: Opening Gambit]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3300,3399])
var(0) = 5

[State 8600, Super Finish Explod]
type = Explod
trigger1 = !Time
anim = 8600
ID = 8600
ontop = 1
postype = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Super Finish Explod Fade]
type = ModifyExplod
trigger1 = NumExplod(8600)
ID = 8600
trans = AddAlpha
alpha = ifElse(Time < 16, 256, 256 - 32 * (Time - 16)), 256

[State 8600, Text 1]
type = Explod
trigger1 = !Time && var(0)
anim = 8610 + var(0)
ID = 10
onTop = 1
posType = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Text 2]
type = Explod
trigger1 = !Time && var(0)
anim = 8610 + var(0)
ID = 11
onTop = 1
posType = left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Text 1 Fade]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
trans = AddAlpha
alpha = ifElse(Time < 16, 256, 256 - 32 * (Time - 16)), ifElse(Time < 16, 0, 32 * (Time - 16))

[State 8600, Text 2 Fade]
type = ModifyExplod
trigger1 = NumExplod(11)
ID = 11
scale = 0.5 + (0.0625 * Time), 0.5 + (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (32 * Time), 32 * Time

[State 8600, Circle Explod]
type = Explod
trigger1 = !Time
anim = 8601
ID = 8601
under = 1
posType = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
bindTime = -1
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Circle Fade]
type = ModifyExplod
trigger1 = NumExplod(8601)
ID = 8601
scale = (0.25 * Time) * (1.3333333 * GameHeight / GameWidth), (0.25 * Time) * (1.3333333 * GameHeight / GameWidth)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8600, Assert: NoFG]
type = AssertSpecial
trigger1 = Time < 16
flag = NoFG

[State 8600, Assert: NoBarDisplay]
type = AssertSpecial
trigger1 = Time < 24
flag = NoBarDisplay

[State 8600, RemoveExplod]
type = RemoveExplod
trigger1 = Time >= 24
trigger2 = RoundState < 3

[State 8600, End]
type = DestroySelf
trigger1 = RoundState < 3



;========================<CAMERA CONTROL>=============================
[StateDef 8999]
type = S
velSet = 0,0
anim = 1

[State 8999, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
moveCamera = 1,1
ignoreHitPause = 1

[State 8999, End]
type = DestroySelf
trigger1 = RoundState = 2
