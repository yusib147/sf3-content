; ________________________________________________
;| Hsien-Ko by Phantom.of.the.Server & varo_hades |
; ������������������������������������������������
;==============================================================================================
;========================================<SPECIAL MOVES>=======================================
;==============================================================================================

;=====================<ANKI HOU>==========================
[StateDef 1000]
type = S
physics = S
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1000, Anim]
type = changeanim
trigger1 = !time
value = ifelse(var(10) = 0, 1000, 1001)

[State 1000, width]
type = width
trigger1 = anim = 1000 && animelemtime(4) = 0
value = 75, 0

[State 1000, width]
type = width
trigger1 = anim = 1001 && animelemtime(6) = 0
value = 50, 0

[State 1000, weapon]
type = helper
trigger1 = anim = 1000 && animelemtime(4) = 1 && var(10) = 0
helpertype = normal
stateno = 1005
ID = 1005
name = "Object"
postype = p1
pos = 103, -24
ownpal = 1

[State 1000, weapon]
type = helper
trigger1 = anim = 1001 && animelemtime(6) = 1 && var(10) = 1
helpertype = normal
stateno = 1005
ID = 1005
name = "Object"
postype = p1
pos = 88, -90
ownpal = 1

[State 1000, weapon]
type = helper
trigger1 = anim = 1001 && animelemtime(6) = 1 && var(10) = 2
helpertype = normal
stateno = 1005
ID = 1005
name = "Object"
postype = p1
pos = 56, -101
ownpal = 1

[State 1000, Snd]
type = playsnd
trigger1 = anim = 1000 && animelem = 3
trigger2 = anim = 1001 && animelem = 5
value = 1000, 0
channel = 0

[State 1000, End]
type = changestate
trigger1 = !animtime
value = 0
ctrl = 1

;========================<EX ANKI HOU>=============================
[StateDef 1030]
type = S
physics = S
moveType = A
anim = 1030
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, width]
type = width
trigger1 = animelemtime(4) = 0 || animelemtime(11) = 0 || animelemtime(18) = 0
value = 75, 0

[State 1030, weapon]
type = helper
trigger1 = animelemtime(4) = 1 || animelemtime(11) = 1 || animelemtime(18) = 1
helpertype = normal
stateno = 1035
ID = 1035
name = "Spiked Ball"
postype = p1
pos = 103, 0
ownpal = 1

[State 1030, spinsnd]
type = playsnd
trigger1 = animelem = 4
value = 4, 4
channel = 0

[State 1030, spinsnd]
type = playsnd
trigger1 = animelem = 11
value = 1000, 1
channel = 0

[State 1030, spinsnd]
type = playsnd
trigger1 = animelem = 18
value = 1000, 2
channel = 0

[State 1030, spinsnd]
type = playsnd
trigger1 = animelemtime(4) = 1 || animelemtime(11) = 1 || animelemtime(18) = 1
value = 5, 6

[State 1030, End]
type = changestate
trigger1 = !animtime
value = 0
ctrl = 1

;========================<SENPUU BU>=============================
[StateDef 1100]
type = U
movetype = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = (statetype != A)

[State 1100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1100, statetype]
type = statetypeset
trigger1 = !time && statetype != A
statetype = S
physics = S

[State 1100, statetype]
type = statetypeset
trigger1 = !time && statetype = A
statetype = A
physics = N

[State 1100, Strength]
type = varset
trigger1 = var(10) != 2
var(10) = 2

[State 1100, Dust]
type = explod
trigger1 = (statetype = A) && animelem = 3
anim = 8104
ID = 8104
sprpriority = 2
postype = p1
pos = 16, 8
removetime = -2
scale = 0.5, 0.5
ownpal = 1
pausemovetime = -1
supermovetime = -1

[State 1100, Dust]
type = explod
trigger1 = (statetype = A) && animelem = 3
anim = 8104
ID = 8104
sprpriority = -2
postype = p1
pos = 59, 2
removetime = -2
scale = 0.5, 0.5
ownpal = 1
pausemovetime = -1
supermovetime = -1

[State 1100, Snd]
type = playsnd
trigger1 = animelem = 17
value = 1100, 0
channel = 0

[State 1100, Snd]
type = playsnd
trigger1 = animelem = 3
value = 5, 0

[State 1100, Push]
type = playerpush
trigger1 = animelemtime(7) >= 0 || statetype = A
value = 0

[State 1100, statetype]
type = statetypeset
trigger1 = animelemtime(12) >= 0
statetype = A
physics = N

[State 1100, pos12 -15]
type = posadd
trigger1 = animelem = 12 || animelem = 13 || animelem = 14 || animelem = 15
x = ifelse((animelem = 12), 25, ifelse((animelem = 13), 5, 4))
y = ifelse((animelem = 12), -3, ifelse((animelem = 13), -1, ifelse((animelem = 14), -4, -3)))

[State 1100, pos16 -19]
type = posadd
trigger1 = animelem = 16 || animelem = 17 || animelem = 18 || animelem = 19
x = ifelse((animelem = 16), 7, ifelse((animelem = 17), 4, ifelse((animelem = 18), -21, 3)))
y = ifelse((animelem = 16), -4, ifelse((animelem = 17), -2, ifelse((animelem = 18), -29, -5)))

[State 1100, pos20 -21]
type = posadd
trigger1 = animelem = 20 || animelem = 21
x = ifelse((animelem = 20), 8, -14)
y = 2

[State 1100, End]
type = changestate
trigger1 = !animtime
value = 1101

;--- SWING ---
[Statedef 1101]
type = A
physics = N
movetype = A
anim = 1101
ctrl = 0
velset = 0, 0
sprpriority = 1

[State 1101, swingvar]
type = varadd
trigger1 = !time
var(41) = 1

[State 1101, Push]
type = playerpush
trigger1 = anim = 1101
value = 0

[State 1101, screenbound]
type = screenbound
trigger1 = anim = 1101
value = 0
movecamera = 1, 1

[State 1101, width]
type = width
trigger1 = anim = 1101
edge = 50, 0

[State 1101, claw]
type = helper
trigger1 = !time
helpertype = normal
stateno = 1105
ID = 1105
name = "Senpuubu Claw"
postype = p1

[State 1101, pos1 -4]
type = posadd
trigger1 = anim = 1101 && (animelem = 1 || animelem = 2 || animelem = 3 || animelem = 4)
x = ifelse((animelem = 1), -1, ifelse((animelem = 2), 0, ifelse((animelem = 3), 3, 4)))
y = ifelse((animelem = 1), -7, ifelse((animelem = 2), 4, ifelse((animelem = 3), 4, 5)))

[State 1101, pos5 -8]
type = posadd
trigger1 = anim = 1101 && (animelem = 5 || animelem = 6 || animelem = 7 || animelem = 8)
x = ifelse((animelem = 5), 3, ifelse((animelem = 6), 5, ifelse((animelem = 7), 7, 22)))
y = ifelse((animelem = 5), 4, ifelse((animelem = 6), 5, ifelse((animelem = 7), 8, 11)))

[State 1101, pos9 -12]
type = posadd
trigger1 = anim = 1101 && (animelem = 9 || animelem = 10 || animelem = 11 || animelem = 12)
x = ifelse((animelem = 9), 4, ifelse((animelem = 10), 9, ifelse((animelem = 11), 5, 18)))
y = ifelse((animelem = 9), 3, ifelse((animelem = 10), 5, ifelse((animelem = 11), 2, 8)))

[State 1101, pos13 -16]
type = posadd
trigger1 = anim = 1101 && (animelem = 13 || animelem = 14 || animelem = 15 || animelem = 16)
x = ifelse((animelem = 13), 11, ifelse((animelem = 14), 8, ifelse((animelem = 15), 15, 37)))
y = ifelse((animelem = 13), 5, ifelse((animelem = 14), 2, ifelse((animelem = 15), 3, 0)))

[State 1101, pos17 -20]
type = posadd
trigger1 = anim = 1101 && (animelem = 17 || animelem = 18 || animelem = 19 || animelem = 20)
x = ifelse((animelem = 17), 11, ifelse((animelem = 18), 12, ifelse((animelem = 19), 11, 14)))
y = ifelse((animelem = 17), 0, ifelse((animelem = 18), -1, ifelse((animelem = 19), -1, -3)))

[State 1101, pos21 -24]
type = posadd
trigger1 = anim = 1101 && (animelem = 21 || animelem = 22 || animelem = 23 || animelem = 24)
x = ifelse((animelem = 21), 21, ifelse((animelem = 22), 7, ifelse((animelem = 23), 25, 5)))
y = ifelse((animelem = 21), -4, ifelse((animelem = 22), -4, ifelse((animelem = 23), -3, -2)))

[State 1101, pos25 -28]
type = posadd
trigger1 = anim = 1101 && (animelem = 25 || animelem = 26 || animelem = 27 || animelem = 28)
x = ifelse((animelem = 25), 2, ifelse((animelem = 26), 12, ifelse((animelem = 27), 5, 3)))
y = ifelse((animelem = 25), -1, ifelse((animelem = 26), -9, ifelse((animelem = 27), -2, -4)))

[State 1101, pos29 -32]
type = posadd
trigger1 = anim = 1101 && (animelem = 29 || animelem = 30 || animelem = 31 || animelem = 32)
x = ifelse((animelem = 29), 2, ifelse((animelem = 30), 5, ifelse((animelem = 31), 4, 3)))
y = ifelse((animelem = 29), -2, ifelse((animelem = 30), -5, ifelse((animelem = 31), -5, -6)))

[State 1101, pos33 -36]
type = posadd
trigger1 = anim = 1101 && (animelem = 33 || animelem = 34 || animelem = 35 || animelem = 36)
x = ifelse((animelem = 33), 3, ifelse((animelem = 34), -3, ifelse((animelem = 35), -3, -4)))
y = ifelse((animelem = 33), -4, ifelse((animelem = 34), 4, ifelse((animelem = 35), 6, 5)))

[State 1101, pos37 -40]
type = posadd
trigger1 = anim = 1101 && (animelem = 37 || animelem = 38 || animelem = 39 || animelem = 40)
x = ifelse((animelem = 37), -5, ifelse((animelem = 38), -2, ifelse((animelem = 39), -3, -5)))
y = ifelse((animelem = 37), 5, ifelse((animelem = 38), 2, ifelse((animelem = 39), 4, 2)))

[State 1101, pos41 -44]
type = posadd
trigger1 = anim = 1101 && (animelem = 41 || animelem = 42 || animelem = 43 || animelem = 44)
x = ifelse((animelem = 41), -12, ifelse((animelem = 42), -2, ifelse((animelem = 43), -5, -25)))
y = ifelse((animelem = 41), 9, ifelse((animelem = 42), 1, ifelse((animelem = 43), 2, 3)))

[State 1101, pos45 -48]
type = posadd
trigger1 = anim = 1101 && (animelem = 45 || animelem = 46 || animelem = 47 || animelem = 48)
x = ifelse((animelem = 45), -7, ifelse((animelem = 46), -21, ifelse((animelem = 47), -14, -11)))
y = ifelse((animelem = 45), 4, ifelse((animelem = 46), 4, ifelse((animelem = 47), 3, 1)))

[State 1101, pos49 -52]
type = posadd
trigger1 = anim = 1101 && (animelem = 49 || animelem = 50 || animelem = 51 || animelem = 52)
x = ifelse((animelem = 49), -12, ifelse((animelem = 50), -11, ifelse((animelem = 51), -37, -15)))
y = ifelse((animelem = 49), 1, ifelse((animelem = 50), 0, ifelse((animelem = 51), 0, -3)))

[State 1101, pos53 -56]
type = posadd
trigger1 = anim = 1101 && (animelem = 53 || animelem = 54 || animelem = 55 || animelem = 56)
x = ifelse((animelem = 53), -8, ifelse((animelem = 54), -11, ifelse((animelem = 55), -18, -5)))
y = ifelse((animelem = 53), -2, ifelse((animelem = 54), -5, ifelse((animelem = 55), -8, -2)))

[State 1101, pos57 -60]
type = posadd
trigger1 = anim = 1101 && (animelem = 57 || animelem = 58 || animelem = 59 || animelem = 60)
x = ifelse((animelem = 57), -9, ifelse((animelem = 58), -4, ifelse((animelem = 59), -22, -7)))
y = ifelse((animelem = 57), -5, ifelse((animelem = 58), -3, ifelse((animelem = 59), -11, -7)))

[State 1101, pos61 -64]
type = posadd
trigger1 = anim = 1101 && (animelem = 61 || animelem = 62 || animelem = 63 || animelem = 64)
x = ifelse((animelem = 61), -5, ifelse((animelem = 62), -3, ifelse((animelem = 63), -4, -3)))
y = ifelse((animelem = 61), -5, ifelse((animelem = 62), -4, ifelse((animelem = 63), -5, -4)))

[State 1101, pos65]
type = posadd
trigger1 = anim = 1101 && animelem = 65
y = -4

[State 1101, Snd]
type = playsnd
trigger1 = animelem = 9 || animelem = 42
value = 5, 14

[State 1101, velvar]
type = varset
trigger1 = anim = 1101
var(0) = animelemtime(1)

[State 1101, Anim]
type = changeanim
triggerall = anim = 1101
trigger1 = !animtime
trigger2 = !AIlevel && (command = "a" || command = "b" || command = "c")
trigger3 = AIlevel && numhelper(1105)
trigger3 = helper(1105), movehit = 2 && random < 350
trigger4 = animelemtime(34) < 0 && frontedgedist <= -50
trigger5 = animelemtime(34) >= 0 && backedgedist <= 0
trigger6 = AIlevel
trigger6 = inguarddist && (p2stateno = [3000, 4999])
value = 1102

[State 1101, Ctrl]
type = ctrlset
trigger1 = anim = 1102
value = 1

[State 1101, Vel]
type = velset
trigger1 = anim = 1102 && animelem = 1
x = ifelse(var(0) > 46, -3, 3)
y = ifelse(var(0) < 22, 2, ifelse(var(0) < 46, -4, ifelse(var(0) < 63, 2, -4)))

[State 1101, statetype]
type = statetypeset
trigger1 = anim = 1102
statetype = A
physics = A

[State Idle]
type = statetypeset
trigger1 = anim = 1102
movetype = I

;========================<EX SENPUU BU>=============================
[StateDef 1130]
type = U
movetype = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = (statetype != A)

[State 1130, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1130, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1130, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 131

[State 1130, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1130, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1130, statetype]
type = statetypeset
trigger1 = !time && statetype != A
statetype = S
physics = S

[State 1130, statetype]
type = statetypeset
trigger1 = !time && statetype = A
statetype = A
physics = N

[State 1130, Strength]
type = varset
trigger1 = var(10) != 3
var(10) = 3

[State 1130, swingvar]
type = varset
trigger1 = var(42)
var(42) = 0

[State 1130, dust]
type = explod
trigger1 = (statetype = A) && animelem = 3
anim = 8104
ID = 8104
sprpriority = 2
postype = p1
pos = 16, 8
removetime = -2
scale = 0.5, 0.5
ownpal = 1
pausemovetime = -1
supermovetime = -1

[State 1130, dust]
type = explod
trigger1 = (statetype = A) && animelem = 3
anim = 8104
ID = 8104
sprpriority = -2
postype = p1
pos = 59, 2
removetime = -2
scale = 0.5, 0.5
ownpal = 1
pausemovetime = -1
supermovetime = -1

[State 1130, snd]
type = playsnd
trigger1 = animelem = 17
value = 1100, 0
channel = 0

[State 1130, snd]
type = playsnd
trigger1 = animelem = 3
value = 5, 0

[State 1130, Push]
type = playerpush
trigger1 = animelemtime(7) >= 0 || statetype = A
value = 0

[State 1130, pos12 -15]
type = posadd
trigger1 = animelem = 12 || animelem = 13 || animelem = 14 || animelem = 15
x = ifelse((animelem = 12), 25, ifelse((animelem = 13), 5, 4))
y = ifelse((animelem = 12), -3, ifelse((animelem = 13), -1, ifelse((animelem = 14), -4, -3)))

[State 1130, pos16 -19]
type = posadd
trigger1 = animelem = 16 || animelem = 17 || animelem = 18 || animelem = 19
x = ifelse((animelem = 16), 7, ifelse((animelem = 17), 4, ifelse((animelem = 18), -21, 3)))
y = ifelse((animelem = 16), -4, ifelse((animelem = 17), -2, ifelse((animelem = 18), -29, -5)))

[State 1130, pos20 -21]
type = posadd
trigger1 = animelem = 20 || animelem = 21
x = ifelse((animelem = 20), 8, -14)
y = 2

[State 1130, statetype]
type = statetypeset
trigger1 = animelemtime(12) >= 0
statetype = A
physics = N

[State 1130, End]
type = changestate
trigger1 = !animtime
value = 1131

;--- SWING ---
[Statedef 1131]
type = A
physics = N
movetype = A
anim = 1101
ctrl = 0
velset = 0, 0
sprpriority = 1

[State 1131, swingvar]
type = varadd
trigger1 = !time
var(41) = 1

[State 1131, Push]
type = playerpush
trigger1 = anim = 1101
value = 0

[State 1131, screenbound]
type = screenbound
trigger1 = anim = 1101
value = 0
movecamera = 1, 1

[State 1131, width]
type = width
trigger1 = anim = 1101
edge = 50, 0

[State 1131, claw]
type = helper
trigger1 = !time
helpertype = normal
stateno = 1105
ID = 1135
name = "Senpuubu Claw"
postype = p1

[State 1131, pos1 -4]
type = posadd
trigger1 = anim = 1101 && (animelem = 1 || animelem = 2 || animelem = 3 || animelem = 4)
x = ifelse((animelem = 1), -1, ifelse((animelem = 2), 0, ifelse((animelem = 3), 3, 4)))
y = ifelse((animelem = 1), -7, ifelse((animelem = 2), 4, ifelse((animelem = 3), 4, 5)))

[State 1131, pos5 -8]
type = posadd
trigger1 = anim = 1101 && (animelem = 5 || animelem = 6 || animelem = 7 || animelem = 8)
x = ifelse((animelem = 5), 3, ifelse((animelem = 6), 5, ifelse((animelem = 7), 7, 22)))
y = ifelse((animelem = 5), 4, ifelse((animelem = 6), 5, ifelse((animelem = 7), 8, 11)))

[State 1131, pos9 -12]
type = posadd
trigger1 = anim = 1101 && (animelem = 9 || animelem = 10 || animelem = 11 || animelem = 12)
x = ifelse((animelem = 9), 4, ifelse((animelem = 10), 9, ifelse((animelem = 11), 5, 18)))
y = ifelse((animelem = 9), 3, ifelse((animelem = 10), 5, ifelse((animelem = 11), 2, 8)))

[State 1131, pos13 -16]
type = posadd
trigger1 = anim = 1101 && (animelem = 13 || animelem = 14 || animelem = 15 || animelem = 16)
x = ifelse((animelem = 13), 11, ifelse((animelem = 14), 8, ifelse((animelem = 15), 15, 37)))
y = ifelse((animelem = 13), 5, ifelse((animelem = 14), 2, ifelse((animelem = 15), 3, 0)))

[State 1131, pos17 -20]
type = posadd
trigger1 = anim = 1101 && (animelem = 17 || animelem = 18 || animelem = 19 || animelem = 20)
x = ifelse((animelem = 17), 11, ifelse((animelem = 18), 12, ifelse((animelem = 19), 11, 14)))
y = ifelse((animelem = 17), 0, ifelse((animelem = 18), -1, ifelse((animelem = 19), -1, -3)))

[State 1131, pos21 -24]
type = posadd
trigger1 = anim = 1101 && (animelem = 21 || animelem = 22 || animelem = 23 || animelem = 24)
x = ifelse((animelem = 21), 21, ifelse((animelem = 22), 7, ifelse((animelem = 23), 25, 5)))
y = ifelse((animelem = 21), -4, ifelse((animelem = 22), -4, ifelse((animelem = 23), -3, -2)))

[State 1131, pos25 -28]
type = posadd
trigger1 = anim = 1101 && (animelem = 25 || animelem = 26 || animelem = 27 || animelem = 28)
x = ifelse((animelem = 25), 2, ifelse((animelem = 26), 12, ifelse((animelem = 27), 5, 3)))
y = ifelse((animelem = 25), -1, ifelse((animelem = 26), -9, ifelse((animelem = 27), -2, -4)))

[State 1131, pos29 -32]
type = posadd
trigger1 = anim = 1101 && (animelem = 29 || animelem = 30 || animelem = 31 || animelem = 32)
x = ifelse((animelem = 29), 2, ifelse((animelem = 30), 5, ifelse((animelem = 31), 4, 3)))
y = ifelse((animelem = 29), -2, ifelse((animelem = 30), -5, ifelse((animelem = 31), -5, -6)))

[State 1131, pos33 -36]
type = posadd
trigger1 = anim = 1101 && (animelem = 33 || animelem = 34 || animelem = 35 || animelem = 36)
x = ifelse((animelem = 33), 3, ifelse((animelem = 34), -3, ifelse((animelem = 35), -3, -4)))
y = ifelse((animelem = 33), -4, ifelse((animelem = 34), 4, ifelse((animelem = 35), 6, 5)))

[State 1131, pos37 -40]
type = posadd
trigger1 = anim = 1101 && (animelem = 37 || animelem = 38 || animelem = 39 || animelem = 40)
x = ifelse((animelem = 37), -5, ifelse((animelem = 38), -2, ifelse((animelem = 39), -3, -5)))
y = ifelse((animelem = 37), 5, ifelse((animelem = 38), 2, ifelse((animelem = 39), 4, 2)))

[State 1131, pos41 -44]
type = posadd
trigger1 = anim = 1101 && (animelem = 41 || animelem = 42 || animelem = 43 || animelem = 44)
x = ifelse((animelem = 41), -12, ifelse((animelem = 42), -2, ifelse((animelem = 43), -5, -25)))
y = ifelse((animelem = 41), 9, ifelse((animelem = 42), 1, ifelse((animelem = 43), 2, 3)))

[State 1131, pos45 -48]
type = posadd
trigger1 = anim = 1101 && (animelem = 45 || animelem = 46 || animelem = 47 || animelem = 48)
x = ifelse((animelem = 45), -7, ifelse((animelem = 46), -21, ifelse((animelem = 47), -14, -11)))
y = ifelse((animelem = 45), 4, ifelse((animelem = 46), 4, ifelse((animelem = 47), 3, 1)))

[State 1131, pos49 -52]
type = posadd
trigger1 = anim = 1101 && (animelem = 49 || animelem = 50 || animelem = 51 || animelem = 52)
x = ifelse((animelem = 49), -12, ifelse((animelem = 50), -11, ifelse((animelem = 51), -37, -15)))
y = ifelse((animelem = 49), 1, ifelse((animelem = 50), 0, ifelse((animelem = 51), 0, -3)))

[State 1131, pos53 -56]
type = posadd
trigger1 = anim = 1101 && (animelem = 53 || animelem = 54 || animelem = 55 || animelem = 56)
x = ifelse((animelem = 53), -8, ifelse((animelem = 54), -11, ifelse((animelem = 55), -18, -5)))
y = ifelse((animelem = 53), -2, ifelse((animelem = 54), -5, ifelse((animelem = 55), -8, -2)))

[State 1131, pos57 -60]
type = posadd
trigger1 = anim = 1101 && (animelem = 57 || animelem = 58 || animelem = 59 || animelem = 60)
x = ifelse((animelem = 57), -9, ifelse((animelem = 58), -4, ifelse((animelem = 59), -22, -7)))
y = ifelse((animelem = 57), -5, ifelse((animelem = 58), -3, ifelse((animelem = 59), -11, -7)))

[State 1131, pos61 -64]
type = posadd
trigger1 = anim = 1101 && (animelem = 61 || animelem = 62 || animelem = 63 || animelem = 64)
x = ifelse((animelem = 61), -5, ifelse((animelem = 62), -3, ifelse((animelem = 63), -4, -3)))
y = ifelse((animelem = 61), -5, ifelse((animelem = 62), -4, ifelse((animelem = 63), -5, -4)))

[State 1131, pos65]
type = posadd
trigger1 = anim = 1101 && animelem = 65
y = -4

[State 1131, snd]
type = playsnd
trigger1 = animelem = 9 || animelem = 42
value = 5, 14

[State 1131, velvar]
type = varset
trigger1 = anim = 1101
var(0) = animelemtime(1)

[State 1131, swingthvar]
type = varadd
trigger1 = anim = 1101 && !animtime
var(42) = 1

[State 1131, Anim]
type = changeanim
triggerall = anim = 1101
trigger1 = !animtime && var(42) >= 2
trigger2 = !AIlevel && (command = "a" || command = "b" || command = "c")
trigger3 = AIlevel && numhelper(1105)
trigger3 = helper(1135), movehit = 2 && random < 350
trigger4 = animelemtime(34) < 0 && frontedgedist <= -100
trigger5 = animelemtime(34) >= 0 && backedgedist <= -50
value = 1102

[State 1131, Ctrl]
type = ctrlset
trigger1 = anim = 1102
value = 1

[State 1131, Vel]
type = velset
trigger1 = anim = 1102 && animelem = 1
x = ifelse(var(0) > 46, -3, 3)
y = ifelse(var(0) < 22, 2, ifelse(var(0) < 46, -4, ifelse(var(0) < 63, 2, -4)))

[State 1131, statetype]
type = statetypeset
trigger1 = anim = 1102
statetype = A
physics = A

[State Idle]
type = statetypeset
trigger1 = anim = 1102
movetype = I

;=====================<HENKYOU KI>==========================
[StateDef 1200]
type = U
movetype = A
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = (statetype != A)

[State 1200, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1200, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1200, statetype]
type = statetypeset
trigger1 = !time && statetype != A
statetype = S
physics = S

[State 1200, statetype]
type = statetypeset
trigger1 = !time && statetype = A
statetype = A
physics = N

[State 1200, Anim]
type = changeanim
trigger1 = !time
value = ifelse((statetype != A), 1200, 1201)

[State 1200, width]
type = width
trigger1 = animelemtime(5) = 0
value = 20, 0

[State 1200, Dust]
type = explod
trigger1 = (anim = 1201) && animelem = 2
anim = 8104
ID = 8104
sprpriority = 2
postype = p1
pos = -15, -13
removetime = -2
scale = 0.5, 0.5
ownpal = 1
pausemovetime = -1
supermovetime = -1

[State 1200, Dust]
type = explod
trigger1 = (anim = 1201) && animelem = 2
anim = 8104
ID = 8104
sprpriority = 2
postype = p1
pos = 68, -13
removetime = -2
scale = 0.5, 0.5
ownpal = 1
pausemovetime = -1
supermovetime = -1

[State 1200, Snd]
type = playsnd
trigger1 = animelem = 5
value = 4, 2
channel = 0

[State 1200, Snd]
type = playsnd
trigger1 = animelem = 5
value = 5, 2

[State 1200, Shake]
type = envshake
trigger1 = animelem = 5
time = 8
fre = 60
ampl = 4

[State 1200, soundwave]
type = helper
trigger1 = animelemtime(5) = 1
helpertype = normal
stateno = 1205
ID = 1205
name = "Soundwave"
postype = p1
pos = 67, ifelse((anim = 1200), -41, -56)
ownpal = 1
size.xscale = 0.5
size.yscale = 0.5

[State 1200, Dust]
type = explod
trigger1 = anim = 1200 && animelemtime(5) = 1
trigger2 = anim = 1201 && animelemtime(5) = 1 && pos y >= -25
anim = 8102
ID = 8102
sprpriority = -2
postype = p1
pos = 63, 0
removetime = -2
ownpal = 1
scale = 0.75, 0.75
pausemovetime = -1
supermovetime = -1

[State 1200, statetype]
type = statetypeset
trigger1 = anim = 1201 && animelemtime(23) >= 0
physics = A

[State 1200, End]
type = changestate
trigger1 = anim = 1200 && !animtime
value = 0
ctrl = 1

;========================<EX HENKYOU KI>=============================
[StateDef 1230]
type = U
movetype = A
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = (statetype != A)

[State 1230, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1230, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1230, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1230, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1230, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1230, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1230, statetype]
type = statetypeset
trigger1 = !time && statetype != A
statetype = S
physics = S

[State 1230, statetype]
type = statetypeset
trigger1 = !time && statetype = A
statetype = A
physics = N

[State 1230, Anim]
type = changeanim
trigger1 = !time
value = ifelse((statetype != A), 1200, 1201)

[State 1230, width]
type = width
trigger1 = animelemtime(5) = 0
value = 20, 0

[State 1230, dust]
type = explod
trigger1 = (anim = 1201) && animelem = 2
anim = 8104
ID = 8104
sprpriority = 2
postype = p1
pos = -15, -13
removetime = -2
scale = 0.5, 0.5
ownpal = 1
pausemovetime = -1
supermovetime = -1

[State 1230, dust]
type = explod
trigger1 = (anim = 1201) && animelem = 2
anim = 8104
ID = 8104
sprpriority = 2
postype = p1
pos = 68, -13
removetime = -2
scale = 0.5, 0.5
ownpal = 1
pausemovetime = -1
supermovetime = -1

[State 1230, snd]
type = playsnd
trigger1 = animelem = 5
value = 810, 0
channel = 0

[State 1230, snd]
type = playsnd
trigger1 = animelem = 5
value = 5, 12

[State 1230, Shake]
type = envshake
trigger1 = animelem = 5
time = 12
freq = 60
ampl = 6

[State 1230, soundwave]
type = helper
trigger1 = animelemtime(5) = 1
helpertype = normal
stateno = 1235
ID = 1235
name = "Soundwave"
postype = p1
pos = 67, ifelse((anim = 1200), -41, -56)
ownpal = 1
size.xscale = 0.5
size.yscale = 0.5

[State 1230, dust]
type = explod
trigger1 = anim = 1200 && animelemtime(5) = 1
trigger2 = anim = 1201 && animelemtime(5) = 1 && pos y >= -25
anim = 8102
ID = 8102
sprpriority = -2
postype = p1
pos = 63, 0
removetime = -2
ownpal = 1
scale = 1, 1
pausemovetime = -1
supermovetime = -1

[State 1230, statetype]
type = statetypeset
trigger1 = anim = 1201 && animelemtime(23) >= 0
physics = A

[State 1230, End]
type = changestate
trigger1 = anim = 1200 && !animtime
value = 0
ctrl = 1

;=====================<HOUTEN GEKI>==========================
[StateDef 1300]
type = S
physics = S
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1300, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1300, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1300, Do not guard]
type = attackdist
trigger1 = 1
value = 0

[State 1300, Hit]
type = hitdef
trigger1 = !time
trigger1 = !var(38)
trigger1 = p2dist x >= 0 && p2bodydist x <= 32
attr = S, ST
hitflag = M-
priority = 7, Miss
sparkNo = -1 +0 * (var(33) := 0)
guard.sparkNo = -1 +0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 40), var(36) := -50
hitSound = -1 +0 * (var(31) := 800)
guardSound = -1 +0 * (var(32) := 0)
p1facing = 1
p2facing = 1
p1stateno = 1305
guard.dist = 0
fall = 1

[State 1300, misssnd]
type = playsnd
trigger1 = animelem = 4
value = 5000, 1
channel = 0

[State Idle]
type = statetypeset
trigger1 = animelemtime(4) >= 0
movetype = I

[State 1300, End]
type = changestate
trigger1 = !animtime
value = 0
ctrl = 1

;--- PLAYER ---
[Statedef 1305]
type = S
movetype = A
physics = S
anim = 1305
poweradd = 0
ctrl = 0

[State 1305, throw]
type = targetstate
trigger1 = !time
value = 1306

[State 1305, throwsnd]
type = playsnd
trigger1 = animelem = 3
value = 1000, 0
channel = 0

[State 1305, throwsnd]
type = playsnd
trigger1 = animelem = 2
value = 1, 5
channel = 1

[State 1305, Bind 1]
type = targetbind
trigger1 = animelemtime(1) >= 0 && animelemtime(2) < 0
pos = 65, 0

[State 1305, Bind 2]
type = targetbind
trigger1 = animelemtime(2) >= 0 && animelemtime(3) < 0
pos = 48, -103

[State 1305, Bind 3]
type = targetbind
trigger1 = animelem = 3
pos = -8, -140

[State 1305, hurt]
type = targetlifeadd
trigger1 = animelem = 3
value = -40
Kill = 0

[State 1305, throw]
type = targetstate
trigger1 = animelem = 3
value = 1307

[State 1305, End]
type = changestate
trigger1 = !animtime
value = 1310

;--- SPINNING ---
[Statedef 1310]
type = C
movetype = A
physics = C
anim = 1310
ctrl = 0

[State 1310, throw]
type = targetstate
trigger1 = numtarget && target, vel y > 0
trigger1 = target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
value = 1311

[State 1310, throw]
type = targetstate
trigger1 = numtarget && target, time && target, vel y > 0
trigger1 = target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
value = 1312

[State 1310, Bind 1]
type = targetbind
trigger1 = numtarget
trigger1 = target, stateno = 1312
pos = 3, -(target, const(size.air.front) + 38)

[State 1310, spin]
type = playsnd
trigger1 = animelemtime(3) >= 0 && !(time % 9)
value = 1, 9
channel = 1
ignorehitpause = 1

[State 1310, spin]
type = playsnd
trigger1 = animelem = 3
value = 5, 16

[State 1310, claws]
type = explod
trigger1 = animelem = 3
anim = 1301
ID = 1300
sprpriority = 2
postype = p1
bindtime = -1
removetime = -1
removeongethit = 1

[State 1310, claws]
type = explod
trigger1 = animelem = 3
anim = 1302
ID = 1300
sprpriority = 0
postype = p1
bindtime = -1
removetime = -1
removeongethit = 1

[State 1310, hurt]
type = targetlifeadd
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
value = -16

[State 1310, hurt]
type = targetpoweradd
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
value = 10

[State 1310, Hit]
type = hitadd
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
value = 1

[State 1310, HitSound]
type = playsnd
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
value = 2, 9

[State 1310, HitSpark]
type = Helper
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8016)
ID = 8000
name = "Spark"
postype = p2
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1310, End]
type = targetstate
trigger1 = hitcount >= 7 || !numtarget || time >= 180
value = 1316

[State 1310, End]
type = changestate
trigger1 = hitcount >= 7 || !numtarget || time >= 180
value = 1315

;--- END ---
[Statedef 1315]
type = S
movetype = I
physics = S
anim = 1315
ctrl = 0

[State 1315, End]
type = changestate
trigger1 = !animtime
value = 0
ctrl = 1

;--- TARGET ---
[Statedef 1306]
type = A
movetype = H
physics = N
velset = 0, 0
sprpriority = 0

[State 1306, Anim]
type = changeanim2
trigger1 = !time
value = 1306

[State 1306, Camera]
type = screenbound
trigger1 = 1
value = 1
movecamera = 0, 0

;Player 2
[Statedef 1307]
type = A
movetype = H
physics = N
velset = 0, -10
sprpriority = 2

[State 1307, Accel]
type = gravity
trigger1 = 1

[State 1307, fix]
type = posadd
trigger1 = animelem = 3
y = -const(size.mid.pos.y)

[State 1307, Turn]
type = turn
trigger1 = animelem = 3
persistent = 0

[State 1307, Anim]
type = changeanim2
trigger1 = animelemtime(3) > 0 && vel y >= 2
value = 1306
elem = 7
persistent = 0

[State 1307, hitground]
type = selfstate
trigger1 = vel y > 0
trigger1 = pos y >= 0
value = 5100

;Player 2
[Statedef 1311]
type = A
movetype = H
physics = N
velset = 0, -6
sprpriority = 0

[State 1311, fix]
type = posadd
trigger1 = !time
y = ceil(const(size.mid.pos.y) / 2)

[State 1311, Accel]
type = gravity
trigger1 = 1

[State 1311, Anim]
type = changeanim2
trigger1 = !time
value = 1311

[State 1311, Camera]
type = screenbound
trigger1 = 1
value = 1
movecamera = 0, 0

;Player 2
[Statedef 1312]
type = A
movetype = H
physics = N
velset = 0, 0
sprpriority = 0

[State 1312, Anim]
type = changeanim2
trigger1 = !time
value = 1312

[State 1312, Camera]
type = screenbound
trigger1 = 1
value = 1
movecamera = 0, 0

;Player 2
[Statedef 1316]
type = A
movetype = H
physics = N
velset = -4.5, -4.5

[State 1316, Accel]
type = gravity
trigger1 = 1

[State 1316, Anim]
type = changeanim
trigger1 = !time
value = ifelse(selfanimexist(5052), 5052, 5030)

[State 1316, hitground]
type = selfstate
trigger1 = vel y > 0
trigger1 = pos y >= 0
value = 5100

;=====================<EX HOUTEN GEKI>==========================
[StateDef 1330]
type = S
physics = S
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1330, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1330, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1330, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1330, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1330, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1330, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1330, Do not guard]
type = attackdist
trigger1 = 1
value = 0

[State 1330, Hit]
type = hitdef
trigger1 = !time
trigger1 = !var(38)
trigger1 = p2dist x >= 0 && p2bodydist x <= 32
attr = S, ST
hitflag = M-
priority = 7, Miss
sparkNo = -1 +0 * (var(33) := 0)
guard.sparkNo = -1 +0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 40), var(36) := -50
hitSound = -1 +0 * (var(31) := 800)
guardSound = -1 +0 * (var(32) := 0)
p1facing = 1
p2facing = 1
p1stateno = 1335
guard.dist = 0
getPower = 0
givePower = 36, 36
fall = 1

[State 1330, misssnd]
type = playsnd
trigger1 = animelem = 4
value = 5000, 1
channel = 0

[State Idle]
type = statetypeset
trigger1 = animelemtime(4) >= 0
movetype = I

[State 1330, End]
type = changestate
trigger1 = !animtime
value = 0
ctrl = 1

;--- PLAYER ---
[Statedef 1335]
type = S
movetype = A
physics = S
anim = 1305
poweradd = 0
ctrl = 0

[State 1335, throw]
type = targetstate
trigger1 = !time
value = 1306

[State 1335, throwsnd]
type = playsnd
trigger1 = animelem = 3
value = 1000, 0
channel = 0

[State 1335, throwsnd]
type = playsnd
trigger1 = animelem = 2
value = 1, 5
channel = 1

[State 1335, Bind 1]
type = targetbind
trigger1 = animelemtime(1) >= 0 && animelemtime(2) < 0
pos = 65, 0

[State 1335, Bind 2]
type = targetbind
trigger1 = animelemtime(2) >= 0 && animelemtime(3) < 0
pos = 48, -103

[State 1335, Bind 3]
type = targetbind
trigger1 = animelem = 3
pos = -8, -140

[State 1335, hurt]
type = targetlifeadd
trigger1 = animelem = 3
value = -40
Kill = 0

[State 1335, throw]
type = targetstate
trigger1 = animelem = 3
value = 1307

[State 1335, End]
type = changestate
trigger1 = !animtime
value = 1340

;--- SPINNING ---
[Statedef 1340]
type = C
movetype = A
physics = C
anim = 1310
ctrl = 0

[State 1340, throw]
type = targetstate
trigger1 = numtarget && target, vel y > 0
trigger1 = target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
value = 1311

[State 1340, throw]
type = targetstate
trigger1 = numtarget && target, time && target, vel y > 0
trigger1 = target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
value = 1312

[State 1340, Bind 1]
type = targetbind
trigger1 = numtarget
trigger1 = target, stateno = 1312
pos = 3, -(target, const(size.air.front) + 38)

[State 1340, spin]
type = playsnd
trigger1 = animelemtime(3) >= 0 && !(time % 9)
value = 1, 9
channel = 1
ignorehitpause = 1

[State 1340, spin]
type = playsnd
trigger1 = animelem = 3
value = 5, 16

[State 1340, claws]
type = explod
trigger1 = animelem = 3
anim = 1301
ID = 1300
sprpriority = 2
postype = p1
bindtime = -1
removetime = -1
removeongethit = 1

[State 1340, claws]
type = explod
trigger1 = animelem = 3
anim = 1302
ID = 1300
sprpriority = 0
postype = p1
bindtime = -1
removetime = -1
removeongethit = 1

[State 1340, hurt]
type = targetlifeadd
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
value = -16

[State 1340, hurt]
type = targetpoweradd
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
value = 0

[State 1340, Hit]
type = hitadd
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
value = 1

[State 1340, HitSound]
type = playsnd
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
value = 2, 9

[State 1340, HitSpark]
type = Helper
triggerall = animelemtime(3) >= 0 && numtarget
trigger1 = target, vel y > 0 && target, stateno = 1307 && target, pos y >= -(target, const(size.air.front) + 38)
trigger2 = target, vel y > 0 && target, stateno = 1311 && target, pos y >= -(target, const(size.air.front) + 38)
trigger3 = target, stateno = 1312 && !(time % 6)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8016)
ID = 8000
name = "Spark"
postype = p2
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1340, End]
type = targetstate
trigger1 = hitcount >= 9 || !numtarget || time >= 180
value = 1316

[State 1340, End]
type = changestate
trigger1 = hitcount >= 9 || !numtarget || time >= 180
value = 1315

;=====================<ZANPA>==========================
[StateDef 1400]
type = A
movetype = A
physics = N
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1400, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1400, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1400, Push]
type = playerpush
trigger1 = anim != 1401 || vel y < 0
value = 0
ignorehitpause = 1

[State 1400, Vel]
type = velset
trigger1 = numenemy
trigger1 = anim = 1400 && animelem = 2
x = (p2dist x / 34.0)
y = -7.5

[State 1400, Vel]
type = turn
trigger1 = anim = 1400 && vel x < 0
persistent = 0

[State 1400, Vel]
type = velset
trigger1 = anim = 1400 && vel x > 10
x = 10

[State 1400, Accel]
type = gravity
trigger1 = anim = 1400 && animelemtime(2) >= 0

[State 1400, Vel]
type = velmul
trigger1 = anim = 1400 && vel y > 0
y = 1.1

[State 1400, Snd]
type = playsnd
trigger1 = anim = 1400 && animelem = 4
value = 4, 4
channel = 0

[State 1400, claws]
type = explod
trigger1 = anim = 1400 && animelem = 10
anim = 1405
ID = 1405
sprpriority = 2
postype = p1
bindtime = -1
removetime = 300
removeongethit = 1

[State 1400, claws]
type = explod
trigger1 = anim = 1400 && animelem = 10
anim = 1406
ID = 1405
sprpriority = 0
postype = p1
bindtime = -1
removetime = 300
removeongethit = 1

[State 1400, spin]
type = playsnd
trigger1 = anim = 1400 && animelemtime(10) >= 0 && !(gametime % 9)
value = 1, 9
channel = 1
ignorehitpause = 1

[State 1400, Hit]
type = hitdef
trigger1 = anim = 1400 && !(time % 6)
attr = A, SA
damage = ceil(ifElse(fvar(11) * 10 < 7, 7, fvar(11) * 10)), 7
animtype = Hard
guardflag = HA
hitflag = FD
priority = 4, Hit
pausetime = 0, 0
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 170), var(36) := -25
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -10
ground.cornerpush.veloff = 0
air.type = Low
air.velocity = -4, -4
down.velocity = 0, 0
down.hittime = 30
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
fall = (p2statetype = L)
fall.recover = 1
fall.recovertime = 120
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envshake.time = 14
envshake.freq = 120
envshake.ampl = 3
ID = 1400
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
airguard.cornerpush.veloff = 0
forcestand = 1

[State 1400, Pos]
type = posset
trigger1 = anim = 1400 && vel y > 0 && pos y >= 0 && movehit && numtarget(1400)
trigger1 = target(1400), statetype = L
x = ceil(target(1400), pos x) - 16 * facing
y = 0
ignorehitpause = 1

[State 1400, Vel]
type = velset
trigger1 = anim = 1400 && vel y > 0 && pos y >= 0 && movehit && numtarget(1400)
trigger1 = target(1400), statetype = L
x = 0
y = 0
ignorehitpause = 1

[State 1400, Anim]
type = changeanim
trigger1 = anim = 1400 && movehit && hitcount >= 6
value = 1401

[State 1400, Vel]
type = velset
trigger1 = anim = 1401
x = -5
y = -5
persistent = 0

[State 1400, Type]
type = statetypeset
trigger1 = anim = 1401
statetype = A
physics = A
movetype = I

[State 1400, removepouncefx]
type = removeexplod
trigger1 = vel y > 0 && pos y >= 10
ID = 1405

[State 1400, End]
type = changestate
trigger1 = vel y > 0 && pos y >= 10
value = 52

;=====================<EX ZANPA>==========================
[StateDef 1430]
type = A
movetype = A
physics = N
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1430, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1430, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1430, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1430, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1430, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1430, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1430, Push]
type = playerpush
trigger1 = anim != 1401 || vel y < 0
value = 0
ignorehitpause = 1

[State 1430, Vel]
type = velset
trigger1 = numenemy
trigger1 = anim = 1400 && animelem = 2
x = (p2dist x / 34.0)
y = -7.5

[State 1430, Vel]
type = turn
trigger1 = anim = 1400 && vel x < 0
persistent = 0

[State 1430, Vel]
type = velset
trigger1 = anim = 1400 && vel x > 10
x = 10

[State 1430, Accel]
type = gravity
trigger1 = anim = 1400 && animelemtime(2) >= 0

[State 1430, Vel]
type = velmul
trigger1 = anim = 1400 && vel y > 0
y = 1.1

[State 1430, snd]
type = playsnd
trigger1 = anim = 1400 && animelem = 4
value = 4, 4
channel = 0

[State 1430, claws]
type = explod
trigger1 = anim = 1400 && animelem = 10
anim = 1405
ID = 1405
sprpriority = 2
postype = p1
bindtime = -1
removetime = 300
removeongethit = 1

[State 1430, claws]
type = explod
trigger1 = anim = 1400 && animelem = 10
anim = 1406
ID = 1405
sprpriority = 0
postype = p1
bindtime = -1
removetime = 300
removeongethit = 1

[State 1430, spin]
type = playsnd
trigger1 = anim = 1400 && animelemtime(10) >= 0 && !(gametime % 9)
value = 1, 9
channel = 1
ignorehitpause = 1

[State 1430, hit]
type = hitdef
trigger1 = anim = 1400 && !(time % 6)
attr = A, SA
damage = ceil(ifElse(fvar(11) * 14 < 7, 7, fvar(11) * 14)), 7
animtype = Hard
guardflag = HA
hitflag = FD
priority = 4, Hit
pausetime = 0, 0
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 170), var(36) := -25
ground.type = High
ground.slidetime = 16
ground.hittime = 16
ground.velocity = -10
ground.cornerpush.veloff = 0
air.type = Low
air.velocity = -4, -4
down.velocity = 0, 0
down.hittime = 30
getpower = 0
givepower = 36, 36
fall = (p2statetype = L)
fall.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envshake.time = 14
envshake.freq = 60
envshake.ampl = 3
ID = 1430
yaccel = 0.5
airguard.ctrltime = 16
airguard.velocity = -8, -1.5
forcestand = 1

[State 1430, Pos]
type = posset
trigger1 = anim = 1400 && vel y > 0 && pos y >= 0 && movehit && numtarget(1430)
trigger1 = target(1430), statetype = L
x = ceil(target(1430), pos x) - 16 * facing
y = 0
ignorehitpause = 1

[State 1430, Vel]
type = velset
trigger1 = anim = 1400 && vel y > 0 && pos y >= 0 && movehit && numtarget(1430)
trigger1 = target(1430), statetype = L
x = 0
y = 0
ignorehitpause = 1

[State 1430, Anim]
type = changeanim
trigger1 = anim = 1400 && movehit && hitcount >= 12
value = 1401

[State 1430, Vel]
type = velset
trigger1 = anim = 1401
x = -5
y = -5
persistent = 0

[State 1430, sts]
type = statetypeset
trigger1 = anim = 1401
statetype = A
physics = A
movetype = I

[State 1430, removepouncefx]
type = removeexplod
trigger1 = anim = 1400 && vel y > 0 && pos y >= 0
ID = 1405

[State 1430, End]
type = changestate
trigger1 = vel y > 0 && pos y >= 10
value = 52

;========================<PUNCH ZERO COUNTER>=============================
[StateDef 2900]
type = S
physics = N
moveType = A
anim = 2900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2900, width]
type = width
trigger1 = animelemtime(3) >= 0 && animelemtime(12) < 0
player = 35, 0
ignorehitpause = 1

[State 2900, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2900, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 2900, Woosh]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,9
channel = 1

[State 2900, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = animelem = 3 || animelem = 6 || animelem = 9
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 0
getpower = 0,0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 185), var(36) := -27
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2900, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(11) >= 0
movetype = I

[State 2900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<KICK ZERO COUNTER>=============================
[StateDef 2910]
type = S
physics = N
moveType = A
anim = 2910
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2910, width]
type = width
trigger1 = animelemtime(2) >= 0 && animelemtime(13) < 0
player = 30, 0
ignorehitpause = 1

[State 2910, Type]
type = statetypeset
trigger1 = animelemtime(13) >= 0
physics = C

[State 2910, Vel]
type = velset
trigger1 = animelemtime(2) >= 0 && animelemtime(13) < 0
x = 3

[State 2910, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2910, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, 4
channel = 0

[State 2910, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,9
channel = 1

[State 2910, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = Time = 0
attr = C, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 9)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 186), var(36) := -22
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2910, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(13) >= 0
moveType = I

[State 2910, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
