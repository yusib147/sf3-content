; ________________________________________________
;| Hsien-Ko by Phantom.of.the.Server & varo_hades |
; ������������������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<CHUUKADAN>=============================
[StateDef 3000]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(20 * const(size.xScale)), ceil(-50 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 40
moveTime = 40
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Strength]
type = varset
trigger1 = !time
var(10) = 5

[State 3000, bomb]
type = helper
trigger1 = animelem = 6
helpertype = normal
stateno = 3004
ID = 3005
name = "Bomb"
postype = p1
pos = 88, -90
ownpal = 1

[State 3000, snd]
type = playsnd
trigger1 = animelem = 5
value = 3000, 0
channel = 0

[State 3000, spinsnd]
type = playsnd
trigger1 = animelem = 5
value = 1, 5
channel = 1

[State 3000, End]
type = changestate
trigger1 = !animtime
value = 0
ctrl = 1

;--- < DETONATE > ---
[Statedef 3002]
type = S
movetype = I
physics = S
anim = 3002
velset = 0, 0
ctrl = 0

[State 3002, snd]
type = playsnd
trigger1 = animelem = 3
value = 5000, 0
channel = 0

[State 3002, snd]
type = playsnd
trigger1 = animelem = 3 && numhelper(3005)
trigger1 = (helper(3005), rootdist x != [ -155, 155])
value = 4, 0
channel = 0

[State 3002, End]
type = changestate
trigger1 = !animtime
value = 0
ctrl = 1

;========================<MAX CHUUKADAN>=============================
[StateDef 3050]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3050, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(20 * const(size.xScale)), ceil(-50 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3050, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 40
moveTime = 40
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3050, Strength]
type = varset
trigger1 = !time
var(10) = 5

[State 3050, bomb]
type = helper
trigger1 = animelem = 6
helpertype = normal
stateno = 3004
ID = 3005
name = "Bomb"
postype = p1
pos = 88, -90
ownpal = 1

[State 3050, bomb]
type = helper
trigger1 = animelem = 6
helpertype = normal
stateno = 3004
ID = 3005
name = "Bomb"
postype = p1
pos = 88, -50
ownpal = 1

[State 3050, snd]
type = playsnd
trigger1 = animelem = 5
value = 3000, 0
channel = 0

[State 3050, spinsnd]
type = playsnd
trigger1 = animelem = 5
value = 1, 5
channel = 1

[State 3050, End]
type = changestate
trigger1 = !animtime
value = 0
ctrl = 1

;========================<CHIREITOU>=============================
[StateDef 3100]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-5 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 40
moveTime = 40
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, Strength]
type = varset
trigger1 = var(10) != 6
var(10) = 6

[State 3100, snd]
type = playsnd
trigger1 = anim = 3100 && animelem = 4
value = 3100, 0
channel = 0
volume = 200

[State 3100, bound]
type = screenbound
trigger1 = anim = 3100 && animelemtime(6) >= 0 && backedgedist < 50 && numhelper(3105)
trigger1 = helper(3105), var(3)
value = 0

[State 3100, snd]
type = playsnd
trigger1 = anim = 3100 && animelem = 5
value = 3100, 1
channel = 0

[State 3100, snd]
type = playsnd
trigger1 = anim = 3100 && animelem = 5
value = 1, 2
channel = 1

[State 3100, Blade]
type = helper
trigger1 = anim = 3100 && animelem = 6
helpertype = normal
stateno = 3105
ID = 3105
name = "Blade"
postype = p1
pos = 25, 0
ownpal = 1
size.shadowoffset = -3

[State 3100, NHB]
type = nothitby
trigger1 = anim = 3100 && animelemtime(6) < 0
time = 1
value = SCA

[State 3100, Offscreen]
type = changestate
trigger1 = anim = 3100 && animelemtime(6) > 0 && backedgedist <= -25
trigger1 = !numhelper(3105) || time >= 240
value = 115

[State 3100, End]
type = changeanim
trigger1 = anim = 3100 && animelemtime(6) > 0 && backedgedist > -25
trigger1 = !numhelper(3105) || time >= 240
value = 3101
persistent = 0

[State 3100, End]
type = changestate
trigger1 = anim = 3101 && !animtime
value = 0
ctrl = 1

;========================<MAX CHIREITOU>=============================
[StateDef 3150]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3150, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3150, Super Pause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-5 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3150, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 40
moveTime = 40
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3150, Strength]
type = varset
trigger1 = var(10) != 6
var(10) = 6

[State 3150, snd]
type = playsnd
trigger1 = anim = 3100 && animelem = 4
value = 3100, 0
channel = 0
volume = 200

[State 3150, bound]
type = screenbound
trigger1 = anim = 3100 && animelemtime(6) >= 0 && backedgedist < 50 && numhelper(3155)
trigger1 = helper(3155), var(3)
value = 0

[State 3150, snd]
type = playsnd
trigger1 = anim = 3100 && animelem = 5
value = 3100, 1
channel = 0

[State 3150, snd]
type = playsnd
trigger1 = anim = 3100 && animelem = 5
value = 1, 2
channel = 1

[State 3150, Blade]
type = helper
trigger1 = anim = 3100 && animelem = 6
helpertype = normal
stateno = 3155
ID = 3155
name = "Blade"
postype = p1
pos = 25, 0
ownpal = 1
size.shadowoffset = -3

[State 3150, NHB]
type = nothitby
trigger1 = anim = 3100 && animelemtime(6) < 0
time = 1
value = SCA

[State 3150, Offscreen]
type = changestate
trigger1 = anim = 3100 && animelemtime(6) > 0 && backedgedist <= -25
trigger1 = !numhelper(3155) || time >= 240
value = 115

[State 3150, End]
type = changeanim
trigger1 = anim = 3100 && animelemtime(6) > 0 && backedgedist > -25
trigger1 = !numhelper(3155) || time >= 240
value = 3101
persistent = 0

[State 3150, End]
type = changestate
trigger1 = anim = 3101 && !animtime
value = 0
ctrl = 1

;========================<TENRAI HA>=============================
[StateDef 3200]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3200, Super Pause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(0 * const(size.xScale)), ceil(-55 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = Time = 3
time = 40
moveTime = 40
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, Strength]
type = varset
trigger1 = var(10) != 6
var(10) = 7

[State 3200, snd]
type = playsnd
trigger1 = animelem = 3
value = 3200, 0
channel = 0
volume = 200

[State 3200, width]
type = width
trigger1 = animelemtime(2) >= 0 && animelemtime(17) < 0
player = 20, 0

[State 3200, shockwave]
type = helper
trigger1 = animelem = 9
helpertype = normal
stateno = 3205
ID = 3205
name = "Shockwave"
postype = p1
pos = 106, 0
size.xscale = 1
size.yscale = 1

[State 3200, dust]
type = helper
trigger1 = animelem = 9
helpertype = normal
stateno = 3206
ID = 3206
name = "Red Dust"
postype = p1
pos = 106, 0
size.xscale = 2
ownpal = 1

[State 3200, snd]
type = playsnd
trigger1 = animelem = 9
value = 5, 3

[State 3400, Shake]
type = envshake
trigger1 = animelem = 9
time = 24
freq = 90
ampl = 12

[State 3200, hit]
type = hitdef
trigger1 = !movecontact && !movereversed
trigger1 = animelem = 5 || animelem = 6 || animelem = 7 || animelem = 8 || animelem = 9
attr = S, HA
damage = 146, 7
animtype = Hard
guardflag = H
hitflag = MAFD
priority = 4, Hit
pausetime = 4, 12
sparkno = -1 + 0 * (var(33) := 8014)
guard.sparkno = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := ifelse((animelem = 5), -90, ifelse((animelem = 6), -74, ifelse((animelem = 7), -54, ifelse((animelem = 8), -30, -13))))
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
ground.type = Low
ground.hittime = 16
ground.slidetime = 16
ground.velocity = 0, 0
air.type = Low
air.velocity = -2.5, -5
getpower = 0
givepower = 36, 36
envshake.time = 6
envshake.ampl = 5
air.fall = 1
fall.recover = 0
persistent = 0
yaccel = 0.5
forcestand = 1

[State 3200, End]
type = changestate
trigger1 = !animtime
value = 0
ctrl = 1

;========================<RIMOUKON>=============================
[StateDef 3300]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3300, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3300, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3300, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3300, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3300, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3300, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3300, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3300, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3300, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3300, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 40
moveTime = 40
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3300, snd]
type = playsnd
trigger1 = animelem = 1
value = 3100, 1

[State 3300, Custom Combo Time]
type = VarSet
trigger1 = Animelem = 4
var(45) = 300

[State 3300, linlin]
type = helper
trigger1 = time = 40
helpertype = normal
stateno = 6020
ID = 6000
name = "Lin -Lin"
postype = p1
pos = -1, -66

[State 3300, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<MAX RIMOUKON>=============================
[StateDef 3350]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3350, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3350, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3350, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3350, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3350, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3350, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3350, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3350, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3350, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3350, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 40
moveTime = 40
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3350, snd]
type = playsnd
trigger1 = animelem = 1
value = 3100, 1

[State 3350, Custom Combo Time]
type = VarSet
trigger1 = Animelem = 4
var(45) = 600

[State 3350, linlin]
type = helper
trigger1 = time = 40
helpertype = normal
stateno = 6020
ID = 6000
name = "Lin -Lin"
postype = p1
pos = -1, -66

[State 3350, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
