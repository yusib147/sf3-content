



[Command]
name = "pioggia"
command = ~D,DB,B,D,DB,B,a+b
time = 36

[Command]
name = "pioggia"
command = ~D,DB,B,D,DB,B,b+c
time = 36
[Command]
name = "pioggia"
command = ~D,DB,B,D,DB,B,a+c
time = 36

[Command]
name = "42136kk"
command = ~B,DB,D,DF,F,a+b
time = 22
[Command]
name = "42136kk"
command = ~B,DB,D,DF,F,a+c
time = 22
[Command]
name = "42136kk"
command = ~B,DB,D,DF,F,b+c
time = 22

[Command]
name = "42136kk"
command = ~B,D,F,a+b
time = 22
[Command]
name = "42136kk"
command = ~B,D,F,a+c
time = 22
[Command]
name = "42136kk"
command = ~B,D,F,b+c
time = 22


[Command]
name = "W236p"
command = ~D,DF,F,D,DF,F,x
time = 24
[Command]
name = "W236p"
command = ~D,DF,F,D,DF,F,~x
time = 24
[Command]
name = "W236p"
command = ~D,DF,F,D,DF,F,y
time = 24
[Command]
name = "W236p"
command = ~D,DF,F,D,DF,F,~y
time = 24
[Command]
name = "W236p"
command = ~D,DF,F,D,DF,F,z
time = 24
[Command]
name = "W236p"
command = ~D,DF,F,D,DF,F,~z
time = 24

[Command]
name = "W236p"
command = ~D,F,D,F,x
time = 24
[Command]
name = "W236p"
command = ~D,F,D,F,~x
time = 24
[Command]
name = "W236p"
command = ~D,F,D,F,y
time = 24
[Command]
name = "W236p"
command = ~D,F,D,F,~y
time = 24
[Command]
name = "W236p"
command = ~D,F,D,F,z
time = 24
[Command]
name = "W236p"
command = ~D,F,D,F,~z
time = 24


[Command]
name = "W214p"
command = ~D,DB,B,D,DB,B,x
time = 24
[Command]
name = "W214p"
command = ~D,DB,B,D,DB,B,~x
time = 24
[Command]
name = "W214p"
command = ~D,DB,B,D,DB,B,y
time = 24
[Command]
name = "W214p"
command = ~D,DB,B,D,DB,B,~y
time = 24
[Command]
name = "W214p"
command = ~D,DB,B,D,DB,B,z
time = 24
[Command]
name = "W214p"
command = ~D,DB,B,D,DB,B,~z
time = 24

[Command]
name = "W214p"
command = ~D,B,D,B,x
time = 24
[Command]
name = "W214p"
command = ~D,B,D,B,~x
time = 24
[Command]
name = "W214p"
command = ~D,B,D,B,y
time = 24
[Command]
name = "W214p"
command = ~D,B,D,B,~y
time = 24
[Command]
name = "W214p"
command = ~D,B,D,B,z
time = 24
[Command]
name = "W214p"
command = ~D,B,D,B,~z
time = 24


[Command]
name = "W236k"
command = ~D,DF,F,D,DF,F,a
time = 24
[Command]
name = "W236k"
command = ~D,DF,F,D,DF,F,~a
time = 24
[Command]
name = "W236k"
command = ~D,DF,F,D,DF,F,b
time = 24
[Command]
name = "W236k"
command = ~D,DF,F,D,DF,F,~b
time = 24
[Command]
name = "W236k"
command = ~D,DF,F,D,DF,F,c
time = 24
[Command]
name = "W236k"
command = ~D,DF,F,D,DF,F,~c
time = 24

[Command]
name = "W236k"
command = ~D,F,D,F,a
time = 24
[Command]
name = "W236k"
command = ~D,F,D,F,~a
time = 24
[Command]
name = "W236k"
command = ~D,F,D,F,b
time = 24
[Command]
name = "W236k"
command = ~D,F,D,F,~b
time = 24
[Command]
name = "W236k"
command = ~D,F,D,F,c
time = 24
[Command]
name = "W236k"
command = ~D,F,D,F,~c
time = 24

[Command]
name = "Ira=Spinta (WK)"
command = ~F, DF, B, a
time = 24

[Command]
name = "Ira=Spinta (WK)"
command = ~F, DF, B, ~a
time = 24

[Command]
name = "Ira=Spinta (MK)"
command = ~F, DF, B, b
time = 24

[Command]
name = "Ira=Spinta (MK)"
command = ~F, DF, B, ~b
time = 24

[Command]
name = "Ira=Spinta (HK)"
command = ~F, DF, B, c
time = 24

[Command]
name = "Ira=Spinta (HK)"
command = ~F, DF, B, ~c
time = 24


[Command]
name = "22pp"
command = ~D,D,x+y
time = 20
[Command]
name = "22pp"
command = ~D,D,x+z
time = 20
[Command]
name = "22pp"
command = ~D,D,y+z
time = 20





[Command]
name = "63214k"
command = ~F,D,B,a
time = 18
[Command]
name = "63214k"
command = ~F,D,B,~a
time = 18
[Command]
name = "63214k"
command = ~F,D,B,b
time = 18
[Command]
name = "63214k"
command = ~F,D,B,~b
time = 18
[Command]
name = "63214k"
command = ~F,D,B,c
time = 18
[Command]
name = "63214k"
command = ~F,D,B,~c
time = 18


[Command]
name = "623pp"
command = ~F,D,DF,x+y
time = 14
[Command]
name = "623pp"
command = ~F,D,DF,x+z
time = 14
[Command]
name = "623pp"
command = ~F,D,DF,y+z
time = 14


[Command]
name = "623x"
command = ~F,D,DF,x
time = 14
[Command]
name = "623x"
command = ~F,D,DF,~x
time = 14

[Command]
name = "623y"
command = ~F,D,DF,y
time = 14
[Command]
name = "623y"
command = ~F,D,DF,~y
time = 14

[Command]
name = "623z"
command = ~F,D,DF,z
time = 14
[Command]
name = "623z"
command = ~F,D,DF,~z
time = 14


[Command]
name = "623a"
command = ~F,D,DF,a
time = 14
[Command]
name = "623a"
command = ~F,D,DF,~a
time = 14

[Command]
name = "623b"
command = ~F,D,DF,b
time = 14
[Command]
name = "623b"
command = ~F,D,DF,~b
time = 14

[Command]
name = "623c"
command = ~F,D,DF,c
time = 14
[Command]
name = "623c"
command = ~F,D,DF,~c
time = 14


[Command]
name = "236pp"
command = ~D,DF,F,x+y
time = 14
[Command]
name = "236pp"
command = ~D,DF,F,x+z
time = 14
[Command]
name = "236pp"
command = ~D,DF,F,y+z
time = 14

[Command]
name = "236x"
command = ~D,DF,F,x
time = 14
[Command]
name = "236x"
command = ~D,DF,F,~x
time = 14

[Command]
name = "236y"
command = ~D,DF,F,y
time = 14
[Command]
name = "236y"
command = ~D,DF,F,~y
time = 14

[Command]
name = "236z"
command = ~D,DF,F,z
time = 14
[Command]
name = "236z"
command = ~D,DF,F,~z
time = 14


[Command]
name = "214pp"
command = ~D,DB,B,x+y
time = 14
[Command]
name = "214pp"
command = ~D,DB,B,x+z
time = 14
[Command]
name = "214pp"
command = ~D,DB,B,y+z
time = 14

[Command]
name = "214x"
command = ~D,DB,B,x
time = 14
[Command]
name = "214x"
command = ~D,DB,B,~x
time = 14

[Command]
name = "214y"
command = ~D,DB,B,y
time = 14
[Command]
name = "214y"
command = ~D,DB,B,~y
time = 14

[Command]
name = "214z"
command = ~D,DB,B,z
time = 14
[Command]
name = "214z"
command = ~D,DB,B,~z
time = 14

[Command]
name = "236s"
command = ~D,DF,F,s
time = 14
[Command]
name = "236s"
command = ~D,DF,F,~s
time = 14
[Command]
name = "214s"
command = ~D,DB,B,s
time = 14
[Command]
name = "214s"
command = ~D,DB,B,~s
time = 14



[Command]
name = "FF"
command = F,F
time = 10

[Command]
name = "BB"
command = B,B
time = 10

[Command]
name = "highjump"
command = D,$U
time = 14



[Command]
name = "recovery"
command = x+y
time = 1

[Command]
name = "recovery"
command = x+z
time = 1

[Command]
name = "recovery"
command = y+z
time = 1

[Command]
name = "recovery"
command = a+x
time = 1

[Command]
name = "a+x"
command = a+x
time=1



[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1




[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "fwd"
command = F
time = 1

[Command]
name = "back"
command = B
time = 1

[Command]
name = "up"
command = U
time = 1

[Command]
name = "down"
command = D
time = 1



[Command]
name = "rfwd"
command = ~$F
time = 1

[Command]
name = "rback"
command = ~$B
time = 1

[Command]
name = "rup"
command = ~$U
time = 1

[Command]
name = "rdown"
command = ~$D
time = 1




[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holds"
command = /s
time = 1




;   --- Uno Tag System [Type-R] Command definition ---

[Command]
name = "aHsoNn"
command = ~D, D, D, z+c
Time = 25

[Command]
name = "sheoun"
command = ~D, DF, F, z+c
Time = 25

[Command]
name = "palit"
command = z+c
Time = 2

[Command]
name = "turtleuno"
command = s
Time = 2


[Statedef -1]


[State -1, Partner Assist]
type = VarSet
sysvar(4) = 10
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 60 && Time > 0
triggerall = teammode = Simul
triggerall = StateNo != [3000,1251199]
triggerall = hitdefattr != SCA, HA, HP, HT
triggerAll = StateNo != [130,152]
triggerall = !(StateNo = [5000,5500])
triggerall = Power >= 500
trigger1 = command = "turtleuno"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = !ctrl && Movetype = A
trigger2 = Random < (((2 * ifelse(MoveContact, ifelse(MoveHit, 2, 3),1)) + (UniqHitCount * 2)) *(AILevel**2/64.0))
trigger3 = AILevel >  0
trigger3 = StateNo = [190,199]
trigger3 = AnimElemNo(0) = 2
ignorehitpause = 1

[State -1, Team Hyper Attack]
type = ChangeState
value = 1251125
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = Partner, life > 0
triggerall = power >= 3000
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 9		
triggerall= (StateType != A)
trigger1 = command = "sheoun"
trigger1 = (Ctrl = 1)
trigger1 = AILevel <=  0
trigger2 = command = "sheoun"
trigger2 = Anim = [200,1000]
trigger2 = movetype = A
trigger2 = hitdefattr = SC, NA
trigger2 = MoveContact
trigger2 = AILevel <=  0
trigger3 = AILevel > 0 && ctrl
trigger3 = Random < (10 + ((Life < Lifemax/6)*3))
trigger3 = NumEnemy && enemy, pos x = [0,200]
trigger4 = AILevel >  0
trigger4 = Anim = [200,1000]
trigger4 = movetype = A
trigger4 = hitdefattr = SC, NA
trigger4 = MoveContact
trigger4 = Random < (11 + ((MoveHit)*5) + ((Life < Lifemax/6)*5))
ignorehitpause = 1

[State -1, Delayed Hyper]
type = ChangeState
value = 1251127
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0
triggerall = power >= 1000
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time > 1 && Time > 45
triggerall = movetype = A
triggerall = StateNo = [2000,1251100]
triggerall = hitdefattr = SCA, HA, HP, HT || (StateNo >= 2000 && StateNo < 4000 && (hitcount < 8 || NumTarget && Target, GetHitVar(hitTime) >= 0))
trigger1 = command = "sheoun"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = NumTarget && MoveContact
trigger2 = Random < (10*(AILevel**2/64.0) + (Uniqhitcount*((Life < Partner,Life)*2)))
trigger2 = Partner, Time > 35
trigger3 = AILevel >  0
trigger3 = Partner, Time > 30 && Time > 25
trigger3 = HitCount >= 6
trigger3 = Random < (2 * Uniqhitcount * ifelse(hitcount > 9, 2, 1))
ignorehitpause = 1

[State -1, UNO Mode]
type = ChangeState
value = 1251128
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0 && Power >= 1000
triggerall = Life <= (Lifemax/8)
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 20
triggerall = (StateType != A) && ((Ctrl = 1) || StateNo = 0 || (Movetype = A && hitdefattr = SC, NA))
trigger1 = command = "aHsoNn"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Partner, Life < Lifemax/4
trigger2 = Random < ((25 + ifelse((Partner, Life < Lifemax/6), 25, 5))*(AILevel**2/64.0))

[State -1, Change Attack]
type = ChangeState
value = 1251126
triggerall = NumPartner
triggerall = (sysvar(4) = 1 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),250,500)) || (sysvar(4) = 15 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),500,1000))
triggerall = Partner, life > 0
triggerall = movetype = A && !MoveReversed
triggerall = (Partner, StateNo = 1251112 || Partner, StateNo = 1251114)  && Time > 1
triggerall = StateNo = [200,4850]
triggerall = StateNo != [1251102,1251105]
triggerall = NumTarget > 0 && Target, pos Y > -160
triggerall = (Target, StateNo != [5110,5955])
triggerall = Hitdefattr != SCA, NT && ((Target, Statetype = A || (Hitdefattr != A, NA && Target, Statetype != A)) && ((!Target, HitOver || EnemyNear, StateNo = [5000,5900]) && (MoveContact || ProjContactTime(0) < 8)))
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = UniqHitCount >= 2
trigger2 = Random < (((ifelse(sysvar(4)=15,25,50)*(AILevel**2/64.0)) + ((hitdefattr = SCA, SA, HA)*15) + ifelse(lifemax/life > 15, 15, lifemax/life)))
trigger2 = Partner, Life > Lifemax/10 || Life <= Partner, Life
trigger2 = Partner, Time > 25
trigger3 = AILevel >  0
trigger3 = Partner, Time > 27
trigger3 = Random < (25*(2*(Life = (Lifemax/4) && Life < Partner, Life)) *(AILevel**2/64.0))
trigger3 = MoveContact
ignorehitpause = 1

[State -1, TagIn]
type = ChangeState
value = 1251110
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner && NumEnemy
triggerall = RoundState = 2 
triggerall = Partner, life > 0
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 40	
triggerall = (MoveType != A && StateType != A) && (Ctrl = 1) || StateNo = 0
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Random < (ifelse((LifeMax/Life > 120), 120, LifeMax/Life)+((EnemyNear,statetype=L)*25))
trigger2 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond
trigger2 = EnemyNear, movetype != A
trigger3 = AILevel >  0
trigger3 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond && Life < LifeMax * (LifeMax*0.55)
trigger3 = Random < ((ifelse(LifeMax/Life > 10, 10, LifeMax/Life) + (10+ifelse((EnemyNear, StateNo > 5000),25,1))) * ifelse((Life < Partner, Life), 1.45, 0.5))
trigger3 = Partner, Time > 1 * TicksPerSecond
trigger3= EnemyNear, statetype = L || p2bodydist x > 250 && EnemyNear, movetype != A
trigger4 = AILevel >  0
trigger4 = Life < 150 && Life < Partner, Life
trigger4 = EnemyNear, statetype = L || p2bodydist x > 200 && EnemyNear, movetype != A
trigger4 = Random < (125*(AILevel**2/64.0))

[State -1, C_6]
type = CtrlSet
value = 1
triggerall = RoundState = 2 && NumPartner
triggerall = NumTarget && Target, StateNo != [200,4999]
triggerall = StateNo != 1251106 && !Ctrl
triggerall = (Partner, StateNo != [1251128,1251129]) && (Partner, PrevStateNo != [1251128,1251129])
trigger1 = command="x"||command="y"||command="z"||command="a"||command="b"||command="c"
trigger1 = sysvar(4) = 7
trigger1 = Movetype = A
trigger1 = MoveContact
trigger1 = hitdefattr = SCA, NA, SA
trigger1 = StateNo != PrevStateNo
trigger1 = Time > 3
trigger2 = PrevStateNo = 1251106
ignorehitpause = 0

; ------ Uno Tag System [Type-R] END LINE -------

;  ;]





[state 0]
type=selfstate
trigger1=ctrl && numpartner && !ishelper && roundstate=2 && pos y=0
trigger1=sysfvar(4)>0 && sysfvar(0)>0 && playeridexist(floor(sysfvar(0)))
trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(22)=4
value=190190
ctrl=0
ignorehitpause=1










[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "up"
trigger1 = !ctrl
var(1) = 90
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "FF"
trigger1 = !ctrl
var(1) = 10
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "x"
trigger1 = !ctrl
var(1) = 100+50*(command="holddown" && statetype!=A)
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "y"
trigger1 = !ctrl
var(1) = 200+50*(command="holddown" && statetype!=A)
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "z"
trigger1 = !ctrl
var(1) = 300+50*(command="holddown" && statetype!=A)
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "a"
trigger1 = !ctrl
var(1) = 400+50*(command="holddown" && statetype!=A)
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "b"
trigger1 = !ctrl
var(1) = 500+50*(command="holddown" && statetype!=A)
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "c"
trigger1 = !ctrl
var(1) = 600+50*(command="holddown" && statetype!=A)
ignorehitpause = 1

[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "236x" || command = "236y" || command = "236z"
trigger1 = !ctrl
var(1) = 1000+ifelse(command="236x",0, ifelse(command="236y",1,2))
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "623x" || command = "623y" || command = "623z"
trigger1 = !ctrl
var(1) = 1200+ifelse(command="623x",0, ifelse(command="623y",1,2))
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "214x" || command = "214y" || command = "214z"
trigger1 = !ctrl
var(1) = 1300+ifelse(command="214x",0, ifelse(command="214y",1,2))
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "63214k"
trigger1 = !ctrl
var(1) = 1400
ignorehitpause = 1

[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "236pp"
trigger1 = !ctrl
var(1) = 1050
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "623pp"
trigger1 = !ctrl
var(1) = 1250
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "214pp"
trigger1 = !ctrl
var(1) = 1350
ignorehitpause = 1

[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "W236p"
trigger1 = !ctrl
var(1) = 3000
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "W214p"
trigger1 = !ctrl
var(1) = 3200
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "W236k"
trigger1 = !ctrl
var(1) = 3300
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "22pp"
trigger1 = !ctrl
var(1) = 3500
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "42136kk"
trigger1 = !ctrl
var(1) = 3400
ignorehitpause = 1
[state -1, var]
type = VarSet
triggerall = roundstate = 2
triggerall = command = "pioggia"
trigger1 = !ctrl
var(1) = 3600
ignorehitpause = 1


[state -1, var]
type = VarSet
trigger1 = time = 1
trigger1 = var(55) <= 0
var(1) = -1
ignorehitpause = 1

[state -1, var]
type = VarAdd
trigger1 = var(55)
var(55) = -1
[state -1, var]
type = VarSet
trigger1 = var(1) != -1
trigger1 = var(55) < 0
var(55) = ifelse(var(1)>3000,6, ifelse(var(1)>1000,5,2))
ignorehitpause = 1
[state -1, var]
type = VarSet
trigger1 = var(1) = -1
var(55) = -1
ignorehitpause = 1







[State -1, cardinale=pioggia]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 3000
triggerall = command = "pioggia" || (var(1)=3600 && var(55))
triggerall = !numhelper(3605)
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = stateno=[200,499]
value = 3600

[State -1, prova=di=servo]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 2000
triggerall = command = "42136kk" || (var(1)=3400 && var(55))
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 3400

[State -1, finale=rosso]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 2000
triggerall = command = "22pp" || (var(1)=3500 && var(55))
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 3500

[State -1, gigante=dio=saga]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 1000
triggerall = command = "W236p" || (var(1)=3000 && var(55))
triggerall = !var(11)
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 3000

[State -1, gigante=dio=saga(air)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = power >= 1000
triggerall = command = "W236p" || (var(1)=3000 && var(55))
triggerall = pos y <= -40
triggerall = !var(11)
trigger1 = ctrl || ((stateno=[600,699])&&var(0)&&var(20))
trigger2 = ((stateno=[600,699]) || stateno=110) && time<2
trigger3 = (stateno=600 || stateno=610 || stateno=630 || stateno=640) && var(0)
value = 3100

[State -1, dite=falce]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 1000
triggerall = command = "W214p" || (var(1)=3200 && var(55))
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 3200

[State -1, ira=ventata]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = power >= 1000
triggerall = command = "W236k" || (var(1)=3300 && var(55))
triggerall = pos y <= -20
trigger1 = ctrl || ((stateno=[600,699])&&var(0)&&var(20))
trigger2 = ((stateno=[600,699]) || stateno=110) && time<2
trigger3 = (stateno=600 || stateno=610 || stateno=630 || stateno=640) && var(0)
value = 3300





[State -1, ex spregio]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 500
triggerall = command = "623pp" || (var(1)=1250 && var(55))
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 1250

[State -1, ex dio=saga]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 500
triggerall = command = "236pp" || (var(1)=1050 && var(55))
triggerall = !var(11)
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 1050

[State -1, ex dio=saga(air)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = power >= 500
triggerall = command = "236pp" || (var(1)=1050 && var(55))
triggerall = !var(11)
triggerall = pos y <= -65
trigger1 = ctrl || ((stateno=[600,699])&&var(0)&&var(20))
trigger2 = ((stateno=[600,699]) || stateno=110) && time<2
trigger3 = (stateno=600 || stateno=610 || stateno=630 || stateno=640) && var(0)
value = 1150

[State -1, ex nero=fatica]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 500
triggerall = command = "214pp" || (var(1)=1350 && var(55))
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 1350



[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1500
triggerall = roundstate = 2
triggerall = command = "Ira=Spinta (WK)"
trigger1 = statetype = A && ctrl

[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1501
triggerall = roundstate = 2
triggerall = command = "Ira=Spinta (MK)"
trigger1 = statetype = A && ctrl

[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1502
triggerall = roundstate = 2
triggerall = command = "Ira=Spinta (HK)"
trigger1 = statetype = A && ctrl

[State -1, sangue=passare]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "63214k" || (var(1)=1400 && var(55))
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=230 || stateno=400 || stateno=430) && var(0)
value = 1400

[State -1, spregio]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "623x" || command = "623y" || command = "623z" || ((var(1)=[1200,1202]) && var(55))
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 1200

[State -1, dio=saga]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "236x" || command = "236y" || command = "236z" || ((var(1)=[1000,1002]) && var(55))
triggerall = !var(11)
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 1000

[State -1, dio=saga(air)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = ((command="236x"||(var(1)=1000&&var(55)))&&pos y<=-50) || ((command="236y"||(var(1)=1001&&var(55)))&&pos y<=-35) || ((command="236z"||(var(1)=1002&&var(55)))&&pos y<=-20)
triggerall = !var(11)
trigger1 = ctrl || ((stateno=[600,699])&&var(0)&&var(20))
trigger2 = ((stateno=[600,699]) || stateno=110) && time<2
trigger3 = (stateno=600 || stateno=610 || stateno=630 || stateno=640) && var(0)
value = 1100

[State -1, nero=fatica]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "214x" || command = "214y" || command = "214z" || ((var(1)=[1300,1302]) && var(55))
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20)) || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
trigger3 = (stateno=200 || stateno=210 || stateno=230 || stateno=240 || stateno=400 || stateno=410 || stateno=430 || stateno=440) && var(0)
value = 1300





[State -1, Original Combo]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "z" && command = "c"
triggerall = power >= 1000
triggerall = !var(20)
trigger1 = ctrl || stateno=40 || stateno=52 || stateno=100
trigger2 = (stateno=[200,499]) && time<2
value = 4100
[State -1, Original Combo]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "z" && command = "c"
triggerall = power >= 1000
triggerall = !var(20)
trigger1 = ctrl
trigger2 = ((stateno=[600,699]) || stateno=110) && time<2
value = 4150

[State -1, PowerCharge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "holdy" && command = "holdb"
triggerall = power < powermax
triggerall = stateno != [4000,4001]
trigger1 = ctrl
value = 4000

[State -1, GC]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 500
triggerall = command = "623x" || command = "623y" || command = "623z" || ((var(1)=[1200,1202]) && var(55))
trigger1 = stateno = [150,153]
value = 700

[State -1,Run]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = [2,3]
triggerall = statetype = S
triggerall = command = "FF"
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20))
value = 100

[State -1, Back Run]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = [2,3]
triggerall = statetype = S
triggerall = command = "BB"
trigger1 = ctrl || ((stateno=[200,499])&&var(0)&&var(20))
value = 105

[State -1, balzo=perdono]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = [2,3]
triggerall = statetype = A
triggerall = command = "FF" || (var(1)=10 && var(55))
triggerall = !var(8) || var(20)
trigger1 = ctrl || ((stateno=[600,699])&&var(0)&&var(20))
trigger2 = (stateno=[600,699]) && time<2
value = 110

[State -1, karma=elegante]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "up" || (var(1)=90 && var(55))
triggerall = !var(5)
triggerall = !var(8)
triggerall = var(9) = [0,1]
triggerall = stateno != 900 || (stateno=900 && var(10))
triggerall = vel y >= -1 && pos y <= -26
trigger1 = ctrl
trigger2 = (stateno=[600,699]) && time<2
value = 900+var(9)

[State -1, Roll Forward]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 710
triggerAll = !AILevel
triggerAll = command = "a+x"
triggerAll = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdfwd"
trigger2 = var(20) && var(4)

[State -1, Roll Backward]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 715
triggerAll = !AILevel
triggerAll = command = "a+x"
triggerAll = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdback"

[State -1, Dodge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 701
triggerAll = !AILevel
triggerAll = command = "a+x"
triggerAll = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))





[State -1,  Throw]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = command = "x" && command = "y"
trigger1 = ctrl
value = 800

[State -1,  Air Throw]
type = null
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = (p2bodydist x = [-2,24]) && (p2bodydist y = [-17,17])
triggerall = enemynear,statetype = A && enemynear,movetype != H
triggerall = command = "holdfwd" || command = "holdback"
triggerall = command = "y" || command = "b"
trigger1 = ctrl
value = 850

[State -1, SLP]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="x" && command!="holddown") || (var(1)=100 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 200 && (var(0) || animelemtime(4)>=0)
trigger4 = stateno = 230 && var(0)
trigger5 = stateno = 400 && var(0)
trigger6 = stateno = 430 && var(0)
value = 200


[State -1, SMP]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="y" && command!="holddown") || (var(1)=200 && var(55))

trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 200 && var(0)
trigger4 = stateno = 230 && var(0)
trigger5 = stateno = 400 && var(0)
trigger6 = stateno = 430 && var(0)
value = 210

[State -1, SHP]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="z" && command!="holddown") || (var(1)=300 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 210 && var(0)
trigger4 = stateno = 240 && var(0)
trigger5 = stateno = 410 && var(0)
trigger6 = stateno = 440 && var(0)
value = 220

[State -1, SLK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="a" && command!="holddown") || (var(1)=400 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 230 && movecontact
trigger5 = stateno = 400 && movecontact
trigger6 = stateno = 430 && movecontact
value = 230

[State -1, SMK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="b" && command!="holddown") || (var(1)=500 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 230 && movecontact
trigger6 = stateno = 400 && movecontact
trigger7 = stateno = 410 && movecontact
trigger8 = stateno = 430 && movecontact
value = 240

[State -1, SHK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="c" && command!="holddown") || (var(1)=600 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 210 && movecontact
trigger4 = stateno = 220 && movecontact
trigger5 = stateno = 240 && movecontact
trigger6 = stateno = 410 && movecontact
trigger7 = stateno = 420 && movecontact
trigger8 = stateno = 440 && movecontact
value = 250


[State -1, CLP]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="x" && command="holddown") || (var(1)=150 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 230 && movecontact
trigger5 = stateno = 400 && movecontact
trigger6 = stateno = 430 && movecontact
value = 400

[State -1, CMP]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="y" && command="holddown") || (var(1)=250 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 230&& movecontact
trigger6 = stateno = 400 && movecontact
trigger7 = stateno = 430 && movecontact
value = 410

[State -1, CHP]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="z" && command="holddown") || (var(1)=350 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 210 && movecontact
trigger4 = stateno = 220 && movecontact
trigger5 = stateno = 240 && movecontact
trigger6 = stateno = 410 && movecontact
trigger7 = stateno = 440 && movecontact
value = 420

[State -1, CLK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="a" && command="holddown") || (var(1)=450 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 230 && movecontact
trigger5 = stateno = 400 && movecontact
trigger6 = stateno = 430 && movecontact
value = 430

[State -1, CMK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="b" && command="holddown") || (var(1)=550 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 230 && movecontact
trigger6 = stateno = 240 && movecontact
trigger7 = stateno = 400 && movecontact
trigger8 = stateno = 410 && movecontact
trigger9 = stateno = 430 && movecontact
value = 440

[State -1, CHK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = (command="c" && command="holddown") || (var(1)=650 && var(55))
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = stateno = 210 && movecontact
trigger4 = stateno = 220 && movecontact
trigger5 = stateno = 240 && movecontact
trigger6 = stateno = 250 && movecontact
trigger7 = stateno = 410 && movecontact
trigger8 = stateno = 420 && movecontact
trigger9 = stateno = 440 && movecontact
value = 450


[State -1, ALP]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command="x" || (var(1)=100 && var(55))
trigger1 = ctrl
trigger2=var(4)
trigger3= stateno = 630 && movecontact && prevstateno != [600,699]
value = 600

[State -1, AMP]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "y" || (var(1)=200 && var(55))
trigger1 = ctrl
trigger2=var(4)
trigger3 = stateno = 600 && movecontact
trigger4 = stateno = 630 && movecontact
value = 610

[State -1, AHP]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "z" || (var(1)=300 && var(55))
trigger1 = ctrl
trigger2=var(4)
trigger3 = stateno = 600 && movecontact
trigger4 = stateno = 610 && movecontact
trigger5 = stateno = 630 && movecontact
value = 620

[State -1, ALK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "a" || (var(1)=400 && var(55))
trigger1 = ctrl
trigger2=var(4)
trigger3= stateno = 600 && movecontact && prevstateno != [600,699]
value = 630

[State -1, AMK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "b" || (var(1)=500 && var(55))
trigger1 = ctrl
trigger2=var(4)
trigger3 = stateno = 600 && movecontact
trigger4 = stateno = 630 && movecontact
value = 640

[State -1, AHK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = command = "c" || (var(1)=600 && var(55))
trigger1 = ctrl
trigger2=var(4)
trigger3 = stateno = 600 && movecontact
trigger4 = stateno = 630 && movecontact
trigger5 = stateno = 640 && movecontact
value = 650


[State -1, ����]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = roundstate = [2,3]
triggerall = statetype != A
triggerall = command = "start" || command = "236s" || command = "214s"
trigger1 = ctrl
value = 195




