;-| Button Remapping |-----------------------------------------------------
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s
 
;-| Default Values |-------------------------------------------------------
[Defaults]
; Default value for the "time" parameter of a Command. Minimum 1.
command.time = 15
; Default value for the "buffer.time" parameter of a Command. Minimum 1,
; maximum 30.
command.buffer.time = 1
 
;-| Super Motions |--------------------------------------------------------
[Command]
name = "SGS"
command = x, x, F, a
time = 32;24
;buffer.time = 10

[Command]
name = "RSGS"
command = x, x, B, a
time = 32
;buffer.time = 10

[Command]
name = "SGS"
command = x, x, F+a
time = 32
;buffer.time = 10

[Command]
name = "RSGS"
command = x, x, B+a
time = 32
;buffer.time = 10

[Command]
name = "SGS2"
command = x, x, F
time = 24
;buffer.time = 10

[Command]
name = "RSGS2"
command = x, x, B
time = 24
;buffer.time = 10

[Command]
name = "QCFx2"
command = ~D, DF, F, D, DF
time = 21

[Command]
name = "QCBx2"
command = ~D, DB, B, D, DB
time = 21
;-| Special Motions |--------------------------------------------------------
[command];easier HCB/F
name = "HCB"
command = ~F, DF, $D, B
time = 24

[command]
name = "HCF"
command = ~B, DB, $D, F
time = 24

[Command]
name = "DP"
command = ~F, D, DF
time = 16

[Command]
name = "RDP"
command = ~B, D, DB
time = 16

[Command]
name = "QCB"
command = ~D, DB, B
time = 15

[Command]
name = "QCF"
command = ~D, DF, F
time = 15

[Command]
name = "QCBD"
command = ~B, DB, D
time = 15

[Command]
name = "QCFD"
command = ~F, DF, D
time = 15

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10
 
;-| Dir + Button |---------------------------------------------------------
[Command]
name = "back_x"
command = /$B,x
time = 1

[Command]
name = "back_y"
command = /$B,y
time = 1

[Command]
name = "back_z"
command = /$B,z
time = 1

[Command]
name = "down_x"
command = /$D,x
time = 1

[Command]
name = "down_y"
command = /$D,y
time = 1

[Command]
name = "down_z"
command = /$D,z
time = 1

[Command]
name = "fwd_x"
command = /$F,x
time = 1

[Command]
name = "fwd_y"
command = /$F,y
time = 1

[Command]
name = "fwd_z"
command = /$F,z
time = 1

[Command]
name = "up_x"
command = /$U,x
time = 1

[Command]
name = "up_y"
command = /$U,y
time = 1

[Command]
name = "up_z"
command = /$U,z
time = 1

[Command]
name = "back_a"
command = /$B,a
time = 1

[Command]
name = "back_b"
command = /$B,b
time = 1

[Command]
name = "back_c"
command = /$B,c
time = 1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

[Command]
name = "down_c"
command = /$D,c
time = 1

[Command]
name = "fwd_a"
command = /$F,a
time = 1

[Command]
name = "fwd_b"
command = /$F,b
time = 1

[Command]
name = "fwd_c"
command = /$F,c
time = 1

[Command]
name = "up_a"
command = /$U,a
time = 1

[Command]
name = "up_b"
command = /$U,b
time = 1

[Command]
name = "up_c"
command = /$U,c
time = 1
 
;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1
buffer.time = 1
 
[Command]
name = "b"
command = b
time = 1
buffer.time = 1
 
[Command]
name = "c"
command = c
time = 1
buffer.time = 1
 
[Command]
name = "x"
command = x
time = 1
buffer.time = 1
 
[Command]
name = "y"
command = y
time = 1
buffer.time = 1
 
[Command]
name = "z"
command = z
time = 1
buffer.time = 1
 
[Command]
name = "start"
command = s
time = 1
buffer.time = 1
 
;-| Single Dir |------------------------------------------------------------
[Command]
name = "fwd" ;Required (do not remove)
command = $F
time = 1

[Command]
name = "downfwd"
command = $DF
time = 1

[Command]
name = "down" ;Required (do not remove)
command = $D
time = 1

[Command]
name = "downback"
command = $DB
time = 1

[Command]
name = "back" ;Required (do not remove)
command = $B
time = 1

[Command]
name = "upback"
command = $UB
time = 1

[Command]
name = "up" ;Required (do not remove)
command = $U
time = 1

[Command]
name = "upfwd"
command = $UF
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holdfwd" ;Required (do not remove)
command = /$F
time = 1

[Command]
name = "holddownfwd"
command = /$DF
time = 1

[Command]
name = "holddown" ;Required (do not remove)
command = /$D
time = 1

[Command]
name = "holddownback"
command = /$DB
time = 1

[Command]
name = "holdback" ;Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdupback"
command = /$UB
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holdupfwd"
command = /$UF
time = 1
 
;-| Hold Button |-----------------------------------------------------------
[Command]
name = "hold_a"
command = /a
time = 1
buffer.time = 1
 
[Command]
name = "hold_b"
command = /b
time = 1
buffer.time = 1
 
[Command]
name = "hold_c"
command = /c
time = 1
buffer.time = 1
 
[Command]
name = "hold_x"
command = /x
time = 1
buffer.time = 1
 
[Command]
name = "hold_y"
command = /y
time = 1
buffer.time = 1
 
[Command]
name = "hold_z"
command = /z
time = 1
buffer.time = 1
 
[Command]
name = "hold_start"
command = /s
time = 1
buffer.time = 1

;---------------------------------------------------------------------------
;Release Direction
[Command]
name = "rlsfwd"
command = ~$F
time = 1

[Command]
name = "rlsback"
command = ~$B
time = 1

[Command]
name = "rlsup"
command = ~$U
time = 1

[Command]
name = "rlsdown"
command = ~$D
time = 1

;--------------------------------------------------------------------------
;Release Button
[Command]
name = "rlsx"
command = ~x
time = 1
buffer.time = 1;Not sure if this is nessecary?

[Command]
name = "rlsy"
command = ~y
time = 1
buffer.time = 1

[Command]
name = "rlsz"
command = ~z
time = 1
buffer.time = 1

[Command]
name = "rlsa"
command = ~a
time = 1
buffer.time = 1

[Command]
name = "rlsb"
command = ~b
time = 1
buffer.time = 1

[Command]
name = "rlsc"
command = ~c
time = 1
buffer.time = 1

[Command]
name = "rlss"
command = ~s
time = 1
buffer.time = 1

;---------------------------------------------------------------------------
;Other
[Command]
name = "highjump"
command = $D, $U
time = 15

;---------------------------------------------------------------------------
;It is VERY important to note, that the placement of Changestates, 
;here are HEAVILY important with this buffering system! 
;Even more so than default! I'm adding this notation as a constant, 
;reminder. Don't forget DW to adjust as needed!

;Also ALWAYS and I mean ALWAYS add these two triggers:
;triggerall = !IsHelper(10371) 
;triggerall = numhelper(10371)
;To EVERY Changestate that uses the buffer. You know why!
;Also be sure to adjust the "Tick Fix" on a char by char basis.
[Statedef -1]

[State -1, Tick Fix]
type = CtrlSet
triggerall = RoundState = 2
triggerall = !ctrl
trigger1 = (StateNo = 52 || StateNo = 5120) && !AnimTime
trigger2 = (StateNo = [200,299]) && !AnimTime
trigger3 = (StateNo = [400,499]) && !AnimTime
trigger4 = (StateNo = [760,762]) && !AnimTime
trigger5 = StateNo = 810 && !AnimTime
trigger6 = (StateNo = 5001 || StateNo = 5011 || StateNo = 151 || StateNo = 153) && HitOver
trigger7 = (StateNo = [700,715]) && !AnimTime
value = 1

[State -1, CtrlSet For Helpers];special thanks to 20S
type = CtrlSet
trigger1 = IsHelper
value = 0

[State -1, Hit Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(13) = 1

[State -1, Juggle Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(15) = 1

[State -1, ProjContact];special thanks to 20S
type = VarSet
trigger1 = IsHelper
trigger1 = MoveContact = 1 && NumTarget
var(18) = 1

[State -1, Root ProjContact];special thanks to 20S
type = ParentVarSet
trigger1 = IsHelper
trigger1 = MoveContact = 1 && NumTarget
var(18) = 1

[State -2, Lilith's Hit Detection]
type = VarSet
trigger1 = IsHelper(3500)
trigger1 = MoveContact = 1 && var(30) < 0
var(30) = HitPauseTime
ignoreHitPause = 1

[State -2, Hit Sparks for Lilith]
type = Helper
triggerAll = IsHelper(3500)
triggerAll = MoveContact = 1 && var(30) = HitPauseTime
trigger1 = MoveHit = 1 && NumEnemy
trigger2 = MoveGuarded = 1 && NumEnemy
helperType = Normal
stateNo = ifElse(MoveGuarded,8001,8014)
ID = 8000
name = "Spark"
postype = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < var(35), ceil(P2Dist x), var(35))), var(36)
facing = -1
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State -2, Counter FX for Lilith]
type = Helper
trigger1 = NumHelper(3500) && MoveHit = 1 && var(30) = HitPauseTime
trigger1 = NumEnemy && var(9)
trigger1 = !(HitDefAttr = SCA, AT) && (EnemyNear, MoveReversed != 1)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < var(35), ceil(P2Dist x), var(35))), var(36)
facing = -1
ownPal = 1
pauseMoveTime = 255
superMoveTime = 255
ignoreHitPause = 1

[State -2, Hit Detection for Lilith]
type = VarSet
trigger1 = IsHelper
var(30) = -1

[State -2, Hit Detection for Lilith]
type = VarRangeSet
trigger1 = IsHelper
trigger1 = MoveType = I
trigger2 = MoveType = H && Time
first = 30
last = 36
value = -1
ignoreHitPause = 1

[State -1, Darkness Illusion]
type = ChangeState
value = 3400
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = helper(10371), var(42)
triggerall = (helper(10371), var(2)) || (helper(10371), var(9))
triggerall = RoundState = 2 
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = (StateNo=[200,251]) || (StateNo=[600,655])

[State -1, Darkness Illusion Alt]
type = ChangeState
value = 3400
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = helper(10371), var(43)
triggerall = (helper(10371), var(3)) && (helper(10371), var(2))
triggerall = RoundState = 2 
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = (StateNo=[200,251]) || (StateNo=[600,655])

[State -1, MAX Valkyrie Turn]
type = ChangeState
value = 3250
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(23)
triggerall = (helper(10371), var(3)) && (helper(10371), var(4)) || (helper(10371), var(4)) && (helper(10371), var(5)) || (helper(10371), var(3)) && (helper(10371), var(5))
triggerall = RoundState = 2
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6) || var(7)

[State -1, Finishing Shower]
type = ChangeState
value = 3300
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = helper(10371), var(41)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = PalNo>=7
triggerall = RoundState = 2
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6) || var(7)

[State -1, Silhouette Blade]
type = ChangeState
value = 3150
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(3)) && (helper(10371), var(4)) || (helper(10371), var(4)) && (helper(10371), var(5)) || (helper(10371), var(3)) && (helper(10371), var(5))
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6) || var(7)

[State -1, MAX Cardinal Blade(Normal)]
type = ChangeState
value = 3110
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(3)) && (helper(10371), var(4)) || (helper(10371), var(4)) && (helper(10371), var(5)) || (helper(10371), var(3)) && (helper(10371), var(5))
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6) || var(7)

[State -1, MAX Air Soul Phoenix]
type = ChangeState
value = 3060
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType = A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(6) || var(7)
trigger1 = NumHelper(3055) <= 0
trigger2 = NumHelper(3055) <= 1
trigger2 = Helper(3055),StateNo = [1014,1016]

[State -1, MAX Soul Phoenix]
type = ChangeState
value = 3050
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || var(7)
trigger1 = NumHelper(3055) <= 0
trigger2 = NumHelper(3055) <= 1
trigger2 = Helper(3055),StateNo = [1014,1016]

[State -1, Valkyrie Turn]
type = ChangeState
value = 3200
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(23)
triggerall = (helper(10371), var(3)) || (helper(10371), var(4)) || (helper(10371), var(5)) || (helper(10371), var(10)) || (helper(10371), var(11)) || (helper(10371), var(12))
triggerall = RoundState = 2
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6)

[State -1, Cardinal Blade]
type = ChangeState
value = 3100
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(3)) || (helper(10371), var(4)) || (helper(10371), var(5)) || (helper(10371), var(10)) || (helper(10371), var(11)) || (helper(10371), var(12))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6)

[State -1, Air Soul Phoenix]
type = ChangeState
value = 3020
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = RoundState = 2 && StateType = A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(6)
trigger1 = NumHelper(3010) <= 0
trigger2 = NumHelper(3010) <= 1
trigger2 = Helper(3010),StateNo = [1014,1016]

[State -1, Soul Phoenix]
type = ChangeState
value = 3000
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6)
trigger1 = NumHelper(3010) <= 0
trigger2 = NumHelper(3010) <= 1
trigger2 = Helper(3010),StateNo = [1014,1016]

[State -1, EX Vector Drain]
type = ChangeState
value = 1330
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = helper(10371), var(23)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(5)

[State -1, EX Shadow Blade]
type = ChangeState
value = 1230
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = helper(10371), var(22)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(5)

[State -1, Air EX Soul Fist]
type = ChangeState
value = 1130
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType = A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, EX Soul Fist]
type = ChangeState
value = 1030
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101]) || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Vector Drain]
type = ChangeState
value = 1300
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(23)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(5)

[State -1, Shadow Blade]
type = ChangeState
value = 1200
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(22)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(5)

[State -1, Air Soul Fist(Arrange)]
type = ChangeState
value = 1101
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType = A
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Air Soul Fist(Normal)]
type = ChangeState
value = 1100
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType = A
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Soul Fist(Arrange)]
type = ChangeState
value = 1001
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Soul Fist(Normal)]
type = ChangeState
value = 1000
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Alpha Counter(Kick)]
type = ChangeState
value = 750
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(20)
triggerall = (helper(10371), var(3)) || (helper(10371), var(4)) || (helper(10371), var(5)) || (helper(10371), var(10)) || (helper(10371), var(11)) || (helper(10371), var(12))
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1, Alpha Counter(Punch)]
type = ChangeState
value = 750
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(20)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1, Counter Movement]
type = ChangeState
value = 740
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(14);LP+LK detection
triggerall = (helper(10371),command = "holdfwd") || (helper(10371),command = "holdback")
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1, Throw(Kick)]
type = ChangeState
value = 800
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = (helper(10371), var(3) && helper(10371), var(4)) || (helper(10371), var(4) && helper(10371), var(5)) || (helper(10371), var(3) && helper(10371), var(5))
trigger1 = (helper(10371),command = "holdfwd")|| (helper(10371),command = "holdback")
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl

[State -1, Throw(Punch)]
type = ChangeState
value = 800
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = (helper(10371), var(0) && helper(10371), var(1)) || (helper(10371), var(1) && helper(10371), var(2)) || (helper(10371), var(0) && helper(10371), var(2))
trigger1 = (helper(10371),command = "holdfwd")|| (helper(10371),command = "holdback")
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl

[State -1, Air Throw]
type = ChangeState
value = 900
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = (helper(10371), var(0) && helper(10371), var(1)) || (helper(10371), var(1) && helper(10371), var(2)) || (helper(10371), var(0) && helper(10371), var(2))
trigger1 = (command = "holdfwd" || command = "holdback")
trigger1 = RoundState = 2 && StateType = A
trigger1 = ctrl && pos y <= -30
trigger1 = statetype != S

[State -1, Roll Forward]
type = ChangeState
value = 710
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(14) ;LP+LK detection
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdfwd"

[State -1, Roll Back]
type = ChangeState
value = 715
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(14) ;LP+LK detection
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdback"

[State -1, Power Charge]
type = ChangeState
value = 730
triggerall = !ailevel
trigger1 = command = "hold_b" && command = "hold_y"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (StateNo = [100,101])
;^I'm gonna have to adapt this to the buffering system(maybe?) 
;I think it's good... I'll keep this as a reminder still though

[State -1, MAX Mode]
type = ChangeState
value = 770
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(16) ;HP+HK detection
triggerall = RoundState = 2 && StateType != A
triggerall = var(20) <= 0 && Power >= 1000
trigger1 = ctrl || (Stateno = [100,101])

[State -1, Dodge]
type = ChangeState
value = 700
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(14) ;LP+LK detection
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))

[State -1, Shell Kick]
type = ChangeState
value = 655
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(5) ;HK buffer
triggerall = command = "holddown"
triggerall = Time >= 12
triggerall = var(3)!=[1,2]
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = RoundState = 2 && StateType = S
trigger1 = command = "FF"
trigger1 = ctrl

[State -1, Run Back]
type = ChangeState
value = 105
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;|Normal Commands|--------------------------------------------------------
[State -1, Stand Light Punch]
type = ChangeState
triggerall = !ailevel
value = 200 + (Abs(P2BodyDist X) <= 20) * 1
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(0) ; The buffered version of LP
triggerall = (helper(10371),command != "holddown")
;^Be sure to include the dir buffer check if needed DW!
triggerall = statetype != A
trigger1= ctrl
trigger2= (StateNo = 200 || StateNo = 201 || StateNo = 430) && Time >=5

[State -1, Stand Medium Punch]
type = ChangeState
triggerall = !ailevel
value = 210 + (Abs(P2BodyDist X) <= 24) * 1
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(1) ; The buffered version of MP
triggerall = (helper(10371),command != "holddown")  
triggerall = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,201]) || StateNo = 230) && (MoveContact=[1,4])
trigger3 = (StateNo=400 || StateNo=430) && (MoveContact=[1,4])

[State -1, Stand Strong Punch]
type = ChangeState
triggerall = !ailevel
value = 220 + (Abs(P2BodyDist X) <= 18) * 1
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(2) ; The buffered version of HP
triggerall = (helper(10371),command != "holddown") 
triggerall = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,211]) || (StateNo=[230,240])) && (MoveContact=[1,4])
trigger3 = ((StateNo=[400,410]) || (StateNo=[430,440])) && (MoveContact=[1,4])

[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(3) ; The buffered version of LK
triggerall = (helper(10371),command != "holddown")
triggerall = statetype != A
trigger1= ctrl
trigger2 = ((StateNo=[200,201]) || StateNo=400) && (MoveContact=[1,4])
trigger3 = ((StateNo=[200,201]) || StateNo=430) && Time>=5

[State -1, Stand Medium Kick]
type = ChangeState
value = 240
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(4) ; The buffered version of MK
triggerall = (helper(10371),command != "holddown")
triggerall = statetype != A
trigger1= ctrl
trigger2 = ((StateNo=[200,211]) || StateNo=230) && (MoveContact=[1,4])
trigger3 = ((StateNo=[400,410]) || StateNo=430) && (MoveContact=[1,4])

[State -1, Standing Strong Kick]
type = ChangeState
triggerall = !ailevel
value = 250 + (Abs(P2BodyDist X) <= 15) * 1
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(5) ; The buffered version of HK
triggerall = (helper(10371),command != "holddown")
triggerall = statetype != A
trigger1= ctrl
trigger2 = ((StateNo=[200,221]) || (StateNo=[230,240])) && (MoveContact=[1,4])
trigger3 = (StateNo=[400,440]) && (MoveContact=[1,4])

[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(0) ; The buffered version of LP
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2= ((StateNo=[200,201]) || StateNo=430) && Time >=5

[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(1) ; The buffered version of MP
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,201]) || StateNo=230 || StateNo=400 || StateNo=430) && (MoveContact=[1,4])

[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(2) ; The buffered version of HP
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,211]) || (StateNo=[230,240])) && (MoveContact=[1,4])
trigger3 = ((StateNo=[400,410]) || (StateNo=[430,440])) && (MoveContact=[1,4])

[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(3) ; The buffered version of LK
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,201]) || StateNo=400) && (MoveContact=[1,4])
trigger3 = ((StateNo=[200,201]) || StateNo=430) && Time>=5

[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(4) ; The buffered version of MK
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,211]) || StateNo=230) && (MoveContact=[1,4])
trigger3 = ((StateNo=[400,410]) || StateNo=430) && (MoveContact=[1,4])

[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(5) ; The buffered version of HK
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,221]) || (StateNo=[230,240])) && (MoveContact=[1,4])
trigger3 = (StateNo=[400,440]) && (MoveContact=[1,4])

[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(0) ; The buffered version of LP
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Med Punch]
type = ChangeState
value = 610
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(1) ; The buffered version of MP
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Punch]
type = ChangeState
value = 620
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(2) ; The buffered version of HP
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(3) ; The buffered version of LK
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Med Kick]
type = ChangeState
value = 640
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(4) ; The buffered version of MK
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerall = !ailevel
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(5) ; The buffered version of HK
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Taunt(Normal)]
type = ChangeState
value = 196
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(6) ; The buffered version of Start
triggerall = PalNo<=6
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl
trigger2 = var(5)

[State -1, Taunt(Arrange)]
type = ChangeState
value = 195
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerall = helper(10371), var(6) ; The buffered version of Start
triggerall = PalNo>=7
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl
trigger2 = var(5)






;----------------------------------------------------------------------------------Ai by Vorse Raider-------------------------------------------


;coming soon





[State -1, Stand Light Punch ai]
type = ChangeState
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,50]) && ((P2Dist y = [-90,0]) ||p2statetype != a) && P2StateType != L && P2StateType != C
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1= ctrl &&  Random < (250 * (AILevel ** 2 / 64.0))
trigger2= (StateNo = 200 || StateNo = 201 || StateNo = 430) && Time >=5 &&  Random < (70 * (AILevel ** 2 / 64.0))
value = 200 + (Abs(P2BodyDist X) <= 20) * 1






[State -1, Stand Medium Punch ai]
type = ChangeState
value = 210 + (Abs(P2BodyDist X) <= 24) * 1
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,110]) &&  ((P2Dist y = [-90,0]) ||p2statetype != a) && P2StateType != L && P2StateType != C
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,201]) || StateNo = 230) && (MoveContact=[1,4]) &&  Random < (250 * (AILevel ** 2 / 64.0))
trigger3 = (StateNo=400 || StateNo=430) && (MoveContact=[1,4])  &&  Random < (250 * (AILevel ** 2 / 64.0))




[State -1, Stand Strong Punch ai]
type = ChangeState
value = 220 + (Abs(P2BodyDist X) <= 18) * 1
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,100]) &&  ((P2Dist y = [-80,0]) ||p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (10 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,211]) || (StateNo=[230,240])) && (MoveContact=[3,4])&&  Random < (150 * (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[400,410]) || (StateNo=[430,440])) && (MoveContact=[3,4])&&  Random < (250 * (AILevel ** 2 / 64.0))



[State -1, Stand Light Kick ai]
type = ChangeState
value = 230
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,55]) &&  ((P2Dist y = [-30,0]) && p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (250 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,201]) || StateNo=400) && (MoveContact=[1,4]) &&  Random < (250* (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[200,201]) || StateNo=430) && Time>=5 &&  Random < (250*(AILevel ** 2 / 64.0))



[State -1, Stand Medium Kick]
type = ChangeState
value = 240
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,90]) &&  ((P2Dist y = [-60,-40]) || p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (10 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,211]) || StateNo=230) && (MoveContact=[1,4]) && Random < (150*(AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[400,410]) || StateNo=430) && (MoveContact=[1,4]) && Random < (350*(AILevel ** 2 / 64.0))





[State -1, Standing Strong Kick ai]
type = ChangeState
value = 250 + (Abs(P2BodyDist X) <= 15) * 1
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,115]) &&  ((P2Dist y = [-120,0]) || p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,221]) || (StateNo=[230,240])) && (MoveContact=[2,4]) && Random < (250*(AILevel ** 2 / 64.0))
trigger3 = (StateNo=[400,440]) && (MoveContact=[2,4]) && Random < (350*(AILevel ** 2 / 64.0))






[State -1, Crouching Light Punch ai]
type = ChangeState
value = 400
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,50]) &&  ((P2Dist y = [-40,0]) && p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (250 * (AILevel ** 2 / 64.0))
trigger2= ((StateNo=[200,201]) || StateNo=430) && Time >=5 && (150*ifelse(moveguarded && p2statetype= s,1,.5)* (AILevel ** 2 / 64.0))


[State -1, Crouching Medium Punch ai]
type = ChangeState
value = 410
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [40,80]) &&  ((P2Dist y = [-50,0]) && p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,201]) || StateNo=230 || StateNo=400 || StateNo=430) && (MoveContact=[1,4])&& (150*ifelse(moveguarded && p2statetype= s,1,.5)* (AILevel ** 2 / 64.0))



[State -1, Crouching Strong Punch ai]
type = ChangeState
value = 420
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,110]) &&  ((P2Dist y = [-30,0]) && p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,211]) || (StateNo=[230,240])) && (MoveContact=[2,4])&& (150* (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[400,410]) || (StateNo=[430,440])) && (MoveContact=[2,4])&& (250* (AILevel ** 2 / 64.0))



[State -1, Crouching Light Kick ai]
type = ChangeState
value = 430
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,50]) &&  ((P2Dist y = [-20,0]) && p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (75 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,201]) || StateNo=400) && (MoveContact=[1,4])&& (150* (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[200,201]) || StateNo=430) && Time>=5 && (80* (AILevel ** 2 / 64.0))



[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,80]) &&  ((P2Dist y = [-20,0]) && p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ctrl && Random < (60 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,211]) || StateNo=230) && (MoveContact=[1,4]) &&(75*  (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[400,410]) || StateNo=430) && (MoveContact=[1,4]) && (250* (AILevel ** 2 / 64.0))





[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,105]) &&  ((P2Dist y = [-20,0]) && p2statetype != a) && P2StateType != L 
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
trigger1 = ((StateNo=[200,221]) || (StateNo=[230,240])) && (MoveContact=[1 ,4])&&(100*  (AILevel ** 2 / 64.0))
trigger2 = (StateNo=[400,440]) && (MoveContact=[1,4])&& (250* (AILevel ** 2 / 64.0))








[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 60+vel x) &&  (P2Dist y = [0,40])
trigger1 = ctrl&& (150* (AILevel ** 2 / 64.0))




[State -1, Jump med Punch ai]
type = ChangeState
value = 610
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 60+vel x) &&  (P2Dist y = [0,40])
trigger1 = ctrl&& (150* (AILevel ** 2 / 64.0))


[State -1, Jump Heavy Punch ai]
type = ChangeState
value = 620
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 60+vel x) && (vel y < 2 && (P2Dist y = [0,40]) || (P2Dist y = [-20,20]) )
trigger1 = ctrl&& (175* (AILevel ** 2 / 64.0))



[State -1, Jump Light kick]
type = ChangeState
value = 630
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 60+vel x) &&  (P2Dist y = [-10,20])
trigger1 = ctrl&& (80* (AILevel ** 2 / 64.0))


[State -1, Jump med kick]
type = ChangeState
value = 640
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 70+vel x) && (vel y <= 0 ||  (P2Dist y = [0,50]) )
trigger1 = ctrl&& (220* (AILevel ** 2 / 64.0))


[State -1, Jump Heavy kick]
type = ChangeState
value = 650
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 70+vel x) &&  (P2Dist y = [0,30])
trigger1 = ctrl && (150* (AILevel ** 2 / 64.0))



[State -1, Zero Counter]
type = ChangeState
value = 750
triggerall = (helper(10371), var(3)) || (helper(10371), var(4)) || (helper(10371), var(5)) || (helper(10371), var(10)) || (helper(10371), var(11)) || (helper(10371), var(12))
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = helper(10371), var(20)
trigger1 = AILevel && NumEnemy
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power >= 1000 
trigger1 = Random < (25 * ifelse(Life < 0.75 * LifeMax, 2,1)* ifelse(Life < 0.50 * LifeMax, 2,1)* ifelse(Life < 0.25 * LifeMax, 2,1) * (AILevel ** 2 / 64.0))
trigger1 = (P2BodyDist x = [0,50]) && !var(20)



[State -1, Counter Movement]
type = ChangeState
value = 740
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
trigger1 = AILevel && NumEnemy
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power >= 1000 
trigger1 = Random < (50 * ifelse(Life < 0.75 * LifeMax, 2,1)* ifelse(Life < 0.50 * LifeMax, 2,1)* ifelse(Life < 0.25 * LifeMax, 2,1) * (AILevel ** 2 / 64.0))
trigger1 = !var(20)


[State -1, Throw]
type = ChangeState
value = 800
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [0,40]) 
trigger1 = ctrl && Random < (75 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl && (P2StateNo = [120,140]) && Random < (100 * (AILevel ** 2 / 64.0))





[State -1, Air Throw]
type = ChangeState
value = 900
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = (helper(10371), var(0) && helper(10371), var(1)) || (helper(10371), var(1) && helper(10371), var(2)) || (helper(10371), var(0) && helper(10371), var(2))
triggerAll = AILevel && NumEnemy
triggerAll = P2StateType = A 
triggerAll = (P2BodyDist x < 55+vel x) && (P2Dist y = [-40,0])
trigger1 = RoundState = 2 && StateType = A
trigger1 = ctrl && pos y <= -30 && Random < (350 * (AIlevel ** 2 / 64.0))



[State -1, Roll Forward]
type = ChangeState
value = 710
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Random < (50 * (AILevel ** 2 / 64.0))
trigger1 = (ctrl || (StateNo = [100,101])) 
trigger1 = (EnemyNear, MoveType = A) && !(EnemyNear, HitDefAttr = SCA, AT) && (P2BodyDist x = [60,125])






[State -1, Power Charge]
type = ChangeState
value = 730
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power < const(data.power) && !var(20)
trigger1 = ctrl && Power < const(data.power) && Power < PowerMax/2 && !var(20) && PrevStateNo != 5120
trigger1 = !InGuardDist && P2BodyDist x >= 160 && Random < (50 * (AILevel ** 2 / 64.0))






[State -1, MAX Mode]
type = ChangeState
value = 770
triggerall = RoundState = 2 && StateType != A
triggerall =  Power >= 1000 && var(20) <= 0
triggerall = AILevel && NumEnemy
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = RoundState = 2 && StateType != A && ctrl
triggerall = ctrl || (Stateno = [100,101])
trigger1 = EnemyNear, ctrl = 0
trigger1 = !InGuardDist && P2BodyDist x < 120 && Random < (150 * (AIlevel ** 2 / 64.0))
trigger2= P2movetype = h || P2StateType = L
trigger2 = ctrl && Random < (180  * (AILevel ** 2 / 64.0))&& RoundState = 2
trigger2 = power >= powermax/2




[State -1, Dodge]
type = ChangeState
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
value = 700
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Random < (50 * (AIlevel ** 2 / 64.0))
trigger1 = (ctrl || (StateNo = [100,101])) && var(20) <= 164 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && !(EnemyNear, HitDefAttr = SCA, AT) && (P2BodyDist x = [0,50])

[State -1, Dodge]
type = ChangeState
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
value = 700
triggerall = AIlevel && numenemy
triggerall = (facing=1 && (enemy,facing=-1)) || (facing=-1 && (enemy,facing=1))
triggerall = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (145 * (AILevel ** 2 / 64.0))
triggerall = roundstate=2  && statetype != A
trigger1 = enemynear,movetype=A && (p2bodydist x=[0,40])&&(p2bodydist y=[0,0])
trigger2 = ((enemynear,numproj) || (enemynear,numhelper)) && inguarddist && p2bodydist x<=60 
trigger3 = RoundState = 2 && InGuardDist
trigger3 = ctrl && (StateNo != [120, 155]) && !var(20)
trigger3 = !var(26) || P2BodyDist x >= 40
trigger3 = !(EnemyNear, HitDefAttr = SCA, AT) && (EnemyNear, Time < 120)
trigger3 = StateType != A || P2StateType = A
trigger3 = ifElse(StateType = A, ((var(3) != [1, 2]) || StateNo = 5210), 1)
trigger3 = Random <  (ifElse((P2StateNo = [200, 699]), 125, ifElse((P2StateNo = [1000,2999]), 333, 1000)) * (AILevel ** 2 / 64.0))





[State -1, Shell Kick]
type = ChangeState
value = 655
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371) ;Prevent debug flood.
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerall = vel y > 0
;triggerall = var(3)!=[1,2]
triggerAll = (P2BodyDist x < 70) &&  (P2Dist y = [0,200])
trigger1 = ctrl && (250* (AILevel ** 2 / 64.0))






[State -1, Dash Backward]
type = ChangeState
value = 105
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = S
triggerAll = ctrl && (StateNo != [100,106]) && var(20) <= 150 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && BackEdgeDist >= 80 && (P2BodyDist x = [60,100]) && (EnemyNear, vel x)
trigger1 = Random < (ifElse((EnemyNear, HitDefAttr = SC, AT), 150, 50) * (AILevel ** 2 / 64.0))
trigger2 = (P2BodyDist x = [0,60]) && BackEdgeBodyDist >= 80
trigger2 = EnemyNear, StateNo = 5120 && EnemyNear, AnimTime = -4 && Random < (750 * (AILevel ** 2 / 64.0))




[State -1, EX Vector Drain]
type = ChangeState
value = 1330
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
;triggerall = helper(10371), var(23)
;triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerAll = AILevel && NumEnemy
triggerall = Random < (50 * (AILevel ** 2 / 64.0)) || enemynear,life <=300 || var(20) <= 0
triggerAll = RoundState = 2 && StateType != A
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [0,60]) && ( Random < (50* ifelse(life > enemynear,life, 2,1) * (AIlevel ** 2 / 64.0)) || (life< lifemax/2))
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 && Random < (50 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl || StateNo = 40 || StateNo = 52 && (P2StateNo = [120,140]) && Random < (250 * (AILevel ** 2 / 64.0))
trigger3 = var(5) && Random < (50 * (AIlevel ** 2 / 64.0))



[State -1, EX Shadow Blade ai ]
type = ChangeState
value = 1230
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2 && statetype != A
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = p2bodydist x = [70,150]
triggerall = p2bodydist y = [-300,-100]
triggerall = !enemy,numproj 
triggerall = Random < (10 * (AILevel ** 2 / 64.0)) || enemynear,life <=300 || var(20) <= 0
triggerall = Ctrl || (stateno = 52 || stateno = 40)  
trigger1 = enemynear(var(59)),movetype = A
trigger1 = random <= 150
trigger2 = random <= 100  ;&& var(5)
trigger2 = p2statetype= a
trigger3 = (StateNo =[200, 500]) 
trigger3 = (MoveHit= [1,5]) && Random < (250 * (AILevel ** 2 / 64.0))





[State -1, Air Soul Fist(Normal) ai]
type = ChangeState
value = 1100
triggerAll = (P2BodyDist x = [65,200]) && (P2Dist y > 20) 
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType = A
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)
;trigger1 = NumHelper(1010) <= 0
trigger1 = ctrl && Random < (35 *(AILevel ** 2 / 64.0))
;trigger2 = NumHelper(1010) <= 1
;trigger2 = Random < (100 *(AILevel ** 2 / 64.0))
;trigger2 = Helper(1010),StateNo = [1012,1016]




[State -1, Air Soul Fist(Arrange) ai]
type = ChangeState
value = 1101
triggerAll = (P2BodyDist x = [65,200]) && (P2Dist y > 20) 
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType = A
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)
;trigger1 = NumHelper(1010) <= 0
trigger1 = ctrl && Random < (35 *(AILevel ** 2 / 64.0))
;trigger2 = NumHelper(1010) <= 1
;trigger2 = Random < (100 *(AILevel ** 2 / 64.0))
;trigger2 = Helper(1010),StateNo = [1012,1016]




[State -1, Air EX Soul Fist ai]
type = ChangeState
value = 1130
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerall = Random < (5 * (AILevel ** 2 / 64.0)) || enemynear,life <=300 || var(20) <= 0
triggerAll = (P2BodyDist x = [65,150]) && (P2Dist y > 30) 
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)
;trigger1 = NumHelper(1010) <= 0
trigger1 = ctrl
trigger1 = Random < (15 *(AILevel ** 2 / 64.0))
;trigger2 = ctrl && Random < (50 *(AILevel ** 2 / 64.0))
;trigger2 = NumHelper(1010) <= 1
;trigger2 = Helper(1010),StateNo = [1012,1016]






[State -1, Vector Drain ai]
type = ChangeState
value = 1300
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [0,60]) 
trigger1 = ctrl && Random < (175 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl && (P2StateNo = [120,140]) && Random < (250 * (AILevel ** 2 / 64.0))
trigger2 = var(5) && Random < (175 * (AIlevel ** 2 / 64.0))




[State -1, Shadow Blade ai]
type = ChangeState
value = 1200
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = p2stateno != [154,155]
triggerall = p2bodydist x = [-5,80]
triggerall = p2bodydist y = [-300,0]
triggerall = statetype != A && Ctrl || ((stateno = 100 || stateno = 101 || stateno = 450 || stateno = 250 ) && Movecontact)
trigger1 = enemynear(var(59)),movetype = A
trigger1 = random <= 150
trigger2 = random <= 100
trigger2 = p2statetype= a
trigger3 = (StateNo =[200, 500]) 
trigger3 = (MoveHit= [2,5]) && Random < (250 * (AILevel ** 2 / 64.0))





[State -1, EX Soul Fist ai]
type = ChangeState
value = 1030
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
;triggerall = helper(10371), var(21)
;triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = Random < (5 * (AILevel ** 2 / 64.0)) || enemynear,life <=300 || var(20) <= 0
triggerall = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101]) || ((stateno= [200,500]) && movehit = [2,5])
triggerall = RoundState = 2 && StateType != A
triggerAll = AILevel && numenemy
triggerAll = p2StateType != l
triggerall = (p2dist y =[-110,0])
trigger1= Random < (80 * (AILevel ** 2 / 64.0)) && movehit
;trigger1 = NumHelper(1010) <= 0
;trigger2 = NumHelper(1010) <= 1
;trigger2 = Helper(1010),StateNo = [1012,1016]
;trigger2= Random < (150 * (AILevel ** 2 / 64.0))







[State -1, Soul Fist(Arrange)]
type = ChangeState
value = 1001
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = PalNo>=7
triggerAll = p2StateType != l
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(5)
triggerAll = AILevel && numenemy
triggerall = (p2dist y =[-110,0])
triggerAll = P2BodyDist x > 120 &&  P2movetype != A
trigger1= Random < (25 * (AILevel ** 2 / 64.0))
;trigger1 = NumHelper(1010) <= 0
;trigger2 = NumHelper(1010) <= 1
;trigger2 = Helper(1010),StateNo = [1012,1016]
;trigger2= Random < (150 * (AILevel ** 2 / 64.0))



[State -1, Soul Fist(Normal) ai]
type = ChangeState
value =  1000
triggerAll = p2StateType != l
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)

triggerall = PalNo<=6
triggerall = (p2dist y =[-110,0])
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(5)
triggerAll = AILevel && numenemy
triggerAll = P2BodyDist x > 120 &&  P2movetype != A
trigger1= Random < (25 * (AILevel ** 2 / 64.0))
;trigger1 = NumHelper(1010) <= 0
;trigger2 = NumHelper(1010) <= 1
;trigger2 = Helper(1010),StateNo = [1012,1016]
;trigger2= Random < (150 * (AILevel ** 2 / 64.0))






[State -1, Darkness Illusion ai]
type = ChangeState
value = 3400
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
triggerAll = p2StateType != l
triggerAll = AILevel && numenemy
triggerall = RoundState = 2 
triggerAll = P2BodyDist x <= 150
triggerAll = P2BodyDist y  = [-30,0]

triggerall= Random < (350 * (AILevel ** 2 / 64.0))
trigger1= (stateno = [200,699]) && movehit=[1,10]
trigger2= (stateno=[200,201]) && movehit=[1,10]
trigger3= (stateno=[210,211]) && movehit=[1,10]
trigger4= stateno=221 && movehit=[1,10]
trigger5= stateno=225 && movehit=[1,10]
trigger6= (stateno=[230,240]) && movehit=[1,10]
trigger7= stateno=400 && movehit=[1,10]
trigger8= stateno=410 && movehit=[1,10]
trigger9= (stateno=[430,450]) && movehit=[1,10]
trigger10= (stateno=[600,650]) && (movehit=[1,8]) && pos y <= -20
trigger11= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger12= stateno=1200 && movehit && movetype=A
trigger13= stateno=1230 && movehit && movetype=A







[State -1, MAX Valkyrie Turn ai]
type = ChangeState
value = 3250
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || var(7)
triggerAll = p2StateType != l
triggerAll = AILevel && numenemy
triggerall = RoundState = 2 
triggerAll = P2BodyDist x <= 150

triggerall = (facing=1 && (enemy,facing=-1)) || (facing=-1 && (enemy,facing=1))
triggerall = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (145 * (AILevel ** 2 / 64.0))

trigger1 = enemynear,movetype=A && (p2bodydist x=[0,40])&&(p2bodydist y=[0,0])
trigger2 = ((enemynear,numproj) || (enemynear,numhelper)) && inguarddist && p2bodydist x>=25 
trigger3 = RoundState = 2 && InGuardDist
trigger3 = ctrl && (StateNo != [120, 155]) && !var(20)
trigger3 = !var(26) || P2BodyDist x >= 40
trigger3 = !(EnemyNear, HitDefAttr = SCA, AT) && (EnemyNear, Time < 120)
trigger3 = StateType != A || P2StateType = A
trigger3 = ifElse(StateType = A, ((var(3) != [1, 2]) || StateNo = 5210), 1)
trigger3 = Random <  (ifElse((P2StateNo = [200, 699]), 125, ifElse((P2StateNo = [1000,2999]), 333, 1000)) * (AILevel ** 2 / 64.0))







[State -1, Finishing Shower ai]
type = ChangeState
value = 3300
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerall = PalNo>=7
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = RoundState = 2
triggerAll = AILevel && numenemy
triggerAll = p2StateType != l
triggerall = (p2dist y =[-110,0])
trigger1= Random < (10 * (AILevel ** 2 / 64.0)) 
trigger1 = ctrl || StateNo = 40 || StateNo = 52 && (p2bodydist x =[80,250])
trigger2 = var(6) || var(7)
trigger2= Random < (80 * (AILevel ** 2 / 64.0)) && movehit











[State -1, Silhouette Blade ai]
type = ChangeState
value = 3150
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = p2stateno != [154,155]
triggerall = p2bodydist x = [50,125]
triggerall = p2bodydist y = [-300,0]
triggerall = p2statetype= a || p2movetype = h
trigger1= stateno=3000 && animelemtime(16)<0 && var(12)
trigger2= stateno=3020 && animelemtime(16)<0 && var(12) && pos y <= -20 
trigger3= stateno=3100 && movecontact && movetype=A && (animelemtime(4)<0 || animelemtime(9)>=0)
trigger4= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [50,125]) && (p2movetype = h|| statetype = a)





[State -1, MAX Cardinal Blade(Normal) ai]
type = ChangeState
value = 3110
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = p2stateno != [154,155]
triggerall = p2bodydist x = [0,50]
triggerall = p2bodydist y = [-300,0]
triggerall = p2statetype= a || p2movetype = h
trigger1= stateno=3000 && animelemtime(16)<0 && var(12)
trigger2= stateno=3020 && animelemtime(16)<0 && var(12) && pos y <= -20 
trigger3= stateno=3100 && movecontact && movetype=A && (animelemtime(4)<0 || animelemtime(9)>=0)
trigger4= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,50]) && (p2movetype = h|| statetype = a)



[State -1, Cardinal Blade ai]
type = ChangeState
value = 3100
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = p2stateno != [154,155]
triggerall = p2bodydist x = [0,50]
triggerall = p2bodydist y = [-300,0]
triggerall = p2statetype= a || p2movetype = h
trigger1= (stateno = [200,699]) && Time <= 2
trigger2= (stateno=[200,201]) && movecontact=[1,10]
trigger3= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,50]) && (p2movetype = h|| statetype = a)









[State -1, MAX Air Soul Phoenix]
type = ChangeState
value = 3060
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerAll = AILevel && numenemy
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || var(7)
triggerall = RoundState = 2 && StateType = A
triggerall = ctrl && pos y <= -30 || var(6) || var(7)
triggerAll = (P2BodyDist x = [65,150]) && (P2Dist y > 30) 
triggerall = Random < (520 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,200]) && (p2movetype = h|| !inguarddist)
;triggerall = NumHelper(3055) <= 0 || (NumHelper(3055) <= 1 && Helper(3055),StateNo = [1014,1016])
triggerall =(EnemyNear, GetHitVar(HitTime) >= 4) || !inguarddist
trigger1= stateno=3000 && animelemtime(16)<0 && var(12)
trigger2= stateno=3020 && animelemtime(16)<0 && var(12) && pos y <= -20 
trigger3= stateno=3100 && movecontact && movetype=A && (animelemtime(4)<0 || animelemtime(9)>=0)
trigger4= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [50,150]) && (p2movetype = h|| !inguarddist)


























[State -1, MAX Soul Phoenix ai]
type = ChangeState
value = 3050
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerAll = AILevel && numenemy
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || var(7)
triggerall = RoundState = 2 && StateType != A
triggerAll = p2StateType != l
triggerall = (p2dist y =[-110,0])
triggerall = Random < (520 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,200]) && p2movetype = h
;triggerall = NumHelper(3055) <= 0 || (NumHelper(3055) <= 1 && Helper(3055),StateNo = [1014,1016])
triggerall =(EnemyNear, GetHitVar(HitTime) >= 4)
trigger1= stateno=3000 && animelemtime(16)<0 && var(12)
trigger2= stateno=3020 && animelemtime(16)<0 && var(12) && pos y <= -20 
trigger3= stateno=3100 && movecontact && movetype=A && (animelemtime(4)<0 || animelemtime(9)>=0)
trigger4= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A




[State -1, Valkyrie Turn ai]
type = ChangeState
value = 3200
triggerall = !IsHelper(10371) ;Always add this!
triggerall = numhelper(10371)
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) 
triggerAll = p2StateType != l
triggerAll = AILevel && numenemy
triggerall = RoundState = 2 
triggerAll = P2BodyDist x <= 100
triggerall = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (145 * (AILevel ** 2 / 64.0))
trigger1 = enemynear,movetype=A && (p2bodydist x=[0,40])&&(p2bodydist y=[0,0])
trigger2 = ((enemynear,numproj) || (enemynear,numhelper)) && inguarddist && p2bodydist x>=25 







[State -1, Air Soul Phoenix ai]
type = ChangeState
value = 3020
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerAll = AILevel && numenemy
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl && pos y <= -30 || var(6)
triggerall = RoundState = 2 && StateType = A
triggerall = ctrl && pos y <= -30 || var(6) 
triggerAll = (P2BodyDist x = [65,150]) && (P2Dist y > 30) 
triggerall = Random < (520 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,200]) && (p2movetype = h|| !inguarddist)
;triggerall = NumHelper(3010) <= 0 || (NumHelper(3010) <= 1 && Helper(3010),StateNo = [1014,1016])
triggerall =(EnemyNear, GetHitVar(HitTime) >= 3) || !inguarddist

trigger1= (stateno = [200,699]) && Time <= 2
trigger2= (stateno=[200,201]) && movecontact=[1,10]
trigger3= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [50,150]) && (p2movetype = h|| !inguarddist)


















[State -1, Soul Phoenix ai]
type = ChangeState
value = 3000
triggerall = !IsHelper(10371) ;Always add this as well!
triggerall = numhelper(10371)
triggerAll = AILevel && numenemy
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) 
triggerall = RoundState = 2 && StateType = A
triggerall = ctrl && pos y <= -30 || var(6) || var(7)
triggerAll = (P2BodyDist x = [65,150]) && (P2Dist y > 30) 
triggerall = Random < (520 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,200]) && (p2movetype = h|| !inguarddist)
;triggerall = NumHelper(3010) <= 0 || (NumHelper(3010) <= 1 && Helper(3010),StateNo = [1014,1016])
triggerall =(EnemyNear, GetHitVar(HitTime) >= 4) || !inguarddist
trigger1= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [50,150]) && (p2movetype = h|| !inguarddist)






