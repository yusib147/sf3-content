
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s


[Defaults]

command.time = 15


command.buffer.time = 1


[Command]
name = "SGS"
command = x, x, F, a
time = 32


[Command]
name = "RSGS"
command = x, x, B, a
time = 32


[Command]
name = "SGS"
command = x, x, F+a
time = 32


[Command]
name = "RSGS"
command = x, x, B+a
time = 32


[Command]
name = "SGS2"
command = x, x, F
time = 24


[Command]
name = "RSGS2"
command = x, x, B
time = 24


[Command]
name = "QCFx2"
command = ~D, DF, F, D, DF
time = 21

[Command]
name = "QCBx2"
command = ~D, DB, B, D, DB
time = 21

[command]
name = "HCB"
command = ~F, DF, $D, B
time = 24

[command]
name = "HCF"
command = ~B, DB, $D, F
time = 24

[Command]
name = "DP"
command = ~F, D, DF
time = 16

[Command]
name = "RDP"
command = ~B, D, DB
time = 16

[Command]
name = "QCB"
command = ~D, DB, B
time = 15

[Command]
name = "QCF"
command = ~D, DF, F
time = 15

[Command]
name = "QCBD"
command = ~B, DB, D
time = 15

[Command]
name = "QCFD"
command = ~F, DF, D
time = 15


[Command]
name = "recovery"
command = x+y
time = 1


[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10


[Command]
name = "back_x"
command = /$B,x
time = 1

[Command]
name = "back_y"
command = /$B,y
time = 1

[Command]
name = "back_z"
command = /$B,z
time = 1

[Command]
name = "down_x"
command = /$D,x
time = 1

[Command]
name = "down_y"
command = /$D,y
time = 1

[Command]
name = "down_z"
command = /$D,z
time = 1

[Command]
name = "fwd_x"
command = /$F,x
time = 1

[Command]
name = "fwd_y"
command = /$F,y
time = 1

[Command]
name = "fwd_z"
command = /$F,z
time = 1

[Command]
name = "up_x"
command = /$U,x
time = 1

[Command]
name = "up_y"
command = /$U,y
time = 1

[Command]
name = "up_z"
command = /$U,z
time = 1

[Command]
name = "back_a"
command = /$B,a
time = 1

[Command]
name = "back_b"
command = /$B,b
time = 1

[Command]
name = "back_c"
command = /$B,c
time = 1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

[Command]
name = "down_c"
command = /$D,c
time = 1

[Command]
name = "fwd_a"
command = /$F,a
time = 1

[Command]
name = "fwd_b"
command = /$F,b
time = 1

[Command]
name = "fwd_c"
command = /$F,c
time = 1

[Command]
name = "up_a"
command = /$U,a
time = 1

[Command]
name = "up_b"
command = /$U,b
time = 1

[Command]
name = "up_c"
command = /$U,c
time = 1


[Command]
name = "a"
command = a
time = 1
buffer.time = 1

[Command]
name = "b"
command = b
time = 1
buffer.time = 1

[Command]
name = "c"
command = c
time = 1
buffer.time = 1

[Command]
name = "x"
command = x
time = 1
buffer.time = 1

[Command]
name = "y"
command = y
time = 1
buffer.time = 1

[Command]
name = "z"
command = z
time = 1
buffer.time = 1

[Command]
name = "start"
command = s
time = 1
buffer.time = 1


[Command]
name = "fwd"
command = $F
time = 1

[Command]
name = "downfwd"
command = $DF
time = 1

[Command]
name = "down"
command = $D
time = 1

[Command]
name = "downback"
command = $DB
time = 1

[Command]
name = "back"
command = $B
time = 1

[Command]
name = "upback"
command = $UB
time = 1

[Command]
name = "up"
command = $U
time = 1

[Command]
name = "upfwd"
command = $UF
time = 1


[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holddownfwd"
command = /$DF
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holddownback"
command = /$DB
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdupback"
command = /$UB
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holdupfwd"
command = /$UF
time = 1


[Command]
name = "hold_a"
command = /a
time = 1
buffer.time = 1

[Command]
name = "hold_b"
command = /b
time = 1
buffer.time = 1

[Command]
name = "hold_c"
command = /c
time = 1
buffer.time = 1

[Command]
name = "hold_x"
command = /x
time = 1
buffer.time = 1

[Command]
name = "hold_y"
command = /y
time = 1
buffer.time = 1

[Command]
name = "hold_z"
command = /z
time = 1
buffer.time = 1

[Command]
name = "hold_start"
command = /s
time = 1
buffer.time = 1



[Command]
name = "rlsfwd"
command = ~$F
time = 1

[Command]
name = "rlsback"
command = ~$B
time = 1

[Command]
name = "rlsup"
command = ~$U
time = 1

[Command]
name = "rlsdown"
command = ~$D
time = 1



[Command]
name = "rlsx"
command = ~x
time = 1
buffer.time = 1

[Command]
name = "rlsy"
command = ~y
time = 1
buffer.time = 1

[Command]
name = "rlsz"
command = ~z
time = 1
buffer.time = 1

[Command]
name = "rlsa"
command = ~a
time = 1
buffer.time = 1

[Command]
name = "rlsb"
command = ~b
time = 1
buffer.time = 1

[Command]
name = "rlsc"
command = ~c
time = 1
buffer.time = 1

[Command]
name = "rlss"
command = ~s
time = 1
buffer.time = 1



[Command]
name = "highjump"
command = $D, $U
time = 15














;   --- Uno Tag System [Type-R] Command definition ---

[Command]
name = "aHsoNn"
command = ~D, D, D, z+c
Time = 25

[Command]
name = "sheoun"
command = ~D, DF, F, z+c
Time = 25

[Command]
name = "palit"
command = z+c
Time = 2

[Command]
name = "turtleuno"
command = s
Time = 2


[Statedef -1]


[State -1, Partner Assist]
type = VarSet
sysvar(4) = 10
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 60 && Time > 0
triggerall = teammode = Simul
triggerall = StateNo != [3000,1251199]
triggerall = hitdefattr != SCA, HA, HP, HT
triggerAll = StateNo != [130,152]
triggerall = !(StateNo = [5000,5500])
triggerall = Power >= 500
trigger1 = command = "turtleuno"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = !ctrl && Movetype = A
trigger2 = Random < (((2 * ifelse(MoveContact, ifelse(MoveHit, 2, 3),1)) + (UniqHitCount * 2)) *(AILevel**2/64.0))
trigger3 = AILevel >  0
trigger3 = StateNo = [190,199]
trigger3 = AnimElemNo(0) = 2
ignorehitpause = 1

[State -1, Team Hyper Attack]
type = ChangeState
value = 1251125
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = Partner, life > 0
triggerall = power >= 3000
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 9		
triggerall= (StateType != A)
trigger1 = command = "sheoun"
trigger1 = (Ctrl = 1)
trigger1 = AILevel <=  0
trigger2 = command = "sheoun"
trigger2 = Anim = [200,1000]
trigger2 = movetype = A
trigger2 = hitdefattr = SC, NA
trigger2 = MoveContact
trigger2 = AILevel <=  0
trigger3 = AILevel > 0 && ctrl
trigger3 = Random < (10 + ((Life < Lifemax/6)*3))
trigger3 = NumEnemy && enemy, pos x = [0,200]
trigger4 = AILevel >  0
trigger4 = Anim = [200,1000]
trigger4 = movetype = A
trigger4 = hitdefattr = SC, NA
trigger4 = MoveContact
trigger4 = Random < (11 + ((MoveHit)*5) + ((Life < Lifemax/6)*5))
ignorehitpause = 1

[State -1, Delayed Hyper]
type = ChangeState
value = 1251127
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0
triggerall = power >= 1000
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time > 1 && Time > 45
triggerall = movetype = A
triggerall = StateNo = [2000,1251100]
triggerall = hitdefattr = SCA, HA, HP, HT || (StateNo >= 2000 && StateNo < 4000 && (hitcount < 8 || NumTarget && Target, GetHitVar(hitTime) >= 0))
trigger1 = command = "sheoun"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = NumTarget && MoveContact
trigger2 = Random < (10*(AILevel**2/64.0) + (Uniqhitcount*((Life < Partner,Life)*2)))
trigger2 = Partner, Time > 35
trigger3 = AILevel >  0
trigger3 = Partner, Time > 30 && Time > 25
trigger3 = HitCount >= 6
trigger3 = Random < (2 * Uniqhitcount * ifelse(hitcount > 9, 2, 1))
ignorehitpause = 1

[State -1, UNO Mode]
type = ChangeState
value = 1251128
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0 && Power >= 1000
triggerall = Life <= (Lifemax/8)
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 20
triggerall = (StateType != A) && ((Ctrl = 1) || StateNo = 0 || (Movetype = A && hitdefattr = SC, NA))
trigger1 = command = "aHsoNn"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Partner, Life < Lifemax/4
trigger2 = Random < ((25 + ifelse((Partner, Life < Lifemax/6), 25, 5))*(AILevel**2/64.0))

[State -1, Change Attack]
type = ChangeState
value = 1251126
triggerall = NumPartner
triggerall = (sysvar(4) = 1 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),250,500)) || (sysvar(4) = 15 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),500,1000))
triggerall = Partner, life > 0
triggerall = movetype = A && !MoveReversed
triggerall = (Partner, StateNo = 1251112 || Partner, StateNo = 1251114)  && Time > 1
triggerall = StateNo = [200,4850]
triggerall = StateNo != [1251102,1251105]
triggerall = NumTarget > 0 && Target, pos Y > -160
triggerall = (Target, StateNo != [5110,5955])
triggerall = Hitdefattr != SCA, NT && ((Target, Statetype = A || (Hitdefattr != A, NA && Target, Statetype != A)) && ((!Target, HitOver || EnemyNear, StateNo = [5000,5900]) && (MoveContact || ProjContactTime(0) < 8)))
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = UniqHitCount >= 2
trigger2 = Random < (((ifelse(sysvar(4)=15,25,50)*(AILevel**2/64.0)) + ((hitdefattr = SCA, SA, HA)*15) + ifelse(lifemax/life > 15, 15, lifemax/life)))
trigger2 = Partner, Life > Lifemax/10 || Life <= Partner, Life
trigger2 = Partner, Time > 25
trigger3 = AILevel >  0
trigger3 = Partner, Time > 27
trigger3 = Random < (25*(2*(Life = (Lifemax/4) && Life < Partner, Life)) *(AILevel**2/64.0))
trigger3 = MoveContact
ignorehitpause = 1

[State -1, TagIn]
type = ChangeState
value = 1251110
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner && NumEnemy
triggerall = RoundState = 2 
triggerall = Partner, life > 0
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 40	
triggerall = (MoveType != A && StateType != A) && (Ctrl = 1) || StateNo = 0
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Random < (ifelse((LifeMax/Life > 120), 120, LifeMax/Life)+((EnemyNear,statetype=L)*25))
trigger2 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond
trigger2 = EnemyNear, movetype != A
trigger3 = AILevel >  0
trigger3 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond && Life < LifeMax * (LifeMax*0.55)
trigger3 = Random < ((ifelse(LifeMax/Life > 10, 10, LifeMax/Life) + (10+ifelse((EnemyNear, StateNo > 5000),25,1))) * ifelse((Life < Partner, Life), 1.45, 0.5))
trigger3 = Partner, Time > 1 * TicksPerSecond
trigger3= EnemyNear, statetype = L || p2bodydist x > 250 && EnemyNear, movetype != A
trigger4 = AILevel >  0
trigger4 = Life < 150 && Life < Partner, Life
trigger4 = EnemyNear, statetype = L || p2bodydist x > 200 && EnemyNear, movetype != A
trigger4 = Random < (125*(AILevel**2/64.0))

[State -1, C_6]
type = CtrlSet
value = 1
triggerall = RoundState = 2 && NumPartner
triggerall = NumTarget && Target, StateNo != [200,4999]
triggerall = StateNo != 1251106 && !Ctrl
triggerall = (Partner, StateNo != [1251128,1251129]) && (Partner, PrevStateNo != [1251128,1251129])
trigger1 = command="x"||command="y"||command="z"||command="a"||command="b"||command="c"
trigger1 = sysvar(4) = 7
trigger1 = Movetype = A
trigger1 = MoveContact
trigger1 = hitdefattr = SCA, NA, SA
trigger1 = StateNo != PrevStateNo
trigger1 = Time > 3
trigger2 = PrevStateNo = 1251106
ignorehitpause = 0

; ------ Uno Tag System [Type-R] END LINE -------

;  ;]

[State -1, Tick Fix]
type = CtrlSet
triggerall = RoundState = 2
triggerall = !ctrl
trigger1 = (StateNo = 52 || StateNo = 5120) && !AnimTime
trigger2 = (StateNo = [200,299]) && !AnimTime
trigger3 = (StateNo = [400,499]) && !AnimTime
trigger4 = (StateNo = [760,762]) && !AnimTime
trigger5 = StateNo = 810 && !AnimTime
trigger6 = (StateNo = 5001 || StateNo = 5011 || StateNo = 151 || StateNo = 153) && HitOver
trigger7 = (StateNo = [700,715]) && !AnimTime
value = 1

[State -1, CtrlSet For Helpers]
type = CtrlSet
trigger1 = IsHelper
value = 0

[State -1, Hit Count For Helpers]
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime
trigger1 = !(HitDefAttr = SCA, AT)
var(13) = 1

[State -1, Juggle Count For Helpers]
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime
trigger1 = !(HitDefAttr = SCA, AT)
var(15) = 1

[State -1, ProjContact]
type = VarSet
trigger1 = IsHelper
trigger1 = MoveContact = 1 && NumTarget
var(18) = 1

[State -1, Root ProjContact]
type = ParentVarSet
trigger1 = IsHelper
trigger1 = MoveContact = 1 && NumTarget
var(18) = 1

[State -2, Lilith's Hit Detection]
type = VarSet
trigger1 = IsHelper(3500)
trigger1 = MoveContact = 1 && var(30) < 0
var(30) = HitPauseTime
ignoreHitPause = 1

[State -2, Hit Sparks for Lilith]
type = Helper
triggerAll = IsHelper(3500)
triggerAll = MoveContact = 1 && var(30) = HitPauseTime
trigger1 = MoveHit = 1 && NumEnemy
trigger2 = MoveGuarded = 1 && NumEnemy
helperType = Normal
stateNo = ifElse(MoveGuarded,8001,8014)
ID = 8000
name = "Spark"
postype = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < var(35), ceil(P2Dist x), var(35))), var(36)
facing = -1
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State -2, Counter FX for Lilith]
type = Helper
trigger1 = NumHelper(3500) && MoveHit = 1 && var(30) = HitPauseTime
trigger1 = NumEnemy && var(9)
trigger1 = !(HitDefAttr = SCA, AT) && (EnemyNear, MoveReversed != 1)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < var(35), ceil(P2Dist x), var(35))), var(36)
facing = -1
ownPal = 1
pauseMoveTime = 255
superMoveTime = 255
ignoreHitPause = 1

[State -2, Hit Detection for Lilith]
type = VarSet
trigger1 = IsHelper
var(30) = -1

[State -2, Hit Detection for Lilith]
type = VarRangeSet
trigger1 = IsHelper
trigger1 = MoveType = I
trigger2 = MoveType = H && Time
first = 30
last = 36
value = -1
ignoreHitPause = 1

[State -1, Darkness Illusion]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3400
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(42)
triggerall = (helper(10371), var(2)) || (helper(10371), var(9))
triggerall = RoundState = 2
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = (StateNo=[200,251]) || (StateNo=[600,655])

[State -1, Darkness Illusion Alt]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3400
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(43)
triggerall = (helper(10371), var(3)) && (helper(10371), var(2))
triggerall = RoundState = 2
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = (StateNo=[200,251]) || (StateNo=[600,655])

[State -1, MAX Valkyrie Turn]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3250
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(23)
triggerall = (helper(10371), var(3)) && (helper(10371), var(4)) || (helper(10371), var(4)) && (helper(10371), var(5)) || (helper(10371), var(3)) && (helper(10371), var(5))
triggerall = RoundState = 2
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6) || var(7)

[State -1, Finishing Shower]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3300
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(41)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = PalNo>=7
triggerall = RoundState = 2
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6) || var(7)

[State -1, Silhouette Blade]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3150
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(3)) && (helper(10371), var(4)) || (helper(10371), var(4)) && (helper(10371), var(5)) || (helper(10371), var(3)) && (helper(10371), var(5))
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6) || var(7)

[State -1, MAX Cardinal Blade(Normal)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3110
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(3)) && (helper(10371), var(4)) || (helper(10371), var(4)) && (helper(10371), var(5)) || (helper(10371), var(3)) && (helper(10371), var(5))
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6) || var(7)

[State -1, MAX Air Soul Phoenix]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3060
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType = A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(6) || var(7)
trigger1 = NumHelper(3055) <= 0
trigger2 = NumHelper(3055) <= 1
trigger2 = Helper(3055),StateNo = [1014,1016]

[State -1, MAX Soul Phoenix]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3050
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || var(7)
trigger1 = NumHelper(3055) <= 0
trigger2 = NumHelper(3055) <= 1
trigger2 = Helper(3055),StateNo = [1014,1016]

[State -1, Valkyrie Turn]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3200
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(23)
triggerall = (helper(10371), var(3)) || (helper(10371), var(4)) || (helper(10371), var(5)) || (helper(10371), var(10)) || (helper(10371), var(11)) || (helper(10371), var(12))
triggerall = RoundState = 2
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6)

[State -1, Cardinal Blade]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3100
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(3)) || (helper(10371), var(4)) || (helper(10371), var(5)) || (helper(10371), var(10)) || (helper(10371), var(11)) || (helper(10371), var(12))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(6)

[State -1, Air Soul Phoenix]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3020
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = RoundState = 2 && StateType = A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(6)
trigger1 = NumHelper(3010) <= 0
trigger2 = NumHelper(3010) <= 1
trigger2 = Helper(3010),StateNo = [1014,1016]

[State -1, Soul Phoenix]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3000
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6)
trigger1 = NumHelper(3010) <= 0
trigger2 = NumHelper(3010) <= 1
trigger2 = Helper(3010),StateNo = [1014,1016]

[State -1, EX Vector Drain]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1330
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(23)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(5)

[State -1, EX Shadow Blade]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1230
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(22)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(5)

[State -1, Air EX Soul Fist]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1130
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType = A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, EX Soul Fist]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1030
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) && (helper(10371), var(1)) || (helper(10371), var(1)) && (helper(10371), var(2)) || (helper(10371), var(0)) && (helper(10371), var(2))
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101]) || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Vector Drain]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1300
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(23)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(5)

[State -1, Shadow Blade]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1200
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(22)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52
trigger2 = var(5)

[State -1, Air Soul Fist(Arrange)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1101
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType = A
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Air Soul Fist(Normal)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1100
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType = A
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Soul Fist(Arrange)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1001
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Soul Fist(Normal)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1000
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(21)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(5)
trigger1 = NumHelper(1010) <= 0
trigger2 = NumHelper(1010) <= 1
trigger2 = Helper(1010),StateNo = [1012,1016]

[State -1, Alpha Counter(Kick)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 750
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(20)
triggerall = (helper(10371), var(3)) || (helper(10371), var(4)) || (helper(10371), var(5)) || (helper(10371), var(10)) || (helper(10371), var(11)) || (helper(10371), var(12))
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1, Alpha Counter(Punch)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 750
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(20)
triggerall = (helper(10371), var(0)) || (helper(10371), var(1)) || (helper(10371), var(2)) || (helper(10371), var(7)) || (helper(10371), var(8)) || (helper(10371), var(9))
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1, Counter Movement]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 740
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(14)
triggerall = (helper(10371),command = "holdfwd") || (helper(10371),command = "holdback")
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1, Throw(Kick)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 800
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = (helper(10371), var(3) && helper(10371), var(4)) || (helper(10371), var(4) && helper(10371), var(5)) || (helper(10371), var(3) && helper(10371), var(5))
trigger1 = (helper(10371),command = "holdfwd")|| (helper(10371),command = "holdback")
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl

[State -1, Throw(Punch)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 800
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = (helper(10371), var(0) && helper(10371), var(1)) || (helper(10371), var(1) && helper(10371), var(2)) || (helper(10371), var(0) && helper(10371), var(2))
trigger1 = (helper(10371),command = "holdfwd")|| (helper(10371),command = "holdback")
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl

[State -1, Air Throw]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 900
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = (helper(10371), var(0) && helper(10371), var(1)) || (helper(10371), var(1) && helper(10371), var(2)) || (helper(10371), var(0) && helper(10371), var(2))
trigger1 = (command = "holdfwd" || command = "holdback")
trigger1 = RoundState = 2 && StateType = A
trigger1 = ctrl && pos y <= -30
trigger1 = statetype != S

[State -1, Roll Forward]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 710
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(14)
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdfwd"

[State -1, Roll Back]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 715
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(14)
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdback"

[State -1, Power Charge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 730
triggerall = !ailevel
trigger1 = command = "hold_b" && command = "hold_y"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (StateNo = [100,101])



[State -1, MAX Mode]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 770
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(16)
triggerall = RoundState = 2 && StateType != A
triggerall = var(20) <= 0 && Power >= 1000
trigger1 = ctrl || (Stateno = [100,101])

[State -1, Dodge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 700
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(14)
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))

[State -1, Shell Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 655
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(5)
triggerall = command = "holddown"
triggerall = Time >= 12
triggerall = var(3)!=[1,2]
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Run Fwd]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 100
triggerall = RoundState = 2 && StateType = S
trigger1 = command = "FF"
trigger1 = ctrl

[State -1, Run Back]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 105
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Stand Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = !ailevel
value = 200 + (Abs(P2BodyDist X) <= 20) * 1
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(0)
triggerall = (helper(10371),command != "holddown")

triggerall = statetype != A
trigger1= ctrl
trigger2= (StateNo = 200 || StateNo = 201 || StateNo = 430) && Time >=5

[State -1, Stand Medium Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = !ailevel
value = 210 + (Abs(P2BodyDist X) <= 24) * 1
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(1)
triggerall = (helper(10371),command != "holddown")
triggerall = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,201]) || StateNo = 230) && (MoveContact=[1,4])
trigger3 = (StateNo=400 || StateNo=430) && (MoveContact=[1,4])

[State -1, Stand Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = !ailevel
value = 220 + (Abs(P2BodyDist X) <= 18) * 1
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(2)
triggerall = (helper(10371),command != "holddown")
triggerall = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,211]) || (StateNo=[230,240])) && (MoveContact=[1,4])
trigger3 = ((StateNo=[400,410]) || (StateNo=[430,440])) && (MoveContact=[1,4])

[State -1, Stand Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 230
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(3)
triggerall = (helper(10371),command != "holddown")
triggerall = statetype != A
trigger1= ctrl
trigger2 = ((StateNo=[200,201]) || StateNo=400) && (MoveContact=[1,4])
trigger3 = ((StateNo=[200,201]) || StateNo=430) && Time>=5

[State -1, Stand Medium Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 240
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(4)
triggerall = (helper(10371),command != "holddown")
triggerall = statetype != A
trigger1= ctrl
trigger2 = ((StateNo=[200,211]) || StateNo=230) && (MoveContact=[1,4])
trigger3 = ((StateNo=[400,410]) || StateNo=430) && (MoveContact=[1,4])

[State -1, Standing Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = !ailevel
value = 250 + (Abs(P2BodyDist X) <= 15) * 1
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(5)
triggerall = (helper(10371),command != "holddown")
triggerall = statetype != A
trigger1= ctrl
trigger2 = ((StateNo=[200,221]) || (StateNo=[230,240])) && (MoveContact=[1,4])
trigger3 = (StateNo=[400,440]) && (MoveContact=[1,4])

[State -1, Crouching Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 400
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(0)
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2= ((StateNo=[200,201]) || StateNo=430) && Time >=5

[State -1, Crouching Medium Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 410
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(1)
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,201]) || StateNo=230 || StateNo=400 || StateNo=430) && (MoveContact=[1,4])

[State -1, Crouching Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 420
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(2)
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,211]) || (StateNo=[230,240])) && (MoveContact=[1,4])
trigger3 = ((StateNo=[400,410]) || (StateNo=[430,440])) && (MoveContact=[1,4])

[State -1, Crouching Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 430
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(3)
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,201]) || StateNo=400) && (MoveContact=[1,4])
trigger3 = ((StateNo=[200,201]) || StateNo=430) && Time>=5

[State -1, Crouching Medium Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 440
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(4)
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,211]) || StateNo=230) && (MoveContact=[1,4])
trigger3 = ((StateNo=[400,410]) || StateNo=430) && (MoveContact=[1,4])

[State -1, Crouching Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 450
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(5)
triggerall = (helper(10371),command = "holddown")
triggerAll = StateType != A
trigger1 = ctrl
trigger2 = ((StateNo=[200,221]) || (StateNo=[230,240])) && (MoveContact=[1,4])
trigger3 = (StateNo=[400,440]) && (MoveContact=[1,4])

[State -1, Jump Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 600
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(0)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Med Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 610
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(1)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 620
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(2)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 630
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(3)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Med Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 640
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(4)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 650
triggerall = !ailevel
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(5)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Taunt(Normal)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 196
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(6)
triggerall = PalNo<=6
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl
trigger2 = var(5)

[State -1, Taunt(Arrange)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 195
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(6)
triggerall = PalNo>=7
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl
trigger2 = var(5)















[State -1, Stand Light Punch ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,50]) && ((P2Dist y = [-90,0]) ||p2statetype != a) && P2StateType != L && P2StateType != C
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1= ctrl &&  Random < (250 * (AILevel ** 2 / 64.0))
trigger2= (StateNo = 200 || StateNo = 201 || StateNo = 430) && Time >=5 &&  Random < (70 * (AILevel ** 2 / 64.0))
value = 200 + (Abs(P2BodyDist X) <= 20) * 1






[State -1, Stand Medium Punch ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 210 + (Abs(P2BodyDist X) <= 24) * 1
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,110]) &&  ((P2Dist y = [-90,0]) ||p2statetype != a) && P2StateType != L && P2StateType != C
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,201]) || StateNo = 230) && (MoveContact=[1,4]) &&  Random < (250 * (AILevel ** 2 / 64.0))
trigger3 = (StateNo=400 || StateNo=430) && (MoveContact=[1,4])  &&  Random < (250 * (AILevel ** 2 / 64.0))




[State -1, Stand Strong Punch ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 220 + (Abs(P2BodyDist X) <= 18) * 1
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,100]) &&  ((P2Dist y = [-80,0]) ||p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (10 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,211]) || (StateNo=[230,240])) && (MoveContact=[3,4])&&  Random < (150 * (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[400,410]) || (StateNo=[430,440])) && (MoveContact=[3,4])&&  Random < (250 * (AILevel ** 2 / 64.0))



[State -1, Stand Light Kick ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 230
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,55]) &&  ((P2Dist y = [-30,0]) && p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (250 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,201]) || StateNo=400) && (MoveContact=[1,4]) &&  Random < (250* (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[200,201]) || StateNo=430) && Time>=5 &&  Random < (250*(AILevel ** 2 / 64.0))



[State -1, Stand Medium Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 240
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,90]) &&  ((P2Dist y = [-60,-40]) || p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (10 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,211]) || StateNo=230) && (MoveContact=[1,4]) && Random < (150*(AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[400,410]) || StateNo=430) && (MoveContact=[1,4]) && Random < (350*(AILevel ** 2 / 64.0))





[State -1, Standing Strong Kick ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 250 + (Abs(P2BodyDist X) <= 15) * 1
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,115]) &&  ((P2Dist y = [-120,0]) || p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,221]) || (StateNo=[230,240])) && (MoveContact=[2,4]) && Random < (250*(AILevel ** 2 / 64.0))
trigger3 = (StateNo=[400,440]) && (MoveContact=[2,4]) && Random < (350*(AILevel ** 2 / 64.0))






[State -1, Crouching Light Punch ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 400
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,50]) &&  ((P2Dist y = [-40,0]) && p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (250 * (AILevel ** 2 / 64.0))
trigger2= ((StateNo=[200,201]) || StateNo=430) && Time >=5 && (150*ifelse(moveguarded && p2statetype= s,1,.5)* (AILevel ** 2 / 64.0))


[State -1, Crouching Medium Punch ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 410
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [40,80]) &&  ((P2Dist y = [-50,0]) && p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,201]) || StateNo=230 || StateNo=400 || StateNo=430) && (MoveContact=[1,4])&& (150*ifelse(moveguarded && p2statetype= s,1,.5)* (AILevel ** 2 / 64.0))



[State -1, Crouching Strong Punch ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 420
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,110]) &&  ((P2Dist y = [-30,0]) && p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,211]) || (StateNo=[230,240])) && (MoveContact=[2,4])&& (150* (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[400,410]) || (StateNo=[430,440])) && (MoveContact=[2,4])&& (250* (AILevel ** 2 / 64.0))



[State -1, Crouching Light Kick ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 430
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,50]) &&  ((P2Dist y = [-20,0]) && p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (75 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,201]) || StateNo=400) && (MoveContact=[1,4])&& (150* (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[200,201]) || StateNo=430) && Time>=5 && (80* (AILevel ** 2 / 64.0))



[State -1, Crouching Medium Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 440
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,80]) &&  ((P2Dist y = [-20,0]) && p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ctrl && Random < (60 * (AILevel ** 2 / 64.0))
trigger2 = ((StateNo=[200,211]) || StateNo=230) && (MoveContact=[1,4]) &&(75*  (AILevel ** 2 / 64.0))
trigger3 = ((StateNo=[400,410]) || StateNo=430) && (MoveContact=[1,4]) && (250* (AILevel ** 2 / 64.0))





[State -1, Crouching Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 450
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (P2BodyDist x = [0,105]) &&  ((P2Dist y = [-20,0]) && p2statetype != a) && P2StateType != L
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = ((StateNo=[200,221]) || (StateNo=[230,240])) && (MoveContact=[1 ,4])&&(100*  (AILevel ** 2 / 64.0))
trigger2 = (StateNo=[400,440]) && (MoveContact=[1,4])&& (250* (AILevel ** 2 / 64.0))








[State -1, Jump Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 600
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 60+vel x) &&  (P2Dist y = [0,40])
trigger1 = ctrl&& (150* (AILevel ** 2 / 64.0))




[State -1, Jump med Punch ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 610
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 60+vel x) &&  (P2Dist y = [0,40])
trigger1 = ctrl&& (150* (AILevel ** 2 / 64.0))


[State -1, Jump Heavy Punch ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 620
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 60+vel x) && (vel y < 2 && (P2Dist y = [0,40]) || (P2Dist y = [-20,20]) )
trigger1 = ctrl&& (175* (AILevel ** 2 / 64.0))



[State -1, Jump Light kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 630
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 60+vel x) &&  (P2Dist y = [-10,20])
trigger1 = ctrl&& (80* (AILevel ** 2 / 64.0))


[State -1, Jump med kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 640
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 70+vel x) && (vel y <= 0 ||  (P2Dist y = [0,50]) )
trigger1 = ctrl&& (220* (AILevel ** 2 / 64.0))


[State -1, Jump Heavy kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 650
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = (P2BodyDist x < 70+vel x) &&  (P2Dist y = [0,30])
trigger1 = ctrl && (150* (AILevel ** 2 / 64.0))



[State -1, Zero Counter]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 750
triggerall = (helper(10371), var(3)) || (helper(10371), var(4)) || (helper(10371), var(5)) || (helper(10371), var(10)) || (helper(10371), var(11)) || (helper(10371), var(12))
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = helper(10371), var(20)
trigger1 = AILevel && NumEnemy
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power >= 1000
trigger1 = Random < (25 * ifelse(Life < 0.75 * LifeMax, 2,1)* ifelse(Life < 0.50 * LifeMax, 2,1)* ifelse(Life < 0.25 * LifeMax, 2,1) * (AILevel ** 2 / 64.0))
trigger1 = (P2BodyDist x = [0,50]) && !var(20)



[State -1, Counter Movement]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 740
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = AILevel && NumEnemy
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power >= 1000
trigger1 = Random < (50 * ifelse(Life < 0.75 * LifeMax, 2,1)* ifelse(Life < 0.50 * LifeMax, 2,1)* ifelse(Life < 0.25 * LifeMax, 2,1) * (AILevel ** 2 / 64.0))
trigger1 = !var(20)


[State -1, Throw]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 800
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [0,40])
trigger1 = ctrl && Random < (75 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl && (P2StateNo = [120,140]) && Random < (100 * (AILevel ** 2 / 64.0))





[State -1, Air Throw]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 900
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = (helper(10371), var(0) && helper(10371), var(1)) || (helper(10371), var(1) && helper(10371), var(2)) || (helper(10371), var(0) && helper(10371), var(2))
triggerAll = AILevel && NumEnemy
triggerAll = P2StateType = A
triggerAll = (P2BodyDist x < 55+vel x) && (P2Dist y = [-40,0])
trigger1 = RoundState = 2 && StateType = A
trigger1 = ctrl && pos y <= -30 && Random < (350 * (AIlevel ** 2 / 64.0))



[State -1, Roll Forward]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 710
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Random < (50 * (AILevel ** 2 / 64.0))
trigger1 = (ctrl || (StateNo = [100,101]))
trigger1 = (EnemyNear, MoveType = A) && !(EnemyNear, HitDefAttr = SCA, AT) && (P2BodyDist x = [60,125])






[State -1, Power Charge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 730
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power < const(data.power) && !var(20)
trigger1 = ctrl && Power < const(data.power) && Power < PowerMax/2 && !var(20) && PrevStateNo != 5120
trigger1 = !InGuardDist && P2BodyDist x >= 160 && Random < (50 * (AILevel ** 2 / 64.0))






[State -1, MAX Mode]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 770
triggerall = RoundState = 2 && StateType != A
triggerall =  Power >= 1000 && var(20) <= 0
triggerall = AILevel && NumEnemy
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = RoundState = 2 && StateType != A && ctrl
triggerall = ctrl || (Stateno = [100,101])
trigger1 = EnemyNear, ctrl = 0
trigger1 = !InGuardDist && P2BodyDist x < 120 && Random < (150 * (AIlevel ** 2 / 64.0))
trigger2= P2movetype = h || P2StateType = L
trigger2 = ctrl && Random < (180  * (AILevel ** 2 / 64.0))&& RoundState = 2
trigger2 = power >= powermax/2




[State -1, Dodge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
value = 700
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Random < (50 * (AIlevel ** 2 / 64.0))
trigger1 = (ctrl || (StateNo = [100,101])) && var(20) <= 164 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && !(EnemyNear, HitDefAttr = SCA, AT) && (P2BodyDist x = [0,50])

[State -1, Dodge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
value = 700
triggerall = AIlevel && numenemy
triggerall = (facing=1 && (enemy,facing=-1)) || (facing=-1 && (enemy,facing=1))
triggerall = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (145 * (AILevel ** 2 / 64.0))
triggerall = roundstate=2  && statetype != A
trigger1 = enemynear,movetype=A && (p2bodydist x=[0,40])&&(p2bodydist y=[0,0])
trigger2 = ((enemynear,numproj) || (enemynear,numhelper)) && inguarddist && p2bodydist x<=60
trigger3 = RoundState = 2 && InGuardDist
trigger3 = ctrl && (StateNo != [120, 155]) && !var(20)
trigger3 = !var(26) || P2BodyDist x >= 40
trigger3 = !(EnemyNear, HitDefAttr = SCA, AT) && (EnemyNear, Time < 120)
trigger3 = StateType != A || P2StateType = A
trigger3 = ifElse(StateType = A, ((var(3) != [1, 2]) || StateNo = 5210), 1)
trigger3 = Random <  (ifElse((P2StateNo = [200, 699]), 125, ifElse((P2StateNo = [1000,2999]), 333, 1000)) * (AILevel ** 2 / 64.0))





[State -1, Shell Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 655
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerall = vel y > 0

triggerAll = (P2BodyDist x < 70) &&  (P2Dist y = [0,200])
trigger1 = ctrl && (250* (AILevel ** 2 / 64.0))






[State -1, Dash Backward]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 105
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = S
triggerAll = ctrl && (StateNo != [100,106]) && var(20) <= 150 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && BackEdgeDist >= 80 && (P2BodyDist x = [60,100]) && (EnemyNear, vel x)
trigger1 = Random < (ifElse((EnemyNear, HitDefAttr = SC, AT), 150, 50) * (AILevel ** 2 / 64.0))
trigger2 = (P2BodyDist x = [0,60]) && BackEdgeBodyDist >= 80
trigger2 = EnemyNear, StateNo = 5120 && EnemyNear, AnimTime = -4 && Random < (750 * (AILevel ** 2 / 64.0))




[State -1, EX Vector Drain]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1330
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)


triggerAll = AILevel && NumEnemy
triggerall = Random < (50 * (AILevel ** 2 / 64.0)) || enemynear,life <=300 || var(20) <= 0
triggerAll = RoundState = 2 && StateType != A
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [0,60]) && ( Random < (50* ifelse(life > enemynear,life, 2,1) * (AIlevel ** 2 / 64.0)) || (life< lifemax/2))
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 && Random < (50 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl || StateNo = 40 || StateNo = 52 && (P2StateNo = [120,140]) && Random < (250 * (AILevel ** 2 / 64.0))
trigger3 = var(5) && Random < (50 * (AIlevel ** 2 / 64.0))



[State -1, EX Shadow Blade ai ]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1230
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2 && statetype != A
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = p2bodydist x = [70,150]
triggerall = p2bodydist y = [-300,-100]
triggerall = !enemy,numproj
triggerall = Random < (10 * (AILevel ** 2 / 64.0)) || enemynear,life <=300 || var(20) <= 0
triggerall = Ctrl || (stateno = 52 || stateno = 40)
trigger1 = enemynear(var(59)),movetype = A
trigger1 = random <= 150
trigger2 = random <= 100
trigger2 = p2statetype= a
trigger3 = (StateNo =[200, 500])
trigger3 = (MoveHit= [1,5]) && Random < (250 * (AILevel ** 2 / 64.0))





[State -1, Air Soul Fist(Normal) ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1100
triggerAll = (P2BodyDist x = [65,200]) && (P2Dist y > 20)
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType = A
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)

trigger1 = ctrl && Random < (35 *(AILevel ** 2 / 64.0))







[State -1, Air Soul Fist(Arrange) ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1101
triggerAll = (P2BodyDist x = [65,200]) && (P2Dist y > 20)
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType = A
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)

trigger1 = ctrl && Random < (35 *(AILevel ** 2 / 64.0))







[State -1, Air EX Soul Fist ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1130
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerall = Random < (5 * (AILevel ** 2 / 64.0)) || enemynear,life <=300 || var(20) <= 0
triggerAll = (P2BodyDist x = [65,150]) && (P2Dist y > 30)
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = var(3)!=[1,2]
triggerall = ctrl && pos y <= -30 || var(5)

trigger1 = ctrl
trigger1 = Random < (15 *(AILevel ** 2 / 64.0))









[State -1, Vector Drain ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1300
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [0,60])
trigger1 = ctrl && Random < (175 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl && (P2StateNo = [120,140]) && Random < (250 * (AILevel ** 2 / 64.0))
trigger2 = var(5) && Random < (175 * (AIlevel ** 2 / 64.0))




[State -1, Shadow Blade ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1200
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = p2stateno != [154,155]
triggerall = p2bodydist x = [-5,80]
triggerall = p2bodydist y = [-300,0]
triggerall = statetype != A && Ctrl || ((stateno = 100 || stateno = 101 || stateno = 450 || stateno = 250 ) && Movecontact)
trigger1 = enemynear(var(59)),movetype = A
trigger1 = random <= 150
trigger2 = random <= 100
trigger2 = p2statetype= a
trigger3 = (StateNo =[200, 500])
trigger3 = (MoveHit= [2,5]) && Random < (250 * (AILevel ** 2 / 64.0))





[State -1, EX Soul Fist ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1030
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)


triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = Random < (5 * (AILevel ** 2 / 64.0)) || enemynear,life <=300 || var(20) <= 0
triggerall = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101]) || ((stateno= [200,500]) && movehit = [2,5])
triggerall = RoundState = 2 && StateType != A
triggerAll = AILevel && numenemy
triggerAll = p2StateType != l
triggerall = (p2dist y =[-110,0])
trigger1= Random < (80 * (AILevel ** 2 / 64.0)) && movehit











[State -1, Soul Fist(Arrange)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1001
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = PalNo>=7
triggerAll = p2StateType != l
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(5)
triggerAll = AILevel && numenemy
triggerall = (p2dist y =[-110,0])
triggerAll = P2BodyDist x > 120 &&  P2movetype != A
trigger1= Random < (25 * (AILevel ** 2 / 64.0))







[State -1, Soul Fist(Normal) ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value =  1000
triggerAll = p2StateType != l
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)

triggerall = PalNo<=6
triggerall = (p2dist y =[-110,0])
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(5)
triggerAll = AILevel && numenemy
triggerAll = P2BodyDist x > 120 &&  P2movetype != A
trigger1= Random < (25 * (AILevel ** 2 / 64.0))










[State -1, Darkness Illusion ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3400
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
triggerAll = p2StateType != l
triggerAll = AILevel && numenemy
triggerall = RoundState = 2
triggerAll = P2BodyDist x <= 150
triggerAll = P2BodyDist y  = [-30,0]

triggerall= Random < (350 * (AILevel ** 2 / 64.0))
trigger1= (stateno = [200,699]) && movehit=[1,10]
trigger2= (stateno=[200,201]) && movehit=[1,10]
trigger3= (stateno=[210,211]) && movehit=[1,10]
trigger4= stateno=221 && movehit=[1,10]
trigger5= stateno=225 && movehit=[1,10]
trigger6= (stateno=[230,240]) && movehit=[1,10]
trigger7= stateno=400 && movehit=[1,10]
trigger8= stateno=410 && movehit=[1,10]
trigger9= (stateno=[430,450]) && movehit=[1,10]
trigger10= (stateno=[600,650]) && (movehit=[1,8]) && pos y <= -20
trigger11= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger12= stateno=1200 && movehit && movetype=A
trigger13= stateno=1230 && movehit && movetype=A







[State -1, MAX Valkyrie Turn ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3250
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || var(7)
triggerAll = p2StateType != l
triggerAll = AILevel && numenemy
triggerall = RoundState = 2
triggerAll = P2BodyDist x <= 150

triggerall = (facing=1 && (enemy,facing=-1)) || (facing=-1 && (enemy,facing=1))
triggerall = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (145 * (AILevel ** 2 / 64.0))

trigger1 = enemynear,movetype=A && (p2bodydist x=[0,40])&&(p2bodydist y=[0,0])
trigger2 = ((enemynear,numproj) || (enemynear,numhelper)) && inguarddist && p2bodydist x>=25
trigger3 = RoundState = 2 && InGuardDist
trigger3 = ctrl && (StateNo != [120, 155]) && !var(20)
trigger3 = !var(26) || P2BodyDist x >= 40
trigger3 = !(EnemyNear, HitDefAttr = SCA, AT) && (EnemyNear, Time < 120)
trigger3 = StateType != A || P2StateType = A
trigger3 = ifElse(StateType = A, ((var(3) != [1, 2]) || StateNo = 5210), 1)
trigger3 = Random <  (ifElse((P2StateNo = [200, 699]), 125, ifElse((P2StateNo = [1000,2999]), 333, 1000)) * (AILevel ** 2 / 64.0))







[State -1, Finishing Shower ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3300
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = PalNo>=7
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = RoundState = 2
triggerAll = AILevel && numenemy
triggerAll = p2StateType != l
triggerall = (p2dist y =[-110,0])
trigger1= Random < (10 * (AILevel ** 2 / 64.0))
trigger1 = ctrl || StateNo = 40 || StateNo = 52 && (p2bodydist x =[80,250])
trigger2 = var(6) || var(7)
trigger2= Random < (80 * (AILevel ** 2 / 64.0)) && movehit











[State -1, Silhouette Blade ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3150
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = PalNo>=7
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = p2stateno != [154,155]
triggerall = p2bodydist x = [50,125]
triggerall = p2bodydist y = [-300,0]
triggerall = p2statetype= a || p2movetype = h
trigger1= stateno=3000 && animelemtime(16)<0 && var(12)
trigger2= stateno=3020 && animelemtime(16)<0 && var(12) && pos y <= -20
trigger3= stateno=3100 && movecontact && movetype=A && (animelemtime(4)<0 || animelemtime(9)>=0)
trigger4= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [50,125]) && (p2movetype = h|| statetype = a)





[State -1, MAX Cardinal Blade(Normal) ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3110
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = PalNo<=6
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = p2stateno != [154,155]
triggerall = p2bodydist x = [0,50]
triggerall = p2bodydist y = [-300,0]
triggerall = p2statetype= a || p2movetype = h
trigger1= stateno=3000 && animelemtime(16)<0 && var(12)
trigger2= stateno=3020 && animelemtime(16)<0 && var(12) && pos y <= -20
trigger3= stateno=3100 && movecontact && movetype=A && (animelemtime(4)<0 || animelemtime(9)>=0)
trigger4= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,50]) && (p2movetype = h|| statetype = a)



[State -1, Cardinal Blade ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3100
triggerall = AILevel && NumEnemy
triggerall = roundstate = 2
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = enemynear(var(59)),statetype != L
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = p2stateno != [154,155]
triggerall = p2bodydist x = [0,50]
triggerall = p2bodydist y = [-300,0]
triggerall = p2statetype= a || p2movetype = h
trigger1= (stateno = [200,699]) && Time <= 2
trigger2= (stateno=[200,201]) && movecontact=[1,10]
trigger3= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,50]) && (p2movetype = h|| statetype = a)









[State -1, MAX Air Soul Phoenix]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3060
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && numenemy
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || var(7)
triggerall = RoundState = 2 && StateType = A
triggerall = ctrl && pos y <= -30 || var(6) || var(7)
triggerAll = (P2BodyDist x = [65,150]) && (P2Dist y > 30)
triggerall = Random < (520 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,200]) && (p2movetype = h|| !inguarddist)

triggerall =(EnemyNear, GetHitVar(HitTime) >= 4) || !inguarddist
trigger1= stateno=3000 && animelemtime(16)<0 && var(12)
trigger2= stateno=3020 && animelemtime(16)<0 && var(12) && pos y <= -20
trigger3= stateno=3100 && movecontact && movetype=A && (animelemtime(4)<0 || animelemtime(9)>=0)
trigger4= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [50,150]) && (p2movetype = h|| !inguarddist)


























[State -1, MAX Soul Phoenix ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3050
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && numenemy
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || var(7)
triggerall = RoundState = 2 && StateType != A
triggerAll = p2StateType != l
triggerall = (p2dist y =[-110,0])
triggerall = Random < (520 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,200]) && p2movetype = h

triggerall =(EnemyNear, GetHitVar(HitTime) >= 4)
trigger1= stateno=3000 && animelemtime(16)<0 && var(12)
trigger2= stateno=3020 && animelemtime(16)<0 && var(12) && pos y <= -20
trigger3= stateno=3100 && movecontact && movetype=A && (animelemtime(4)<0 || animelemtime(9)>=0)
trigger4= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A




[State -1, Valkyrie Turn ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3200
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6)
triggerAll = p2StateType != l
triggerAll = AILevel && numenemy
triggerall = RoundState = 2
triggerAll = P2BodyDist x <= 100
triggerall = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (145 * (AILevel ** 2 / 64.0))
trigger1 = enemynear,movetype=A && (p2bodydist x=[0,40])&&(p2bodydist y=[0,0])
trigger2 = ((enemynear,numproj) || (enemynear,numhelper)) && inguarddist && p2bodydist x>=25







[State -1, Air Soul Phoenix ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3020
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && numenemy
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl && pos y <= -30 || var(6)
triggerall = RoundState = 2 && StateType = A
triggerall = ctrl && pos y <= -30 || var(6)
triggerAll = (P2BodyDist x = [65,150]) && (P2Dist y > 30)
triggerall = Random < (520 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,200]) && (p2movetype = h|| !inguarddist)

triggerall =(EnemyNear, GetHitVar(HitTime) >= 3) || !inguarddist

trigger1= (stateno = [200,699]) && Time <= 2
trigger2= (stateno=[200,201]) && movecontact=[1,10]
trigger3= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [50,150]) && (p2movetype = h|| !inguarddist)


















[State -1, Soul Phoenix ai]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3000
triggerall = !IsHelper(10371)
triggerall = numhelper(10371)
triggerAll = AILevel && numenemy
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6)
triggerall = RoundState = 2 && StateType = A
triggerall = ctrl && pos y <= -30 || var(6) || var(7)
triggerAll = (P2BodyDist x = [65,150]) && (P2Dist y > 30)
triggerall = Random < (520 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [0,200]) && (p2movetype = h|| !inguarddist)

triggerall =(EnemyNear, GetHitVar(HitTime) >= 4) || !inguarddist
trigger1= (stateno = [200,699]) && Time <= 2
trigger5= (stateno=[200,201]) && movecontact=[1,10]
trigger6= (stateno=[210,211]) && movecontact=[1,10]
trigger7= stateno=221 && movecontact=[1,10]
trigger8= stateno=225 && movecontact=[1,10]
trigger9= (stateno=[230,240]) && movecontact=[1,10]
trigger10= stateno=400 && movecontact=[1,10]
trigger11= stateno=410 && movecontact=[1,10]
trigger12= (stateno=[430,450]) && movecontact=[1,10]
trigger13= (stateno=[600,650]) && (movecontact=[1,8]) && pos y <= -20
trigger14= (stateno=[1000,1130]) && (animelemtime(6)>1 && animelemtime(8)<0)
trigger15= stateno=1200 && movecontact && movetype=A
trigger16= stateno=1230 && movecontact && movetype=A
trigger17= ctrl && Random < (120 * (AILevel ** 2 / 64.0)) && (p2bodydist x = [50,150]) && (p2movetype = h|| !inguarddist)






