


[Command]
name = "Evil_Scream"
command = ~D,DF,F,D,DF,F,a+b
time = 25

[Command]
name = "Evil_Scream"
command = ~D,DF,F,D,DF,F,b+c
time = 25

[Command]
name = "Evil_Scream"
command = ~D,DF,F,D,DF,F,a+c
time = 25

[Command]
name = "Hell_Dunk"
command = ~D,DF,F,D,DF,F,x
time = 25

[Command]
name = "Hell_Dunk"
command = ~D,DF,F,D,DF,F,y
time = 25

[Command]
name = "Hell_Dunk"
command = ~D,DF,F,D,DF,F,z
time = 25

[Command]
name = "Death_Voltage"
command = ~D,DB,B,D,DB,B,a
time = 25

[Command]
name = "Death_Voltage"
command = ~D,DB,B,D,DB,B,b
time = 25

[Command]
name = "Death_Voltage"
command = ~D,DB,B,D,DB,B,c
time = 25


[Command]
name = "Dark_Force"
command = ~D,DB,B,D,DB,B,x
time = 25


[Command]
name = "Dark_Force"
command = ~D,DB,B,D,DB,B,y
time = 25


[Command]
name = "Dark_Force"
command = ~D,DB,B,D,DB,B,z
time = 25




[Command]
name = "Pursuit"
command = $U, x

[Command]
name = "Pursuit"
command = $U, y

[Command]
name = "Pursuit"
command = $U, z

[Command]
name = "Skull_Punish"
command = ~F, D, B, x
time = 30

[Command]
name = "Skull_Punish"
command = ~F, D, B, y
time = 30

[Command]
name = "Skull_Punish"
command = ~F, D, B, z
time = 30

[Command]
name = "Hell_Gate_a"
command = ~B, D, F, a
time = 20

[Command]
name = "Hell_Gate_b"
command = ~B, D, F, b
time = 20

[Command]
name = "Hell_Gate_c"
command = ~B, D, F, c
time = 20

[Command]
name = "Death_Copter_a"
command = ~D, DB, B, a
time = 20

[Command]
name = "Death_Copter_b"
command = ~D, DB, B, b
time = 20

[Command]
name = "Death_Copter_c"
command = ~D, DB, B, c
time = 20

[Command]
name = "Skull_Sting_a"
command = ~D, DF, F, a
time = 20

[Command]
name = "Skull_Sting_b"
command = ~D, DF, F, b
time = 20

[Command]
name = "Skull_Sting_c"
command = ~D, DF, F, c
time = 20


[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10


[Command]
name = "recovery"
command = x+y
time = 1


[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1


[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1

[Command]
name = "longjump"
command = $D, $U
time = 15


[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_y"
command = /y
time = 1


[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1






;   --- Uno Tag System [Type-R] Command definition ---

[Command]
name = "aHsoNn"
command = ~D, D, D, z+c
Time = 25

[Command]
name = "sheoun"
command = ~D, DF, F, z+c
Time = 25

[Command]
name = "palit"
command = z+c
Time = 2

[Command]
name = "turtleuno"
command = s
Time = 2


[Statedef -1]


[State -1, Partner Assist]
type = VarSet
sysvar(4) = 10
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 60 && Time > 0
triggerall = teammode = Simul
triggerall = StateNo != [3000,1251199]
triggerall = hitdefattr != SCA, HA, HP, HT
triggerAll = StateNo != [130,152]
triggerall = !(StateNo = [5000,5500])
triggerall = Power >= 500
trigger1 = command = "turtleuno"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = !ctrl && Movetype = A
trigger2 = Random < (((2 * ifelse(MoveContact, ifelse(MoveHit, 2, 3),1)) + (UniqHitCount * 2)) *(AILevel**2/64.0))
trigger3 = AILevel >  0
trigger3 = StateNo = [190,199]
trigger3 = AnimElemNo(0) = 2
ignorehitpause = 1

[State -1, Team Hyper Attack]
type = ChangeState
value = 1251125
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = Partner, life > 0
triggerall = power >= 3000
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 9		
triggerall= (StateType != A)
trigger1 = command = "sheoun"
trigger1 = (Ctrl = 1)
trigger1 = AILevel <=  0
trigger2 = command = "sheoun"
trigger2 = Anim = [200,1000]
trigger2 = movetype = A
trigger2 = hitdefattr = SC, NA
trigger2 = MoveContact
trigger2 = AILevel <=  0
trigger3 = AILevel > 0 && ctrl
trigger3 = Random < (10 + ((Life < Lifemax/6)*3))
trigger3 = NumEnemy && enemy, pos x = [0,200]
trigger4 = AILevel >  0
trigger4 = Anim = [200,1000]
trigger4 = movetype = A
trigger4 = hitdefattr = SC, NA
trigger4 = MoveContact
trigger4 = Random < (11 + ((MoveHit)*5) + ((Life < Lifemax/6)*5))
ignorehitpause = 1

[State -1, Delayed Hyper]
type = ChangeState
value = 1251127
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0
triggerall = power >= 1000
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time > 1 && Time > 45
triggerall = movetype = A
triggerall = StateNo = [2000,1251100]
triggerall = hitdefattr = SCA, HA, HP, HT || (StateNo >= 2000 && StateNo < 4000 && (hitcount < 8 || NumTarget && Target, GetHitVar(hitTime) >= 0))
trigger1 = command = "sheoun"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = NumTarget && MoveContact
trigger2 = Random < (10*(AILevel**2/64.0) + (Uniqhitcount*((Life < Partner,Life)*2)))
trigger2 = Partner, Time > 35
trigger3 = AILevel >  0
trigger3 = Partner, Time > 30 && Time > 25
trigger3 = HitCount >= 6
trigger3 = Random < (2 * Uniqhitcount * ifelse(hitcount > 9, 2, 1))
ignorehitpause = 1

[State -1, UNO Mode]
type = ChangeState
value = 1251128
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0 && Power >= 1000
triggerall = Life <= (Lifemax/8)
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 20
triggerall = (StateType != A) && ((Ctrl = 1) || StateNo = 0 || (Movetype = A && hitdefattr = SC, NA))
trigger1 = command = "aHsoNn"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Partner, Life < Lifemax/4
trigger2 = Random < ((25 + ifelse((Partner, Life < Lifemax/6), 25, 5))*(AILevel**2/64.0))

[State -1, Change Attack]
type = ChangeState
value = 1251126
triggerall = NumPartner
triggerall = (sysvar(4) = 1 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),250,500)) || (sysvar(4) = 15 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),500,1000))
triggerall = Partner, life > 0
triggerall = movetype = A && !MoveReversed
triggerall = (Partner, StateNo = 1251112 || Partner, StateNo = 1251114)  && Time > 1
triggerall = StateNo = [200,4850]
triggerall = StateNo != [1251102,1251105]
triggerall = NumTarget > 0 && Target, pos Y > -160
triggerall = (Target, StateNo != [5110,5955])
triggerall = Hitdefattr != SCA, NT && ((Target, Statetype = A || (Hitdefattr != A, NA && Target, Statetype != A)) && ((!Target, HitOver || EnemyNear, StateNo = [5000,5900]) && (MoveContact || ProjContactTime(0) < 8)))
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = UniqHitCount >= 2
trigger2 = Random < (((ifelse(sysvar(4)=15,25,50)*(AILevel**2/64.0)) + ((hitdefattr = SCA, SA, HA)*15) + ifelse(lifemax/life > 15, 15, lifemax/life)))
trigger2 = Partner, Life > Lifemax/10 || Life <= Partner, Life
trigger2 = Partner, Time > 25
trigger3 = AILevel >  0
trigger3 = Partner, Time > 27
trigger3 = Random < (25*(2*(Life = (Lifemax/4) && Life < Partner, Life)) *(AILevel**2/64.0))
trigger3 = MoveContact
ignorehitpause = 1

[State -1, TagIn]
type = ChangeState
value = 1251110
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner && NumEnemy
triggerall = RoundState = 2 
triggerall = Partner, life > 0
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 40	
triggerall = (MoveType != A && StateType != A) && (Ctrl = 1) || StateNo = 0
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Random < (ifelse((LifeMax/Life > 120), 120, LifeMax/Life)+((EnemyNear,statetype=L)*25))
trigger2 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond
trigger2 = EnemyNear, movetype != A
trigger3 = AILevel >  0
trigger3 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond && Life < LifeMax * (LifeMax*0.55)
trigger3 = Random < ((ifelse(LifeMax/Life > 10, 10, LifeMax/Life) + (10+ifelse((EnemyNear, StateNo > 5000),25,1))) * ifelse((Life < Partner, Life), 1.45, 0.5))
trigger3 = Partner, Time > 1 * TicksPerSecond
trigger3= EnemyNear, statetype = L || p2bodydist x > 250 && EnemyNear, movetype != A
trigger4 = AILevel >  0
trigger4 = Life < 150 && Life < Partner, Life
trigger4 = EnemyNear, statetype = L || p2bodydist x > 200 && EnemyNear, movetype != A
trigger4 = Random < (125*(AILevel**2/64.0))

[State -1, C_6]
type = CtrlSet
value = 1
triggerall = RoundState = 2 && NumPartner
triggerall = NumTarget && Target, StateNo != [200,4999]
triggerall = StateNo != 1251106 && !Ctrl
triggerall = (Partner, StateNo != [1251128,1251129]) && (Partner, PrevStateNo != [1251128,1251129])
trigger1 = command="x"||command="y"||command="z"||command="a"||command="b"||command="c"
trigger1 = sysvar(4) = 7
trigger1 = Movetype = A
trigger1 = MoveContact
trigger1 = hitdefattr = SCA, NA, SA
trigger1 = StateNo != PrevStateNo
trigger1 = Time > 3
trigger2 = PrevStateNo = 1251106
ignorehitpause = 0

; ------ Uno Tag System [Type-R] END LINE -------

;  ;]





[state 0]
type=selfstate
trigger1=ctrl && numpartner && !ishelper && roundstate=2 && pos y=0
trigger1=sysfvar(4)>0 && sysfvar(0)>0 && playeridexist(floor(sysfvar(0)))
trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(22)=4
value=190190
ctrl=0
ignorehitpause=1











[State -1, Dark Force]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 2900 + 50*(var(12)=1)
triggerall = !ailevel
triggerall = command = "Dark_Force"
triggerall = power >= 1000 || var(12)=1
trigger1 = statetype = S
trigger1 = ctrl






[State -1, Evil Scream]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1400
triggerall = !ailevel
triggerall = command = "Evil_Scream"
triggerall = !var(12)
triggerall = power >= 3000
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Hell Dunk]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 2000
triggerall = !ailevel
triggerall = command = "Hell_Dunk"
triggerall = !var(12)
triggerall = power >= 1000
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Death Voltage]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1140 + 51*(statetype = A)
triggerall = !ailevel
triggerall = command = "Death_Voltage"
triggerall = !var(12)
triggerall = power >= 1000
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = statetype = A
trigger2 = ctrl






[State -1, Skull Punish]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1300
triggerall = !ailevel
triggerall = command = "Skull_Punish"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Hell Gate]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1500
triggerall = !ailevel
triggerall = command = "Hell_Gate_a"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Hell Gate]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1510
triggerall = !ailevel
triggerall = command = "Hell_Gate_b"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Hell Gate]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1520
triggerall = !ailevel
triggerall = command = "Hell_Gate_c"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl


[State -1, Death Copter]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1100 + 50*(statetype = A)
triggerall = !ailevel
triggerall = command = "Death_Copter_a"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = statetype = A
trigger2 = ctrl


[State -1, Death Copter]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1110 + 50*(statetype = A)
triggerall = !ailevel
triggerall = command = "Death_Copter_b"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = statetype = A
trigger2 = ctrl


[State -1, Death Copter]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1120 + 50*(statetype = A)
triggerall = !ailevel
triggerall = command = "Death_Copter_c"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = statetype = A
trigger2 = ctrl


[State -1, Skull Sting]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1200 + 50*(statetype = A)
triggerall = !ailevel
triggerall = command = "Skull_Sting_a"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = statetype = A
trigger2 = ctrl


[State -1, Skull Sting]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1210 + 50*(statetype = A)
triggerall = !ailevel
triggerall = command = "Skull_Sting_b"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = statetype = A
trigger2 = ctrl


[State -1, Skull Sting]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1220 + 50*(statetype = A)
triggerall = !ailevel
triggerall = command = "Skull_Sting_c"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = statetype = A
trigger2 = ctrl



[State -1, Pursuit Attack]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1000
triggerall = command = "Pursuit"
triggerall = P2StateNo = 5110
trigger1 = StateType = S
trigger1 = ctrl
trigger2 = StateNo = 40

[State -1, roll / dodge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = ifelse(command = "holdfwd", 10720, 10710)
triggerall = !AIlevel
triggerall = !var(12)
trigger1 = command = "x" && command = "a"
trigger1 = roundstate = 2 && statetype != A && (ctrl || stateno = 100)

[State -1, powercharge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 10740
triggerall = !var(12)
triggerall = !AIlevel
trigger1 = command = "hold_b" && command = "hold_y"
trigger1 = roundstate = 2 && statetype != A && ctrl
trigger1 = power < const(data.power) && power < powermax

[State -1, Zero Counter]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1600
triggerall = !ailevel
triggerall = !var(12)
trigger1 = stateno = 150 || stateno = 152
trigger1 = (command = "c" && command = "z")
trigger1 = roundstate = 2 && power >= 1000 && statetype != A






[State -1, Run Fwd]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 100 + 3510*(var(12)=1)
triggerall = !ailevel
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl



[State -1, Run Back]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 105 + 3510*(var(12)=1)
triggerall = !ailevel
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl





[State -1, Throw1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 800
triggerall = !ailevel
triggerall = command = "y" || command = "z"
triggerall = command = "holdfwd"
triggerall = command != "holddown"
triggerall = !var(12)
triggerall = p2bodydist X<20
triggerall = p2statetype != A
trigger1 = statetype = S
trigger1 = ctrl

[State -1, Throw2]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 850
triggerall = !ailevel
triggerall = command = "b" || command = "c"
triggerall = command = "holdfwd"
triggerall = command != "holddown"
triggerall = !var(12)
triggerall = p2bodydist X<20
triggerall = p2statetype != A
trigger1 = statetype = S
trigger1 = ctrl






[State -1, Stand Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 200 + 100*(command = "holdfwd")
triggerall = !ailevel
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 200
trigger2 = time > 5


[State -1, Stand Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 210 + 100*(command = "holdfwd" && p2bodydist X>10)
triggerall = !ailevel
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 200
trigger2 = movecontact
trigger3 = stateno = 250
trigger3 = movecontact
trigger4 = stateno = 300
trigger4 = movecontact
trigger5 = stateno = 350
trigger5 = movecontact
trigger6 = stateno = 400
trigger6 = movecontact
trigger7 = stateno = 450
trigger7 = movecontact


[State -1, Stand Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 220 + 100*(command = "holdfwd" && p2bodydist X>10)
triggerall = !ailevel
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1  = statetype = S
trigger1  = ctrl
trigger2  = stateno = 200
trigger2  = movecontact
trigger3  = stateno = 210
trigger3  = movecontact
trigger4  = stateno = 250
trigger4  = movecontact
trigger5  = stateno = 260
trigger5  = movecontact
trigger6  = stateno = 300
trigger6  = movecontact
trigger7  = stateno = 310
trigger7  = movecontact
trigger8  = stateno = 350
trigger8  = movecontact
trigger9  = stateno = 360
trigger9  = movecontact
trigger10 = stateno = 400
trigger10 = movecontact
trigger11 = stateno = 410
trigger11 = movecontact
trigger12 = stateno = 450
trigger12 = movecontact
trigger13 = stateno = 460
trigger13 = movecontact


[State -1, Stand Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 250 + 100*(command = "holdfwd")
triggerall = !ailevel
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 200
trigger2 = movecontact
trigger3 = stateno = 300
trigger3 = movecontact
trigger4 = stateno = 400
trigger4 = movecontact


[State -1, Standing Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 260 + 100*(command = "holdfwd" && p2bodydist X>10)
triggerall = !ailevel
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 200
trigger2 = movecontact
trigger3 = stateno = 210
trigger3 = movecontact
trigger4 = stateno = 250
trigger4 = movecontact
trigger5 = stateno = 300
trigger5 = movecontact
trigger6 = stateno = 310
trigger6 = movecontact
trigger7 = stateno = 350
trigger7 = movecontact
trigger8 = stateno = 400
trigger8 = movecontact
trigger9 = stateno = 410
trigger9 = movecontact
trigger10 = stateno = 450
trigger10 = movecontact


[State -1, Stand Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 270 + 100*(command = "holdfwd" && p2bodydist X>10)
triggerall = !ailevel
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = S
trigger1 = ctrl
trigger2  = stateno = 200
trigger2  = movecontact
trigger3  = stateno = 210
trigger3  = movecontact
trigger4  = stateno = 220
trigger4  = movecontact
trigger5  = stateno = 250
trigger5  = movecontact
trigger6  = stateno = 260
trigger6  = movecontact
trigger7  = stateno = 300
trigger7  = movecontact
trigger8  = stateno = 310
trigger8  = movecontact
trigger9  = stateno = 320
trigger9  = movecontact
trigger10  = stateno = 350
trigger10  = movecontact
trigger11  = stateno = 360
trigger11  = movecontact
trigger12 = stateno = 400
trigger12 = movecontact
trigger13 = stateno = 410
trigger13 = movecontact
trigger14 = stateno = 420
trigger14 = movecontact
trigger15 = stateno = 450
trigger15 = movecontact
trigger16 = stateno = 460
trigger16 = movecontact


[State -1, DF]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3200
triggerall = !ailevel
triggerall = var(12)
triggerall = command != "holddown"
triggerall = statetype = S
triggerall = ctrl
trigger1 = command = "x"
trigger2 = command = "a"


[State -1, DF]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3210
triggerall = !ailevel
triggerall = var(12)
triggerall = command != "holddown"
triggerall = statetype = S
triggerall = ctrl
trigger1 = command = "y"
trigger2 = command = "b"


[State -1, DF]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3220
triggerall = !ailevel
triggerall = var(12)
triggerall = command != "holddown"
triggerall = statetype = S
triggerall = ctrl
trigger1 = command = "z"
trigger2 = command = "c"



[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 195
triggerall = !ailevel
triggerall = command = "s"
triggerall = !var(12)
trigger1 = statetype != A
trigger1 = ctrl






[State -1, Crouching Walk Fwd]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 101
triggerall = !ailevel
triggerall = command = "holddown"
triggerall = command = "holdfwd"
triggerall = !var(12)
triggerall = stateno = 11
trigger1 = statetype = C
trigger1 = ctrl


[State -1, Crouching Walk Back]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 106
triggerall = !ailevel
triggerall = command = "holddown"
triggerall = command = "holdback"
triggerall = !var(12)
triggerall = stateno = 11
trigger1 = statetype = C
trigger1 = ctrl


[State -1, Crouching Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 400
triggerall = !ailevel
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 400
trigger2 = time > 3


[State -1, Crouching Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 410
triggerall = !ailevel
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 200
trigger2 = movecontact
trigger3 = stateno = 250
trigger3 = movecontact
trigger4 = stateno = 300
trigger4 = movecontact
trigger5 = stateno = 350
trigger5 = movecontact
trigger6 = stateno = 400
trigger6 = movecontact
trigger7 = stateno = 450
trigger7 = movecontact


[State -1, Crouching Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 420
triggerall = !ailevel
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = C
trigger1 = ctrl
trigger2  = stateno = 200
trigger2  = movecontact
trigger3  = stateno = 210
trigger3  = movecontact
trigger4  = stateno = 250
trigger4  = movecontact
trigger5  = stateno = 260
trigger5  = movecontact
trigger6  = stateno = 300
trigger6  = movecontact
trigger7  = stateno = 310
trigger7  = movecontact
trigger8  = stateno = 350
trigger8  = movecontact
trigger9  = stateno = 360
trigger9  = movecontact
trigger10 = stateno = 400
trigger10 = movecontact
trigger11 = stateno = 410
trigger11 = movecontact
trigger12 = stateno = 450
trigger12 = movecontact
trigger13 = stateno = 460
trigger13 = movecontact




[State -1, Crouching Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 450
triggerall = !ailevel
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 200
trigger2 = movecontact
trigger3 = stateno = 300
trigger3 = movecontact
trigger4 = stateno = 400
trigger4 = movecontact


[State -1, Crouching Medium Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 460
triggerall = !ailevel
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 200
trigger2 = movecontact
trigger3 = stateno = 210
trigger3 = movecontact
trigger4 = stateno = 250
trigger4 = movecontact
trigger5 = stateno = 300
trigger5 = movecontact
trigger6 = stateno = 310
trigger6 = movecontact
trigger7 = stateno = 350
trigger7 = movecontact
trigger8 = stateno = 400
trigger8 = movecontact
trigger9 = stateno = 410
trigger9 = movecontact
trigger10 = stateno = 450
trigger10 = movecontact


[State -1, Crouching Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 470
triggerall = !ailevel
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = C
trigger1 = ctrl
trigger2  = stateno = 200
trigger2  = movecontact
trigger3  = stateno = 210
trigger3  = movecontact
trigger4  = stateno = 220
trigger4  = movecontact
trigger5  = stateno = 250
trigger5  = movecontact
trigger6  = stateno = 260
trigger6  = movecontact
trigger7  = stateno = 300
trigger7  = movecontact
trigger8  = stateno = 310
trigger8  = movecontact
trigger9  = stateno = 320
trigger9  = movecontact
trigger10  = stateno = 350
trigger10  = movecontact
trigger11  = stateno = 360
trigger11  = movecontact
trigger12 = stateno = 400
trigger12 = movecontact
trigger13 = stateno = 410
trigger13 = movecontact
trigger14 = stateno = 420
trigger14 = movecontact
trigger15 = stateno = 450
trigger15 = movecontact
trigger16 = stateno = 460
trigger16 = movecontact


[State -1, DF]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3400
triggerall = !ailevel
triggerall = var(12)
triggerall = command = "holddown"
triggerall = statetype = C
triggerall = ctrl
trigger1 = command = "x"
trigger2 = command = "y"
trigger3 = command = "z"
trigger4 = command = "a"
trigger5 = command = "b"
trigger6 = command = "c"






[State -1, Jump Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 600
triggerall = !ailevel
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl


[State -1, Jump Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 610
triggerall = !ailevel
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600
trigger2 = movecontact
trigger3 = stateno = 650
trigger3 = movecontact
trigger4 = stateno = 750
trigger4 = movecontact


[State -1, Jump Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 620
triggerall = !ailevel
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600
trigger2 = movecontact
trigger3 = stateno = 610
trigger3 = movecontact
trigger4 = stateno = 650
trigger4 = movecontact
trigger5 = stateno = 660
trigger5 = movecontact
trigger6 = stateno = 760
trigger6 = movecontact



[State -1, Jump Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 650
triggerall = !ailevel
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600
trigger2 = movecontact
trigger3 = stateno = 750
trigger3 = movecontact


[State -1, Jump Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 660
triggerall = !ailevel
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600
trigger2 = movecontact
trigger3 = stateno = 610
trigger3 = movecontact
trigger4 = stateno = 650
trigger4 = movecontact
trigger5 = stateno = 750
trigger5 = movecontact
trigger6 = stateno = 760
trigger6 = movecontact


[State -1, Jump Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 670
triggerall = !ailevel
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600
trigger2 = movecontact
trigger3 = stateno = 610
trigger3 = movecontact
trigger4 = stateno = 620
trigger4 = movecontact
trigger5 = stateno = 650
trigger5 = movecontact
trigger6 = stateno = 660
trigger6 = movecontact
trigger7 = stateno = 750
trigger7 = movecontact
trigger8 = stateno = 760
trigger8 = movecontact
trigger9 = stateno = 770
trigger9 = movecontact

[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 700
triggerall = !ailevel
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl

[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 710
triggerall = !ailevel
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl

[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 720
triggerall = !ailevel
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl

[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 750
triggerall = !ailevel
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl

[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 760
triggerall = !ailevel
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600
trigger2 = movecontact
trigger3 = stateno = 650
trigger3 = movecontact
trigger4 = stateno = 750
trigger4 = movecontact

[State -1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 770
triggerall = !ailevel
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = !var(12)
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600
trigger2 = movecontact
trigger3 = stateno = 610
trigger3 = movecontact
trigger4 = stateno = 650
trigger4 = movecontact
trigger5 = stateno = 660
trigger5 = movecontact
trigger6 = stateno = 760
trigger6 = movecontact


[State -1, DF]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3600
triggerall = !ailevel
triggerall = var(12)
triggerall = statetype = A
triggerall = ctrl
trigger1 = command = "x"
trigger2 = command = "y"
trigger3 = command = "z"
trigger4 = command = "a"
trigger5 = command = "b"
trigger6 = command = "c"





[State -1, taunt]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 195
triggerall = AIlevel && numenemy
triggerall = roundstate = 2 && statetype != A
triggerall = !var(12)
trigger1 = p2dist x > 160 && (enemynear, vel y > 0) && ctrl && random < (100 * (AIlevel ** 2 / 64.0))
trigger1 = !(enemynear, ctrl) && (enemynear, movetype = H)

[State -1, roll / dodge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = ifelse(random < 600, 10720, 10710)
triggerall = !var(12)
trigger1 = AIlevel && numenemy
trigger1 = roundstate = 2 && statetype != A && ctrl && random < (50 * (AIlevel ** 2 / 64.0))
trigger1 = enemynear, movetype = A && p2bodydist x < 80

[State -1, powercharge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 10740
trigger1 = AIlevel && numenemy
triggerall = !var(12)
trigger1 = roundstate = 2 && statetype != A && ctrl
trigger1 = power < const(data.power) && power < powermax
trigger1 = random < (50 * (AIlevel ** 2 / 64.0)) && !inguarddist && p2movetype != A && p2dist x >= 160

[State -1, Counter Attack]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1600
triggerall = !var(12)
trigger1 = AIlevel && numenemy
trigger1 = (p2dist x = [-90, 90]) && stateno = 150 || stateno = 152
trigger1 = roundstate = 2 && power >= 1000 && life < 500 && random < (10 * (AIlevel ** 2 / 64.0))






[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 132
triggerall = p2movetype = A || (enemy, NumProj >= 1)
triggerall = P2bodydist X <= 40 || (enemy, NumProj >= 1)
triggerall = statetype = A
triggerall = random <= 600
triggerall = ailevel
triggerall = ctrl
triggerall = stateno != 132
trigger1 = p2statetype = A
trigger2 = (enemy, NumProj >= 1)


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 130
triggerall = p2movetype = A || (enemy, NumProj >= 1)
triggerall = P2bodydist X <= 40 || (enemy, NumProj >= 1)
triggerall = random <= 400
triggerall = statetype != A
triggerall = ailevel
triggerall = ctrl
triggerall = stateno != 120
trigger1 = p2statetype = S
trigger2 = (enemy, NumProj >= 1)

[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 130
triggerall = p2movetype = A || (enemy, NumProj >= 1)
triggerall = P2bodydist X <= 40 || (enemy, NumProj >= 1)
triggerall = random <= 400
triggerall = statetype != A
triggerall = ailevel
triggerall = ctrl
triggerall = stateno != 130
trigger1 = p2statetype = A
trigger2 = (enemy, NumProj >= 1)



[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 131
triggerall = p2movetype = A || (enemy, NumProj >= 1)
triggerall = P2bodydist X <= 40 || (enemy, NumProj >= 1)
triggerall = statetype != A
triggerall = random <= 400
triggerall = ailevel
triggerall = ctrl
triggerall = stateno != 131
trigger1 = p2statetype = C
trigger2 = (enemy, NumProj >= 1)






[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 40
triggerall = p2movetype != A
triggerall = P2bodydist X >=100
triggerall = random = [200,499]
triggerall = statetype != A
triggerall = ailevel
triggerall = ctrl
trigger1 = p2statetype != L


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = ailevel
triggerall = (StateType != A) && (StateType != L)
triggerall = (P2MoveType = A) && (P2StateType != A) && (enemy, NumProj >= 1)
triggerall = StateNo != 40
trigger1 = Ctrl
value = 40





[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 2000
triggerall = p2movetype != A
triggerall = P2bodydist X >= 100
triggerall = ailevel
triggerall = !var(12)
triggerall = random < 400
triggerall = ctrl
triggerall = statetype != A
triggerall = p2statetype = S
trigger1 = power >= 1000


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1140 + 51*(statetype = A)
triggerall = p2movetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = P2bodydist X <= 170
triggerall = random = [400,599]
triggerall = ctrl
triggerall = statetype = S || (statetype = A && (vel Y <=1 && vel Y>=-1))
triggerall = p2statetype = S
trigger1 = power >= 1000


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1400
triggerall = p2movetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = P2bodydist X <= 170
triggerall = P2bodydist X >= 10
triggerall = random = [600,899]
triggerall = ctrl
triggerall = statetype != A
triggerall = p2statetype = S
trigger1 = power >= 3000


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 2900
triggerall = p2movetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = random >= 975
triggerall = ctrl
triggerall = statetype != A
triggerall = power >= 1000
trigger1 = p2statetype != L




[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3200
triggerall = p2movetype != A
triggerall = P2bodydist X <= 120
triggerall = random < 300
triggerall = statetype != A
triggerall = ailevel
triggerall = var(12)
triggerall = ctrl
trigger1 = p2statetype != L

[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3210
triggerall = p2movetype != A
triggerall = P2bodydist X <= 150
triggerall = random = [300,600]
triggerall = statetype != A
triggerall = ailevel
triggerall = var(12)
triggerall = ctrl
trigger1 = p2statetype != L

[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3220
triggerall = p2movetype != A
triggerall = P2bodydist X <= 50
triggerall = random = [600,900]
triggerall = statetype != A
triggerall = ailevel
triggerall = var(12)
triggerall = ctrl
trigger1 = p2statetype != L

[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3220
triggerall = p2movetype != A
triggerall = P2bodydist X >= 170
triggerall = statetype != A
triggerall = ailevel
triggerall = var(12)
triggerall = ctrl
trigger1 = p2statetype != L

[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3600
triggerall = p2movetype != A
triggerall = P2bodydist X <= 50
triggerall = vel Y <=1 && vel Y>=-1
triggerall = random < 500
triggerall = statetype = A
triggerall = ailevel
triggerall = var(12)
triggerall = ctrl
triggerall = stateno != 3610
trigger1 = p2statetype != L





[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1500 + 20*(random <= 10)
triggerall = p2movetype != A
triggerall = random <= 20
triggerall = statetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1120
triggerall = p2movetype != A
triggerall = P2bodydist X <= 20
triggerall = random < 200
triggerall = statetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1220
triggerall = p2movetype != A
triggerall = P2bodydist X = [100,200]
triggerall = random = [500,599]
triggerall = statetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L


[State -1, Pursuit AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1000
triggerall = ailevel
triggerall = !var(12)
trigger1 = P2StateNo = 5110
trigger1 = StateType = S || StateType = C
trigger1 = ctrl
trigger1 = Random <= 400




[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 320
triggerall = p2movetype != A
triggerall = P2bodydist X = [100,150]
triggerall = random = [600,749]
triggerall = statetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L

[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 370
triggerall = p2movetype != A
triggerall = P2bodydist X = [100,150]
triggerall = random = [750,899]
triggerall = statetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L

[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 220
triggerall = p2movetype != A
triggerall = P2bodydist X <= 80
triggerall = random <= 150
triggerall = statetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L





[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1300
triggerall = p2movetype != A
triggerall = P2bodydist X <= 20
triggerall = random = [600,699]
triggerall = statetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 800
triggerall = p2movetype != A
triggerall = P2bodydist X <= 20
triggerall = random = [700,899]
triggerall = statetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 850
triggerall = p2movetype != A
triggerall = P2bodydist X <= 20
triggerall = random >= 900
triggerall = statetype != A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L





[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 620 + 50*(random >= 500)
triggerall = p2movetype != A
triggerall = P2bodydist X <= 50
triggerall = vel Y <=1 && vel Y>=-1
triggerall = random < 500
triggerall = statetype = A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L

[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 700 + 20*(random >= 500)
triggerall = p2movetype != A
triggerall = P2bodydist X >= 100 && P2bodydist X <= 150
triggerall = vel Y <=1 && vel Y>=-1
triggerall = statetype = A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype = S


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1170
triggerall = p2movetype != A
triggerall = random <= 300
triggerall = P2bodydist X >= 80
triggerall = vel Y <=1 && vel Y>=-1
triggerall = statetype = A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L


[State -2, AI]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1270
triggerall = p2movetype != A
triggerall = random >= 700
triggerall = P2bodydist X >= 80
triggerall = vel Y <=1 && vel Y>=-1
triggerall = statetype = A
triggerall = ailevel
triggerall = !var(12)
triggerall = ctrl
trigger1 = p2statetype != L

[State -2]
type = Posset
triggerall = ailevel
triggerall = stateno = 0
trigger1 = Pos Y > 5
trigger2 = Pos Y <-5
y = 0
