; _________________________________________
;| Sasquatch by varo_hades                 |
; �����������������������������������������
;==============================================================================================
;=======================================<HELPER STATES>========================================
;==============================================================================================

;====================<PARRY HELPER>=========================
[StateDef 765]
type = A
physics = N
moveType = I
anim = ifElse(Root, StateType = C, 766, ifElse(Root, StateType = A, 767, 765))
velSet = 0,0
ctrl = 0

[State 765, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 765, BindToRoot]
type = BindToRoot
trigger1 = 1
time = -1

[State 765, Change to Crouching]
type = ChangeAnim
triggerAll = !Time
trigger1 = !(Root, AILevel) && Root, command = "down"
trigger2 = Root, AILevel && (Root, StateType != A) && P2StateType = C
value = 766

[State 765, Change to Standing / Jumping]
type = ChangeAnim
triggerAll = !Time
trigger1 = !(Root, AILevel) && Root, command = "fwd"
trigger2 = Root, AILevel && Anim != 766
value = ifElse((Root, StateType = A), 767, 765)

[State 765, Change to Standing / Jumping]
type = ChangeAnim
trigger1 = Anim = 765 || Anim = 767
value = ifElse((Root, StateType = A), 767, 765)

[State 765, Disable]
type = VarSet
trigger1 = Time >= ifElse((Root, StateType = A), 7, 8)
trigger2 = Facing != (Root, Facing)
trigger3 = !(Root, ctrl)
trigger3 = (Root, StateNo != [760,762]) && (Root, StateNo != 5120)
var(0) = 1

[State 765, Disable]
type = VarSet
triggerAll = !(Root, AILevel)
trigger1 = (Root, command = "holdback")
trigger2 = Time < 4 && (Root, command = "holdfwd" + Root, command = "holddown") > 1
trigger3 = Time >= 4 && (Root, command = "holdfwd" || Root, command = "holddown")
trigger4 = Time >= 1 && (((Anim = 765 || Anim = 767) && Root, command = "fwd") || (Anim = 766 && Root, command = "down"))
var(0) = 1

[State 765, Disable]
type = ChangeAnim
trigger1 = var(0) = 1
value = 1

[State 765, Standing/Air]
type = ReversalDef
trigger1 = !var(0) && (Anim = 765 || Anim = 767)
trigger1 = (Root, StateNo != 5120) || !(Root, AnimTime)
reversal.attr = SCA,AA
p1StateNo = 766
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, Crouching]
type = ReversalDef
trigger1 = !var(0) && Anim = 766
reversal.attr = SC,AA
p1StateNo = 766
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, Disable]
type = ReversalDef
trigger1 = var(0) = 1
reversal.attr =
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, End]
type = DestroySelf
trigger1 = Time >= 18
trigger2 = (Root, MoveType != I)
trigger3 = !(Root, ctrl) && (Root, StateNo != [760,762]) && (Root, StateNo != 5120)
trigger4 = (Root, StateNo = [760,762]) && (Root, Time <= 1)


;Success
[StateDef 766]
moveType = I
ctrl = 0

[State 766, Disable]
type = VarSet
trigger1 = 1
var(0) = 1

[State 766, End]
type = DestroySelf
trigger1 = Root, StateNo = [760,762]
trigger2 = Time >= 2

;=====================<BIG BREATH PROJECTILE>=========================
[StateDef 1105]
type = S
physics = N
moveType = A
ctrl = 0
anim = 6000
sprPriority = 3

[State 1105, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = 1107
ignoreHitPause = 1

[State 1105, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 1105, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 6000
value = 6000

[State 1105, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[State 1105, VelSet]
type = VelSet
trigger1 = 1
x = ifElse(var(10) = 2, 1, ifElse(var(10) = 1, 0.5, 0.25))

[State 1105, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1105, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1105, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 1105, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1105, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = Root, StateNo != 193
attr = S,SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 63, ifElse(var(10), 56, 49)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 63, ifElse(var(10), 56, 49)))), ifElse(var(10) >= 2, 8, 7)
getPower = ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)), 36 * !(Root, var(20))
givePower = 36, 36
pauseTime = 1, 7
guard.pauseTime = 1, 7
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -5, -4
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5, -4
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 0
fall.recover = 0
air.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1105, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 1106
ignoreHitPause = 1

[State 1105, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1107
ignoreHitPause = 1

[State 1105, End]
type = DestroySelf
trigger1 = Time = 34

;Hit Pause
[StateDef 1106]
type = A
physics = N
moveType = A
ctrl = 0
sprPriority = 3
moveHitPersist = 1

[State 1106, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 1106, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 1400), ifElse(MoveGuarded, 0, 1)
channel = 3
ignorehitPause = 1

[State 1106, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1106, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1106,Burn]
type = TargetState
trigger1 = movehit=1 && numtarget
value = 6018

[State 1106, Super]
type = Helper
trigger1 = MoveHit = 1 && NumTarget
id = 8952
name = "ice"
pos = 0,0
postype = P2
stateno = 8952
helpertype = normal
facing=-1
keyctrl = 0
ownpal = 1
ignorehitpause = 1
supermovetime = 99999
pausemovetime = 99999
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[State 1106, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1106, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1106, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1106, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1100,1130]
var(18) = 1

[State 1106, End]
type = ChangeState
trigger1 = Time >= 0
value = 1107

;Disappear
[StateDef 1107]
type = A
physics = N
moveType = A
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 1107, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 2,6
channel = 3
volume = -128
lowPriority = 1

[State 1107, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 1107, End]
type = ChangeState
trigger1 = !AnimTime
value = 1108

;Wait
[StateDef 1108]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 1108, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)

;=====================<EX BIG BREATH PROJECTILE>=========================
[StateDef 1135]
type = S
physics = N
moveType = A
ctrl = 0
anim = 6030
sprPriority = 3

[State 1135, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = 1107
ignoreHitPause = 1

[State 1135, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 1135, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 6030 && !PrevStateNo
value = 6030

[State 1135, VelSet]
type = VelSet
trigger1 = 1
x = 1.5

[State 1135, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1135, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1135, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 1135, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1135, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = Root, StateNo != 193
attr = S,SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 91 < 7, 7, fvar(11) * 91)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 1, 7
guard.pauseTime = 1, 7
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -5, -6
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 0
fall.recover = 0
air.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3
id = 6018

[State 1135, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 1106
ignoreHitPause = 1

[State 1135, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1107
ignoreHitPause = 1

[State 1135, End]
type = DestroySelf
trigger1 = Time = 34

;=====================<EX BIG TOWERS PROJECTILE>=========================
[StateDef 1335]
type = S
physics = N
moveType = A
ctrl = 0
anim = 6305
sprPriority = 3

[State 1335, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = 1337
ignoreHitPause = 1

[State 1335, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 1335, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 6305
value = 6305

[State 1335, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[state 1335]
type = velset
trigger1 = time=1
x = 0
y = 0

[state 1335]
type = ScreenBound
trigger1 = 1
value = 0

[state 1335]
type = AttackDist
trigger1 = 1
value = 320

[state 1335]
type = Explod
trigger1 = !time
id = 6300
anim = 6300
pos = 0,0
postype = p1
bindtime = -1
sprpriority = 4
ignorehitpause = 1
scale = const(size.xscale),const(size.yscale)

[state 1335]
type = Explod
trigger1 = time = 5
id = 6301
anim = 6300
pos = ceil(52*const(size.xscale)),0
postype = p1
bindtime = -1
sprpriority = 4
ignorehitpause = 1
scale = const(size.xscale),const(size.yscale)

[state 1335]
type = Explod
trigger1 = time = 10
id = 6302
anim = 6300
pos = ceil(104*const(size.xscale)),0
postype = p1
bindtime = -1
sprpriority = 4
ignorehitpause = 1
scale = const(size.xscale),const(size.yscale)

[state 1335]
type = Explod
trigger1 = time = 15
id = 6303
anim = 6300
pos = ceil(156*const(size.xscale)),0
postype = p1
bindtime = -1
sprpriority = 4
ignorehitpause = 1
scale = const(size.xscale),const(size.yscale)

[state 1335]
type = Explod
trigger1 = time = 20
id = 6304
anim = 6300
pos = ceil(208*const(size.xscale)),0
postype = p1
bindtime = -1
sprpriority = 4
ignorehitpause = 1
scale = const(size.xscale),const(size.yscale)

[state 1335]
type = Explod
trigger1 = time = 25
id = 6304
anim = 6300
pos = ceil(260*const(size.xscale)),0
postype = p1
bindtime = -1
sprpriority = 4
ignorehitpause = 1
scale = const(size.xscale),const(size.yscale)

[state 1335]
type = Explod
trigger1 = time = 30
id = 6304
anim = 6300
pos = ceil(312*const(size.xscale)),0
postype = p1
bindtime = -1
sprpriority = 4
ignorehitpause = 1
scale = const(size.xscale),const(size.yscale)

[State 1335, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1335, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1335, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 1335, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1335, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = Root, StateNo != 193
attr = S,SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 144 < 7, 7, fvar(11) * 144)), 8
getPower = 0,0
givePower = 36, 36
pauseTime = 1, 7
guard.pauseTime = 1, 7
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4, -7
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4, -7
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 0
fall.recover = 0
air.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3
P2stateno = 6018

[State 1335, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 1336
ignoreHitPause = 1

[State 1335, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1337
ignoreHitPause = 1

[State 1335, End]
type = DestroySelf
trigger1 = AnimTime = 0

;Hit Pause
[StateDef 1336]
type = A
physics = N
moveType = A
ctrl = 0
sprPriority = 3
moveHitPersist = 1

[State 1336, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 1336, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 1400), ifElse(MoveGuarded, 0, 1)
channel = 3
ignorehitPause = 1

[State 1336, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1336, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ceil(P2Dist x), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1336, Super]
type = Helper
trigger1 = MoveHit = 1 && NumTarget
id = 8952
name = "ice"
pos = 0,0
postype = P2
stateno = 8952
helpertype = normal
facing=-1
keyctrl = 0
ownpal = 1
ignorehitpause = 1
supermovetime = 99999
pausemovetime = 99999
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[State 1336, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1336, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1336, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1336, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = 1330
var(18) = 1

[State 1336, End]
type = ChangeState
trigger1 = Time >= 0
value = 1337

;Disappear
[StateDef 1337]
type = A
physics = N
moveType = A
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 1337, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 2,6
channel = 3
volume = -128
lowPriority = 1

[State 1337, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 1337, End]
type = ChangeState
trigger1 = !AnimTime
value = 1338

;Wait
[StateDef 1338]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 1338, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)

;=====================<BIG SNOW PROJECTILE>=========================
[StateDef 1605]
type = S
physics = N
moveType = A
ctrl = 0
anim = 6100
sprPriority = 3

[State 1605, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = 1607
ignoreHitPause = 1

[State 1605, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 1605, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 6100
value = 6100

[State 1605, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[state 1605]
type = VelSet
trigger1 = 1
x = 2.0+var(10)*1.5

[State 1605, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1605, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1605, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 1605, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1605, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = Root, StateNo != 193
attr = S,SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 60, ifElse(var(10), 52, 45)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 60, ifElse(var(10), 52, 45)))), ifElse(var(10) >= 2, 8, 7)
getPower = ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)), 36 * !(Root, var(20))
givePower = 36, 36
pauseTime = 1, 7
guard.pauseTime = 1, 7
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -5, -4
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5, -4
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 0
fall.recover = 0
air.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1605, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 1606
ignoreHitPause = 1

[State 1605, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1607
ignoreHitPause = 1

[State 1605, End]
type = DestroySelf
trigger1 = !AnimTime

;Hit Pause
[StateDef 1606]
type = A
physics = N
moveType = A
ctrl = 0
sprPriority = 3
moveHitPersist = 1

[State 1606, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 1606, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 1400), ifElse(MoveGuarded, 0, 1)
channel = 3
ignorehitPause = 1

[State 1606, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), ceil(P2Dist y-50)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1606, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), ceil(P2Dist y-50)
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1606,Burn]
type = TargetState
trigger1 = movehit=1 && numtarget
value = 6018

[State 1606, Super]
type = Helper
trigger1 = MoveHit = 1 && NumTarget
id = 8952
name = "ice"
pos = 0,0
postype = P2
stateno = 8952
helpertype = normal
facing=-1
keyctrl = 0
ownpal = 1
ignorehitpause = 1
supermovetime = 99999
pausemovetime = 99999
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[State 1606, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1606, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1606, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1606, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1600,1630]
var(18) = 1

[State 1606, End]
type = ChangeState
trigger1 = Time >= 0
value = 1607

;Disappear
[StateDef 1607]
type = A
physics = N
moveType = A
anim = 6110
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 1607, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 2,6
channel = 3
volume = -128
lowPriority = 1

[State 1607, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 1607, End]
type = ChangeState
trigger1 = !AnimTime
value = 1608

;Wait
[StateDef 1608]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 1608, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)

;=====================<EX BIG SNOW PROJECTILE>=========================
[StateDef 1635]
type = S
physics = N
moveType = A
ctrl = 0
anim = 6100
sprPriority = 3

[State 1635, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = ifElse(var(2) < 3, 1635, 1637)
ignoreHitPause = 1

[State 1635, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 1635, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 6100
value = 6100

[State 1635, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[state 1635]
type = VelSet
trigger1 = 1
x = 2.0+var(10)*1.5

[State 1635, VarAdd]
type = VarAdd
trigger1 = !Time
var(2) = 1

[State 1635, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1635, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1635, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 1635, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1635, Hit 1]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = var(2) < 3
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 4 * (var(2) < 3), ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 4 * (var(2) < 3), ifElse((Root, var(20)), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4, -6
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4, -6
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 0
fall.recover = 0
air.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1635, Hit 2]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = var(2) >= 3
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 4 * (var(2) < 3), ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 4 * (var(2) < 3), ifElse((Root, var(20)), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4, -6
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4, -6
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 0
fall.recover = 0
air.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd = -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1635, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 1400), ifElse(MoveGuarded, 0, 1)
channel = 3
persistent = 0
ignorehitPause = 1

[State 1635, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), ceil(P2Dist y-50)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1635, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), ceil(P2Dist y-50)
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1635, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 1635, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 1635, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 1635, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1600,1630]
var(18) = 1
persistent = 0

[State 1635, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = ifElse(var(2) < 3, 1635, 1637)
ignoreHitPause = 1

[State 1635, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1637
ignoreHitPause = 1

[State 1635, End]
type = DestroySelf
trigger1 = !AnimTime

;Disappear
[StateDef 1637]
type = A
physics = N
moveType = A
anim = 6110
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 1637,Burn]
type = TargetState
trigger1 = movehit = 1 && numtarget
value = 6018

[State 1637, Super]
type = Helper
trigger1 = Movehit = 1 && NumTarget
id = 8953
name = "ice"
pos = 0,0
postype = P2
stateno = 8953
helpertype = normal
facing=-1
keyctrl = 0
ownpal = 1
ignorehitpause = 1
supermovetime = 99999
pausemovetime = 99999
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[State 1607, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 2,6
channel = 3
volume = -128
lowPriority = 1

[State 1607, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 1607, End]
type = ChangeState
trigger1 = !AnimTime
value = 1638

;Wait
[StateDef 1638]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 1608, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)

;=====================<BIG TRAP PROJECTILE>=========================
[statedef 3005]
type = A
physics = N
movetype = A
ctrl = 0
velset = 0,0
anim = 6405
sprpriority = 4

[State 3005, Helper]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 3005, Helper]
type = AssertSpecial
trigger1 = var(43)%3=0&&var(43)!=0
flag = invisible

[state 3005]
type = velset
trigger1 = time=1
x = 3.0
y = 0

[state 3005]
type = veladd
trigger1 = time>1&&Anim=6405
y = .5

[state 3005]
type = changeanim
trigger1 = vel Y>0 && Pos Y>=-Vel Y && time>1
value = 6410

[state 3005]
type = velset
trigger1 = Anim=6410
x = 0
y = 0

[state 3005]
type = posset
trigger1 = Anim=6410
y = 0

[state 3005]
type = statetypeset
trigger1 = Anim=6410
statetype = S
physics = S

[state 3005]
type = varadd
trigger1 = anim=6410
var(2) = 1

[state 3005]
type = varadd
trigger1 = var(2)>=146
trigger2 = movehit
var(43) = 1

[State 3005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3005, Damage Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3005, Miss]
type = HitDef
trigger1 = 1
attr = S,HP
hitFlag =
sparkXY = -10,0

[State 3005, 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = !movecontact && !movereversed
trigger1 = Anim = 6410
attr = S, HP
damage = ceil(ifElse(fvar(11) * 10 < 7, 7, fvar(11) * 10)), 7
getPower = 0, 0
givePower = 36, 36
affectteam = B
hitflag = MAF
pausetime = 1,10
sparkno = -1;s7150
guard.sparkno = -1;s7050
sparkxy = 10, 0
hitsound = -1;S1,5
guardsound = -1;s0,1
ground.type = Trip;Low;========
ground.slidetime = 17
guard.slidetime = 17
ground.hittime = 16
guard.hittime = 16
airguard.ctrltime = 2
ground.velocity = -3.0,-7.0
guard.velocity = -13.0*const(size.xscale)
airguard.velocity = -2
air.type = Low
air.velocity = -3.0,-7.0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
yaccel = .5
fall = 1
air.fall = 1
fall.recover = 0
air.recover = 0
;P2stateno=6406
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd = -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 3005, 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = !movecontact && !movereversed
trigger1 = Anim = 6410 && (P2stateno=[152,153])
attr = S, HP
damage = ceil(ifElse(fvar(11) * 10 < 7, 7, fvar(11) * 10)), 7
getPower = 0, 0
givePower = 36, 36
affectteam = B
guardflag = L
hitflag = MAF
pausetime = 1,10
sparkno = -1;s7150
guard.sparkno = -1;s7050
sparkxy = 10, 0
hitsound = -1;S1,5
guardsound = -1;s0,1
ground.type = Trip;Low;========
ground.slidetime = 17
guard.slidetime = 17
ground.hittime = 16
guard.hittime = 16
airguard.ctrltime = 2
ground.velocity = -3.0,-7.0
guard.velocity = -13.0*const(size.xscale)
airguard.velocity = -2
air.type = Low
air.velocity = -3.0,-7.0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
yaccel = .5
fall = 1
air.fall = 1
fall.recover = 0
air.recover = 0
;P2stateno=6406
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd = -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[state 3005]
type = AttackDist
trigger1 = 1
value = 0

[state 3005]
type = StatetypeSet
trigger1 = movehit
movetype = I

[State 3005, HitAdd]
type = HitAdd
trigger1 = movehit = 1 && !numtarget
value = -1

[State 3005, HitCount]
type = VarAdd
trigger1 = movehit = 1 && numtarget
var(13) = 1

[State 3005, Juggle]
type = VarAdd
trigger1 = movehit = 1 && numtarget
var(15) = 1
ignoreHitPause = 1

[State 3005, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 3005, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [3000,3050]
var(18) = 1
persistent = 0

[state 3005]
type = DestroySelf
trigger1 = var(43)>=18

;=====================<BIG BREATH PROJECTILE>=========================
[StateDef 3105]
type = S
physics = N
moveType = A
ctrl = 0
anim = 6500
sprPriority = 3

[State 3105, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = 3107
ignoreHitPause = 1

[State 3105, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 3105, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 6500
value = 6500

[State 3105, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[state 3105]
type = explod
trigger1 = time%4=0 && time>=8 && time<48 && random%3!=0
id = 6550
anim = 6550+random%5
pos = -100,-45+random%5*15
postype = p1
ownpal = 1
vel = 10,0
sprpriority = 5
removetime = 30

[State 3105, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3105, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3105, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 3105, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 3105, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = Root, StateNo != 193
attr = S,SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 220 < 7, 7, fvar(11) * 220)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 1, 1
guard.pauseTime = 1, 7
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4, -8
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4, -8
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 0
air.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3
P2stateno = 6018

[State 3105, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 3106
ignoreHitPause = 1

[State 3105, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 3107
ignoreHitPause = 1

[State 3105, End]
type = DestroySelf
trigger1 = AnimTime=0
trigger2 = Root,stateno!=3100&&!((root,stateno=5000||root,stateno=5010) && root,time=0 && root,life>root,gethitvar(damage) && root,gethitvar(animtype)<=2)

;Hit Pause
[StateDef 3106]
type = A
physics = N
moveType = A
ctrl = 0
sprPriority = 3
moveHitPersist = 1

[State 3106, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 3106, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 1400), ifElse(MoveGuarded, 0, 1)
channel = 3
ignorehitPause = 1

[State 3106, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), ceil(P2Dist y-50)
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3106, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ceil(P2Dist x), ceil(P2Dist y-50)
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3106, Super]
type = Helper
trigger1 = Movehit = 1 && NumTarget
id = 8954
name = "ice"
pos = 0,0
postype = P2
stateno = 8954
helpertype = normal
facing=-1
keyctrl = 0
ownpal = 1
ignorehitpause = 1
supermovetime = 99999
pausemovetime = 99999
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[State 3106, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 3106, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 3106, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3106, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1

[State 3106, End]
type = ChangeState
trigger1 = Time >= 0
value = 3107

;Disappear
[StateDef 3107]
type = A
physics = N
moveType = A
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 3107, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 2,6
channel = 3
volume = -128
lowPriority = 1

[State 3107, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 3107, End]
type = ChangeState
trigger1 = !AnimTime
value = 3108

;Wait
[StateDef 3108]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 3108, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)

;=====================<BIG BREATH PROJECTILE>=========================
[StateDef 3155]
type = S
physics = N
moveType = A
ctrl = 0
anim = 6500
sprPriority = 3

[State 3155, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = 3107
ignoreHitPause = 1

[State 3155, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 3155, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 6500
value = 6500

[State 3155, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[state 3155]
type = explod
trigger1 = time%4=0 && time>=8 && time<48 && random%3!=0
id = 6550
anim = 6550+random%5
pos = -100,-45+random%5*15
postype = p1
ownpal = 1
vel = 10,0
sprpriority = 5
removetime = 30

[State 3155, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3155, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3155, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 3155, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 3155, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = Root, StateNo != 193
attr = S,SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 320 < 7, 7, fvar(11) * 320)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 1, 1
guard.pauseTime = 1, 7
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4, -8
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4, -8
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 0
air.recover = 0
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3
P2stateno = 6018

[State 3155, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 3106
ignoreHitPause = 1

[State 3155, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 3107
ignoreHitPause = 1

[State 3155, End]
type = DestroySelf
trigger1 = AnimTime=0
trigger2 = Root,stateno!=3150&&!((root,stateno=5000||root,stateno=5010) && root,time=0 && root,life>root,gethitvar(damage) && root,gethitvar(animtype)<=2)

;========================<BIG ICE BURN PROJECTILE>=============================
[statedef 3305]
type = S
physics = S
movetype = A
ctrl = 0
velset = 0,0
anim = 6600
sprpriority = 4

[State 3305, Helper]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[state 3305]
type = BindtoRoot
trigger1 = 1
pos = 0,0

[state 3305]
type = AttackDist
trigger1 = 1
value = 0

[State 3305, 1]
type = HitDef
trigger1 = !movecontact&&!movereversed
trigger1 = P2movetype!=H && P2stateno!=40
trigger1 = AnimElemTime(8)>=0 && AnimElemTime(32)<0
attr = S, HT
hitflag = MAF
getPower = 0, 0
givePower = 36, 36
pausetime = 1,10
sparkno = -1;s7150
guard.sparkno = -1;s7050
sparkxy = 10, 0
hitsound = -1;S1,5
guardsound = -1;s0,1
ground.type = High;========
ground.slidetime = 17
ground.hittime = 17
guard.slidetime  = 16
guard.hittime  = 16
airguard.ctrltime = 2
ground.velocity = -5.0,-4.0
guard.velocity = -13.0*const(size.xscale)
airguard.velocity = -2
air.type = Low
air.velocity = -5.0,-4.0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
yaccel = .5
fall = 1
air.fall = 1
fall.recover = 0
air.recover = 0
P2stateno = 3311
numhits = 1

[State 3305, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[state 3305]
type = targetlifeadd
trigger1 = movehit = 122
value = floor(ifElse(230 * fvar(11) < 7, -7, -230 * fvar(11)))

[state 3305]
type = targetpoweradd
trigger1 = movehit = 122
value = 36

[State 3305, Super]
type = Helper
trigger1 = movehit = 122
id = 8956
name = "ice"
pos = 0,0
postype = P2
stateno = 8956
helpertype = normal
facing=-1
keyctrl = 0
ownpal = 1
ignorehitpause = 1
supermovetime = 99999
pausemovetime = 99999
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[State 3305, HitAdd]
type = HitAdd
trigger1 = movehit = 1 && !numtarget
value = 1

[State 3305, HitCount]
type = VarAdd
trigger1 = movehit = 1 && numtarget
var(13) = 1

[State 3305, Juggle]
type = VarAdd
trigger1 = movehit = 1 && numtarget
var(15) = 1
ignoreHitPause = 1

[State 3305, Juggle]
type = VarSet
trigger1 = movehit = 1 && numtarget
var(16) = 1
ignoreHitPause = 1

[state 3305]
type = SprPriority
trigger1 = root,stateno = 3310
value = -1

[state 3305]
type = ChangeAnim
trigger1 = root,stateno = 3310
value = 6610

[state 3305]
type = ChangeAnim
trigger1 = root,stateno = 3310 && (root,Anim=[3350,3359])&&root,AnimElemTime(16)>=0
value = 1

[state 3305]
type = DestroySelf
trigger1 = AnimTime = 0 && (root,Anim!=[3350,3359])
trigger2 = (Root,stateno!=[3300,3310])&&!((root,stateno=5000||root,stateno=5010) && root,time=0 && root,life>root,gethitvar(damage) && root,gethitvar(animtype)<=2)

;========================<MAX BIG ICE BURN PROJECTILE>=============================
[statedef 3355]
type = S
physics = S
movetype = A
ctrl = 0
velset = 0,0
anim = 6600
sprpriority = 4

[State 3355, Helper]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[state 3355]
type = BindtoRoot
trigger1 = 1
pos = 0,0

[state 3355]
type = AttackDist
trigger1 = 1
value = 0

[State 3355,Proj]
type = HitDef
trigger1 = !movecontact&&!movereversed
trigger1 = P2movetype!=H && P2stateno!=40
trigger1 = AnimElemTime(8)>=0&&AnimElemTime(32)<0
sprpriority = 5
attr = S, HT
getpower = 0,0
givepower = 0*root,var(6),0
hitflag = MAF
pausetime = 1,10;Hunter
sparkno = -1;s7120
guard.sparkno = -1;s7000
sparkxy = 0, 0
hitsound = -1;S1,10
guardsound = -1;S0,1
ground.type = Low
ground.slidetime = 16
guard.slidetime = 16
ground.hittime = 14
guard.hittime = 14
airguard.ctrltime = 5
ground.velocity = -4.0,-6.0
guard.velocity = -13.0*const(size.xscale)
airguard.velocity = -2
air.type = Low
air.velocity = -4,-6
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
yaccel = .5
fall = 1
air.fall = 1
fall.recover = 0
air.recover = 0
P2stateno = 3361
numhits = 1

[State 3355, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[state 3355]
type = targetlifeadd
trigger1 = movehit = 122
value = floor(ifElse(180 * fvar(11) < 7, -7, -180 * fvar(11)))

[state 3355]
type = targetpoweradd
trigger1 = movehit = 122
value = 36

[state 3355]
type = parentvarset
trigger1 = movehit = 122
trigger1 = numtarget
trigger1 = target,prevstateno=3364 || target,stateno=3364
fvar(2) = 100

[State 3355, HitAdd]
type = HitAdd
trigger1 = movehit = 1 && !numtarget
value = 1

[State 3355, HitCount]
type = VarAdd
trigger1 = movehit = 1 && numtarget
var(13) = 1

[State 3355, Juggle]
type = VarAdd
trigger1 = movehit = 1 && numtarget
var(15) = 1
ignoreHitPause = 1

[State 3305, Juggle]
type = VarSet
trigger1 = movehit = 1 && numtarget
var(16) = 1
ignoreHitPause = 1

[state 3355]
type = SprPriority
trigger1 = root,stateno = 3360
value = -1

[state 3355]
type = ChangeAnim
trigger1 = root,stateno = 3360
value = 6610

[state 3355]
type = ChangeAnim
trigger1 = root,stateno = 3360 && (root,Anim=[3350,3359])&&root,AnimElemTime(16)>=0
value = 1

[state 3305]
type = DestroySelf
trigger1 = AnimTime = 0 && (root,Anim!=[3350,3359])
trigger2 = (Root,stateno!=[3350,3360])&&!((root,stateno=5000||root,stateno=5010) && root,time=0 && root,life>root,gethitvar(damage) && root,gethitvar(animtype)<=2)

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10000]
type = S
physics = S
movetype = I
ctrl = 0
velset = 0,0
sprpriority = -5
anim = 10000

[State 10000]
type = SprPriority
trigger1 = 1
value = -5

[State 10000]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 10000]
type = VarAdd
trigger1 = (root,stateno=200||root,stateno=400||root,stateno=600) && time>0 && root,time=1 && root,animelemtime(2)<=0
trigger2 = (root,stateno=210||root,stateno=410||root,stateno=610) && time>0 && root,time=1 && root,animelemtime(2)<=0
trigger3 = (root,stateno=220||root,stateno=420||root,stateno=620) && time>0 && root,time=1 && root,animelemtime(2)<=0
var(40) = 1

[state -2]
type = ChangeState
trigger1 = (root,stateno=200||root,stateno=400||root,stateno=600) && time>0 && root,time=1 && root,animelemtime(2)<=0 && var(40)=8
trigger1 = var(41):=0||1
value = ifelse(statetype=A,250,200)+10000

[state -2]
type = ChangeState
trigger1 = (root,stateno=210||root,stateno=410||root,stateno=610) && time>0 && root,time=1 && root,animelemtime(2)<=0 && var(40)=8
trigger1 = var(41):=1
value = ifelse(statetype=A,250,200)+10000

[state -2]
type = ChangeState
trigger1 = (root,stateno=220||root,stateno=420||root,stateno=620) && time>0 && root,time=1 && root,animelemtime(2)<=0 && var(40)=8
trigger1 = var(41):=2
value = ifelse(statetype=A,250,200)+10000

[state -2]
type = ChangeState
triggerall = root,statetype!=A
trigger1 = abs(pos x-root,pos X)>60&&IsHelper(10000)
trigger2 = IsHelper(10001)&&numhelper(10000)
trigger2 = abs(pos x-helper(10000),pos X)>50
trigger3 = IsHelper(10002)&&numhelper(10001)
trigger3 = abs(pos x-helper(10001),pos X)>50
trigger4 = IsHelper(10003)&&numhelper(10002)
trigger4 = abs(pos x-helper(10002),pos X)>50
trigger5 = IsHelper(10004)&&numhelper(10003)
trigger5 = abs(pos x-helper(10003),pos X)>50
trigger6 = IsHelper(10005)&&numhelper(10004)
trigger6 = abs(pos x-helper(10004),pos X)>50
trigger7 = IsHelper(10006)&&numhelper(10005)
trigger7 = abs(pos x-helper(10005),pos X)>50
value = 10020

[state -2]
type = ChangeState
trigger1 = abs(pos y-root,pos y)>20&&IsHelper(10000)
trigger2 = IsHelper(10001)&&numhelper(10000)
trigger2 = abs(pos y-helper(10000),pos y)>50
trigger3 = IsHelper(10002)&&numhelper(10001)
trigger3 = abs(pos y-helper(10001),pos y)>50
trigger4 = IsHelper(10003)&&numhelper(10002)
trigger4 = abs(pos y-helper(10002),pos y)>50
trigger5 = IsHelper(10004)&&numhelper(10003)
trigger5 = abs(pos y-helper(10003),pos y)>50
trigger6 = IsHelper(10005)&&numhelper(10004)
trigger6 = abs(pos y-helper(10004),pos y)>50
trigger7 = IsHelper(10006)&&numhelper(10005)
trigger7 = abs(pos y-helper(10005),pos y)>50
value = 10050

[state -2]
type = ChangeState
trigger1 = root,var(52)<=0
value = 10500

[state -2]
type = DisplaytoClipboard
trigger1 = 1
text = "a = %d %d"
params = var(40),var(41)
ignorehitpause = 1

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10020]
type = S
physics = S
movetype = I
ctrl = 0
velset = 0,0
sprpriority = -5
anim = 10020

[State 10020]
type = SprPriority
trigger1 = 1
value = -5

[State 10020]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[state 10020]
type = Turn
trigger1 = ifelse(facing=-1,(pos x-root,pos x)<0,(pos x-root,pos x)>0)&&IsHelper(10000)
trigger2 = IsHelper(10001)&&numhelper(10000)
trigger2 = ifelse(facing=-1,(pos x-helper(10000),pos x)<0,(pos x-helper(10000),pos x)>0)
trigger3 = IsHelper(10002)&&numhelper(10001)
trigger3 = ifelse(facing=-1,(pos x-helper(10001),pos x)<0,(pos x-helper(10001),pos x)>0)
trigger4 = IsHelper(10003)&&numhelper(10002)
trigger4 = ifelse(facing=-1,(pos x-helper(10002),pos x)<0,(pos x-helper(10002),pos x)>0)
trigger5 = IsHelper(10004)&&numhelper(10003)
trigger5 = ifelse(facing=-1,(pos x-helper(10003),pos x)<0,(pos x-helper(10003),pos x)>0)
trigger6 = IsHelper(10005)&&numhelper(10004)
trigger6 = ifelse(facing=-1,(pos x-helper(10004),pos x)<0,(pos x-helper(10004),pos x)>0)
trigger7 = IsHelper(10006)&&numhelper(10005)
trigger7 = ifelse(facing=-1,(pos x-helper(10005),pos x)<0,(pos x-helper(10005),pos x)>0)

[state 10020]
type = VelSet
trigger1 = 1
x = 3

[State 10020]
type = VarAdd
trigger1 = (root,stateno=200||root,stateno=400||root,stateno=600) && time>0 && root,time=1 && root,animelemtime(2)<=0
trigger2 = (root,stateno=210||root,stateno=410||root,stateno=610) && time>0 && root,time=1 && root,animelemtime(2)<=0
trigger3 = (root,stateno=220||root,stateno=420||root,stateno=620) && time>0 && root,time=1 && root,animelemtime(2)<=0
var(40) = 1

[state -2]
type = ChangeState
trigger1 = (root,stateno=200||root,stateno=400||root,stateno=600) && time>0 && root,time=1 && root,animelemtime(2)<=0 && var(40)=8
trigger1 = var(41):=0||1
value = ifelse(statetype=A,250,200)+10000

[state -2]
type = ChangeState
trigger1 = (root,stateno=210||root,stateno=410||root,stateno=610) && time>0 && root,time=1 && root,animelemtime(2)<=0 && var(40)=8
trigger1 = var(41):=1
value = ifelse(statetype=A,250,200)+10000

[state -2]
type = ChangeState
trigger1 = (root,stateno=220||root,stateno=420||root,stateno=620) && time>0 && root,time=1 && root,animelemtime(2)<=0 && var(40)=8
trigger1 = var(41):=2
value = ifelse(statetype=A,250,200)+10000

[state -2]
type = ChangeState
trigger1 = abs(pos x-root,pos X)<40&&IsHelper(10000)
trigger2 = IsHelper(10001)&&numhelper(10000)
trigger2 = abs(pos x-helper(10000),pos X)<40
trigger3 = IsHelper(10002)&&numhelper(10001)
trigger3 = abs(pos x-helper(10001),pos X)<40
trigger4 = IsHelper(10003)&&numhelper(10002)
trigger4 = abs(pos x-helper(10002),pos X)<40
trigger5 = IsHelper(10004)&&numhelper(10003)
trigger5 = abs(pos x-helper(10003),pos X)<40
trigger6 = IsHelper(10005)&&numhelper(10004)
trigger6 = abs(pos x-helper(10004),pos X)<40
trigger7 = IsHelper(10006)&&numhelper(10005)
trigger7 = abs(pos x-helper(10005),pos X)<40
value = 10000

[state -2]
type = ChangeState
trigger1 = root,var(52)<=0
value = 10500

[state -2]
type = DisplaytoClipboard
trigger1 = 1
text = "a = %d %d"
params = var(40),var(41)
ignorehitpause = 1

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10050]
type = A
physics = N
movetype = I
ctrl = 0
velset = ifelse(root,vel X<0,-3,ifelse(root,vel X>0,3,0)),-6
sprpriority = -5
anim = 10000+50

[State 10050]
type = VelSet
trigger1 = facing!=root,facing
x = -vel x

[State 10050]
type = Turn
trigger1 = facing!=root,facing

[State 10050]
type = SprPriority
trigger1 = 1
value = -5

[State 10050]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[state 10050]
type = VarAdd
trigger1 = time%4=0 && time
var(42) = 1

[State 10050]
type = AngleDraw
trigger1 = 1
value = -45*var(42)
scale = 1,1;const(size.xscale),const(size.yscale)

[State 10050]
type = VelAdd
trigger1 = 1
y = .3

[state -2]
type = PosSet
trigger1 = Pos Y>=-Vel Y && Vel Y>0
y = 0

[state -2]
type = ChangeState
trigger1 = Pos Y>=-Vel Y && Vel Y>0
value = 10000

[State 10050]
type = VarAdd
trigger1 = (root,stateno=200||root,stateno=400||root,stateno=600) && time>0 && root,time=1 && root,animelemtime(2)<=0
trigger2 = (root,stateno=210||root,stateno=410||root,stateno=610) && time>0 && root,time=1 && root,animelemtime(2)<=0
trigger3 = (root,stateno=220||root,stateno=420||root,stateno=620) && time>0 && root,time=1 && root,animelemtime(2)<=0
var(40) = 1

[state -2]
type = ChangeState
trigger1 = (root,stateno=200||root,stateno=400||root,stateno=600) && time>0 && root,time=1 && root,animelemtime(2)<=0 && var(40)=8
trigger1 = var(41):=0||1
value = ifelse(statetype=A,250,200)+10000

[state -2]
type = ChangeState
trigger1 = (root,stateno=210||root,stateno=410||root,stateno=610) && time>0 && root,time=1 && root,animelemtime(2)<=0 && var(40)=8
trigger1 = var(41):=1
value = ifelse(statetype=A,250,200)+10000

[state -2]
type = ChangeState
trigger1 = (root,stateno=220||root,stateno=420||root,stateno=620) && time>0 && root,time=1 && root,animelemtime(2)<=0 && var(40)=8
trigger1 = var(41):=2
value = ifelse(statetype=A,250,200)+10000

[state -2]
type = ChangeState
trigger1 = root,var(52)<=0
value = 10500

[state -2]
type = DisplaytoClipboard
trigger1 = 1
text = "a = %d %d"
params = var(40),var(41)
ignorehitpause = 1

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10200]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0,0
sprpriority = -5
anim = 10000

[State 10200]
type = SprPriority
trigger1 = 1
value = -5

[State 10200]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[state -2]
type = Turn
trigger1 = time=0 && facing!=root,facing

[state -2]
type = VelSet
trigger1 = time=1
x = 5

[state -2]
type = ChangeState
trigger1 = time>=(28+var(41)*20)
value = 10300

[state -2]
type = ChangeState
trigger1 = root,var(52)<=0
value = 10500

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10250]
type = A
physics = N
movetype = A
ctrl = 0
velset = 0,0
sprpriority = -5
anim = 10000+50

[State 10250]
type = SprPriority
trigger1 = 1
value = -5

[State 10250]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[state 10250]
type = VarAdd
trigger1 = time%4=0 && time
var(42) = 1

[State 10250]
type = AngleDraw
trigger1 = 1
value = -45*var(42)
scale = 1,1;const(size.xscale),const(size.yscale)

[State 10250]
type = VelAdd
trigger1 = time
y = .3

[state -2]
type = VelSet
trigger1 = time=1
x = 4+var(41)*1.0
y = -(6+var(41)*1.0)

[state -2]
type = ChangeState
trigger1 = time>=(16+var(41)*12)
value = 10350

[state -2]
type = ChangeState
trigger1 = root,var(52)<=0
value = 10500

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10300]
type = U
physics = N
movetype = A
ctrl = 0
sprpriority = -5
anim = 10300

[State 10300]
type = SprPriority
trigger1 = 1
value = -5

[State 10300]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 10300, 6]
type = PlaySND
trigger1 = AnimElem=5
value = 3400,1

[state -2]
type = velSet
trigger1 = AnimElem=1
x = 0
y = 0

[State 10300, 6]
type = HitOverride
trigger1 = 1
time = 1
attr = SCA, AA, AT, AP
slot = 0
stateno = stateno

[state 10300]
type = Explod
trigger1 = AnimElem = 5
id = 8321
anim = 8321
pos = 0,floor(50*const(size.yscale))
postype = p1
scale = const(size.xscale),const(size.yscale)

[State 10300, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 10300, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 10300, Miss]
type = HitDef
trigger1 = 1
attr = S,NA
hitFlag =
sparkXY = -10,0

[State 10300, HitDef]
type = HitDef
trigger1 = AnimElem = 5
attr = S,NA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAF        ;HLAFD+-
guardflag = MA         ;HLA
getPower = 0,0
givePower = 36, 36
animtype = light          ;light,medium,hard,back,up,diagup
air.animtype = light
;fall.animtype = Back
damage = ceil(ifElse(fvar(11) * 80 < 7, 7, fvar(11) * 80)), 8
pausetime = 1,10
sparkno = -1
guard.sparkno = -1
sparkxy = ifelse((Abs(P2bodydist X)-10)<20,-20,-10),ceil(-70*const(size.yscale))
hitsound = -1;s1,0
guardsound = -1;s0,0
ground.type = High      ;Low,Trip,None
;air.type = High
ground.slidetime = 11
ground.hittime = 11
guard.slidetime = 10
guard.hittime = 10
yaccel = .5
ground.velocity = -5.75*const(size.xscale)
air.velocity = -4.0,-7.0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
fall = 0
air.fall = 0
fall.xvelocity = -2.0
fall.recover = 0
air.recover = 0
sprpriority = -5
p2stateno = 7697
id = 7697
palfx.color = 64
palfx.add = 40,40,128
palfx.mul = 96,96,96
palfx.time = 40
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 10300, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 10300, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 10300, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 10300, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [3400,3450]
var(18) = 1

[State 10300, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 2
ignorehitPause = 1

[State 10300, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 10300, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 10300, Flames]
type = Helper
trigger1 = MoveHit = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = var(43) := (Target, ID)
helperType = Normal
stateNo = 8150
ID = ifElse(Target, SelfAnimExist(7697), 8150, 8151)
name = "Flames"
posType = P2
size.xScale = Root, const(size.xScale) * 0.5
size.yScale = 0.5
ownPal = 1
ignoreHitPause = 1

[State 10300, 6]
type =  NotHitBy
trigger1 = 1
value = SCA

[state -2]
type = DestroySelf
trigger1 = AnimTime=0&&!IsHelper(10000)
trigger2 = root,var(52)<=0&&Anim=1

[state -2]
type = ChangeAnim
trigger1 = AnimTime=0&&IsHelper(10000)
value = 1

[state -2]
type = ChangeState
trigger1 = root,var(52)<=0&&Anim!=1
value = 10500

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10350]
type = U
physics = N
movetype = A
ctrl = 0
sprpriority = -5
anim = 10350

[State 10350]
type = SprPriority
trigger1 = 1
value = -5

[State 10350]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[state 10350]
type = VarAdd
trigger1 = time%4=0 && time
var(42) = 1

[State 10350]
type = AngleDraw
trigger1 = 1
value = -45*var(42)
scale = 1,1;const(size.xscale),const(size.yscale)

[State 10350, 6]
type = PlaySND
trigger1 = AnimElem=2
value = 3400,1

[state -2]
type = veladd
trigger1 = Statetype=A
y = .3

[state -2]
type = velSet
trigger1 = AnimElem=2
x = 0
y = 0

[State 10350, 6]
type = HitOverride
trigger1 = 1
time = 1
attr = SCA, AA, AT, AP
slot = 0
stateno = stateno

[state 10350]
type = Explod
trigger1 = AnimElem = 2
id = 8321
anim = 8321
pos = 0,floor(50*const(size.yscale))
postype = p1
scale = const(size.xscale),const(size.yscale)

[State 10350, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 10350, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 10350, Miss]
type = HitDef
trigger1 = 1
attr = S,NA
hitFlag =
sparkXY = -10,0

[State 10350, HitDef]
type = HitDef
trigger1 = AnimElem = 2
attr = S,NA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAF        ;HLAFD+-
guardflag = MA         ;HLA
getPower = 0,0
givePower = 36, 36
animtype = light          ;light,medium,hard,back,up,diagup
air.animtype = light
;fall.animtype = Back
damage = ceil(ifElse(fvar(11) * 80 < 7, 7, fvar(11) * 80)), 8
pausetime = 1,10
sparkno = -1
guard.sparkno = -1
sparkxy = ifelse((Abs(P2bodydist X)-10)<20,-20,-10),ceil(-70*const(size.yscale))
hitsound = -1;s1,0
guardsound = -1;s0,0
ground.type = High      ;Low,Trip,None
;air.type = High
ground.slidetime = 11
ground.hittime = 11
guard.slidetime = 10
guard.hittime = 10
yaccel = .5
ground.velocity = -5.75*const(size.xscale)
air.velocity = -4.0,-7.0
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
fall = 0
air.fall = 0
fall.xvelocity = -2.0
fall.recover = 0
air.recover = 0
sprpriority = -5
p2stateno = 7697
id = 7697
palfx.color = 64
palfx.add = 40,40,128
palfx.mul = 96,96,96
palfx.time = 40
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 10350, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 10350, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 10350, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 10350, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [3400,3450]
var(18) = 1

[State 10350, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 2
ignorehitPause = 1

[State 10350, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 10350, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 10350, Flames]
type = Helper
trigger1 = MoveHit = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = var(43) := (Target, ID)
helperType = Normal
stateNo = 8150
ID = ifElse(Target, SelfAnimExist(7697), 8150, 8151)
name = "Flames"
posType = P2
size.xScale = Root, const(size.xScale) * 0.5
size.yScale = 0.5
ownPal = 1
ignoreHitPause = 1

[State 10350, 6]
type =  NotHitBy
trigger1 = 1
value = SCA

[state -2]
type = DestroySelf
trigger1 = AnimTime=0&&!IsHelper(10000)
trigger2 = root,var(52)<=0&&Anim=1

[state -2]
type = ChangeAnim
trigger1 = AnimTime=0&&IsHelper(10000)
value = 1

[state -2]
type = ChangeState
trigger1 = root,var(52)<=0&&Anim!=1
value = 10500

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10400]
type = S
physics = N
movetype = I
ctrl = 0
velset = 0,0
sprpriority = -5
anim = 10000

[State 10400]
type = SprPriority
trigger1 = 1
value = -5

[State 10400]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[state -2]
type = VarSet
trigger1 = !time
var(40) = 1+(prevstateno-10400)*(prevstateno>=10400)

[state -2]
type = VelSet
trigger1 = time=1
x = -15

[state -2]
type = VelSet
trigger1 = !numhelper(10000)||Ishelper(10000)
trigger1 = abs(root,pos X-pos X)>15
trigger2 = numhelper(10000)&&Ishelper(10001)
trigger2 = abs(helper(10000),Pos X-Pos X)>15
trigger3 = numhelper(10001)&&Ishelper(10002)
trigger3 = abs(helper(10001),Pos X-Pos X)>15
trigger4 = numhelper(10002)&&Ishelper(10003)
trigger4 = abs(helper(10002),Pos X-Pos X)>15
trigger5 = numhelper(10003)&&Ishelper(10004)
trigger5 = abs(helper(10003),Pos X-Pos X)>15
trigger6 = numhelper(10004)&&Ishelper(10005)
trigger6 = abs(helper(10004),Pos X-Pos X)>15
trigger7 = numhelper(10005)&&Ishelper(10006)
trigger7 = abs(helper(10005),Pos X-Pos X)>15
x = 0

[state -2]
type = ChangeState
trigger1 = Time=20
value = 10000

[state -2]
type = ChangeState
trigger1 = root,var(52)<=0
value = 10500

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10401]
type = S
ctrl = 0

[state 10401]
type = ChangeState
trigger1 = !time
value = 10400

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10402]
type = S
ctrl = 0

[state 10401]
type = ChangeState
trigger1 = !time
value = 10400

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10403]
type = S
ctrl = 0

[state 10401]
type = ChangeState
trigger1 = !time
value = 10400

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10404]
type = S
ctrl = 0

[state 10401]
type = ChangeState
trigger1 = !time
value = 10400

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10405]
type = S
ctrl = 0

[state 10401]
type = ChangeState
trigger1 = !time
value = 10400

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10406]
type = S
ctrl = 0

[state 10401]
type = ChangeState
trigger1 = !time
value = 10400

;=====================<Big RESISTOR WITH M.A.P.S. PROJECTILE>=========================
[statedef 10500]
type = S
physics = S
movetype = I
ctrl = 0
velset = 0,0
sprpriority = -5
anim = 10500

[State 10500]
type = SprPriority
trigger1 = 1
value = -5

[State 10500]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[state 10500]
type = DestroySelf
trigger1 = AnimTime = 0

;=====================<PLAYER 2>=========================
[statedef 6018]
type = S
physics = S
movetype = H
ctrl = 0
velset = 0,0
anim = 5010
sprpriority = -2

[state 6018]
type = StateTypeSet
trigger1 = !HitShakeover && !gethitvar(fall)
trigger2 = HitShakeover&&Pos Y>=0
statetype = S
physics = S

[state 6018]
type = StateTypeSet
trigger1 = (HitShakeover&&Pos Y<0) || gethitvar(fall)
statetype = A
physics = N

[state 6018]
type = HitFallSet
trigger1 = !HitShakeover;!time
value = gethitvar(fall)

[state 6018]
type = ChangeAnim
trigger1 = !HitShakeover || !HitFall
value = 5010+(Hitfall>0)*(40-SelfAnimExist(5035)*15)

[state 6018]
type = ChangeAnim
trigger1 = HitShakeover && HitFall
value = 5030
persistent=0

[state 6018]
type = ChangeAnim
trigger1 = HitShakeover && HitFall && ((Anim=5030&&!AnimTime)||Anim=5010)
value = 5050
persistent=0

[state 6018]
type = NotHitBy
triggerall = prevstateno=[5000,5099]
trigger1 = time<30 && gethitvar(hittime)<20
trigger2 = HitOver
value = SCA

[State 700, HitBy]
type = HitBy
trigger1 = 1
value = SCA,AT
time = 1

[state 6018]
type = VelAdd
trigger1 = HitShakeOver
y = gethitvar(yaccel)

[state 6018]
type = HitVelSet
trigger1 = HitShakeOver
x = 1
y = 1
persistent=0

[state 6018]
type = VelSet
trigger1 = HitShakeOver && !HitFall
x = -abs(gethitvar(xvel))*.75*ifelse(gethitvar(xvel)*facing>0,-1,1)
persistent=0

[state 6018]
type = HitVelSet
trigger1 = HitShakeOver && Vel Y>0 && !HitFall
x = 1
persistent=0

[state 6018]
type = PosSet
trigger1 = hitshakeover && Vel Y>0 && Pos Y>=-Vel Y && !HitFall
y = 0

[state 6018]
type = VelSet
trigger1 = HitShakeover && (vel X>abs(gethitvar(xvel))*.7||vel X<-abs(gethitvar(xvel))*.7) && Vel Y>0 && Pos Y>=0 && !HitFall
x = -abs(gethitvar(xvel))*.3333*ifelse(gethitvar(xvel)*facing>0,-1,1)
y = gethitvar(yvel)/1.5
persistent=0

[state 6018]
type = VelSet
trigger1 = HitShakeover && (vel X>abs(gethitvar(xvel))*.3||vel X<-abs(gethitvar(xvel))*.3) && Vel Y>0 && Pos Y>=0 && !HitFall
x = -abs(gethitvar(xvel))*.175*ifelse(gethitvar(xvel)*facing>0,-1,1)
y = gethitvar(yvel)/3.0
persistent=0

[state 6018]
type = VelSet
trigger1 = HitShakeover && Vel Y>0 && Pos Y>=0 && !HitFall
x = 0
y = 0

[state 6018]
type = ChangeState
trigger1 = HitOver&&time>=48 && !HitFall
value = 6019

[state 6018]
type = SelfState
trigger1 = HitShakeOver && Pos Y>=-Vel Y && HitFall
value = 5100

[state 6018]
type = AssertSpecial
trigger1 = time%4<2 && !hitshakeover
trigger2 = HitShakeOver
flag = invisible
ignorehitpause = 1

;=====================<PLAYER 2>=========================
[statedef 6019]
type = S
physics = S
ctrl = 0
velset = 0,0
sprpriority = -1
anim = 5015

[state 6018]
type = PosSet
trigger1 = !time
y = 0

[state 6018]
type = SelfState
trigger1 = Time>4
value = 0
ctrl = 1

[State 6018]
type = NotHitBy
trigger1 = 1
value = SCA

;=====================<PLAYER 2>=========================
[statedef 6020]
type = S
physics = S
movetype = H
ctrl = 0
velset = 0,0
anim = 5010
sprpriority = -2

[state 6020]
type = StateTypeSet
trigger1 = !HitShakeover && !gethitvar(fall)
trigger2 = HitShakeover&&Pos Y>=0
statetype = S
physics = S

[state 6020]
type = StateTypeSet
trigger1 = (HitShakeover&&Pos Y<0) || gethitvar(fall)
statetype = A
physics = N

[state 6020]
type = HitFallSet
trigger1 = !HitShakeover;!time
value = gethitvar(fall)

[state 6020]
type = ChangeAnim
trigger1 = !HitShakeover || !HitFall
value = 5010+(Hitfall>0)*(40-SelfAnimExist(5035)*15)

[state 6020]
type = ChangeAnim
trigger1 = HitShakeover && HitFall
value = 5030
persistent=0

[state 6020]
type = ChangeAnim
trigger1 = HitShakeover && HitFall && ((Anim=5030&&!AnimTime)||Anim=5010)
value = 5050
persistent=0

[state 6020]
type = VelAdd
trigger1 = HitShakeOver
y = gethitvar(yaccel)

[state 6020]
type = HitVelSet
trigger1 = HitShakeOver
x = 1
y = 1
persistent=0

[state 6020]
type = VelSet
trigger1 = HitShakeOver && !HitFall
x = -abs(gethitvar(xvel))*.75*ifelse(gethitvar(xvel)*facing>0,-1,1)
persistent=0

[state 6020]
type = HitVelSet
trigger1 = HitShakeOver && Vel Y>0 && !HitFall
x = 1
persistent=0

[state 6020]
type = PosSet
trigger1 = hitshakeover && Vel Y>0 && Pos Y>=-Vel Y && !HitFall
y = 0

[state 6020]
type = VelSet
trigger1 = HitShakeover && (vel X>abs(gethitvar(xvel))*.7||vel X<-abs(gethitvar(xvel))*.7) && Vel Y>0 && Pos Y>=0 && !HitFall
x = -abs(gethitvar(xvel))*.3333*ifelse(gethitvar(xvel)*facing>0,-1,1)
y = gethitvar(yvel)/1.5
persistent=0

[state 6020]
type = VelSet
trigger1 = HitShakeover && (vel X>abs(gethitvar(xvel))*.3||vel X<-abs(gethitvar(xvel))*.3) && Vel Y>0 && Pos Y>=0 && !HitFall
x = -abs(gethitvar(xvel))*.175*ifelse(gethitvar(xvel)*facing>0,-1,1)
y = gethitvar(yvel)/3.0
persistent=0

[state 6020]
type = VelSet
trigger1 = HitShakeover && Vel Y>0 && Pos Y>=0 && !HitFall
x = 0
y = 0

[state 6020]
type = ChangeState
trigger1 = HitOver&&time>=48 && !HitFall
value = 6021

[state 6020]
type = SelfState
trigger1 = HitShakeOver && Pos Y>=-Vel Y && HitFall
value = 5100

[state 6020]
type = AssertSpecial
trigger1 = time%4<2 && !hitshakeover
trigger2 = HitShakeOver
flag = invisible
ignorehitpause = 1

;=====================<PLAYER 2>=========================
[statedef 6021]
type = S
physics = S
ctrl = 0
velset = 0,0
sprpriority = -1
anim = 5015

[state 6021]
type = PosSet
trigger1 = !time
y = 0

[state 6021]
type = SelfState
trigger1 = Time>4
value = 0
ctrl = 1

[State 6021]
type = NotHitBy
trigger1 = 1
value = SCA

;=====================<FREEZE>=========================
[statedef 8950]
ctrl = 0
anim = 1

[state 8955]
type = varset
trigger1 = !time||(enemynear,stateno=6018&&enemynear,movetype=H&&enemynear,time=1)
var(0) = enemynear,id
ignorehitpause=1

[state 8955]
type = posset
trigger1 = 1
x = playerid(var(0)),pos x
y = playerid(var(0)),pos y
ignorehitpause=1

[state 8955,frozen]
type = Explod
trigger1 = !numexplod(7500)
id = 7500
anim = 7500+((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*5
pos = 0,0
postype = P2
bindtime=-1
removetime=-1
sprpriority = 1
ignorehitpause=1
scale = const(size.xscale),const(size.yscale)

[state 8955]
type = RemoveExplod
trigger1 = !playerid(var(0)),HitShakeOver && (playerid(var(0)),time-1)%4>1
id = 7500

[state 8950]
type = parentvarset
trigger1 = !playeridExist(var(0))
fvar(1) = 0

[state 8955,ice_mid1-1]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7529
pos = -floor(4*const(size.xscale)),-floor(90*const(size.yscale))
postype = P2
vel = -1.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-1]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7521
pos = -floor(18*const(size.xscale)),-floor(65*const(size.yscale))
postype = P2
vel = -2.5*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7520
pos = -floor(26*const(size.xscale)),-floor(42*const(size.yscale))
postype = P2
vel = -3.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-3]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7520
pos = floor(36*const(size.xscale)),-floor(48*const(size.yscale))
postype = P2
vel = 4.0*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7521
pos = floor(50*const(size.xscale)),-floor(23*const(size.yscale))
postype = P2
vel = 6.0*const(size.xscale),-6.0*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-1]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7523
pos = floor(23*const(size.xscale)),-floor(82*const(size.yscale))
postype = P2
vel = 3.0*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7523
pos = -floor(28*const(size.xscale)),-floor(76*const(size.yscale))
postype = P2
vel = -3.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-1]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7522
pos = floor(22*const(size.xscale)),-floor(50*const(size.yscale))
postype = p1
vel = 2.5,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7522
pos = -floor(48*const(size.xscale)),-floor(48*const(size.yscale))
postype = p1
vel = -3.00,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7523
pos = -floor(40*const(size.xscale)),-floor(32*const(size.yscale))
postype = P2
vel = -4.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8950]
type = ParentVarset
trigger1 = playerid(var(0)),hitfall
fvar(1) = 101

[state 8950]
type = RemoveExplod
trigger1 = root,fvar(1)=101
id = 7500

[state 8950]
type = ChangeState
trigger1 = root,fvar(1)=101
value = 8955

[state 8950]
type = playsnd
trigger1 = playerid(var(0)),stateno=6018&&playerid(var(0)),movetype=H
trigger1 = playerid(var(0)),vel Y>=3.0 && playerid(var(0)),Pos Y>=-playerid(var(0)),vel Y && playerid(var(0)),Pos Y<3 && playerid(var(0)),time<40
value = 5100,((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*2
channel = 3

[state 8950]
type = PlaySND
trigger1 = root,fvar(1)!=[100,101]
value = 1,6
channel = 2

[state 8950]
type = RemoveExplod
trigger1 = root,fvar(1)!=[100,101]
id = 7500

[state 8950]
type = DestroySelf
trigger1 = root,fvar(1)!=[100,101]

;=====================<FREEZE>=========================
[statedef 8955]
ctrl = 0
anim = 1

[state 8955]
type = varset
trigger1 = !time||(enemynear,stateno=6018&&enemynear,movetype=H&&enemynear,time=1)
var(0) = enemynear,id
ignorehitpause=1

[state 8955]
type = posset
trigger1 = 1
x = playerid(var(0)),pos x
y = playerid(var(0)),pos y
ignorehitpause=1

[state 8955]
type = Explod
trigger1 = !numexplod(7500)
id = 7500
anim = 7501+((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*5
pos = 0,0
postype = p2
bindtime=-1
removetime=-1
sprpriority = 1
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955]
type = RemoveExplod
trigger1 = !playerid(var(0)),HitShakeOver && (playerid(var(0)),time-1)%4>1
id = 7500

[state 8950]
type = parentvarset
trigger1 = !playeridExist(var(0))
trigger2 = playerid(var(0)),movetype!=H||playerid(var(0)),statetype!=A||playerid(var(0)),stateno!=6018
fvar(1) = 0

[state 8955,ice_mid1-1]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7529
pos = -floor(4*const(size.xscale)),-floor(60*const(size.yscale))
postype = P2
vel = -1.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-1]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7521
pos = -floor(18*const(size.xscale)),-floor(35*const(size.yscale))
postype = P2
vel = -2.5*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7520
pos = -floor(26*const(size.xscale)),-floor(12*const(size.yscale))
postype = P2
vel = -3.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-3]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7520
pos = floor(36*const(size.xscale)),-floor(18*const(size.yscale))
postype = P2
vel = 4.0*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7521
pos = floor(50*const(size.xscale)),floor(13*const(size.yscale))
postype = P2
vel = 6.0*const(size.xscale),-6.0*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-1]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7523
pos = floor(23*const(size.xscale)),-floor(52*const(size.yscale))
postype = P2
vel = 3.0*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7523
pos = -floor(28*const(size.xscale)),-floor(46*const(size.yscale))
postype = P2
vel = -3.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-1]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7522
pos = floor(22*const(size.xscale)),-floor(20*const(size.yscale))
postype = p1
vel = 2.5,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7522
pos = -floor(48*const(size.xscale)),-floor(18*const(size.yscale))
postype = p1
vel = -3.00,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = root,fvar(1)!=[100,101]
id = 7520
anim = 7523
pos = -floor(40*const(size.xscale)),-floor(2*const(size.yscale))
postype = P2
vel = -4.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8950]
type = ParentVarset
trigger1 = !playerid(var(0)),hitfall
fvar(1) = 100

[state 8950]
type = RemoveExplod
trigger1 = root,fvar(1)=100
id = 7500

[state 8950]
type = ChangeState
trigger1 = root,fvar(1)=100
value = 8950

[state 8950]
type = PlaySND
trigger1 = root,fvar(1)!=[100,101]
value = 1,6
channel = 2

[state 8950]
type = RemoveExplod
trigger1 = root,fvar(1)!=[100,101]
id = 7500

[state 8950]
type = DestroySelf
trigger1 = root,fvar(1)!=[100,101]

;=====================<FREEZE>=========================
[statedef 8952]
ctrl = 0
anim = 1

[state 8955]
type = varset
trigger1 = !time||(enemynear,stateno=6018&&enemynear,movetype=H&&enemynear,time=1)
var(0) = enemynear,id
ignorehitpause=1

[state 8955]
type = posset
trigger1 = 1
x = playerid(var(0)),pos x
y = playerid(var(0)),pos y
ignorehitpause=1

[state 8955,frozen]
type = Explod
trigger1 = !numexplod(7500)
id = 7500
anim = 7500+((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*5
pos = 0,0
postype = P2
bindtime=-1
removetime=-1
sprpriority = 1
ignorehitpause=1
scale = const(size.xscale),const(size.yscale)

[state 8955,ice_mid1-1]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7529
pos = -floor(4*const(size.xscale)),-floor(90*const(size.yscale))
postype = P2
vel = -1.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-1]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7521
pos = -floor(18*const(size.xscale)),-floor(65*const(size.yscale))
postype = P2
vel = -2.5*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-2]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7520
pos = -floor(26*const(size.xscale)),-floor(42*const(size.yscale))
postype = P2
vel = -3.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-3]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7520
pos = floor(36*const(size.xscale)),-floor(48*const(size.yscale))
postype = P2
vel = 4.0*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-2]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7521
pos = floor(50*const(size.xscale)),-floor(23*const(size.yscale))
postype = P2
vel = 6.0*const(size.xscale),-6.0*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-1]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7523
pos = floor(23*const(size.xscale)),-floor(82*const(size.yscale))
postype = P2
vel = 3.0*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7523
pos = -floor(28*const(size.xscale)),-floor(76*const(size.yscale))
postype = P2
vel = -3.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-1]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7522
pos = floor(22*const(size.xscale)),-floor(50*const(size.yscale))
postype = p1
vel = 2.5,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-2]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7522
pos = -floor(48*const(size.xscale)),-floor(48*const(size.yscale))
postype = p1
vel = -3.00,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = Time = 65
id = 7520
anim = 7523
pos = -floor(40*const(size.xscale)),-floor(32*const(size.yscale))
postype = P2
vel = -4.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8950]
type = playsnd
trigger1 = playerid(var(0)),stateno=6018&&playerid(var(0)),movetype=H
trigger1 = playerid(var(0)),vel Y>=3.0 && playerid(var(0)),Pos Y>=-playerid(var(0)),vel Y && playerid(var(0)),Pos Y<3 && playerid(var(0)),time<40
value = 5100,((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*2
channel = 3

[state 8950]
type = PlaySND
trigger1 = Time = 65
value = 1,6
channel = 2

[state 8950]
type = RemoveExplod
trigger1 = Time = 65
id = 7500

[state 8950]
type = DestroySelf
trigger1 = Time = 65

;=====================<FREEZE>=========================
[statedef 8953]
ctrl = 0
anim = 1

[state 8955]
type = varset
trigger1 = !time||(enemynear,stateno=6018&&enemynear,movetype=H&&enemynear,time=1)
var(0) = enemynear,id
ignorehitpause=1

[state 8955]
type = posset
trigger1 = 1
x = playerid(var(0)),pos x
y = playerid(var(0)),pos y
ignorehitpause=1

[state 8955,frozen]
type = Explod
trigger1 = !numexplod(7500)
id = 7500
anim = 7500+((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*5
pos = 0,0
postype = P2
bindtime=-1
removetime=-1
sprpriority = 1
ignorehitpause=1
scale = const(size.xscale),const(size.yscale)

[state 8955,ice_mid1-1]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7529
pos = -floor(4*const(size.xscale)),-floor(90*const(size.yscale))
postype = P2
vel = -1.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-1]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7521
pos = -floor(18*const(size.xscale)),-floor(65*const(size.yscale))
postype = P2
vel = -2.5*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-2]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7520
pos = -floor(26*const(size.xscale)),-floor(42*const(size.yscale))
postype = P2
vel = -3.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-3]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7520
pos = floor(36*const(size.xscale)),-floor(48*const(size.yscale))
postype = P2
vel = 4.0*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-2]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7521
pos = floor(50*const(size.xscale)),-floor(23*const(size.yscale))
postype = P2
vel = 6.0*const(size.xscale),-6.0*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-1]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7523
pos = floor(23*const(size.xscale)),-floor(82*const(size.yscale))
postype = P2
vel = 3.0*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7523
pos = -floor(28*const(size.xscale)),-floor(76*const(size.yscale))
postype = P2
vel = -3.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-1]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7522
pos = floor(22*const(size.xscale)),-floor(50*const(size.yscale))
postype = p1
vel = 2.5,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-2]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7522
pos = -floor(48*const(size.xscale)),-floor(48*const(size.yscale))
postype = p1
vel = -3.00,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = Time = 70
id = 7520
anim = 7523
pos = -floor(40*const(size.xscale)),-floor(32*const(size.yscale))
postype = P2
vel = -4.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8950]
type = playsnd
trigger1 = playerid(var(0)),stateno=6018&&playerid(var(0)),movetype=H
trigger1 = playerid(var(0)),vel Y>=3.0 && playerid(var(0)),Pos Y>=-playerid(var(0)),vel Y && playerid(var(0)),Pos Y<3 && playerid(var(0)),time<40
value = 5100,((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*2
channel = 3

[state 8950]
type = PlaySND
trigger1 = Time = 70
value = 1,6
channel = 2

[state 8950]
type = RemoveExplod
trigger1 = Time = 70
id = 7500

[state 8950]
type = DestroySelf
trigger1 = Time = 70

;=====================<FREEZE>=========================
[statedef 8954]
ctrl = 0
anim = 1

[state 8955]
type = varset
trigger1 = !time||(enemynear,stateno=6018&&enemynear,movetype=H&&enemynear,time=1)
var(0) = enemynear,id
ignorehitpause=1

[state 8955]
type = posset
trigger1 = 1
x = playerid(var(0)),pos x
y = playerid(var(0)),pos y
ignorehitpause=1

[state 8955]
type = Explod
trigger1 = !numexplod(7500)
id = 7500
anim = 7501+((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*5
pos = 0,0
postype = p2
bindtime=-1
removetime=-1
sprpriority = 1
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-1]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7529
pos = -floor(4*const(size.xscale)),-floor(60*const(size.yscale))
postype = P2
vel = -1.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-1]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7521
pos = -floor(18*const(size.xscale)),-floor(35*const(size.yscale))
postype = P2
vel = -2.5*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-2]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7520
pos = -floor(26*const(size.xscale)),-floor(12*const(size.yscale))
postype = P2
vel = -3.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-3]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7520
pos = floor(36*const(size.xscale)),-floor(18*const(size.yscale))
postype = P2
vel = 4.0*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-2]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7521
pos = floor(50*const(size.xscale)),floor(13*const(size.yscale))
postype = P2
vel = 6.0*const(size.xscale),-6.0*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-1]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7523
pos = floor(23*const(size.xscale)),-floor(52*const(size.yscale))
postype = P2
vel = 3.0*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7523
pos = -floor(28*const(size.xscale)),-floor(46*const(size.yscale))
postype = P2
vel = -3.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-1]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7522
pos = floor(22*const(size.xscale)),-floor(20*const(size.yscale))
postype = p1
vel = 2.5,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-2]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7522
pos = -floor(48*const(size.xscale)),-floor(18*const(size.yscale))
postype = p1
vel = -3.00,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = Time = 30
id = 7520
anim = 7523
pos = -floor(40*const(size.xscale)),-floor(2*const(size.yscale))
postype = P2
vel = -4.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8950]
type = PlaySND
trigger1 = Time = 30
value = 1,6
channel = 2

[state 8950]
type = RemoveExplod
trigger1 = Time = 30
id = 7500

[state 8950]
type = DestroySelf
trigger1 = Time = 30

;=====================<FREEZE>=========================
[statedef 8956]
ctrl = 0
anim = 1

[state 8955]
type = varset
trigger1 = !time||(enemynear,stateno=6018&&enemynear,movetype=H&&enemynear,time=1)
var(0) = enemynear,id
ignorehitpause=1

[state 8955]
type = posset
trigger1 = 1
x = playerid(var(0)),pos x
y = playerid(var(0)),pos y
ignorehitpause=1

[state 8955]
type = Explod
trigger1 = !numexplod(7500)
id = 7500
anim = 7501+((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*5
pos = 0,0
postype = p2
bindtime=-1
removetime=-1
sprpriority = 1
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-1]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7529
pos = -floor(4*const(size.xscale)),-floor(60*const(size.yscale))
postype = P2
vel = -1.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-1]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7521
pos = -floor(18*const(size.xscale)),-floor(35*const(size.yscale))
postype = P2
vel = -2.5*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-2]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7520
pos = -floor(26*const(size.xscale)),-floor(12*const(size.yscale))
postype = P2
vel = -3.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-3]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7520
pos = floor(36*const(size.xscale)),-floor(18*const(size.yscale))
postype = P2
vel = 4.0*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-2]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7521
pos = floor(50*const(size.xscale)),floor(13*const(size.yscale))
postype = P2
vel = 6.0*const(size.xscale),-6.0*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-1]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7523
pos = floor(23*const(size.xscale)),-floor(52*const(size.yscale))
postype = P2
vel = 3.0*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7523
pos = -floor(28*const(size.xscale)),-floor(46*const(size.yscale))
postype = P2
vel = -3.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-1]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7522
pos = floor(22*const(size.xscale)),-floor(20*const(size.yscale))
postype = p1
vel = 2.5,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-2]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7522
pos = -floor(48*const(size.xscale)),-floor(18*const(size.yscale))
postype = p1
vel = -3.00,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = Time = 20
id = 7520
anim = 7523
pos = -floor(40*const(size.xscale)),-floor(2*const(size.yscale))
postype = P2
vel = -4.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8950]
type = PlaySND
trigger1 = Time = 20
value = 1,6
channel = 2

[state 8950]
type = RemoveExplod
trigger1 = Time = 20
id = 7500

[state 8950]
type = DestroySelf
trigger1 = Time = 20

;=====================<FREEZE>=========================
[statedef 8960]
ctrl = 0
anim = 1

[state 8955]
type = varset
trigger1 = !time||(enemynear,stateno=6018&&enemynear,movetype=H&&enemynear,time=1)
var(0) = enemynear,id
ignorehitpause=1

[state 8955]
type = posset
trigger1 = 1
x = playerid(var(0)),pos x
y = playerid(var(0)),pos y
ignorehitpause=1

[state 8955,frozen]
type = Explod
trigger1 = !numexplod(7500)
id = 7500
anim = 7500+((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*5
pos = 0,0
postype = P2
bindtime=-1
removetime=-1
sprpriority = 1
ignorehitpause=1
scale = const(size.xscale),const(size.yscale)

[state 8955]
type = RemoveExplod
trigger1 = !playerid(var(0)),HitShakeOver && (playerid(var(0)),time-1)%4>1
id = 7500

[state 8950]
type = parentvarset
trigger1 = !playeridExist(var(0))
fvar(1) = 0

[state 8955,ice_mid1-1]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7529
pos = -floor(4*const(size.xscale)),-floor(90*const(size.yscale))
postype = P2
vel = -1.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-1]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7521
pos = -floor(18*const(size.xscale)),-floor(65*const(size.yscale))
postype = P2
vel = -2.5*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7520
pos = -floor(26*const(size.xscale)),-floor(42*const(size.yscale))
postype = P2
vel = -3.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-3]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7520
pos = floor(36*const(size.xscale)),-floor(48*const(size.yscale))
postype = P2
vel = 4.0*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7521
pos = floor(50*const(size.xscale)),-floor(23*const(size.yscale))
postype = P2
vel = 6.0*const(size.xscale),-6.0*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-1]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7523
pos = floor(23*const(size.xscale)),-floor(82*const(size.yscale))
postype = P2
vel = 3.0*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7523
pos = -floor(28*const(size.xscale)),-floor(76*const(size.yscale))
postype = P2
vel = -3.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-1]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7522
pos = floor(22*const(size.xscale)),-floor(50*const(size.yscale))
postype = p1
vel = 2.5,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7522
pos = -floor(48*const(size.xscale)),-floor(48*const(size.yscale))
postype = p1
vel = -3.00,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7523
pos = -floor(40*const(size.xscale)),-floor(32*const(size.yscale))
postype = P2
vel = -4.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8950]
type = ParentVarset
trigger1 = playerid(var(0)),hitfall
fvar(2) = 101

[state 8950]
type = RemoveExplod
trigger1 = root,fvar(2)=101
id = 7500

[state 8950]
type = ChangeState
trigger1 = root,fvar(2)=101
value = 8955

[state 8950]
type = playsnd
trigger1 = playerid(var(0)),stateno=6018&&playerid(var(0)),movetype=H
trigger1 = playerid(var(0)),vel Y>=3.0 && playerid(var(0)),Pos Y>=-playerid(var(0)),vel Y && playerid(var(0)),Pos Y<3 && playerid(var(0)),time<40
value = 5100,((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*2
channel = 3

[state 8950]
type = PlaySND
trigger1 = root,fvar(2)!=[100,101]
value = 1,6
channel = 2

[state 8950]
type = RemoveExplod
trigger1 = root,fvar(2)!=[100,101]
id = 7500

[state 8950]
type = DestroySelf
trigger1 = root,fvar(2)!=[100,101]

;=====================<FREEZE>=========================
[statedef 8965]
ctrl = 0
anim = 1

[state 8955]
type = varset
trigger1 = !time||(enemynear,stateno=6018&&enemynear,movetype=H&&enemynear,time=1)
var(0) = enemynear,id
ignorehitpause=1

[state 8955]
type = posset
trigger1 = 1
x = playerid(var(0)),pos x
y = playerid(var(0)),pos y
ignorehitpause=1

[state 8955]
type = Explod
trigger1 = !numexplod(7500)
id = 7500
anim = 7501+((playerid(var(0)),const(size.ground.front)+playerid(var(0)),const(size.ground.back))>(53*const(size.xscale)))*5
pos = 0,0
postype = p2
bindtime=-1
removetime=-1
sprpriority = 1
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955]
type = RemoveExplod
trigger1 = !playerid(var(0)),HitShakeOver && (playerid(var(0)),time-1)%4>1
id = 7500

[state 8950]
type = parentvarset
trigger1 = !playeridExist(var(0))
trigger2 = playerid(var(0)),movetype!=H||playerid(var(0)),statetype!=A||playerid(var(0)),stateno!=6018
fvar(2) = 0

[state 8955,ice_mid1-1]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7529
pos = -floor(4*const(size.xscale)),-floor(60*const(size.yscale))
postype = P2
vel = -1.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-1]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7521
pos = -floor(18*const(size.xscale)),-floor(35*const(size.yscale))
postype = P2
vel = -2.5*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7520
pos = -floor(26*const(size.xscale)),-floor(12*const(size.yscale))
postype = P2
vel = -3.5*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid1-3]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7520
pos = floor(36*const(size.xscale)),-floor(18*const(size.yscale))
postype = P2
vel = 4.0*const(size.xscale),-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small1-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7521
pos = floor(50*const(size.xscale)),floor(13*const(size.yscale))
postype = P2
vel = 6.0*const(size.xscale),-6.0*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-1]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7523
pos = floor(23*const(size.xscale)),-floor(52*const(size.yscale))
postype = P2
vel = 3.0*const(size.xscale),-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7523
pos = -floor(28*const(size.xscale)),-floor(46*const(size.yscale))
postype = P2
vel = -3.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-1]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7522
pos = floor(22*const(size.xscale)),-floor(20*const(size.yscale))
postype = p1
vel = 2.5,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_mid2-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7522
pos = -floor(48*const(size.xscale)),-floor(18*const(size.yscale))
postype = p1
vel = -3.00,-4.5*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8955,ice_small2-2]
type = Explod
trigger1 = root,fvar(2)!=[100,101]
id = 7520
anim = 7523
pos = -floor(40*const(size.xscale)),-floor(2*const(size.yscale))
postype = P2
vel = -4.0,-6*const(size.yscale)
accel = 0,.5*const(size.yscale)
sprpriority = 2
removetime=28
scale = const(size.xscale),const(size.yscale)
ignorehitpause=1

[state 8950]
type = ParentVarset
trigger1 = !playerid(var(0)),hitfall
fvar(2) = 100

[state 8950]
type = RemoveExplod
trigger1 = root,fvar(2)=100
id = 7500

[state 8950]
type = ChangeState
trigger1 = root,fvar(2)=100
value = 8950

[state 8950]
type = PlaySND
trigger1 = root,fvar(2)!=[100,101]
value = 1,6
channel = 2

[state 8950]
type = RemoveExplod
trigger1 = root,fvar(2)!=[100,101]
id = 7500

[state 8950]
type = DestroySelf
trigger1 = root,fvar(2)!=[100,101]

;========================<SPARKS>=============================
;Guard Spark (Normal)
[StateDef 8000]
type = A
physics = N
moveType = I
anim = 8000
velset = 0,0
sprPriority = 5

[State 8000, Assert: No Shadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8000, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.125 + (0.046875 * Time), 0.125 + (0.046875 * Time)
ignoreHitPause = 1

[State 8000, Transparency]
type = Trans
trigger1 = Time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8000, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8000, End]
type = DestroySelf
trigger1 = Time >= 8


;Guard Spark (Special)
[StateDef 8001]
type = A
physics = N
moveType = I
anim = 8001
velSet = 0,0
sprPriority = 5

[State 8001, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8001, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
ignoreHitPause = 1

[State 8001, Transparency]
type = Trans
trigger1 = time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8001, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8001, End]
type = DestroySelf
trigger1 = Time >= 8


;Weak Hit Spark
[StateDef 8010]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8010, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8010, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8010, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8010, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.3 - (Time * 0.03), 0.3 - (Time * 0.03)
ignoreHitPause = 1

[State 8010, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8010, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8010, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.15 + (0.009375 * Time), 0.15 + (0.009375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time),256

[State 8010, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.15 + (0.009375 * Time), 0.15 + (0.009375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8010, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.3 - (0.0375 * Time), 0.3 - (0.0375 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8010, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8010, End]
type = DestroySelf
trigger1 = Time >= 16


;Medium Hit Spark
[StateDef 8011]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8011, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8011, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8011, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8011, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.35 - (Time * 0.035), 0.35 - (Time * 0.035)
ignoreHitPause = 1

[State 8011, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8011, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8011, Center]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removetime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.175 + (0.0109375 * Time), 0.175 + (0.0109375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8011, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.175 + (0.0109375 * Time), 0.175 + (0.0109375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8011, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.35 - (0.04375 * Time), 0.35 - (0.04375 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8011, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8011, End]
type = DestroySelf
trigger1 = Time >= 16


;Strong Hit Spark
[StateDef 8012]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8012, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8012, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8012, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8012, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.4 - (Time * 0.04), 0.4 - (Time * 0.04)
ignoreHitPause = 1

[State 8012, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8012, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8012, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8012, Streaks Explod]
type = Explod
trigger1 = !time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8012, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.4 - (0.05 * Time), 0.4 - (0.05 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8012, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8012, End]
type = DestroySelf
trigger1 = Time >= 16


;Special Move Hit Spark
[StateDef 8013]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8013, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8013, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8013, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8013, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.45 - (Time * 0.045), 0.45 - (Time * 0.045)
ignoreHitPause = 1

[State 8012, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8013, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8013, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8013, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8013, P2 Back Explod]
type = Explod
trigger1 = !Time
anim = 8013
ID = 3
posType = P1
facing = -1
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = -3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale P2 Back Explod]
type = ModifyExplod
trigger1= NumExplod(3)
ID = 3
scale = 0.4, 0.4
trans = AddAlpha
alpha = 256 - (32 * Time), 256

[State 8013, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(random < 500, -1, 1)
vFacing = ifElse(random < 500, -1, 1)
sprPriority=3
removeTime=8
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.45 - (0.05625 * Time), 0.45 - (0.05625 * Time)
trans = AddAlpha
alpha = 192 - (24 * Time), 256

[State 8013, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8013, End]
type = DestroySelf
trigger1 = Time >= 16


;Super Hit Spark
[StateDef 8014]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8014, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8014, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8014, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8014, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.5 - (Time * 0.05), 0.5 - (Time * 0.05)
ignoreHitPause = 1

[State 8014, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8014, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8014, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8014, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8014, P2 Back Explod]
type = Explod
trigger1 = !Time
anim = 8013
ID = 3
posType = P1
facing = ifElse((Parent, StateNo = [3000,3999]), -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = -3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale P2 Back Explod]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 0.5,0.5
trans = AddAlpha
alpha = 256 - (32 * Time), 256

[State 8014, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.5 - (0.0625 * Time), 0.5 - (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (32 * Time),256

[State 8014, Remove Explods]
type = RemoveExplod
trigger1 = time >= 16

[State 8014, End]
type = DestroySelf
trigger1 = Time >= 16


;Reversal Spark
[StateDef 8020]
type = A
physics = N
moveType = I
anim = 8020
velSet = 0,0
sprPriority = 5

[State 8020, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8020, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.09375 * Time), 0.25 + (0.09375 * Time)
ignoreHitPause = 1

[State 8020, Transparency]
type = Trans
trigger1 = Time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8020, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8020, End]
type = DestroySelf
trigger1 = Time >= 8



;======================<JUMP DUST>===========================
[StateDef 8100]
type = S
anim = 1
velSet = 0,0

[State 8100, Bind]
type = BindToRoot
trigger1 = Time

[State 8100, Floor Dust]
type = Explod
trigger1 = !Time
anim = 8100
sprPriority = 3
posType = P1
pos = 0, ceil(pos y)
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8100, Player Dust]
type = Explod
trigger1 = !Time || Time = 2 || Time = 6
anim = 8101
sprPriority = 3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8100, End]
type = DestroySelf
trigger1 = Time >= 7



;======================<DASH DUST>===========================
[StateDef 8103]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8103, posSet]
type = PosSet
trigger1 = !Time = 0
y = 0

[State 8103, Dash Dust]
type = Explod
trigger1 = Time = 0 || Time = 3 || Time = 6
anim = 8103
ID = ifElse((Time = 6), 3, ifElse((Time = 3), 2, 1))
posType = P1
pos = 0,-4
random = 8,8
vel = -3 - (Random / 1000.0), -2 - (Random / 2000.0)
facing = ifElse(Random < 500,-1,1)
vFacing = ifElse(Random < 500,-1,1)
removeTime = 16
sprPriority = 3
pauseMoveTime = -1
superMoveTime = -1

[State 8103, Scale Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.1 + (0.025 * Time), 0.1 + (0.025 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8103, Scale Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.1 + (0.025 * (Time - 3)), 0.1 + (0.025 * (Time - 3))
trans = AddAlpha
alpha = 256 - (16 * (Time - 3)), 256

[State 8103, Scale Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 0.1 + (0.025 * (Time - 6)), 0.1 + (0.025 * (Time - 6))
trans = AddAlpha
alpha = 256 - (16 * (Time - 6)), 256

[State 8103, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 22

[State 8103, End]
type = DestroySelf
trigger1 = !NumExplod


;======================<IMPACT DUST>===========================
[StateDef 8110]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8110, Impact Dust Explod 1]
type = Explod
trigger1 = !Time
anim = 8110
ID = ifElse(Time = 8, 3, ifElse(Time = 4, 2, 1))
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8110, Impact Dust Explod 2]
type = Explod
trigger1 = !Time
anim = 8120
ID = 2
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8110, Scale]
type = ModifyExplod
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 256, 256 - (64 * (Time - 4))), 256

[State 8110, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 8

[State 8110, End]
type = DestroySelf
trigger1 = !NumExplod


;======================<WALL IMPACT DUST>===========================
[StateDef 8111]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8111, Impact Dust Explod 1]
type = Explod
trigger1 = !Time
anim = 8111
ID = ifElse(Time = 8, 3, ifElse(Time = 4, 2, 1))
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8111, Impact Dust Explod 2]
type = Explod
trigger1 = !Time
anim = 8121
ID = 2
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8111, Scale]
type = ModifyExplod
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 256, 256 - (64 * (Time - 4))), 256

[State 8111, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 8

[State 8111, End]
type = DestroySelf
trigger1 = !NumExplod

;========================<BURN>=============================
[statedef 7697]
type  = S
movetype= H
physics = N
ctrl = 0
velset = 0,0
anim = 5010

[state 7697]
type = hitfallset
trigger1 = !time&&gethitvar(fall)||gethitvar(yvel)
value = 1

[state 7697]
type = StatetypeSet
trigger1 = !time && hitfall
statetype = A

[state 7697]
type = NotHitBy
trigger1 = !HitFall
value = SCA

[state 7697]
type = PalFX
trigger1 = gethitvar(hitshaketime)>1
add = -64,-144,-160
color = 128
time=1

[state 7697]
type = changeanim
trigger1 = hitshakeover && hitfall
value = ifelse(selfanimexist(5035),5035,5050)
persistent = 0

[state 7697]
type = changeanim
trigger1 = (anim=5035||anim=5050) && (animelem=1,>4||!animtime)
trigger2 = hitshakeover && !hitfall
value = ifelse(name="pyron"&&authorname="Gal129"&&var(59)>3,5000,ifelse(selfanimexist(7697),7697,ifelse(selfanimexist(9015),9015,5017)))
persistent = 0

[state 7697]
type = changeanim
trigger1 = anim=5017 && animelem=2,>=0
value = 5017
elem = 1

[state 7697]
type = veladd
trigger1 = Hitfall && HitShakeOver
y = gethitvar(yaccel)

[state 7697]
type = hitvelset
trigger1 = HitShakeOver
x = 1
y = 1
persistent = 0

[state 7697]
type = velset
trigger1 = Hitfall && HitShakeOver && Vel X && Vel Y>=-1.75
x = 0
persistent = 0

[state 7697]
type = PosFreeze
trigger1 = Hitfall && HitShakeOver && (Vel Y=[-1.75,2.5])
value = 1

[state 7697]
type = PlayerPush
trigger1 = !hitfall
value = 0

[state 7697]
type = ChangeAnim
trigger1 = Hitfall && Vel Y>0 && Pos Y>=-Vel Y
value = 5170

[state 7697]
type = SelfState
trigger1 = Hitfall && Vel Y>0 && Pos Y>=-Vel Y
value = 5110

[state 7697]
type = SelfState
trigger1 = HitOver&&!hitfall
value = 0
ctrl = 1

;========================<FLAMES>=============================
[StateDef 8150]
type = A
physics = N
moveType = I
ctrl = 0
anim = 8150
sprPriority = 4

[State 8150, Assert: No Shadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8150, Flames sound]
type = PlaySnd
trigger1 = Time = 1 && Root, StateNo != 3011
trigger2 = !Time && Root, StateNo = 3011
value = 2, 8150
ignorehitPause = 1

[State 8150, Player]
type = VarSet
trigger1 = !Time
var(0) = Parent, var(43)

[State 8150, PosSet]
type = PosSet
trigger1 = PlayerIDexist(var(0))
x = ceil(PlayerID(var(0)), pos x)
y = ceil(PlayerID(var(0)), pos y)

[State 8150, Facing]
type = Turn
trigger1 = PlayerIDexist(var(0))
trigger1 = Facing != (PlayerID(var(0)), Facing)

[State 8150, Flame Explod 1]
type = Explod
trigger1 = PlayerIDexist(var(0)) && IsHelper(8151) && AnimElemTime(3) >= 0
ID = 18150
anim = 8151
sprPriority = 3
posType = P1
pos = 0, ceil((PlayerID(var(0)), const(size.mid.pos.y)))
random = 40,40
vel = (Random / 2000.0), -0.5 - (Random / 2000.0)
facing = ifElse(Random < 500, -1, 1)
vfacing = ifElse(Random < 500, -1, 1)
scale = 0.5,0.5
ownpal = 1

[State 8150, Flames Explod 2]
type = Explod
trigger1 = PlayerIDexist(var(0)) && IsHelper(8151) && AnimElemTime(3) >= 0
ID = 18151
anim = 8151
sprPriority = 3
posType = P1
pos = 0, ceil((PlayerID(var(0)), const(size.mid.pos.y)))
random = 60,60
vel = (Random / 2000.0), -0.5 - (Random / 2000.0)
facing = ifElse(Random < 500, -1, 1)
vfacing = ifElse(Random < 500, -1, 1)
scale = 0.5,0.5
ownpal = 1

[State 8150, ChangeAnim]
type = ChangeAnim
trigger1 = IsHelper(8151) && !AnimTime
value = 1

[State 8150, End]
type = DestroySelf
trigger1 = IsHelper(8150) && !AnimTime
trigger2 = IsHelper(8151) && Time = 36
trigger3 = !PlayerIDexist(var(0))
trigger4 = (Parent, StateNo = [1036,1037]) && Parent, Time = 1 && Time >= 2

[State 8150, End]
type = DestroySelf
triggerAll = PlayerIDexist(var(0))
trigger1 = PlayerID(var(0)), StateType = L && (PlayerID(var(0)), StateNo != [5080,5081])

;========================<RECOVER FX>=============================
[StateDef 8200]
type = A
velSet = 0,0
anim = 8200
sprPriority = 5

[State 8200, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8200, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.017 * Time), 0.25 + (0.017 * Time)
ignoreHitPause = 1

[State 8200, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = ceil(256 - 17.1 * Time), 256
ignoreHitPause = 1

[State 8200, End]
type = DestroySelf
trigger1 = Time >= 15



;========================<COUNTER FX>=============================
[StateDef 8290]
type = A
physics = N
velSet = 0,0
anim = 1

[State 8290, "Counter!" Text Explod]
type = Explod
trigger1 = !NumExplod(8290)
anim = 8290
ID = 8290
sprPriority = 64
posType = P1
facing = Facing
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8290, Scale]
type = ModifyExplod
trigger1 = Time < 8
ID = 8290
scale = 0.5, .5
trans = AddAlpha
alpha = 256,0

[State 8290, Scale]
type = ModifyExplod
trigger1 = Time >= 8
ID = 8290
scale = 0.5 + 0.0625 * (Time - 8), 0.5 + 0.0625 * (Time - 8)
trans = AddAlpha
alpha = 256 - 32 * (Time - 8), 32 * (Time - 8)

[State 8290, Safety]
type = RemoveExplod
trigger1 = Time >= 16

[State 8290, End]
type = DestroySelf
trigger1 = Time >= 16



;==================<POWER CHARGE FX>==================
;Aura and Dust
[StateDef 8330]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velset = 0,0

[State 8330, BindToRoot]
type = BindToRoot
trigger1 = (Root, StateNo = 730)
pos = -7,0

[State 8330, Charging Sound]
type = PlaySnd
trigger1 = !Time
value = 730,0
channel = 0

[State 8330, Power Charge Aura]
type = Explod
trigger1 = !NumExplod(8330)
ID = 8330
anim = 8330
sprPriority = 3
posType = P1
bindTime = -1
removeTime = -1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8330, Power Charge Dust]
type = Explod
trigger1 = !(Time % 6)
anim = 8105
sprPriority = -3
posType = P1
pos = 0, -ceil(pos y)
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8330, Modify Aura 1]
type = ModifyExplod
trigger1 = Numexplod(8330) && Root, Power < 3000
ID = 8330
scale = 0.5, 0.1 + 0.4 * (Root, Power / 3000.0)

[State 8330, Modify Aura 2]
type = ModifyExplod
trigger1 = NumExplod(8330) && Root, Power >= 3000
ID = 8330
scale = 0.5, 0.5

[State 8330, StopSnd]
type = StopSnd
trigger1 = Root, StateNo != 730
channel = 0

[State 8330, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 730

[State 8330, End]
type = DestroySelf
trigger1 = Root, StateNo != 730


;Particles
[StateDef 8331]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8331, BindToRoot]
type = BindToRoot
trigger1 = !(Time % 8)
pos = ceil(-151 + (Random / 3.125)), ceil(98 - (Random / 3.125))

[State 8331, Particle]
type = Explod
trigger1 = (Time % 8) = 1
anim = 8331
sprPriority = ifElse(Random < 750, 5, -1)
posType = P1
vel = ((RootDist x - 9) / 32.0), ((RootDist y - 71) / 32.0)
scale = ifElse(Random < 500, 0.5, -0.5), ifElse(Random < 500, 0.5, -0.5)
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8331, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 730

[State 8331, End]
type = DestroySelf
trigger1 = Root, StateNo != 730


;==================<VIOLENT WIN VS VEGA PARTICLES>==================
[StateDef 8332]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8332, BindToRoot]
type = BindToRoot
trigger1 = !(Time % 4)
pos = ceil(-40 + (Random /10.25)), ceil(-17 - (Random / 10.25))

[State 8332, Particles]
type = Explod
trigger1 = (Time % 4) = 1
anim = 8332
sprPriority = ifElse(Random < 750,5,-1)
posType = P1
vel = (-(RootDist x + 4) / 10.0),(-(RootDist y - 85) / 10.0)
scale = ifElse(random < 500 ,0.5, -0.5),ifElse(random < 500, 0.5, -0.5)
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8332, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 187 || Root, AnimElemTime(60) >= 0

[State 833, End]
type = DestroySelf
trigger1 = Root, StateNo != 187 || Root, AnimElemTime(60) >= 0



;==================<ZERO COUNTER FX>==================
[StateDef 8350]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8350, bgPalFX]
type = bgPalFX
trigger1 = 1
time = 1
color = 16 * Time
mul = 16 * Time, 16 * Time, 16 * Time

[State 8350, Circle Explod]
type = Explod
trigger1 = !Time
anim = 8350
ID = 1
sprPriority = 3
posType = P1
removeTime = 16
superMoveTime = -1
ownPal = 1

[State 8350, Scale]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = (0.0625 * Time), (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8350, Lightning Explod]
type = Explod
trigger1 = !Time
anim = 8351
ID = 2
sprPriority = -2
posType = P1
pos = 0, -ceil(pos y)
superMoveTime = -1
ownPal = 1

[State 8350, End]
type = DestroySelf
trigger1 = Time >= 16



;========================<CUSTOM COMBO>=============================
[StateDef 8400]
type = A
physics = N
moveType = I
anim = 8400
ctrl = 0
velSet = 0,0
sprPriority = 5

[State 8400, NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8400, BGpalFX]
type = BGpalFX
trigger1 = Time < 25
time = 1
mul = 128,128,128

[State 8400, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8400, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8400, Scale]
type = AngleDraw
trigger1 = Time < 8
scale = (0.0625 * Time), (0.0625 * Time)
ignoreHitPause = 1

[State 8400, Scale]
type = AngleDraw
trigger1 = Time >= 8
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8400, Transparency]
type = Trans
trigger1 = Time < 16
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8400, Transparency]
type = Trans
trigger1 = Time >= 16
trans = AddAlpha
alpha = ceil(256 - 25.6 * (Time - 16)), 256
ignoreHitPause = 1

[State 8400, Lines Explod]
type = Explod
trigger1 = !Time
anim = 8401
ID = 1
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8400, Scale Lines Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 2 - (0.125 * Time), 2 - (0.125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8400, Circle Explod]
type = Explod
trigger1 = Time = 16
anim = 8402
ID = 2
sprPriority = 5
posType = P1
removeTime = 32
superMoveTime = -1

[State 8400, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = (0.1 * (Time - 16)), (0.1 * (Time - 16))
trans = AddAlpha
alpha = ceil(256 - 25.6 * (Time - 16)), 256

[State 8400, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 26

[State 8400, End]
type = DestroySelf
trigger1 = Time >= 26



;========================<SUPER PAUSE FX>=============================
;Level 1 Super FX
[StateDef 8500]
type = A
velSet = 0,0
anim = 8500
sprPriority = 5

[State 8500, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8500, BGpalFX]
type = BGpalFX
trigger1 = Time < 39
time = 1
color = 0
mul = 0,0,256

[State 8500, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8500, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8500, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8500, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5,0.5
ignoreHitPause = 1

[State 8500, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8500, Lines Explod]
type = Explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8501
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8500, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8500, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1 - (0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8500, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8500, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 - (0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8500, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8502
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 32
superMoveTime = -1

[State 8500, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8500, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8500, End]
type = DestroySelf
trigger1 = Time >= 40


;Level 2 Super FX
[StateDef 8510]
type = A
velSet = 0,0
anim = 8510
sprPriority = 5

[State 8510, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8510, BGpalFX]
type = BGpalFX
trigger1 = Time < 39
time = 1
color = 0
mul = 192,0,256

[State 8510, Rotate]
type = AngleSet
trigger1 = !Time
value =6 * (Random % 60)

[State 8510, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8510, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8510, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8510, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8510, Lines Explod]
type = Explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8511
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8510, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8510, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1 - (0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8510, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8510, Scale Lines Explod 4]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 -(0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8510, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8512
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500,-1,1)
vFacing = ifElse(Random < 500,-1,1)
removeTime = 32
superMoveTime = -1

[State 8510, Scale]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24)<4, 64 * (Time - 24), 256), 256

[State 8510, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8510, End]
type = DestroySelf
trigger1 = Time >= 40


;Level 3 Super FX
[StateDef 8520]
type = A
velset = 0,0
anim = 8520
sprPriority = 5

[State 8520, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8520, Assert: NoBarDisplay, NoBG, NoFG]
type = AssertSpecial
trigger1 = Time < 40
flag = NoBarDisplay
flag2 = NoBG
flag3 = NoFG

[State 8520, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8520, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8520, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8520, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8520, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8520, Portrait 1]
type = Explod
trigger1 = !Time
anim = 8525
ID = 20
sprPriority = -16
posType = Back
removeTime = 40
superMoveTime = -1

[State 8520, Portrait 2]
type = Explod
trigger1 = !Time
anim = 8525
ID = 21
sprPriority = -16
posType = Back
removeTime = 40
superMoveTime = -1

[State 8520, Scale Portrait 1a]
type = ModifyExplod
trigger1 = NumExplod(20) && Time < 16
ID = 20
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 1 - (0.03125 * Time), 1 - (0.03125 * Time)
trans = AddAlpha
alpha = (8 * Time), 256

[State 8520, Scale Portrait 2a]
type = ModifyExplod
trigger1 = NumExplod(21) && Time < 16
ID = 21
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 2 - (0.09375 * Time), 2 - (0.09375 * Time)
trans = AddAlpha
alpha = (8 * Time), 256

[State 8520, Scale Portrait 1b]
type = ModifyExplod
trigger1 = NumExplod(20) && (Time = [16,32])
ID = 20
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 256, 256

[State 8520, Scale Portrait 2b]
type = ModifyExplod
trigger1 = NumExplod(21) && (Time = [16,32])
ID = 21
scale = 0,0

[State 8520, Scale Portrait 1c]
type = ModifyExplod
trigger1 = NumExplod(20) && Time >= 32
ID = 20
posType = Back
pos = 160 + (8 * (Time - 32)), floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 128 - 16 * (Time - 32), 256

[State 8520, Scale Portrait 2c]
type = ModifyExplod
trigger1 = NumExplod(21) && Time >= 32
ID = 21
posType = Back
pos = 160 - (8 * (Time - 32)), floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 128 - 16 * (Time - 32), 256

[State 8520, Lines Explod]
type = explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8521
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8520, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8520, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1-(0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8520, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8520, Scale Lines Explod 4]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 - (0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8520, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8522
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1 ,1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 32
superMoveTime = -1

[State 8520, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8520, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8520, End]
type = DestroySelf
trigger1 = Time >= 40



;========================<SUPER FINISH>=============================
[StateDef 8600]
type = A
velSet = 0,0
anim = 1

[State 8600, Super Finish Sound]
type = PlaySnd
trigger1 = !Time
value = 8600,0
channel = 0

[State 8600, SndPan]
type = SndPan
trigger1 = Time <= 80
channel = 1
absPan = ceil(sin(GameTime / 20.0 * pi) * 160)

[State 8600, BG PalFX]
type = BGpalFX
trigger1 = Time < 16
time = 1
mul = 0, 0, 0

[State 8600, BG PalFX]
type = BGpalFX
trigger1 = Time = [16,24)
time = 1
mul = 32 * (Time - 16), 32 * (Time - 16), 32 * (Time - 16)

[State 8600, Move Name: Custom Combo]
type = VarSet
trigger1= !Time && Root, var(23) = 900
var(0) = 1

[State 8600, Move Name: Somersault Strike]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3000,3099])
var(0) = 2

[State 8600, Move Name: Total Wipeout]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3100,3199])
var(0) = 3

[State 8600, Move Name: Sonic Hurricane]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3200,3299])
var(0) = 4

[State 8600, Move Name: Opening Gambit]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3300,3399])
var(0) = 5

[State 8600, Super Finish Explod]
type = Explod
trigger1 = !Time
anim = 8600
ID = 8600
ontop = 1
postype = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Super Finish Explod Fade]
type = ModifyExplod
trigger1 = NumExplod(8600)
ID = 8600
trans = AddAlpha
alpha = ifElse(Time < 16, 256, 256 - 32 * (Time - 16)), 256

[State 8600, Text 1]
type = Explod
trigger1 = !Time && var(0)
anim = 8610 + var(0)
ID = 10
onTop = 1
posType = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Text 2]
type = Explod
trigger1 = !Time && var(0)
anim = 8610 + var(0)
ID = 11
onTop = 1
posType = left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Text 1 Fade]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
trans = AddAlpha
alpha = ifElse(Time < 16, 256, 256 - 32 * (Time - 16)), ifElse(Time < 16, 0, 32 * (Time - 16))

[State 8600, Text 2 Fade]
type = ModifyExplod
trigger1 = NumExplod(11)
ID = 11
scale = 0.5 + (0.0625 * Time), 0.5 + (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (32 * Time), 32 * Time

[State 8600, Circle Explod]
type = Explod
trigger1 = !Time
anim = 8601
ID = 8601
under = 1
posType = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
bindTime = -1
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Circle Fade]
type = ModifyExplod
trigger1 = NumExplod(8601)
ID = 8601
scale = (0.25 * Time) * (1.3333333 * GameHeight / GameWidth), (0.25 * Time) * (1.3333333 * GameHeight / GameWidth)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8600, Assert: NoFG]
type = AssertSpecial
trigger1 = Time < 16
flag = NoFG

[State 8600, Assert: NoBarDisplay]
type = AssertSpecial
trigger1 = Time < 24
flag = NoBarDisplay

[State 8600, RemoveExplod]
type = RemoveExplod
trigger1 = Time >= 24
trigger2 = RoundState < 3

[State 8600, End]
type = DestroySelf
trigger1 = RoundState < 3



;========================<CAMERA CONTROL>=============================
[StateDef 8999]
type = S
velSet = 0,0
anim = 1

[State 8999, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
moveCamera = 1,1
ignoreHitPause = 1

[State 8999, End]
type = DestroySelf
trigger1 = RoundState = 2
