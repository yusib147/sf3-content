; _________________________________________
;| Sasquatch by varo_hades                 |
; �����������������������������������������
;==============================================================================================
;========================================<SPECIAL MOVES>=======================================
;==============================================================================================

;=====================<BIG THYPOON>==========================
[StateDef 1000]
type = S
physics = S
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1000, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1020, ifElse(var(10) = 1, 1010, 1000))

[State 1000, VelSet]
type = VelSet
trigger1 = AnimElem = 3
x = ifElse(var(10) = 2, 5, ifElse(var(10) = 1, 4, 3))

[State 1000, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4,2
channel = 0

[State 1000, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 1000, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 32, ifElse(var(10), 40, 55)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 32, ifElse(var(10), 40, 55)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -13, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 0
trigger1 = AnimElem = 5
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 55 < 7, 7, fvar(11) * 55)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -13, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = [1,2]
trigger1 = AnimElem = 5
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 32, ifElse(var(10), 40, 55)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 32, ifElse(var(10), 40, 55)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -13, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 1
trigger1 = AnimElem = 8
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -13, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 2
trigger1 = AnimElem = 8
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 33 < 7, 7, fvar(11) * 33)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -13, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 2
trigger1 = AnimElem = 11
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 33 < 7, 7, fvar(11) * 33)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -13, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX BIG THYPOON>=============================
[StateDef 1030]
type = S
physics = S
moveType = A
anim = 1030
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, VelSet]
type = VelSet
trigger1 = AnimElem = 3
x = 6

[State 1030, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4,2
channel = 0

[State 1030, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 3

[State 1030, 1]
type = Explod
trigger1 = !numexplod(1055)&&!time
id = 1055
anim = 1055
pos = 0,0
postype = p1
bindtime = -1
ownpal = 1
sprpriority = 1
removeongethit = 1
scale = const(size.xscale),const(size.yscale)

[State 1030, 1]
type = RemoveExplod
trigger1 = AnimElem=3
id = 1055

[State 1030, 1]
type = RemoveExplod
trigger1 = AnimElem=3
trigger2 = AnimElem=4
trigger3 = AnimElem=5
trigger4 = AnimElem=6
trigger5 = AnimElem=7
trigger6 = AnimElem=8
trigger7 = AnimElem=9
trigger8 = AnimElem=10
trigger9 = AnimElem=11
trigger10 = AnimElem=12
trigger11 = AnimElem=13
trigger12 = AnimElem=14
trigger13 = AnimElem=15
;trigger14 = AnimElem=16
;trigger15 = AnimElem=17
id = 1060

[State 1030, 1]
type = RemoveExplod
trigger1 = AnimElem=3
trigger2 = AnimElem=4
trigger3 = AnimElem=5
trigger4 = AnimElem=6
trigger5 = AnimElem=7
trigger6 = AnimElem=8
trigger7 = AnimElem=9
trigger8 = AnimElem=10
trigger9 = AnimElem=11
trigger10 = AnimElem=12
trigger11 = AnimElem=13
trigger12 = AnimElem=14
trigger13 = AnimElem=15
;trigger14 = AnimElem=16
;trigger15 = AnimElem=17
id = 1065

[State 1030, 1]
type = Explod
trigger1 = !numexplod(1060)&&AnimElem=3
trigger2 = !numexplod(1060)&&AnimElem=7
trigger3 = !numexplod(1060)&&AnimElem=11
;trigger4 = !numexplod(1060)&&AnimElem=15
id = 1060
anim = 1060
pos = 0,0
postype = p1
bindtime = -1
removetime=-1
ownpal = 1
sprpriority = 1
removeongethit = 1
scale = const(size.xscale),const(size.yscale)

[State 1030, 1]
type = Explod
trigger1 = !numexplod(1060)&&AnimElem=4
trigger2 = !numexplod(1060)&&AnimElem=8
trigger3 = !numexplod(1060)&&AnimElem=12
;trigger4 = !numexplod(1060)&&AnimElem=16
id = 1060
anim = 1061
pos = 0,0
postype = p1
bindtime = -1
removetime = -1
ownpal = 1
sprpriority = 1
removeongethit = 1
scale = const(size.xscale),const(size.yscale)

[State 1030, 1]
type = Explod
trigger1 = !numexplod(1060)&&AnimElem=5
trigger2 = !numexplod(1060)&&AnimElem=9
trigger3 = !numexplod(1060)&&AnimElem=13
id = 1060
anim = 1062
pos = 0,0
postype = p1
bindtime = -1
removetime = -1
ownpal = 1
sprpriority = 1
removeongethit = 1
scale = const(size.xscale),const(size.yscale)

[State 1030, 1]
type = Explod
trigger1 = !numexplod(1060)&&AnimElem=6
trigger2 = !numexplod(1060)&&AnimElem=10
trigger3 = !numexplod(1060)&&AnimElem=14
id = 1060
anim = 1063
pos = 0,0
postype = p1
bindtime = -1
removetime = -1
ownpal = 1
sprpriority = 1
removeongethit = 1
scale = const(size.xscale),const(size.yscale)

[State 1030, 1]
type = Explod
trigger1 = !numexplod(1065)&&AnimElem=3
trigger2 = !numexplod(1065)&&AnimElem=5
trigger3 = !numexplod(1065)&&AnimElem=7
trigger4 = !numexplod(1065)&&AnimElem=9
trigger5 = !numexplod(1065)&&AnimElem=11
trigger6 = !numexplod(1065)&&AnimElem=13
;trigger7 = !numexplod(1060)&&AnimElem=15
id = 1065
anim = 1065
pos = 0,0
postype = p1
bindtime = -1
removetime = -1
ownpal = 1
sprpriority = 1
removeongethit = 1
scale = const(size.xscale),const(size.yscale)

[State 1030, 1]
type = Explod
trigger1 = !numexplod(1065)&&AnimElem=4
trigger2 = !numexplod(1065)&&AnimElem=6
trigger3 = !numexplod(1065)&&AnimElem=8
trigger4 = !numexplod(1065)&&AnimElem=10
trigger5 = !numexplod(1065)&&AnimElem=12
trigger6 = !numexplod(1065)&&AnimElem=14
;trigger7 = !numexplod(1060)&&AnimElem=16
id = 1065
anim = 1065
pos = 0,0
postype = p1
bindtime = -1
removetime = -1
ownpal = 1
sprpriority = 1
removeongethit = 1
scale = const(size.xscale),const(size.yscale)

[State 1030, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem=3,>=0 && AnimElem=15,<0 &&!movecontact
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 140 < 7, 7, fvar(11) * 140)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -7
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -4, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = s1400,1
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1030, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<BIG BREATH>=============================
[StateDef 1100]
type = S
physics = S
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[state 1100]
type = playsnd
trigger1 = animelem = 4
value = 1100,0
volume = 255
channel = 2

[State 1100, Helper]
type = Helper
trigger1 = AnimElem=4
helpertype = normal
name = "breath"
ID = 1105
stateno = 1105
pos = ceil(48*const(size.xscale)),ceil(-80*const(size.yscale))
postype = p1
facing = 1
ownpal = 0
persistent =0

[State 1100, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX BIG BREATH>=============================
[StateDef 1130]
type = S
physics = S
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1130, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1130, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1130, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 111

[State 1130, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1130, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
value = SCA
time = 1

[State 1130, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[state 1130]
type = playsnd
trigger1 = animelem = 4
value = 1100,0
volume = 255
channel = 2

[State 1130, Helper]
type = Helper
trigger1 = AnimElem=4
helpertype = normal
name = "breath"
ID = 1105
stateno = 1135
pos = ceil(48*const(size.xscale)),ceil(-80*const(size.yscale))
postype = p1
facing = 1
ownpal = 0
persistent =0

[State 1130, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<BIG BLOW>==========================
[StateDef 1200]
type = S
physics = S
moveType = I
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1200, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1200, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1200, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1220, ifElse(var(10) = 1, 1210, 1200))

[State 1200, VelSet]
type = VelSet
trigger1 = AnimElem = 5
x = ifElse(var(2)>=51, 20, ifElse(var(2)>=24, 15, 5))

[state 1200]
type = ChangeAnim
trigger1 = AnimElemTime(4)=0&&var(2)<65&&ifelse(!var(10),command="holdx",ifelse(var(10)=1,command="holdy",command="holdz"))
value = 1200+(var(2)>=24)*40+(var(2)>=51)*10

[state 1200]
type = VarSet
trigger1 = time=0&&(prevstateno!=[500,5099])
var(2) = 0

[state 1200]
type = VarAdd
trigger1 = AnimElemTime(4)<0
var(2) = 1

[state 1200]
type = ChangeAnim
trigger1 = AnimElem=4
trigger2 = AnimElem=4,<0&&var(2)>=12&&ifelse(!var(10),command!="holdx",ifelse(var(10)=1,command!="holdy",command!="holdz"))
value = 1200+ifelse(var(2)>=51,20,ifelse(var(2)>=25,10,0))
elem = 4

[state 1200]
type = statetypeset
trigger1 = AnimElem = 4
movetype = A

[State 1200, Voice]
type = PlaySnd
trigger1 = AnimElem = 5
value = 4,2
channel = 0

[State 1200, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,2
channel = 1

[State 1200, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 133, ifElse(var(10), 122, 111)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 133, ifElse(var(10), 122, 111)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.5, -6.5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -6.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 187), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1200, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6 && !movecontact && !movereversed
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 133, ifElse(var(10), 122, 111)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 133, ifElse(var(10), 122, 111)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -13, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 183), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1200, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX BIG BLOW>=============================
[StateDef 1230]
type = S
physics = S
moveType = I
;anim = 1230
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1230, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1230, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1230, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 111

[State 1230, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1230, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
value = SCA
time = 1

[State 1230, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[state 1230]
type = ChangeAnim
trigger1 = !time && Anim != 1250
value = 1250

[State 1230, VelSet]
type = VelSet
trigger1 = AnimElem = 5
x = 25

[state 1230]
type = ChangeAnim
trigger1 = AnimElemTime(4)=0&&var(2)<32&&(ifelse(!var(10),command="holdx",ifelse(var(10)=1,command="holdy",command="holdz"))||var(2)<12)
value = 1250

[state 1230]
type = VarSet
trigger1 = time=0&&(prevstateno!=[500,5099])
var(2) = 0

[state 1230]
type = VarAdd
trigger1 = AnimElemTime(4)<0
var(2) = 1

[state 1230]
type = ChangeAnim
trigger1 = AnimElem=4,<0&&var(2)>=32&&ifelse(!var(10),command!="holdx",ifelse(var(10)=1,command!="holdy",command!="holdz"))
value = 1250
elem = 4

[state 1230]
type = StatetypeSet
trigger1 = AnimElem = 4
movetype = A

[State 1200, Voice]
type = PlaySnd
trigger1 = AnimElem = 5
value = 4,2
channel = 0

[State 1200, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,2
channel = 2

[State 1230, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 48 < 7, 7, fvar(11) * 48)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4, 12
guard.pauseTime = 4, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -13, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -6.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 183), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1230, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 7
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 48 < 7, 7, fvar(11) * 48)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4, 12
guard.pauseTime = 4, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -13, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -6.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 183), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1230, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 8
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 48 < 7, 7, fvar(11) * 48)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6, 12
guard.pauseTime = 6, 12
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.5, -6.5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -6.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 187), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1230, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<BIG TOWERS>==========================
[StateDef 1300]
type = S
physics = S
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1300, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1300, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1300, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1320, ifElse(var(10) = 1, 1310, 1300))

[State 1300, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1300,0
channel = 0

[State 1300, Helper]
type = explod
trigger1 = AnimElemTime(1)=0
name = "towers"
ID = 6200
anim = 6200
pos = ceil(0*const(size.yscale)),ceil(0*const(size.yscale))
postype = p1
ownpal = 0
sprpriority = 2
removeongethit=1
scale = const(size.xscale),const(size.yscale)
bindtime=-1

[State 1300, Helper]
type = explod
trigger1 = AnimElemTime(2)=0
name = "towers"
ID = 6250
anim = 6250
pos = ceil(0*const(size.yscale)),ceil(0*const(size.yscale))
postype = p1
ownpal = 0
sprpriority = -2
removeongethit=1
scale = const(size.xscale),const(size.yscale)
bindtime=-1

[State 1300, Helper]
type = explod
trigger1 = AnimElemTime(2)=0
name = "towers"
ID = 6200
anim = 6210
pos = ceil(0*const(size.yscale)),ceil(0*const(size.yscale))
postype = p1
ownpal = 0
sprpriority = 2
removeongethit=1
scale = const(size.xscale),const(size.yscale)
bindtime=-1

[State 1300, Helper]
type = removeexplod
trigger1 = AnimElemTime(3)=0
ID = 6200

[State 1300, Helper]
type = removeexplod
trigger1 = AnimElemTime(3)=0
ID = 6250

[State 1300, Helper]
type = explod
trigger1 = AnimElemTime(3)=0
name = "towers"
ID = 6250
anim = 6260
pos = ceil(0*const(size.yscale)),ceil(0*const(size.yscale))
postype = p1
ownpal = 0
sprpriority = -2
scale = const(size.xscale),const(size.yscale)
bindtime=-1

[State 1300, Helper]
type = explod
trigger1 = AnimElemTime(3)=0
name = "towers"
ID = 6200
anim = 6220
pos = ceil(0*const(size.yscale)),ceil(0*const(size.yscale))
postype = p1
ownpal = 0
sprpriority = 2
scale = const(size.xscale),const(size.yscale)
bindtime=-1

[State 1300, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem=2,>=0 && AnimElem=3,<0 && !movecontact && !movereversed
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 133, ifElse(var(10), 122, 111)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 133, ifElse(var(10), 122, 111)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -6
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = s1400,1
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 187), var(36) := -30
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1300, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX BIG TOWERS>=============================
[StateDef 1330]
type = S
physics = S
moveType = A
anim = 1330
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1330, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1330, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1330, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 111

[State 1330, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1330, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
value = SCA
time = 1

[State 1330, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1330, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1300,0
channel = 0

[State 1330, Helper]
type = Helper
trigger1 = AnimElem = 2
helpertype = normal
name = "EXtowers"
ID = 1335
stateno = 1335
pos = ceil(28*const(size.yscale)),ceil(0*const(size.yscale))
postype = p1
facing = 1
ownpal = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
persistent =0

[State 1330, Helper]
type = Helper
trigger1 = AnimElem = 2
helpertype = normal
name = "EXtowers"
ID = 1335
stateno = 1335
pos = -ceil(28*const(size.yscale)),ceil(0*const(size.yscale))
postype = p1
facing = -1
ownpal = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
persistent =0

[state 1330]
type = ChangeState
trigger1 = AnimTime=0
value = 0
ctrl = 1

;=====================<BIG BRUNCH>==========================
[StateDef 1400]
type = S
physics = S
moveType = A
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1400, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1400, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1400, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 5000,0
channel = 1

[state 1400]
type = AttackDist
trigger1 = 1
value = 0

[State 1400, Hitdef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = P2MoveType!=H
trigger1 = P2StateNo!=40
trigger1 = AnimElem = 2
trigger1 = P2bodydist X<=(ceil(54*const(size.xscale))-const(size.ground.front))
attr = S, ST
hitflag = M-
priority = 9, Dodge
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1facing = 1
p2facing = 1
p1stateno = 1411
p2stateno = 1416
guard.dist = 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
yaccel = .5
ground.velocity = -8, -4.0
air.velocity = -8, -4.0
air.hittime = 120
numhits = 0
guard.dist = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1400]
type = StatetypeSet
trigger1 = AnimElem = 3
movetype = I

[state 1400]
type = PosAdd
trigger1 = AnimElem = 5
x = ceil(20*const(size.xscale))

[State 1400]
type = CtrlSet
trigger1 = AnimTime = -1
value = 1

[State 1400]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Success
[Statedef 1411]
type = S
movetype = A
physics = S
velset = 0,0
ctrl = 0
anim = 1411

[state 800]
type = PlaySnd
trigger1 = AnimElem = 6
value = 1400,0

[state 1411]
type = PlaySnd
trigger1 = AnimElem = 8
value = 1400,1

[state 1411]
type = ScreenBound
trigger1 = AnimElemTime(8)<0
value = 1

[state 1411]
type = Width
trigger1 = AnimElemTime(1)=0;>=0&&AnimElemTime(2)<0
edge = ceil(84*const(size.xscale)),0

[state 1411]
type = Width
trigger1 = AnimElemTime(8)=0
edge = ceil(110*const(size.xscale)),0

[state 1411]
type = targetbind
trigger1 = AnimElemTime(1)>=0&&AnimElemTime(2)<0
pos = ceil(84*const(size.xscale)),-ceil(62*const(size.yscale))

[state 1411]
type = targetbind
trigger1 = AnimElemTime(2)>=0&&AnimElemTime(3)<0
pos = ceil(64*const(size.xscale)),-ceil(82*const(size.yscale))

[state 1411]
type = targetbind
trigger1 = AnimElemTime(3)>=0&&AnimElemTime(4)<0
pos = -ceil(4*const(size.xscale)),-ceil(86*const(size.yscale))

[state 1411]
type = targetbind
trigger1 = AnimElemTime(4)>=0&&AnimElemTime(5)<0
pos = -ceil(14*const(size.xscale)),-ceil(56*const(size.yscale))

[state 1411]
type = targetbind
trigger1 = AnimElemTime(5)>=0&&AnimElemTime(6)<0
pos = ceil(10*const(size.xscale)),-ceil(72*const(size.yscale))

[state 1411]
type = targetbind
trigger1 = AnimElemTime(8)>=0&&AnimElemTime(8)<2
pos = ceil(70*const(size.xscale)),-ceil(40*const(size.yscale))

[state 1411]
type = targetbind
trigger1 = AnimElem=8,=2
pos = ceil(100*const(size.xscale)),-ceil(0*const(size.yscale))

[state 1411]
type = targetlifeadd
trigger1 = var(10) = 0
trigger1 = AnimElem = 8
value = floor(ifElse(120 * fvar(11) < 7, -7, -120 * fvar(11)))

[state 1411]
type = targetlifeadd
trigger1 = var(10) = 1
trigger1 = AnimElem = 8
value = floor(ifElse(130 * fvar(11) < 7, -7, -130 * fvar(11)))

[state 1411]
type = targetlifeadd
trigger1 = var(10) = 2
trigger1 = AnimElem = 8
value = floor(ifElse(140 * fvar(11) < 7, -7, -140 * fvar(11)))

[State 1411, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = AnimElem = 8
value = 36

[State 1411, Power]
type = PowerAdd
trigger1 = AnimElem = 8 && !var(20)
value = 72

[State 1411, HitAdd]
type = HitAdd
trigger1 = AnimElem = 8
value = 1

[State 1411, HitCount]
type = VarAdd
trigger1 = AnimElem = 8
var(13) = 1

[State 1411, Juggle]
type = VarAdd
trigger1 = AnimElem = 8
var(15) = 1
ignoreHitPause = 1

[State 1411, Juggle]
type = VarSet
trigger1 = AnimElem = 8
var(16) = 1
ignoreHitPause = 1

[State 1411, Throw 11]
type = TargetState
trigger1 = numtarget && AnimElem = 8
value = 1417+(target,life<=0)

[State 1411, Throw 11]
type = TargetState
trigger1 = AnimElem = 8,=2
value = 6018

[State 1411, State End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Player 2
[statedef 1416]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1416]
type = ScreenBound
trigger1 = 1
value = 1

[state 1416]
type = changeanim2
trigger1 = time = 0
value = 1416

[state 1416]
type = selfstate
trigger1 = Time>=60
value = 5000

;Player 2
[statedef 1417]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1417]
type = ScreenBound
trigger1 = 1
value = 1

[state 1417]
type = changeanim2
trigger1 = time = 0
value = 1417

[state 1417]
type = selfstate
trigger1 = Time>=60
value = 5000

;Player 2
[statedef 1418]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1418]
type = ScreenBound
trigger1 = 1
value = 1

[state 1418]
type = changeanim2
trigger1 = time = 0
value = 1417

[state 1418]
type = HitFallSet
trigger1 = !time
value = 1

[state 1418]
type = selfstate
trigger1 = Time>=60
value = 5000

;========================<EX BIG TOWERS>=============================
[StateDef 1430]
type = S
physics = S
moveType = A
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1430, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1430, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1430, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 131

[State 1430, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1430, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
value = SCA
time = 1

[State 1430, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1430, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 5000,0
channel = 2

[state 1430]
type = AttackDist
trigger1 = 1
value = 0

[State 1430, Hitdef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = P2MoveType!=H
trigger1 = P2StateNo!=40
trigger1 = AnimElem = 2
trigger1 = P2bodydist X<=(ceil(54*const(size.xscale))-const(size.ground.front))
attr = S, ST
hitflag = M-
priority = 9, Dodge
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1facing = 1
p2facing = 1
p1stateno = 1431
p2stateno = 1436
guard.dist = 0
getpower = 0
givepower = 36, 36
yaccel = .5
ground.velocity = -8, -4
air.velocity = -8 ,-4
air.hittime = 140
numhits = 0
guard.dist = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1430]
type = PosAdd
trigger1 = AnimElem = 5
x = ceil(20*const(size.xscale))

[state 1430]
type = StatetypeSet
trigger1 = AnimElem = 3
movetype = I

[State 1430]
type = CtrlSet
trigger1 = AnimTime = -1
value = 1

[State 1430]
type = ChangeState
trigger1 = AnimTime=0
value = 0
ctrl = 1

;Success
[Statedef 1431]
type = S
movetype = A
physics = S
velset = 0,0
ctrl = 0
anim = 1411

[state 1431]
type = PlaySnd
trigger1 = AnimElem = 6
value = 1400,0

[state 1431]
type = PlaySnd
trigger1 = AnimElem = 8
value = 1400,1

[state 1431]
type = ScreenBound
trigger1 = AnimElemTime(8)<0
value = 1

[state 1431]
type = Width
trigger1 = AnimElemTime(1)=0;>=0&&AnimElemTime(2)<0
edge = ceil(84*const(size.xscale)),0

[state 1431]
type = Width
trigger1 = AnimElemTime(8)=0
edge = ceil(110*const(size.xscale)),0

[state 1431]
type = targetbind
trigger1 = AnimElemTime(1)>=0&&AnimElemTime(2)<0
pos = ceil(84*const(size.xscale)),-ceil(62*const(size.yscale))

[state 1431]
type = targetbind
trigger1 = AnimElemTime(2)>=0&&AnimElemTime(3)<0
pos = ceil(64*const(size.xscale)),-ceil(82*const(size.yscale))

[state 1431]
type = targetbind
trigger1 = AnimElemTime(3)>=0&&AnimElemTime(4)<0
pos = -ceil(4*const(size.xscale)),-ceil(86*const(size.yscale))

[state 1431]
type = targetbind
trigger1 = AnimElemTime(4)>=0&&AnimElemTime(5)<0
pos = -ceil(14*const(size.xscale)),-ceil(56*const(size.yscale))

[state 1431]
type = targetbind
trigger1 = AnimElemTime(5)>=0&&AnimElemTime(6)<0
pos = ceil(10*const(size.xscale)),-ceil(72*const(size.yscale))

[state 1431]
type = targetbind
trigger1 = AnimElemTime(8)>=0&&AnimElemTime(8)<2
pos = ceil(70*const(size.xscale)),-ceil(40*const(size.yscale))

[state 1431]
type = targetbind
trigger1 = AnimElem=8,=2
pos = ceil(100*const(size.xscale)),-ceil(0*const(size.yscale))

[state 1431]
type = targetlifeadd
trigger1 = AnimElem = 8
value = floor(ifElse(150 * fvar(11) < 7, -7, -150 * fvar(11)))

[State 1431, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = AnimElem = 8
value = 36

[State 1431, Power]
type = PowerAdd
trigger1 = AnimElem = 8 && !var(20)
value = 0

[State 1431, HitAdd]
type = HitAdd
trigger1 = AnimElem = 8
value = 1

[State 1431, HitCount]
type = VarAdd
trigger1 = AnimElem = 8
var(13) = 1

[State 1431, Juggle]
type = VarAdd
trigger1 = AnimElem = 8
var(15) = 1
ignoreHitPause = 1

[State 1431, Juggle]
type = VarSet
trigger1 = AnimElem = 8
var(16) = 1
ignoreHitPause = 1

[State 1431, Throw 11]
type = TargetState
trigger1 = numtarget && AnimElem = 8
value = 1437+(target,life<=0)

[State 1431, Throw 11]
type = TargetState
trigger1 = AnimElem = 8,=2
value = 6018

[State 1431, State End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Player 2
[statedef 1436]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1436]
type = ScreenBound
trigger1 = 1
value = 1

[state 1436]
type = changeanim2
trigger1 = time=0
value = 1416

[state 1436]
type = selfstate
trigger1 = Time>=60
value = 5000

;Player 2
[statedef 1437]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1437]
type = ScreenBound
trigger1 = 1
value = 1

[state 1437]
type = changeanim2
trigger1 = time=0
value = 1417

[state 1437]
type = selfstate
trigger1 = Time>=60
value = 5000

;Player 2
[statedef 1438]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1438]
type = ScreenBound
trigger1 = 1
value = 1

[state 1438]
type = changeanim2
trigger1 = time = 0
value = 1417

[state 1438]
type = HitFallSet
trigger1 = !time
value = 1

[state 1438]
type = selfstate
trigger1 = Time>=60
value = 5000

;=====================<BIG SWING>==========================
[StateDef 1500]
type = S
physics = S
moveType = A
anim = 1500
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1500, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1500, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1500, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 5000,0
channel = 1

[state 1500]
type = AttackDist
trigger1 = 1
value = 0

[State 1500, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = P2MoveType!=H
trigger1 = P2StateNo!=40
trigger1 = AnimElem = 2
trigger1 = P2bodydist X<=(ceil(58*const(size.xscale))-const(size.ground.front))
attr = S, ST
hitflag = M-
priority = 9, Dodge
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 1511
p2stateno = 1516
p2facing = 1
guard.dist = 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
numhits = 0
guard.dist = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1500]
type = StatetypeSet
trigger1 = AnimElem = 3
movetype = I

[state 1500]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Success
[statedef 1511]
type = A
physics = N
movetype = A
velset = 0,0
ctrl = 0
anim = 1511

[state 1511]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1500,0
channel = 1

[state 1511]
type = PlaySnd
trigger1 = AnimElemTime(3)=1
value = 1,2
channel = 10

[State 1511, Throw 11]
type = Turn
trigger1 = var(10)>=100 && AnimElemTime(3)=0

[State 1511, Throw 11]
type = TargetFacing
trigger1 = var(10)>=100 && AnimElemTime(3)=0
value = -1

[State 1511, Throw 11]
type = TargetState
trigger1 = AnimElemTime(3)=0
value = 1517
persistent=0

[state 1511]
type = Width
trigger1 = time=0
edge = ceil(84*const(size.xscale)),0

[state 1511]
type = Width
trigger1 = AnimElemTime(3)>=0 && AnimElemTime(4)<0
edge = ceil(94*const(size.xscale)),0

[state 1511]
type = Width
trigger1 = AnimElemTime(4)>=0 && AnimElemTime(5)<0
edge = 0,ceil(84*const(size.xscale))

[state 1511]
type = Width
trigger1 = AnimElemTime(5)>=0 && AnimElemTime(6)<0
edge = 0,ceil(110*const(size.xscale))

[state 1511]
type = Width
trigger1 = AnimElemTime(8)>=0
edge = ceil(120*const(size.xscale)),0

[state 1511]
type = targetbind
trigger1 = time=0
pos = ceil(60*const(size.xscale)),-ceil(62*const(size.yscale))

[state 1511]
type = targetbind
trigger1 = AnimElemTime(4)>=0 && AnimElemTime(5)<0
pos = ceil(64*const(size.xscale)),-ceil(82*const(size.yscale))

[state 1511]
type = targetbind
trigger1 = AnimElemTime(3)>=0 && AnimElemTime(4)<0
pos = ceil(32*const(size.xscale))-enemynear,const(size.mid.pos.y),-ceil(66*const(size.yscale))

[state 1511]
type = targetbind
trigger1 = AnimElemTime(4)>=0 && AnimElemTime(5)<0
pos = -ceil(34*const(size.xscale))+enemynear,const(size.mid.pos.y),-ceil(66*const(size.yscale))

[state 1511]
type = targetbind
trigger1 = AnimElemTime(5)>=0 && AnimElemTime(6)<0
pos = -ceil(54*const(size.xscale))+enemynear,const(size.mid.pos.y),-ceil(56*const(size.yscale))

[state 1511]
type = targetbind
trigger1 = AnimElemTime(6)>=0 && AnimElemTime(7)<0
pos = -ceil(20*const(size.xscale))+enemynear,const(size.mid.pos.y),-ceil(46*const(size.yscale))

[state 1511]
type = targetbind
trigger1 = AnimElemTime(7)>=0 && AnimElemTime(8)<0
pos = ceil(44*const(size.xscale))-enemynear,const(size.mid.pos.y),-ceil(46*const(size.yscale))

[state 1511]
type = targetbind
trigger1 = AnimElemTime(8)>=0
pos = ceil(60*const(size.xscale))-enemynear,const(size.mid.pos.y),-ceil(56*const(size.yscale))

[State 1511, Throw 11]
type = VarSet
trigger1 = time=0
var(2) = 0

[State 1511, Throw 11]
type = VarAdd
trigger1 = animelemtime(5)=1
var(2) = 1

[State 1511, Throw 11]
type = ChangeState
trigger1 = var(2)=ifelse(var(10)%100>=5,10,3)&&AnimTime=0
value = 1512

;Finish
[statedef 1512]
type = S
movetype = A
physics = S
ctrl = 0
velset = 0,0
anim = 1512

[state 1512]
type = Width
trigger1 = time=0
edge = ceil(110*const(size.xscale)),0

[state 1512]
type = targetbind
trigger1 = !time
pos = ceil(90*const(size.xscale)),-ceil(36*const(size.yscale))

[state 1512]
type = targetlifeadd
trigger1 = var(10) = 0
trigger1 = !time
value = floor(ifElse(120 * fvar(11) < 7, -7, -120 * fvar(11)))

[state 1512]
type = targetlifeadd
trigger1 = var(10) = 1
trigger1 = !time
value = floor(ifElse(130 * fvar(11) < 7, -7, -130 * fvar(11)))

[state 1512]
type = targetlifeadd
trigger1 = var(10) = 2
trigger1 = !time
value = floor(ifElse(140 * fvar(11) < 7, -7, -140 * fvar(11)))

[State 1512, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = !time
value = 36

[State 1512, Power]
type = PowerAdd
trigger1 = !time && !var(20)
value = 72

[State 1512, HitAdd]
type = HitAdd
trigger1 = !time
value = 1

[State 1512, HitCount]
type = VarAdd
trigger1 = !time
var(13) = 1

[State 1512, Juggle]
type = VarAdd
trigger1 = !time
var(15) = 1
ignoreHitPause = 1

[State 1512, Juggle]
type = VarSet
trigger1 = !time
var(16) = 1
ignoreHitPause = 1

[State 1512, Throw 11]
type = TargetState
trigger1 = AnimElemTime(1)=0
value = 1518

[State 1512, State End]
type = ChangeAnim
trigger1 = Anim=1512 && AnimTime = 0
value = 1513

[State 1512, State End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Player 2
[statedef 1516]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1516]
type = ScreenBound
trigger1 = 1
value = 1

[state 1516]
type = changeanim2
trigger1 = time = 0
value = 1516

;Player 2
[statedef 1517]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1517]
type = ScreenBound
trigger1 = 1
value = 1

[state 1517]
type = changeanim2
trigger1 = time = 0
value = 1517

[state 1517]
type = Turn
trigger1 = Animelemtime(2)=0
trigger2 = AnimElemTime(5)=0

[state 1517]
type = SprPriority
trigger1 = 1
value = -1

[state 1517]
type = SprPriority
trigger1 = Animelemtime(4)>=0&&AnimElemTime(6)<0
value = 2

;Player 2
[statedef 1518]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1518]
type = changeanim2
trigger1 = time=0
value = 1518

[state 1518]
type = changeanim2
trigger1 = Vel Y>-1&&time>1
value = 1519
persistent=0

[state 1518]
type = hitfallset
trigger1 = time=0
value = 1

[state 1518]
type = velset
trigger1 = time=1
x = ifelse(abs(gethitvar(xvel))<2.5,-2.5,-abs(gethitvar(xvel)))
y = ifelse(gethitvar(yvel)!=-5.0,-7.0,gethitvar(yvel))

[state 1518]
type = veladd
trigger1 = time>0&&Pos Y<0
y = .5

[state 1518]
type = HitFallDamage
trigger1 = time && Vel Y>0 && Pos Y>=0

[state 1518]
type = selfstate
trigger1 = Vel Y>0 && Pos Y>=0
value = 5100

;========================<EX BIG SWING>=============================
[StateDef 1530]
type = S
physics = S
moveType = A
anim = 1500
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1530, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1530, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1530, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 131

[State 1530, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1530, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
value = SCA
time = 1

[State 1530, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1530, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 5000,0
channel = 2

[state 1530]
type = AttackDist
trigger1 = 1
value = 0

[State 1530, Hitdef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = P2MoveType!=H
trigger1 = AnimElem = 2,>=0
trigger1 = P2bodydist X<=ceil(58*const(size.xscale))
attr = A, ST
hitflag = M-
priority = 9, Dodge
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 1531
p2stateno = 1536
guard.dist = 0
getpower = 0
givepower = 36, 36
numhits = 0
guard.dist = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1530]
type = StatetypeSet
trigger1 = AnimElem = 3
movetype = I

[state 1530]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Success
[statedef 1531]
type = A
physics = N
movetype = A
velset = 0,0
ctrl = 0
anim = 1531

[state 1531]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1500,0
channel = 1

[state 1531]
type = PlaySnd
trigger1 = AnimElemTime(3)=1
value = 1,2
channel = 10

[State 1531, Throw 11]
type = Turn
trigger1 = var(10)>=100 && AnimElemTime(3)=0

[State 1531, Throw 11]
type = TargetFacing
trigger1 = var(10)>=100 && AnimElemTime(3)=0
value = -1

[State 1531, Throw 11]
type = TargetState
trigger1 = AnimElemTime(3)=0
value = 1537
persistent=0

[state 1531]
type = Width
trigger1 = time = 0
edge = ceil(84*const(size.xscale)),0

[state 1531]
type = Width
trigger1 = AnimElemTime(3)>=0 && AnimElemTime(4)<0
edge = ceil(94*const(size.xscale)),0

[state 1531]
type = Width
trigger1 = AnimElemTime(4)>=0 && AnimElemTime(5)<0
edge = 0,ceil(84*const(size.xscale))

[state 1531]
type = Width
trigger1 = AnimElemTime(5)>=0 && AnimElemTime(6)<0
edge = 0,ceil(110*const(size.xscale))

[state 1531]
type = Width
trigger1 = AnimElemTime(8)>=0
edge = ceil(120*const(size.xscale)),0

[state 1531]
type = targetbind
trigger1 = time=0
pos = ceil(60*const(size.xscale)),-ceil(62*const(size.yscale))

[state 1531]
type = targetbind
trigger1 = AnimElemTime(4)>=0 && AnimElemTime(5)<0
pos = ceil(64*const(size.xscale)),-ceil(82*const(size.yscale))

[state 1531]
type = targetbind
trigger1 = AnimElemTime(3)>=0 && AnimElemTime(4)<0
pos = ceil(32*const(size.xscale))-enemynear,const(size.mid.pos.y),-ceil(66*const(size.yscale))

[state 1531]
type = targetbind
trigger1 = AnimElemTime(4)>=0 && AnimElemTime(5)<0
pos = -ceil(34*const(size.xscale))+enemynear,const(size.mid.pos.y),-ceil(66*const(size.yscale))

[state 1531]
type = targetbind
trigger1 = AnimElemTime(5)>=0 && AnimElemTime(6)<0
pos = -ceil(54*const(size.xscale))+enemynear,const(size.mid.pos.y),-ceil(56*const(size.yscale))

[state 1531]
type = targetbind
trigger1 = AnimElemTime(6)>=0 && AnimElemTime(7)<0
pos = -ceil(20*const(size.xscale))+enemynear,const(size.mid.pos.y),-ceil(46*const(size.yscale))

[state 1531]
type = targetbind
trigger1 = AnimElemTime(7)>=0 && AnimElemTime(8)<0
pos = ceil(44*const(size.xscale))-enemynear,const(size.mid.pos.y),-ceil(46*const(size.yscale))

[state 1531]
type = targetbind
trigger1 = AnimElemTime(8)>=0
pos = ceil(60*const(size.xscale))-enemynear,const(size.mid.pos.y),-ceil(56*const(size.yscale))

[State 1531, Throw 11]
type = VarSet
trigger1 = time = 0
var(2) = 0

[State 1531, Throw 11]
type = VarAdd
trigger1 = animelemtime(3)=1
var(2) = 1

[State 1531, Throw 11]
type = ChangeState
trigger1 = var(2)=((var(10)%100>=5)*7+3) && AnimTime = 0
value = 1532

;Finish
[statedef 1532]
type = S
movetype = A
physics = S
ctrl = 0
velset = 0,0
anim = 1512

[state 1532]
type = Turn
trigger1 = !time && var(10)=1

[state 1532]
type = Width
trigger1 = time=0
edge = ceil(110*const(size.xscale)),0

[state 1532]
type = targetbind
trigger1 = !time
pos = ceil(90*const(size.xscale)),-ceil(36*const(size.yscale))

[state 1532]
type = targetlifeadd
trigger1 = !time
value = floor(ifElse(150 * fvar(11) < 7, -7, -150 * fvar(11)))

[State 1532, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = !time
value = 36

[State 1532, Power]
type = PowerAdd
trigger1 = !time && !var(20)
value = 0

[State 1532, HitAdd]
type = HitAdd
trigger1 = !time
value = 1

[State 1532, HitCount]
type = VarAdd
trigger1 = !time
var(13) = 1

[State 1532, Juggle]
type = VarAdd
trigger1 = !time
var(15) = 1
ignoreHitPause = 1

[State 1532, Juggle]
type = VarSet
trigger1 = !time
var(16) = 1
ignoreHitPause = 1

[State 1532, Throw 11]
type = TargetState
trigger1 = AnimElemTime(1)=0
value = 1538

[State 1532, State End]
type = ChangeAnim
trigger1 = Anim=1512 && AnimTime = 0
value = 1513

[State 1532, State End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Player 2
[statedef 1536]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1536]
type = ScreenBound
trigger1 = 1
value = 1

[state 1536]
type = changeanim2
trigger1 = time = 0
value = 1516

;Player 2
[statedef 1537]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1537]
type = ScreenBound
trigger1 = 1
value = 1

[state 1537]
type = changeanim2
trigger1 = time = 0
value = 1537

[state 1537]
type = Turn
trigger1 = Animelemtime(2)=0
trigger2 = AnimElemTime(5)=0

[state 1537]
type = SprPriority
trigger1 = 1
value = -1

[state 1537]
type = SprPriority
trigger1 = Animelemtime(4)>=0&&AnimElemTime(6)<0
value = 2

;Player 2
[statedef 1538]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 1538]
type = changeanim2
trigger1 = time=0
value = 1518

[state 1538]
type = changeanim2
trigger1 = Vel Y>-1 && time>1
value = 1519
persistent = 0

[state 1538]
type = hitfallset
trigger1 = time = 0
value = 1

[state 1538]
type = velset
trigger1 = time=1
x = ifelse(abs(gethitvar(xvel))<2.5,-2.5,-abs(gethitvar(xvel)))
y = ifelse(gethitvar(yvel)!=-5.0,-7.0,gethitvar(yvel))

[state 1538]
type = veladd
trigger1 = time>0 && Pos Y<0
y = .5

[state 1538]
type = HitFallDamage
trigger1 = time && Vel Y>0 && Pos Y>=0

[state 1538]
type = selfstate
trigger1 = Vel Y>0 && Pos Y>=0
value = 5100

;========================<BIG SNOW>=============================
[StateDef 1600]
type = S
physics = S
moveType = A
anim = 1600
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1600, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1600, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[state 1600]
type = playsnd
trigger1 = animelem = 6
value = 1600,0
volume = 255
channel = 2

[State 1600, Helper]
type = Helper
trigger1 = AnimElem = 6
helpertype = normal
name = "snow"
ID = 1605
stateno = 1605
pos = ceil(50*const(size.xscale)),ceil(0*const(size.yscale))
postype = p1
facing = 1
ownpal = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
persistent =0

[State 1600, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX BIG SNOW>=============================
[StateDef 1630]
type = S
physics = S
moveType = A
anim = 1630
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1630, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1630, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1630, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1630, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 111

[State 1630, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1630, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(6) < 0
value = SCA
time = 1

[State 1630, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[state 1630]
type = playsnd
trigger1 = animelem = 6
value = 1600,0
volume = 255
channel = 2

[State 1630, Helper]
type = Helper
trigger1 = AnimElem = 6
helpertype = normal
name = "snow"
ID = 1605
stateno = 1635
pos = ceil(50*const(size.xscale)),ceil(0*const(size.yscale))
postype = p1
facing = 1
ownpal = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)
persistent =0

[State 1630, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<BIG CYCLONE>==========================
[StateDef 1700]
type = S
physics = S
moveType = A
anim = 1700
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1700, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1700, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1700, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1720, ifElse(var(10) = 1, 1710, 1700))

[state 1700]
type = velset
trigger1 = animelem = 2
y = -10.0

[state 1700]
type = veladd
trigger1 = animelemtime(2)>=0 && animelemtime(4)<0
trigger2 = animelemtime(ifelse(var(10)=0,13,ifelse(var(10)=1,19,25)))>=0
y = 1.0

[state -2]
type = velset
trigger1 = animelemtime(4)>=0 && animelemtime(ifelse(var(10)=0,13,ifelse(var(10)=1,19,25)))<0
x = 3.5
y = 0

[State 1700, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4,2
channel = 0

[State 1700, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 5
trigger2 = AnimElem = 8 && !MoveContact
trigger3 = AnimElem = 11 && !MoveContact
trigger4 = AnimElem = 14 && var(10)>=1 && !MoveContact
trigger5 = AnimElem = 17 && var(10)>=1 && !MoveContact
trigger6 = AnimElem = 20 && var(10)>=2 && !MoveContact
trigger7 = AnimElem = 23 && var(10)>=2 && !MoveContact
value = 1,5
channel = 1

[State 1700, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
trigger2 = AnimElem = 8 && !MoveContact
trigger3 = AnimElem = 11 && !MoveContact
trigger4 = AnimElem = 14 && var(10)>=1 && !MoveContact
trigger5 = AnimElem = 17 && var(10)>=1 && !MoveContact
trigger6 = AnimElem = 20 && var(10)>=2 && !MoveContact
trigger7 = AnimElem = 23 && var(10)>=2 && !MoveContact
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 135, ifElse(var(10), 125, 115)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 135, ifElse(var(10), 125, 115)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -7
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1700]
type = ChangeAnim
trigger1 = animelemtime(4)>=0 && vel Y>0 && Pos Y>=-Vel Y
value = 1740
persistent = 0

[state 1700]
type = PosSet
trigger1 = vel Y>0 && Pos Y>=-Vel Y
y = 0

[state 1700]
type = VelSet
trigger1 = vel Y>0 && Pos Y>=-Vel Y
x = 0
y = 0

[state 1700]
type = StatetypeSet
trigger1 = Pos Y<0
statetype = A
physics = N

[state 1700]
type = StatetypeSet
trigger1 = Pos Y>=0
statetype = S
physics = S

[State 1700, Landing Sound]
type = PlaySnd
trigger1 = Anim = 1740 && AnimTime = 0
value = 52,0

[State 1700, Landing Dust Explod]
type = Explod
trigger1 = Anim = 1740 && AnimTime = 0
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[state 1700]
type = ChangeState
trigger1 = Anim = 1740 && AnimTime = 0
value = 0
ctrl = 1

;========================<EX BIG CYCLONE>=============================
[StateDef 1730]
type = S
physics = S
moveType = A
anim = 1730
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1730, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1730, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1730, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1730, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1730, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1730, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1730, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4,2
channel = 0

[State 1730, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 5
trigger2 = AnimElem = 8
trigger3 = AnimElem = 11
trigger4 = AnimElem = 14 && var(10)>=1
trigger5 = AnimElem = 17 && var(10)>=1
trigger6 = AnimElem = 20 && var(10)>=2
trigger7 = AnimElem = 23 && var(10)>=2
trigger8 = AnimElem = 26 && var(10)>=3
trigger9 = AnimElem = 29 && var(10)>=3
trigger10 = AnimElem = 35 && var(10)>=3
trigger11 = AnimElem = 38 && var(10)>=3
trigger12 = AnimElem = 41 && var(10)>=3
value = 1,5
channel = 3

[state 1730]
type = velset
trigger1 = animelem=2
y = -10.0

[state 1730]
type = veladd
trigger1 = animelemtime(2)>=0 && animelemtime(4)<0
trigger2 = animelemtime(43)>=0
y = 1.0

[state 1730]
type = velset
trigger1 = animelemtime(4)>=0 && animelemtime(43)<0
x = 3.5
y = 0

[State 1730, HitDef]
type = HitDef
triggerall = HitCount <= 2
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
trigger2 = AnimElem = 8
trigger3 = AnimElem = 11
trigger4 = AnimElem = 14 && var(10)>=1
trigger5 = AnimElem = 17 && var(10)>=1
trigger6 = AnimElem = 20 && var(10)>=2
trigger7 = AnimElem = 23 && var(10)>=2
trigger8 = AnimElem = 26 && var(10)>=3
trigger9 = AnimElem = 29 && var(10)>=3
trigger10 = AnimElem = 35 && var(10)>=3
trigger11 = AnimElem = 38 && var(10)>=3
trigger12 = AnimElem = 41 && var(10)>=3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 48 < 7, 7, fvar(11) * 48)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -7
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1730]
type = ChangeAnim
trigger1 = animelemtime(4)>=0 && vel Y>0 && Pos Y>=-Vel Y
value = 1740
persistent = 0

[state 1730]
type = PosSet
trigger1 = vel Y>0 && Pos Y>=-Vel Y
y = 0

[state 1730]
type = VelSet
trigger1 = vel Y>0 && Pos Y>=-Vel Y
x = 0
y = 0

[state 1730]
type = StatetypeSet
trigger1 = Pos Y<0
statetype = A
physics = N

[state 1730]
type = StatetypeSet
trigger1 = Pos Y>=0
statetype = S
physics = S

[State 1730, Landing Sound]
type = PlaySnd
trigger1 = Anim = 1740 && AnimTime = 0
value = 52,0

[State 1730, Landing Dust Explod]
type = Explod
trigger1 = Anim = 1740 && AnimTime = 0
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[state 1730]
type = ChangeState
trigger1 = Anim = 1740 && AnimTime=0
value = 0
ctrl = 1

;=====================<AIR BIG CYCLONE>==========================
[StateDef 1750]
type = A
physics = N
moveType = A
anim = 1750
ctrl = 0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1750, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1750, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1750, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1770, ifElse(var(10) = 1, 1760, 1750))

[State 1750]
type = ChangeAnim
trigger1 = !time
value = anim
elem = 2

[State 1750, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4,2
channel = 0

[State 1750, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 5
trigger2 = AnimElem = 8 && !MoveContact
trigger3 = AnimElem = 11 && !MoveContact
trigger4 = AnimElem = 14 && var(10)>=1 && !MoveContact
trigger5 = AnimElem = 17 && var(10)>=1 && !MoveContact
trigger6 = AnimElem = 20 && var(10)>=2 && !MoveContact
trigger7 = AnimElem = 23 && var(10)>=2 && !MoveContact
value = 1,5
channel = 1

[State 1750, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
trigger2 = AnimElem = 8 && !MoveContact
trigger3 = AnimElem = 11 && !MoveContact
trigger4 = AnimElem = 14 && var(10)>=1 && !MoveContact
trigger5 = AnimElem = 17 && var(10)>=1 && !MoveContact
trigger6 = AnimElem = 20 && var(10)>=2 && !MoveContact
trigger7 = AnimElem = 23 && var(10)>=2 && !MoveContact
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 135, ifElse(var(10), 125, 115)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 135, ifElse(var(10), 125, 115)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -7
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1750]
type = veladd
trigger1 = 1
y = .35

[state 1750]
type = ChangeState
trigger1 = vel Y>0 && Pos Y>=-Vel Y
value = 52

;========================<EX AIR BIG CYCLONE>=============================
[StateDef 1780]
type = A
physics = N
moveType = A
anim = 1780
ctrl = 0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1780, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1780, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1780, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1780, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1780, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1780, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1780, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4,2
channel = 0

[State 1780, Sonic Boom Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 5
trigger2 = AnimElem = 8
trigger3 = AnimElem = 11
trigger4 = AnimElem = 14 && var(10)>=1
trigger5 = AnimElem = 17 && var(10)>=1
trigger6 = AnimElem = 20 && var(10)>=2
trigger7 = AnimElem = 23 && var(10)>=2
trigger8 = AnimElem = 26 && var(10)>=3
trigger9 = AnimElem = 29 && var(10)>=3
trigger10 = AnimElem = 35 && var(10)>=3
trigger11 = AnimElem = 38 && var(10)>=3
trigger12 = AnimElem = 41 && var(10)>=3
value = 1,5
channel = 3

[State 1780]
type = ChangeAnim
trigger1 = !time
value = anim
elem = 2

[State 1780, HitDef]
type = HitDef
triggerall = HitCount <= 2
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
trigger2 = AnimElem = 8
trigger3 = AnimElem = 11
trigger4 = AnimElem = 14 && var(10)>=1
trigger5 = AnimElem = 17 && var(10)>=1
trigger6 = AnimElem = 20 && var(10)>=2
trigger7 = AnimElem = 23 && var(10)>=2
trigger8 = AnimElem = 26 && var(10)>=3
trigger9 = AnimElem = 29 && var(10)>=3
trigger10 = AnimElem = 35 && var(10)>=3
trigger11 = AnimElem = 38 && var(10)>=3
trigger12 = AnimElem = 41 && var(10)>=3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 48 < 7, 7, fvar(11) * 48)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -7
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1780]
type = veladd
trigger1 = 1
y = .35

[state 1780]
type = ChangeState
trigger1 = vel Y>0 && Pos Y>=-Vel Y
value = 52

;=====================<BIG WHEEL>==========================
[StateDef 1800]
type = A
physics = N
moveType = A
anim = 1800
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1800, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1800, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[state 1800]
type = AttackDist
trigger1 = 1
value = 0

[state 1800]
type = PosSet
trigger1 = time = 0
y = 0

[state 1800]
type = PlaySND
trigger1 = AnimElem = 2
value = 4,2
channel = 1
volume = 255

[state 1800]
type = velset
trigger1 = AnimElem=2,=1
x = ifelse(abs(Pos X-enemynear,Pos X)<25,1,ifelse(abs(Pos X-enemynear,Pos X)/25>7,7,abs(Pos X-enemynear,Pos X)/25))-enemynear,vel x*.5*ifelse(enemynear,facing=facing,-1,1)+.5
y = -10.0

[state 1800]
type = veladd
trigger1 = AnimElem=2,>=1
y = .73

[State 1800, HitDef 1]
type = HitDef
triggerall = P2statetype=L && Pos Y>=-15
triggerall = !movecontact && !movereversed
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem=5,>=0
attr = A, SA
hitFlag = FD
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 120, ifElse(var(10), 110, 100)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 120, ifElse(var(10), 110, 100)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -6
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -4, 0
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -20
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1800]
type = PlayerPush
trigger1 = P2bodydist X>15
value = 1

[state 1800]
type = PlayerPush
trigger1 = P2bodydist X<=15
value = 0

[state 1800]
type = varset
trigger1 = time=0
var(2) = 0

[state 1800]
type = varadd
trigger1 = Vel Y>0 && (Pos Y>=0||(movecontact=[1,10]))
var(2) = 1+ifelse(!var(2),(!movecontact),0)

[state 1800]
type = PosSet
trigger1 = Vel Y>0 && Pos Y>=0 && var(2)=1
y = 0

[state 1800]
type = velset
trigger1 = Vel Y>0 && (Pos Y>=0||(movecontact=[1,10])) && var(2)=1
x = 6.0
y = -14.0

[state 1800]
type = veladd
trigger1 = var(2)=1
y = .4

[state 1800]
type = ChangeAnim
trigger1 = Vel Y>=-6 && var(2)=1
value = 41
elem = 5
persistent=0

[state 1800]
type = StatetypeSet
trigger1 = var(2)=1
movetype = I

[state 1800]
type = PlaySND
trigger1 = Vel Y>0 && Pos Y>=0 && !movecontact
value = 52,0
persistent=0

[state 1800]
type = ChangeAnim
trigger1 = Vel Y>0 && Pos Y>=0 && var(2)=2
value = 1801

[state 1800]
type = statetypeset
trigger1 = anim = 1801
statetype = S
physics =S

[state 1800]
type = VelSet
trigger1 = anim = 1801
x = 0
y = 0

[state 1800]
type = PosSet
trigger1 = anim = 1801
y = 0

[state 1800]
type = ChangeState
trigger1 = anim = 1801 && AnimTime = 0
value = 0
ctrl = 1

;========================<EX BIG WHEEL>=============================
[StateDef 1830]
type = A
physics = N
moveType = A
anim = 1800
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1830, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1830, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1830, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1830, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1830, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1830, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[state 1830]
type = AttackDist
trigger1 = 1
value = 0

[state 1830]
type = PosSet
trigger1 = time=0
y = 0

[state 1830]
type = PlaySND
trigger1 = Anim = 1800 && AnimElem = 2
value = 4,2
channel = 2
volume = 255

[state 1830]
type = velset
trigger1 = Anim = 1800 && AnimElem=2,=1
x = ifelse(abs(Pos X-enemynear,Pos X)<25,1,ifelse(abs(Pos X-enemynear,Pos X)/25>7,7,abs(Pos X-enemynear,Pos X)/25))-enemynear,vel x*.5*ifelse(enemynear,facing=facing,-1,1)+.5
y = -10.0

[state 1830]
type = veladd
trigger1 = AnimElem=2,>=1
y = .73

[State 1830, HitDef]
type = HitDef
triggerall = P2statetype=L && Pos Y>=-15
triggerall = !movecontact && !movereversed
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem=5,>=0
attr = A, SA
hitFlag = FD
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 65 < 7, 7, fvar(11) * 65)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -6
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -4, 0
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -20
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1830, HitDef]
type = HitDef
triggerall = P2statetype=L && Pos Y>=-15
triggerall = !movecontact && !movereversed
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Anim = 1830 && AnimElem=5,>=0
attr = A, SA
hitFlag = FD
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 65 < 7, 7, fvar(11) * 65)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -6
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -4, 0
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -20
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[state 1830]
type = PlayerPush
trigger1 = P2bodydist X>15
value = 1

[state 1830]
type = PlayerPush
trigger1 = P2bodydist X<=15
value = 0

[state 1830]
type = varset
trigger1 = time=0
var(2) = 0

[state 1830]
type = varadd
trigger1 = Vel Y>0 && (Pos Y>=0||(movecontact=[1,10]))
var(2) = 1+ifelse(!var(2),(!movecontact),0)

[state 1830]
type = ChangeAnim
trigger1 = (Vel Y=(-1,0)) && movecontact && Anim = 1800
value = 1830

[state 1830]
type = PosSet
trigger1 = Vel Y>0 && Pos Y>=0 && var(2)=1
y = 0

[state 1830]
type = velset
trigger1 = Vel Y>0 && (Pos Y>=0||(movecontact=[1,10])) && var(2)=1 && Anim!=41
x = 0
y = -8.5

[state 1830]
type = velset
trigger1 = Vel Y>0 && (Pos Y>=0||(movecontact=[1,10])) && var(2)>1 && Anim!=41
x = 6.0
y = -14.0

[state 1830]
type = veladd
trigger1 = var(2)>=1 && Statetype = A
y = .4

[state 1830]
type = ChangeAnim
trigger1 = Anim = 1830 && var(2)=2
value = 1800
elem = 5
persistent=0

[state 1830]
type = ChangeAnim
trigger1 = Vel Y>=-4 && var(2)=2
value = 41
elem = 5
persistent=0

[state 1830]
type = MoveHitReset
trigger1 = Anim = 1830 && AnimElem = 1

[state 1830]
type = StatetypeSet
trigger1 = var(2)>=2
movetype = I

[state 1830]
type = PlaySND
trigger1 = Vel Y>0 && Pos Y>=0 && !movecontact
value = 52,0
persistent=0

[state 1830]
type = ChangeAnim
trigger1 = Vel Y>0 && Pos Y>=0 && var(2)>=2
value = 1801

[state 1830]
type = statetypeset
trigger1 = anim = 1801
statetype = S
physics =S

[state 1830]
type = VelSet
trigger1 = anim = 1801
x = 0
y = 0

[state 1830]
type = PosSet
trigger1 = anim = 1801
y = 0

[state 1830]
type = ChangeState
trigger1 = anim = 1801 && AnimTime = 0
value = 0
ctrl = 1

;========================<PUNCH ZERO COUNTER>=============================
[StateDef 2900]
type = S
physics = N
moveType = A
anim = 2900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2900, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2900, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, 2
channel = 0

[State 2900, Woosh]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,2
channel = 1

[State 2900, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 62 < 7, 7, fvar(11) * 62)), 0
getpower = 0,0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 195), var(36) := -75
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2900, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 2900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<KICK ZERO COUNTER>=============================
[StateDef 2910]
type = S
physics = N
moveType = A
anim = 2910
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2910, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2910, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, 2
channel = 0

[State 2910, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,5
channel = 1

[State 2910, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 3
attr = C, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 62 < 7, 7, fvar(11) * 62)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 196), var(36) := -30
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2910, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(4) >= 0
moveType = I

[State 2910, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
