; _________________________________________
;| Sasquatch by varo_hades                 |
; �����������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<BIG TRAP>=============================
[StateDef 3000]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(11) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 9
value = 3000,0
channel = 0

[State 3000, Explod]
type = Explod
trigger1 = AnimElem = 2
ID = 6400
anim = 6400
pos = 0,0
postype = p1
ownpal = 1
keyctrl = 1
scale = const(size.xscale),const(size.yscale)

[State 3000, Helper]
type = Helper
trigger1 = AnimElem = 11
ID = 3005
stateno = 3005
name = "trap"
pos = ceil(140*const(size.xscale)),-ceil(80*const(size.xscale))
postype = p1
ownpal = 1
keyctrl = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[State 3000, Health]
type = LifeAdd
trigger1 = AnimElem = 11
value = 150

[state 3000]
type = AttackDist
trigger1 = 1
value = 0

[state 3000]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl  = 1

;========================<MAX BIG TRAP>=============================
[StateDef 3050]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(11) < 0
time = 1
value = SCA

[State 3050, SuperPause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3050, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3050, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 9
value = 3000,0
channel = 0

[State 3050, Explod]
type = Explod
trigger1 = AnimElem = 2
ID = 6400
anim = 6400
pos = 0,0
postype = p1
ownpal = 1
keyctrl = 1
scale = const(size.xscale),const(size.yscale)

[State 3050, Helper]
type = Helper
trigger1 = AnimElem = 11
ID = 3005
stateno = 3005
name = "trap"
pos = ceil(140*const(size.xscale)),-ceil(80*const(size.xscale))
postype = p1
ownpal = 1
keyctrl = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[State 3050, Health]
type = LifeAdd
trigger1 = AnimElem = 11
value = 300

[state 3050]
type = AttackDist
trigger1 = 1
value = 0

[state 3050]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl  = 1

;========================<BIG FREEZE>=============================
[StateDef 3100]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 5
value = 3100,0
channel = 0

[State 3100, Helper]
type = Helper
trigger1 = AnimElem = 5
ID = 3105
stateno = 3105
name = "freezer"
pos = 0,0
postype = p1
ownpal = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[state 3100]
type = AttackDist
trigger1 = AnimElemTime(6)<0
value = 320

[state 3100]
type = ChangeState
trigger1 = AnimTime=0
value = 0
ctrl  = 1

;========================<MAX BIG FREEZE>=============================
[StateDef 3150]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3150, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3150, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3150, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3150, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 5
value = 3100,0
channel = 0

[State 3150, Helper]
type = Helper
trigger1 = AnimElem = 5
ID = 3105
stateno = 3155
name = "freezer"
pos = 0,0
postype = p1
ownpal = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[state 3150]
type = AttackDist
trigger1 = AnimElemTime(6)<0
value = 320

[state 3150]
type = ChangeState
trigger1 = AnimTime=0
value = 0
ctrl  = 1

;========================<BIG SLEDGE>=============================
[StateDef 3200]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
time = 1
value = SCA

[State 3200, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(0 * const(size.xScale)), ceil(-64 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 5
value = 5000,0
channel = 0

[state 3200]
type = AttackDist
trigger1 = 1
value = 0

[State 3200, 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = P2MoveType!=H
trigger1 = AnimElem = 2,>=0
trigger1 = P2bodydist X<=ceil(68*const(size.xscale))
attr = A, ST
hitflag = M-
priority = 9, Dodge
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 0)
p1stateno = 3211
p2stateno = 3216
guard.dist = 0
getPower = 0,0
givePower = 36, 36
numhits = 0
guard.dist = 0

[state 3200]
type = StatetypeSet
trigger1 = AnimElem=3
movetype = I

[state 3200]
type = ChangeState
trigger1 = AnimTime=0
value = 0
ctrl = 1

;Success
[statedef 3211]
type = A
physics = N
movetype = A
velset = 0,0
ctrl = 0
anim = 3211

[state 3211]
type = Targetstate
trigger1 = !time && numtarget
value = 3216

[state 3211]
type = Width
trigger1 = AnimElemTime(1)=0
edge = ceil(84*const(size.xscale)),0

[state 3211]
type = Width
trigger1 = AnimElemTime(8)=0
edge = ceil(110*const(size.xscale)),0

[state 3211]
type = targetbind
trigger1 = AnimElemTime(1)>=0 && AnimElemTime(2)<0
pos = ceil(84*const(size.xscale)),-ceil(62*const(size.yscale))

[state 3211]
type = targetbind
trigger1 = AnimElemTime(2)>=0 && AnimElemTime(3)<0
pos = ceil(64*const(size.xscale)),-ceil(62*const(size.yscale))

[state 3211]
type = targetbind
trigger1 = AnimElemTime(3)>=0 && AnimElemTime(4)<0
pos = ceil(64*const(size.xscale)),-ceil(62*const(size.yscale))

[state 3211]
type = targetbind
trigger1 = AnimElemTime(4)>=0 && AnimElemTime(5)<0
pos = ceil(64*const(size.xscale)),-ceil(62*const(size.yscale))

[state 3211]
type = targetbind
trigger1 = AnimElemTime(5)>=0 && AnimElemTime(6)<0
pos = -ceil(20*const(size.xscale)),-ceil(130*const(size.yscale))

[state 3211]
type = targetbind
trigger1 = AnimElemTime(6)>=0 && AnimElemTime(7)<0
pos = -ceil(30*const(size.xscale)),-ceil(124*const(size.yscale))

[state 3211]
type = targetbind
trigger1 = AnimElemTime(7)>=0 && AnimElemTime(8)<0
pos = -ceil(40*const(size.xscale)),-ceil(96*const(size.yscale))

[state 3211]
type = targetbind
trigger1 = AnimElemTime(8)>=0 && AnimElemTime(9)<0
pos = -ceil(36*const(size.xscale)),-ceil(50*const(size.yscale))

[state 3211]
type = targetbind
trigger1 = AnimElemTime(9)>=0 && AnimElemTime(10)<0
pos = -ceil(2*const(size.xscale)),-ceil(24*const(size.yscale))

[state 3211]
type = targetbind
trigger1 = AnimElemTime(10)>=0
pos = -ceil(2*const(size.xscale)),-ceil(0*const(size.yscale))

[State 3211, Throw 11]
type = StatetypeSet
trigger1 = AnimElem = 4
statetype = A
physics = N

[State 3211, Throw 11]
type = VelSet
trigger1 = AnimElem=4,=1
x = -7.5
y = -8.5

[state 3211]
type = VelAdd
trigger1 = AnimElem=4,>=1 && statetype = A
y = .5

[state 3211]
type = PlaySnd
trigger1 = AnimElem=10
value = 52,0

[State 3211, Throw 11]
type = StatetypeSet
trigger1 = AnimElem = 10
statetype = S
physics = S

[State 3211, Throw 11]
type = PosSet
trigger1 = AnimElem = 10
y = 0

[State 3211, Throw 11]
type = VelSet
trigger1 = AnimElem = 10
x = 0
y = 0

[State 3211, Throw 11]
type = VarSet
trigger1 = time = 0
var(2) = 0

[State 3211, Throw 11]
type = VarAdd
trigger1 = animelemtime(11)>=0
var(2) = 1

[State 3211, Throw 11]
type = VarSet
trigger1 = AnimElem = 6
var(1) = ceil(ScreenPos X)

[state 3211]
type = Explod
trigger1 = AnimElem = 6;var(2)=1
id = 13300
anim = 13300
pos = 400-(ifelse(facing=-1,320-ceil(ScreenPos X),ceil(ScreenPos X))),0-ceil(Pos Y)
postype = p1
facing = -1
vel = -7.5,0
removetime = -1
ignorehitpause = 1
ownpal = 1
sprpriority = 2
scale = const(size.xscale),const(size.yscale)
persistent = 0

[state 3211]
type = RemoveExplod
trigger1 = AnimElemTime(11)>=0 && abs((400-ifelse(facing=-1,320-var(1),var(1)))-pos x*facing)<=((var(2)+28)*7.5+100)
id = 13300

[state 3211]
type = Explod
trigger1 = AnimElemTime(11)>=0 && abs((400-ifelse(facing=-1,320-var(1),var(1)))-pos x*facing)<=((var(2)+28)*7.5+100)
id = 13310
anim = 13310
pos = 0,0
postype = p1
ignorehitpause=1
ownpal = 1
sprpriority = 2
scale = const(size.xscale),const(size.yscale)
persistent=0

[State 3211, Throw 11]
type = ChangeState
trigger1 = AnimElemTime(11)>=0 && !NumExplod(13300) && !NumExplod(13310)
value = 3212

;Second
[statedef 3212]
type = S
movetype = A
physics = N
ctrl = 0
velset = 0,0
anim = 3212

[state 3212]
type = Targetstate
trigger1 = !time && numtarget
value = 3217

[state 3212]
type = PlaySnd
trigger1 = Time = 0
trigger2 = Time = 60
value = 3200,0

[state 3212]
type = PlaySnd
trigger1 = Time = 0
trigger2 = Time = 30
trigger3 = Time = 85
value = 3200,1
channel = 10

[state 3212]
type = PlaySnd
trigger1 = Time = 15
trigger2 = Time = 70
trigger3 = Time = 85
trigger4 = Time = 100
value = 3200,2
channel = 10

[state 3212]
type = Turn
trigger1 = Time = 30
trigger2 = Time = 70
trigger3 = Time = 108

[state 3212]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 0,0

[state 3212]
type = VelSet
trigger1 = Time = 0
trigger2 = Time = 30
trigger3 = Time = 70
trigger4 = Time = 108
x = 8

[state 3212]
type = VelAdd
trigger1 = Time
x = .5

[state 3212]
type = RemoveExplod
trigger1 = !time
trigger2 = time = 30
trigger3 = time = 70
trigger4 = time = 108
trigger5 = time = 120
id = 13320

[state 3212]
type = Explod
trigger1 = !time
trigger2 = time = 30
trigger3 = time = 70
trigger4 = time = 108
id = 13320
anim = 13320
pos = 0,0
postype = p1
bindtime = -1
removetime = -1
ignorehitpause=1
ownpal = 1
scale = const(size.xscale),const(size.yscale)

[state 3212]
type = Explod
trigger1 = time = 120
id = 13320
anim = 13320
pos = 0,0
postype = p1
vel = vel x, 0
removetime = 24
ignorehitpause=1
ownpal = 1
scale = const(size.xscale),const(size.yscale)

[state 3212]
type = Width
trigger1 = time=0
edge = ceil(110*const(size.xscale)),0

[state 3212]
type = targetbind
trigger1 = 1
pos = ceil(-20*const(size.xscale)),-ceil(0*const(size.yscale))

[State 3212, State End]
type = ChangeState
trigger1 = time>=120
value = 3213

;Third
[statedef 3213]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
anim = 3213

[state 3213]
type = Targetstate
trigger1 = !time && numtarget
value = 3218

[state 3213]
type = targetlifeadd
trigger1 = !time
value = floor(ifElse(200 * fvar(11) < 7, -7, -200 * fvar(11)))
kill = 0

[State 3213, State End]
type = VelSet
trigger1 = time = 1
x = 12
y = -10.0

[State 3213, State End]
type = VelAdd
trigger1 = time>=1
y = .75

[State 3213, State End]
type = PosSet
trigger1 = time>=1 && Vel Y>0 && Pos Y>=-Vel Y
y = 0

[State 3213, State End]
type = ChangeState
trigger1 = time>=1 && Vel Y>0 && Pos Y>=-Vel Y
value = 3214

;Finish
[statedef 3214]
type = S
movetype = A
physics = S
ctrl = 0
velset = 0,0
anim = 3214

[state 3214]
type = PlaySnd
trigger1 = AnimElem = 5
value = 2,5
channel = 2

[state 3214]
type = PlaySnd
trigger1 = AnimElem = 5
value = 4,0
channel = 1

[state 3214]
type = PlaySnd
trigger1 = AnimElem = 5
value = 1,5

[State 3214, Hit Spark]
type = Helper
trigger1 = AnimElem = 5
helperType = Normal
stateNo = 8014
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2dist X)+30+ifelse((Abs(P2bodydist X)-10)<20,-20,-10),ceil(-10*const(size.yscale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[state 3214]
type = targetlifeadd
trigger1 = AnimElem = 5
value = floor(ifElse(220 * fvar(11) < 7, -7, -220 * fvar(11)))

[State 3214, HitAdd]
type = HitAdd
trigger1 = AnimElem = 5
value = 1

[State 3214, HitCount]
type = VarAdd
trigger1 = AnimElem = 5
var(13) = 1

[State 3214, Juggle]
type = VarAdd
trigger1 = AnimElem = 5
var(15) = 1
ignoreHitPause = 1

[State 3214, Juggle]
type = VarSet
trigger1 = AnimElem = 5
var(16) = 1
ignoreHitPause = 1

[state 3214]
type = TargetState
trigger1 = AnimElem=5
value = 3219

[State 3214, State End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Player 2
[statedef 3216]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3216]
type = ScreenBound
trigger1 = 1
value = 1

[state 3216]
type = changeanim2
trigger1 = time = 0
value = 3216

;Player 2
[statedef 3217]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3217]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 0,0

[state 3217]
type = changeanim2
trigger1 = time = 0
value = 3217

[state 3217]
type = SprPriority
trigger1 = 1
value = -1

;Player 2
[statedef 3218]
type = S
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3218]
type = ScreenBound
trigger1 = 1
value = 1

[state 3218]
type = changeanim2
trigger1 = time = 0
value = 3218

[state 3218]
type = SprPriority
trigger1 = 1
value = -1

[state 3218]
type = VelSet
trigger1 = !time
x = 7.5

[state 3218]
type = VelMul
trigger1 = time
x = .975

;Player 2
[statedef 3219]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3219]
type = changeanim2
trigger1 = time = 0
value = 3219

[state 3219]
type = changeanim2
trigger1 = Vel Y>-1 && time>1
value = 3219
persistent = 0

[state 3219]
type = hitfallset
trigger1 = time = 0
value = 1

[state 3219]
type = velset
trigger1 = time = 10
x = -7.5
y = -8.0

[state 3219]
type = veladd
trigger1 = time>=10 && Pos Y<0
y = .5

[state 3219]
type = selfstate
trigger1 = Vel Y>0 && Pos Y>=0
value = 5100

;========================<BIG ICE BURN>=============================
[StateDef 3300]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3300, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3300, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3300, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3300, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3300, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3300, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3300, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3300, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3300, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3300, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3300, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 6
value = 3300,0
channel = 0

[State 3300, Helper]
type = Helper
triggerall = !numhelper(3305)
trigger1 = AnimElem = 9
ID = 3305
stateno = 3305
name="ice_burn"
pos = 0,0
postype = p1
ownpal = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[state 3300]
type = AttackDist
trigger1 = 1
value = 0

[state 3300]
type = ChangeState
trigger1 = NumHelper(3305)
trigger1 = Helper(3305),movehit = 1
value = 3310

[state 3300]
type = ChangeState
trigger1 = AnimTime=0
value = 0
ctrl  = 1

;Conect
[statedef 3310]
type = S
physics = S
movetype = A
ctrl = 0
velset = 0,0
anim = 3350

[State 3310, 1]
type = PlaySND
trigger1 = Time%(8)=0 && time && time<49
value = 3300,1

[State 3310, Helper]
type = RemoveExplod
trigger1 = Time = 76
ID = 6610

[State 3310, Helper]
type = Explod
trigger1 = Time = 76
ID = 6650
anim = 6650
pos = 0,0
postype = p1
ownpal = 1
scale = const(size.xscale),const(size.yscale)

[State 3310, 1]
type = PlaySND
trigger1 = (Anim=[3350,3359]) && AnimElem=11
trigger2 = (Anim=[3350,3359]) && AnimElem=19
value = 195,0
channel = 1

[state 3310]
type = PlaySND
trigger1 = Time = 46
value = 3300,2

[state 3310]
type = PlaySND
trigger1 = AnimElem = 11
trigger2 = AnimElem = 15
value = 52,0

[state 3310]
type = PlaySND
trigger1 = Time = 76
value = 1,6

[state 3310]
type = PlaySND
trigger1 = time = 114
value = 3300,3

[state 3110]
type = AttackDist
trigger1 = 1
value = 0

[state 3310]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl  = 1

;Player 2
[statedef 3311]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3311]
type = ScreenBound
trigger1 = 1
value = 0

[state 3311]
type = NotHitBy
trigger1 = 1
value = SCA

[state 3311]
type = ChangeAnim
trigger1 = !time
value = ifelse(enemynear,name="sasquatch"&&P2dist X<floor(160*enemynear,const(size.xscale)),20,21)

[state 3311]
type = ChangeAnim
trigger1 = AnimElemNo(3)!=AnimElemNo(0)
value = anim
elem = AnimElemNo(3)

[state 3311]
type = ChangeAnim
trigger1 = AnimElemNo(6)!=AnimElemNo(0) && AnimElemTime(AnimElemNo(0))>1
value = anim
elem = AnimElemNo(6)

[state 3311]
type = hitFallSet
trigger1 = !time
value = 1

[state 3311]
type = VelSet
trigger1 = !time
x = ifelse(enemynear,name="sasquatch"&&P2dist X<floor(160*enemynear,const(size.xscale)),-1,1)

[state 3311]
type = VelSet
trigger1 = 1
x = ifelse(enemynear,name="sasquatch"&&(P2dist X=[floor(160*enemynear,const(size.xscale)),floor(180*enemynear,const(size.xscale))]),0,vel x)

[state 3311]
type = ChangeState
trigger1 = time>=46
value = 3312

;Player 2
[statedef 3312]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3312]
type = ScreenBound
trigger1 = 1
value = 0

[state 3312]
type = NotHitBy
trigger1 = 1
value = SCA

[state 3312]
type = ChangeAnim
trigger1 = !time
value = ifelse(SelfAnimExist(5070),5070,5050)

[state 3312]
type = VelSet
trigger1 = time
x = 0
y = -8
persistent=0

[state 3312]
type = VelAdd
trigger1 = time
y = .55

[state 3312]
type = ChangeState
trigger1 = Vel Y>0 && Pos Y>=10
value = 3313

;Player 2
[statedef 3313]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3313]
type = PosSet
trigger1 = !time
y = 10

[state 3313]
type = ScreenBound
trigger1 = 1
value = 0

[state 3313]
type = NotHitBy
trigger1 = 1
value = SCA

[state 3313]
type = ChangeAnim
trigger1 = !time
value = ifelse(SelfAnimExist(5171),5171,5170)

[state 3313]
type = ChangeAnim
trigger1 = time=3
value = ifelse(SelfAnimExist(5070),5070,5050)

[state 3313]
type = VelSet
trigger1 = time=3
x = 0
y = -4
persistent=0

[state 3313]
type = VelAdd
trigger1 = time>=3
y = .5

[state 3313]
type = ChangeState
trigger1 = Vel Y>0 && Pos Y>=20
value = 3314

;Player 2
[statedef 3314]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3314]
type = PosSet
trigger1 = !time
y = 0

[state 3314]
type = ScreenBound
trigger1 = 1
value = 1

[state 3314]
type = NotHitBy
trigger1 = 1
value = SCA

[state 3314]
type = ChangeAnim2
trigger1 = 1
value = 1

[state 3314]
type = PosSet
trigger1 = 1
y = 0

[state 3314]
type = ChangeState
trigger1 = time>=24
value = 6018

;========================<MAX BIG ICE BURN>=============================
[StateDef 3350]
type = S
physics = S
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3350, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3350, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3350, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3350, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3350, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3350, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3350, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3350, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3350, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3350, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3350, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 6
value = 3300,0
channel = 0

[State 3350, Helper]
type = Helper
triggerall = !numhelper(3355)
trigger1 = AnimElem = 9
ID = 3355
stateno = 3355
name="ice_burn"
pos = 0,0
postype = p1
ownpal = 1
size.xscale = const(size.xscale)
size.yscale = const(size.yscale)

[state 3350]
type = AttackDist
trigger1 = 1
value = 0

[state 3350]
type = ChangeState
trigger1 = NumHelper(3355)
trigger1 = Helper(3355),movehit = 1
value = 3360

[state 3350]
type = ChangeState
trigger1 = AnimTime=0
value = 0
ctrl  = 1

;Success
[statedef 3360]
type = S
physics = S
movetype = A
ctrl = 0
velset = 0,0
anim = 3360

[State 3360, 1]
type = PlaySND
trigger1 = Time%(6)=0 && time && time<49
value = 3300,1

[State 3360, Helper]
type = RemoveExplod
trigger1 = Time = 76
ID = 6610

[State 3360, Helper]
type = Explod
trigger1 = Time = 76
ID = 6650
anim = 6650
pos = 0,0
postype = p1
ownpal = 1
scale = const(size.xscale),const(size.yscale)

[state 3360]
type = PlaySND
trigger1 = Time = 46
value = 3300,2

[state 3360]
type = PlaySND
trigger1 = AnimElem = 15
trigger2 = AnimElem = 19
trigger3 = AnimElem = 23
trigger4 = AnimElem = 27
value = 52,0

[state 3360]
type = PlaySND
trigger1 = Time = 76
value = 1,6

[state 3360]
type = PlaySND
trigger1 = time = 100
value = 3300,3

[state 3360]
type = PlaySND
trigger1 = time = 124
value = 1400,1

[State 3360, Helper]
type = ChangeAnim
trigger1 = Time <146 && Anim>=3260 && AnimTime=0
value = 3360+(time=[49,99])+(time=[100,146])*2

[State 3360, Helper]
type = ChangeState
trigger1 = Time>=146 && Anim>=3360 && AnimTime=0
value = 3370

[state 3360]
type = AttackDist
trigger1 = 1
value = 0

[state 3360]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl  = 1

;Success
[statedef 3370]
type = S
physics = S
movetype = A
ctrl = 0
velset = 0,0
anim = 3365
juggle = 15

[State 3370, 1]
type = Screenbound
trigger1 = 1
value = 1
movecamera = 1,1

[state 3370]
type = PlaySND
trigger1 = AnimElem = 3
value = 1,2

[state 3370]
type = PlaySND
trigger1 = AnimElem = 4
value = 4,0
channel = 1

[State 3370, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 6
attr = S,SA
hitflag = MAF
guardflag = M
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
animtype = hard
air.animtype = back
;fall.animtype = Back
pausetime = 5,10
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -55
ground.type = High
;air.type = High
ground.slidetime = 17
ground.hittime = 17
guard.slidetime = 16
guard.hittime = 16
yaccel = .5
ground.velocity = -13.0*const(size.xscale)
guard.velocity = -13.0*const(size.xscale)
air.velocity = -2.5,-6.5
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
fall = 0
air.fall = 1
fall.xvelocity = -2.0*ifelse(enemynear,facing=facing,-1,1)
fall.recover = 0
air.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3370, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 2
trigger1 = AnimElem = 7
attr = S,SA
hitflag = MAF
guardflag = MA
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
animtype = hard
air.animtype = back
;fall.animtype = Back
pausetime = 5,10
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -55
ground.type = High
;air.type = High
ground.slidetime = 17
ground.hittime = 17
guard.slidetime = 16
guard.hittime = 16
yaccel = .5
ground.velocity = -13.0*const(size.xscale)
guard.velocity = -13.0*const(size.xscale)
air.velocity = -2.5,-6.5
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
fall = 0
air.fall = 1
fall.xvelocity = -2.0*ifelse(enemynear,facing=facing,-1,1)
fall.recover = 0
air.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3370, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 3
trigger1 = AnimElem = 8
attr = S,SA
hitflag = MAF
guardflag = M
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
animtype = hard
air.animtype = back
;fall.animtype = Back
pausetime = 5,10
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -55
ground.type = High
;air.type = High
ground.slidetime = 17
ground.hittime = 17
guard.slidetime = 16
guard.hittime = 16
yaccel = .5
ground.velocity = -2.5,-6.5
guard.velocity = -13.0*const(size.xscale)
air.velocity = -2.5,-6.5
ground.cornerpush.veloff = 0
air.cornerpush.veloff = 0
fall = 1
air.fall = 1
fall.xvelocity = -2.0*ifelse(enemynear,facing=facing,-1,1)
fall.recover = 0
air.recover = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[state 3370]
type = statetypeset
trigger1 = animelem = 5
physics = N

[state 3370]
type = velset
trigger1 = animelem = 5
x = 12

[state 3370]
type = velset
trigger1 = AnimElem = 9
x = 0

[state 3370]
type = StatetypeSet
trigger1 = AnimElem = 9
movetype = I

[state 3370]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl  = 1

;Player 2
[statedef 3361]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3361]
type = ScreenBound
trigger1 = 1
value = 0

[state 3361]
type = NotHitBy
trigger1 = 1
value = SCA

[state 3261]
type = ChangeAnim
trigger1 = !time
value = ifelse(enemynear,name="sasquatch"&&P2dist X<floor(160*enemynear,const(size.xscale)),20,21)

[state 3261]
type = ChangeAnim
trigger1 = AnimElemNo(3)!=AnimElemNo(0)
value = anim
elem = AnimElemNo(3)

[state 3261]
type = ChangeAnim
trigger1 = AnimElemNo(6)!=AnimElemNo(0) && AnimElemTime(AnimElemNo(0))>1
value = anim
elem = AnimElemNo(6)

[state 3261]
type = hitFallSet
trigger1 = !time
value = 1

[state 3261]
type = VelSet
trigger1 = !time
x = ifelse(enemynear,name="sasquatch"&&P2dist X<floor(160*enemynear,const(size.xscale)),-1,1)

[state 3261]
type = VelSet
trigger1 = 1
x = ifelse(enemynear,name="sasquatch"&&(P2dist X=[floor(160*enemynear,const(size.xscale)),floor(180*enemynear,const(size.xscale))]),0,vel x)

[state 3361]
type = ChangeState
trigger1 = time>=46
value = 3362

;Player 2
[statedef 3362]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3362]
type = ScreenBound
trigger1 = 1
value = 0

[state 3362]
type = NotHitBy
trigger1 = 1
value = SCA

[state 3362]
type = ChangeAnim
trigger1 = !time
value = ifelse(SelfAnimExist(5070),5070,5050)

[state 3362]
type = VelSet
trigger1 = time
x = 0
y = -8
persistent = 0

[state 3362]
type = VelAdd
trigger1 = time
y = .55

[state 3361]
type = ChangeState
trigger1 = Vel Y>0 && Pos Y>=10
value = 3363

;Player 2
[statedef 3363]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3363]
type = PosSet
trigger1 = !time
y = 10

[state 3363]
type = ScreenBound
trigger1 = 1
value = 0

[state 3363]
type = NotHitBy
trigger1 = 1
value = SCA

[state 3363]
type = ChangeAnim
trigger1 = time<=2
value = ifelse(SelfAnimExist(5070),5070,5050)

[state 3363]
type = VelSet
trigger1 = time=3
x = 0
y = -4
persistent=0

[state 3363]
type = VelAdd
trigger1 = time>=3
y = .5

[state 3363]
type = ChangeState
trigger1 = Vel Y>0 && Pos Y>=10
value = 3364

;Player 2
[statedef 3364]
type = A
movetype = H
physics = N
ctrl = 0
velset = 0,0

[state 3364]
type = PosSet
trigger1 = !time
y = 0

[state 3364]
type = ScreenBound
trigger1 = 1
value = 1

[state 3364]
type = NotHitBy
trigger1 = 1
value = SCA

[state 3364]
type = ChangeAnim2
trigger1 = 1
value = 1

[state 3364]
type = PosSet
trigger1 = 1
y = 0

[state 3364]
type = HitFallSet
trigger1 = 1
value = 0

[state 3364]
type = ChangeState
trigger1 = time>=24
value = 6020

;========================<BIG RESISTOR WITH M.A.P.S>=============================
[StateDef 3400]
type = S
physics = S
moveType = I
anim = 3400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3400, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3400, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3400, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3400, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3400, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3400, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3400, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3400, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3400, SuperPause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3400, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3400, 6]
type = PlaySND
trigger1 = AnimElem = 3
value = 190,0
channel = 1

[State 3400, 6]
type = PlaySND
trigger1 = AnimElem = 2
value = 3400,0

[State 3400, 6]
type = PlaySND
trigger1 = AnimElem = 2
value = 4,0
channel = 2

[State 3400, 6]
type = varset
trigger1 = Time
var(52) = 250

[state 3400]
type = Helper
trigger1 = AnimElem = 3
id = 10000
stateno = 10400
pos = -40,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3400]
type = Helper
trigger1 = AnimElem = 3
id = 10001
stateno = 10401
pos = -50,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3400]
type = Helper
trigger1 = AnimElem = 3
id = 10002
stateno = 10402
pos = -60,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3400]
type = Helper
trigger1 = AnimElem = 3
id = 10003
stateno = 10403
pos = -70,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3400]
type = Helper
trigger1 = AnimElem = 3
id = 10004
stateno = 10404
pos = -80,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3400]
type = Helper
trigger1 = AnimElem = 3
id = 10005
stateno = 10405
pos = -90,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3400]
type = Helper
trigger1 = AnimElem = 3
id = 10006
stateno = 10406
pos = -100,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3400]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl  = 1

;========================<MAX RESISTOR WITH M.A.P.S>=============================
[StateDef 3450]
type = S
physics = S
moveType = I
anim = 3400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3450, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3450, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3450, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3450, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3450, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3450, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3450, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3450, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3450, SuperPause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-65 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3450, SuperPause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3450, 6]
type = PlaySND
trigger1 = AnimElem = 3
value = 190,0
channel = 1

[State 3450, 6]
type = PlaySND
trigger1 = AnimElem = 2
value = 3400,0

[State 3450, 6]
type = PlaySND
trigger1 = AnimElem = 2
value = 4,0
channel = 2

[State 3450, 6]
type = varset
trigger1 = Time
var(52) = 500

[state 3450]
type = Helper
trigger1 = AnimElem = 3
id = 10000
stateno = 10400
pos = -40,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3450]
type = Helper
trigger1 = AnimElem = 3
id = 10001
stateno = 10401
pos = -50,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3450]
type = Helper
trigger1 = AnimElem = 3
id = 10002
stateno = 10402
pos = -60,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3450]
type = Helper
trigger1 = AnimElem = 3
id = 10003
stateno = 10403
pos = -70,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3450]
type = Helper
trigger1 = AnimElem = 3
id = 10004
stateno = 10404
pos = -80,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3450]
type = Helper
trigger1 = AnimElem = 3
id = 10005
stateno = 10405
pos = -90,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3450]
type = Helper
trigger1 = AnimElem = 3
id = 10006
stateno = 10406
pos = -100,0
postype = p1
name = "penguin"
ignorehitpuase=1

[state 3450]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl  = 1
