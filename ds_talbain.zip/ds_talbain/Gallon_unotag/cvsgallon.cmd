





[Defaults]
command.time = 15
command.buffer.time = 1

[Command]
name = "Moment Slice"
command = ~x, y, F, a, b
time = 35
[Command]
name = "Moment Slice"
command = ~x, y, F, a, ~b
time = 35

[Command]
name = "Moment Slice 2"
command = ~x, y, B, a, b
time = 35
[Command]
name = "Moment Slice 2"
command = ~x, y, B, a, ~b
time = 35

[Command]
name = "HCFx2"
command = ~B,D,F,B,D,F
time = 30

[Command]
name = "HCBx2"
command = ~F,D,B,F,D,B
time = 30

[Command]
name = "QCFx2"
command = ~D,DF,F,D,DF
time = 21
[Command]
name = "QCBx2"
command = ~D,DB,B,D,DB
time = 21


[Command]
name = "DU"
command = ~$D,$U
time = 12

[Command]
name = "DP"
command = ~F,D,DF
time = 12

[Command]
name = "rDP"
command = ~B,D,DB
time = 12

[Command]
name = "QCF"
command = ~D,DF,F
time = 12

[Command]
name = "QCB"
command = ~D,DB,B
time = 12

[Command]
name = "HCF"
command = ~B,DB,D,DF,F
time = 18

[Command]
name = "HCB"
command = ~F,DF,D,DB,B
time = 18

[Command]
name = "mash_x"
command = x,x,x


[Command]
name = "longjump"
command = D,$U
time = 10

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10


[Command]
name = "recovery"
command = x+a
time = 1


[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

[Command]
name = "back"
command = B
time = 1

[Command]
name = "upback"
command = UB
time = 1

[Command]
name = "downback"
command = DB
time = 1

[Command]
name = "parry"
command = F
time = 1

[Command]
name = "parry2"
command = D
time = 1

[Command]
name = "rich"
command = U
time = 1

[Command]
name = "up"
command = U
time = 3

[Command]
name = "down"
command = D
time = 3

[Command]
name = "down2"
command = $D
time = 1


[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_start"
command = /s
time = 1


[Command]
name = "holdfwd"
command = /$F
time = 1
[Command]
name = "holddown"
command = /$D
time = 1
[Command]
name = "holdback"
command = /$B
time = 1
[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holdfwd_r"
command = /F
time = 1
[Command]
name = "holddown_r"
command = /D
time = 1
[Command]
name = "holdback_r"
command = /B
time = 1
[Command]
name = "holdup_r"
command = /U
time = 1


[Command]
name = "release_fwd"
command = ~F
time = 1

[Command]
name = "release_down"
command = ~D
time = 1

[Command]
name = "release_back"
command = ~B
time = 1

[Command]
name = "release_up"
command = ~U
time = 1


[Command]
name = "release_a"
command = ~a
time = 1

[Command]
name = "release_b"
command = ~b
time = 1

[Command]
name = "release_c"
command = ~c
time = 1

[Command]
name = "release_x"
command = ~x
time = 1

[Command]
name = "release_y"
command = ~y
time = 1

[Command]
name = "release_z"
command = ~z
time = 1

[Command]
name = "release_start"
command = ~s
time = 1




;   --- Uno Tag System [Type-R] Command definition ---

[Command]
name = "aHsoNn"
command = ~D, D, D, z+c
Time = 25

[Command]
name = "sheoun"
command = ~D, DF, F, z+c
Time = 25

[Command]
name = "palit"
command = z+c
Time = 2

[Command]
name = "turtleuno"
command = s
Time = 2


[Statedef -1]


[State -1, Partner Assist]
type = VarSet
sysvar(4) = 10
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 60 && Time > 0
triggerall = teammode = Simul
triggerall = StateNo != [3000,1251199]
triggerall = hitdefattr != SCA, HA, HP, HT
triggerAll = StateNo != [130,152]
triggerall = !(StateNo = [5000,5500])
triggerall = Power >= 500
trigger1 = command = "turtleuno"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = !ctrl && Movetype = A
trigger2 = Random < (((2 * ifelse(MoveContact, ifelse(MoveHit, 2, 3),1)) + (UniqHitCount * 2)) *(AILevel**2/64.0))
trigger3 = AILevel >  0
trigger3 = StateNo = [190,199]
trigger3 = AnimElemNo(0) = 2
ignorehitpause = 1

[State -1, Team Hyper Attack]
type = ChangeState
value = 1251125
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = Partner, life > 0
triggerall = power >= 3000
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 9		
triggerall= (StateType != A)
trigger1 = command = "sheoun"
trigger1 = (Ctrl = 1)
trigger1 = AILevel <=  0
trigger2 = command = "sheoun"
trigger2 = Anim = [200,1000]
trigger2 = movetype = A
trigger2 = hitdefattr = SC, NA
trigger2 = MoveContact
trigger2 = AILevel <=  0
trigger3 = AILevel > 0 && ctrl
trigger3 = Random < (10 + ((Life < Lifemax/6)*3))
trigger3 = NumEnemy && enemy, pos x = [0,200]
trigger4 = AILevel >  0
trigger4 = Anim = [200,1000]
trigger4 = movetype = A
trigger4 = hitdefattr = SC, NA
trigger4 = MoveContact
trigger4 = Random < (11 + ((MoveHit)*5) + ((Life < Lifemax/6)*5))
ignorehitpause = 1

[State -1, Delayed Hyper]
type = ChangeState
value = 1251127
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0
triggerall = power >= 1000
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time > 1 && Time > 45
triggerall = movetype = A
triggerall = StateNo = [2000,1251100]
triggerall = hitdefattr = SCA, HA, HP, HT || (StateNo >= 2000 && StateNo < 4000 && (hitcount < 8 || NumTarget && Target, GetHitVar(hitTime) >= 0))
trigger1 = command = "sheoun"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = NumTarget && MoveContact
trigger2 = Random < (10*(AILevel**2/64.0) + (Uniqhitcount*((Life < Partner,Life)*2)))
trigger2 = Partner, Time > 35
trigger3 = AILevel >  0
trigger3 = Partner, Time > 30 && Time > 25
trigger3 = HitCount >= 6
trigger3 = Random < (2 * Uniqhitcount * ifelse(hitcount > 9, 2, 1))
ignorehitpause = 1

[State -1, UNO Mode]
type = ChangeState
value = 1251128
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0 && Power >= 1000
triggerall = Life <= (Lifemax/8)
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 20
triggerall = (StateType != A) && ((Ctrl = 1) || StateNo = 0 || (Movetype = A && hitdefattr = SC, NA))
trigger1 = command = "aHsoNn"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Partner, Life < Lifemax/4
trigger2 = Random < ((25 + ifelse((Partner, Life < Lifemax/6), 25, 5))*(AILevel**2/64.0))

[State -1, Change Attack]
type = ChangeState
value = 1251126
triggerall = NumPartner
triggerall = (sysvar(4) = 1 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),250,500)) || (sysvar(4) = 15 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),500,1000))
triggerall = Partner, life > 0
triggerall = movetype = A && !MoveReversed
triggerall = (Partner, StateNo = 1251112 || Partner, StateNo = 1251114)  && Time > 1
triggerall = StateNo = [200,4850]
triggerall = StateNo != [1251102,1251105]
triggerall = NumTarget > 0 && Target, pos Y > -160
triggerall = (Target, StateNo != [5110,5955])
triggerall = Hitdefattr != SCA, NT && ((Target, Statetype = A || (Hitdefattr != A, NA && Target, Statetype != A)) && ((!Target, HitOver || EnemyNear, StateNo = [5000,5900]) && (MoveContact || ProjContactTime(0) < 8)))
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = UniqHitCount >= 2
trigger2 = Random < (((ifelse(sysvar(4)=15,25,50)*(AILevel**2/64.0)) + ((hitdefattr = SCA, SA, HA)*15) + ifelse(lifemax/life > 15, 15, lifemax/life)))
trigger2 = Partner, Life > Lifemax/10 || Life <= Partner, Life
trigger2 = Partner, Time > 25
trigger3 = AILevel >  0
trigger3 = Partner, Time > 27
trigger3 = Random < (25*(2*(Life = (Lifemax/4) && Life < Partner, Life)) *(AILevel**2/64.0))
trigger3 = MoveContact
ignorehitpause = 1

[State -1, TagIn]
type = ChangeState
value = 1251110
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner && NumEnemy
triggerall = RoundState = 2 
triggerall = Partner, life > 0
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 40	
triggerall = (MoveType != A && StateType != A) && (Ctrl = 1) || StateNo = 0
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Random < (ifelse((LifeMax/Life > 120), 120, LifeMax/Life)+((EnemyNear,statetype=L)*25))
trigger2 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond
trigger2 = EnemyNear, movetype != A
trigger3 = AILevel >  0
trigger3 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond && Life < LifeMax * (LifeMax*0.55)
trigger3 = Random < ((ifelse(LifeMax/Life > 10, 10, LifeMax/Life) + (10+ifelse((EnemyNear, StateNo > 5000),25,1))) * ifelse((Life < Partner, Life), 1.45, 0.5))
trigger3 = Partner, Time > 1 * TicksPerSecond
trigger3= EnemyNear, statetype = L || p2bodydist x > 250 && EnemyNear, movetype != A
trigger4 = AILevel >  0
trigger4 = Life < 150 && Life < Partner, Life
trigger4 = EnemyNear, statetype = L || p2bodydist x > 200 && EnemyNear, movetype != A
trigger4 = Random < (125*(AILevel**2/64.0))

[State -1, C_6]
type = CtrlSet
value = 1
triggerall = RoundState = 2 && NumPartner
triggerall = NumTarget && Target, StateNo != [200,4999]
triggerall = StateNo != 1251106 && !Ctrl
triggerall = (Partner, StateNo != [1251128,1251129]) && (Partner, PrevStateNo != [1251128,1251129])
trigger1 = command="x"||command="y"||command="z"||command="a"||command="b"||command="c"
trigger1 = sysvar(4) = 7
trigger1 = Movetype = A
trigger1 = MoveContact
trigger1 = hitdefattr = SCA, NA, SA
trigger1 = StateNo != PrevStateNo
trigger1 = Time > 3
trigger2 = PrevStateNo = 1251106
ignorehitpause = 0

; ------ Uno Tag System [Type-R] END LINE -------

;  ;]





[state 0]
type=selfstate
trigger1=ctrl && numpartner && !ishelper && roundstate=2 && pos y=0
trigger1=sysfvar(4)>0 && sysfvar(0)>0 && playeridexist(floor(sysfvar(0)))
trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(22)=4
value=190190
ctrl=0
ignorehitpause=1






[State -1, Buffered Walk]
type = AssertSpecial
trigger1 = NumHelper(10371)
flag = NoWalk
[State -1, Buffered Walk]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 

triggerall = NumHelper(10371)
triggerall = command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
triggerall = !isHelper
triggerall = (StateNo != [11,12]) && StateNo != 20 && StateNo != 40 && !(StateNo = 52 && Time < 5)
triggerall = Ctrl && (StateNo != [120,132]) && (StateNo != [150,155]) && (StateNo != [700,720])
trigger1 = (helper(10371), Var(16) = [1,9])
trigger1 = !(helper(10371), Var(18) > helper(10371), Var(16))
trigger2 = (helper(10371), Var(17) = [1,9])
trigger2 = !(helper(10371), Var(19) > helper(10371), Var(17))
trigger3 = (helper(10371), Var(16) = -1) || (helper(10371), Var(17) = -1)
value = 20
[State -1, M.I.X. THE CRACK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = NumHelper(10371)
triggerall = !(helper(10371), Var(14) = [1,2])
triggerall = !((helper(10371), Var(15) = [1,9]) || (helper(10371), Var(15) = -1))

triggerall = statetype != A
triggerall = roundstate = 2
triggerall = !isHelper
triggerall = StateNo != 0 && (StateNo != [11,12]) && StateNo != 20 && StateNo != 52
trigger1 = Ctrl && (StateNo != [120,132]) && (StateNo != [150,155]) && (StateNo != [700,720])
value = ifElse(((helper(10371), Var(16)) || (helper(10371), Var(17))), 20, 0)
[State -1, M.I.X. THE CRACK]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
triggerall = NumHelper(10371)
triggerall = helper(10371), Var(14) = [1,2]

triggerall = statetype != A
triggerall = roundstate = 2
triggerall = !isHelper
triggerall = StateNo != 0 && (StateNo != [11,12]) && StateNo != 20 && StateNo != 40
trigger1 = Ctrl && (StateNo != [120,132]) && (StateNo != [150,155]) && (StateNo != [700,720])
value = 40


[State -2, PlaySnd]
type = Playsnd
triggerall = Time = 0
trigger1 = StateNo = 700
trigger2 = StateNo = 710
trigger3 = StateNo = 720
trigger4 = StateNo = 150 && Var(14) = 1
trigger5 = StateNo = 152 && Var(14) = 1
trigger6 = StateNo = 154 && Var(14) = 1
value = S8,0
channel = 0

[State 710, Explod]
type = Explod
triggerall = Time = 0
trigger1 = StateNo = 700
trigger2 = StateNo = 710
trigger3 = StateNo = 720
anim = 7500

pos = ifElse(StateNo=720,14,ifElse(StateNo=710,35,49)),ifElse(StateNo=720,-84,ifElse(StateNo=710,-28,-77))
sprpriority = 3
ownpal = 1
scale = .5,.5
pausemovetime = 15
[State 500, Explod]
type = Explod
triggerall = Time = 0
triggerall = Var(14) = 1
trigger1 = StateNo = 150
trigger2 = StateNo = 152
trigger3 = StateNo = 154
anim = 7000

pos = ifElse(StateNo=152,21,0),ifElse(StateNo=154,-63,ifElse(StateNo=152,-35,-56))
sprpriority = 3
ownpal = 1
scale = .5,.5
pausemovetime = 4






[State -1, P]
type = VarSet

trigger1 = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2])
trigger2 = !Var(30)
trigger2 = (helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])
var(46) = 1
ignorehitpause = 1
[State -1, K]
type = VarSet

trigger1 = (helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2])
trigger2 = !Var(30)
trigger2 = (helper(10371), Var(10) = [1,2]) || (helper(10371), Var(11) = [1,2]) || (helper(10371), Var(12) = [1,2])
var(46) = 0
ignorehitpause = 1
[State -1, P beats ~K]
type = VarSet

triggerall = !Var(30)
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2])
trigger1 = (helper(10371), Var(0) >= helper(10371), Var(10)) || (helper(10371), Var(0) >= helper(10371), Var(11))
trigger2 = (helper(10371), Var(0) >= helper(10371), Var(12)) || (helper(10371), Var(1) >= helper(10371), Var(10))
trigger3 = (helper(10371), Var(1) >= helper(10371), Var(11)) || (helper(10371), Var(1) >= helper(10371), Var(12))
trigger4 = (helper(10371), Var(2) >= helper(10371), Var(10)) || (helper(10371), Var(2) >= helper(10371), Var(11))
trigger5 = (helper(10371), Var(2) >= helper(10371), Var(12))
var(46) = 1
ignorehitpause = 1
[State -1, K beats ~P]
type = VarSet

triggerall = !Var(30)
triggerall = (helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2])
trigger1 = (helper(10371), Var(3) >= helper(10371), Var(7)) || (helper(10371), Var(3) >= helper(10371), Var(9))
trigger2 = (helper(10371), Var(3) >= helper(10371), Var(9)) || (helper(10371), Var(4) >= helper(10371), Var(7))
trigger3 = (helper(10371), Var(4) >= helper(10371), Var(8)) || (helper(10371), Var(4) >= helper(10371), Var(9))
trigger4 = (helper(10371), Var(5) >= helper(10371), Var(7)) || (helper(10371), Var(5) >= helper(10371), Var(8))
trigger5 = (helper(10371), Var(5) >= helper(10371), Var(9))
var(46) = 0
ignorehitpause = 1



[State -1, Moment Slice]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3200
triggerall = numHelper(10371)
triggerall = helper(10371), Var(42)
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 3) && Power >= 3000) || (Var(10) = 4 && (100*life/const(data.life))<=30 && Var(17)) || (Var(29) && Power >= 1000) || Var(19)
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && AnimElemTime(4) < 0
trigger4 = StateNo = 215 && AnimElemTime(3) < 0
trigger5 = StateNo = 225 && (Var(30) || AnimElemTime(5) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 230 && AnimElemTime(3) < 0
trigger7 = StateNo = 235 && AnimElemTime(3) < 0
trigger8 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && AnimElemTime(4) < 0
trigger11 = StateNo = 430 && AnimElemTime(3) < 0
trigger12 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger13 = StateNo = 450 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger14 = (StateNo = [1000,1499]) && Var(50) && (((var(5)&16)>0) || Var(30))
ignorehitpause = 0



[State -1, Dragon Cannon]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 3100

triggerall = numHelper(10371)
triggerall = helper(10371), var(41)
triggerall = (helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2]) || (!Var(30) && ((helper(10371), Var(10) = [1,2]) || (helper(10371), Var(11) = [1,2]) || (helper(10371), Var(12) = [1,2])))
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 5) && Power >= 1000) || (Var(10) = 2 && Power >= 1500) || (Var(10) = 3 && Power >= 3000) || (Var(10) = 4 && ((100*Life)/(Const(data.life))<=30)) || Var(19) || Var(17) || Var(30)
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 225 && (Var(30) || AnimElemTime(5) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger9 = StateNo = 400
trigger10 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger12 = StateNo = 450 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger13 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger14 = (StateNo = [1000,1499]) && Var(50) && (((var(5)&16)>0) || Var(30))
trigger15 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Dragon Cannon/Hyper Beast Cannon]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = ifElse(!Var(46) && (helper(10371), Var(41)), 3100, 3000)

triggerall = numHelper(10371)
triggerall = helper(10371), var(40)
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 5) && Power >= 1000) || (Var(10) = 2 && Power >= 1500) || (Var(10) = 3 && Power >= 3000) || (Var(10) = 4 && ((100*Life)/(Const(data.life))<=30)) || Var(19) || Var(17) || Var(30)
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 225 && (Var(30) || AnimElemTime(5) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger9 = StateNo = 400
trigger10 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger12 = StateNo = 450 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger13 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger14 = (StateNo = [1000,1499]) && Var(50) && (((var(5)&16)>0) || Var(30))
trigger15 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Power Charge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 900
triggerall = RoundState = 2
triggerall = (Power < 1000 && Var(10) = 4) || (Var(10) = 0 && Power < 3000)
triggerall = !Var(17) && !Var(29)
triggerall = numHelper(10371)
triggerall = helper(10371), var(38) = [1,2]
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time < 2
trigger3 = StateNo = 205 && Time < 2
trigger4 = StateNo = 210 && Time < 2
trigger5 = StateNo = 215 && Time < 2
trigger6 = StateNo = 220 && Time < 2
trigger7 = StateNo = 225 && Time < 2
trigger8 = StateNo = 230 && Time < 2
trigger9 = StateNo = 235 && Time < 2
trigger10 = StateNo = 240 && Time < 2
trigger11 = StateNo = 245 && Time < 2
trigger12 = StateNo = 250 && Time < 2
trigger13 = StateNo = 255 && Time < 2
trigger14 = StateNo = 400 && Time < 2
trigger15 = StateNo = 410 && Time < 2
trigger16 = StateNo = 420 && Time < 2
trigger17 = StateNo = 430 && Time < 2
trigger18 = StateNo = 440 && Time < 2
trigger19 = StateNo = 450 && Time < 2



[State -1, MAX Activation]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 960
triggerall = Var(10) = 5
triggerall = Power >= 1000
triggerall = numHelper(10371)
triggerall = helper(10371), var(38) = [1,2]
triggerall = !Var(29) && !Var(30)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time < 2
trigger3 = StateNo = 205 && Time < 2
trigger4 = StateNo = 210 && Time < 2
trigger5 = StateNo = 215 && Time < 2
trigger6 = StateNo = 220 && Time < 2
trigger7 = StateNo = 225 && Time < 2
trigger8 = StateNo = 230 && Time < 2
trigger9 = StateNo = 235 && Time < 2
trigger10 = StateNo = 240 && Time < 2
trigger11 = StateNo = 245 && Time < 2
trigger12 = StateNo = 250 && Time < 2
trigger13 = StateNo = 255 && Time < 2
trigger14 = StateNo = 400 && Time < 2
trigger15 = StateNo = 410 && Time < 2
trigger16 = StateNo = 420 && Time < 2
trigger17 = StateNo = 430 && Time < 2
trigger18 = StateNo = 440 && Time < 2
trigger19 = StateNo = 450 && Time < 2



[State -1, Standing Custom Combo]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 970
triggerall = Var(10) = 2
triggerall = Power >= 3000
triggerall = numHelper(10371)
triggerall = helper(10371), var(38) = [1,2]
triggerall = !Var(29) && !Var(30)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time < 2
trigger3 = StateNo = 205 && Time < 2
trigger4 = StateNo = 210 && Time < 2
trigger5 = StateNo = 215 && Time < 2
trigger6 = StateNo = 220 && Time < 2
trigger7 = StateNo = 225 && Time < 2
trigger8 = StateNo = 230 && Time < 2
trigger9 = StateNo = 235 && Time < 2
trigger10 = StateNo = 240 && Time < 2
trigger11 = StateNo = 245 && Time < 2
trigger12 = StateNo = 250 && Time < 2
trigger13 = StateNo = 255 && Time < 2
trigger14 = StateNo = 400 && Time < 2
trigger15 = StateNo = 410 && Time < 2
trigger16 = StateNo = 420 && Time < 2
trigger17 = StateNo = 430 && Time < 2
trigger18 = StateNo = 440 && Time < 2
trigger19 = StateNo = 450 && Time < 2



[State -1, Counter Attack]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 2800
triggerall = roundstate = 2
triggerall = StateNo = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = numHelper(10371)
triggerall = helper(10371), var(37) = [1,2]
triggerall = command != "holddown" && command = "holdfwd"
triggerall = (var(5)&32)>0
trigger1 = Power >= 1000 && (Var(10) || Var(10) = 5)
trigger2 = Power >= 1500 && Var(10) = 2
trigger3 = Power >= 3000 && (Var(10) = 3 || Var(10) = 4)
trigger4 = Var(19)



[State -1, Aerial Custom Combo]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 975

triggerall = Var(10) = 2
triggerall = Power >= 3000
triggerall = numHelper(10371)
triggerall = helper(10371), var(38) = [1,2]
triggerall = !Var(29) && !Var(30)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && Time < 2
trigger3 = StateNo = 610 && Time < 2
trigger4 = StateNo = 620 && Time < 2
trigger5 = StateNo = 630 && time < 2
trigger6 = StateNo = 640 && Time < 2
trigger7 = StateNo = 650 && time < 2



[State -1, Run Fwd]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = ifElse(((Var(5)&2)>0),100,102)

triggerall = roundstate = 2
trigger1 = numHelper(10371)
trigger1 = helper(10371), Var(55) = [1,3]
trigger1 = statetype = S
trigger1 = ctrl



[State -1, Run Back]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 105

triggerall = roundstate = 2
trigger1 = numHelper(10371)
trigger1 = helper(10371), Var(56) = [1,3]
trigger1 = statetype = S
trigger1 = ctrl



[State -1, Safe Fall]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 5201

triggerall = !Var(15)
triggerall = (var(5)&128)>0
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Pos Y + Vel Y >= 0
trigger1 = numHelper(10371)
trigger1 = helper(10371), var(36) = [1,2]
persistent = 0




[State -1, Taunt]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 195

triggerall = numHelper(10371)
triggerall = helper(10371), var(6) = [1,2]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Counter Movement (forward)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 320

triggerall = roundstate = 2
triggerall = (var(5)&64)>0
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 5) && Power >= 1000) || (Var(10) = 2 && Power >= 1500) || (Var(10) = 3 && Power >= 3000) || Var(19) || Var(17)
triggerall = numHelper(10371)
triggerall = helper(10371), var(36) = [1,2]
triggerall = command != "holddown" && command = "holdfwd"
trigger1 = StateNo = 150
trigger2 = StateNo = 151
trigger3 = StateNo = 152
trigger4 = StateNo = 153
ignorehitpause = 0



[State -1, Counter Movement (back)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 330

triggerall = roundstate = 2
triggerall = (var(5)&64)>0
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 5) && Power >= 1000) || (Var(10) = 2 && Power >= 1500) || (Var(10) = 3 && Power >= 3000) || Var(19) || Var(17)
triggerall = numHelper(10371)
triggerall = helper(10371), var(36) = [1,2]
triggerall = command != "holddown" && command = "holdback"
trigger1 = StateNo = 150
trigger2 = StateNo = 151
trigger3 = StateNo = 152
trigger4 = StateNo = 153
ignorehitpause = 0



[State -1, Roll/Dodge]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = IfElse((Var(9)=1 && Var(10) > 0) || (Var(10) = 0 && command = "holdfwd"),300,310)

triggerall = Var(9) != 3
triggerall = numHelper(10371)
triggerall = helper(10371), var(36) = [1,2]
triggerall = StateType != A
triggerall = StateNo < 195 || PrevStateNo != 310
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time <= 2 && PrevStateNo != [200,450]
trigger3 = StateNo = 205 && Time <= 2 && PrevStateNo != [200,450]
trigger4 = StateNo = 210 && Time <= 2 && PrevStateNo != [200,450]
trigger5 = StateNo = 215 && Time <= 2 && PrevStateNo != [200,450]
trigger6 = StateNo = 220 && Time <= 2 && PrevStateNo != [200,450]
trigger7 = StateNo = 225 && Time <= 2 && PrevStateNo != [200,450]
trigger8 = StateNo = 230 && Time <= 2 && PrevStateNo != [200,450]
trigger9 = StateNo = 235 && Time <= 2 && PrevStateNo != [200,450]
trigger10 = StateNo = 240 && Time <= 2 && PrevStateNo != [200,450]
trigger11 = StateNo = 245 && Time <= 2 && PrevStateNo != [200,450]
trigger12 = StateNo = 250 && Time <= 2 && PrevStateNo != [200,450]
trigger13 = StateNo = 255 && Time <= 2 && PrevStateNo != [200,450]
trigger14 = StateNo = 260 && Time <= 2 && PrevStateNo != [200,450]
trigger15 = StateNo = 270 && Time <= 2 && PrevStateNo != [200,450]
trigger16 = StateNo = 280 && Time <= 2 && PrevStateNo != [200,450]
trigger17 = StateNo = 400 && Time <= 2 && PrevStateNo != [200,450]
trigger18 = (StateNo = 410 || StateNo = 415) && Time <= 2 && PrevStateNo != [200,450]
trigger19 = StateNo = 420 && Time <= 2 && PrevStateNo != [200,450]
trigger20 = StateNo = 430 && Time <= 2 && PrevStateNo != [200,450]
trigger21 = StateNo = 440 && Time <= 2 && PrevStateNo != [200,450]
trigger22 = StateNo = 450 && Time <= 2 && PrevStateNo != [200,450]
trigger23 = ((StateNo = [195,299]) || (StateNo = [400,450])) && (Var(50) = [1,2]) && Var(30)
trigger24 = (StateNo = [1000,1999]) && Var(30) && Var(50)
ignorehitpause = 0



[State -1, Quick Move]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1400


triggerall = numHelper(10371)
triggerall = helper(10371), Var(33) || helper(10371), Var(34) || helper(10371), Var(35)
triggerall = command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Wild Circular]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1300


triggerall = numHelper(10371)
triggerall = helper(10371), Var(24)
triggerall = (helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2]) || (!Var(30) && ((helper(10371), Var(10) = [1,2]) || (helper(10371), Var(11) = [1,2]) || (helper(10371), Var(12) = [1,2])))

triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Climb Razor]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1200


triggerall = numHelper(10371)
triggerall = helper(10371), Var(26)
triggerall =(helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2]) || (!Var(30) && ((helper(10371), Var(10) = [1,2]) || (helper(10371), Var(11) = [1,2]) || (helper(10371), Var(12) = [1,2])))
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Beast Cannon (diagonal)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1005

triggerall = numHelper(10371)
triggerall = helper(10371), Var(22)
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Million Flicker]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1100


triggerall = numHelper(10371)
triggerall = helper(10371), Var(23)
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Beast Cannon (air)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1005

triggerall = numHelper(10371)
triggerall = helper(10371), Var(21)
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = StateNo = 600 && ((Var(50)=[1,2]) && AnimElemTime(3) < 0)
trigger3 = StateNo = 610 && ((Var(50)=[1,2]) && AnimElemTime(5) < 0)
trigger4 = StateNo = 630 && ((Var(50)=[1,2]) && AnimElemTime(4) < 0)
trigger5 = StateNo = 640 && ((Var(50)=[1,2]) && AnimElemTime(3) < 0)
trigger6 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
trigger7 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger8 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Beast Cannon]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 1000


triggerall = numHelper(10371)
triggerall = helper(10371), Var(21)
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0



[State -1, Throw 2]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 830

triggerall = numHelper(10371)
triggerall = (helper(10371), command = "holdback") || (helper(10371), command = "holdfwd")
triggerall = helper(10371), var(5) = [1,2]
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [-22,22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || Var(30)
ignorehitpause = 0



[State -1, Throw 1]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 800

triggerall = numHelper(10371)
triggerall = (helper(10371), command = "holdback") || (helper(10371), command = "holdfwd")
triggerall = helper(10371), var(2) = [1,2]
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [-22,22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || Var(30)
ignorehitpause = 0



[State -1, Air Throw]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 860

triggerall = roundstate = 2
triggerall = numHelper(10371)
triggerall = (helper(10371), command = "holdback") || (helper(10371), command = "holdfwd") || (helper(10371), command = "holddown")
triggerall = helper(10371), var(2) = [1,2]
triggerall = statetype = A
triggerall = ctrl
triggerall = P2BodyDist X <= 39-Const(Size.Ground.Front)
trigger1 = p2statetype = A
trigger1 = p2movetype != H || Var(30)
ignorehitpause = 0



[State -1, Dodge Attack (K)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 240
triggerall = roundstate = 2
triggerall = numHelper(10371)
triggerall = (helper(10371), var(3) = [1,2]) || (helper(10371), var(4) = [1,2]) || (helper(10371), var(5) = [1,2])
trigger1 = StateNo = 310 && Time = [14,24]



[State -1, Dodge Attack (P)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 215
triggerall = roundstate = 2
triggerall = numHelper(10371)
triggerall = (helper(10371), var(0) = [1,2]) || (helper(10371), var(1) = [1,2]) || (helper(10371), var(2) = [1,2])
trigger1 = StateNo = 310 && Time = [14,24]



[State -1, Sadness Wind]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 260

triggerall = numHelper(10371)
triggerall = helper(10371), var(4) = [1,2]
triggerall = command = "holdfwd"
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 230 && (Var(50) = [1,2])
trigger10 = StateNo = 235 && (Var(50) = [1,2])
trigger11 = StateNo = 400 && (Var(50) = [1,2])
trigger12 = StateNo = 410 && (Var(50) = [1,2])
trigger13 = StateNo = 430 && (Var(50) = [1,2])
trigger14 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger15 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Standing Strong Kick (close)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 255

triggerall = numHelper(10371)
triggerall = helper(10371), var(5) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = P2BodyDist X = [-9,9]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 220 && (Var(50) = [1,2])
trigger10 = StateNo = 225 && (Var(50) = [1,2])
trigger11 = StateNo = 230 && (Var(50) = [1,2])
trigger12 = StateNo = 235 && (Var(50) = [1,2])
trigger13 = StateNo = 400 && (Var(50) = [1,2])
trigger14 = StateNo = 410 && (Var(50) = [1,2])
trigger15 = StateNo = 420 && (Var(50) = [1,2])
trigger16 = StateNo = 430 && (Var(50) = [1,2])
trigger17 = StateNo = 440 && (Var(50) = [1,2])
trigger18 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger19 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Standing Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 250

triggerall = numHelper(10371)
triggerall = helper(10371), var(5) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 220 && (Var(50) = [1,2])
trigger10 = StateNo = 225 && (Var(50) = [1,2])
trigger11 = StateNo = 230 && (Var(50) = [1,2])
trigger12 = StateNo = 235 && (Var(50) = [1,2])
trigger13 = StateNo = 240 && (Var(50) = [1,2])
trigger14 = StateNo = 400 && (Var(50) = [1,2])
trigger15 = StateNo = 410 && (Var(50) = [1,2])
trigger16 = StateNo = 420 && (Var(50) = [1,2])
trigger17 = StateNo = 430 && (Var(50) = [1,2])
trigger18 = StateNo = 440 && (Var(50) = [1,2])
trigger19 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger20 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Stand Strong Punch (close)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 225

triggerall = numHelper(10371)
triggerall = helper(10371), var(2) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = P2BodyDist X = [-9,9]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 210 && (Var(50) = [1,2]) && PrevStateNo != 310
trigger4 = StateNo = 215 && (Var(50) = [1,2])
trigger5 = StateNo = 230 && (Var(50) = [1,2])
trigger6 = StateNo = 235 && (Var(50) = [1,2])
trigger7 = StateNo = 240 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = StateNo = 410 && (Var(50) = [1,2])
trigger10 = StateNo = 430 && (Var(50) = [1,2])
trigger11 = StateNo = 440 && (Var(50) = [1,2])
trigger12 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger13 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Stand Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 220

triggerall = numHelper(10371)
triggerall = helper(10371), var(2) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 210 && (Var(50) = [1,2]) && PrevStateNo != 310
trigger4 = StateNo = 215 && (Var(50) = [1,2])
trigger5 = StateNo = 230 && (Var(50) = [1,2])
trigger6 = StateNo = 235 && (Var(50) = [1,2])
trigger7 = StateNo = 240 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = StateNo = 410 && (Var(50) = [1,2])
trigger10 = StateNo = 430 && (Var(50) = [1,2])
trigger11 = StateNo = 440 && (Var(50) = [1,2])
trigger12 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger13 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Standing Medium Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 240

triggerall = numHelper(10371)
triggerall = helper(10371), var(4) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 230 && (Var(50) = [1,2])
trigger10 = StateNo = 235 && (Var(50) = [1,2])
trigger11 = StateNo = 400 && (Var(50) = [1,2])
trigger12 = StateNo = 410 && (Var(50) = [1,2])
trigger13 = StateNo = 430 && (Var(50) = [1,2])
trigger14 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger15 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Stand Medium Punch (close)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 215

triggerall = numHelper(10371)
triggerall = helper(10371), var(1) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = P2BodyDist X = [-9,9]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 230 && (Var(50) = [1,2])
trigger4 = StateNo = 235 && (Var(50) = [1,2])
trigger5 = StateNo = 400 && (Var(50) = [1,2])
trigger6 = StateNo = 430 && (Var(50) = [1,2])
trigger8 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger9 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Stand Medium Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 210

triggerall = numHelper(10371)
triggerall = helper(10371), var(1) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 230 && (Var(50) = [1,2])
trigger4 = StateNo = 235 && (Var(50) = [1,2])
trigger5 = StateNo = 400 && (Var(50) = [1,2])
trigger6 = StateNo = 430 && (Var(50) = [1,2])
trigger8 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger9 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Stand Light Kick (close)]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 235

triggerall = numHelper(10371)
triggerall = helper(10371), var(3) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = P2BodyDist X = [-9,9]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 205 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger10 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Stand Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 230

triggerall = numHelper(10371)
triggerall = helper(10371), var(3) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 205 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger10 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Stand Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 200

triggerall = numHelper(10371)
triggerall = helper(10371), var(0) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger7 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Crouching Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 450

triggerall = numHelper(10371)
triggerall = helper(10371), var(5) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 220 && (Var(50) = [1,2])
trigger10 = StateNo = 225 && (Var(50) = [1,2])
trigger11 = StateNo = 230 && (Var(50) = [1,2])
trigger12 = StateNo = 235 && (Var(50) = [1,2])
trigger13 = StateNo = 240 && (Var(50) = [1,2])
trigger14 = StateNo = 400 && (Var(50) = [1,2])
trigger15 = StateNo = 410 && (Var(50) = [1,2])
trigger16 = StateNo = 420 && (Var(50) = [1,2])
trigger17 = StateNo = 430 && (Var(50) = [1,2])
trigger18 = StateNo = 440 && (Var(50) = [1,2])
trigger19 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger20 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Crouching Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 420

triggerall = numHelper(10371)
triggerall = helper(10371), var(2) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 210 && (Var(50) = [1,2]) && PrevStateNo != 310
trigger4 = StateNo = 215 && (Var(50) = [1,2])
trigger5 = StateNo = 230 && (Var(50) = [1,2])
trigger6 = StateNo = 235 && (Var(50) = [1,2])
trigger7 = StateNo = 240 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = StateNo = 410 && (Var(50) = [1,2])
trigger10 = StateNo = 430 && (Var(50) = [1,2])
trigger11 = StateNo = 440 && (Var(50) = [1,2])
trigger12 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger13 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Crouching Medium Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 440

triggerall = numHelper(10371)
triggerall = helper(10371), var(4) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 230 && (Var(50) = [1,2])
trigger10 = StateNo = 235 && (Var(50) = [1,2])
trigger11 = StateNo = 400 && (Var(50) = [1,2])
trigger12 = StateNo = 410 && (Var(50) = [1,2])
trigger13 = StateNo = 430 && (Var(50) = [1,2])
trigger14 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger15 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Crouching Medium Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 410

triggerall = numHelper(10371)
triggerall = helper(10371), var(1) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 230 && (Var(50) = [1,2])
trigger4 = StateNo = 235 && (Var(50) = [1,2])
trigger5 = StateNo = 400 && (Var(50) = [1,2])
trigger6 = StateNo = 430 && (Var(50) = [1,2])
trigger8 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger9 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Crouching Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 430

triggerall = numHelper(10371)
triggerall = helper(10371), var(3) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 2
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 400 && (Var(50) = [1,2])
trigger8 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger9 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Crouching Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 400

triggerall = numHelper(10371)
triggerall = helper(10371), var(0) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger7 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0



[State -1, Jump Strong Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 650

triggerall = numHelper(10371)
triggerall = helper(10371), var(5) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0



[State -1, Jump Strong Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 620

triggerall = numHelper(10371)
triggerall = helper(10371), var(2) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0



[State -1, Jump Medium Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 640

triggerall = numHelper(10371)
triggerall = helper(10371), var(4) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0



[State -1, Jump Medium Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 610

triggerall = numHelper(10371)
triggerall = helper(10371), var(1) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0



[State -1, Jump Light Kick]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 630

triggerall = numHelper(10371)
triggerall = helper(10371), var(3) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0



[State -1, Jump Light Punch]
type = ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value = 600

triggerall = numHelper(10371)
triggerall = helper(10371), var(0) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0
