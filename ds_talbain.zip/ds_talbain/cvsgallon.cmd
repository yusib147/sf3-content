;#ADD004BASIC PIEs#
; The CMD file. Don't fuck with any of this.
;
; REQUIRED.
; Default value for the "buffer.time" parameter of a Command. Minimum 1,
; maximum 30.
[Defaults]
command.time = 15
command.buffer.time = 1
;-| Super Motions |--------------------------------------------------------
[Command]
name = "Moment Slice"
command = ~x, y, F, a, b
time = 35
[Command]
name = "Moment Slice"
command = ~x, y, F, a, ~b
time = 35

[Command]
name = "Moment Slice 2"
command = ~x, y, B, a, b
time = 35
[Command]
name = "Moment Slice 2"
command = ~x, y, B, a, ~b
time = 35

[Command]
name = "HCFx2"
command = ~B,D,F,B,D,F
time = 30

[Command]
name = "HCBx2"
command = ~F,D,B,F,D,B
time = 30

[Command]
name = "QCFx2"
command = ~D,DF,F,D,DF
time = 21
[Command]
name = "QCBx2"
command = ~D,DB,B,D,DB
time = 21

;-| Special Motions |------------------------------------------------------
[Command]
name = "DU"
command = ~$D,$U
time = 12

[Command]
name = "DP"
command = ~F,D,DF
time = 12

[Command]
name = "rDP"
command = ~B,D,DB
time = 12

[Command]
name = "QCF"
command = ~D,DF,F
time = 12

[Command]
name = "QCB"
command = ~D,DB,B
time = 12

[Command]
name = "HCF"
command = ~B,DB,D,DF,F
time = 18

[Command]
name = "HCB"
command = ~F,DF,D,DB,B
time = 18

[Command]
name = "mash_x"
command = x,x,x

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "longjump"
command = D,$U
time = 10

[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery" ;Required (do not remove)
command = x+a
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

[Command]
name = "back"
command = B
time = 1

[Command]
name = "upback"
command = UB
time = 1

[Command]
name = "downback"
command = DB
time = 1

[Command]
name = "parry" ; REQUIRED for command buffering
command = F
time = 1

[Command]
name = "parry2" ; REQUIRED for command buffering
command = D
time = 1

[Command]
name = "rich"  ; REQUIRED for command buffering
command = U
time = 1

[Command]
name = "up"
command = U
time = 3

[Command]
name = "down"
command = D
time = 3

[Command]
name = "down2" ; REQUIRED for command buffering
command = $D
time = 1

;-| Hold Button |--------------------------------------------------------------
[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_start"
command = /s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd" ;Required (do not remove)
command = /$F
time = 1
[Command]
name = "holddown" ;Required (do not remove)
command = /$D
time = 1
[Command]
name = "holdback" ;Required (do not remove)
command = /$B
time = 1
[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holdfwd_r" ; Raw hold forward (REQUIRED for command buffering)
command = /F
time = 1
[Command]
name = "holddown_r" ; Raw hold forward (REQUIRED for command buffering)
command = /D
time = 1
[Command]
name = "holdback_r" ; Raw hold forward (REQUIRED for command buffering)
command = /B
time = 1
[Command]
name = "holdup_r" ; Raw hold forward (REQUIRED for command buffering)
command = /U
time = 1

;-| Release Dir |-----------------------------------------------------------
[Command]
name = "release_fwd"
command = ~F
time = 1

[Command]
name = "release_down"
command = ~D
time = 1

[Command]
name = "release_back"
command = ~B
time = 1

[Command]
name = "release_up"
command = ~U
time = 1

;-| Release Button |---------------------------------------------------------
[Command]
name = "release_a"
command = ~a
time = 1

[Command]
name = "release_b"
command = ~b
time = 1

[Command]
name = "release_c"
command = ~c
time = 1

[Command]
name = "release_x"
command = ~x
time = 1

[Command]
name = "release_y"
command = ~y
time = 1

[Command]
name = "release_z"
command = ~z
time = 1

[Command]
name = "release_start"
command = ~s
time = 1

;---------------------------------------------------------------------------
[Statedef -1]

;//==========================
;// add004-1-sctrls-start
;//==========================
;--- partner_standby
[state 0]
	type=selfstate
	trigger1=ctrl && numpartner && !ishelper && roundstate=2 && pos y=0
	trigger1=sysfvar(4)>0 && sysfvar(0)>0 && playeridexist(floor(sysfvar(0)))
	trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(22)=4
	value=190190
	ctrl=0
	ignorehitpause=1
;//==========================
;// add004-1-sctrls-end
;//==========================



[State -1, Buffered Walk]
type = AssertSpecial
trigger1 = NumHelper(10371)
flag = NoWalk
[State -1, Buffered Walk]
type = ChangeState
;triggerall = !AILevel
triggerall = NumHelper(10371)
triggerall = command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
triggerall = !isHelper
triggerall = (StateNo != [11,12]) && StateNo != 20 && StateNo != 40 && !(StateNo = 52 && Time < 5)
triggerall = Ctrl && (StateNo != [120,132]) && (StateNo != [150,155]) && (StateNo != [700,720])
trigger1 = (helper(10371), Var(16) = [1,9])
trigger1 = !(helper(10371), Var(18) > helper(10371), Var(16))
trigger2 = (helper(10371), Var(17) = [1,9])
trigger2 = !(helper(10371), Var(19) > helper(10371), Var(17))
trigger3 = (helper(10371), Var(16) = -1) || (helper(10371), Var(17) = -1)
value = 20
[State -1, M.I.X. THE CRACK]
type = ChangeState
triggerall = NumHelper(10371)
triggerall = !(helper(10371), Var(14) = [1,2]) ; Buffered jump
triggerall = !((helper(10371), Var(15) = [1,9]) || (helper(10371), Var(15) = -1)) ; Buffered crouch
;triggerall = !AILevel
triggerall = statetype != A
triggerall = roundstate = 2
triggerall = !isHelper
triggerall = StateNo != 0 && (StateNo != [11,12]) && StateNo != 20 && StateNo != 52
trigger1 = Ctrl && (StateNo != [120,132]) && (StateNo != [150,155]) && (StateNo != [700,720])
value = ifElse(((helper(10371), Var(16)) || (helper(10371), Var(17))), 20, 0)
[State -1, M.I.X. THE CRACK]
type = ChangeState
triggerall = NumHelper(10371)
triggerall = helper(10371), Var(14) = [1,2] ; Buffered jump
;triggerall = !AILevel
triggerall = statetype != A
triggerall = roundstate = 2
triggerall = !isHelper
triggerall = StateNo != 0 && (StateNo != [11,12]) && StateNo != 20 && StateNo != 40 ;&& StateNo != 52
trigger1 = Ctrl && (StateNo != [120,132]) && (StateNo != [150,155]) && (StateNo != [700,720])
value = 40

; Parrying/Just Defend Voice
[State -2, PlaySnd]
type = Playsnd
triggerall = Time = 0
trigger1 = StateNo = 700
trigger2 = StateNo = 710
trigger3 = StateNo = 720
trigger4 = StateNo = 150 && Var(14) = 1
trigger5 = StateNo = 152 && Var(14) = 1
trigger6 = StateNo = 154 && Var(14) = 1
value = S8,0
channel = 0

[State 710, Explod]; Parry spark
type = Explod
triggerall = Time = 0
trigger1 = StateNo = 700
trigger2 = StateNo = 710
trigger3 = StateNo = 720
anim = 7500
;pos = ifElse(StateNo=720,49,ifElse(StateNo=710,56,49)),ifElse(StateNo=720,-21,ifElse(StateNo=710,-49,-77)) ;basic code
pos = ifElse(StateNo=720,14,ifElse(StateNo=710,35,49)),ifElse(StateNo=720,-84,ifElse(StateNo=710,-28,-77))
sprpriority = 3
ownpal = 1
scale = .5,.5
pausemovetime = 15
[State 500, Explod]; Just Defend spark
type = Explod
triggerall = Time = 0
triggerall = Var(14) = 1
trigger1 = StateNo = 150
trigger2 = StateNo = 152
trigger3 = StateNo = 154
anim = 7000
;pos = ifElse(StateNo=154,0,ifElse(StateNo=152,21,0)),ifElse(StateNo=154,-63,ifElse(StateNo=152,-35,-56)) ;basic code
pos = ifElse(StateNo=152,21,0),ifElse(StateNo=154,-63,ifElse(StateNo=152,-35,-56))
sprpriority = 3
ownpal = 1
scale = .5,.5
pausemovetime = 4

;==========================================================================;
;                              HUMAN COMMANDS                              ;
;==========================================================================;
;---------------------------------------------------------------------------
; Conflict Check
[State -1, P]
type = VarSet
;triggerall = !AILevel
trigger1 = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2])
trigger2 = !Var(30)
trigger2 = (helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])
var(46) = 1
ignorehitpause = 1
[State -1, K]
type = VarSet
;triggerall = !AILevel
trigger1 = (helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2])
trigger2 = !Var(30)
trigger2 = (helper(10371), Var(10) = [1,2]) || (helper(10371), Var(11) = [1,2]) || (helper(10371), Var(12) = [1,2])
var(46) = 0
ignorehitpause = 1
[State -1, P beats ~K]
type = VarSet
;triggerall = !AILevel
triggerall = !Var(30)
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2])
trigger1 = (helper(10371), Var(0) >= helper(10371), Var(10)) || (helper(10371), Var(0) >= helper(10371), Var(11))
trigger2 = (helper(10371), Var(0) >= helper(10371), Var(12)) || (helper(10371), Var(1) >= helper(10371), Var(10))
trigger3 = (helper(10371), Var(1) >= helper(10371), Var(11)) || (helper(10371), Var(1) >= helper(10371), Var(12))
trigger4 = (helper(10371), Var(2) >= helper(10371), Var(10)) || (helper(10371), Var(2) >= helper(10371), Var(11))
trigger5 = (helper(10371), Var(2) >= helper(10371), Var(12))
var(46) = 1
ignorehitpause = 1
[State -1, K beats ~P]
type = VarSet
;triggerall = !AILevel
triggerall = !Var(30)
triggerall = (helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2])
trigger1 = (helper(10371), Var(3) >= helper(10371), Var(7)) || (helper(10371), Var(3) >= helper(10371), Var(9))
trigger2 = (helper(10371), Var(3) >= helper(10371), Var(9)) || (helper(10371), Var(4) >= helper(10371), Var(7))
trigger3 = (helper(10371), Var(4) >= helper(10371), Var(8)) || (helper(10371), Var(4) >= helper(10371), Var(9))
trigger4 = (helper(10371), Var(5) >= helper(10371), Var(7)) || (helper(10371), Var(5) >= helper(10371), Var(8))
trigger5 = (helper(10371), Var(5) >= helper(10371), Var(9))
var(46) = 0
ignorehitpause = 1

;---------------------------------------------------------------------------
; Moment Slice
[State -1, Moment Slice]
type = ChangeState
value = 3200
triggerall = numHelper(10371)
triggerall = helper(10371), Var(42) 
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 3) && Power >= 3000) || (Var(10) = 4 && (100*life/const(data.life))<=30 && Var(17)) || (Var(29) && Power >= 1000) || Var(19)
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && AnimElemTime(4) < 0
trigger4 = StateNo = 215 && AnimElemTime(3) < 0
trigger5 = StateNo = 225 && (Var(30) || AnimElemTime(5) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 230 && AnimElemTime(3) < 0
trigger7 = StateNo = 235 && AnimElemTime(3) < 0
trigger8 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger9 = StateNo = 400
trigger10 = StateNo = 410 && AnimElemTime(4) < 0
trigger11 = StateNo = 430 && AnimElemTime(3) < 0
trigger12 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger13 = StateNo = 450 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger14 = (StateNo = [1000,1499]) && Var(50) && (((var(5)&16)>0) || Var(30))
ignorehitpause = 0

;---------------------------------------------------------------------------
; Dragon Cannon
[State -1, Dragon Cannon]
type = ChangeState
value = 3100
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(41) 
triggerall = (helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2]) || (!Var(30) && ((helper(10371), Var(10) = [1,2]) || (helper(10371), Var(11) = [1,2]) || (helper(10371), Var(12) = [1,2])))
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 5) && Power >= 1000) || (Var(10) = 2 && Power >= 1500) || (Var(10) = 3 && Power >= 3000) || (Var(10) = 4 && ((100*Life)/(Const(data.life))<=30)) || Var(19) || Var(17) || Var(30)
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 225 && (Var(30) || AnimElemTime(5) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger9 = StateNo = 400
trigger10 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger12 = StateNo = 450 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger13 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger14 = (StateNo = [1000,1499]) && Var(50) && (((var(5)&16)>0) || Var(30))
trigger15 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Dragon Cannon/Hyper Beast Cannon
[State -1, Dragon Cannon/Hyper Beast Cannon]
type = ChangeState
value = ifElse(!Var(46) && (helper(10371), Var(41)), 3100, 3000)
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(40) 
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 5) && Power >= 1000) || (Var(10) = 2 && Power >= 1500) || (Var(10) = 3 && Power >= 3000) || (Var(10) = 4 && ((100*Life)/(Const(data.life))<=30)) || Var(19) || Var(17) || Var(30)
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 225 && (Var(30) || AnimElemTime(5) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger9 = StateNo = 400
trigger10 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger12 = StateNo = 450 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger13 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger14 = (StateNo = [1000,1499]) && Var(50) && (((var(5)&16)>0) || Var(30))
trigger15 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Power Charge
[State -1, Power Charge]
type = ChangeState
value = 900
triggerall = RoundState = 2
triggerall = (Power < 1000 && Var(10) = 4) || (Var(10) = 0 && Power < 3000)
triggerall = !Var(17) && !Var(29)
triggerall = numHelper(10371)
triggerall = helper(10371), var(38) = [1,2]
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time < 2
trigger3 = StateNo = 205 && Time < 2
trigger4 = StateNo = 210 && Time < 2
trigger5 = StateNo = 215 && Time < 2
trigger6 = StateNo = 220 && Time < 2
trigger7 = StateNo = 225 && Time < 2
trigger8 = StateNo = 230 && Time < 2
trigger9 = StateNo = 235 && Time < 2
trigger10 = StateNo = 240 && Time < 2
trigger11 = StateNo = 245 && Time < 2
trigger12 = StateNo = 250 && Time < 2
trigger13 = StateNo = 255 && Time < 2
trigger14 = StateNo = 400 && Time < 2
trigger15 = StateNo = 410 && Time < 2
trigger16 = StateNo = 420 && Time < 2
trigger17 = StateNo = 430 && Time < 2
trigger18 = StateNo = 440 && Time < 2
trigger19 = StateNo = 450 && Time < 2

;---------------------------------------------------------------------------
; MAX Activation
[State -1, MAX Activation]
type = ChangeState
value = 960
triggerall = Var(10) = 5
triggerall = Power >= 1000
triggerall = numHelper(10371)
triggerall = helper(10371), var(38) = [1,2]
triggerall = !Var(29) && !Var(30)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time < 2
trigger3 = StateNo = 205 && Time < 2
trigger4 = StateNo = 210 && Time < 2
trigger5 = StateNo = 215 && Time < 2
trigger6 = StateNo = 220 && Time < 2
trigger7 = StateNo = 225 && Time < 2
trigger8 = StateNo = 230 && Time < 2
trigger9 = StateNo = 235 && Time < 2
trigger10 = StateNo = 240 && Time < 2
trigger11 = StateNo = 245 && Time < 2
trigger12 = StateNo = 250 && Time < 2
trigger13 = StateNo = 255 && Time < 2
trigger14 = StateNo = 400 && Time < 2
trigger15 = StateNo = 410 && Time < 2
trigger16 = StateNo = 420 && Time < 2
trigger17 = StateNo = 430 && Time < 2
trigger18 = StateNo = 440 && Time < 2
trigger19 = StateNo = 450 && Time < 2

;---------------------------------------------------------------------------
; Stand Custom Combo
[State -1, Standing Custom Combo]
type = ChangeState
value = 970
triggerall = Var(10) = 2
triggerall = Power >= 3000
triggerall = numHelper(10371)
triggerall = helper(10371), var(38) = [1,2]
triggerall = !Var(29) && !Var(30)
triggerall = roundstate = 2
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time < 2
trigger3 = StateNo = 205 && Time < 2
trigger4 = StateNo = 210 && Time < 2
trigger5 = StateNo = 215 && Time < 2
trigger6 = StateNo = 220 && Time < 2
trigger7 = StateNo = 225 && Time < 2
trigger8 = StateNo = 230 && Time < 2
trigger9 = StateNo = 235 && Time < 2
trigger10 = StateNo = 240 && Time < 2
trigger11 = StateNo = 245 && Time < 2
trigger12 = StateNo = 250 && Time < 2
trigger13 = StateNo = 255 && Time < 2
trigger14 = StateNo = 400 && Time < 2
trigger15 = StateNo = 410 && Time < 2
trigger16 = StateNo = 420 && Time < 2
trigger17 = StateNo = 430 && Time < 2
trigger18 = StateNo = 440 && Time < 2
trigger19 = StateNo = 450 && Time < 2

;---------------------------------------------------------------------------
; Counter Attack
[State -1, Counter Attack]
type = ChangeState
value = 2800
triggerall = roundstate = 2
triggerall = StateNo = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = numHelper(10371)
triggerall = helper(10371), var(37) = [1,2]
triggerall = command != "holddown" && command = "holdfwd"
triggerall = (var(5)&32)>0
trigger1 = Power >= 1000 && (Var(10) || Var(10) = 5)
trigger2 = Power >= 1500 && Var(10) = 2
trigger3 = Power >= 3000 && (Var(10) = 3 || Var(10) = 4)
trigger4 = Var(19)

;---------------------------------------------------------------------------
; Aerial Custom Combo
[State -1, Aerial Custom Combo]
type = ChangeState
value = 975
;triggerall = !AILevel
triggerall = Var(10) = 2
triggerall = Power >= 3000
triggerall = numHelper(10371)
triggerall = helper(10371), var(38) = [1,2]
triggerall = !Var(29) && !Var(30)
triggerall = roundstate = 2
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600 && Time < 2
trigger3 = StateNo = 610 && Time < 2
trigger4 = StateNo = 620 && Time < 2
trigger5 = StateNo = 630 && time < 2
trigger6 = StateNo = 640 && Time < 2
trigger7 = StateNo = 650 && time < 2

;---------------------------------------------------------------------------
; Run Fwd
[State -1, Run Fwd]
type = ChangeState
value = ifElse(((Var(5)&2)>0),100,102)
;triggerall = !AILevel
triggerall = roundstate = 2
trigger1 = numHelper(10371)
trigger1 = helper(10371), Var(55) = [1,3]
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
; Run Back
[State -1, Run Back]
type = ChangeState
value = 105
;triggerall = !AILevel
triggerall = roundstate = 2
trigger1 = numHelper(10371)
trigger1 = helper(10371), Var(56) = [1,3]
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
; Safe Fall
[State -1, Safe Fall]
type = ChangeState
value = 5201
;triggerall = !AILevel
triggerall = !Var(15)
triggerall = (var(5)&128)>0
triggerall = Alive
triggerall = StateNo = 5050 || StateNo = 5071
triggerall = Pos Y + Vel Y >= 0
trigger1 = numHelper(10371)
trigger1 = helper(10371), var(36) = [1,2]
persistent = 0

;===========================================================================
;---------------------------------------------------------------------------
; Taunt
[State -1, Taunt]
type = ChangeState
value = 195
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(6) = [1,2]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Counter Movement (forward)
[State -1, Counter Movement (forward)]
type = ChangeState
value = 320
;triggerall = !AILevel
triggerall = roundstate = 2
triggerall = (var(5)&64)>0
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 5) && Power >= 1000) || (Var(10) = 2 && Power >= 1500) || (Var(10) = 3 && Power >= 3000) || Var(19) || Var(17)
triggerall = numHelper(10371)
triggerall = helper(10371), var(36) = [1,2]
triggerall = command != "holddown" && command = "holdfwd"
trigger1 = StateNo = 150
trigger2 = StateNo = 151
trigger3 = StateNo = 152
trigger4 = StateNo = 153
ignorehitpause = 0

;---------------------------------------------------------------------------
; Counter Movement (back)
[State -1, Counter Movement (back)]
type = ChangeState
value = 330
;triggerall = !AILevel
triggerall = roundstate = 2
triggerall = (var(5)&64)>0
triggerall = ((Var(10) = 0 || Var(10) = 1 || Var(10) = 5) && Power >= 1000) || (Var(10) = 2 && Power >= 1500) || (Var(10) = 3 && Power >= 3000) || Var(19) || Var(17)
triggerall = numHelper(10371)
triggerall = helper(10371), var(36) = [1,2]
triggerall = command != "holddown" && command = "holdback"
trigger1 = StateNo = 150
trigger2 = StateNo = 151
trigger3 = StateNo = 152
trigger4 = StateNo = 153
ignorehitpause = 0

;---------------------------------------------------------------------------
; Roll/Dodge
[State -1, Roll/Dodge]
type = ChangeState
value = IfElse((Var(9)=1 && Var(10) > 0) || (Var(10) = 0 && command = "holdfwd"),300,310)
;triggerall = !AILevel
triggerall = Var(9) != 3
triggerall = numHelper(10371)
triggerall = helper(10371), var(36) = [1,2]
triggerall = StateType != A
triggerall = StateNo < 195 || PrevStateNo != 310
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time <= 2 && PrevStateNo != [200,450]
trigger3 = StateNo = 205 && Time <= 2 && PrevStateNo != [200,450]
trigger4 = StateNo = 210 && Time <= 2 && PrevStateNo != [200,450]
trigger5 = StateNo = 215 && Time <= 2 && PrevStateNo != [200,450]
trigger6 = StateNo = 220 && Time <= 2 && PrevStateNo != [200,450]
trigger7 = StateNo = 225 && Time <= 2 && PrevStateNo != [200,450]
trigger8 = StateNo = 230 && Time <= 2 && PrevStateNo != [200,450]
trigger9 = StateNo = 235 && Time <= 2 && PrevStateNo != [200,450]
trigger10 = StateNo = 240 && Time <= 2 && PrevStateNo != [200,450]
trigger11 = StateNo = 245 && Time <= 2 && PrevStateNo != [200,450]
trigger12 = StateNo = 250 && Time <= 2 && PrevStateNo != [200,450]
trigger13 = StateNo = 255 && Time <= 2 && PrevStateNo != [200,450]
trigger14 = StateNo = 260 && Time <= 2 && PrevStateNo != [200,450]
trigger15 = StateNo = 270 && Time <= 2 && PrevStateNo != [200,450]
trigger16 = StateNo = 280 && Time <= 2 && PrevStateNo != [200,450]
trigger17 = StateNo = 400 && Time <= 2 && PrevStateNo != [200,450]
trigger18 = (StateNo = 410 || StateNo = 415) && Time <= 2 && PrevStateNo != [200,450]
trigger19 = StateNo = 420 && Time <= 2 && PrevStateNo != [200,450]
trigger20 = StateNo = 430 && Time <= 2 && PrevStateNo != [200,450]
trigger21 = StateNo = 440 && Time <= 2 && PrevStateNo != [200,450]
trigger22 = StateNo = 450 && Time <= 2 && PrevStateNo != [200,450]
trigger23 = ((StateNo = [195,299]) || (StateNo = [400,450])) && (Var(50) = [1,2]) && Var(30)
trigger24 = (StateNo = [1000,1999]) && Var(30) && Var(50)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Quick Move
[State -1, Quick Move]
type = ChangeState
value = 1400
;;triggerall = !AILevel
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), Var(33) || helper(10371), Var(34) || helper(10371), Var(35)
triggerall = command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Wild Circular
[State -1, Wild Circular]
type = ChangeState
value = 1300
;;triggerall = !AILevel
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), Var(24) 
triggerall = (helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2]) || (!Var(30) && ((helper(10371), Var(10) = [1,2]) || (helper(10371), Var(11) = [1,2]) || (helper(10371), Var(12) = [1,2])))
;triggerall = P2BodyDist X = [-16,16]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Climb Razor
[State -1, Climb Razor]
type = ChangeState
value = 1200
;;triggerall = !AILevel
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), Var(26) 
triggerall =(helper(10371), Var(3) = [1,2]) || (helper(10371), Var(4) = [1,2]) || (helper(10371), Var(5) = [1,2]) || (!Var(30) && ((helper(10371), Var(10) = [1,2]) || (helper(10371), Var(11) = [1,2]) || (helper(10371), Var(12) = [1,2])))
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Beast Cannon (diagonal)
[State -1, Beast Cannon (diagonal)]
type = ChangeState
value = 1005
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), Var(22) 
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Million Flicker
[State -1, Million Flicker]
type = ChangeState
value = 1100
;;triggerall = !AILevel
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), Var(23) 
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Beast Cannon (air)
[State -1, Beast Cannon (air)]
type = ChangeState
value = 1005
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), Var(21) 
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = StateNo = 600 && ((Var(50)=[1,2]) && AnimElemTime(3) < 0)
trigger3 = StateNo = 610 && ((Var(50)=[1,2]) && AnimElemTime(5) < 0)
trigger4 = StateNo = 630 && ((Var(50)=[1,2]) && AnimElemTime(4) < 0)
trigger5 = StateNo = 640 && ((Var(50)=[1,2]) && AnimElemTime(3) < 0)
trigger6 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
trigger7 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger8 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Beast Cannon
[State -1, Beast Cannon]
type = ChangeState
value = 1000
;;triggerall = !AILevel
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), Var(21) 
triggerall = (helper(10371), Var(0) = [1,2]) || (helper(10371), Var(1) = [1,2]) || (helper(10371), Var(2) = [1,2]) || (!Var(30) && ((helper(10371), Var(7) = [1,2]) || (helper(10371), Var(8) = [1,2]) || (helper(10371), Var(9) = [1,2])))
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101 || StateNo = 40 || (StateNo = 52 && Anim = 47 && Time >= 2)
trigger2 = StateNo = 200
trigger3 = StateNo = 210 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger4 = StateNo = 215 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger5 = StateNo = 230 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger6 = StateNo = 235 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger7 = StateNo = 240 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger8 = StateNo = 400
trigger9 = StateNo = 430 && (Var(30) || AnimElemTime(3) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger10 = StateNo = 440 && (Var(30) || AnimElemTime(4) < 0) && !(!Var(30) && (PrevStateNo = [200,255]) || (PrevStateNo = [400,450]))
trigger11 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger12 = (StateNo = [1000,1999]) && Var(30) && Var(50)
trigger13 = (StateNo = [3000,3199]) && Var(22) = 1 && (Var(50) = 1||Var(50) = 3)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Throw 2
[State -1, Throw 2]
type = ChangeState
value = 830
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = (helper(10371), command = "holdback") || (helper(10371), command = "holdfwd")
triggerall = helper(10371), var(5) = [1,2]
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [-22,22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Throw 1
[State -1, Throw 1]
type = ChangeState
value = 800
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = (helper(10371), command = "holdback") || (helper(10371), command = "holdfwd")
triggerall = helper(10371), var(2) = [1,2]
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = p2bodydist X = [-22,22]
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H || Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Air Throw
[State -1, Air Throw]
type = ChangeState
value = 860
;triggerall = !AILevel
triggerall = roundstate = 2
triggerall = numHelper(10371)
triggerall = (helper(10371), command = "holdback") || (helper(10371), command = "holdfwd") || (helper(10371), command = "holddown")
triggerall = helper(10371), var(2) = [1,2]
triggerall = statetype = A
triggerall = ctrl
triggerall = P2BodyDist X <= 39-Const(Size.Ground.Front)
trigger1 = p2statetype = A
trigger1 = p2movetype != H || Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Dodge Attack (K)
[State -1, Dodge Attack (K)]
type = ChangeState
value = 240
triggerall = roundstate = 2
triggerall = numHelper(10371)
triggerall = (helper(10371), var(3) = [1,2]) || (helper(10371), var(4) = [1,2]) || (helper(10371), var(5) = [1,2])
trigger1 = StateNo = 310 && Time = [14,24]

;---------------------------------------------------------------------------
; Dodge Attack (P)
[State -1, Dodge Attack (P)]
type = ChangeState
value = 215
triggerall = roundstate = 2
triggerall = numHelper(10371)
triggerall = (helper(10371), var(0) = [1,2]) || (helper(10371), var(1) = [1,2]) || (helper(10371), var(2) = [1,2])
trigger1 = StateNo = 310 && Time = [14,24]

;---------------------------------------------------------------------------
; Sadness Wind
[State -1, Sadness Wind]
type = ChangeState
value = 260
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(4) = [1,2]
triggerall = command = "holdfwd"
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 230 && (Var(50) = [1,2])
trigger10 = StateNo = 235 && (Var(50) = [1,2])
trigger11 = StateNo = 400 && (Var(50) = [1,2])
trigger12 = StateNo = 410 && (Var(50) = [1,2])
trigger13 = StateNo = 430 && (Var(50) = [1,2])
trigger14 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger15 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Standing Strong Kick (close)
[State -1, Standing Strong Kick (close)]
type = ChangeState
value = 255
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(5) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = P2BodyDist X = [-9,9]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 220 && (Var(50) = [1,2])
trigger10 = StateNo = 225 && (Var(50) = [1,2])
trigger11 = StateNo = 230 && (Var(50) = [1,2])
trigger12 = StateNo = 235 && (Var(50) = [1,2])
trigger13 = StateNo = 400 && (Var(50) = [1,2])
trigger14 = StateNo = 410 && (Var(50) = [1,2])
trigger15 = StateNo = 420 && (Var(50) = [1,2])
trigger16 = StateNo = 430 && (Var(50) = [1,2])
trigger17 = StateNo = 440 && (Var(50) = [1,2])
trigger18 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger19 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Standing Strong Kick
[State -1, Standing Strong Kick]
type = ChangeState
value = 250
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(5) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 220 && (Var(50) = [1,2])
trigger10 = StateNo = 225 && (Var(50) = [1,2])
trigger11 = StateNo = 230 && (Var(50) = [1,2])
trigger12 = StateNo = 235 && (Var(50) = [1,2])
trigger13 = StateNo = 240 && (Var(50) = [1,2])
trigger14 = StateNo = 400 && (Var(50) = [1,2])
trigger15 = StateNo = 410 && (Var(50) = [1,2])
trigger16 = StateNo = 420 && (Var(50) = [1,2])
trigger17 = StateNo = 430 && (Var(50) = [1,2])
trigger18 = StateNo = 440 && (Var(50) = [1,2])
trigger19 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger20 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Stand Strong Punch (close)
[State -1, Stand Strong Punch (close)]
type = ChangeState
value = 225
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(2) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = P2BodyDist X = [-9,9]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 210 && (Var(50) = [1,2]) && PrevStateNo != 310
trigger4 = StateNo = 215 && (Var(50) = [1,2])
trigger5 = StateNo = 230 && (Var(50) = [1,2])
trigger6 = StateNo = 235 && (Var(50) = [1,2])
trigger7 = StateNo = 240 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = StateNo = 410 && (Var(50) = [1,2])
trigger10 = StateNo = 430 && (Var(50) = [1,2])
trigger11 = StateNo = 440 && (Var(50) = [1,2])
trigger12 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger13 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Stand Strong Punch
[State -1, Stand Strong Punch]
type = ChangeState
value = 220
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(2) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 210 && (Var(50) = [1,2]) && PrevStateNo != 310
trigger4 = StateNo = 215 && (Var(50) = [1,2])
trigger5 = StateNo = 230 && (Var(50) = [1,2])
trigger6 = StateNo = 235 && (Var(50) = [1,2])
trigger7 = StateNo = 240 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = StateNo = 410 && (Var(50) = [1,2])
trigger10 = StateNo = 430 && (Var(50) = [1,2])
trigger11 = StateNo = 440 && (Var(50) = [1,2])
trigger12 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger13 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Standing Medium Kick
[State -1, Standing Medium Kick]
type = ChangeState
value = 240
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(4) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 230 && (Var(50) = [1,2])
trigger10 = StateNo = 235 && (Var(50) = [1,2])
trigger11 = StateNo = 400 && (Var(50) = [1,2])
trigger12 = StateNo = 410 && (Var(50) = [1,2])
trigger13 = StateNo = 430 && (Var(50) = [1,2])
trigger14 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger15 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Stand Medium Punch (close)
[State -1, Stand Medium Punch (close)]
type = ChangeState
value = 215
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(1) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = P2BodyDist X = [-9,9]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 230 && (Var(50) = [1,2])
trigger4 = StateNo = 235 && (Var(50) = [1,2])
trigger5 = StateNo = 400 && (Var(50) = [1,2])
trigger6 = StateNo = 430 && (Var(50) = [1,2])
trigger8 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger9 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Stand Medium Punch
[State -1, Stand Medium Punch]
type = ChangeState
value = 210
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(1) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 230 && (Var(50) = [1,2])
trigger4 = StateNo = 235 && (Var(50) = [1,2])
trigger5 = StateNo = 400 && (Var(50) = [1,2])
trigger6 = StateNo = 430 && (Var(50) = [1,2])
trigger8 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger9 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Stand Light Kick (close)
[State -1, Stand Light Kick (close)]
type = ChangeState
value = 235
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(3) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = P2BodyDist X = [-9,9]
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 205 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger10 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Stand Light Kick
[State -1, Stand Light Kick]
type = ChangeState
value = 230
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(3) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 205 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger10 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Stand Light Punch
[State -1, Stand Light Punch]
type = ChangeState
value = 200
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(0) = [1,2]
triggerall = helper(10371), command != "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger7 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Crouching Strong Kick
[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(5) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 220 && (Var(50) = [1,2])
trigger10 = StateNo = 225 && (Var(50) = [1,2])
trigger11 = StateNo = 230 && (Var(50) = [1,2])
trigger12 = StateNo = 235 && (Var(50) = [1,2])
trigger13 = StateNo = 240 && (Var(50) = [1,2])
trigger14 = StateNo = 400 && (Var(50) = [1,2])
trigger15 = StateNo = 410 && (Var(50) = [1,2])
trigger16 = StateNo = 420 && (Var(50) = [1,2])
trigger17 = StateNo = 430 && (Var(50) = [1,2])
trigger18 = StateNo = 440 && (Var(50) = [1,2])
trigger19 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger20 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Crouching Strong Punch
[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(2) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 210 && (Var(50) = [1,2]) && PrevStateNo != 310
trigger4 = StateNo = 215 && (Var(50) = [1,2])
trigger5 = StateNo = 230 && (Var(50) = [1,2])
trigger6 = StateNo = 235 && (Var(50) = [1,2])
trigger7 = StateNo = 240 && (Var(50) = [1,2])
trigger8 = StateNo = 400 && (Var(50) = [1,2])
trigger9 = StateNo = 410 && (Var(50) = [1,2])
trigger10 = StateNo = 430 && (Var(50) = [1,2])
trigger11 = StateNo = 440 && (Var(50) = [1,2])
trigger12 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger13 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Crouching Medium Kick
[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(4) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 210 && (Var(50) = [1,2])
trigger8 = StateNo = 215 && (Var(50) = [1,2])
trigger9 = StateNo = 230 && (Var(50) = [1,2])
trigger10 = StateNo = 235 && (Var(50) = [1,2])
trigger11 = StateNo = 400 && (Var(50) = [1,2])
trigger12 = StateNo = 410 && (Var(50) = [1,2])
trigger13 = StateNo = 430 && (Var(50) = [1,2])
trigger14 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger15 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Crouching Medium Punch
[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(1) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && (Var(50) = [1,2])
trigger3 = StateNo = 230 && (Var(50) = [1,2])
trigger4 = StateNo = 235 && (Var(50) = [1,2])
trigger5 = StateNo = 400 && (Var(50) = [1,2])
trigger6 = StateNo = 430 && (Var(50) = [1,2])
trigger8 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger9 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Crouching Light Kick
[State -1, Crouching Light Kick]
type = ChangeState
value = 430
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(3) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 2
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = StateNo = 200 && (Var(50) = [1,2])
trigger7 = StateNo = 400 && (Var(50) = [1,2])
trigger8 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger9 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Crouching Light Punch
[State -1, Crouching Light Punch]
type = ChangeState
value = 400
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(0) = [1,2]
triggerall = helper(10371), command = "holddown"
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = ctrl || (StateNo = 100 && AnimElemTime(2) >1) || StateNo = 101
trigger2 = StateNo = 200 && Time > 1
trigger3 = StateNo = 230 && Time > 4
trigger4 = StateNo = 400 && Time > 2
trigger5 = StateNo = 430 && Time > 2
trigger6 = ((StateNo = [195,299]) || (StateNo = [400,450]) || (StateNo = [600,650])) && (Var(50) = [1,2]) && Var(30)
trigger7 = (StateNo = [1000,1499]) && Var(50) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Jump Strong Kick
[State -1, Jump Strong Kick]
type = ChangeState
value = 650
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(5) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Jump Strong Punch
[State -1, Jump Strong Punch]
type = ChangeState
value = 620
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(2) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Jump Medium Kick
[State -1, Jump Medium Kick]
type = ChangeState
value = 640
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(4) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Jump Medium Punch
[State -1, Jump Medium Punch]
type = ChangeState
value = 610
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(1) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Jump Light Kick
[State -1, Jump Light Kick]
type = ChangeState
value = 630
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(3) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0

;---------------------------------------------------------------------------
; Jump Light Punch
[State -1, Jump Light Punch]
type = ChangeState
value = 600
;triggerall = !AILevel
triggerall = numHelper(10371)
triggerall = helper(10371), var(0) = [1,2]
triggerall = statetype = A
triggerall = roundstate = 2
trigger1 = ctrl
trigger2 = (StateNo = [600,650]) && (Var(50) = [1,2]) && Var(30)
ignorehitpause = 0
