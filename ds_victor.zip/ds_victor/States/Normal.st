; _________________________________________
;| Victor by varo_hades                    |
; �����������������������������������������
;==============================================================================================
;========================================<NORMAL MOVES>========================================
;==============================================================================================

;===========<STANDING LIGHT PUNCH>==========
[StateDef 200]
type = S
physics = S
moveType = A
anim = 200
ctrl = 0
velset = 0,0
sprPriority = 1
powerAdd = 0
facep2 = 1

[State 200, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 0, 1)
channel = 0

[State 200, Woosh]
type = PlaySnd
trigger1 = !Time
value = 1,0
channel = 1

[State 200, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 0
getpower = 72 * !var(20), 36 * !var(20)
givepower = 36, 36
pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
animType = Light
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 12 + 2 * var(9)
ground.slideTime = 12 + 2 * var(9)
guard.hitTime = 12
air.hitTime = 120
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.4
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 0)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8010)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 171), var(36):= -60
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 200, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 4 && !MoveContact
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 0
getpower = 72 * !var(20), 36 * !var(20)
givepower = 36, 36
pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
animType = Light
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 12 + 2 * var(9)
ground.slideTime = 12 + 2 * var(9)
guard.hitTime = 12
air.hitTime = 120
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.4
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 0)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8010)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 171), var(36):= -120
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48

[State 200, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(5) >= 0
moveType = I

[State 200, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING FAR MEDIUM PUNCH>==========
[StateDef 210]
type = S
physics = S
moveType = A
anim = 210
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 210, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 210, Woosh]
type = PlaySnd
trigger1 = !Time
value = 1,1
channel = 1

[State 210, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 85 < 7, 7, fvar(11) * 85)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.15, -8.3), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.15, -8.3)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 1)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 190), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 210, 5]
type = ChangeState
triggerall = time = 6
trigger1 = prevstateno != 100
trigger1 = command = "holdy"
trigger2 = var(11) = 2
value = 211

[State 210, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
moveType = I

[State 210, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING FAR MEDIUM PUNCH>==========
[StateDef 211]
type = S
physics = S
moveType = A
anim = 211
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 211, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 211, Woosh]
type = PlaySnd
trigger1 = !Time
value = 1,6
channel = 1

[State 211]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 211]
type = Helper
trigger1 = Animelem = 1
stateno = 212
id = 211
pos = 59,-60
postype = p1
ownpal = 1
sprpriority = 5

[State 211, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 65 < 7, 7, fvar(11) * 65)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.15, -8.3), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.15, -8.3)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 190), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 211]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2600
value = 2600
persistent = 0
ignorehitpause = 1

[State 211, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(3) >= 0
moveType = I

[State 211, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 212]
type = A
movetype = I
physics = N
ctrl = 0
velset = 8,0
anim = 212
sprpriority = 5

[State 212]
type = Explod
trigger1 = time = 0
anim = 212
id = 211
pos = -20,0
postype = p1
sprpriority = 4
facing = 1
vel = 7,0
scale = .8,.8
ownpal = 1

[State 212]
type = Explod
trigger1 = time = 0
anim = 212
id = 211
pos = -40,0
postype = p1
sprpriority = 3
facing = 1
vel = 6,0
scale = .6,.6
ownpal = 1

[State 212]
type = VelSet
trigger1 = Time = 8
x = 0

[State 212]
type = RemoveExplod
trigger1 = Time = 7
trigger2 = Animtime = 0
trigger3 = root,Movetype = H
trigger4 = root,stateno != 211
id = 211

[State 212]
type = Explod
trigger1 = time = 8
anim = 213
id = 211
pos = -40,0
postype = p1
sprpriority = 4
facing = 1
vel = 0,0
scale = .8,.8
ownpal = 1

[State 212]
type = Explod
trigger1 = time = 8
anim = 213
id = 211
pos = -65,0
postype = p1
sprpriority = 3
facing = 1
vel = 0,0
scale = .6,.6
ownpal = 1

[State 212]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 211

;===========<STANDING CLOSE MEDIUM PUNCH>==========
[StateDef 215]
type = S
physics = S
moveType = A
anim = 215
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
facep2 = 1

[State 215, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 215, Woosh]
type = PlaySnd
trigger1 = !Time
value = 1,1
channel = 1

[State 215, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 80 < 7, 7, fvar(11) * 80)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.15, -8.3), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.15, -8.3)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 1)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 194), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 215, 5]
type = ChangeState
triggerall = time = 5
trigger1 = prevstateno != 100
trigger1 = command = "holdy"
trigger2 = var(11) = 2
value = 216

[State 215, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
moveType = I

[State 215, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING CLOSE MEDIUM PUNCH>==========
[StateDef 216]
type = S
physics = S
moveType = A
anim = 216
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
facep2 = 1

[State 216, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 216, Woosh]
type = PlaySnd
trigger1 = !Time
value = 1,6
channel = 1

[State 216]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 216]
type = Helper
trigger1 = Animelem = 1
stateno = 217
id = 216
pos = -1,-103
postype = p1
ownpal = 1
sprpriority = 5

[State 216, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 65 < 7, 7, fvar(11) * 65)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.15, -8.3), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.15, -8.3)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 194), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 216]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2600
value = 2600
persistent = 0
ignorehitpause = 1

[State 216, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
moveType = I

[State 216, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 217]
type = A
movetype = I
physics = N
ctrl = 0
velset = 5,3
anim = 242
sprpriority = 5

[State 217]
type = Explod
trigger1 = time = 0
anim = 242
id = 216
pos = -7,-5
postype = p1
sprpriority = 4
facing = 1
vel = 5,3
scale = .8,.8
ownpal = 1

[State 217]
type = Explod
trigger1 = time = 0
anim = 242
id = 216
pos = -15,-10
postype = p1
sprpriority = 3
facing = 1
vel = 5,3
scale = .6,.6
ownpal = 1

[State 217]
type = VelSet
trigger1 = Time = 11
x = 0

[State 217]
type = RemoveExplod
trigger1 = Time = 10
trigger2 = Animtime = 0
trigger3 = root,Movetype = H
trigger4 = root,stateno != 216
id = 216

[State 217]
type = Explod
trigger1 = time = 10
anim = 243
id = 216
pos = -7,-5
postype = p1
sprpriority = 4
facing = 1
vel = 0,0
scale = .8,.8
ownpal = 1

[State 217]
type = Explod
trigger1 = time = 10
anim = 243
id = 216
pos = -15,-10
postype = p1
sprpriority = 3
facing = 1
vel = 0,0
scale = .6,.6
ownpal = 1

[State 217]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 216

;===========<STANDING FAR HEAVY PUNCH>==========
[StateDef 220]
type = S
physics = S
moveType = A
anim = 220
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
facep2 = 1

[State 220, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 220, Woosh]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1,2
channel = 1

[State 220, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 105 < 7, 7, fvar(11) * 105)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -1.5, -3), -7
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -3, -5
air.cornerPush.velOff = 0
yAccel = 0.40
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 169), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 220]
type = ChangeState
triggerall = time = 9
trigger1 = prevstateno != 100
trigger1 = command = "holdz"
trigger2 = var(11) = 2
value = 221

[State 220, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 220, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING FAR HEAVY PUNCH>==========
[StateDef 221]
type = S
physics = S
moveType = A
anim = 221
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
facep2 = 1

[State 221, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 221, Woosh]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,6
channel = 1

[State 221]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 221]
type = Helper
trigger1 = Animelem = 1
stateno = 222
id = 221
pos = 59,-80
postype = p1
ownpal = 1
sprpriority = 5

[State 221, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 90 < 7, 7, fvar(11) * 90)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.5, -9), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.40
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 169), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 221, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(5) >= 0
movetype = I

[State 221]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2670
value = 2670
persistent = 0
ignorehitpause = 1

[State 221, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 222]
type = A
movetype = I
physics = N
ctrl = 0
velset = 8,0
anim = 242
sprpriority = 5

[State 222]
type = Explod
trigger1 = time = 0
anim = 242
id = 221
pos = -20,0
postype = p1
sprpriority = 4
facing = 1
vel = 7,0
scale = .8,.8
ownpal = 1

[State 222]
type = Explod
trigger1 = time = 0
anim = 242
id = 221
pos = -40,0
postype = p1
sprpriority = 3
facing = 1
vel = 5,0
scale = .6,.6
ownpal = 1

[State 222]
type = VelSet
trigger1 = Time = 11
x = 0

[State 222]
type = RemoveExplod
trigger1 = Time = 10
trigger2 = Animtime = 0
trigger3 = root,Movetype = H
trigger4 = root,stateno != 221
id = 221

[State 222]
type = Explod
trigger1 = time = 10
anim = 243
id = 221
pos = -50,0
postype = p1
sprpriority = 4
facing = 1
vel = 0,0
scale = .8,.8
ownpal = 1

[State 222]
type = Explod
trigger1 = time = 10
anim = 243
id = 221
pos = -90,0
postype = p1
sprpriority = 3
facing = 1
vel = 0,0
scale = .6,.6
ownpal = 1

[State 222]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 221

;===========<STANDING CLOSE HEAVY PUNCH>==========
[StateDef 225]
type = S
physics = S
moveType = A
anim = 225
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
facep2 = 1

[State 225, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 225, Woosh]
type = PlaySnd
trigger1 = !Time
value = 1,2
channel = 1

[State 225, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 120 < 7, 7, fvar(11) * 120)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifelse(var(20), -1.75, -3.5), -7
ground.cornerPush.veloff = 0
guard.velocity = ifelse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -3, -5
air.cornerPush.velOff = 0
yAccel = 0.40
fall = ifElse(PrevStateNo = 700, 1, 0)
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 190), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
forceStand = 1

[State 225]
type = ChangeState
triggerall = time = 10
trigger1 = prevstateno != 100
trigger1 = command = "holdz"
trigger2 = var(11) = 2
value = 226

[State 225, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(7) >= 0
movetype = I

[State 225, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING CLOSE HEAVY PUNCH>==========
[StateDef 226]
type = S
physics = S
moveType = A
anim = 226
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
facep2 = 1

[State 226, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 226, Woosh]
type = PlaySnd
trigger1 = !Time
value = 1,6
channel = 1

[State 226]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 226]
type = Helper
trigger1 = animelem = 1
stateno = 227
id = 226
pos = 22,-125
postype = p1
ownpal = 1
sprpriority = 5

[State 226]
type = Helper
trigger1 = time = 5
stateno = 227
id = 226
pos = 22,-125
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .8
size.yscale = .8

[State 226]
type = Helper
trigger1 = time = 8
stateno = 227
id = 226
pos = 22,-125
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .6
size.yscale = .6

[State 226, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 90 < 7, 7, fvar(11) * 90)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifelse(var(20), -4.5, -9), 0
ground.cornerPush.veloff = 0
guard.velocity = ifelse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.40
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 190), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
forceStand = 1

[State 226]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2670
value = 2670
persistent = 0
ignorehitpause = 1

[State 226, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 226, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 227]
type    = A
movetype= I
physics = N
ctrl = 0
velset = 0,0
anim = 227
sprpriority = 5

[State 227]
type = varset
trigger1 = time = 0
fvar(15) = 0

[State 227]
type = varset
trigger1 = time = 0
fvar(16) = 0

[State 227]
type = varadd
trigger1 = 1
fvar(15) = 73/15

[State 227]
type = varadd
trigger1 = 1
fvar(16) = 89/15

[State 227]
type = bindtoparent
trigger1 = time =[0,5]
pos = (fvar(15))+47,-122+(fvar(16))

[State 227]
type = bindtoparent
trigger1 = time =[6,15]
pos = (fvar(15))+47+10,-122+(fvar(16))

[State 227]
type = bindtoparent
trigger1 = time > 15
pos = 120,-33

[State 227]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 226

;===========<STANDING LIGHT KICK>==========
[StateDef 230]
type = S
physics = S
moveType = A
anim = 230
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
facep2 = 1

[State 230, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, ifElse(Random < 500, 0, 1)
channel = 0

[State 230, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,3
channel = 1

[State 230, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 4
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 0
getPower = 72 * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
animType = Light
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 12 + 2 * var(9)
ground.slideTime = 12 + 2 * var(9)
guard.hitTime = 12
air.hitTime = 120
ground.velocity = ifElse(var(20), -2.35, -4.7), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.35, -4.7)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 3)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8010)
guard.sparkNo = -1 + 0*(var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 169), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 230, StateTypeSet: Idle]
type = StateTypeSet
trigger1= AnimElemTime(5) >= 0
moveType = I

[State 230, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING CLOSE LIGHT KICK>==========
[StateDef 235]
type = S
physics = S
moveType = A
anim = 235
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
facep2 = 1

[State 235, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, ifElse(Random < 500, 0, 1)
channel = 0

[State 235, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,3
channel = 1

[State 235, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 0
getPower = 72 * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
animType = Light
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 12 + 2 * var(9)
ground.slideTime = 12 + 2 * var(9)
guard.hitTime = 12
air.hitTime = 120
ground.velocity = ifElse(var(20), -2.25, -4.5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.25, -4.5)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 3)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8010)
guard.sparkNo = -1 + 0*(var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 169), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 235, StateTypeSet: Idle]
type = StateTypeSet
trigger1= AnimElemTime(4) >= 0
moveType = I

[State 235, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING FAR MEDIUM KICK>==========
[StateDef 240]
type = S
physics = S
moveType = A
anim = 240
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 240, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 240, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1,4
channel = 1

[State 240, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 85 < 7, 7, fvar(11) * 85)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.15, -8.3), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.15, -8.3)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 4)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 160), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 240]
type = ChangeState
triggerall = Animelem = 4
trigger1 = prevstateno != 100
trigger1 = command = "holdb"
trigger2 = var(11) = 2
value = 241

[State 240, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 240, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING FAR MEDIUM KICK>==========
[StateDef 241]
type = S
physics = S
moveType = A
anim = 241
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 241, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 241, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1,6
channel = 1

[State 241]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 241]
type = Helper
trigger1 = Animelem = 1
stateno = 242
id = 241
pos = 29,-72
postype = p1
ownpal = 1
sprpriority = 5

[State 241, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 80 < 7, 7, fvar(11) * 80)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.15, -8.3), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.15, -8.3)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 160), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 241]
type = TargetState
trigger1 = Movehit
value = 2600
persistent = 0
ignorehitpause = 1

[State 241, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(3) >= 0
movetype = I

[State 241, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 242]
type = A
movetype = I
physics = N
ctrl = 0
velset = 8,0
anim = 242
sprpriority = 5

[State 242]
type = Explod
trigger1 = time = 0
anim = 242
id = 241
pos = -20,0
postype = p1
sprpriority = 4
facing = 1
vel = 7,0
scale = .8,.8
ownpal = 1

[State 242]
type = Explod
trigger1 = time = 0
anim = 242
id = 241
pos = -40,0
postype = p1
sprpriority = 3
facing = 1
vel = 5,0
scale = .6,.6
ownpal = 1

[State 242]
type = VelSet
trigger1 = Time = 11
x = 0

[State 242]
type = RemoveExplod
trigger1 = Time = 10
trigger2 = Animtime = 0
trigger3 = root,Movetype = H
trigger4 = root,stateno != 241
id = 241

[State 242]
type = Explod
trigger1 = time = 10
anim = 243
id = 241
pos = -50,0
postype = p1
sprpriority = 4
facing = 1
vel = 0,0
scale = .8,.8
ownpal = 1

[State 242]
type = Explod
trigger1 = time = 10
anim = 243
id = 241
pos = -90,0
postype = p1
sprpriority = 3
facing = 1
vel = 0,0
scale = .6,.6
ownpal = 1

[State 242]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 241

;===========<STANDING CLOSE MEDIUM KICK>==========
[StateDef 245]
type = S
physics = S
moveType = A
anim = 245
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 245, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 245, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1,4
channel = 1

[State 245, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 85 < 7, 7, fvar(11) * 85)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -3.25, -6.5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -3.25, -6.5)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 4)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 178), var(36) := -50
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 245]
type = ChangeState
triggerall = Animelem = 3
trigger1 = prevstateno != 100
trigger1 = command = "holdb"
trigger2 = var(11) = 2
value = 246

[State 245, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 245, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING CLOSE MEDIUM KICK>==========
[StateDef 246]
type = S
physics = S
moveType = A
anim = 246
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 246, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 246, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,6
channel = 1

[State 246]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 246]
type = Helper
trigger1 = Animelem = 2
stateno = 247
id = 246
pos = 0,-58
postype = p1
ownpal = 1
sprpriority = 5

[State 246, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.15, -8.3), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.15, -8.3)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 178), var(36) := -50
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 246, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 246]
type = TargetState
trigger1 = Movehit
value = 2600
persistent = 0
ignorehitpause = 1

[State 246, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 247]
type = A
movetype = I
physics = N
ctrl = 0
velset = 6,0
anim = 247
sprpriority = 5

[State 247]
type = Explod
trigger1 = time = 0
anim = 247
id = 246
pos = 0,0
postype = p1
sprpriority = 4
facing = 1
vel = 4,0
scale = .8,.8
ownpal = 1

[State 247]
type = Explod
trigger1 = time = 0
anim = 247
id = 246
pos = 0,0
postype = p1
sprpriority = 3
facing = 1
vel = 2,0
scale = .6,.6
ownpal = 1

[State 247]
type = VelSet
trigger1 = Time = 14
x = 0

[State 247]
type = RemoveExplod
trigger1 = Time = 13
trigger2 = Animtime = 0
trigger3 = root,Movetype = H
trigger4 = root,stateno != 246
id = 246

[State 247]
type = Explod
trigger1 = time = 13
anim = 248
id = 246
pos = -50,0
postype = p1
sprpriority = 4
facing = 1
vel = 0,0
scale = .8,.8
ownpal = 1

[State 247]
type = Explod
trigger1 = time = 13
anim = 248
id = 246
pos = -90,0
postype = p1
sprpriority = 3
facing = 1
vel = 0,0
scale = .6,.6
ownpal = 1

[State 247]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 246

;===========<STANDING FAR HEAVY KICK>==========
[StateDef 250]
type = S
physics = N
moveType = A
anim = 250
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 250, Voice]
type = PlaySnd
trigger1 = AnimElem = 5
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 250, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 1,5
channel = 1

[State 250, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 110 < 7, 7, fvar(11) * 110)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.5, -9),0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkxy = -10 + 0 * (var(35) := 153), var(36) := -95
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 250]
type = ChangeState
triggerall = time = 8
trigger1 = prevstateno != 100
trigger1 = command = "holdc"
trigger2 = var(11) = 2
value = 251

[State 250, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(7) >= 0
moveType = I

[State 250, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING FAR HEAVY KICK>==========
[StateDef 251]
type = S
physics = N
moveType = A
anim = 251
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 251, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 251, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,6
channel = 1

[State 251]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 251]
type = Helper
trigger1 = Animelem = 2
stateno = 252
id = 251
pos = 20,-66
postype = p1
ownpal = 1
sprpriority = 5

[State 251, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 90 < 7, 7, fvar(11) * 90)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -4, -8),0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4, -8)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkxy = -10 + 0 * (var(35) := 153), var(36) := -95
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 251, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
moveType = I

[State 251]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2670
value = 2670
persistent = 0
ignorehitpause = 1

[State 251, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 252]
type = A
movetype = I
physics = N
ctrl = 0
velset = 8,-8
anim = 252
sprpriority = 5

[State 252]
type = Explod
trigger1 = time = 0
anim = 252
id = 251
pos = -10,10
postype = p1
sprpriority = 4
facing = 1
vel = 7,-7
scale = .8,.8
ownpal = 1

[State 252]
type = Explod
trigger1 = time = 0
anim = 252
id = 251
pos = -20,20
postype = p1
sprpriority = 3
facing = 1
vel = 5,-5
scale = .6,.6
ownpal = 1

[State 252]
type = VelSet
trigger1 = Time = 11
x = 0

[State 252]
type = RemoveExplod
trigger1 = Time = 11
trigger2 = Animtime = 0
trigger3 = root,Movetype = H
trigger4 = root,stateno != 251
id = 251

[State 2251]
type = Bindtoparent
trigger1 = Time >= 11
pos = 114,-152

[State 252]
type = Explod
trigger1 = time = 11
anim = 253
id = 251
pos = -30,30
postype = p1
sprpriority = 4
facing = 1
vel = 0,0
scale = .8,.8
ownpal = 1

[State 252]
type = Explod
trigger1 = time = 11
anim = 253
id = 251
pos = -60,60
postype = p1
sprpriority = 3
facing = 1
vel = 0,0
scale = .6,.6
ownpal = 1

[State 252]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 251

;===========<STANDING CLOSE HEAVY KICK>==========
[StateDef 255]
type = S
physics = S
moveType = A
anim = 255
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 255]
type = PosAdd
trigger1 = Time = 0
trigger1 = prevstateno = 245
x = 10

[State 255, Voice]
type = PlaySnd
trigger1 = AnimElem = 6
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 255, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 6
value = 1,5
channel = 1

[State 255, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 7
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 100 < 7, 7, fvar(11) * 100)), 0
getPower = ifElse(!var(13), 216, 72)*!var(20), 36*!var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -5.25, -10.5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -5.25, -10.5)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkno = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 174), var(36) := -50
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
forceStand = 1

[State 255]
type = ChangeState
triggerall = time = 9
trigger1 = prevstateno != 100
trigger1 = command = "holdc"
trigger2 = var(11) = 2
value = 256

[State 255, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElemTime(8) >= 0
moveType = I

[State 255, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<STANDING CLOSE HEAVY KICK>==========
[StateDef 256]
type = S
physics = S
moveType = A
anim = 256
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 256, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 256, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1,6
channel = 1

[State 256]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 256]
type = Helper
trigger1 = Animelem = 2
stateno = 257
id = 256
pos = 0,-58
postype = p1
ownpal = 1
sprpriority = 5

[State 256]
type = Helper
trigger1 = time = 6
stateno = 257
id = 256
pos = -53,-41
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .8
size.yscale = .8

[State 256]
type = Helper
trigger1 = time = 11
stateno = 257
id = 256
pos = -53,-41
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .6
size.yscale = .6

[State 256]
type = Explod
trigger1 = animelem = 3
anim = 3041
pos = -12,23
postype = p1
sprpriority = 3
ownpal = 1
shadow = 0,0,0
removeongethit = 1

[State 256, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 85 < 7, 7, fvar(11) * 85)), 0
getPower = ifElse(!var(13), 216, 72)*!var(20), 36*!var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.5, -9), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkno = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 174), var(36) := -50
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
forceStand = 1

[State 256, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
moveType = I

[State 256]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2670
value = 2670
persistent = 0
ignorehitpause = 1

[State 256, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 257]
type = A
movetype = I
physics = N
ctrl = 0
velset = 0,0
anim = 247
sprpriority = 5

[State 257]
type = varset
trigger1 = time = 0
fvar(15) = 0

[State 257]
type = varset
trigger1 = time = 0
fvar(16) = 0

[State 257]
type = varadd
trigger1 = 1
fvar(15) = 138/15

[State 257]
type = varadd
trigger1 = 1
fvar(16) = 19/15

[State 257]
type = bindtoparent
trigger1 = time <=15
pos = (fvar(15))-53,-41-(fvar(16))

[State 257]
type = bindtoparent
trigger1 = time > 15
pos = 85,-60

[State 257]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 256

;===========<CROUCHING LIGHT PUNCH>==========
[StateDef 400]
type = C
physics = C
moveType = A
anim = 400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 400, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 0, 1)
channel = 0

[State 400, Woosh Sound]
type = PlaySnd
trigger1 = !Time
value = 1,0
channel = 1

[State 400, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = C, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 0
getPower = 72 * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
animType = Light
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 12 + 2 * var(9)
ground.slideTime = 12 + 2 * var(9)
guard.hitTime = 12
air.hitTime = 120
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 0)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8010)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 171), var(36) := -45
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 400, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
moveType = I

[State 400, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<CROUCHING MEDIUM PUNCH>==========
[StateDef 410]
type = C
physics = C
moveType = A
anim = 410
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 410, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 410, Woosh Sound]
type = PlaySnd
trigger1 = !Time
value = 1,1
channel = 1

[State 410, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
forceNoFall = !var(20)
attr = C, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 80 < 7, 7, fvar(11) * 80)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.15, -8.3), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.15, -8.3)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 1)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0*(var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 179), var(36) := -50
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 410, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(7) >= 0
moveType = I

[State 410]
type = ChangeState
triggerall = time = 8
trigger1 = prevstateno != 100
trigger1 = command = "holdy"
trigger2 = var(11) = 2
value = 411

[State 410, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<CROUCHING MEDIUM PUNCH>==========
[StateDef 411]
type = C
physics = C
moveType = A
anim = 411
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 411, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 411, Woosh Sound]
type = PlaySnd
trigger1 = !Time
value = 1,6
channel = 1

[State 411]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 411]
type = Helper
trigger1 = Animelem = 1
stateno = 412
id = 411
pos = 46,-45
postype = p1
ownpal = 1
sprpriority = 5

[State 411, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
forceNoFall = !var(20)
attr = C, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 65 < 7, 7, fvar(11) * 65)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.5, -9), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0*(var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 179), var(36) := -40
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 411, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(3) >= 0
moveType = I

[State 411]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2600
value = 2600
persistent = 0
ignorehitpause = 1

[State 411, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 412]
type = A
movetype = I
physics = N
ctrl = 0
velset = 8,0
anim = 212
sprpriority = 5

[State 412]
type = Explod
trigger1 = time = 0
anim = 212
id = 411
pos = -20,0
postype = p1
sprpriority = 4
facing = 1
vel = 7,0
scale = .8,.8
ownpal = 1

[State 412]
type = Explod
trigger1 = time = 0
anim = 212
id = 411
pos = -40,0
postype = p1
sprpriority = 3
facing = 1
vel = 6,0
scale = .6,.6
ownpal = 1

[State 412]
type = VelSet
trigger1 = Time = 8
x = 0

[State 412]
type = RemoveExplod
trigger1 = Time = 7
trigger2 = Animtime = 0
trigger3 = root,Movetype = H
trigger4 = root,stateno != 411
id = 411

[State 412]
type = Explod
trigger1 = time = 8
anim = 213
id = 411
pos = -40,0
postype = p1
sprpriority = 4
facing = 1
vel = 0,0
scale = .8,.8
ownpal = 1

[State 412]
type = Explod
trigger1 = time = 8
anim = 213
id = 411
pos = -65,0
postype = p1
sprpriority = 3
facing = 1
vel = 0,0
scale = .6,.6
ownpal = 1

[State 412]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 411

;===========<CROUCHING HEAVY PUNCH>==========
[StateDef 420]
type = C
physics = C
moveType = A
anim = 420
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 420, Voice]
type = PlaySnd
trigger1 = AnimElem = 5
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 420, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 6
value = 1,2
channel = 1

[State 420, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
forceNoFall = !var(20)
attr = C, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 115 < 7, 7, fvar(11) * 115)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -1.5, -3), -7
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -3, -5
air.cornerPush.velOff = 0
yAccel = 0.40
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 156), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
forceStand = 1

[State 420, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(7) >= 0
moveType = I

[State 420]
type = ChangeState
triggerall = time = 8
trigger1 = prevstateno != 100
trigger1 = command = "holdz"
trigger2 = var(11) = 2
value = 421

[State 420, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<CROUCHING HEAVY PUNCH>==========
[StateDef 421]
type = C
physics = C
moveType = A
anim = 421
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 421, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 421, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,6
channel = 1

[State 421]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 421]
type = Helper
trigger1 = animelem = 2
stateno = 422
id = 421
pos = -25,-25
postype = p1
ownpal = 1
sprpriority = 5

[State 421]
type = Helper
trigger1 = time = 13
stateno = 422
id = 421
pos = -25,-25
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .8
size.yscale = .8

[State 421]
type = Helper
trigger1 = time = 19
stateno = 422
id = 421
pos = -25,-25
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .6
size.yscale = .6

[State 421, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
forceNoFall = !var(20)
attr = C, NA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 85 < 7, 7, fvar(11) * 85)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -1.5, -3), -7
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -3, -5
air.cornerPush.velOff = 0
yAccel = 0.40
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 156), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
forceStand = 1

[State 421, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(5) >= 0
moveType = I

[State 421]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2670
value = 2670
persistent = 0
ignorehitpause = 1

[State 421, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 422]
type = A
movetype = I
physics = N
ctrl = 0
velset = 0,0
anim = 252
sprpriority = 4

[State 422]
type = varset
trigger1 = time = 0
fvar(15) = 0

[State 422]
type = varset
trigger1 = time = 0
fvar(16) = 0

[State 422]
type = varadd
trigger1 = time < 10
fvar(15) = 119/9

[State 422]
type = varadd
trigger1 = time < 10
fvar(16) = 47/9

[State 422]
type = bindtoparent
trigger1 = time = [0, 5]
pos = (fvar(15))-25,-25-(fvar(16))

[State 422]
type = bindtoparent
trigger1 = time =[5, 10]
pos = (fvar(15))-25+2,-25-(fvar(16))

[State 422]
type = varset
trigger1 = time = 10
fvar(15) = 0

[State 422]
type = varset
trigger1 = time = 10
fvar(16) = 0

[State 422]
type = varadd
trigger1 = time = [10,18]
fvar(15) = 75/9

[State 256]
type = varadd
trigger1 = time = [10,18]
fvar(16) = 49/9

[State 422]
type = bindtoparent
trigger1 = time = [10,12]
pos = 94-(fvar(15))-2,-72-(fvar(16))-2

[State 422]
type = bindtoparent
trigger1 = time = [13,18]
pos = 94-(fvar(15)),-72-(fvar(16))-1

[State 422]
type = bindtoparent
trigger1 = time > 18
pos = 19,-121

[State 422]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 421

;===========<CROUCHING LIGHT KICK>==========
[StateDef 430]
type = C
physics = C
moveType = A
anim = 430
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 430, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, ifElse(Random < 500, 0, 1)
channel = 0

[State 430, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,3
channel = 1

[State 430, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = C, NA
hitFlag = MAF
guardFlag = L
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 0
getPower = 72 * !var(20), 36 * !var(20)
givepower = 36, 36
pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
animType = Light
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 12 + 2 * var(9)
ground.slideTime = 12 + 2 * var(9)
guard.hitTime = 12
air.hitTime = 120
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 3)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8010)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 196), var(36) := -25
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinadd= -255, -255, -255, 48

[State 430, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
moveType = I

[State 430, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<CROUCHING MEDIUM KICK>==========
[StateDef 440]
type = C
physics = C
moveType = A
anim = 440
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 440, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 440, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 1,4
channel = 1

[State 440, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
forceNoFall = !var(20)
attr = C, NA
hitFlag = MAF
guardFlag = L
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 80 < 7, 7, fvar(11) * 80)), 0
getPower = ifElse(!var(13),144,72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.15, -8.3), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.15, -8.3)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 4)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 166), var(36) := -15
palFX.time = 12*var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 440, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(7) >= 0
movetype = I

[State 440]
type = ChangeState
triggerall = time = 9
trigger1 = prevstateno != 100
trigger1 = command = "holdb"
trigger2 = var(11) = 2
value = 441

[State 440, End]
type = Changestate
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<CROUCHING MEDIUM KICK>==========
[StateDef 441]
type = C
physics = C
moveType = A
anim = 441
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 441, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 441, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1,6
channel = 1

[State 441]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 441]
type = Helper
trigger1 = Animelem = 1
stateno = 442
id = 441
pos = 40,-16
postype = p1
ownpal = 1
sprpriority = 5

[State 441, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
forceNoFall = !var(20)
attr = C, NA
hitFlag = MAF
guardFlag = L
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 65 < 7, 7, fvar(11) * 65)), 0
getPower = ifElse(!var(13),144,72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 15 + 3 * var(9)
ground.slideTime = 15 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.5, -9), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.5, -9)
guard.cornerPush.velOff = 0
air.velocity = -4, -5
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 166), var(36) := -15
palFX.time = 12*var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 441, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(3) >= 0
movetype = I

[State 441]
type = TargetState
trigger1 = Movehit
value = 2600
persistent = 0
ignorehitpause = 1

[State 441, End]
type = Changestate
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 442]
type = A
movetype = I
physics = N
ctrl = 0
velset = 8,0
anim = 212
sprpriority = 5

[State 442]
type = Explod
trigger1 = time = 0
anim = 212
id = 441
pos = -20,0
postype = p1
sprpriority = 4
facing = 1
vel = 7,0
scale = .8,.8
ownpal = 1

[State 442]
type = Explod
trigger1 = time = 0
anim = 212
id = 441
pos = -40,0
postype = p1
sprpriority = 3
facing = 1
vel = 5,0
scale = .6,.6
ownpal = 1

[State 442]
type = VelSet
trigger1 = Time = 8
x = 0

[State 442]
type = RemoveExplod
trigger1 = Time = 7
trigger2 = Animtime = 0
trigger3 = root,Movetype = H
trigger4 = root,stateno != 441
id = 441

[State 442]
type = Explod
trigger1 = time = 8
anim = 213
id = 441
pos = -50,0
postype = p1
sprpriority = 4
facing = 1
vel = 0,0
scale = .8,.8
ownpal = 1

[State 442]
type = Explod
trigger1 = time = 8
anim = 213
id = 441
pos = -90,0
postype = p1
sprpriority = 3
facing = 1
vel = 0,0
scale = .6,.6
ownpal = 1

[State 442]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 441

;===========<CROUCHING HEAVY KICK>==========
[StateDef 450]
type = C
physics = C
moveType = A
anim = 450
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 450, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 4, 4
channel = 0

[State 450, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1,5
channel = 1

[State 450, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
attr = C, NA
hitFlag = MAF
guardFlag = LA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 100 < 7, 7, fvar(11) * 100)), 0
getpower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givepower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Trip
air.type = Trip
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, -5
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.86, -10.52)
guard.cornerPush.velOff = 0
air.velocity = -2, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 196), var(36) := -25
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48

[State 450, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(6) >= 0
moveType = I

[State 450]
type = ChangeState
triggerall = time = 9
trigger1 = prevstateno != 100
trigger1 = command = "holdc"
trigger2 = var(11) = 2
value = 451

[State 450, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<CROUCHING HEAVY KICK>==========
[StateDef 451]
type = C
physics = C
moveType = A
anim = 451
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 451, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4, 4
channel = 0

[State 451, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1,6
channel = 1

[State 451]
type = palfx
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 451]
type = Helper
trigger1 = Animelem = 1
stateno = 452
id = 451
pos = 11,-23
postype = p1
ownpal = 1
sprpriority = 5

[State 451, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
attr = C, NA
hitFlag = MAF
guardFlag = LA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 85 < 7, 7, fvar(11) * 85)), 0
getpower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givepower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Trip
air.type = Trip
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, -5
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.86, -10.52)
guard.cornerPush.velOff = 0
air.velocity = -2, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 196), var(36) := -25
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48

[State 451, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(6) >= 0
moveType = I

[State 451]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2650
value = 2650
persistent = 0
ignorehitpause = 1

[State 451, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1

;===========<ELECTRICITY>==========
[Statedef 452]
type = A
movetype = I
physics = N
ctrl = 0
velset = 12,0
anim = 252
sprpriority = 5

[State 452]
type = Explod
trigger1 = time = 0
anim = 252
id = 451
pos = -20,0
postype = p1
sprpriority = 4
facing = 1
vel = 10,0
scale = .8,.8
ownpal = 1

[State 452]
type = Explod
trigger1 = time = 0
anim = 252
id = 451
pos = -40,0
postype = p1
sprpriority = 3
facing = 1
vel = 8,0
scale = .6,.6
ownpal = 1

[State 452]
type = VelSet
trigger1 = Time = 10
x = 0

[State 452]
type = RemoveExplod
trigger1 = Time = 9
trigger2 = Animtime = 0
trigger3 = root,Movetype = H
trigger4 = root,stateno != 451
id = 451

[State 452]
type = Explod
trigger1 = time = 10
anim = 452
id = 451
pos = -50,0
postype = p1
sprpriority = 4
facing = 1
vel = 0,0
scale = .8,.8
ownpal = 1

[State 452]
type = Explod
trigger1 = time = 10
anim = 452
id = 451
pos = -90,0
postype = p1
sprpriority = 3
facing = 1
vel = 0,0
scale = .6,.6
ownpal = 1

[State 452]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 451

;===========<JUMPING LIGHT PUNCH>==========
[StateDef 600]
type = A
physics = N
moveType = A
anim = 600
ctrl = 0
sprPriority = 1
powerAdd = 0

[State 600, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value= 4, ifElse(Random < 500, 0, 1)
channel = 0

[State 600, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,0
channel = 1

[State 600, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
forceNoFall = !var(20)
attr = A, NA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 0
getPower = 72 * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
animType = Light
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 12 + 2 * var(9)
ground.slideTime = 12 + 2 * var(9)
guard.hitTime = 12
air.hitTime = 120
airguard.ctrlTime = 16
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -1.3, -3
air.cornerPush.velOff = 0
airguard.velocity = -5, 0
airguard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 0)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8010)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 150), var(36) := -38
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 600, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(5) >= 0
moveType = I

[State 600, Gravity]
type = Gravity
trigger1 = Time >= 0

[State 600, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 52

;===========<JUMPING MEDIUM PUNCH>==========
[StateDef 610]
type = A
physics  = N
moveType = A
anim = 610
ctrl = 0
sprPriority = 1
powerAdd = 18 * !var(20)

[State 610, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 610, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,1
channel = 1

[State 610, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
forceNoFall = !var(20)
attr = A, NA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 80 < 7, 7, fvar(11) * 80)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 12 + 3 * var(9)
ground.slideTime = 12 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
airguard.ctrlTime = 16
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
airguard.velocity = -5, 0
airguard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 1)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 150), var(36) := -55
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 610, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 610, Gravity]
type = Gravity
trigger1 = Time >= 0

[State 610, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 52

;===========<NEUTRAL JUMPING HEAVY PUNCH>==========
[StateDef 620]
type = A
physics = N
moveType = A
anim = 620
ctrl = 0
sprPriority = 1
powerAdd = 18 * !var(20)

[State 620, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 620, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,2
channel = 1

[State 620, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = A, NA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 120 < 7, 7, fvar(11) * 120)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animtype = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 12 + 4 * var(9)
ground.slideTime = 12 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
airguard.ctrlTime = 16
ground.velocity = ifElse(var(20), -0.5, -1), 5
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -3, 5
air.cornerPush.velOff = 0
airguard.velocity = -5, 0
airguard.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 150), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 620, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
moveType = I

[State 620, Gravity]
type = Gravity
trigger1 = Time >= 0

[State 620, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 52

;===========<ANGLED JUMPING HEAVY PUNCH>==========
[StateDef 621]
type = A
physics = N
moveType = A
anim = 621
ctrl = 0
sprPriority = 1
powerAdd = 18 * !var(20)

[State 621, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 621, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,2
channel = 1

[State 621, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = A, NA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 90 < 7, 7, fvar(11) * 90)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animtype = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 12 + 4 * var(9)
ground.slideTime = 12 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
airguard.ctrlTime = 16
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
airguard.velocity = -5, 0
airguard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 163), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 621, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
moveType = I

[State 621, Gravity]
type = Gravity
trigger1 = Time >= 0

[State 621, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 52

;===========<JUMPING LIGHT KICK>==========
[StateDef 630]
type = A
physics = N
moveType = A
anim = 630
ctrl = 0
sprPriority = 1
powerAdd = 0

[State 630, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, ifElse(Random < 500, 0, 1)
channel = 0

[State 630, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,3
channel = 1

[State 630, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
forceNoFall = !var(20)
attr = A, NA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 0
getPower = 72 * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 3, 8), ifElse(var(20), 4, 8)
animType = Light
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 12 + 2 * var(9)
ground.slideTime = 12 + 2 * var(9)
guard.hitTime = 12
air.hitTime = 120
airguard.ctrlTime = 16
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -2, -3
air.cornerPush.velOff = 0
airguard.velocity = -5, 0
airguard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 3)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8010)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 147), var(36) := -35
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 630, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
moveType = I

[State 630, Gravity]
type = Gravity
trigger1 = Time >= 0

[State 630, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 52

;===========<JUMPING MEDIUM KICK>==========
[StateDef 640]
type = A
physics = N
moveType = A
anim = 640
ctrl = 0
sprPriority = 1
powerAdd = 18 * !var(20)

[State 640, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, ifElse(Random < 500, 1, 2)
channel = 0

[State 640, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,4
channel = 1

[State 640, Hit]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = A, NA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 85 < 7, 7, fvar(11) * 85)), 0
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 4, 10), ifElse(var(20), 5, 10)
animType = Medium
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 12 + 3 * var(9)
ground.slideTime = 12 + 3 * var(9)
guard.hitTime = 15
air.hitTime = 120
airguard.ctrlTime = 16
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
airguard.velocity = -5, 0
airguard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 4)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8011)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 178), var(36) := -40
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 640, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 640, Gravity]
type = Gravity
trigger1 = Time >= 0

[State 640, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 52

;===========<JUMPING HEAVY KICK>==========
[StateDef 650]
type = A
physics = N
moveType = A
anim = 650
ctrl = 0
sprPriority = 1
powerAdd = 18 * !var(20)

[State 650, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 650, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,5
channel = 1

[State 650, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
forceNoFall = !var(20)
attr = A, NA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 110 < 7, 7, fvar(11) * 110)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 12 + 4 * var(9)
ground.slideTime = 12 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
airguard.ctrlTime = 16
ground.velocity = ifElse(var(20), -2.5, -5), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -2.5, -5)
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
airguard.velocity = -5, 0
airguard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8012)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 195), var(36) := -40
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48

[State 650, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(5) >= 0
moveType = I

[State 650, Gravity]
type = Gravity
trigger1 = Time >= 0

[State 650, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 52

;===========<THROW ATTEMPT>==========
[StateDef 800]
type = S
physics = S
movetype = A
anim = 800
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 18 * !var(20)
faceP2 = 1

[State 800, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = (command = "kk")

[State 800, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(40) = (command = "pp2")

[State 800, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = (Random < 500)

[State 800, Tech Hit Reset]
type = VarSet
trigger1 = 1
var(19) = 0

[State 800, Tech Hit]
type = VarSet
trigger1 = NumEnemy
trigger1 = EnemyNear, StateType != A
trigger1 = (EnemyNear, StateNo = [0,999]) && (EnemyNear, StateNo != [100,119]) && (EnemyNear, StateNo != [200,799])
var(19) = 7

[State 800, AttackDist]
type = AttackDist
trigger1 = 1
value = 0

[State 800, HitDef: PP Throw]
type = HitDef
trigger1 = AnimElem = 2
trigger1 = !var(38)
attr = S, NT
hitFlag = M-
priority = 1, Miss
getPower = 0,0
givePower = 0,0
sparkNo = -1 +0 * (var(33) := 0)
guard.sparkNo = -1 +0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 40), var(36) := -50
hitSound = -1 +0 * (var(31) := 800)
guardSound = -1 +0 * (var(32) := 0)
fall = 1
fall.recover = 1
numHits = 0
p1StateNo = ifElse(command = "holdback", 805, 820)

[State 800, HitDef: KK Throw]
type = HitDef
trigger1 = AnimElem = 2 && var(10)
trigger1 = !var(38)
attr = S, NT
hitFlag = M-
priority = 1, Miss
getPower = 0,0
givePower = 0,0
sparkNo = -1 + 0 * (var(33) := 0)
guard.sparkNo = -1 +0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 40), var(36) := -50
hitSound = -1 +0 * (var(31) := 800)
guardSound = -1 +0 * (var(32) := 0)
fall = 1
fall.recover = 1
numhits = 0
p1StateNo = ifElse(command = "holdback", 805, 810)

[State 800, HitDef: PP2 Throw]
type = HitDef
trigger1 = AnimElem = 2 && var(40)
trigger1 = !var(38)
attr = S, NT
hitFlag = M-
priority = 1, Miss
getPower = 0,0
givePower = 0,0
sparkNo = -1 + 0 * (var(33) := 0)
guard.sparkNo = -1 +0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 40), var(36) := -50
hitSound = -1 +0 * (var(31) := 800)
guardSound = -1 +0 * (var(32) := 0)
fall = 1
fall.recover = 1
numhits = 0
p1StateNo = ifElse(command = "holdback", 805, 830)

[State 800, Voice (Missed)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 800,0
channel = 0

[State 800, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,0
channel = 1

[State 800, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(3) >= 0
moveType = I

[State 800, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<THROW SWITCHING SIDES>==========
[StateDef 805]
type = S
moveType = A
physics = S
anim = 805
ctrl = 0
sprPriority = 0

[State 805, TargetState]
type = TargetState
trigger1 = !Time && NumTarget
value = 806

[State 805, TargetFacing]
type = TargetFacing
trigger1 = !Time && NumTarget
value = -1

[State 805, Width]
type = Width
trigger1 = 1
edge = 24,24
ignoreHitPause = 1

[State 805, Turn]
type = Turn
trigger1 = AnimElem = 3

[State 805, Facing]
type = TargetFacing
trigger1 = 1
value = -1

[State 805, Tech Hit]
type = ChangeState
trigger1 = NumTarget && var(19)
trigger1 = (Target, command = "holdfwd" || Target, command = "holdback") && Target, command != "holdup" && Target, command != "holddown"
trigger1 = (Target, command = "b" || Target, command = "c" || Target, command = "y" || Target, command = "z")
value = 890

[State 805, Tech Hit Countdown]
type = VarAdd
trigger1 = var(19) > 0
var(19) = -1

[State 805, TargetBind 1]
type = TargetBind
trigger1 = AnimElemTime(2) < 0 || AnimElemTime(4) >= 0
pos = ceil(35 * const(size.xScale)), 0

[State 805, TargetBind 2]
type = TargetBind
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(4) < 0
pos = ceil(11 * const(size.xScale)), 0

[State 805, SprPriority 1]
type = SprPriority
trigger1 = AnimElemTime(2) < 0 || AnimElemTime(4) >= 0
value = 1

[State 805, SprPriority -1]
type = SprPriority
trigger1 = AnimElemTime(2) >= 0 && AnimElemTime(4)< 0
value = -1

[State 805, End]
type = ChangeState
trigger1 = !NumTarget
value = 0
ctrl = 1

[State 805, End]
type = ChangeState
trigger1 = AnimElemTime(4) >= 0
value = ifElse(var(10), 810, ifElse(var(40), 830, 820))

;===========<THROW SWITCHING SIDES (TARGET)>==========
[StateDef 806]
type = A
moveType = H
physics = N
velSet = 0,0
sprPriority = 0

[State 806, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 806, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time
value = 806

[State 806, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
moveCamera = 1,1
ignoreHitPause = 1

[State 806, SelfState]
type = SelfState
trigger1 = Time >= 60
value = ifElse(pos y < 0, 5040, 0)
ctrl = 1

;===========<MEGA STRANGLE>==========
[Statedef 820]
type = S
physics = N
moveType = A
anim = 810
ctrl = 0
velSet = 0,0
sprPriority = 1

[State 810, Lost Target]
type = ChangeState
trigger1 = !Time && !NumTarget
value = 0
ctrl = 1

[State 810, Tech Hit]
type = ChangeState
trigger1 = NumTarget && var(19)
trigger1 = (Target, command = "holdfwd" || Target, command = "holdback")
trigger1 = (Target, command = "b" || Target, command = "c" || Target, command = "y" || Target, command = "z")
value = 890

[State 810, Throw Escape]
type = VarAdd
trigger1 = var(19) > 0
var(19) = -1

[State 810, Throw]
type = TargetState
trigger1 = !Time && NumTarget
value = 825

[State 805]
type = Helper
trigger1 = time = 0
stateno = 2700
id = 2700
pos = 0,9999
postype = p1
ownpal = 1
sprpriority = -2
keyctrl = 1

[State 805]
type = varset
trigger1 = time = 0
var(5) = 0

[State 805]
type = varset
trigger1 = command = "Throw"
var(5) = 1

[State 805]
type = changestate
trigger1 = animelem = 5,<= 0
trigger1 = var(5) = 1
value = 840

[State 805]
type = posadd
trigger1 = time = 1
trigger1 = frontedgebodydist <= 60
x = -70

[State 805]
type = targetBind
trigger1 = animelem = 1
pos = 40,-80

[State 805]
type = targetBind
trigger1 = animelem = 2
pos = 135,-95

[State 805]
type = targetBind
trigger1 = animelem = 3
pos = 70,-90

[State 805]
type = targetBind
trigger1 = animelem = 4
pos = 50,-95

[State 810]
type = SprPriority
trigger1 = AnimElem = 5
value = 2

[State 805]
type = targetBind
trigger1 = animelem = 5
pos = 35,-73

[State 805]
type = targetBind
trigger1 = animelem = 6
pos = 91,-102

[State 805]
type = targetBind
trigger1 = animelem = 7
pos = 61,-91

[State 805]
type = targetBind
trigger1 = animelem = 8
pos = 60,-88

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 8
value = floor(ifElse(20 * fvar(11) < 7, -7, -20 * fvar(11)))
Kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 8
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 8 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 8
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 5
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 8
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 8
var(16) = 1
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 8
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(65 * const(size.xScale)), ceil(-88 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 810, Voice]
type = PlaySnd
trigger1 = NumTarget && AnimElem = 8
value = 2,2
channel = 0

[State 810]
type = ChangeState
Trigger1 = AnimTime = 0
value = 821

;===========<MEGA STRANGLE>==========
[Statedef 821]
type = S
movetype = A
physics = N
anim = 811
poweradd = 0
sprpriority = 2

[State 856]
type = TargetState
Trigger1 = Time = 0
value = 826

[State 811]
type = VarAdd
trigger1 = 1
var(12) = -1
persistent = 0

[State 811]
type = Changestate
triggerall = prevstateno = 810 && var(14) != 0
triggerall = fvar(19) < 4 && Animelem = 1
trigger1 = fvar(19) != fvar(20)
value = 822;1 + var(14)
persistent = 0

[State 811]
type = Changestate
triggerall = prevstateno != 810 && var(14) != 0
triggerall = fvar(19) < 4 && Animelem = 1
trigger1 = fvar(19) != fvar(20)
value = 822;1 + var(14)
persistent = 0

[State 811]
type = targetBind
trigger1 = animelem = 1
pos = 91,-102

[State 805]
type = targetBind
trigger1 = animelem = 2
pos = 61,-91

[State 805]
type = targetBind
trigger1 = animelem = 3
pos = 65,-88

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 3
value = floor(ifElse(15 * fvar(11) < 7, -7, -15 * fvar(11)))

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 3
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 3 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 3
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 3
var(16) = 1
ignoreHitPause = 1

[State 811]
type = PlaySnd
trigger1 = animelem = 3
value = 2,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 3
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(65 * const(size.xScale)), ceil(-88 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 856]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) <= 0
value = 823

[State 811]
type = ChangeState
triggerall = AnimTime = 0
trigger1 = var(12) > 0
trigger2 = fvar(19) != fvar(20)
value = 821

;===========<MEGA STRANGLE>==========
[Statedef 823]
type = S
movetype = A
physics = N
anim = 814
poweradd = 0
sprpriority = 2

[State 815]
type = Varset
trigger1 = 1
var(24) = 0

[State 815]
type = targetBind
trigger1 = animelem = 1
pos = 50,-60

[State 815]
type = targetstate
trigger1 = animelem = 1
trigger1 = fvar(19) <= 0
value = 828

[State 815]
type = targetstate
trigger1 = animelem = 1
trigger1 = fvar(19) > 0
value = 827

[State 815]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;===========<MEGA STRANGLE>==========
[Statedef 822]
type = S
movetype = A
physics = N
anim = 812
poweradd = 0
sprpriority = 2

[State 811]
type = changeanim
Trigger1 = Time = 0
value = 812

[State 811]
type = TargetState
Trigger1 = Time = 0
value = 826

[State 853]
type = null;VarAdd
trigger1 = 1
var(12) = -1
persistent = 0

[State 805]
type = targetBind
trigger1 = animelem = 1
pos = 91,-102

[State 805]
type = targetBind
trigger1 = animelem = 2
pos = 61,-91

[State 805]
type = targetBind
trigger1 = animelem = 3
pos = 65,-88

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 3
value = floor(ifElse(15 * fvar(11) < 7, -7, -15 * fvar(11)))
Kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 3
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 3 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 3
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 3
var(16) = 1
ignoreHitPause = 1

[State 853]
type = PlaySnd
trigger1 = animelem = 3
value = 2,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 3
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(65 * const(size.xScale)), ceil(-88 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 853]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) > 0
value = 821

[State 853]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) <= 0
value = 823

;===========<MEGA STRANGLE (TARGET)>==========
;Being Thrown
[StateDef 825]
type = A
moveType = H
physics = N
velSet = 0,0
sprPriority = 0

[State 815, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time
value = 815

[State 815, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0

;After Throw
[StateDef 826]
type = A
physics = N
movetype = H
ctrl = 0
velSet = 0, 0
sprPriority = 0

[State 816]
type = ChangeAnim2
Trigger1 = Time = 0
value = (enemy,anim)+5

[STate 816]
type = screenbound
trigger1 = 1
value = 0

[State 816]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 870

;After Throw
[Statedef 827]
type = A
movetype = H
physics = N
velset = -5,-6.5
poweradd = 100
sprpriority = -3

[State 825, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 819

[State 825] ;Gravity
type = VelAdd
Trigger1 = 1
y = .5

[State 825]
type = angleadd
trigger1 = animelem = 2,>= 0
trigger1 = time < 31
value = 15

[State 825]
type = angleset
trigger1 = time >= 31
value = 0

[State 825]
type = angleDraw
trigger1 = animelem = 2,>= 0
trigger1 = time < 31

[State 865, 2] ; Recover near ground (use ChangeState)
type = ChangeState
triggerall = Vel Y > 0
triggerall = Pos Y >= -40
triggerall = alive
triggerall = CanRecover
triggerall = animelem = 5, >= 0
trigger1 = Command = "recovery"
value = 5200 ;HITFALL_RECOVER

[State 825] ; Recover in mid air (use SelfState)
type = SelfState
triggerall = Vel Y > 0
triggerall = alive
triggerall = CanRecover
triggerall = animelem = 5, >= 0
trigger1 = Command = "recovery"
value = 5210 ;HITFALL_AIRRECOVER

[State 825] ;Hit ground
type = SelfState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -20
value = 5100 ;Hit ground

;After Throw
[Statedef 828]
type = A
movetype = H
physics = N
velset = -5,-6.5
poweradd = 100
sprpriority = -3

[State 825, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 819

[State 825]
type = angleadd
trigger1 = Alive = 0
trigger1 = animelem = 2,>= 0
trigger1 = time < 31
value = 15

[State 825]
type = angleset
trigger1 = Alive = 0
trigger1 = time >= 31
value = 0

[State 825]
type = angleDraw
trigger1 = Alive = 0
trigger1 = animelem = 2,>= 0
trigger1 = time < 31

[State 825] ;Gravity
type = VelAdd
Trigger1 = 1
y = .5

[State 865, 2] ; Recover near ground (use ChangeState)
type = selfState
trigger1 = animtime = 0 && alive = 1
value = 5040 ;HITFALL_RECOVER

[State 825] ;Hit ground
type = SelfState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -10
value = 5100 ;Hit ground

;===========<BOTTOM GRIP>==========
[StateDef 810]
type = S
physics = S
moveType = A
anim = 820
ctrl = 0
velset = 0,0
sprpriority = 1

[State 820, Lost Target]
type = ChangeState
trigger1 = !Time && !NumTarget
value = 0
ctrl = 1

[State 820, Tech Hit]
type = ChangeState
trigger1 = NumTarget && var(19)
trigger1 = (Target, command = "holdfwd" || Target, command = "holdback")
trigger1 = (Target, command = "b" || Target, command = "c" || Target, command = "y" || Target, command = "z")
value = 890

[State 820, Throw Escape]
type = VarAdd
trigger1 = var(19) > 0
var(19) = -1

[State 820, TargetState]
type = TargetState
trigger1 = !Time && NumTarget
value = 815

[State 910]
type = PosAdd
trigger1 = time = 0
trigger1 = backedgebodydist <= 40
x = 80

[State 910]
type = targetbind
trigger1 = animelem = 1,>= 0
trigger1 = animelem = 2,< 0
trigger2 = animelem = 3,>= 0
trigger2 = animelem = 4,< 0
pos = 60,-75

[State 910]
type = targetbind
trigger1 = animelem = 2,>= 0
trigger1 = animelem = 3,< 0
pos = 70,-75

[State 910]
type = targetbind
trigger1 = animelem = 4,>= 0
trigger1 = animelem = 5,< 0
pos = 10,-75

[State 910]
type = targetbind
trigger1 = animelem = 5,>= 0
trigger1 = animelem = 6,< 0
pos = -40,-70

[State 910]
type = targetbind
trigger1 = animelem = 6,>= 0
trigger1 = animelem = 7,< 0
pos = 30,-75

[State 910]
type = targetbind
trigger1 = animelem = 7,>= 0
trigger1 = animelem = 8,< 0
pos = 85,-75

[State 910]
type = targetbind
trigger1 = animelem = 8
pos = 85,-75

[State 910]
type = sprpriority
trigger1 = animelem = 6
value = -2

[State 910]
type = sprpriority
trigger1 = animelem = 8
value = 2

[State 820, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 8
value = floor(ifElse(120 * fvar(11) < 7, -7, -120 * fvar(11)))

[State 820, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 8
value = 36

[State 820, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 8 && !var(20)
value = 72

[State 820, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 8
value = 1

[State 820, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 8
var(13) = 1

[State 820, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 8
var(15) = 1
ignoreHitPause = 1

[State 820, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 8
var(16) = 1
ignoreHitPause = 1

[State 910]
type = PlaySnd
trigger1 = animelem = 5
value = 820,0

[State 820, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;===========<BOTTOM GRIP (TARGET)>==========
;Being Hit
[StateDef 815]
type = A
moveType = H
physics = N
velSet = 0,0
sprPriority = 0

[State 825, Turn]
type = Turn
trigger1 = NumEnemy
trigger1 = Facing = EnemyNear, Facing
ignoreHitPause = 1

[State 825, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time
value = 825

[State 825, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1
moveCamera = 1,0
ignoreHitPause = 1

[State 920, 1]
type = Velset
Trigger1 = animelem = 9
x = -8
y = -5

[State 920, 1]
type = VelAdd
Trigger1 = animelem = 9 ,>= 0
y = .4

[State 920, 2]
type = ChangeState
triggerall = Vel Y > 0
triggerall = Pos Y >= -50
triggerall = alive
triggerall = CanRecover
triggerall = animelem = 11, >= 0
trigger1 = Command = "recovery"
value = 5200 ;HITFALL_RECOVER

[State 920, 3]
type = SelfState
triggerall = Vel Y > -30
triggerall = alive
triggerall = CanRecover
triggerall = animelem = 11, >= 0
trigger1 = Command = "recovery"
value = 5210 ;HITFALL_AIRRECOVER

[State 920, 4]
type = SelfState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -30
value = 5100 ;Hit ground

;===========<JAR SLUGGER>==========
[Statedef 830]
type = S
physics = N
moveType = A
anim = 830
ctrl = 0
velSet = 0,0
sprPriority = 1

[State 810, Lost Target]
type = ChangeState
trigger1 = !Time && !NumTarget
value = 0
ctrl = 1

[State 810, Tech Hit]
type = ChangeState
trigger1 = NumTarget && var(19)
trigger1 = (Target, command = "holdfwd" || Target, command = "holdback")
trigger1 = (Target, command = "b" || Target, command = "c" || Target, command = "y" || Target, command = "z")
value = 890

[State 810, Throw Escape]
type = VarAdd
trigger1 = var(19) > 0
var(19) = -1

[State 810, Throw]
type = TargetState
trigger1 = !Time && NumTarget
value = 835

[State 805]
type = Helper
trigger1 = time = 0
stateno = 2700
id = 2700
pos = 0,9999
postype = p1
ownpal = 1
sprpriority = -2
keyctrl = 1

[State 855]
type = varset
trigger1 = time = 0
var(5) = 0

[State 855]
type = varset
trigger1 = command = "Throw"
var(5) = 1

[State 855]
type = changestate
trigger1 = animelem = 5,<= 0
trigger1 = var(5) = 1
value = 840

[State 855]
type = posadd
trigger1 = time = 1
trigger1 = frontedgebodydist <= 60
x = -70

[State 855]
type = targetBind
trigger1 = animelem = 1
pos = 40,-80

[State 855]
type = targetBind
trigger1 = animelem = 2
pos = 135,-95

[State 855]
type = targetBind
trigger1 = animelem = 3
pos = 70,-90

[State 855]
type = targetBind
trigger1 = animelem = 4
pos = 50,-95

[State 855]
type = targetBind
trigger1 = animelem = 5
pos = 65,-95

[State 855]
type = targetBind
trigger1 = animelem = 6
pos = 50,-70

[State 855]
type = targetBind
trigger1 = animelem = 7
trigger2 = animelem = 8
pos = 50,-75

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 8
value = floor(ifElse(20 * fvar(11) < 7, -7, -20 * fvar(11)))
Kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 8
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 8 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 8
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 5
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 8
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 8
var(16) = 1
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 8
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(50 * const(size.xScale)), ceil(-75 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 855]
type = PlaySnd
trigger1 = animelem = 8
value = 2,2

[State 855]
type = ChangeState
Trigger1 = AnimTime = 0
value = 831

;===========<JAR SLUGGER>==========
[Statedef 831]
type = S
movetype = A
physics = N
anim = 831
poweradd = 0
sprpriority = -2

[State 856]
type = TargetState
Trigger1 = Time = 0
value = 836

[State 853]
type = VarAdd
trigger1 = 1
var(12) = -1
persistent = 0

[State 856]
type = Changestate
triggerall = prevstateno = 830 && var(14) != 0
triggerall = fvar(19) < 4 && Animelem = 1
trigger1 = fvar(19) != fvar(20)
value = 832;2 + var(14)
persistent = 0

[State 856]
type = Changestate
triggerall = prevstateno != 830 && var(14) != 0
triggerall = fvar(19) < 4 && Animelem = 1
trigger1 = fvar(19) != fvar(20)
value = 832;2 + var(14)
persistent = 0

[State 856]
type = targetBind
trigger1 = animelem = 1
pos = 65,-95

[State 856]
type = targetBind
trigger1 = animelem = 2
pos = 50,-70

[State 856]
type = targetBind
trigger1 = animelem = 3
trigger2 = animelem = 4
pos = 57,-69

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 4
value = floor(ifElse(15 * fvar(11) < 7, -7, -15 * fvar(11)))

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 4
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 4 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 4
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 4
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 4
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 4
var(16) = 1
ignoreHitPause = 1

[State 811]
type = PlaySnd
trigger1 = animelem = 4
value = 2,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 4
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(50 * const(size.xScale)), ceil(-75 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 856]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) <= 0
value = 833

[State 856]
type = ChangeState
triggerall = AnimTime = 0
trigger1 = var(12) > 0
trigger2 = fvar(19) != fvar(20)
value = 831

;===========<JAR SLUGGER>==========
[Statedef 833]
type = S
movetype = A
physics = N
anim = 832
poweradd = 0
sprpriority = -2

[State 857]
type = targetBind
trigger1 = animelem = 1
pos = 50,-60

[State 857]
type = targetstate
trigger1 = animelem = 1
value = 837

[State 857]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;===========<JAR SLUGGER>==========
[Statedef 832]
type = S
movetype = A
physics = N
anim = 833
poweradd = 0
sprpriority = -2

[State 853]
type = changeanim
Trigger1 = Time = 0
value = 833

[State 853]
type = TargetState
Trigger1 = Time = 0
value = 836

[State 853]
type = null;VarAdd
trigger1 = 1
var(12) = -1
persistent = 0

[State 853]
type = targetBind
trigger1 = animelem = 1
pos = 65,-95

[State 853]
type = targetBind
trigger1 = animelem = 2
pos = 50,-70

[State 853]
type = targetBind
trigger1 = animelem = 3
trigger2 = animelem = 4
pos = 57,-69

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 4
value = floor(ifElse(15 * fvar(11) < 7, -7, -15 * fvar(11)))
Kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 4
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 4 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 4
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 4
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 4
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 4
var(16) = 1
ignoreHitPause = 1

[State 853]
type = PlaySnd
trigger1 = animelem = 4
value = 2,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 4
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(50 * const(size.xScale)), ceil(-75 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 853]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) > 0
value = 831

[State 853]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) <= 0
value = 833

;===========<JAR SLUGGER (TARGET)>==========
;Being Thrown
[Statedef 835]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = 1

[State 860, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 835

[STate 860]
type = screenbound
trigger1 = 1
value = 0

;After Throw
[Statedef 836]
type    = A
movetype= H
physics = N
velset = 0,0
sprpriority = 1

[State 861]
type = ChangeAnim2
Trigger1 = Time = 0
value = 836

[STate 861]
type = screenbound
trigger1 = 1
value = 0

[State 865]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 870

;After Throw
[Statedef 837]
type = A
movetype = H
physics = N
velset = -5,-6.5
poweradd = 100
sprpriority = 1

[State 865, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 837

[State 865, 1] ;Gravity
type = VelAdd
Trigger1 = 1
y = .5

[State 865, 2] ; Recover near ground (use ChangeState)
type = ChangeState
triggerall = Vel Y > 0
triggerall = Pos Y >= -40
triggerall = alive
triggerall = CanRecover
triggerall = animelem = 4, >= 0
trigger1 = Command = "recovery"
value = 5200 ;HITFALL_RECOVER

[State 865, 3] ; Recover in mid air (use SelfState)
type = SelfState
triggerall = Vel Y > 0
triggerall = alive
triggerall = CanRecover
triggerall = animelem = 4, >= 0
trigger1 = Command = "recovery"
value = 5210 ;HITFALL_AIRRECOVER

[State 865, 4] ;Hit ground
type = SelfState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -20
value = 5100 ;Hit ground

;===========<GRAVITON KNUCKLE>==========
[Statedef 840]
type = A
physics = N
moveType = A
anim = 840
ctrl = 0
velSet = 0,0
sprPriority = 1

[State 810, Lost Target]
type = ChangeState
trigger1 = !Time && !NumTarget
value = 0
ctrl = 1

[State 810, Tech Hit]
type = ChangeState
trigger1 = NumTarget && var(19)
trigger1 = (Target, command = "holdfwd" || Target, command = "holdback")
trigger1 = (Target, command = "b" || Target, command = "c" || Target, command = "y" || Target, command = "z")
value = 890

[State 810, Throw Escape]
type = VarAdd
trigger1 = var(19) > 0
var(19) = -1

[State 810, Throw]
type = TargetState
trigger1 = !Time && NumTarget
value = 845

[State 1610]
type = SprPriority
trigger1 = animelem = 2
value = 2

[State 1610]
type = width
trigger1 = animelem = 7, <= 0
value = 40,0

[State 1610]
type = targetBind
trigger1 = animelem = 1, >= 0
trigger1 = animelem = 2, < 0
pos = 59,-97

[State 1610]
type = targetBind
trigger1 = animelem = 2, >= 0
trigger1 = animelem = 3, < 0
pos = 20,-74

[State 1610]
type = targetBind
trigger1 = animelem = 3, >= 0
trigger1 = animelem = 4, < 0
pos = -35,-94

[State 1610]
type = targetBind
trigger1 = animelem = 4, >= 0
trigger1 = animelem = 5, < 0
pos = -3,-133

[State 1610]
type = targetBind
trigger1 = animelem = 5, >= 0
trigger1 = animelem = 6, < 0
pos = 77,-24

[State 1610]
type = targetBind
trigger1 = animelem = 6, >= 0
trigger1 = animelem = 7, < 0
pos = 83,-11

[State 1610]
type = targetBind
trigger1 = animelem = 7
pos = 79,-15

[State 1610]
type = VelSet
trigger1 = animelem = 3
x = 3
y = -10

[State 1610]
type = Veladd
trigger1 = animelem = 3, >= 0
trigger1 = animelem = 6, < 0
y = .66

[State 1610]
type = VelSet
trigger1 = animelem = 6
x = 0
y = 0

[State 1610]
type = posSet
trigger1 = animelem = 6
y = 0

[State 1610]
type = PlaySnd
trigger1 = animelem = 4
value = 4,3
volume = 0

[State 1610]
type = PlaySnd
trigger1 = animelem = 6
value = 820,2
volume = 0

[State 1610]
type = VelSet
trigger1 = animelem = 8
x = -3
y = -8

[State 1610]
type = Veladd
trigger1 = animelem = 8, >= 0
y = .5

[State 1610]
type = EnvShake
trigger1 = animelem = 6
ampl = -8
time = 15

[State 871, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && Animelem = 6
value = floor(ifElse(150 * fvar(11) < 7, -7, -150 * fvar(11)))
kill = 1

[State 871, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && Animelem = 6
value = 36

[State 871, Power]
type = PowerAdd
trigger1 = NumTarget && Animelem = 6 && !var(20)
value = 72

[State 871, HitAdd]
type = HitAdd
trigger1 = NumTarget && Animelem = 6
value = 1

[State 871, HitCount]
type = VarAdd
trigger1 = NumTarget && Animelem = 6
var(13) = 1

[State 871, Juggle]
type = VarAdd
trigger1 = NumTarget && Animelem = 6
var(15) = 1
ignoreHitPause = 1

[State 871, Juggle]
type = VarSet
trigger1 = NumTarget && Animelem = 6
var(16) = 1
ignoreHitPause = 1

[State 871, Impact Dust]
type = Helper
trigger1 = Animelem = 6
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
pos = ceil(82 * const(size.xScale)), ceil(-5 * const(size.yScale))
posType = P1
facing = -1
ownPal = 1

[State 871, Hit Spark]
type = Helper
trigger1 = Animelem = 6
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(54 * const(size.xScale)), ceil(-21 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1610]
type = Explod
trigger1 = Animelem = 6
anim = 841
id = 841
pos = 54,-21
postype = p1
sprpriority = 4
vel = 0,-5
removeongethit = 1

[State 1610]
type = Explod
trigger1 = Animelem = 6
anim = 841
id = 841
pos = 54,-21
postype = p1
sprpriority = 4
vel = 5,0
removeongethit = 1

[State 1610]
type = Explod
trigger1 = Animelem = 6
anim = 841
id = 841
pos = 54,-21
postype = p1
sprpriority = 4
vel = -5,0
removeongethit = 1

[State 1610]
type = Explod
trigger1 = Animelem = 6
anim = 841
id = 841
pos = 54,-21
postype = p1
sprpriority = 4
vel = 4,-4
removeongethit = 1

[State 1610]
type = Explod
trigger1 = Animelem = 6
anim = 841
id = 841
pos = 54,-21
postype = p1
sprpriority = 4
vel = -4,-4
removeongethit = 1

[State 1610]
type = ChangeState
trigger1 = pos Y >= 0 && vel Y > 0
value = 52

;===========<GRAVITON KNUCKLE (TARGET)>==========
;In Air
[Statedef 845]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 2

[State 1620]
type = ChangeAnim2
trigger1 = time = 0
value = 845

[State 1620]
type = ChangeAnim2
Triggerall = Time = 0
trigger1 = name = "Tin's Victor"
value = 846

[State 1620]
type = SprPriority
trigger1 = animelem = 2
value = -2

[State 1620]
type = VelSet
trigger1 = animelem = 7
x = -2
y = -6

[State 1620]
type = Veladd
trigger1 = animelem = 7, >= 0
y = .4

[State 1620]
type = screenbound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1620]
type = SelfState
trigger1 = pos Y >= -10 && vel Y > 0
value = 5100

;===========<AIR THROW ATTEMPT>==========
[StateDef 850]
type = A
physics = N
moveType = A
anim = 850
ctrl = 0
sprPriority = 1
powerAdd = 18 * !var(20)

[State 850, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = 850

[State 850, Tech Hit Reset]
type = VarSet
trigger1 = 1
var(19) = 0

[State 850, Tech Hit]
type = VarSet
trigger1 = NumEnemy
trigger1 = EnemyNear, StateType = A
trigger1 = (EnemyNear, StateNo = [0,999]) && (EnemyNear, StateNo != [100,119]) && (EnemyNear, StateNo != [200,799])
var(19) = 7

[State 850, AttackDist]
type = AttackDist
trigger1 = 1
value = 0

[State 850, HitDef: PP Throw]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 1
trigger1 = !var(38)
attr = A,NT
hitFlag = AF
priority = 1,Miss
getPower = 0,0
givePower = 0,0
sparkNo = -1 + 0 * (var(33) := 0)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 40), var(36) := -50
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
fall = 1
fall.recover = 1
numHits = 0
p1StateNo = 860

[State 850, Voice (Missed)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 800,0
channel = 0

[State 850, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,0
channel = 1

[State 850, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(2) >= 0
moveType = I

[State 850, Gravity]
type = Gravity
trigger1 = Time >= 0

[State 850, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 52

;===========<MEGA THROW>==========
[StateDef 860]
type = A
physics = N
moveType = A
anim = 860
ctrl = 0
sprPriority = 1

[State 860, Lost Target]
type = ChangeState
trigger1 = !Time && !NumTarget
value = 51
ctrl = 1

[State 860, Throw Escape]
type = ChangeState
trigger1 = NumTarget && var(19)
trigger1 = (Target, command = "holdfwd" || Target, command = "holdback")
trigger1 = (Target, command = "b" || Target, command = "c" || Target, command = "y" || Target, command = "z")
value = 892

[State 860, Throw Escape]
type = VarAdd
trigger1 = var(19) > 0
var(19) = -1

[State 860, Turn]
type = Turn
triggerAll = !Time
trigger1 = !AILevel && command = "holdback"
trigger2 = AILevel && BackEdgeDist < FrontEdgeDist

[State 860, TargetState]
type = TargetState
trigger1 = !Time && NumTarget
value = 865

[State 860, TargetFacing]
type = TargetFacing
trigger1 = Time <= 1
value = -1

[State 3015]
type = targetbind
trigger1 = animelem = 1 && animelem = 2, < 0
pos = -77,-111

[State 3015]
type = targetbind
trigger1 = animelem = 2 && animelem = 3, < 0
pos = -25,-149

[State 3015]
type = targetbind
trigger1 = animelem = 3
pos = 116,-4

[State 3015]
type = targetstate
trigger1 = animelem = 3
value = 866

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 3
value = floor(ifElse(150 * fvar(11) < 7, -7, -150 * fvar(11)))

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 3
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 3 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 3
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 3
var(16) = 1
ignoreHitPause = 1

[State 3015]
type = SprPriority
trigger1 = Animelem = 3
value = 2

[State 3015]
type = Explod
trigger1 = Animelem = 1
anim = 3045
id = 3045
pos = 0,0
postype = p1
sprpriority = 3
bindtime = -1
removetime = 11
removeongethit = 1

[State 3015]
type = PlaySnd
trigger1 = animelem = 3
value = 4,2

[State 860, PosFreeze]
type = PosFreeze
trigger1 = AnimElemTime(4) < 0
value = 1

[State 3015]
type = velset
trigger1 = animelem = 4
x = -1.2
y = -8

[State 3015]
type = veladd
trigger1 = animelem = 4, >= 0
y = .5

[State 3015]
type = changestate
trigger1 = pos Y >= 5 && vel Y > 0
value = 1350

;===========<MEGA THROW (TARGET)>==========
;In Air
[StateDef 865]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = 1

[State 3020, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 865

[STate 3020]
type = screenbound
trigger1 = 1
value = 0

;Finish
[Statedef 866]
type = A
physics = N
movetype = H
ctrl = 0
velSet = -4.5,4.5
sprPriority = 0

[State 866, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1
moveCamera = 1,0
ignoreHitPause = 1

[State 866, VelAdd]
type = VelAdd
Trigger1 = 1
y = 0.5

[State 866, EnvShake]
type = EnvShake
trigger1 = pos y > -vel y
time = 14
ampl = -4
freq = 120

[State 866, Recover]
type = SelfState
trigger1 = Alive
trigger1 = command = "recovery"
trigger1 = vel y > 0 && pos y >= const(movement.air.getHit.groundRecover.ground.threshold)
value = 5200

[State 866, End]
type = SelfState
trigger1 = pos y > -vel y
value = 5100

;===========<JAR SLUGGER>==========
[Statedef 870]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 1

[State 870]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 870]
type = ChangeState
trigger1 = command != "x" && command != "y" && command != "z" && command != "a" && command != "b" && command != "c"
value = 871

;===========<JAR SLUGGER>==========
[Statedef 871]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 1

[State 871]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 871]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 872

;===========<JAR SLUGGER>==========
[Statedef 872]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 1

[State 872]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 872]
type = ChangeState
trigger1 = command != "x" && command != "y" && command != "z" && command != "a" && command != "b" && command != "c"
value = 873

;===========<JAR SLUGGER>==========
[Statedef 873]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 1

[State 873]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 873]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 874

;===========<JAR SLUGGER>==========
[Statedef 874]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 1

[State 874]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 874]
type = ChangeState
trigger1 = command != "x" && command != "y" && command != "z" && command != "a" && command != "b" && command != "c"
value = 875

;===========<JAR SLUGGER>==========
[Statedef 875]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 1

[State 875]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 875]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 876

;===========<JAR SLUGGER>==========
[Statedef 876]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 1

[State 876]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 876]
type = ChangeState
trigger1 = command != "x" && command != "y" && command != "z" && command != "a" && command != "b" && command != "c"
value = 877

;===========<JAR SLUGGER>==========
[Statedef 877]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 1

[State 877]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 877]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 878

;===========<JAR SLUGGER>==========
[Statedef 878]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = 1

[State 878]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

;===========<THROW ESCAPED>==========
[StateDef 890]
type = S
physics = N
movetype = I
anim = 5945
ctrl = 0
velset = 0,0
sprPriority = 1

[State 890, TargetBind]
type = TargetBind
trigger1 = !Time && NumTarget
pos = 0,0

[State 890, TargetState]
type = TargetState
trigger1 = !Time && NumTarget
value = 895

[State 890, TargetFacing]
type = TargetFacing
trigger1 = !Time && NumTarget
value = -1

[State 890, PosAdd]
type = PosAdd
trigger1 = !Time
x = 24

[State 890, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 890, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignoreHitPause = 1

[State 890, SprPriority 1]
type = SprPriority
trigger1 = AnimElemTime(6) >= 0
value = 1

[State 890, SprPriority -1]
type = SprPriority
trigger1 = AnimElemTime(2) <= 0
value = -1

[State 890, PosSet]
type = PosSet
trigger1 = !Time
y = 0

[State 890, VelSet]
type = VelSet
trigger1 = 1
x = -1.425
y = 0

[State 890, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 5000,2
channel = 0

[State 890, Escape Sound]
type = PlaySnd
trigger1= !Time
value = 760,0

[State 890, Throw Escape FX]
type = Helper
trigger1 = !Time
helperType = Normal
stateNo = 8000
ID = 8000
name = "Spark"
PosType = P1
pos = 0, -68
facing = -1
ownPal = 1
size.xScale = 0.5
size.yScale = 0.5
pauseMoveTime = 65535
superMoveTime = 65535

[State 890, End]
type = ChangeState
trigger1 = Time >= 27
value = 0
ctrl = 1


;Target Escape
[StateDef 895]
type = S
physics = N
moveType = I
ctrl = 0
velSet = 0,0
sprPriority = 1

[State 895, ChangeAnim]
type = ChangeAnim
trigger1= !Time
value = ifElse(SelfAnimExist(5940), 5940, 130)

[State 895, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && !SelfAnimExist(5945) && SelfAnimExist(5940)
value = 5940

[State 895, ChangeAnim]
type = ChangeAnim
trigger1= !Time && !SelfAnimExist(5945) && !SelfAnimExist(5940) && SelfAnimExist(5910)
value = 5910

[State 895, ChangeAnim]
type = ChangeAnim
trigger1 = Time >= 20 && Anim = 130
value = 140

[State 895, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 895, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignoreHitPause = 1

[State 895, PosSet]
type = PosSet
trigger1 = !Time
y = 0

[State 895, VelSet]
type = VelSet
trigger1 = 1
x = -1.425
y = 0

[State 895, End]
type = SelfState
trigger1 = Time >= 27
value = 0
ctrl = 1



;===========<THROW ESCAPE MIDAIR>==========
[StateDef 892]
type = A
physics = N
moveType = I
anim = 892
ctrl = 0
velSet = 0, 0
sprPriority = 1

[State 892, TargetBind]
type = TargetBind
trigger1 = !Time && NumTarget
pos = 48, 0

[State 892, TargetState]
type = TargetState
trigger1 = !Time && NumTarget
value = 897

[State 892, TargetFacing]
type = TargetFacing
trigger1 = !Time && NumTarget
value = -1

[State 892, PosAdd]
type = PosAdd
trigger1 = !Time
x = 24

[State 892, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 892, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 892, PosFreeze]
type = PosFreeze
trigger1 = Time < 18
value = 1

[State 892, VelSet]
type = VelSet
trigger1 = Time = 18
x = -2
y = -4

[State 892, VelAdd]
type = VelAdd
trigger1 = Time > 18
y = 0.5

[State 892, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 2
value = 5000,2
channel = 0

[State 892, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 760,0

[State 892, Throw Escape FX]
type = Helper
trigger1 = !Time
helperType = Normal
stateNo = 8000
ID = 8000
name = "Spark"
posType = P1
pos = 24,-64
facing = -1
ownPal = 1
size.xScale = 0.5
size.yScale = 0.5
pauseMoveTime = 65535
superMoveTime = 65535

[State 892, ChangeState]
type = ChangeState
trigger1 = vel y > 0
trigger1 = pos y > -vel y
value = 52


;Target Escape
[StateDef 897]
type = A
physics = N
moveType = I
ctrl = 0
velSet = 0, 0
sprPriority = 1

[State 897, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = 152

[State 897, ChangeAnim]
type = ChangeAnim
trigger1 = Time = 18
value = 142

[State 897, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 897, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 897, PosFreeze]
type = PosFreeze
trigger1 = Time < 18
value = 1

[State 897, VelSet]
type = VelSet
trigger1 = Time = 18
x = -2
y = -4

[State 897, VelAdd]
type = VelAdd
trigger1 = Time >= 18
y = 0.5

[State 897, SelfState]
type = SelfState
trigger1 = vel y > 0
trigger1 = pos y > -vel y
value = 52
