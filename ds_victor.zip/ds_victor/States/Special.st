; _________________________________________
;| Victor by varo_hades                    |
; �����������������������������������������
;==============================================================================================
;========================================<SPECIAL MOVES>=======================================
;==============================================================================================

;=====================<GYRO CRUSH>==========================
[StateDef 1000]
type = S
physics = S
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1000, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1020, ifElse(var(10) = 1, 1010, 1000))

[State 1000]
type = PlaySnd
trigger1 = var(10) = 0
trigger1 = Animelem = 2
value = 1, 2

[State 1000]
type = PlaySnd
trigger1 = var(10) = 0
trigger1 = Time = 1
value = 1000, 2

[State 1000]
type = PlaySnd
trigger1 = var(10) = 0
trigger1 = animelem = 1
value = 4,2

[State 1000]
type = palfx
trigger1 = var(10) = 0
trigger1 = animelem = 6, < 0
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 1000]
type = VelSet
trigger1 = var(10) = 0
trigger1 = command = "holdfwd"
trigger1 = Animelem = 5, < 0
x = 1

[State 1000]
type = VelSet
trigger1 = var(10) = 0
trigger1 = command = "holdback"
trigger1 = Animelem = 5, < 0
x = -1

[State 1000]
type = velset
trigger1 = var(10) = 0
trigger1 = command != "holdfwd" && command != "holdback"
trigger2 = Animelem = 5, >= 0
x = 0

[State 1000]
type = Explod
trigger1 = var(10) = 0
trigger1 = NumExplod(3041) = 0
trigger1 = Animelem = 3,>= 0
trigger1 = Animelem = 4, <= 0
anim = 3041
id = 3041
pos = 0,20
postype = p1
sprpriority = 3
vel = 0,1
removetime = 12
removeongethit = 1

[State 1000]
type = Explod
trigger1 = var(10) = 0
trigger1 = NumExplod(3042) = 0
trigger1 = Animelem = 3,>= 0
trigger1 = Animelem = 4, <= 0
anim = 3042
id = 3042
pos = 0,20
postype = p1
sprpriority = 3
vel = 0,1
removeongethit = 1

[State 1000]
type = ReMoveExplod
trigger1 = var(10) = 0
trigger1 = animelem = 5
id = 3041

[State 1000]
type = ReMoveExplod
trigger1 = var(10) = 0
trigger1 = animelem = 5
id = 3042

[State 1010]
type = PlaySnd
trigger1 = var(10) = 1
trigger1 = Animelem = 2
value = 1, 2

[State 1010]
type = PlaySnd
trigger1 = var(10) = 1
trigger1 = Time = 1
value = 2, 7

[State 1010]
type = PlaySnd
trigger1 = var(10) = 1
trigger1 = animelem = 1
value = 1000,0

[State 1010]
type = VelSet
trigger1 = var(10) = 1
trigger1 = command = "holdfwd"
trigger1 = Animelem = 9, < 0
x = 1

[State 1010]
type = VelSet
trigger1 = var(10) = 1
trigger1 = command = "holdback"
trigger1 = Animelem = 9, < 0
x = -1

[State 1010]
type = velset
trigger1 = var(10) = 1
trigger1 = command != "holdfwd" && command != "holdback"
trigger2 = Animelem = 9, >= 0
x = 0

[State 1010]
type = palfx
trigger1 = var(10) = 1
trigger1 = animelem = 9, < 0
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 1010]
type = Explod
trigger1 = var(10) = 1
trigger1 = NumExplod(3041) = 0
trigger1 = Animelem = 3,>= 0
trigger1 = Animelem = 8, <= 0
anim = 3041
id = 3041
pos = 0,20
postype = p1
sprpriority = 3
vel = 0,1
removetime = 12
removeongethit = 1

[State 1010]
type = Explod
trigger1 = var(10) = 1
trigger1 = NumExplod(3042) = 0
trigger1 = Animelem = 3,>= 0
trigger1 = Animelem = 8, <= 0
anim = 3042
id = 3042
pos = 0,20
postype = p1
sprpriority = 3
vel = 0,1
removeongethit = 1

[State 1010]
type = ReMoveExplod
trigger1 = var(10) = 1
trigger1 = animelem = 9
id = 3041

[State 1010]
type = ReMoveExplod
trigger1 = var(10) = 1
trigger1 = animelem = 9
id = 3042

[State 1020]
type = PlaySnd
trigger1 = var(10) = 2
trigger1 = Animelem = 2
value = 1, 2

[State 1020]
type = PlaySnd
trigger1 = var(10) = 2
trigger1 = Time = 1
value = 2, 8

[State 1020]
type = PlaySnd
trigger1 = var(10) = 2
trigger1 = animelem = 1
value = 1000,1

[State 1020]
type = VelSet
trigger1 = var(10) = 2
trigger1 = command = "holdfwd"
trigger1 = Animelem = 13, < 0
x = 1

[State 1020]
type = VelSet
trigger1 = var(10) = 2
trigger1 = command = "holdback"
trigger1 = Animelem = 13, < 0
x = -1

[State 1020]
type = velset
trigger1 = var(10) = 2
trigger1 = command != "holdfwd" && command != "holdback"
trigger2 = Animelem = 13, >= 0
x = 0

[State 1020]
type = palfx
trigger1 = var(10) = 2
trigger1 = animelem = 13, < 0
trigger1 = gametime%7 = 0
add=10,110,185
mul=10,110,255
time = 3
ignorehitpause = 1

[State 1020]
type = Explod
trigger1 = var(10) = 2
trigger1 = NumExplod(3041) = 0
trigger1 = Animelem = 3,>= 0
trigger1 = Animelem = 12, <= 0
anim = 3041
id = 3041
pos = 0,20
postype = p1
sprpriority = 3
vel = 0,1
removetime = 12
removeongethit = 1

[State 1020]
type = Explod
trigger1 = var(10) = 2
trigger1 = NumExplod(3042) = 0
trigger1 = Animelem = 3,>= 0
trigger1 = Animelem = 12, <= 0
anim = 3042
id = 3042
pos = 0,20
postype = p1
sprpriority = 3
vel = 0,1
removeongethit = 1

[State 1020]
type = ReMoveExplod
trigger1 = var(10) = 2
trigger1 = animelem = 13
id = 3041

[State 1020]
type = ReMoveExplod
trigger1 = var(10) = 2
trigger1 = animelem = 13
id = 3042

[State 1000, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 0
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 130 < 7, 7, fvar(11) * 130)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 1
trigger1 = AnimElem = 3
trigger2 = animelem = 5
trigger3 = animelem = 7
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 2
trigger1 = AnimElem = 3
trigger2 = animelem = 5
trigger3 = animelem = 7
trigger4 = animelem = 9
trigger5 = animelem = 11
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(anim = 5, -10, -11), 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX GYRO CRUSH>=============================
[StateDef 1030]
type = S
physics = S
moveType = A
anim = 1030
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 94

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030]
type = PlaySnd
trigger1 = Animelem = 2
value = 1, 2
channel = 2

[State 1030]
type = PlaySnd
trigger1 = Time = 1
value = 2, 8
channel = 3

[State 1030]
type = PlaySnd
trigger1 = animelem = 1
value = 4,3
channel = 4

[State 1030]
type = PlaySnd
trigger1 = animelem = 10
value = 1,6
channel = 5

[State 1030]
type = VelSet
trigger1 = command = "holdfwd"
trigger1 = Animelem = 9, < 0
x = .5

[State 1030]
type = VelSet
trigger1 = command = "holdback"
trigger1 = Animelem = 9, < 0
x = -.5

[State 1030]
type = velset
trigger1 = command != "holdfwd" && command != "holdback"
trigger1 = Animelem = 9, < 0
x = 0

[State 1030]
type = VelSet
trigger1 = Animelem = 9
x = 10

[State 1030]
type = width
trigger1 = 1
value = 20,0

[State 1030]
type = Explod
trigger1 = NumExplod(3041) = 0
trigger1 = Animelem = 3,>= 0
trigger1 = Animelem = 8, <= 0
anim = 3041
id = 3041
pos = 0,20
postype = p1
sprpriority = 3
vel = 0,1
removetime = 12
removeongethit = 1

[State 1030]
type = Explod
trigger1 = NumExplod(3042) = 0
trigger1 = Animelem = 3,>= 0
trigger1 = Animelem = 8, <= 0
anim = 3042
id = 3042
pos = 0,20
postype = p1
sprpriority = 3
vel = 0,1
removeongethit = 1

[State 1030]
type = ReMoveExplod
trigger1 = animelem = 9
id = 3041

[State 1030]
type = ReMoveExplod
trigger1 = animelem = 9
id = 3042

[State 1030]
type = Helper
trigger1 = Animelem = 9
stateno = 1035
id = 1035
pos = 59,-80
postype = p1
ownpal = 1
sprpriority = 5

[State 1030, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 42 < 7, 7, fvar(11) * 42)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1030, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem = 5
trigger2 = animelem = 7
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 42 < 7, 7, fvar(11) * 42)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1030]
type = movehitreset
trigger1 = Animelem = 9

[State 1030, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem = 10
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 42 < 7, 7, fvar(11) * 42)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, -5.5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -4.5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
Air.fall = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 8)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1030]
type = TargetState
trigger1 = AnimElem = 10,>= 0
trigger1 = Movehit
trigger1 = enemy,prevstateno != 1040
;trigger1 = enemy,stateno != 1040
value = 1040
persistent = 0
ignorehitpause = 1

[State 1030, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;Helper
[Statedef 1035]
type = A
movetype = I
physics = N
ctrl = 0
velset = 11,0
anim = 242
sprpriority = 5

[State 1035]
type = Explod
trigger1 = time = 0
anim = 242
id = 1035
pos = -20,0
postype = p1
sprpriority = 4
facing = 1
vel = 10,0
scale = .8,.8
ownpal = 1
removeongethit = 1

[State 1035]
type = Explod
trigger1 = time = 0
anim = 242
id = 1035
pos = -40,0
postype = p1
sprpriority = 3
facing = 1
vel = 8,0
scale = .6,.6
ownpal = 1
removeongethit = 1

[State 1035]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 1030

;Player 2
[statedef 1040]
type = A
movetype = H
velset = 0,0
ctrl = 0

[STate 1040]
type=ChangeAnim2
trigger1 = Time = 0
value = 1392

[State 1040]
type = NotHitBy
trigger1 = enemy,stateno != [1020,1030]
value = SAC

[State 1040]
type = velset
trigger1 = animelem = 2
x = -2
y = -7

[State 1040]
type = veladd
trigger1 = animelem = 2, >= 0
y = .4

[State 1040]
type = selfstate
trigger1 = pos Y >= 15 && vel Y > 0
value = 5100

;========================<MEGA FOREHEAD>=============================
[StateDef 1100]
type = S
physics = S
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1100, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1120, ifElse(var(10) = 1, 1110, 1100))

[State 1100]
type = PlaySnd
trigger1 = animelem = 4
value = 1, 2

[State 1100]
type = PlaySnd
trigger1 = animelem = 4
value = 4,3

[State 1100]
type = velset
trigger1 = var(10) = 0
trigger1 = animelem = 5
x = 7

[State 1100]
type = velset
trigger1 = var(10) = 1
trigger1 = animelem = 5
x = 12

[State 1100]
type = velset
trigger1 = var(10) = 2
trigger1 = animelem = 5
x = 16

[State 110, Dust Helper]
type = Helper
trigger1 = AnimElem = 5
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1100]
type = Explod
trigger1 = NumExplod(3042) = 0
trigger1 = Animelem = 5
anim = 3042
id = 3042
pos = 50,-10
postype = p1
sprpriority = 3
bindtime = -1
removeongethit = 1

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 150, ifElse(var(10), 140, 130)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 150, ifElse(var(10), 140, 130)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -90
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX MEGA FOREHEAD>=============================
[StateDef 1130]
type = S
physics = S
moveType = A
anim = 1130
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1130, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1130, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1130, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 91

[State 1130, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1130, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1130]
type = PlaySnd
trigger1 = animelem = 4
value = 1, 2
channel = 2

[State 1130]
type = PlaySnd
trigger1 = animelem = 4
value = 4,3
channel = 3

[State 1130]
type = velset
trigger1 = animelem = 5
x = 16

[State 110, Dust Helper]
type = Helper
trigger1 = AnimElem = 5
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1100]
type = Explod
trigger1 = NumExplod(3042) = 0
trigger1 = Animelem = 5
anim = 3042
id = 3042
pos = 50,-10
postype = p1
sprpriority = 3
bindtime = -1
removeongethit = 1

[State 1130, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 5
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -90
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 7
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -90
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = AnimElem = 8
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -3
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -3
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -90
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<MEGA STAKE>=============================
[StateDef 1200]
type = S
physics = N
moveType = A
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1100, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1220, ifElse(var(10) = 1, 1210, 1200))

[State 1200]
type = PlaySnd
trigger1 = animelem = 5
value = 1000,0
volume = 0

[State 1200]
type = PlaySnd
trigger1 = Animelem = 6
value = 2, 7

[State 1200]
type = StateTypeSet
trigger1 = animelem = 2
statetype = A

[State 1200]
type = VelSet
trigger1 = var(10) = 0
trigger1 = animelem = 2
x = 3
y = -8

[State 1200]
type = VelSet
trigger1 = var(10) = 1
trigger1 = animelem = 2
x = 3
y = -9

[State 1200]
type = VelSet
trigger1 = var(10) = 2
trigger1 = animelem = 2
x = 3
y = -10

[State 1200]
type = Veladd
trigger1 = var(10) = 0
trigger1 = animelem = 2,>= 0
trigger1 = animelem = 7,< 0
y = .5

[State 1200]
type = Veladd
trigger1 = var(10) = 1
trigger1 = animelem = 2,>= 0
trigger1 = animelem = 7,< 0
y = .53

[State 1200]
type = Veladd
trigger1 = var(10) = 2
trigger1 = animelem = 2,>= 0
trigger1 = animelem = 7,< 0
y = .6

[State 1200]
type = VelSet
trigger1 = animelem = 7
x = 0
y = 0

[State 1200]
type = VelSet
trigger1 = animelem = 14
x = -1.5
y = -5

[State 1200]
type = Veladd
trigger1 = animelem = 14,>= 0
y = .5

[State 1200]
type = Helper
trigger1 = Animelem = 6
stateno = 1250
id = 1250
pos = 0,0
postype = p1
ownpal = 1
sprpriority = 3

[State 40, Dust Helper]
type = Helper
trigger1 = Animelem = 2
helperType = Normal
stateNo = 8100
ID = 8100
name = "Jump Dust"
posType = P1
ownPal = 1

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 6
attr = A, SA
hitFlag = FD
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 155, ifElse(var(10), 145, 135)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 155, ifElse(var(10), 145, 135)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 7 && !MoveContact
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 155, ifElse(var(10), 145, 135)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 155, ifElse(var(10), 145, 135)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1200]
type = TargetState
trigger1 = Movehit && enemy,stateno != 2650 && enemy,stateno != 1540
value = 2650
persistent = 0
ignorehitpause = 1

[State 1200]
type = ChangeState
trigger1 = pos Y >= 0 && vel Y > 0
value = 1350

;========================<EX MEGA STAKE>=============================
[StateDef 1230]
type = S
physics = N
moveType = A
anim = 1230
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1230, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1230, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1230, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 91

[State 1230, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1230, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1230]
type = PlaySnd
trigger1 = animelem = 5
value = 1000,1
volume = 0
channel = 0

[State 1230]
type = PlaySnd
trigger1 = Animelem = 6
value = 2, 8
channel = 3

[State 1230]
type = StateTypeSet
trigger1 = animelem = 2
statetype = A

[State 1230]
type = VelSet
trigger1 = animelem = 2
x = 3
y = -10

[State 1230]
type = Veladd
trigger1 = animelem = 2,>= 0
trigger1 = animelem = 7,< 0
y = .66

[State 1230]
type = VelSet
trigger1 = animelem = 7
x = 0
y = 0

[State 1230]
type = VelSet
trigger1 = animelem = 14
x = -1.5
y = -5

[State 1230]
type = Veladd
trigger1 = animelem = 14,>= 0
y = .5

[State 1230]
type = Helper
trigger1 = Animelem = 6
stateno = 1250
id = 1250
pos = 0,0
postype = p1
ownpal = 1
sprpriority = 3

[State 40, Dust Helper]
type = Helper
trigger1 = Animelem = 2
helperType = Normal
stateNo = 8100
ID = 8100
name = "Jump Dust"
posType = P1
ownPal = 1

[State 1130, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 5
attr = A, SA
hitFlag = FD
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 58 < 7, 7, fvar(11) * 58)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
Air.Fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, HitDef 2]
type = HitDef
triggerall = HitCount < 3
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = animelem = 7
trigger2 = animelem = 8
trigger3 = animelem = 9
trigger4 = animelem = 10
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 58 < 7, 7, fvar(11) * 58)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
Air.Fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1230]
type = TargetState
triggerall = Movehit
trigger1 = Hitcount = 1
value = 2630
persistent = 0
ignorehitpause = 1

[State 1230]
type = TargetState
triggerall = Movehit
trigger1 = Hitcount = 2
value = 2630
persistent = 0
ignorehitpause = 1

[State 1230]
type = TargetState
triggerall = Movehit
trigger1 = Hitcount = 3
value = 2630
persistent = 0
ignorehitpause = 1

[State 1230]
type = ChangeState
trigger1 = pos Y >= 0 && vel Y > 0
value = 1350

;========================<MEGA STAKE EFFECT>=============================
[Statedef 1250]
type = A
movetype = I
physics = N
ctrl = 0
velset = 0,0
anim = 1250
sprpriority = 3

[State 1250]
type = BindToParent
trigger1 = 1
pos = 0,0

[State 1250]
type = DestroySelf
trigger1 = Root,Movetype = H
trigger2 = root,Animelem = 11

;========================<GIGA BURN>=============================
[StateDef 1300]
type = S
physics = N
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1300, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "c" || command = "rlsc"), 2, ifElse((command = "b" || command = "rlsb"), 1, 0))

[State 1300, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1300, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1320, ifElse(var(10) = 1, 1310, 1300))

[State 1300, 1]
type = PlaySnd
trigger1 = animelem = 2
value = 1000,0

[State 1300]
type = velset
trigger1 = var(10) = 0
trigger1 = animelem = 3
x = 4.7
y = -8.6

[State 1300]
type = velset
trigger1 = var(10) = 1
trigger1 = animelem = 3
x = 6
y = -10

[State 1300]
type = velset
trigger1 = var(10) = 2
trigger1 = animelem = 3
x = 7
y = -13

[State 1300]
type = veladd
trigger1 = var(10) = 0
trigger1 = animelem = 3,>=0
y = .66

[State 1300]
type = veladd
trigger1 = var(10) = 1
trigger1 = animelem = 3,>=0
y = .9

[State 1300]
type = veladd
trigger1 = var(10) = 2
trigger1 = animelem = 3,>=0
y = .95

[State 1300]
type = velset
trigger1 = animelem = 5
y = 2

[State 1300]
type = statetypeset
trigger1 = animelem = 3
value = A

[State 1300]
type = statetypeset
trigger1 = animelem = 5
physics = S

[State 40, Dust Helper]
type = Helper
trigger1 = Animelem = 3
helperType = Normal
stateNo = 8100
ID = 8100
name = "Jump Dust"
posType = P1
ownPal = 1

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 155, ifElse(var(10), 145, 135)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 155, ifElse(var(10), 145, 135)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1300, 4]
type = ChangeState
trigger1 = pos Y >= 0
trigger1 = vel Y > 0
value = 1350

;========================<EX GIGA BURN>=============================
[StateDef 1330]
type = S
physics = N
moveType = A
anim = 1330
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1330, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1330, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1330, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 91

[State 1330, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1330, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1330, 1]
type = PlaySnd
trigger1 = animelem = 2
value = 1000,1
channel = 0

[State 1330]
type = velset
trigger1 = animelem = 3
x = 8.6
y = -13

[State 1330]
type = veladd
trigger1 = animelem = 3,>=0
y = .95

[State 1330]
type = velset
trigger1 = animelem = 6
y = 0

[State 1330]
type = statetypeset
trigger1 = animelem = 3
value = A

[State 1330]
type = statetypeset
trigger1 = animelem = 4
physics = S

[State 40, Dust Helper]
type = Helper
trigger1 = Animelem = 3
helperType = Normal
stateNo = 8100
ID = 8100
name = "Jump Dust"
posType = P1
ownPal = 1

[State 1330, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 3
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 58 < 7, 7, fvar(11) * 58)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1330, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 4
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 58 < 7, 7, fvar(11) * 58)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2, -5
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1330]
type = MoveHitReSet
trigger1 = Animelem = 4

[State 1330, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 5
attr = A, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 58 < 7, 7, fvar(11) * 58)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2, -3
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1330]
type = TargetState
trigger1 = AnimElem = 6,>= 0
trigger1 = Movehit
trigger1 = enemy,stateno != 1391
value = 1391
persistent = 0
ignorehitpause = 1

[State 1330, 4]
type = ChangeState
trigger1 = pos Y >= 0
trigger1 = vel Y > 0
value = 1350

;========================<GIGA BURN LANDING>=============================
[Statedef 1350]
type = S
movetype = A
physics = S
poweradd = 0
ctrl = 0
velset = 0,0
anim = 1350
sprpriority = 2

[State 1350]
type = posset
trigger1 = time = 0
y = 0

[State 1350]
type = afterimagetime
trigger1 = time = 0
time = 0

[State 52, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0

[State 52, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
pos = ceil(0 * const(size.xScale)),-5
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1350]
type = ctrlset
trigger1 = time = 2
value = 1

[State 1310, 4]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;========================<GIGA BURN PLAYER 2>=============================
[statedef 1391]
type = A
movetype = H
velset = 0,0

[STate 1391]
type=ChangeAnim2
trigger1 = Time = 0
value = 1391

[State 1391]
type = NotHitBy
trigger1 = enemy,stateno != [1020,1030]
value = SAC

[State 1391]
type = velset
trigger1 = animelem = 2
x = -2
y = -5

[State 1391]
type = veladd
trigger1 = animelem = 2, >= 0
y = .4

[State 1391]
type = selfstate
trigger1 = pos Y >= 15 && vel Y > 0
value = 5100

;========================<MEGA SPIKE>=============================
[StateDef 1400]
type = S
physics = S
moveType = A
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1400, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall = P2stateno != 40
triggerall = P2stateno != [120,153]
triggerall = enemy,movetype != H
Trigger1 = animelem = 1
attr = S, ST
hitflag = M-
priority = 7, Miss
sparkno = -1
sprpriority = 1
p1facing = 1
p2facing = 1
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 1410
p2stateno = 1415
numhits = 0

[State 1400]
type = playsnd
trigger1 = animelem = 3
value = 800,0

[State 1400, 2]
type = ChangeState
Trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<MEGA SPIKE CONECT>=============================
[Statedef 1410]
type = S
movetype = A
physics = N
juggle = 0
velset = 0,0
ctrl = 0
anim = 1410
sprpriority = 2
poweradd = 100

[State 1410]
type = posadd
trigger1 = animelem = 1
trigger1 = frontedgebodydist <= 50
x = -50

[State 1410]
type = width
trigger1 =1
value = 30,30

[State 1410]
type = targetbind
trigger1 = animelem = 1
pos = 40,-60

[State 1410]
type = targetbind
trigger1 = animelem = 2
pos = 100,-80

[State 1410]
type = targetbind
trigger1 = animelem = 3
pos = 40,-60

[State 1410]
type = targetbind
trigger1 = animelem = 4
pos = 85,-90

[State 1410]
type = targetbind
trigger1 = animelem = 5
pos = 60,-80

[State 1410]
type = targetbind
trigger1 = animelem = 6
pos = 40,-80

[State 1410]
type = velset
trigger1 = animelem = 12
x = .5
y = -18

[State 1410]
type = veladd
trigger1 = animelem = 12,>= 0
y = .9

[State 1410]
type = null;targetbind
trigger1 = animelem = 14
pos = 70,-15

[State 871, Hit Spark]
type = Helper
trigger1 = Animelem = 6
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(40 * const(size.xScale)), ceil(-80 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = Animelem = 14
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(70 * const(size.xScale)), ceil(-15 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Damage]
type = TargetLifeAdd
trigger1 = animelem = 6
value = floor(ifElse(50 * fvar(11) < 7, -7, -50 * fvar(11)))

[State 871, Damage]
type = TargetLifeAdd
trigger1 = animelem = 14
value = floor(ifElse(130 * fvar(11) < 7, -7, -130 * fvar(11)))
kill = 1

[State 871, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = animelem = 6
trigger2 = animelem = 14
value = 36

[State 871, Power]
type = PowerAdd
trigger1 = animelem = 6 && !var(20)
trigger2 = animelem = 14 && !var(20)
value = 72

[State 871, HitAdd]
type = HitAdd
trigger1 = animelem = 6
trigger2 = animelem = 14
value = 1

[State 871, HitCount]
type = VarAdd
trigger1 = animelem = 6
trigger2 = animelem = 14
var(13) = 1

[State 871, Juggle]
type = VarAdd
trigger1 = animelem = 6
trigger2 = animelem = 14
var(15) = 1
ignoreHitPause = 1

[State 871, Juggle]
type = VarSet
trigger1 = animelem = 6
trigger2 = animelem = 14
var(16) = 1
ignoreHitPause = 1

[State 1410]
type = envshake
trigger1 = animelem = 6
ampl = 6
time = 10

[State 1410]
type = envshake
trigger1 = animelem = 14
ampl = 10
time = 10

[State 1410]
type = targetstate
trigger1 = animelem = 14
value = 1417

[State 1410]
type = targetstate
trigger1 = animelem = 16
value = 1418

[State 1410]
type = velset
trigger1 = animelem = 14
x = 0
y = 0

[State 1410]
type = velset
trigger1 = animelem = 15
x = 1.5

[State 1410]
type = veladd
trigger1 = animelem = 15,>= 0
y = .4

[State 1410]
type = PlaySnd
trigger1 = animelem = 6
value = 1400,0

[State 1410]
type = PlaySnd
trigger1 = animelem = 13
value = 1000,1

[State 1410]
type = PlaySnd
trigger1 = animelem = 6
value = 2,5

[State 1410]
type = PlaySnd
trigger1 = animelem = 14
value = 820,2

[State 1410]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
value = 1350

;========================<MEGA SPIKE PLAYER 2>=============================
[Statedef 1415]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = -1

[State 1420, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1415

[STate 1420]
type = screenbound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1420]
type = velset
trigger1 = animelem = 6
x = -.5
y = -17

[State 1420]
type = veladd
trigger1 = animelem = 6,>= 0
y = .6

[State 1420]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1420]
type = changestate
trigger1 = pos Y>=10 && vel Y>0
value = 1416

;========================<MEGA SPIKE PLAYER 2>=============================
[Statedef 1416]
type = A
movetype = H
physics = N
velset = 0,0

[State 1430, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1416

[State 1430, 1]
type = ChangeAnim2
Triggerall = Time = 0
trigger1 = name = "Tin's Victor"
value = 1417

[State 1430]
type = posset
trigger1 = time = 0
y = -10

[STate 1430]
type = screenbound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1430]
type = velset
trigger1 = animelem = 2
x = -2
y = -14.7

[State 1430]
type = veladd
trigger1 = animelem = 2,>= 0
y = .4

;========================<MEGA SPIKE PLAYER 2>=============================
[Statedef 1417]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = -2

[State 1430, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1416

[State 1430, 1]
type = ChangeAnim2
Triggerall = Time = 0
trigger1 = name = "Tin's Victor"
value = 1417

[State 1435]
type = velset
trigger1 = time = 0
x =0
y = 0

[State 1435]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

;========================<MEGA SPIKE PLAYER 2>=============================
[Statedef 1418]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = 3

[State 1440]
type = velset
trigger1 = time = 0
x = -8
y = 6

[State 1440]
type = veladd
trigger1 = 1
y = .4

[State 1440]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1440]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
value = 1419

;========================<MEGA SPIKE PLAYER 2>=============================
[Statedef 1419]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = -2

[State 1445]
type = posset
trigger1 = time = 0
y = 0

[State 1445]
type = EnvShake
trigger1 = time = 0
ampl = -6
time = 10

[State 1445]
type = velset
trigger1 = time = 10
x = -1.2
y = -6

[State 1445]
type = veladd
trigger1 = time >= 10
y = .5

[State 1445]
type = selfstate
trigger1 = pos Y>=0 && vel Y>0
trigger1 = Alive = 1
value = 5110

[State 1445]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
trigger1 = Alive = 0
value = 1420

;========================<MEGA SPIKE PLAYER 2>=============================
[Statedef 1420]
type = L
movetype = H
physics = N
velset = 0,0
sprpriority = -2

[State 1446]
type = posset
trigger1 = time = 0
y = 0

[State 1445]
type = selfstate
trigger1 = time = 0
value = 5101

;========================<EX MEGA SPIKE>=============================
[StateDef 1430]
type = S
physics = S
moveType = A
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1430, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1430, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1430, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 251

[State 1430, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1430, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1430, 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
triggerall=P2stateno!=40
triggerall=P2stateno!=[120,153]
triggerall = enemy,movetype != H
Trigger1 = animelem = 1
attr = S, ST
hitflag = M-
priority = 7, Miss
sparkno = -1
sprpriority = 1
p1facing = 1
p2facing = 1
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 1440
p2stateno = 1415
numhits = 0

[State 1430]
type = playsnd
trigger1 = animelem = 3
value = 800,0

[State 1430, 2]
type = ChangeState
Trigger1 = AnimTime = 0
value =0
ctrl = 1

;========================<EX MEGA SPIKE CONECT>=============================
[Statedef 1440]
type = S
movetype = A
physics = N
juggle  = 0
velset = 0,0
ctrl = 0
anim = 1410
sprpriority = 2
poweradd = 0

[State 1440]
type = posadd
trigger1 = time = 0
trigger1 = frontedgebodydist <= 100
x = -70

[State 1440]
type = posadd
trigger1 = time = 0
trigger1 = frontedgebodydist <= 50
x = -40

[State 1440]
type = width
trigger1 =1
value = 30,30

[State 1440]
type = targetbind
trigger1 = animelem = 1
pos = 40,-60

[State 1440]
type = targetbind
trigger1 = animelem = 2
pos = 100,-80

[State 1440]
type = targetbind
trigger1 = animelem = 3
pos = 40,-60

[State 1440]
type = targetbind
trigger1 = animelem = 4
pos = 85,-90

[State 1440]
type = targetbind
trigger1 = animelem = 5
pos = 60,-80

[State 1440]
type = targetbind
trigger1 = animelem = 6
pos = 40,-80

[State 1440]
type = velset
trigger1 = animelem = 12
x = 0
y = -18

[State 1440]
type = veladd
trigger1 = animelem = 12,>= 0
y = .9

[State 871, Hit Spark]
type = Helper
trigger1 = Animelem = 6
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(40 * const(size.xScale)), ceil(-80 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = Animelem = 14
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(70 * const(size.xScale)), ceil(-15 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Damage]
type = TargetLifeAdd
trigger1 = animelem = 6
value = floor(ifElse(50 * fvar(11) < 7, -7, -50 * fvar(11)))

[State 871, Damage]
type = TargetLifeAdd
trigger1 = animelem = 14
value = floor(ifElse(100 * fvar(11) < 7, -7, -100 * fvar(11)))

[State 871, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = animelem = 6
trigger2 = animelem = 14
value = 0

[State 871, Power]
type = PowerAdd
trigger1 = animelem = 6 && !var(20)
trigger2 = animelem = 14 && !var(20)
value = 0

[State 871, HitAdd]
type = HitAdd
trigger1 = animelem = 6
trigger2 = animelem = 14
value = 1

[State 871, HitCount]
type = VarAdd
trigger1 = animelem = 6
trigger2 = animelem = 14
var(13) = 1

[State 871, Juggle]
type = VarAdd
trigger1 = animelem = 6
trigger2 = animelem = 14
var(15) = 1
ignoreHitPause = 1

[State 871, Juggle]
type = VarSet
trigger1 = animelem = 6
trigger2 = animelem = 14
var(16) = 1
ignoreHitPause = 1

[State 1460]
type = envshake
trigger1 = animelem = 6
ampl = 6
time = 10

[State 1460]
type = envshake
trigger1 = animelem = 14
ampl = 10
time = 10

[State 1460]
type = targetstate
trigger1 = animelem = 14
value = 1442

[State 1460]
type = targetstate
trigger1 = animelem = 16
value = 1443

[State 1460]
type = velset
trigger1 = animelem = 14
x = 0
y = 0

[State 1460]
type = velset
trigger1 = animelem = 15
x = 1.5

[State 1460]
type = veladd
trigger1 = animelem = 15,>= 0
y = .4

[State 1460]
type = PlaySnd
trigger1 = animelem = 6
value = 4,2

[State 1460]
type = PlaySnd
trigger1 = animelem = 6
value = 2,5

[State 1460]
type = PlaySnd
trigger1 = animelem = 14
value = 820,2

[State 1460]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
value = 1441

;========================<EX MEGA SPIKE CONTINUE>=============================
[Statedef 1441]
type = S
movetype = A
physics = S
poweradd = 0
ctrl = 0
velset = 0,0
anim = 1430
sprpriority = 2

[State 1470, 1]
type = PlaySnd
trigger1 = Time = 1
value = 52, 0

[State 1470]
type = posset
trigger1 = time = 0
y = 0

[State 871, Damage]
type = TargetLifeAdd
trigger1 = animelem = 19
value = floor(ifElse(50 * fvar(11) < 7, -7, -50 * fvar(11)))

[State 871, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = animelem = 19
value = 0

[State 871, Power]
type = PowerAdd
trigger1 = animelem = 19 && !var(20)
value = 0

[State 871, HitAdd]
type = HitAdd
trigger1 = animelem = 19
value = 1

[State 871, HitCount]
type = VarAdd
trigger1 = animelem = 19
var(13) = 1

[State 871, Juggle]
type = VarAdd
trigger1 = animelem = 19
var(15) = 1
ignoreHitPause = 1

[State 871, Juggle]
type = VarSet
trigger1 = animelem = 19
var(16) = 1
ignoreHitPause = 1

[State 1470]
type = TargetBind
trigger1 = Animelem = 19
pos = 175,-113

[State 1470]
type = TargetState
trigger1 = Animelem = 19
value = 1445

[State 1470]
type = EnvShake
trigger1 = Animelem = 19
ampl = -6
time = 10

[State 871, Hit Spark]
type = Helper
trigger1 = Animelem = 19
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(170 * const(size.xScale)), ceil(-93 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1470]
type = PlaySnd
trigger1 = Animelem = 2
value = 1000,1

[State 1470]
type = PlaySnd
trigger1 = Animelem = 19
value = 820,2

[State 1470]
type = VelSet
trigger1 = Animelem = 20
x = 4

[State 1470]
type = afterimagetime
trigger1 = animtime = 0
time = 0

[State 1470, 4]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;========================<EX MEGA SPIKE PLAYER 2>=============================
[Statedef 1442]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = -2

[State 1475, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1416

[State 1475, 1]
type = ChangeAnim2
Triggerall = Time = 0
trigger1 = name = "Tin's Victor"
value = 1417

[State 1475]
type = velset
trigger1 = time = 0
x =0
y = 0

[State 1475]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

;========================<EX MEGA SPIKE PLAYER 2>=============================
[Statedef 1443]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = 3

[State 1480]
type = velset
trigger1 = time = 0
x = -3
y = 6

[State 1480]
type = veladd
trigger1 = 1
y = .4

[State 1480]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1480]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
value = 1444

;========================<EX MEGA SPIKE PLAYER 2>=============================
[Statedef 1444]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = -2

[State 1485]
type = posset
trigger1 = time = 0
y = 0

[State 1485]
type = EnvShake
trigger1 = time = 0
ampl = -6
time = 10

[State 1485]
type = velset
trigger1 = time = 10
x = -2
y = -12

[State 1485]
type = veladd
trigger1 = time >= 10
y = .5

[State 1485]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1485]
type = selfstate
trigger1 = pos Y>=0 && vel Y>0
trigger1 = Alive = 1
value = 5110

[State 1485]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
trigger1 = Alive = 0
value = 1420

;========================<EX MEGA SPIKE CONTINUE>=============================
[Statedef 1445]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = -2

[State 1490]
type = changeanim2
trigger1 = time = 0
value = 1435

[State 1490]
type = angleadd
trigger1 = animelem = 2,>= 0
value = 20

[State 1490]
type = angleDraw
trigger1 = animelem = 2,>= 0
trigger1 = pos Y < -10

[State 1490]
type = velset
trigger1 = animelem = 2
x = -5
y = -9
persistent = 0

[State 1490]
type = veladd
trigger1 = animelem = 2, >= 0
y = .5

[State 1490]
type = selfstate
trigger1 = pos Y>= -10 && vel Y>0
trigger1 = Alive = 1
value = 5110

[State 1490]
type = changestate
trigger1 = pos Y>= -10 && vel Y>0
trigger1 = Alive = 0
value = 1420

;========================<VICTOR FINGER>=============================
[StateDef 1500]
type = A
physics = N
moveType = A
anim = 1500
ctrl = 0
velSet = 2, -8
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1500, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "c" || command = "rlsc"), 2, ifElse((command = "b" || command = "rlsb"), 1, 0))

[State 1500, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1500]
type = PlaySnd
trigger1 = animelem = 4
value = 4,0

[State 1500]
type = width
trigger1 = animelem = 5, < 0
value = 40,0

[State 1500]
type = Veladd
trigger1 = animelem = 5,< 0
y = .5

[State 1500]
type = VelSet
trigger1 = animelem = 5
x = 0
y = 0

[State 1500]
type = VelSet
trigger1 = animelem = 9
x = -1.5
y = -4.6

[State 1500]
type = Veladd
trigger1 = animelem = 9,>= 0
y = .5

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
attr = A, NA
hitFlag = MAFD
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 150, ifElse(var(10), 140, 130)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 150, ifElse(var(10), 140, 130)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
Air.fall = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
p2stateno = 1525

[State 1500]
type = ChangeState
trigger1 = pos Y >= 0 && vel Y > 0
value = 1350

;========================<VICTOR FINGER PLAYER 2>=============================
[Statedef 1525]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2
velset = 0,0

[State 1540]
type = ChangeAnim2
trigger1 = time = 0
value = 1525

[State 1540]
type = posset
trigger1 = 1
y = 0

[State 1540]
type = SelfState
trigger1 = time >= 35
trigger1 = alive = 0
value = 5100

[State 1540]
type = SelfState
trigger1 = time >= 35
trigger1 = alive = 1
value = 5120

;========================<EX VICTOR FINGER>=============================
[StateDef 1530]
type = A
physics = N
moveType = A
anim = 1510
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1530, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1530, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1530, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 91

[State 1530, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1530, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1530]
type = PlaySnd
trigger1 = animelem = 5
trigger2 = animelem = 10
value = 4,0
volume = 0

[State 1530]
type = width
trigger1 = animelem = 6, < 0
value = 40,0

[State 1530]
type = VelSet
trigger1 = animelem = 2
x = 2
y = -8

[State 1530]
type = Veladd
trigger1 = animelem = 2,>= 0
trigger1 = animelem = 6,< 0
y = .5

[State 1530]
type = VelSet
trigger1 = animelem = 6
x = 0
y = 0

[State 1530]
type = VelSet
trigger1 = animelem = 12
x = -1.5
y = -4.6

[State 1530]
type = Veladd
trigger1 = animelem = 12,>= 0
y = .5

[State 1130, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 6
attr = A, NA
hitFlag = MAFD
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Heavy
air.animType = High
fall.animType = High
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = 0, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -1, -1
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
Air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
p2stateno = 1525

[State 1130, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 11
attr = A, NA
hitFlag = MAFD
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Heavy
air.animType = High
fall.animType = High
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = 0, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -1, -1
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
Air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
p2stateno = 1525

[State 1510]
type = ChangeState
trigger1 = Movehit && animelem = 15
value = 1535

[State 1510]
type = ChangeState
trigger1 = pos Y >= 0 && vel Y > 0
value = 1350

;========================<EX VICTOR FINGER>=============================
[Statedef 1535]
type = A
movetype = A
physics = N
juggle  = 0
poweradd= 0
ctrl = 0
velset = 0,0
anim = 1520
sprpriority = 2

[State 1520]
type = PlaySnd
trigger1 = animelem = 3
value = 4,1
volume = 0

[State 1130, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 4
attr = A, NA
hitFlag = MAFD
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
Air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -50
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1520]
type = VelSet
trigger1 = animelem = 6
x = -1.5
y = -4.6

[State 1520]
type = Veladd
trigger1 = animelem = 6,>= 0
y = .5

[State 1520]
type = ChangeState
trigger1 = pos Y >= 0 && vel Y > 0
value = 1350

;========================<MINIUM STEP>=============================
[StateDef 1600]
type = S
physics = N
moveType = I
anim = 1600
ctrl = 0
velSet = 0, 0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 500]
type = PlaySnd
trigger1 = Animelem = 3
value = 1400,0
channel = 0

[State 500]
type = StateTypeSet
trigger1 = animelem = 4
statetype = A

[State 500]
type = Velset
trigger1 = Animelem = 4
x = 4
y = -6

[State 500]
type = Veladd
trigger1 = Animelem = 4,>= 0
y = .44

[State 500]
type = changestate
trigger1 = vel Y > 0 && Pos Y >= 5
value = 1610

;========================<MINIUM STEP LANDING>=============================
[Statedef 1610]
type = S
movetype = I
physics = N
poweradd = 0
ctrl = 0
anim = 1610
sprpriority = 2
velset = 0,0

[State 510]
type = posset
trigger1 = Time = 0
y = 0

[State 52, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0

[State 52, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
pos = ceil(0 * const(size.xScale)),-5
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 510]
type = changestate
trigger1 = Animtime = 0
value = 0
ctrl = 1

;========================<MEGA SHOCK>=============================
[StateDef 1700]
type = S
physics = N
moveType = I
anim = 1700
ctrl = 0
velSet = 0, 0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1500, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "c" || command = "rlsc"), 2, ifElse((command = "b" || command = "rlsb"), 1, 0))

[State 1500, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1700]
type = StateTypeSet
trigger1 = Animelem = 2
movetype = A

[State 1700, 1]
type = HitDef
triggerall=P2stateno!=40
triggerall=P2stateno!=[120,153]
triggerall = enemy,movetype != H
trigger1 = !var(16) && (var(15) < 1 || var(20))
Trigger1 = animelem = 2
attr = S, ST
hitflag = M-
priority = 6, Miss
sparkno = -1
sprpriority = 1
p1facing = 1
p2facing = 1
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 1710
p2stateno = 1715
numhits = 0

[State 1700]
type = playsnd
trigger1 = animelem = 3
value = 800,0

[State 1700, 2]
type = ChangeState
Trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<MEGA SHOCK>=============================
[Statedef 1710]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 1710
sprpriority = 2

[State 1710]
type = Helper
trigger1 = time = 0
stateno = 2700
id = 2700
pos = 0,9999
postype = p1
ownpal = 1
sprpriority = -2
keyctrl = 1

[State 1710]
type = PosAdd
trigger1 = time = 0
trigger1 = frontedgebodydist <= 60
x = -40

[State 1710]
type = Width
trigger1 = 1
value = 40,0

[State 1710]
type = TargetBind
trigger1 = AnimElem = 1
pos = 57,-81

[State 1710]
type = TargetBind
trigger1 = AnimElem = 2
pos = 113,-90

[State 1710]
type = TargetBind
trigger1 = AnimElem = 3
pos = 40,-72

[State 1710]
type = TargetBind
trigger1 = AnimElem = 4
pos = 83,-70

[State 1710]
type = TargetBind
trigger1 = AnimElem = 5
pos = 77,-69

[State 1710]
type = Explod
trigger1 = Animelem = 4
anim = 1705
id = 1705
pos = 0,0
postype = p1
sprpriority = 3

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 5
value = floor(ifElse(25 * fvar(11) < 7, -7, -25 * fvar(11)))
Kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 5
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 5 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 5
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 5
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 5
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 5
var(16) = 1
ignoreHitPause = 1

[State 1710]
type = PlaySnd
trigger1 = AnimElem = 5
value = 1000,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 5
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(77 * const(size.xScale)), ceil(-69 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1710]
type = ChangeState
trigger1 = AnimTime = 0
value = 1711

;========================<MEGA SHOCK CONECT>=============================
[Statedef 1711]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 1711
sprpriority = 2

[State 1711]
type = Targetstate
trigger1 = time = 0
value = 1716

[State 1711]
type = VarAdd
trigger1 = 1
var(12) = -1
persistent = 0

[State 1711]
type = Changestate
triggerall = prevstateno = 1710 && var(14) != 0
triggerall = fvar(19) < 3 && Animelem = 1
trigger1 = fvar(19) != fvar(20)
value = 1713;2 + var(10)
persistent = 0

[State 1711]
type = Changestate
triggerall = prevstateno != 1710 && var(14) != 0
triggerall = fvar(19) < 3 && Animelem = 1
trigger1 = fvar(19) != fvar(20)
value = 1713;2 + var(10)
persistent = 0

[State 1711]
type = TargetBind
trigger1 = AnimElem = 1
pos = 83,-70

[State 1711]
type = TargetBind
trigger1 = AnimElem = 2
pos = 77,-69

[State 1711]
type = Explod
trigger1 = Animelem = 2
anim = 1705
id = 1705
pos = 0,0
postype = p1
sprpriority = 3

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 3
value = floor(ifElse(20 * fvar(11) < 7, -7, -20 * fvar(11)))
Kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 3
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 3 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 3
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 3
var(16) = 1
ignoreHitPause = 1

[State 1711]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1000,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 3
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(77 * const(size.xScale)), ceil(-69 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1711]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) <= 0
value = 1712

[State 1711]
type = ChangeState
triggerall = AnimTime = 0
trigger1 = var(12) > 0
trigger2 = fvar(19) != fvar(20)
value = 1711

;========================<MEGA SHOCK FINISH>=============================
[Statedef 1712]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 1712
sprpriority = 2

[State 1712]
type = Varset
trigger1 = time = 0
fvar(19) = 0

[State 1712]
type = TargetBind
trigger1 = AnimElem = 1
pos = 83,-70

[State 1712]
type = TargetBind
trigger1 = AnimElem = 2
pos = 79,-12

[State 1712]
type = Targetstate
trigger1 = AnimElem = 2
value = 1717

[State 1712]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<MEGA SHOCK CONECT>=============================
[Statedef 1713]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 1713
sprpriority = 2

[State 1711]
type = Targetstate
trigger1 = time = 0
value = 1718

[State 1711]
type = null;VarAdd
trigger1 = 1
var(12) = 1
persistent = 0

[State 1711]
type = TargetBind
trigger1 = AnimElem = 1
pos = 83,-70

[State 1711]
type = TargetBind
trigger1 = AnimElem = 2
pos = 77,-69

[State 1711]
type = Explod
trigger1 = Animelem = 2
anim = 1706
id = 1705
pos = 0,0
postype = p1
sprpriority = 3

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 3
value = floor(ifElse(20 * fvar(11) < 7, -7, -20 * fvar(11)))

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 3
value = 36

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 3 && !var(20)
value = 72

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 3
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 3
var(16) = 1
ignoreHitPause = 1

[State 1710]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1000,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 3
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(77 * const(size.xScale)), ceil(-69 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1711]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) > 0
value = 1711

[State 1711]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) <= 0
value = 1712

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1715]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = ChangeAnim2
trigger1 = time = 0
value = 1715

[State 1721]
type = ChangeAnim2
triggerall = Time = 0
triggerall = SelfAnimExist(9011) = 1
trigger1 = AuthorName = "Tin" || AuthorName = "Mouser" || AuthorName = "H�h" || AuthorName = "adamskie"
trigger2 = AuthorName = "M.M.R." || AuthorName = "ryokucha" || AuthorName = "Bad Darkness" || AuthorName = "Third"
trigger3 = AuthorName = "CAMRAT Type KOF" || AuthorName = "keyu"
value = 1722

[State 1720]
type = PalFX
trigger1 = AnimElem = 5 && Anim = 1715
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1720]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1716]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1721]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1716

[State 1721]
type = ChangeAnim2
triggerall = Time = 0
triggerall = SelfAnimExist(9011) = 1
trigger1 = AuthorName = "Tin" || AuthorName = "Mouser" || AuthorName = "H�h" || AuthorName = "adamskie"
trigger2 = AuthorName = "M.M.R." || AuthorName = "ryokucha" || AuthorName = "Bad Darkness" || AuthorName = "Third"
trigger3 = AuthorName = "CAMRAT Type KOF" || AuthorName = "keyu"
value = 1723

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1716
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1721]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1721]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 1719

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1718]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1723]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1718

[State 1723]
type = ChangeAnim2
triggerall = Time = 0
triggerall = SelfAnimExist(9011) = 1
trigger1 = AuthorName = "Tin" || AuthorName = "Mouser" || AuthorName = "H�h" || AuthorName = "adamskie"
trigger2 = AuthorName = "M.M.R." || AuthorName = "ryokucha" || AuthorName = "Bad Darkness" || AuthorName = "Third"
trigger3 = AuthorName = "CAMRAT Type KOF" || AuthorName = "keyu"
value = 1724

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1723]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1723]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 1719

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1717]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1722]
type = ChangeAnim2
trigger1 = time = 0
value = 1717

[State 1722]
type = ChangeAnim2
Triggerall = Time = 0
trigger1 = name = "Tin's Victor"
value = 1720

[State 1722]
type = ScreenBound
trigger1 = animelem = 1, <= 0
value = 1
movecamera = 1,0

[State 1722]
type = VelSet
trigger1 = animelem = 2
x = -3
y = -6

[State 1722]
type = Veladd
trigger1 = animelem = 2, >= 0
y = .4

[State 1720]
type = SelfState
trigger1 = pos Y >= 30 && vel Y > 0
trigger1 = name != "Tin's Victor"
value = 5100

[State 1722]
type = SelfState
triggerall = pos Y >= 44 && vel Y > 0
trigger1 = name = "Tin's Victor"
value = 5100

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1719]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1725]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1725]
type = ChangeState
trigger1 = command != "x" && command != "y" && command != "z" && command != "a" && command != "b" && command != "c"
value = 1720

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1720]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1726]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1726]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 1721

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1721]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1727]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1727]
type = ChangeState
trigger1 = command != "x" && command != "y" && command != "z" && command != "a" && command != "b" && command != "c"
value = 1722

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1722]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1728]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1728]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 1723

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1723]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1729]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1729]
type = ChangeState
trigger1 = command != "x" && command != "y" && command != "z" && command != "a" && command != "b" && command != "c"
value = 1724

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1724]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1730]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1730]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 1725

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1725]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1731]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1731]
type = ChangeState
trigger1 = command != "x" && command != "y" && command != "z" && command != "a" && command != "b" && command != "c"
value = 1726

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1726]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1732]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

[State 1732]
type = ChangeState
trigger1 = command = "x" || command = "y" || command = "z"
trigger2 = command = "a" || command = "b" || command = "c"
value = 1727

;========================<MEGA SHOCK PLAYER 2>=============================
[Statedef 1727]
type = A
movetype = H
physics = N
poweradd = 0
sprpriority = -2

[State 1720]
type = PalFX
trigger1 = AnimElem = 3
trigger1 = Anim = 1718
time = 7
add = 159,159,150
sinadd = 20,20,130,7
mul = 81,82,150
invertall = 0
color = 0

[State 1733]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 1,0

;========================<EX MEGA SHOCK>=============================
[StateDef 1730]
type = S
physics = N
moveType = I
anim = 1700
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1730, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1730, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1730, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 391

[State 1730, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1730, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1700]
type = StateTypeSet
trigger1 = Animelem = 2
movetype = A

[State 1700, 1]
type = HitDef
triggerall=P2stateno!=40
triggerall=P2stateno!=[120,153]
triggerall = enemy,movetype != H
trigger1 = !var(16) && (var(15) < 1 || var(20))
Trigger1 = animelem = 2
attr = S, ST
hitflag = M-
priority = 6, Miss
sparkno = -1
sprpriority = 1
p1facing = 1
p2facing = 1
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 1740
p2stateno = 1715
numhits = 0

[State 1700]
type = playsnd
trigger1 = animelem = 3
value = 800,0

[State 1700, 2]
type = ChangeState
Trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<MEGA SHOCK>=============================
[Statedef 1740]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 1710
sprpriority = 2

[State 1710]
type = Helper
trigger1 = time = 0
stateno = 2700
id = 2700
pos = 0,9999
postype = p1
ownpal = 1
sprpriority = -2
keyctrl = 1

[State 1710]
type = PosAdd
trigger1 = time = 0
trigger1 = frontedgebodydist <= 60
x = -40

[State 1710]
type = Width
trigger1 = 1
value = 40,0

[State 1710]
type = TargetBind
trigger1 = AnimElem = 1
pos = 57,-81

[State 1710]
type = TargetBind
trigger1 = AnimElem = 2
pos = 113,-90

[State 1710]
type = TargetBind
trigger1 = AnimElem = 3
pos = 40,-72

[State 1710]
type = TargetBind
trigger1 = AnimElem = 4
pos = 83,-70

[State 1710]
type = TargetBind
trigger1 = AnimElem = 5
pos = 77,-69

[State 1710]
type = Explod
trigger1 = Animelem = 4
anim = 1705
id = 1705
pos = 0,0
postype = p1
sprpriority = 3

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 5
value = floor(ifElse(17 * fvar(11) < 7, -7, -17 * fvar(11)))
Kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 5
value = 0

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 5 && !var(20)
value = 0

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 5
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 5
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 5
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 5
var(16) = 1
ignoreHitPause = 1

[State 1710]
type = PlaySnd
trigger1 = AnimElem = 5
value = 1000,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 5
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(77 * const(size.xScale)), ceil(-69 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1710]
type = ChangeState
trigger1 = AnimTime = 0
value = 1741

;========================<MEGA SHOCK CONECT>=============================
[Statedef 1741]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 1711
sprpriority = 2

[State 1711]
type = Targetstate
trigger1 = time = 0
value = 1716

[State 1711]
type = VarAdd
trigger1 = 1
var(12) = -1
persistent = 0

[State 1711]
type = Changestate
triggerall = prevstateno = 1710 && var(14) != 0
triggerall = fvar(19) < 3 && Animelem = 1
trigger1 = fvar(19) != fvar(20)
value = 1743;2 + var(10)
persistent = 0

[State 1711]
type = Changestate
triggerall = prevstateno != 1710 && var(14) != 0
triggerall = fvar(19) < 3 && Animelem = 1
trigger1 = fvar(19) != fvar(20)
value = 1743;2 + var(10)
persistent = 0

[State 1711]
type = TargetBind
trigger1 = AnimElem = 1
pos = 83,-70

[State 1711]
type = TargetBind
trigger1 = AnimElem = 2
pos = 77,-69

[State 1711]
type = Explod
trigger1 = Animelem = 2
anim = 1705
id = 1705
pos = 0,0
postype = p1
sprpriority = 3

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 3
value = floor(ifElse(17 * fvar(11) < 7, -7, -17 * fvar(11)))
Kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 3
value = 0

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 3 && !var(20)
value = 0

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 3
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 3
var(16) = 1
ignoreHitPause = 1

[State 1711]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1000,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 3
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(77 * const(size.xScale)), ceil(-69 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1711]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) <= 0
value = 1742

[State 1711]
type = ChangeState
triggerall = AnimTime = 0
trigger1 = var(12) > 0
trigger2 = fvar(19) != fvar(20)
value = 1741

;========================<MEGA SHOCK FINISH>=============================
[Statedef 1742]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 1712
sprpriority = 2

[State 1712]
type = Varset
trigger1 = time = 0
fvar(19) = 0

[State 1712]
type = TargetBind
trigger1 = AnimElem = 1
pos = 83,-70

[State 1712]
type = TargetBind
trigger1 = AnimElem = 2
pos = 79,-12

[State 1712]
type = Targetstate
trigger1 = AnimElem = 2
value = 1717

[State 1712]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<MEGA SHOCK CONECT>=============================
[Statedef 1743]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 1713
sprpriority = 2

[State 1711]
type = Targetstate
trigger1 = time = 0
value = 1718

[State 1711]
type = null;VarAdd
trigger1 = 1
var(12) = 1
persistent = 0

[State 1711]
type = TargetBind
trigger1 = AnimElem = 1
pos = 83,-70

[State 1711]
type = TargetBind
trigger1 = AnimElem = 2
pos = 77,-69

[State 1711]
type = Explod
trigger1 = Animelem = 2
anim = 1706
id = 1705
pos = 0,0
postype = p1
sprpriority = 3

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 3
value = floor(ifElse(17 * fvar(11) < 7, -7, -17 * fvar(11)))

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 3
value = 0

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 3 && !var(20)
value = 0

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 3
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 3
var(16) = 1
ignoreHitPause = 1

[State 1710]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1000,2

[State 871, Hit Spark]
type = Helper
trigger1 = NumTarget && Animelem = 3
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(77 * const(size.xScale)), ceil(-69 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1711]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) > 0
value = 1741

[State 1711]
type = ChangeState
trigger1 = AnimTime = 0
trigger1 = var(12) <= 0
value = 1742

;========================<GIGA BUSTER>=============================
[StateDef 1800]
type = S
physics = S
moveType = A
anim = 1800
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1800, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "c" || command = "rlsc"), 2, ifElse((command = "b" || command = "rlsb"), 1, 0))

[State 1800, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1800, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1820, ifElse(var(10) = 1, 1810, 1800))

[State 1800]
type = PlaySnd
trigger1 = animelem = 5
value = 1, 5

[State 1800]
type = PlaySnd
trigger1 = animelem = 5
value = 4,3

[State 1800]
type = velset
trigger1 = var(10) = 0
trigger1 = animelem = 3
x = 6

[State 1800]
type = velset
trigger1 = var(10) = 1
trigger1 = animelem = 3
x = 12

[State 1800]
type = velset
trigger1 = var(10) = 2
trigger1 = animelem = 3
x = 18

[State 1800]
type = velset
trigger1 = animelem = 6
x = 0

[State 1800, Dust Helper]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1800, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
attr = S, SA
hitFlag = MAF
guardFlag = L
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 150, ifElse(var(10), 140, 130)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 150, ifElse(var(10), 140, 130)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -30
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1800, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX GIGA BUSTER>=============================
[StateDef 1830]
type = S
physics = S
moveType = A
anim = 1830
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1830, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1830, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1830, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 91

[State 1830, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1830, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1830]
type = PlaySnd
trigger1 = animelem = 8
trigger2 = Animelem = 17
trigger3 = Animelem = 26
value = 1, 5
channel = 3

[State 1830]
type = PlaySnd
trigger1 = animelem = 7
value = 4,3
channel = 0

[State 1830]
type = velset
trigger1 = animelem = 4
x = 7

[State 1830]
type = statetypeset
trigger1 = animelem = 6
value = A

[State 1830]
type = velset
trigger1 = animelem = 6
x = 4
y = -4.4

[State 1830]
type = posadd
trigger1 = animelem = 16
trigger2 = Animelem = 25
x = 10
y = 10

[State 1830]
type = velset
trigger1 = animelem = 7
trigger2 = Animelem = 22
x = 0
y = 0

[State 1830]
type = veladd
trigger1 = animelem = 16,>= 0
trigger1 = animelem = 21,< 0
trigger2 = Animelem = 30,>= 0
y = .5

[State 1830, Dust Helper]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 40, Dust Helper]
type = Helper
trigger1 = Animelem = 6
helperType = Normal
stateNo = 8100
ID = 8100
name = "Jump Dust"
posType = P1
ownPal = 1

[State 1830, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 6
trigger2 = Animelem = 12
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -7, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -40
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1830, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 18
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
Air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -40
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1830, 4]
type = ChangeState
trigger1 = pos Y >= 0 && vel Y > 0
value = 1350

;========================<GIGA HAMMER>=============================
[StateDef 1900]
type = S
physics = S
moveType = A
anim = 1900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1900, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1900, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1900, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1920, ifElse(var(10) = 1, 1910, 1900))

[State 1900]
type = PlaySnd
trigger1 = animelem = 5
value = 1, 2

[State 1900]
type = PlaySnd
trigger1 = animelem = 5
value = 4,4

[State 1900]
type = velset
trigger1 = var(10) = 0
trigger1 = animelem = 3
x = 6

[State 1900]
type = velset
trigger1 = var(10) = 1
trigger1 = animelem = 3
x = 12

[State 1900]
type = velset
trigger1 = var(10) = 2
trigger1 = animelem = 3
x = 18

[State 1900]
type = velset
trigger1 = animelem = 6
x = 0

[State 1900]
type = Explod
trigger1 = Animelem = 5
anim = 1940
id = 1940
pos = 86,-41
postype = p1
sprpriority = 3
bindtime = -1
ownpal = 1
removeongethit = 1
removetime = 15

[State 1900]
type = RemoveExplod
trigger1 = animelem = 6
id = 1940

[State 1900, Dust Helper]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1900, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 5
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 150, ifElse(var(10), 140, 130)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 150, ifElse(var(10), 140, 130)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -40
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<EX GIGA HAMMER>=============================
[StateDef 1930]
type = S
physics = S
moveType = A
anim = 1930
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1930, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1930, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1930, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 91

[State 1930, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1930, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1930]
type = PlaySnd
trigger1 = animelem = 5
value = 2, 8
channel = 3

[State 1930]
type = PlaySnd
trigger1 = animelem = 5
trigger2 = Animelem = 11
trigger3 = Animelem = 17
value = 1, 2
channel = 2

[State 1930]
type = PlaySnd
trigger1 = animelem = 5
value = 4,4
channel = 0

[State 1930]
type = velset
trigger1 = animelem = 3
trigger2 = Animelem = 8
trigger3 = Animelem = 14
x = 8

[State 1930]
type = velset
trigger1 = animelem = 18
x = 0

[State 1930]
type = Explod
trigger1 = Animelem = 5
trigger2 = animelem = 11
trigger3 = animelem = 17
anim = 1940
id = 1940
pos = 86,-61
postype = p1
sprpriority = 3
ownpal = 1
removeongethit = 1
removetime = 15
vel = 4,-2

[State 1930]
type = Explod
trigger1 = Animelem = 5
trigger2 = animelem = 11
trigger3 = animelem = 17
anim = 1940
id = 1941
pos = 70,-46
postype = p1
sprpriority = 3
ownpal = 1
removeongethit = 1
removetime = 15
vel = 3,-2

[State 1930]
type = Explod
trigger1 = Animelem = 5
trigger2 = animelem = 11
trigger3 = animelem = 17
anim = 1940
id = 1942
pos = 60,-36
postype = p1
sprpriority = 3
ownpal = 1
removeongethit = 1
removetime = 15
vel = 2,-2

[State 1930, Dust Helper]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pos = -40,0
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1930, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 6
trigger2 = Animelem = 12
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -9, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -90
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1930, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 18
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
guard.pauseTime = ifElse(var(20), 4, 9), ifElse(var(20), 4, 9)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = High
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5, -6
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
Air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 197), var(36) := -90
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1930, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<PUNCH ZERO COUNTER>=============================
[StateDef 2900]
type = S
physics = N
moveType = A
anim = 2900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2900, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2900, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 4, ifElse(Random < 500, 3, 4)
channel = 0

[State 2900, Woosh]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1,2
channel = 1

[State 2900, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 5
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 92 < 7, 7, fvar(11) * 92)), 0
getpower = 0,0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 175), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2900, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 2900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<KICK ZERO COUNTER>=============================
[StateDef 2910]
type = S
physics = N
moveType = A
anim = 2910
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2910, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2910, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 4, 4
channel = 0

[State 2910, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1,5
channel = 1

[State 2910, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 5
attr = C, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 92 < 7, 7, fvar(11) * 92)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 196), var(36) := -25
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2910, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(6) >= 0
moveType = I

[State 2910, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
