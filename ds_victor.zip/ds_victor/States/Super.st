; _________________________________________
;| Victor by varo_hades                    |
; �����������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<GREAT GELDENHEIM>=============================
[StateDef 3000]
type = S
physics = S
moveType = I
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(10 * const(size.xScale)), ceil(-100 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3010]
type = statetypeset
trigger1 = animelem = 2
movetype = A

[State 3010]
type = HitDef
triggerall = P2stateno != 40
triggerall = P2stateno != [120,153]
triggerall = enemy,movetype != H
Trigger1 = animelem = 2
attr = S, HT
hitflag = M-
priority = 7, Miss
sparkno = -1
sprpriority = 1
p1facing = 1
p2facing = 1
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 3001
p2stateno = 3005
numhits = 0

[State 3010]
type = playsnd
trigger1 = animelem = 3
value = 4,0

[State 3010]
type = ChangeState
Trigger1 = AnimTime = 0
value =0
ctrl = 1

;========================<GREAT GELDENHEIM CONECT>=============================
[Statedef 3001]
type = A
movetype = A
physics = N
velset = 0,0
ctrl = 0
anim = 3001
sprpriority = -2

[State 3015]
type = PosAdd
trigger1 = time = 0 && frontedgebodydist <= 60
x = -70

[State 3015]
type = targetbind
trigger1 = animelem = 1
pos = 77,-91

[State 3015]
type = targetbind
trigger1 = animelem = 2
pos = 54,-97

[State 3015]
type = targetbind
trigger1 = animelem = 3
pos = 91,-33

[State 3015]
type = targetbind
trigger1 = animelem = 4
pos = 89,-40

[State 3015]
type = targetbind
trigger1 = animelem = 5 && animelem = 6, < 0
pos = 87,-99

[State 3015]
type = targetbind
trigger1 = animelem = 6,>= 0 && animelem = 5, < 0
trigger2 = animelem = 12,>= 0 && animelem = 13, < 0
trigger3 = animelem = 18,>= 0 && animelem = 19, < 0
trigger4 = animelem = 24,>= 0 && animelem = 25, < 0
trigger5 = animelem = 30,>= 0 && animelem = 31, < 0
pos = 55,-103

[State 3015]
type = targetbind
trigger1 = animelem = 7,>= 0 && animelem = 8, < 0
trigger2 = animelem = 13,>= 0 && animelem = 14, < 0
trigger3 = animelem = 19,>= 0 && animelem = 20, < 0
trigger4 = animelem = 25,>= 0 && animelem = 26, < 0
trigger5 = animelem = 31,>= 0 && animelem = 32, < 0
pos = -27,-107

[State 3015]
type = targetbind
trigger1 = animelem = 8,>= 0 && animelem = 9, < 0
trigger2 = animelem = 14,>= 0 && animelem = 15, < 0
trigger3 = animelem = 20,>= 0 && animelem = 21, < 0
trigger4 = animelem = 26,>= 0 && animelem = 27, < 0
pos = -80,-103

[State 3015]
type = targetbind
trigger1 = animelem = 9,>= 0 && animelem = 10, < 0
trigger2 = animelem = 15,>= 0 && animelem = 16, < 0
trigger3 = animelem = 21,>= 0 && animelem = 22, < 0
trigger4 = animelem = 27,>= 0 && animelem = 28, < 0
pos = -85,-104

[State 3015]
type = targetbind
trigger1 = animelem = 10,>= 0 && animelem = 11, < 0
trigger2 = animelem = 16,>= 0 && animelem = 17, < 0
trigger3 = animelem = 22,>= 0 && animelem = 23, < 0
trigger4 = animelem = 28,>= 0 && animelem = 29, < 0
pos = -3,-101

[State 3015]
type = targetbind
trigger1 = animelem = 11,>= 0 && animelem = 12, < 0
trigger2 = animelem = 17,>= 0 && animelem = 18, < 0
trigger3 = animelem = 23,>= 0 && animelem = 24, < 0
trigger4 = animelem = 29,>= 0 && animelem = 30, < 0
pos = 85,-106

[State 3015]
type = targetbind
trigger1 = animelem = 32 && animelem = 33, < 0
pos = -77,-111

[State 3015]
type = targetbind
trigger1 = animelem = 33 && animelem = 34, < 0
pos = -25,-149

[State 3015]
type = targetbind
trigger1 = animelem = 34
pos = 116,-4

[State 3015]
type = targetstate
trigger1 = animelem = 34
value = 3006

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 34
value = floor(ifElse(200 * fvar(11) < 7, -7, -200 * fvar(11)))
kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 34
value = 0

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 34 && !var(20)
value = 0

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 34
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 34
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 34
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 34
var(16) = 1
ignoreHitPause = 1

[State 3015]
type = SprPriority
trigger1 = Animelem = 3
trigger2 = Animelem = 11
trigger3 = Animelem = 17
trigger4 = Animelem = 23
trigger5 = Animelem = 29
trigger6 = Animelem = 34
value = 2

[State 3015]
type = SprPriority
trigger1 = Animelem = 7
trigger2 = Animelem = 13
trigger3 = Animelem = 19
trigger4 = Animelem = 25
trigger5 = Animelem = 31
value = -2

[State 3015]
type = Explod
trigger1 = Animelem = 6
trigger2 = Animelem = 12
anim = 3040
id = 3040
pos = 0,0
postype = p1
sprpriority = 1
bindtime = -1
removetime = 20
removeongethit = 1

[State 3015]
type = Explod
trigger1 = Animelem = 18
trigger2 = Animelem = 24
anim = 3044
id = 3040
pos = 0,0
postype = p1
sprpriority = 1
bindtime = -1
removetime = 20
removeongethit = 1

[State 3015]
type = Explod
trigger1 = NumExplod(3041) = 0
trigger1 = Animelem = 6,>= 0
trigger1 = Animelem = 31, <= 0
anim = 3041
id = 3041
pos = 0,0
postype = p1
sprpriority = 3
bindtime = -1
removeongethit = 1

[State 3015]
type = Explod
trigger1 = NumExplod(3042) = 0
trigger1 = Animelem = 6,>= 0
trigger1 = Animelem = 31, <= 0
anim = 3042
id = 3042
pos = 0,0
postype = p1
sprpriority = 3
bindtime = -1
removeongethit = 1

[State 3015]
type = ReMoveExplod
trigger1 = animelem = 32
id = 3040

[State 3015]
type = ReMoveExplod
trigger1 = animelem = 32
id = 3041

[State 3015]
type = ReMoveExplod
trigger1 = animelem = 32
id = 3042

[State 3015]
type = Explod
trigger1 = Animelem = 32
anim = 3045
id = 3045
pos = 0,0
postype = p1
sprpriority = 3
bindtime = -1
removetime = 11
removeongethit = 1

[State 3015]
type = PlaySnd
trigger1 = animelem = 13
value = 2,7

[State 3015]
type = PlaySnd
trigger1 = animelem = 33
value = 1400,0

[State 3015]
type = velset
trigger1 = animelem = 5
y = -2.5

[State 3015]
type = velset
trigger1 = animelem = 13
y = 0

[State 3015]
type = velset
trigger1 = animelem = 35
x = -1.2
y = -8

[State 3015]
type = veladd
trigger1 = animelem = 35, >= 0
y = .5

[State 3015]
type = changestate
trigger1 = pos Y >= 5 && vel Y > 0
value = 1350

;========================<GREAT GELDENHEIM PLAYER 2>=============================
[Statedef 3005]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = 1

[State 3020, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3005

[STate 3020]
type = screenbound
trigger1 = 1
value = 0

;========================<GREAT GELDENHEIM PLAYER 2>=============================
[Statedef 3006]
type = A
movetype = H
physics = N
velset = 0,0
sprpriority = 2
velset = -5,8

[State 3030]
type = velset
trigger1 = 1
x = -10
y = 12

[STate 3030]
type = screenbound
trigger1 = 1
value = 1
movecamera = 1,0

[State 3030]
type = EnvShake
trigger1 = pos Y >= 0 && vel Y > 0
ampl = -7
time = 15

[State 3030]
type = lifeadd
trigger1 = pos Y >= 0 && vel Y > 0
value = -70
persistent = 0

[State 3030]
type = SelfState
trigger1 = pos Y >= 0 && vel Y > 0
value = 5100

;========================<MAX GREAT GELDENHEIM>=============================
[StateDef 3050]
type = S
physics = S
moveType = I
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
time = 1
value = SCA

[State 3050, SuperPause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(10 * const(size.xScale)), ceil(-100 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3050, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3050]
type = statetypeset
trigger1 = animelem = 2
movetype = A

[State 3050]
type = HitDef
triggerall = P2stateno != 40
triggerall = P2stateno != [120,153]
triggerall = enemy,movetype != H
Trigger1 = animelem = 2
attr = S, HT
hitflag = M-
priority = 7, Miss
sparkno = -1
sprpriority = 1
p1facing = 1
p2facing = 1
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 3051
p2stateno = 3005
numhits = 0

[State 3050]
type = playsnd
trigger1 = animelem = 3
value = 4,0

[State 3050]
type = ChangeState
Trigger1 = AnimTime = 0
value =0
ctrl = 1

;========================<MAX GREAT GELDENHEIM CONECT>=============================
[Statedef 3051]
type = A
movetype = A
physics = N
velset = 0,0
ctrl = 0
anim = 3001
sprpriority = -2

[State 3015]
type = PosAdd
trigger1 = time = 0 && frontedgebodydist <= 60
x = -70

[State 3015]
type = targetbind
trigger1 = animelem = 1
pos = 77,-91

[State 3015]
type = targetbind
trigger1 = animelem = 2
pos = 54,-97

[State 3015]
type = targetbind
trigger1 = animelem = 3
pos = 91,-33

[State 3015]
type = targetbind
trigger1 = animelem = 4
pos = 89,-40

[State 3015]
type = targetbind
trigger1 = animelem = 5 && animelem = 6, < 0
pos = 87,-99

[State 3015]
type = targetbind
trigger1 = animelem = 6,>= 0 && animelem = 5, < 0
trigger2 = animelem = 12,>= 0 && animelem = 13, < 0
trigger3 = animelem = 18,>= 0 && animelem = 19, < 0
trigger4 = animelem = 24,>= 0 && animelem = 25, < 0
trigger5 = animelem = 30,>= 0 && animelem = 31, < 0
pos = 55,-103

[State 3015]
type = targetbind
trigger1 = animelem = 7,>= 0 && animelem = 8, < 0
trigger2 = animelem = 13,>= 0 && animelem = 14, < 0
trigger3 = animelem = 19,>= 0 && animelem = 20, < 0
trigger4 = animelem = 25,>= 0 && animelem = 26, < 0
trigger5 = animelem = 31,>= 0 && animelem = 32, < 0
pos = -27,-107

[State 3015]
type = targetbind
trigger1 = animelem = 8,>= 0 && animelem = 9, < 0
trigger2 = animelem = 14,>= 0 && animelem = 15, < 0
trigger3 = animelem = 20,>= 0 && animelem = 21, < 0
trigger4 = animelem = 26,>= 0 && animelem = 27, < 0
pos = -80,-103

[State 3015]
type = targetbind
trigger1 = animelem = 9,>= 0 && animelem = 10, < 0
trigger2 = animelem = 15,>= 0 && animelem = 16, < 0
trigger3 = animelem = 21,>= 0 && animelem = 22, < 0
trigger4 = animelem = 27,>= 0 && animelem = 28, < 0
pos = -85,-104

[State 3015]
type = targetbind
trigger1 = animelem = 10,>= 0 && animelem = 11, < 0
trigger2 = animelem = 16,>= 0 && animelem = 17, < 0
trigger3 = animelem = 22,>= 0 && animelem = 23, < 0
trigger4 = animelem = 28,>= 0 && animelem = 29, < 0
pos = -3,-101

[State 3015]
type = targetbind
trigger1 = animelem = 11,>= 0 && animelem = 12, < 0
trigger2 = animelem = 17,>= 0 && animelem = 18, < 0
trigger3 = animelem = 23,>= 0 && animelem = 24, < 0
trigger4 = animelem = 29,>= 0 && animelem = 30, < 0
pos = 85,-106

[State 3015]
type = targetbind
trigger1 = animelem = 32 && animelem = 33, < 0
pos = -77,-111

[State 3015]
type = targetbind
trigger1 = animelem = 33 && animelem = 34, < 0
pos = -25,-149

[State 3015]
type = targetbind
trigger1 = animelem = 34
pos = 116,-4

[State 3015]
type = targetstate
trigger1 = animelem = 34
value = 3006

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 34
value = floor(ifElse(300 * fvar(11) < 7, -7, -300 * fvar(11)))
kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 34
value = 0

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 34 && !var(20)
value = 0

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 34
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 34
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 34
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 34
var(16) = 1
ignoreHitPause = 1

[State 3015]
type = SprPriority
trigger1 = Animelem = 3
trigger2 = Animelem = 11
trigger3 = Animelem = 17
trigger4 = Animelem = 23
trigger5 = Animelem = 29
trigger6 = Animelem = 34
value = 2

[State 3015]
type = SprPriority
trigger1 = Animelem = 7
trigger2 = Animelem = 13
trigger3 = Animelem = 19
trigger4 = Animelem = 25
trigger5 = Animelem = 31
value = -2

[State 3015]
type = Explod
trigger1 = Animelem = 6
trigger2 = Animelem = 12
anim = 3040
id = 3040
pos = 0,0
postype = p1
sprpriority = 1
bindtime = -1
removetime = 20
removeongethit = 1

[State 3015]
type = Explod
trigger1 = Animelem = 18
trigger2 = Animelem = 24
anim = 3044
id = 3040
pos = 0,0
postype = p1
sprpriority = 1
bindtime = -1
removetime = 20
removeongethit = 1

[State 3015]
type = Explod
trigger1 = NumExplod(3041) = 0
trigger1 = Animelem = 6,>= 0
trigger1 = Animelem = 31, <= 0
anim = 3041
id = 3041
pos = 0,0
postype = p1
sprpriority = 3
bindtime = -1
removeongethit = 1

[State 3015]
type = Explod
trigger1 = NumExplod(3042) = 0
trigger1 = Animelem = 6,>= 0
trigger1 = Animelem = 31, <= 0
anim = 3042
id = 3042
pos = 0,0
postype = p1
sprpriority = 3
bindtime = -1
removeongethit = 1

[State 3015]
type = ReMoveExplod
trigger1 = animelem = 32
id = 3040

[State 3015]
type = ReMoveExplod
trigger1 = animelem = 32
id = 3041

[State 3015]
type = ReMoveExplod
trigger1 = animelem = 32
id = 3042

[State 3015]
type = Explod
trigger1 = Animelem = 32
anim = 3045
id = 3045
pos = 0,0
postype = p1
sprpriority = 3
bindtime = -1
removetime = 11
removeongethit = 1

[State 3015]
type = PlaySnd
trigger1 = animelem = 13
value = 2,7

[State 3015]
type = PlaySnd
trigger1 = animelem = 33
value = 1400,0

[State 3015]
type = velset
trigger1 = animelem = 5
y = -2.5

[State 3015]
type = velset
trigger1 = animelem = 13
y = 0

[State 3015]
type = velset
trigger1 = animelem = 35
x = -1.2
y = -8

[State 3015]
type = veladd
trigger1 = animelem = 35, >= 0
y = .5

[State 3015]
type = changestate
trigger1 = pos Y >= 5 && vel Y > 0
value = 1350

;========================<THUNDER BREAK>=============================
[StateDef 3100]
type = S
physics = N
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(20 * const(size.xScale)), ceil(-70 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100]
type = PlaySnd
trigger1 = animelem = 2
value = 3100,0
channel = 0

[State 3100]
type = PlaySnd
trigger1 = animelem = 6
value = 820,2

[State 3100]
type = EnvShake
trigger1 = animelem = 6
ampl = -4
time = 10

[State 3100]
type = palfx
trigger1 = gametime%2 = 0
add=10,110,185
mul=10,110,255
time = 1
ignorehitpause = 1

[State 3100]
type = StateTypeSet
trigger1 = animelem = 3
statetype = A

[State 3100]
type = StateTypeSet
trigger1 = animelem = 6
statetype = S

[State 3100]
type = posset
trigger1 = animelem = 6, >= 0
y = 0

[State 3100]
type = VelSet
trigger1 = animelem = 6
x = 0
y = 0

[State 3100]
type = VelSet
trigger1 = animelem = 3
x = 4
y = -10

[State 3100]
type = Veladd
trigger1 = animelem = 3,>= 0
trigger1 = animelem = 6,< 0
y = .7

[State 871, Impact Dust]
type = Helper
trigger1 = NumTarget && Animelem = 6
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 82,0
facing = -1
ownPal = 1

[State 3100]
type = Helper
trigger1 = Animelem = 3
stateno = 3105
id = 3105
pos = -51,-81
postype = p1
ownpal = 1
sprpriority = 5

[State 3100]
type = Helper
trigger1 = time = 12
stateno = 3105
id = 3105
pos = -51,-81
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .8
size.yscale = .8

[State 3100]
type = Helper
trigger1 = time = 17
stateno = 3105
id = 3105
pos = -51,-81
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .6
size.yscale = .6

[State 3100]
type = Helper
trigger1 = animelem = 6
stateno = 3110
id = 3110
pos = 0,-10
postype = p1
ownpal = 1
sprpriority = 3
persistent = 0

[State 3100]
type = Helper
trigger1 = animelem = 6
stateno = 3120
id = 3120
pos = 0,-10
postype = p1
ownpal = 1
sprpriority = 3
persistent = 0

[State 3100, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 5
attr = A, HA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -5,-5
ground.cornerpush.veloff = (1.3*-6)
air.cornerpush.veloff = (1.3*-6)
down.cornerpush.veloff = (1.3*-6)
guard.cornerpush.veloff = (1.3*-6)
airguard.cornerpush.veloff = (1.3*-6)
air.velocity = -3, -4
guard.velocity = -6
airguard.velocity = -4.5,-2
down.velocity = -3,-5
down.bounce = 1
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 194), var(36) := -30
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100]
type = TargetState
trigger1 = Movehit
value = 2600
persistent = 0
ignorehitpause = 1

[State 3100]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;========================<THUNDER BREAK>=============================
[Statedef 3105]
type = A
movetype = I
physics = N
ctrl = 0
velset = 0,0
anim = 3105
sprpriority = 5

[State 3105]
type = varset
trigger1 = time = 0
trigger2 = time = 18
fvar(15) = 0

[State 3105]
type = varset
trigger1 = time = 0
trigger2 = time = 18
fvar(16) = 0

[State 3105]
type = varadd
trigger1 = time < 18
fvar(15) = 51/18

[State 3105]
type = varadd
trigger1 = time < 18
fvar(16) = -(39/18)

[State 3105]
type = varadd
trigger1 = time >= 18
fvar(15) = 87/10

[State 3105]
type = varadd
trigger1 = time >= 18
fvar(16) = 111/10

[State 3105]
type = bindtoparent
trigger1 = time < 18
pos = -51+(fvar(15)),-81+(fvar(16))

[State 3105]
type = bindtoparent
trigger1 = time =[18,27]
pos = (fvar(15)),-120+(fvar(16))

[State 3105]
type = bindtoparent
trigger1 = time > 27
pos = 87,-9

[State 3105]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 3100

;========================<THUNDER BREAK>=============================
[Statedef 3110]
type = A
movetype = A
physics = N
juggle = 0
poweradd= 0
ctrl = 0
velset = 0,0
anim = 3110
sprpriority = 3

[State 3110]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3100, HitDef 2]
type = HitDef
trigger1 = !var(16) && var(15) < 2
trigger1 = Time = 0
attr = A, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 100 < 7, 7, fvar(11) * 100)), 8
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerpush.veloff = (1.3*-6)
air.cornerpush.veloff = (1.3*-6)
down.cornerpush.veloff = (1.3*-6)
guard.cornerpush.veloff = (1.3*-6)
airguard.cornerpush.veloff = (1.3*-6)
air.velocity = -3, -4
guard.velocity = -6
airguard.velocity = -4.5,-2
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := -1)
guardSound = -1 + 0 * (var(32) := -1)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 183), var(36) := -20
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 8)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ceil(P2Dist x), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3110]
type = TargetState
trigger1 = Movehit && enemy,stateno!= 2600
value = 2600
persistent = 0
ignorehitpause = 1

[State 3110]
type = TargetState
trigger1 = Movehit && enemy,stateno = 2600
value = 2650
persistent = 0
ignorehitpause = 1

[State 3110]
type = VelSet
trigger1 = 1
x = -5

[State 3110]
type = DestroySelf
trigger1 = backedgebodydist < -100

;========================<THUNDER BREAK>=============================
[Statedef 3120]
type = A
movetype = A
physics = N
juggle = 0
poweradd= 0
ctrl = 0
velset = 0,0
anim = 3120
sprpriority = 3

[State 3120]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3100, HitDef 3]
type = HitDef
trigger1 = !var(16) && var(15) < 3
trigger1 = Time = 0
attr = A, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 100 < 7, 7, fvar(11) * 100)), 8
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerpush.veloff = (1.3*-6)
air.cornerpush.veloff = (1.3*-6)
down.cornerpush.veloff = (1.3*-6)
guard.cornerpush.veloff = (1.3*-6)
airguard.cornerpush.veloff = (1.3*-6)
air.velocity = -3, -4
guard.velocity = -6
airguard.velocity = -4.5,-2
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := -1)
guardSound = -1 + 0 * (var(32) := -1)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 185), var(36) := -20
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 8)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ceil(P2Dist x), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3120]
type = TargetState
trigger1 = Movehit && enemy,stateno!= 2600
value = 2600
persistent = 0
ignorehitpause = 1

[State 3120]
type = TargetState
trigger1 = Movehit && enemy,stateno = 2600
value = 2650
persistent = 0
ignorehitpause = 1

[State 3120]
type = VelSet
trigger1 = 1
x = 5

[State 3120]
type = DestroySelf
trigger1 = frontedgebodydist < -100

;========================<MAX THUNDER BREAK>=============================
[StateDef 3150]
type = S
physics = N
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3150, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(20 * const(size.xScale)), ceil(-70 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3150, SuperPause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3150]
type = PlaySnd
trigger1 = animelem = 2
value = 3100,0
channel = 0

[State 3150]
type = PlaySnd
trigger1 = animelem = 6
value = 820,2

[State 3150]
type = EnvShake
trigger1 = animelem = 6
ampl = -4
time = 10

[State 3150]
type = palfx
trigger1 = gametime%2 = 0
add=10,110,185
mul=10,110,255
time = 1
ignorehitpause = 1

[State 3150]
type = StateTypeSet
trigger1 = animelem = 3
statetype = A

[State 3150]
type = StateTypeSet
trigger1 = animelem = 6
statetype = S

[State 3150]
type = posset
trigger1 = animelem = 6, >= 0
y = 0

[State 3150]
type = VelSet
trigger1 = animelem = 6
x = 0
y = 0

[State 3150]
type = VelSet
trigger1 = animelem = 3
x = 4
y = -10

[State 3150]
type = Veladd
trigger1 = animelem = 3,>= 0
trigger1 = animelem = 6,< 0
y = .7

[State 871, Impact Dust]
type = Helper
trigger1 = NumTarget && Animelem = 6
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 82,0
facing = -1
ownPal = 1

[State 3150]
type = Helper
trigger1 = Animelem = 3
stateno = 3155
id = 3155
pos = -51,-81
postype = p1
ownpal = 1
sprpriority = 5

[State 3150]
type = Helper
trigger1 = time = 12
stateno = 3155
id = 3155
pos = -51,-81
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .8
size.yscale = .8

[State 3150]
type = Helper
trigger1 = time = 17
stateno = 3155
id = 3155
pos = -51,-81
postype = p1
ownpal = 1
sprpriority = 5
size.xscale = .6
size.yscale = .6

[State 3150]
type = Helper
trigger1 = animelem = 6
stateno = 3160
id = 3160
pos = 0,-10
postype = p1
ownpal = 1
sprpriority = 3
persistent = 0

[State 3150]
type = Helper
trigger1 = animelem = 6
stateno = 3170
id = 3170
pos = 0,-10
postype = p1
ownpal = 1
sprpriority = 3
persistent = 0

[State 3150]
type = Helper
trigger1 = animelem = 6
stateno = 3160
id = 3160
pos = 0,-10
postype = p1
ownpal = 1
sprpriority = 3
persistent = 0

[State 3150]
type = Helper
trigger1 = animelem = 6
stateno = 3170
id = 3170
pos = 0,-10
postype = p1
ownpal = 1
sprpriority = 3
persistent = 0

[State 3150, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 5
attr = A, HA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 70 < 7, 7, fvar(11) * 70)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -5,-5
ground.cornerpush.veloff = (1.3*-6)
air.cornerpush.veloff = (1.3*-6)
down.cornerpush.veloff = (1.3*-6)
guard.cornerpush.veloff = (1.3*-6)
airguard.cornerpush.veloff = (1.3*-6)
air.velocity = -3, -4
guard.velocity = -6
airguard.velocity = -4.5,-2
down.velocity = -3,-5
down.bounce = 1
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 194), var(36) := -30
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150]
type = TargetState
trigger1 = Movehit
value = 2600
persistent = 0
ignorehitpause = 1

[State 3150]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;========================<THUNDER BREAK>=============================
[Statedef 3155]
type = A
movetype = I
physics = N
ctrl = 0
velset = 0,0
anim = 3105
sprpriority = 5

[State 3105]
type = varset
trigger1 = time = 0
trigger2 = time = 18
fvar(15) = 0

[State 3105]
type = varset
trigger1 = time = 0
trigger2 = time = 18
fvar(16) = 0

[State 3105]
type = varadd
trigger1 = time < 18
fvar(15) = 51/18

[State 3105]
type = varadd
trigger1 = time < 18
fvar(16) = -(39/18)

[State 3105]
type = varadd
trigger1 = time >= 18
fvar(15) = 87/10

[State 3105]
type = varadd
trigger1 = time >= 18
fvar(16) = 111/10

[State 3105]
type = bindtoparent
trigger1 = time < 18
pos = -51+(fvar(15)),-81+(fvar(16))

[State 3105]
type = bindtoparent
trigger1 = time =[18,27]
pos = (fvar(15)),-120+(fvar(16))

[State 3105]
type = bindtoparent
trigger1 = time > 27
pos = 87,-9

[State 3105]
type = DestroySelf
trigger1 = Animtime = 0
trigger2 = root,Movetype = H
trigger3 = root,stateno != 3150

;========================<THUNDER BREAK>=============================
[Statedef 3160]
type = A
movetype = A
physics = N
juggle = 0
poweradd= 0
ctrl = 0
velset = 0,0
anim = 3110
sprpriority = 3

[State 3110]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3100, HitDef 2]
type = HitDef
trigger1 = !var(16) && var(15) < 2
trigger1 = Time = 0
attr = A, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 70 < 7, 7, fvar(11) * 70)), 8
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerpush.veloff = (1.3*-6)
air.cornerpush.veloff = (1.3*-6)
down.cornerpush.veloff = (1.3*-6)
guard.cornerpush.veloff = (1.3*-6)
airguard.cornerpush.veloff = (1.3*-6)
air.velocity = -3, -4
guard.velocity = -6
airguard.velocity = -4.5,-2
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := -1)
guardSound = -1 + 0 * (var(32) := -1)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 183), var(36) := -20
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 8)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ceil(P2Dist x), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3110]
type = TargetState
trigger1 = Movehit && enemy,stateno!= 2600
value = 2600
persistent = 0
ignorehitpause = 1

[State 3110]
type = TargetState
trigger1 = Movehit && enemy,stateno = 2600
value = 2650
persistent = 0
ignorehitpause = 1

[State 3110]
type = VelSet
trigger1 = 1
x = -5

[State 3110]
type = DestroySelf
trigger1 = backedgebodydist < -100

;========================<THUNDER BREAK>=============================
[Statedef 3170]
type = A
movetype = A
physics = N
juggle = 0
poweradd= 0
ctrl = 0
velset = 0,0
anim = 3120
sprpriority = 3

[State 3120]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3100, HitDef 3]
type = HitDef
trigger1 = !var(16) && var(15) < 3
trigger1 = Time = 0
attr = A, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 70 < 7, 7, fvar(11) * 70)), 8
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Up
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -5, -5
ground.cornerpush.veloff = (1.3*-6)
air.cornerpush.veloff = (1.3*-6)
down.cornerpush.veloff = (1.3*-6)
guard.cornerpush.veloff = (1.3*-6)
airguard.cornerpush.veloff = (1.3*-6)
air.velocity = -3, -4
guard.velocity = -6
airguard.velocity = -4.5,-2
yAccel = 0.5
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := -1)
guardSound = -1 + 0 * (var(32) := -1)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 185), var(36) := -20
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 8)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ceil(P2Dist x), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ceil(P2Dist x), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3120]
type = TargetState
trigger1 = Movehit && enemy,stateno!= 2600
value = 2600
persistent = 0
ignorehitpause = 1

[State 3120]
type = TargetState
trigger1 = Movehit && enemy,stateno = 2600
value = 2650
persistent = 0
ignorehitpause = 1

[State 3120]
type = VelSet
trigger1 = 1
x = 5

[State 3120]
type = DestroySelf
trigger1 = frontedgebodydist < -100

;========================<GELDENHEIM 3>=============================
[StateDef 3200]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3200, Super Pause FX]
type = Helper
trigger1 = Time = 0
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(10 * const(size.xScale)), ceil(-90 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = Time = 0
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200]
type = palfx
trigger1 = gametime%2 = 0
add=10,110,185
mul=10,110,255
time = 1
ignorehitpause = 1

[State 3200]
type = HitDef
triggerall=P2stateno!=40
triggerall=P2stateno!=[120,153]
triggerall = enemy,movetype != H
trigger1 = !var(16) && var(15) < 1
Trigger1 = animelem = 1
attr = S,HT
hitflag = M-
priority = 7, Miss
sparkno = -1
sprpriority = 1
p1facing = 1
p2facing = 1
sparkNo = -1 + 0 * (var(33) := 0)
hitSound = -1 + 0 * (var(31) := 800)
guardSound = -1 + 0 * (var(32) := 0)
p1stateno = 3201
p2stateno = 3205
numhits = 0

[State 3200]
type = playsnd
trigger1 = animelem = 3
value = 800,0

[State 3200, 2]
type = ChangeState
Trigger1 = AnimTime = 0
value =0
ctrl = 1

;========================<GELDENHEIM 3 CONECT>=============================
[Statedef 3201]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 3201
sprpriority = 2

[State 3210]
type = VarSet
trigger1 = time = 0
var(12) = 8

[State 3210]
type = PosAdd
trigger1 = time = 0
trigger1 = frontedgebodydist <= 100
x = -60

[State 3210]
type = palfx
trigger1 = gametime%2 = 0
add=10,110,185
mul=10,110,255
time = 1
ignorehitpause = 1

[State 3200]
type = playsnd
trigger1 = animelem = 1
value = 3200,0

[State 3200]
type = Helper
trigger1 = Animelem = 3
stateno = 3220
id = 3220
pos = 80,-213
postype = p1
ownpal = 1
sprpriority = 2
name = "hakase"

[State 3200]
type = Helper
trigger1 = Animelem = 3
stateno = 3230
id = 3230
pos = 200,-100
postype = p1
ownpal = 1
sprpriority = 2
name = "emiri"

[State 3210]
type = targetbind
trigger1 = animelem = 1
trigger2 = animelem = 3
pos = 60,-65

[State 3210]
type = targetbind
trigger1 = animelem = 2
pos = 87,-65

[State 3230]
type = Targetstate
trigger1 = numhelper(3220) = 1
trigger1 = numhelper(3230) = 1
trigger1 = helper(3220),stateno = 3221
trigger1 = helper(3230),stateno = 3231
value = 3206

[State 3210]
type = changestate
trigger1 = numhelper(3220) = 1
trigger1 = numhelper(3230) = 1
trigger1 = helper(3220),stateno = 3221
trigger1 = helper(3230),stateno = 3231
value = 3202

;========================<GELDENHEIM 3 CONTINUE>=============================
[Statedef 3202]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 3202
sprpriority = 2

[State 3230]
type = Targetstate
trigger1 = time = 0
value = 3206

[State 3210]
type = palfx
trigger1 = gametime%2 = 0
add=10,110,185
mul=10,110,255
time = 1
ignorehitpause = 1

[State 3015]
type = Explod
trigger1 = timemod = 10,0
anim = 3212
id = 3212
pos = 70,-20
vel = 0,5.5
postype = p1
sprpriority = 3
ownpal = 1
removeongethit = 1

[State 3210]
type = targetbind
trigger1 = animelem = 1
trigger2 = animelem = 3
pos = 60,-65

[State 3210]
type = targetbind
trigger1 = animelem = 2
pos = 87,-65

[State 3230]
type = playsnd
trigger1 = animelem = 3
value = 4,0

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 3
value = floor(ifElse(50 * fvar(11) < 7, -7, -50 * fvar(11)))
kill = 0

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 3
value = 0

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 3 && !var(20)
value = 0

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 3
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 3
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 3
var(16) = 1
ignoreHitPause = 1

[State 3230]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1000,2

[State 3230]
type = VarAdd
trigger1 = 1
var(12) = -1
persistent = 0

[State 3230]
type = changestate
trigger1 = animtime = 0
trigger1 = var(12) > 0
value = 3202

[State 3230]
type = changestate
trigger1 = animtime = 0
trigger1 = var(12) <= 0
value = 3203

;========================<GELDENHEIM 3 CONTINUE>=============================
[Statedef 3203]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 3203
sprpriority = 2

[State 3250]
type = targetstate
trigger1 = time = 0
value = 3207

[State 3230]
type = changestate
trigger1 = animtime = 0
value = 3210

;========================<GELDENHEIM 3 PLAYER 2>=============================
[Statedef 3205]
type = A
movetype = H
physics = N
velset = 0,0

[State 3220, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3205

[STate 3220]
type = screenbound
trigger1 = 1
value = 1
movecamera = 1,0

;========================<GELDENHEIM 3 PLAYER 2>=============================
[Statedef 3206]
type = A
movetype = H
physics = N
velset = 0,0

[State 3240, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3206

[State 3240]
type = ChangeAnim2
triggerall = anim != 3207
triggerall = SelfAnimExist(9011) = 1
trigger1 = AuthorName = "Tin" || AuthorName = "Mouser" || AuthorName = "H�h" || AuthorName = "adamskie"
trigger2 = AuthorName = "M.M.R." || AuthorName = "ryokucha" || AuthorName = "Bad Darkness" || AuthorName = "Third"
trigger3 = AuthorName = "CAMRAT Type KOF"
value = 3207

[STate 3240]
type = screenbound
trigger1 = 1
value = 1
movecamera = 1,0

[State 3240]
type = PalFX
trigger1 = AnimElem = 3 && anim = 3206
time = 12
add = 159,159,150
sinadd = 20,20,130,5
mul = 81,82,150
invertall = 0
color = 0

;========================<GELDENHEIM 3 PLAYER 2>=============================
[Statedef 3207]
type = A
movetype = H
physics = N
velset = 0,0

[State 3260]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3208

[STate 3260]
type = screenbound
trigger1 = 1
value = 1
movecamera = 1,0

;========================<GELDENHEIM 3 PLAYER 2>=============================
[Statedef 3210]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
ctrl = 0
anim = 820
sprpriority = 2

[State 3250]
type = targetstate
trigger1 = time = 0
value = 815

[State 3250]
type = targetbind
trigger1 = animelem = 1,>= 0
trigger1 = animelem = 2,< 0
trigger2 = animelem = 3,>= 0
trigger2 = animelem = 4,< 0
pos = 60,-75

[State 3250]
type = targetbind
trigger1 = animelem = 2,>= 0
trigger1 = animelem = 3,< 0
pos = 70,-75

[State 3250]
type = targetbind
trigger1 = animelem = 4,>= 0
trigger1 = animelem = 5,< 0
pos = 10,-75

[State 3250]
type = targetbind
trigger1 = animelem = 5,>= 0
trigger1 = animelem = 6,< 0
pos = -40,-70

[State 3250]
type = targetbind
trigger1 = animelem = 6,>= 0
trigger1 = animelem = 7,< 0
pos = 30,-75

[State 3250]
type = targetbind
trigger1 = animelem = 7,>= 0
trigger1 = animelem = 8,< 0
pos = 85,-75

[State 3250]
type = targetbind
trigger1 = animelem = 8
pos = 85,-75

[State 3250]
type = sprpriority
trigger1 = animelem = 6
value = -2

[State 3250]
type = sprpriority
trigger1 = animelem = 8
value = 2

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 8
value = floor(ifElse(80 * fvar(11) < 7, -7, -80 * fvar(11)))

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 8
value = 0

[State 810, Power]
type = PowerAdd
trigger1 = NumTarget && AnimElem = 8 && !var(20)
value = 0

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 8
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = NumTarget && AnimElem = 8
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = NumTarget && AnimElem = 8
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = NumTarget && AnimElem = 8
var(16) = 1
ignoreHitPause = 1

[State 3250]
type = PlaySnd
trigger1 = animelem = 5
value = 820,0

[State 3250]
type = changestate
trigger1 = animtime = 0 && Anim = 820
value = 3211

[State 3250]
type = changestate
trigger1 = animtime = 0 && Anim = 195
value = 0
ctrl = 1

;========================<GELDENHEIM 3 FINISH>=============================
[Statedef 3211]
type = S
ctrl = 0
anim = 196
velset = 0,0
movetype = I
physics = S
sprpriority = 2

[State 3251]
type = playsnd
trigger1 = animelem = 1
value = 196,0
channel = 0

[State 3251]
type = ChangeState
trigger1 = time = 76
value = 0
ctrl = 1

;========================<GELDENHEIM 3 PLAYER 2>=============================
[Statedef 3207]
type = A
movetype = H
physics = N
velset = 0,0

[State 3255, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 825

[STate 3255]
type = screenbound
trigger1 = 1
value = 1
movecamera = 1,0

[State 3255, 1]
type = Velset
Trigger1 = animelem = 9
x = -8
y = -5

[State 3255, 1]
type = VelAdd
Trigger1 = animelem = 9 ,>= 0
y = .4

[State 3255, 4]
type = SelfState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -30
value = 5100 ;Hit ground

;========================<GELDENHEIM 3 HELPER>=============================
[Statedef 3220]
type = A
movetype = I
physics = N
juggle = 0
velset = 0,0
ctrl = 0
anim = 3007
sprpriority = 2

[State 3260]
type = VelSet
trigger1 = 1
y = 3

[State 3260]
type = ChangeState
trigger1 = animtime = 0
value = 3221

;========================<GELDENHEIM 3 HELPER>=============================
[Statedef 3221]
type = A
movetype = I
physics = N
juggle = 0
velset = 0,0
ctrl = 0
anim = 3008
sprpriority = 2

[State 3261]
type = BindToParent
trigger1 = 1
pos = 90,-40

[State 3261]
type = changeanim
trigger1 = root,stateno = 3202
value = 3210
persistent = 0

[State 3000]
type = Explod
triggerall = Anim = 3210
trigger1 = animelem = 3
trigger2 = animelem = 17
anim = 3030
pos = -20,50
postype = p1
sprpriority = 4
bindtime = -1
ownpal = 1
shadow = 0,0,0
removeongethit = 1

[State 3000]
type = Explod
triggerall = Anim = 3210
trigger1 = animelem = 3
trigger2 = animelem = 17
anim = 3031
pos = -20,50
postype = p1
sprpriority = 4
bindtime = -1
ownpal = 1
shadow = 0,0,0
removeongethit = 1

[State 3261]
type = changestate
trigger1 = animtime = 0 && Anim = 3210
value = 3221

[State 3261]
type = changestate
trigger1 = root,stateno = 3203
value = 3222

;========================<GELDENHEIM 3 HELPER>=============================
[Statedef 3222]
type = A
movetype = I
physics = N
juggle = 0
velset = 0,0
ctrl = 0
anim = 3008
sprpriority = 2

[State 3261]
type = BindToParent
trigger1 = 1
pos = 90,-40

[State 3261]
type = changestate
trigger1 = root,stateno = 3210
value = 3223

;========================<GELDENHEIM 3 PLAYER 2>=============================
[Statedef 3223]
type = A
movetype = I
physics = N
ctrl = 0
sprpriority = -2
poweradd = 0
velset = 0,0
anim = 3003

[State 3262]
type = BindToParent
trigger1 = animelem = 8, < 0
pos = 70,-143
time = 1
facing = 1

[State 3262]
type = velset
trigger1 = animelem = 8
y = -4

[State 3262]
type = Destroyself
trigger1 = animtime = 0

;========================<GELDENHEIM 3 HELPER>=============================
[Statedef 3230]
type = A
movetype = I
physics = N
juggle = 0
velset = 0,0
ctrl = 0
anim = 3050
sprpriority = 2

[State 3270]
type = VelSet
trigger1 = animelem = 23
x = -2

[State 3270]
type = ChangeState
trigger1 = time = 54
value = 3231

;========================<GELDENHEIM 3 HELPER>=============================
[Statedef 3231]
type = A
movetype = I
physics = N
juggle = 0
velset = 0,0
ctrl = 0
anim = 3050
sprpriority = 2

[State 3271]
type = changeanim
trigger1 = time = 0
value = 3050
elem = 23

[State 1802]
type = varset
trigger1 = fvar(16) = 0
var(46) = 0

[State 1802]
type = varset
trigger1 = fvar(16) = 360
var(46) = 1

[State 1802]
type = varadd
trigger1 = var(46) = 0
fvar(16) = .1

[State 1802]
type = varadd
trigger1 = var(46) = 1
fvar(16) = -.1

[State 1802]
type = varset
trigger1 = 1
fvar(15) = cos(fvar(16))

[State 1802]
type = velset
trigger1 = 1
y = fvar(15)

[State 3261]
type = changestate
trigger1 = root,stateno = 3203
value = 3232

;========================<GELDENHEIM 3 HELPER>=============================
[Statedef 3232]
type = A
movetype = I
physics = N
juggle = 0
velset = 0,0
ctrl = 0
anim = 3050
sprpriority = 2

[State 3271]
type = changeanim
trigger1 = time = 0
value = 3050
elem = 23

[State 3272]
type = playsnd
trigger1 = time = 0
value = 190,0

[State 1802]
type = varset
trigger1 = fvar(16) = 0
var(46) = 0

[State 1802]
type = varset
trigger1 = fvar(16) = 360
var(46) = 1

[State 1802]
type = varadd
trigger1 = var(46) = 0
fvar(16) = .1

[State 1802]
type = varadd
trigger1 = var(46) = 1
fvar(16) = -.1

[State 1802]
type = varset
trigger1 = 1
fvar(15) = cos(fvar(16))

[State 1802]
type = velset
trigger1 = 1
y = fvar(15)

[State 3261]
type = changestate
trigger1 = root,stateno = 3210
value = 3233

;========================<GELDENHEIM 3 HELPER>=============================
[Statedef 3233]
type = A
movetype = I
physics = N
juggle = 0
velset = 0,0
ctrl = 0
anim = 3051
sprpriority = 2

[State 3272]
type = Destroyself
trigger1 = animtime = 0

;========================<GIGA BRUTE>=============================
[StateDef 3300]
type = S
physics = N
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3300, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3300, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3300, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3300, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3300, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3300, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3300, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3300, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3300, Super Pause FX]
type = Helper
trigger1 = Animelem = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-95 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3300, SuperPause]
type = SuperPause
trigger1 = Animelem = 3
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3310]
type = posadd
trigger1 = time = 0
x = 10

[State 3300]
type = PlaySnd
trigger1 = animelem = 2
value = 4,4
channel = 0

[State 3300]
type = PlaySnd
trigger1 = animelem = 5
value = 1,5

[State 3300]
type = palfx
trigger1 = gametime%2 = 0
add=10,110,185
mul=10,110,255
time = 1
ignorehitpause = 1

[State 3300, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 7
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 70 < 7, 7, fvar(11) * 70)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Heavy
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -5,0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 146), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3300]
type = targetstate
trigger1 = movehit
value = 3305
ignorehitpause = 1
persistent = 0

[State 3300]
type = changestate
trigger1 = movehit
value = 3301

[State 3300]
type = changestate
trigger1 = Animtime = 0
value = 0
ctrl = 1

;========================<GIGA BRUTE CONECT>=============================
[Statedef 3301]
type = S
movetype = A
physics = S
juggle = 7
poweradd = 0
ctrl = 0
velset = 0,0
anim = 3301
sprpriority = 2

[State 3310]
type = posadd
trigger1 = time = 0 && frontedgebodydist <= 80
x = -50

[State 3310]
type = targetstate
trigger1 = time = 0
value = 3305

[State 3310]
type = targetbind
trigger1 = time = 0
pos = 60,0

[State 3310]
type = palfx
trigger1 = gametime%2 = 0
add=10,110,185
mul=10,110,255
time = 1
ignorehitpause = 1

[State 3310]
type = targetstate
trigger1 = animelem = 21
value = 3306

[State 3310]
type = targetstate
trigger1 = animelem = 16
trigger2 = animelem = 28
value = 3307

[State 3310]
type = targetstate
trigger1 = animelem = 37
value = 3308

[State 3310]
type = Playsnd
trigger1 = animelem = 8
value = 1000,1

[State 3310]
type = Playsnd
trigger1 = animelem = 16
trigger2 = animelem = 28
value = s2,2

[State 3310]
type = Playsnd
trigger1 = animelem = 21
value = s2,5

[State 3310]
type = Playsnd
trigger1 = animelem = 37
value = s820,2

[State 3310]
type = EnvShake
trigger1 = animelem = 16
trigger2 = animelem = 21
trigger3 = animelem = 28
trigger5 = animelem = 37
ampl = -6
time = 9

[State 810, Damage]
type = TargetLifeAdd
trigger1 = animelem = 16
trigger2 = animelem = 21
trigger3 = animelem = 28
value = floor(ifElse(50 * fvar(11) < 7, -7, -50 * fvar(11)))
Kill = 0

[State 810, Damage]
type = TargetLifeAdd
trigger1 = animelem = 37
value = floor(ifElse(50 * fvar(11) < 7, -7, -50 * fvar(11)))

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = animelem = 16
trigger2 = animelem = 21
trigger3 = animelem = 28
trigger4 = animelem = 37
value = 0

[State 810, Power]
type = PowerAdd
trigger1 = animelem = 16 && !var(20)
trigger2 = animelem = 21 && !var(20)
trigger3 = animelem = 28 && !var(20)
trigger4 = animelem = 37 && !var(20)
value = 0

[State 810, HitAdd]
type = HitAdd
trigger1 = animelem = 16
trigger2 = animelem = 21
trigger3 = animelem = 28
trigger4 = animelem = 37
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = animelem = 16
trigger2 = animelem = 21
trigger3 = animelem = 28
trigger4 = animelem = 37
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = animelem = 16
trigger2 = animelem = 21
trigger3 = animelem = 28
trigger4 = animelem = 37
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = animelem = 16
trigger2 = animelem = 21
trigger3 = animelem = 28
trigger4 = animelem = 37
var(16) = 1
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 16
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(77 * const(size.xScale)), ceil(-63 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 21
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(96 * const(size.xScale)), ceil(-68 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 28
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(96 * const(size.xScale)), ceil(-53 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 37
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(86 * const(size.xScale)), ceil(-63 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3310]
type = changestate
trigger1 = Animtime = 0
value = 0
ctrl = 1

;========================<GIGA BRUTE PLAYER 2>=============================
[Statedef 3305]
type = A
movetype = H
physics = N
velset = 0,0

[State 3320, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3305

[State 3320]
type = ChangeAnim2
triggerall = Time = 0
triggerall = SelfAnimExist(9010) = 1
trigger1 = AuthorName = "Tin" || AuthorName = "Mouser" || AuthorName = "H�h" || AuthorName = "adamskie"
trigger2 = AuthorName = "M.M.R." || AuthorName = "ryokucha" || AuthorName = "Bad Darkness" || AuthorName = "Third"
trigger3 = AuthorName = "CAMRAT Type KOF" || AuthorName = "keyu"
value = 3306

[State 3320]
type = null;ChangeAnim2
triggerall = Time = 0
trigger1 = AuthorName = "M.M.R." && name = "Lilith"
value = 3326

[State 3320]
type = null;ChangeAnim2
triggerall = Time = 0
trigger1 = AuthorName = "Third" && name = "Anakaris By Third"
value = 3327

[State 3320]
type = PalFX
trigger1 = timemod = 5,0
trigger1 = Anim = 3320
time = 5
add = 159,159,150
sinadd = 20,20,130,5
mul = 81,82,150
invertall = 0
color = 0

[STate 3320]
type = screenbound
trigger1 = 1
value = 1
movecamera = 1,0

[State 3320, 4]
type = SelfState
trigger1 = time >= 200
value = 5100

;========================<GIGA BRUTE PLAYER 2>=============================
[Statedef 3306]
type = A
movetype = H
physics = N
velset = 0,0

[State 3340]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3307

;========================<GIGA BRUTE PLAYER 2>=============================
[Statedef 3307]
type = A
movetype = H
physics = N
velset = 0,0

[State 3345]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3308

;========================<GIGA BRUTE PLAYER 2>=============================
[Statedef 3308]
type = A
movetype = H
physics = N
velset = 0,0

[State 3350]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3309

[State 3350]
type = velset
trigger1 = Anim = 3309
trigger1 = Animelem = 2
y = -25
x = -1

[State 3350]
type = veladd
trigger1 = Anim = 3309
trigger1 = Animelem = 2,>= 0
trigger2 = Anim = 3310
y = .5

[State 3350]
type = changeanim2
trigger1 = Anim = 3309
trigger1 = vel Y > 0
value = 3310

[State 3350]
type = SelfState
trigger1 = Anim = 3310
trigger1 = Pos Y >= 5 && Vel Y > 0
value = 5100

;========================<MAX GIGA BRUTE>=============================
[StateDef 3350]
type = S
physics = N
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3350, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3350, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3350, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3350, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3350, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3350, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3350, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3300, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3300, Super Pause FX]
type = Helper
trigger1 = Animelem = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-95 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3300, SuperPause]
type = SuperPause
trigger1 = Animelem = 3
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3310]
type = posadd
trigger1 = time = 0
x = 10

[State 3300]
type = PlaySnd
trigger1 = animelem = 2
value = 4,4
channel = 0

[State 3300]
type = PlaySnd
trigger1 = animelem = 5
value = 1,5

[State 3300]
type = palfx
trigger1 = gametime%2 = 0
add=10,110,185
mul=10,110,255
time = 1
ignorehitpause = 1

[State 3300, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 7
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 55 < 7, 7, fvar(11) * 55)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Heavy
air.animType = Heavy
fall.animType = Up
ground.type = High
air.type = High
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -5,0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -3, -4
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 146), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3300]
type = targetstate
trigger1 = movehit
value = 3305
ignorehitpause = 1
persistent = 0

[State 3300]
type = changestate
trigger1 = movehit
value = 3351

[State 3300]
type = changestate
trigger1 = Animtime = 0
value = 0
ctrl = 1

;========================<MAX GIGA BRUTE CONECT>=============================
[Statedef 3351]
type = S
movetype = A
physics = S
juggle = 7
poweradd = 0
ctrl = 0
velset = 0,0
anim = 3351
sprpriority = 2

[State 3310]
type = posadd
trigger1 = time = 0 && frontedgebodydist <= 80
x = -50

[State 3310]
type = targetstate
trigger1 = time = 0
value = 3305

[State 3310]
type = targetbind
trigger1 = time = 0
pos = 60,0

[State 3310]
type = palfx
trigger1 = gametime%2 = 0
add=10,110,185
mul=10,110,255
time = 1
ignorehitpause = 1

[State 3310]
type = targetstate
trigger1 = animelem = 17
trigger2 = animelem = 26
trigger3 = animelem = 40
value = 3306

[State 3310]
type = targetstate
trigger1 = animelem = 21
trigger2 = animelem = 33
trigger3 = animelem = 45
value = 3307

[State 3310]
type = targetstate
trigger1 = animelem = 54
value = 3308

[State 3310]
type = Playsnd
trigger1 = animelem = 8
value = 1000,1

[State 3310]
type = Playsnd
trigger1 = animelem = 21
trigger2 = animelem = 33
trigger3 = animelem = 45
value = s2,2

[State 3310]
type = Playsnd
trigger1 = animelem = 17
trigger2 = animelem = 26
trigger3 = animelem = 40
value = s2,5

[State 3310]
type = Playsnd
trigger1 = animelem = 54
value = s820,2

[State 3310]
type = EnvShake
trigger1 = animelem = 17
trigger2 = animelem = 21
trigger3 = animelem = 26
trigger4 = animelem = 33
trigger5 = animelem = 40
trigger6 = animelem = 45
trigger7 = animelem = 54
ampl = -6
time = 9

[State 810, Damage]
type = TargetLifeAdd
trigger1 = animelem = 17
trigger2 = animelem = 21
trigger3 = animelem = 26
trigger4 = animelem = 33
trigger5 = animelem = 40
trigger6 = animelem = 45
value = floor(ifElse(45 * fvar(11) < 7, -7, -45 * fvar(11)))
Kill = 0

[State 810, Damage]
type = TargetLifeAdd
trigger1 = animelem = 54
value = floor(ifElse(45 * fvar(11) < 7, -7, -45 * fvar(11)))

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = animelem = 17
trigger2 = animelem = 21
trigger3 = animelem = 26
trigger4 = animelem = 33
trigger5 = animelem = 40
trigger6 = animelem = 45
trigger7 = animelem = 54
value = 0

[State 810, Power]
type = PowerAdd
trigger1 = animelem = 17 && !var(20)
trigger2 = animelem = 21 && !var(20)
trigger3 = animelem = 26 && !var(20)
trigger4 = animelem = 33 && !var(20)
trigger5 = animelem = 40 && !var(20)
trigger6 = animelem = 45 && !var(20)
trigger7 = animelem = 54 && !var(20)
value = 0

[State 810, HitAdd]
type = HitAdd
trigger1 = animelem = 17
trigger2 = animelem = 21
trigger3 = animelem = 26
trigger4 = animelem = 33
trigger5 = animelem = 40
trigger6 = animelem = 45
trigger7 = animelem = 54
value = 1

[State 810, HitCount]
type = VarAdd
trigger1 = animelem = 17
trigger2 = animelem = 21
trigger3 = animelem = 26
trigger4 = animelem = 33
trigger5 = animelem = 40
trigger6 = animelem = 45
trigger7 = animelem = 54
var(13) = 1

[State 810, Juggle]
type = VarAdd
trigger1 = animelem = 17
trigger2 = animelem = 21
trigger3 = animelem = 26
trigger4 = animelem = 33
trigger5 = animelem = 40
trigger6 = animelem = 45
trigger7 = animelem = 54
var(15) = 1
ignoreHitPause = 1

[State 810, Juggle]
type = VarSet
trigger1 = animelem = 17
trigger2 = animelem = 21
trigger3 = animelem = 26
trigger4 = animelem = 33
trigger5 = animelem = 40
trigger6 = animelem = 45
trigger7 = animelem = 54
var(16) = 1
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 17
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(77 * const(size.xScale)), ceil(-60 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 21
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(77 * const(size.xScale)), ceil(-63 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 26
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(96 * const(size.xScale)), ceil(-68 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 33
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(96 * const(size.xScale)), ceil(-53 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 40
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(96 * const(size.xScale)), ceil(-95 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 45
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(96 * const(size.xScale)), ceil(-70 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 871, Hit Spark]
type = Helper
trigger1 = animelem = 54
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(86 * const(size.xScale)), ceil(-63 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3310]
type = changestate
trigger1 = Animtime = 0
value = 0
ctrl = 1
