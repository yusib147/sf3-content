[Command]
name = "AI0"
command = a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a
time = 0
[Command]
name = "AI1"
command = b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b
time = 0
[Command]
name = "AI2"
command = c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c
time = 0
[Command]
name = "AI3"
command = x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x
time = 0
[Command]
name = "AI4"
command = y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y
time = 0
[Command]
name = "AI5"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI6"
command = s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s
time = 0
[Command]
name = "AI7"
command = F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F
time = 0
[Command]
name = "AI8"
command = D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D
time = 0
[Command]
name = "AI9"
command = B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B
time = 0
[Command]
name = "AI10"
command = U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U
time = 0
[Command]
name = "AI11"
command = a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a
time = 0
[Command]
name = "AI12"
command = c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c
time = 0
[Command]
name = "AI13"
command = x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x
time = 0
[Command]
name = "AI14"
command = y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y
time = 0
[Command]
name = "AI15"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI16"
command = s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s
time = 0
[Command]
name = "AI17"
command = a,B,c,x,y,z,s,B,D,F,U,a,b,c,x,y,z,s,s
time = 0
[Command]
name = "AI18"
command = a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a
time = 0
[Command]
name = "AI19"
command = b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b
time = 0
[Command]
name = "AI20"
command = c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c
time = 0
[Command]
name = "AI21"
command = x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x
time = 0
[Command]
name = "AI22"
command = y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y
time = 0
[Command]
name = "AI23"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI24"
command = s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s
time = 0
[Command]
name = "AI25"
command = F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F
time = 0
[Command]
name = "AI26"
command = D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D
time = 0
[Command]
name = "AI27"
command = B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B
time = 0
[Command]
name = "AI28"
command = U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U,U
time = 0
[Command]
name = "AI29"
command = a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a
time = 0
[Command]
name = "AI30"
command = c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c
time = 0
[Command]
name = "AI31"
command = x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x
time = 0
[Command]
name = "AI32"
command = y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y,y
time = 0
[Command]
name = "AI33"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI34"
command = s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s
time = 0
[Command]
name = "AI35"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI36"
command = z,z,z,z,z,z,a,a,a,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI37"
command = z,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,z,z,z
time = 0
[Command]
name = "AI38"
command = z,z,z,z,z,a,a,a,z,z,z,z,z,a,a,a,z,z,z
time = 0
[Command]
name = "AI39"
command = z,z,z,z,z,a,a,a,z,z,z,z,z,z,a,a,z,z,z
time = 0
[Command]
name = "AI40"
command = z,z,z,z,a,a,a,z,z,z,z,a,z,z,a,a,z,z,z
time = 0
[Command]
name = "AI41"
command = z,z,z,a,z,z,z,z,z,z,z,z,z,a,a,z,z,z,z
time = 0
[Command]
name = "AI42"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI43"
command = z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,z,a,a,z
time = 0
[Command]
name = "AI44"
command = z,z,a,a,a,a,z,z,z,z,z,z,z,z,z,a,a,a,z
time = 0
[Command]
name = "AI45"
command = z,z,z,z,z,z,a,a,z,z,z,z,z,a,a,a,a,z,z
time = 0
[Command]
name = "AI46"
command = z,z,z,z,z,z,z,z,a,a,a,a,a,a,z,z,z,z,z
time = 0
[Command]
name = "AI47"
command = z,z,z,a,a,a,a,z,z,z,z,z,z,z,z,z,z,z,z
time = 0
[Command]
name = "AI48"
command = z,z,z,z,z,a,a,a,z,z,z,a,a,a,z,z,a,z,a
time = 0
[Command]
name = "AI49"
command = z,z,z,z,a,a,a,z,z,z,z,z,a,a,a,z,z,z,z
time = 0
[Command]
name = "AI50"
command = z,z,z,a,a,z,z,z,z,z,z,z,z,z,a,a,z,z,z
time = 0
[command]
name="fwd"
command=F
time=1
[command]
name="back"
command=B
time=1
[command]
name="up"
command=U
time=1
[command]
name="down"
command=D
time=1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "dameoshi"
command = ~D, DF, F, x+y
time = 18

[Command]
name = "dameoshi"
command = ~D, DF, F, y+z
time = 18

[Command]
name = "dameoshi"
command = ~D, DF, F, z+x
time = 18

[Command]
name = "dameoshi"
command = ~D, DF, F, x+y+z
time = 18

[Command]
name = "dameoshi"
command = ~D, DF, F, b
time = 18

[Command]
name = "zettaini"
command = ~D, DB, B, x+y
time = 18

[Command]
name = "zettaini"
command = ~D, DB, B, y+z
time = 18

[Command]
name = "zettaini"
command = ~D, DB, B, z+x
time = 18

[Command]
name = "zettaini"
command = ~D, DB, B, x+y+z
time = 18

[Command]
name = "zettaini"
command = ~D, DB, B, b
time = 18

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "kiren1"
command = ~D, DF, F, x
time = 12

[Command]
name = "kiren2"
command = ~D, DF, F, y
time = 12

[Command]
name = "kiren3"
command = ~D, DF, F, z
time = 12

[Command]
name = "tatsujin1"
command = ~F, D, DF, x
time = 15

[Command]
name = "tatsujin2"
command = ~F, D, DF, y
time = 15

[Command]
name = "tatsujin3"
command = ~F, D, DF, z
time = 15

[Command]
name = "oboeta"
command = ~D, DB, B, x
time = 12

[Command]
name = "oboeta"
command = ~D, DB, B, y
time = 12

[Command]
name = "oboeta"
command = ~D, DB, B, z
time = 12

[Command]
name = "spit"
command = ~D, DF, F, a
time = 12

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 18

[Command]
name = "FF"     
command = F, F
time = 12

[Command]
name = "BB"     
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+y
time = 5

[Command]
name = "recovery"
command = y+z
time = 5

[Command]
name = "recovery"
command = z+x
time = 5

[Command]
name = "recovery"
command = x+y+z
time = 5

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "back"
command = B
time = 1

[Command]
name = "down"
command = $D
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;---------------------------------------------------------------------------
[State -3, AI�t���O�Z�b�g]
type = VarSet
triggerall = var(58) = 0
triggerall = RoundState = [1,2]
trigger1 = Command = "AI0"
trigger2 = Command = "AI1"
trigger3 = Command = "AI2"
trigger4 = Command = "AI3"
trigger5 = Command = "AI4"
trigger6 = Command = "AI5"
trigger7 = Command = "AI6"
trigger8 = Command = "AI7"
trigger9 = Command = "AI8"
trigger10 = Command = "AI9"
trigger11 = Command = "AI10"
trigger12 = Command = "AI11"
trigger13 = Command = "AI12"
trigger14 = Command = "AI13"
trigger15 = Command = "AI14"
trigger16 = Command = "AI15"
trigger17 = Command = "AI16"
trigger18 = Command = "AI17"
trigger19 = Command = "AI18"
trigger20 = Command = "AI19"
trigger21 = Command = "AI20"
trigger22 = Command = "AI21"
trigger23 = Command = "AI22"
trigger24 = Command = "AI23"
trigger25 = Command = "AI24"
trigger26 = Command = "AI25"
trigger27 = Command = "AI26"
trigger28 = Command = "AI27"
trigger29 = Command = "AI28"
trigger30 = Command = "AI29"
trigger31 = Command = "AI30"
trigger32 = Command = "AI31"
trigger33 = Command = "AI32"
trigger34 = Command = "AI33"
trigger35 = Command = "AI34"
trigger36 = Command = "AI35"
trigger37 = Command = "AI36"
trigger38 = Command = "AI37"
trigger39 = Command = "AI38"
trigger40 = Command = "AI39"
trigger41 = Command = "AI40"
trigger42 = Command = "AI41"
trigger43 = Command = "AI42"
trigger44 = Command = "AI43"
trigger45 = Command = "AI44"
trigger46 = Command = "AI45"
trigger47 = Command = "AI46"
trigger48 = Command = "AI47"
trigger49 = Command = "AI48"
trigger50 = Command = "AI49"
trigger51 = Command = "AI50"
trigger52 = helper(10000),var(58) = 1
var(58) = 1

[State -3, AI���x���Z�b�g]
type = VarSet
trigger1 = var(58) = 1
var(49) =200150 ;�����̐��l��ύX

;��3�P�^���U�����x���A��3�P�^���h�䃌�x���B
;�U�����x�����オ��ƍU���I�ȍs���������A�h�䃌�x�����オ��Ɩh��I�ȍs����������B
;���Ԍo�߂Ƌ��ɍU�����x�����������オ�邪�A�h�䃌�x���͕ς��Ȃ��B
;�u���������v�𐬌�������Ɨ����̃��x�����オ��B���łɉ����Ă����Z�ł�����������΂�����Ƃ����オ��B
;�܂��A���x���Ƃ͕ʂɁA�u���������v�ŉ��������ɉ����ē���ȍs����������Ƒ�����B
;���x�����オ�肷����ƒ����������Ȃ葝����̂Œ��ӁB

[State -3, ��O���@�U�����x��]
type = VarSet
trigger1 = var(58) = 1
trigger1 = var(50) = 0
var(50) = var(49)/1000

[State -3, ���O���@�h�䃌�x��]
type = VarSet
trigger1 = var(58) = 1
trigger1 = var(51) = 0
var(51) = var(49)-(1000*var(50))

;��΂ɕ�����̂��b
[State -1, Taunt]
type = ChangeState
value = 3000
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "zettaini"
triggerall = statetype != A
triggerall = power >= 1000
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200 && (var(48) != 1&&var(48) != 2)
trigger3 = StateNo = 210 && (var(48) != 1&&var(48) != 2)
trigger4 = StateNo = 220 && (var(48) != 1&&var(48) != 2)
trigger5 = StateNo = 230 && (var(48) != 1&&var(48) != 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420 && (var(48) != 1&&var(48) != 2)
trigger9 = StateNo = 205 && (var(48) != 1&&var(48) != 2)
trigger10 = StateNo = 215 && (var(48) != 1&&var(48) != 2)
trigger11 = StateNo = 225 && (var(48) != 1&&var(48) != 2)
trigger12 = StateNo = 235 && (var(48) != 1&&var(48) != 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425 && (var(48) != 1&&var(48) != 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;---------------------------------------------------------------------------
;��΂ɕ�����̂��b�i���L�����Z���Łj
[State -1, Taunt]
type = ChangeState
value = 3050
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "zettaini"
triggerall = statetype != A
triggerall = power >= 1000
trigger1 = StateNo = 200 && (var(48) = 1||var(48) = 2)
trigger2 = StateNo = 210 && (var(48) = 1||var(48) = 2)
trigger3 = StateNo = 220 && (var(48) = 1||var(48) = 2)
trigger4 = StateNo = 230 && (var(48) = 1||var(48) = 2)
trigger5 = StateNo = 420 && (var(48) = 1||var(48) = 2)
trigger6 = StateNo = 205 && (var(48) = 1||var(48) = 2)
trigger7 = StateNo = 215 && (var(48) = 1||var(48) = 2)
trigger8 = StateNo = 225 && (var(48) = 1||var(48) = 2)
trigger9 = StateNo = 235 && (var(48) = 1||var(48) = 2)
trigger10 = StateNo = 425 && (var(48) = 1||var(48) = 2)

;---------------------------------------------------------------------------
;�_�������ƌ�������b
[State -1, Taunt]
type = ChangeState
value = 3100
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "dameoshi"
triggerall = statetype != A
triggerall = power >= 1000
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;===========================================================================
;---------------------------------------------------------------------------
;�B�l�񓁗�
[State -1, Taunt]
type = ChangeState
value = 1000
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "tatsujin1" || command = "tatsujin2" || command = "tatsujin3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;---------------------------------------------------------------------------
;�S�A�a
[State -1, Taunt]
type = ChangeState
value = 1200
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "kiren1" || command = "kiren2" || command = "kiren3"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;---------------------------------------------------------------------------
;�������b�I
[State -1, Taunt]
type = ChangeState
value = 1300
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "oboeta"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;---------------------------------------------------------------------------
;�`�����I�b�c�X�s�b�g
[State -1, Taunt]
type = ChangeState
value = 1100
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "spit"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201
trigger19 = StateNo = 1250; && (var(41) = 1||var(41) = 2)
trigger20 = StateNo = 1260; && (var(41) = 1||var(41) = 2)

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = 311
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "tatsujin1" || command = "tatsujin2" || command = "tatsujin3"
triggerall = prevstateno != [810,811]
trigger1 = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
ignorehitpause = 1

;---------------------------------------------------------------------------
;�A�h�o���V���O�K�[�h
[State -1]
type = ChangeState
value = 810
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "recovery" || command = "b"
triggerall = prevstateno != [810,811]
trigger1 = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
ignorehitpause = 1

;---------------------------------------------------------------------------
;����2
[State -1, Taunt]
type = ChangeState
value = 196
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = command = "holdfwd" && command = "start"
triggerall = statetype != A
trigger1 = ctrl

;---------------------------------------------------------------------------
;����1
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl

;---------------------------------------------------------------------------
;����
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(59) = 0
triggerall = var(58) = 0
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 0
triggerall = var(58) = 0
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��荞��
[State -1]
type = ChangeState
value = 800
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "recovery" || command = "b"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = (command = "holdfwd" || command = "holdback") && command = "z"
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
triggerall = P2bodyDist X <= 6
trigger1 = p2statetype = S || p2statetype = C
trigger1 = p2movetype != H

;---------------------------------------------------------------------------
;���o�[��X�^���h�U��
[State -1, Taunt]
type = ChangeState
value = 320
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "holdback" && command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;---------------------------------------------------------------------------
;���o�[�O�X�^���h�U��
[State -1, Taunt]
type = ChangeState
value = 310
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "holdfwd" && command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;---------------------------------------------------------------------------
;�����X�^���h�U��
[State -1, Taunt]
type = ChangeState
value = 300
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;---------------------------------------------------------------------------
;���Ⴊ�݃X�^���h�U��
[State -1, Taunt]
type = ChangeState
value = 500
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;---------------------------------------------------------------------------
;�W�����v�X�^���h�U��
[State -1]
type = ChangeState
value = 700
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = StateNo = 600; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 610; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 620; && (var(41) = 1||var(41) = 2)

;---------------------------------------------------------------------------
;���o�[�O�������U���i�����j
[State -1, Taunt]
type = ChangeState
value = 235
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "holdfwd" && command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
triggerall = stateno = 150 || stateno = 152
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40

;---------------------------------------------------------------------------
;������U���i�����j
[State -1, Taunt]
type = ChangeState
value = 205
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
triggerall = stateno = 150 || stateno = 152
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40

;---------------------------------------------------------------------------
;�������U���i�����j
[State -1, Taunt]
type = ChangeState
value = 215
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
triggerall = stateno = 150 || stateno = 152
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40

;---------------------------------------------------------------------------
;�������U���i�����j
[State -1, Taunt]
type = ChangeState
value = 225
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
triggerall = stateno = 150 || stateno = 152
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�U���i�����j
[State -1]
type = ChangeState
value = 405
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
triggerall = stateno = 150 || stateno = 152
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��U���i�����j
[State -1]
type = ChangeState
value = 415
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
triggerall = stateno = 150 || stateno = 152
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40

;---------------------------------------------------------------------------
;���Ⴊ�݋��U���i�����j
[State -1]
type = ChangeState
value = 425
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "z" || (NumHelper(2000) = 1 && (command = "x" || command = "y"))
triggerall = command = "holddown"
triggerall = statetype != A
triggerall = stateno = 150 || stateno = 152
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40

;---------------------------------------------------------------------------
;���o�[�O�������U��
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "holdfwd" && command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl
trigger2 = StateNo = 400 && animelemtime(4) > 0
trigger3 = StateNo = 420 && anim = 420 && animelemtime(6) > 0
trigger4 = StateNo = 420 && anim = 421 && animelemtime(6) > 3
trigger5 = StateNo = 405 && animelemtime(8) > 0
trigger6 = StateNo = 425 && animelemtime(10) > 0

;---------------------------------------------------------------------------
;������U��
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200 && anim = 200 && Time > 6
trigger3 = StateNo = 200 && anim = 201 && animelemtime(4) > 0
trigger4 = StateNo = 400 && animelemtime(4) > 0
trigger5 = StateNo = 420 && anim = 420 && animelemtime(6) > 0
trigger6 = StateNo = 420 && anim = 421 && animelemtime(6) > 3
trigger7 = StateNo = 205 && Time > 18
trigger8 = StateNo = 405 && animelemtime(8) > 0
trigger9 = StateNo = 425 && animelemtime(10) > 0

;---------------------------------------------------------------------------
;�������U��
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 400 && animelemtime(4) > 0
trigger3 = StateNo = 420 && anim = 420 && animelemtime(6) > 0
trigger4 = StateNo = 420 && anim = 421 && animelemtime(6) > 3
trigger5 = StateNo = 405 && animelemtime(8) > 0
trigger6 = StateNo = 425 && animelemtime(10) > 0

;---------------------------------------------------------------------------
;�������U��
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 400 && animelemtime(4) > 0
trigger3 = StateNo = 420 && anim = 420 && animelemtime(5) > 0
trigger4 = StateNo = 420 && anim = 421 && animelemtime(6) > 3
trigger5 = StateNo = 405 && animelemtime(8) > 0
trigger6 = StateNo = 425 && animelemtime(9) > 0

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�U��
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 400 && animelemtime(4) > 0
trigger3 = StateNo = 420 && anim = 420 && animelemtime(6) > 0
trigger4 = StateNo = 420 && anim = 421 && animelemtime(6) > 3
trigger5 = StateNo = 405 && animelemtime(8) > 0
trigger6 = StateNo = 425 && animelemtime(10) > 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��U��
[State -1]
type = ChangeState
value = 410
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 400 && animelemtime(4) > 0
trigger3 = StateNo = 420 && anim = 420 && animelemtime(6) > 0
trigger4 = StateNo = 420 && anim = 421 && animelemtime(6) > 3
trigger5 = StateNo = 405 && animelemtime(8) > 0
trigger6 = StateNo = 425 && animelemtime(10) > 0

;---------------------------------------------------------------------------
;���Ⴊ�݋��U��
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "z" || (NumHelper(2000) = 1 && (command = "x" || command = "y"))
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 400 && animelemtime(4) > 0
trigger3 = StateNo = 420 && anim = 420 && animelemtime(6) > 0
trigger4 = StateNo = 420 && anim = 421 && animelemtime(6) > 3
trigger5 = StateNo = 405 && animelemtime(8) > 0
trigger6 = StateNo = 425 && animelemtime(10) > 0

;---------------------------------------------------------------------------
;�W�����v��U��
[State -1]
type = ChangeState
value = 600
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�W�����v���U��
[State -1]
type = ChangeState
value = 610
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�W�����v���U��
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 0
triggerall = var(58) = 0
triggerall = roundstate = 2
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
[State -3, AI�N���p�w���p�[]
type=helper
trigger1=!NumHelper(10000)
trigger1=roundstate=2
trigger1=alive
trigger1=var(58)=0
Trigger1=PrevStateNo=(190)||PrevStateNo=5900
Trigger1=ctrl&&stateno=0
helpertype=normal
name="AI"
stateno=10000
ID=10000
pos=9999,9999
keyctrl=1
pausemovetime=2147483647
supermovetime=2147483647
persistent = 0

;�O�̂��߁����t���Ă���
[State -3, �֌W�����X�e�[�g�ɍs���Ȃ��悤��]
type=changestate
trigger1= ishelper(10000)
trigger1= stateno!=43434
value=43434


;��������������������������������`�h���쁣������������������������������������������������
[State -2, �����m�F�f�o�b�N]
type = null;AppendToClipboard
trigger1 = 1
text =  "P2X:%f,P2Y:%f,Vx%f,Vy%f,Py%f \n"
params = p2bodydist x, p2bodydist y,vel x,vel y,Pos y
IgnoreHitPause = 1

[State -2, �f�o�b�N(�ϐ��m�F)]
Type =DisplayToClipBoard
Trigger1 = 1
Text = "var(50)=%d,var(51)=%d,var(42)=%d,\nfvar(38)=%f,fvar(14)=%f\n"
Params = var(50),var(51),var(42),fvar(38),fvar(14)
IgnoreHitPause = 1
;,fvar(36),var(49)var(49)=%d,


[State -3, �f�o]
type = Varset
trigger1 = 1
fvar(14) = ceil(ifelse((-315*fvar(1))>-7,-7,(-315*fvar(1))))


;
;[AI�t���O]
;�b

[State -3, EnemyNear()]
type = VarSet
trigger1 = NumEnemy = 1
trigger2 = NumEnemy = 2
trigger2 = Enemynear(var(47)),Life > 0
var(47) = 0
ignorehitpause = 1

[State -3, EnemyNear()]
type = VarSet
trigger1 = NumEnemy > 1
trigger1 = Enemynear(var(47)),Life = 0
var(47) = 1
ignorehitpause = 1


[State -3, AI���x���A�b�v]
type = Varadd
triggerall = roundstate = 2
triggerall = var(58) = 1
trigger1 = gametime%50 = 0
var(50) = 2


[State -3, �w�K���ԃ��Z�b�g]
type = VarSet
triggerall = roundstate != 2
trigger1 = var(9) < 3 && var(50) < 970
fvar(35) = 0

[State -3, �w�K���ԃ��Z�b�g]
type = VarSet
triggerall = roundstate != 2
trigger1 = var(9) < 3 && var(50) < 970
fvar(37) = 0


[State -3, �w�K���Ԍ���]
type = VarSet
triggerall = roundstate = 2
trigger1 = fvar(34) > 0
fvar(34) = fvar(34) -1

[State -3, �w�K���Ԍ���]
type = VarSet
triggerall = roundstate = 2
trigger1 = fvar(33) > 0
fvar(33) = fvar(33) -1

[State -3, �w�K���Ԍ���]
type = VarSet
triggerall = roundstate = 2
trigger1 = fvar(36) > 0
fvar(36) = fvar(36) -1

[State -3, �w�K���Ԍ���]
type = VarSet
triggerall = roundstate = 2
trigger1 = fvar(35) > 0
fvar(35) = fvar(35) -1-(2*(var(9) < 3 && var(50) < 970))


[State -3, �w�K���Ԍ���]
type = VarSet
triggerall = roundstate = 2
trigger1 = fvar(37) > 0
fvar(37) = fvar(37) -1

[State -3, �w�K���Ԍ���]
type = VarSet
triggerall = roundstate = 2
trigger1 = fvar(38) > 0
fvar(38) = fvar(38) -1

[State -3, �w�K���Ԍ���]
type = Varadd
triggerall = roundstate = 2
trigger1 = fvar(32) > 0
fvar(32) = -1

[State -3, 10�̃��Z�b�g]
type = VarSet
triggerALL = fvar(10) = 1
Trigger1 = stateno = 19 || ctrl
fvar(10) = 0

[State -3, �o�����Z���o�����܂܃_���[�W���󂯂��ꍇ�A�A�����Ȃ��悤�Ɋw�K1]
type = Varadd
trigger1 = prevstateno = (205||215||225||405||415||425)
trigger1 = movetype = H
trigger1 = fvar(32) < 10
fvar(32) = 900

[State -3, �X�s�b�g���o�����܂܃_���[�W���󂯂��ꍇ�A�A�����Ȃ��悤�Ɋw�K1]
type = Varadd
trigger1 = Helper(2000),StateNo = 2000
trigger1 = fvar(13) = 1
fvar(33) = fvar(33)*2+10000

[State -3, �X�s�b�g���o�����܂܃_���[�W���󂯂��ꍇ�A�A�����Ȃ��悤�Ɋw�K1]
type = VarSet
trigger1 = Helper(2000),StateNo = 2000
trigger1 = fvar(13) = 1
fvar(34) = (fvar(34) :=(fvar(33)/5)+(fvar(10) := 1)+(fvar(13) := 0))

[State -3, 13�̃��Z�b�g]
type = VarSet
trigger1 = NumHelper(2000) = 0
fvar(13) = 0

[State -3, �o���������o�����܂܃_���[�W���󂯂��ꍇ�A�A�����Ȃ��悤�Ɋw�K1]
type = Varadd
trigger1 = fvar(12) = 1
Trigger1 = stateno = 19 || ctrl
trigger1 = fvar(10) = 0
fvar(35) = fvar(35)+1300+(500*roundno)

[State -3, ��荞�݂��o�����܂܃_���[�W���󂯂��ꍇ�A�A�����Ȃ��悤�Ɋw�K2]
type = Varadd
trigger1 = fvar(11) = 1
Trigger1 = stateno != 800
trigger1 = fvar(10) = 0
fvar(36) = fvar(36)+8000

[State -3, �o���������o�����܂܃_���[�W���󂯂��ꍇ�A�A�����Ȃ��悤�Ɋw�K3]
type = Varadd
trigger1 = fvar(12) = 1
Trigger1 = stateno = 19 || ctrl
trigger1 = fvar(10) = 0
fvar(37) = (fvar(35)/5)+(fvar(10) := 1)

[State -3, ��荞�݂��o�����܂܃_���[�W���󂯂��ꍇ�A�A�����Ȃ��悤�Ɋw�K4]
type = VarSet
trigger1 = fvar(11) = 1
Trigger1 = stateno != 800
trigger1 = fvar(10) = 0
fvar(38) = (fvar(38) :=(fvar(36)/5)+(fvar(10) := 1))

;[State -3, ���肪�����Z�������Ă���ꍇ�A�C��t����]
;type = VarSet
;trigger1 = enemynear(var(47)),hitdefattr = SCA,ST,HT
;fvar(37) = fvar(37)+(fvar(35)/5)+150+(fvar(12) := 1)

[State -3, 11�̃��Z�b�g]
type = VarSet
triggerALL = fvar(11) = 1
Trigger1 = stateno = 19 || ctrl
fvar(11) = 0

[State -3, 12�̃��Z�b�g]
type = VarSet
triggerALL = fvar(12) = 1
Trigger1 = stateno = 19 || ctrl
fvar(12) = 0




[State -3, ����]
type = ChangeState
value = 900
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0;�X�^���h���o�Ă��Ȃ��ꍇ
triggerall = random < var(50)/100 || var(50)+var(51) > 1900
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = statetype = S
triggerall = stateno != 100
triggerall = p2statetype = S || p2statetype = C
triggerall = p2movetype != H
Triggerall = StateNo = 19 || ctrl
Triggerall =  P2bodyDist X <= 6
trigger1 = Random <= 60
trigger2 = PrevStateNo = 52
trigger3 = BackEdgeBodyDist = 0 && random < 500
Trigger4 = gametime%1000 > 500 && time > 1

[State -3, �K�E�����Z�ɃJ�E���^�[]
type = ChangeState
value = ifelse((var(48) != 1&&var(48) != 2),3000,3050)
triggerall = var(58) = 1
triggerall = random < var(51)/15 || var(51) > 998 || p2life > life
triggerALL = enemynear(var(47)),hitdefattr = SCA,HT;NT,ST,
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 1000
triggerall = random-1 < var(51)
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 200
trigger3 = StateNo = 210
trigger4 = StateNo = 220
trigger5 = StateNo = 230
trigger6 = StateNo = 400
trigger7 = StateNo = 410
trigger8 = StateNo = 420
trigger9 = StateNo = 205
trigger10 = StateNo = 215
trigger11 = StateNo = 225
trigger12 = StateNo = 235
trigger13 = StateNo = 405
trigger14 = StateNo = 415
trigger15 = StateNo = 425
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201
trigger19 = StateNo = 19
trigger20 = StateNo = 140

[State -3, ���荞�ݒ��K�E�c]
type = ChangeState
value = 3100
triggerall = 900 < var(51) ||  p2life-300 > life || 150 > life
triggerall = random < var(51)/15 || var(50)+var(51) > 1990
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = power >= 1000
triggerall = roundstate = 2
triggerall = p2statetype != L
triggerall = statetype != A
triggerall = p2movetype = A
Triggerall = p2StateNo != [120,155];�G���K�[�h���͎g��Ȃ�
Triggerall = p2StateNo <= 5000;�G�����炢���͎g��Ȃ�
triggerall = InGuardDist; || enemynear(var(47)),Vel X = 0 && enemynear(var(47)),Vel Y != 0;�G�����Ɉړ����Ă��Ȃ��ꍇ
Triggerall = P2BodyDist X = [0,65+(18*(enemynear(var(47)),Vel X+(Vel X/2)))]
triggerall = enemynear(var(47)),ctrl = 0
triggerall = enemynear(var(47)),Vel X > -1
;triggerall = enemynear(var(47)),Vel Y > -1;�G���オ���Ă���ꍇ�͎g��Ȃ�
;triggerall = enemynear(var(47)),HitDefAttr != SCA,NA,NT || power > 2000 || life < 800 || RoundNo > 2;�ʏ�U���ɂ͎g��Ȃ�
;Triggerall = p2StateNo != [120,155];�G���K�[�h���͎g��Ȃ�
;Triggerall = p2StateNo < 5000 || Enemynear(var(47)),BackEdgeBodyDist = 0 && StateNo = 420 && Time >= 7
;triggerall = InGuardDist || enemynear(var(47)),Vel X = 0 && enemynear(var(47)),Vel Y != 0;�G�����Ɉړ����Ă��Ȃ��ꍇ ||Enemynear(var(47)),BackEdgeBodyDist = 0 || p2movetype = A
;triggerall = power >= 1000
;Triggerall = P2BodyDist X = [0,55+(18*(enemynear(var(47)),Vel X))];
;Triggerall = enemynear(var(47)),pos Y < -15
;triggerall = enemynear(var(47)),ctrl = 0
;triggerall = enemynear(var(47)),Vel X > -5
triggerall = P2StateNo < 3000 || enemynear(var(47)),HitDefAttr = SCA,NA,NT || enemynear(var(47)),HitDefAttr = SCA,SA,ST || enemynear(var(47)),pos Y < -70
triggerall = Random <= 100+(power/20)+(50*enemynear(0),HitDefAttr = SCA,SA,ST)+(100*enemynear(0),HitDefAttr = SCA,HA,HT)+(900*(StateNo = 220)*enemynear(0),HitDefAttr = SCA,HA,HT)+(900*(StateNo = 420)*enemynear(0),HitDefAttr = SCA,HA,HT) || P2StateNo >= 3000
;triggerall = Random <= 100+power/20+50*enemynear(0),HitDefAttr = SCA,SA,ST+100*enemynear(var(47)),HitDefAttr = SCA,HA,HT+900*(StateNo = 220)*enemynear(var(47)),HitDefAttr = SCA,HA,HT)+(900*(StateNo = 420)*enemynear(var(47)),HitDefAttr = SCA,HA,HT) || P2StateNo >= 3000
;��{0�A�X�ɂ�������Q�[�W1000(���K���)���Ƃɑ����@�G���K�E�Z�⒴�K�E�Z���g���Ɗm���A�b�v
;triggerall = enemynear(var(47)),time < 60 || enemynear(var(47)),time > 120
trigger1 = 0;ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = 0;StateNo = 200
trigger3 = StateNo = 210
trigger4 = StateNo = 220
trigger5 = StateNo = 230
trigger6 = StateNo = 400
trigger7 = StateNo = 410 && (power >= 5000 || time > 7 || P2StateNo >= 3000)
trigger8 = StateNo = 420
trigger9 = StateNo = 205
trigger10 = StateNo = 215
trigger10 = animelemtime(10) > 0 || var(51) > 800
trigger11 = StateNo = 225
trigger11 = animelemtime(9) > 0 || var(51) > 800
trigger12 = StateNo = 235
trigger13 = StateNo = 405
trigger14 = StateNo = 415
trigger15 = StateNo = 425
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201
trigger19 = StateNo = 19
trigger20 = StateNo = 140

[State -3, ���荞�ݒ��K�E��]
type = ChangeState
value = ifelse((var(48) != 1&&var(48) != 2),3000,3050)
triggerall = 900 < var(51) ||  p2life-200 > life || 150 > life
triggerall = random < var(51)/15 || var(50)+var(51) > 1990
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = p2statetype != L
triggerall = statetype != A
triggerall = p2movetype = A
Triggerall = p2StateNo != [120,155];�G���K�[�h���͎g��Ȃ�
Triggerall = p2StateNo <= 5000;�G�����炢���͎g��Ȃ�
triggerall = InGuardDist; || enemynear(var(47)),Vel X = 0 && enemynear(var(47)),Vel Y != 0;�G�����Ɉړ����Ă��Ȃ��ꍇ
triggerall = power >= 1000
Triggerall = P2BodyDist X = [0,100]
triggerall = enemynear(var(47)),Vel Y > -1;�G���オ���Ă���ꍇ�͎g��Ȃ�
triggerall = enemynear(var(47)),ctrl = 0
triggerall = enemynear(var(47)),HitDefAttr != SCA,NA,NT || power > 2000 || life < 600 || RoundNo > 2;�ʏ�U���ɂ͎g��Ȃ�
triggerall = Random <= -100+(power/20)+(50*enemynear(0),HitDefAttr = SCA,SA,ST)+(100*enemynear(0),HitDefAttr = SCA,HA,HT)+(900*(StateNo = 220)*enemynear(0),HitDefAttr = SCA,HA,HT)+(900*(StateNo = 420)*enemynear(0),HitDefAttr = SCA,HA,HT) || P2StateNo >= 2000 && p2movetype = A; && enemynear(0),HitDefAttr = SCA,HA,HT
;��{0�A�X�ɂ�������Q�[�W1000(���K���)���Ƃɑ����@�G���K�E�Z�⒴�K�E�Z���g���Ɗm���A�b�v
triggerall = enemynear(var(47)),time < 60 || RoundNo > 1
Triggerall = !((P2BodyDist Y != [0,70])&&(enemynear(var(47)),Vel Y < 0));���肪��𒵂щz�������ȏꍇ
trigger1 = 0;ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = 0;StateNo = 200
trigger3 = StateNo = 210
trigger4 = StateNo = 220
trigger5 = StateNo = 230
trigger6 = StateNo = 400
trigger7 = StateNo = 410 && (power >= 5000 || time > 7 || P2StateNo >= 3000)
trigger8 = StateNo = 420
trigger9 = StateNo = 205
trigger10 = StateNo = 215
trigger10 = p2StateNo >= 5000 || animelemtime(10) > 0
trigger11 = StateNo = 225
trigger11 = p2StateNo >= 5000 || animelemtime(9) > 0
trigger12 = StateNo = 235
trigger13 = StateNo = 405
trigger14 = StateNo = 415
trigger15 = StateNo = 425
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201
trigger19 = 0;StateNo = 19
trigger20 = StateNo = 140



[State -3�@�J�E���^�[���Ⴊ�ݒ��X�^���h]
Type = ChangeState
Value = 410
TriggerAll = Var(58) = 1
triggerall = random < var(51)/100 || 998 < var(51)
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
triggerall = NumHelper(2000) = 0
TriggerAll = p2StateType != A
TriggerAll = prevStateNo != 410
TriggerAll = prevStateNo != [150,151]
TriggerAll = enemynear(var(47)),time < 8
Trigger1 = ctrl || StateNo = 11 || StateNo = 19 || StateNo = [120,140]
Trigger1 = P2BodyDist X = [35+(6*enemynear(var(47)),Vel X+vel X),76+(6*enemynear(var(47)),Vel X+vel X)]
Trigger1 = random < 500

[State -3, �΋�2�@�܂�������]
type = ChangeState
value = 420
triggerall = var(58) = 1
triggerall = random < var(51)/8 || 950 < var(51)
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = p2statetype = A || p2movetype != H && stateno = [100,101]
Triggerall = enemynear(var(47)),pos Y > -55+(enemynear(var(47)),Vel Y) || p2stateno = 5050 && (P2BodyDist Y = [-90,0]) && enemynear(var(47)),vel Y > 0
Triggerall = StateNo = 19 || ctrl && statetype != A || (stateno = 100 && animelemtime(2) >1) || StateNo = 101
;triggerALL = !enemynear(var(47)),hitdefattr = SCA,HA,HT;���K�E�Z�͖��G�̏ꍇ�������̂ő΋���g��Ȃ�
triggerALL = !InGuardDist
TriggerAll = prevStateNo != 420
TriggerAll = Enemynear(var(47)),BackEdgeBodyDist != 0
triggerall = enemynear(var(47)),Facing != Facing
Trigger1 = P2BodyDist X = [0,45+(6*(enemynear(var(47)),Vel X+Vel X))]

[State -3, �΋�3�@������̂�]
type = ChangeState
value = 1000
triggerall = var(58) = 1
triggerall = random < var(51)/5 || 998 < var(51)
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = p2statetype = A
Triggerall = P2BodyDist X = [50,100+(6*enemynear(var(47)),Vel X)]; && (!InGuardDist) || (P2BodyDist X = [40,100+(6*enemynear(var(47)),Vel X)])
Triggerall = P2BodyDist Y = [-90,-0]
Triggerall = enemynear(var(47)),pos Y < -10
triggerall = Random <= 700
triggerALL = !enemynear(var(47)),hitdefattr = SCA,HA,HT;���K�E�Z�͖��G�̏ꍇ�������̂ő΋���g��Ȃ�
triggerall = enemynear(var(47)),Vel X > -1;�G�����ɍs���Ă���ꍇ�͎g��Ȃ�
triggerall = enemynear(var(47)),Vel X < 3
triggerall = p2StateNo < 5000
triggerall = enemynear(var(47)),Facing != Facing
triggerall = Random <= 600
Triggerall = P2movetype != A
triggerALL = !InGuardDist
Triggerall = P2movetype != H || enemynear(var(47)),BackEdgeBodyDist < 10
Trigger1 = StateNo = 19
Trigger2 = ctrl && statetype != A

[State -3, �΋�1�A�c�`�����I�b�c]
type = ChangeState
value = 320
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = random < var(51)/10 || 998 < var(51)
triggerall = enemynear(var(47)),Facing != Facing
triggerall = statetype != A
triggerall = p2statetype = A
Triggerall = enemynear(var(47)),pos X < -30
Triggerall = StateNo = 19 || ctrl && statetype != A || StateNo = 220
triggerall = enemynear(var(47)),Vel X > -1;�G�����ɂ������Ă���ꍇ�͎g��Ȃ�
triggerall = enemynear(var(47)),Vel Y > 0;�G�����ɂ������Ă���ꍇ�����g��Ȃ�
Trigger1 = P2BodyDist X = [20,50+(8*(enemynear(var(47)),Vel X))]
;Trigger3 = StateNo = 400

[State -3, �΋�2�@������̂����Z�b�g]
type = VarSet
triggerall = var(58) = 1
Triggerall = StateNo != 420
Trigger1 = P2BodyDist X = [50,70]
;Trigger2 = Helper(2000),movehit
Trigger2 = P2statetype != A || (P2BodyDist X = [0,70]) && enemynear(var(47)),pos Y > -100
var(5) = 2

[State -3, �΋�2�@������̂����Z�b�g]
type = VarSet
triggerall = var(58) = 1
Trigger1 = P2BodyDist X = [0,50]
Trigger2 = StateNo = 420 && p2statetype = A
var(5) = 0




;[�؂�ւ���]
;�b
;[�K�[�h]


[State -3, �_�E�����Ă���̑΋N���U�߂̂ӂ邟]
type = ChangeState
value = 3100
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = InGuardDist
;triggerall = enemynear(var(47)),MoveType = A
triggerall = enemynear(var(47)),Vel X < 1
triggerall = enemynear(var(47)),Vel X > -1
triggerall = CTRL
triggerall = power >= 1000
Triggerall = P2BodyDist X = [0,20]
triggerall = p2StateType != A || Random < 500
trigger1 = PrevStateNo = 5120

[State -3, ��荞��]
type  = ChangeState
value = 800
triggerall = InGuardDist
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = p2moveType != H
triggerall = p2stateno < 5000
triggerall = var(58) = 1
triggerall = fvar(38) <= 1;��荞�݂����s�������b��͎g��Ȃ�
triggerall = P2BodyDist Y < -30 || P2BodyDist X > 130 ; || P2BodyDist X != [85-Enemynear(var(47)),const(size.ground.front)-Enemynear(var(47)),const(size.ground.back),105]
Triggerall = P2BodyDist X != [-20,20]
Triggerall = enemynear(var(47)),Facing != Facing
Trigger1 = StateNo = 19 || (stateno = 100 && animelemtime(2) >1)  || ctrl || StateNo = 140 || StateNo = 120 
Trigger1 = Random <= 500

;triggerall = Enemynear(var(47)),BackEdgeBodyDist !=[-10,5]
;Trigger2 = Random <= 950
;triggerall = Random < -100+(200*BackEdgeBodyDist > 5)+(100*Enemynear(var(47)),NumProj)+(200*Enemynear(var(47)),NumHelper(0))+(300*enemynear(var(47)),Vel X > 4) || StateNo = 100 && animelemtime(2) >1 || stateno = 101 || NumHelper(2000)
;�G���n�ォ���ɋ��āA������ꂻ���Ȋԍ����ł͏o���ɂ���

[State -3, �����_���ȉ�荞��]
type  = ChangeState
value = 800
triggerall = InGuardDist
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = p2moveType != H
triggerall = var(58) = 1
triggerall = fvar(38) <= 1;��荞�݂����s�������b��͎g��Ȃ�
Triggerall = enemynear(var(47)),Facing != Facing
Trigger1 = StateNo = 19 || (stateno = 100 && animelemtime(2) >1)  || ctrl || StateNo = 140 || StateNo = 120 
Trigger1 = var(51) < 990
Trigger1 = random < var(51)/200


[State -3, �K�[�h]
type  = ChangeState
value = 120
TriggerAll = StateNo = 19 || ctrl
triggerall = NumHelper(2000) = 0
triggerall = var(58) = 1
triggerall = random-200 < (var(51)/2)+(150*Var(9))+(300*(p2life > life))+(100*(300 > life))+(5*Enemynear(var(47)),time)+(50*p2movetype != A)+(2*P2BodyDist X) || 980 < var(51)
Trigger1 = InGuardDist
Trigger2 = !InGuardDist 
Trigger2 = Enemynear(var(47)),Vel X > 0 
Trigger2 = Enemynear(var(47)),HitDefAttr = SCA,AA 
;trigger1 = enemynear(var(47)),hitdefattr != SCA,NT,ST,HT

[State -1, �o�����U���̃J�E���^�[�p���`]
type = ChangeState
value = 405
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = stateno = 150 || stateno = 152
triggerall = random < var(51)/2 || 998 < var(51)
triggerall = P2BodyDist Y >= -40
triggerall = P2BodyDist X < 40
triggerall = fvar(32) < 10
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40


[State -1, �o�����U���̃J�E���^�[�R��]
type = ChangeState
value = 215
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = random < var(51)/2 || 998 < var(51)
triggerall = stateno = 150 || stateno = 152
triggerall = P2BodyDist Y >= -40
triggerall = P2BodyDist X < 60
triggerall = fvar(32) < 10
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40

[State -1, �o�����U���̃J�E���^�[��a��]
type = ChangeState
value = 225
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = random < var(51)/2 || 998 < var(51)
triggerall = stateno = 150 || stateno = 152
triggerall = P2BodyDist Y >= -40
triggerall = P2BodyDist X < 90
triggerall = fvar(32) < 10
trigger1 = P2stateno = var(11) || P2stateno = var(12) || P2stateno = var(13) || P2stateno = var(14) || P2stateno = var(15)
trigger2 = P2stateno = var(16) || P2stateno = var(17) || P2stateno = var(18) || P2stateno = var(19) || P2stateno = var(20)
trigger3 = P2stateno = var(21) || P2stateno = var(22) || P2stateno = var(23) || P2stateno = var(24) || P2stateno = var(25)
trigger4 = P2stateno = var(26) || P2stateno = var(27) || P2stateno = var(28) || P2stateno = var(29) || P2stateno = var(30)
trigger5 = P2stateno = var(31) || P2stateno = var(32) || P2stateno = var(33) || P2stateno = var(34) || P2stateno = var(35)
trigger6 = P2stateno = var(36) || P2stateno = var(37) || P2stateno = var(38) || P2stateno = var(39) || var(9) = 40

[State -1, �J�E���^�[����K�E]
type = ChangeState
value = ifelse((var(48) != 1&&var(48) != 2),3000,3050)
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = power >= 1000
triggerall = p2stateno >= 5000
triggerall = 3 < var(9) || 900 < var(50) || p2life > life || p2life < 200
trigger1 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger2 = StateNo = 225; && (var(41) = 1||var(41) = 2)



[State -1,�K�[�h�L�����Z���U��]
type = ChangeState
value = 311
triggerall = var(58) = 1
triggerall = pos Y = 0 && StateType != A
triggerall = roundstate = 2
triggerall = prevstateno != [810,811]
triggerall = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
triggerall = p2statetype != C
triggerall = P2BodyDist Y >= -55
Triggerall = P2BodyDist X <= 130
triggerall = random < var(51)/10 || var(51) > 998
triggerall = p2stateno < 3000
trigger1 = Random <= 10+var(9)*5
trigger2 = Random <= 30
trigger2 = life <= 300

[State -1,�A�h�o���V���O�K�[�h]
type = ChangeState
value = 810
triggerall = var(58) = 1
triggerall = pos Y = 0 && StateType != A
triggerall = p2statetype != A
triggerall = roundstate = 2
triggerall = prevstateno != [810,811]
trigger1 = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
trigger1 = Random <= 5
Trigger1 = P2BodyDist X = [-20,50]
trigger2 = stateno = 150 || stateno = 151 || stateno = 152 || stateno = 153
trigger2 = Random <= 5
Trigger2 = P2BodyDist X = [-20,20]
;trigger3 = Random <= 5
ignorehitpause = 1


[State -1, �o�����b�I]
type  = ChangeState
value = 1300
triggerall = var(58) = 1
triggerall = pos Y = 0 && StateType != A
triggerall = roundstate = 2
triggerall = GameTime > 300;�Q�[���J�n���玞�Ԃ������Ă���g��
triggerall = NumHelper(2000) = 0
triggerall = fvar(37) <= 1;�o���������s�������b��͎g��Ȃ�
triggerall = Random < Life-100;+(1000*PrevStateNo =1000);���C�t���Ⴂ�Ƃ��܂�g��Ȃ�
triggerall = p2MoveType = A || p2MoveType != H && random < 12 || ctrl || stateno = 19
Triggerall = Enemy,NumProj < 1;��ѓ���o�Ă���Ƃ��͎g��Ȃ�
Triggerall = P2BodyDist X < 150
Triggerall = random+((var(9) = 0)*200) > var(51) && random < 100 || random+(!var(9)*200) > var(50) && random < 100
Triggerall = 1900 > var(50)+var(51)
triggerall = life > 300
;&& gametime%1000 < 500 || 
triggerall = enemynear(var(47)),Facing != Facing
;Triggerall = enemynear(var(47)),vel X < 4 && P2BodyDist X > 40 || enemynear(var(47)),vel X > 4 && P2BodyDist X > 60
;triggerall = enemynear(var(47)),HitDefAttr != SCA,HA
;triggerall = enemynear(var(47)),MoveType = A
;triggerall = Random <= 950-(100*Var(9))
;Triggerall = Enemy,numhelper + InGuardDist >= 2;�w���p�[���o�Ă����ɃK�[�h�͈͂��Ǝg��Ȃ�
;triggerall = PrevStateNo != [150,155];�h�䒼��͎g��Ȃ�
trigger1 = ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1) || StateNo = 19
trigger2 = StateNo = 200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = 0;StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = 0;StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201

;�b
;[(�N���U��)]
;�b��[�n��]-[�n��N���U��]
;�b��[��]-[�󒆋N���U��(���\���)]

[State -3,�u���U�߃X�s�b�g]
Type = ChangeState
value = 1100
triggerall = var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = Enemynear(var(47)),StateType = L
TriggerAll = P2BodyDist X <= 90
TriggerAll = Enemynear(var(47)),StateNo = 5120
triggerall = NumHelper(2000) = 0;�X�^���h���o�Ă��Ȃ��ꍇ
triggerall = fvar(34) <= 0;���肪�X�s�b�g���甽�����Ă��Ȃ��ꍇ
triggerall = Random < 100
triggerall = BackEdgeBodyDist > 5
Trigger1 = StateNo = 19 || StateNo = 0
Trigger2 = ctrl

[State -3,�u���U�߃W�����v]
Type = ChangeState
value = 39
triggerall = var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = Enemynear(var(47)),StateType = L
TriggerAll = P2BodyDist X <= 90
TriggerAll = Enemynear(var(47)),StateNo = 5120
triggerall = NumHelper(2000) = 0;�X�^���h���o�Ă��Ȃ��ꍇ
triggerall = Random < 700
triggerall = BackEdgeBodyDist != 0
triggerall = var(57) = 1
Trigger1 = StateNo = 19 || StateNo = 0
Trigger2 = ctrl

[State -3,�u���U�ߊo����]
Type = ChangeState
value = 1300
triggerall = var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = Enemynear(var(47)),StateType = L
TriggerAll = P2BodyDist X <= 90
TriggerAll = Enemynear(var(47)),StateNo = 5120
triggerall = NumHelper(2000) = 0;�X�^���h���o�Ă��Ȃ��ꍇ
triggerall = fvar(37) <= 30;�o���������s�������b��͎g��Ȃ�
triggerall = Random < 200
triggerall = life > 300
Trigger1 = StateNo = 19 || StateNo = 0
Trigger2 = ctrl
;[(�A���Z�֘A)]
;�b��[�n��]��[�n��ډ���]
;�b�b�@�@�@��[�n��q��]




[State -1, ���Ⴊ�ݍU������X�p�R��]
type = ChangeState
value = 3100
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = statetype != A
TriggerAll = p2StateType != L
TriggerAll = p2StateType != A
triggerall = power >= 1000
triggerall = random*2 > life
triggerall = random < var(50)/2
triggerall = 900 > var(50)
triggerall = p2movetype = H
triggerall = P2BodyDist X = [0,80]
trigger1 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger2 = StateNo = 425; && (var(41) = 1||var(41) = 2)

[State -3, �L�b�N���璴�K]
type = ChangeState
value = ifelse((var(48) != 1&&var(48) != 2),3000,3050)
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = p2statetype != A || enemynear(var(47)),vel Y < 0
TriggerAll = p2StateType != L
triggerall = power >= 1000
;triggerall = random*2 > life
triggerall = random < var(50)
triggerall = p2stateno >= 5000
triggerall = p2movetype = H
triggerall = 990 > var(50)
trigger1 = StateNo = 210 && time > 10
;trigger2 = StateNo = 215



[State -3, �ǌ��p���`]
type = null;ChangeState
value = 200
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = p2statetype != L
triggerall = p2statetype != C
triggerall = NumHelper(2000) = 1
triggerall = Helper(2000),time > 36
;Trigger1 = var(50) < 998
Trigger1 = var(42) < 15
trigger1 = p2StateNo >= 5000
Trigger1 = P2BodyDist X < 50
Trigger1 = Enemynear(var(47)),BackEdgeBodyDist = 0
Trigger1 = enemynear(var(47)),life < life
;Trigger1 = random > 900
;Trigger1 = enemynear(var(47)),GetHitVar(hittime) < 6

[State -3, �ǌ��p���`2]
type = null;ChangeState
value = 200
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = p2statetype != L
triggerall = NumHelper(2000) = 1
;Trigger1 = P2BodyDist X = [0,30]
trigger1 = p2StateNo >= 5000
trigger1 = StateNo = 200; && Time > 4
;trigger1 = movehit
;�ʏ�̃L�����Z���ł͂Ȃ��A���Ⴊ�݃L�����Z������o���Ă���B���Ȃ�^�C�~���O�����������ǁA�{���Ȃ�Ύg��Ȃ����������V�т̃R���{�Ȃ̂Ŋ��ق��Ă��������B

[State -3, �����L�b�N];
type = null;ChangeState
value = 210
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = p2statetype != L
triggerall = p2statetype != A
triggerall = NumHelper(2000) = 1
triggerall = Helper(2000),time > 70 || P2BodyDist X > 30
Trigger1 = random > power/5
trigger1 = StateNo = 200 && time > 4

[State -3, �ǌ��a��];
type = null;ChangeState
value = 420
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = p2statetype != A
triggerall = p2statetype != L
triggerall = NumHelper(2000) = 1
triggerall = Helper(2000),time > 70 || P2BodyDist X > 30
trigger1 = StateNo = 200 && time > 4

[State -1, �ǌ�����_������]
type = null;ChangeState
value = 3100
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = statetype != A
TriggerAll = p2StateType != L
triggerall = p2movetype = H
triggerall = power >= 1000
trigger1 = StateNo = 420
Trigger1 = animelemtime(4) > 0
Trigger1 = var(42) > 5


[State -3, �ǌ����Ⴊ�ݑ�a��]
type = ChangeState
value = 420
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = p2statetype != A
triggerall = p2statetype != L
triggerall = ctrl
triggerall = NumHelper(2000) = 1
triggerall = Helper(2000),time > 36
trigger1 = p2StateNo >= 5000
;Trigger1 = PrevStateNo = 620 || PrevStateNo = 47
Trigger1 = P2BodyDist X = [-10,50]
Trigger2 = PrevStateNo = 1000
Trigger2 = P2BodyDist X = [-10,50]
trigger2 = p2statetype = A
;Trigger2 = PrevStateNo = 200
;Trigger2 = P2BodyDist X = [-10,20]
;Trigger2 = P2BodyDist Y = [-40,30]

[State -3, �ǌ���a��]
type = ChangeState
value = 220
triggerall = var(58) = 1
triggerall = roundstate = 2
triggerall = pos Y = 0 && StateType != A
triggerall = p2statetype != A
triggerall = p2statetype != L
trigger1 = p2StateNo >= 5000
Trigger1 = PrevStateNo = 1260; && power >= 1000;���f�S
trigger2 = p2StateNo >= 5000
Trigger2 = PrevStateNo = 620
Trigger2 = Helper(2000),StateNo != [1100,1105];�W�����v�A�k�r�X
trigger3 = p2StateNo >= 5000
trigger3 = StateNo = 420 && anim = 420 && animelemtime(5) > 0
;trigger3 = StateNo = 420 && anim = 420 && animelemtime(5) > 0
Trigger3 = P2BodyDist X = [0,95]

[State -1, �u�����ꂽ�ꍇ�̃X�^���h]
type  = ChangeState
value = 1100
triggerall = var(58) = 1
triggerall = pos Y = 0 && StateType != A
triggerall = roundstate = 2
triggerall = NumHelper(2000) = 0
triggerall = p2statetype != A
triggerall = p2statetype != L
triggerall = p2movetype != A
Triggerall = P2BodyDist X = [0,103+(10*enemynear(var(47)),Vel X)]
Triggerall = enemynear(var(47)),Vel Y > -10
triggerall = p2StateNo < 5000
triggerall = p2StateNo!=[140,155]
trigger1 = StateNo = 420 && time >= 16

[State -1, �~�X�����ꍇ�̊o�����b�I]
type  = ChangeState
value = 1300
triggerall = var(58) = 1
triggerall = pos Y = 0 && StateType != A
triggerall = roundstate = 2
triggerall = NumHelper(2000) = 0
triggerall = p2statetype != L
triggerall = fvar(37) <= 100;�o���������s�������b��͎g��Ȃ�
Triggerall = P2BodyDist X < 100
triggerall = p2StateNo < 5000
Triggerall = Enemy,NumProj < 1;��ѓ���o�Ă���Ƃ��͎g��Ȃ�
triggerall = Random < Life-300
triggerall = Random < 100
trigger1 = StateNo = 220 && time >= 13
trigger2 = StateNo = 210
trigger2 = (time >= 15) || p2movetype = A
trigger3 = StateNo = 410 && time >= 10

[State -3�@�������o���Ȃ��ꍇ�̒ǌ��̓񓁗�]
Type = ChangeState
Value = 1000
TriggerAll = Var(58) = 1
triggerall = random < var(50)/10 || 900 < var(50) && random < 500
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
triggerall = NumHelper(2000) = 0
TriggerAll = p2StateType != L
trigger1 = p2StateType != C
TriggerAll = p2moveType = H || (P2BodyDist X = [0,15])
;TriggerAll = p2stateno !=[150,151]
TriggerAll = enemynear(var(47)),pos Y > -80 || StateNo = 420 || prevStateNo = 901
trigger1 = StateNo = 220 && animelemtime(5) > 0 || StateNo = 225
Trigger1 = Var(42) > 30
Trigger1 = enemynear(var(47)),GetHitVar(hitcount) > 25
trigger2 = StateNo = 220
Trigger2 = p2statetype = A
trigger2 = p2StateType != C
trigger2 = Var(42) < 3
trigger2 = enemynear(var(47)),pos Y < -10
Trigger3 = StateNo = 210 && Time >= 9
trigger3 = p2statetype = A && enemynear(var(47)),pos y < -20
Trigger4 = StateNo = 420 && Time > 11
trigger4 = p2statetype = A && enemynear(var(47)),pos Y < -10 
;trigger4 = 0
Trigger5 = prevStateNo = 901 && (ctrl || StateNo = 19);��������

[State -3�@���Ⴊ�݃p���`]
Type = ChangeState
Value = 400
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
triggerall = random < var(50) || 998 < var(50)
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2moveType != A || enemynear(var(47)),Facing = Facing
TriggerAll = p2StateType != A
triggerall = NumHelper(2000) = 0
TriggerAll = p2StateType != L
;TriggerAll = enemynear(var(47)),StateType != A;�ߋ����ɋ��遁�U���\
;TriggerAll = (enemynear(var(47)),HitDefAttr != SCA,HA,HT) || enemynear(var(47)),Facing = Facing ||(stateno = 100 && animelemtime(2) >1)  ||stateno = 101
TriggerAll = !(prevstateno = 52 && p2stateno =[0,155])
Trigger1 = StateNo = 19
Trigger1 = P2BodyDist X < 40
Trigger2 = ctrl || StateNo = [120,141]
Trigger2 = P2BodyDist X = [10-(20*gametime%1000 < 500),40]
Trigger3 = stateno = 100 && animelemtime(2) >1 ||stateno = 101
Trigger3 = P2BodyDist X = [10-(20*gametime%1000 < 500),50]

[State -3�@�΋�p���`]
Type = ChangeState
Value = 200
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
triggerall = random < var(50)/20 || 998 < var(50)
TriggerAll = p2StateType = A
TriggerAll = p2StateType != C
TriggerAll = p2StateType != L
;triggerall = ((Helper(2000),StateNo = [1100,1105])*(p2moveType = H)) = 0;��Ԃ��X�s�b�g���{�G�����炢��
triggerall = enemynear(var(47)),Facing != Facing
Triggerall = enemynear(var(47)),pos Y < -20 || 900 > var(51)
Triggerall = enemynear(var(47)),pos Y > -70
Trigger1 = enemynear(var(47)),pos Y > -60; || (Enemynear(var(47)),BackEdgeBodyDist =[-10,10]) || 900 > var(51)
Trigger1 = StateNo = 19 || ctrl || StateNo = 200 && anim = 200 && Time > 6 || StateNo = 200 && anim = 201 && animelemtime(4) > 0
Trigger1 = P2BodyDist X = [0,40+(6*enemynear(var(47)),Vel X)]
Trigger2 = stateno = 100 && animelemtime(2) >1
Trigger2 = P2BodyDist X = [0+(6*enemynear(var(47)),Vel X),60+(6*enemynear(var(47)),Vel X)]

[State -3�@�����Ǎۂɒǂ��l�߂Ă̒��K�E�Z]
Type = null;ChangeState
Value = 3100
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2StateType = A
TriggerAll = p2StateType != L
triggerall = NumHelper(2000) = 0
TriggerAll = enemynear(var(47)),BackEdgeBodyDist > 5 || enemynear(var(47)),FrontEdgeBodyDist > 5
triggerall = power >= 1000
Trigger1 = StateNo = 19 || ctrl || StateNo = 200 && anim = 200 && Time > 6 || StateNo = 200 && anim = 201 && animelemtime(4) > 0
Trigger1 = Enemynear(var(47)),pos Y < -10
Trigger1 = P2BodyDist X = [-40,40]

[State -3�@�����Ǎۂɒǂ��l�߂Ẵp���`����X�^���h]
Type = ChangeState
Value = 1000
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
triggerall = NumHelper(2000) = 0
TriggerAll = p2StateType = A
TriggerAll = p2StateType != L
triggerall = enemynear(var(47)),BackEdgeBodyDist < 5 || enemynear(var(47)),FrontEdgeBodyDist < 5
triggerall = FrontEdgeBodyDist < 50
Trigger1 = StateNo = 200 && anim = 200 && Time > 6 || StateNo = 200 && anim = 201 && animelemtime(4) > 0
Trigger1 = Enemynear(var(47)),pos Y < -10
Trigger1 = P2BodyDist X = [-40,40]
Trigger1 = P2movetype=H

[State -3�@�����Ǎۂɒǂ��l�߂Ẵp���`]
Type = ChangeState
Value = 200
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2StateType = A
TriggerAll = p2StateType != L
triggerall = enemynear(var(47)),BackEdgeBodyDist < 5 || enemynear(var(47)),FrontEdgeBodyDist < 5
triggerall = FrontEdgeBodyDist < 50
Trigger1 = StateNo = 19 || ctrl || StateNo = 200 && anim = 200 && Time > 6 || StateNo = 200 && anim = 201 && animelemtime(4) > 0
Trigger1 = Enemynear(var(47)),pos Y < -10
Trigger1 = P2BodyDist X = [-40,40]

[State -3�@�p���`];�ߋ����ł͉���
Type = ChangeState
Value = 200
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
triggerall = random < var(50)/2 || 998 < var(50)
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2moveType != A || enemynear(var(47)),Facing = Facing
TriggerAll = p2StateType != A
TriggerAll = p2StateType != C
TriggerAll = p2StateType != L
;TriggerAll = enemynear(var(47)),StateType != A;�ߋ����ɋ��遁�U���\
;TriggerAll = (enemynear(var(47)),HitDefAttr != SCA,HA,HT) || enemynear(var(47)),Facing = Facing ||(stateno = 100 && animelemtime(2) >1)  ||stateno = 101
triggerall = enemynear(var(47)),Vel X > -0.5
triggerall = random < 500 || NumHelper(2000) != 0
triggerall = p2StateNo < 5000
TriggerAll = !(prevstateno = 52 && p2stateno =[0,155])
Trigger1 = StateNo = 19
Trigger1 = P2BodyDist X = [-30,40+(10*enemynear(var(47)),Vel X)]
Trigger2 = ctrl || StateNo = [120,141]
Trigger2 = P2BodyDist X = [10,40]
Trigger3 = stateno = 100 && animelemtime(2) >1 ||stateno = 101
Trigger3 = P2BodyDist X = [10,50+(10*enemynear(var(47)),Vel X)]
Trigger3 = p2movetype!=H
[State -3�@���L�b�N]
Type = ChangeState
Value = 210
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
triggerall = NumHelper(2000) = 0
TriggerAll = p2StateType != L
TriggerAll = p2StateType != C
TriggerAll = p2StateType != A || enemynear(var(47)),HitFall = 1
Triggerall = enemynear(var(47)),pos Y > -50
TriggerAll = p2moveType != A; || enemynear(var(47)),time <= 6 && random < 500 || enemynear(var(47)),Facing = Facing ||(stateno = 100 && animelemtime(2) >1)  ||stateno = 101
TriggerAll = prevStateNo != 410
triggerall = random < 70
Trigger1 = stateno = 100 && animelemtime(2) >1 ||stateno = 101
Trigger1 = P2BodyDist X = [60-(30*enemynear(var(47)),Vel X < -1),120+(50*enemynear(var(47)),Vel X > 1)]
Trigger2 = ctrl
Trigger2 = P2BodyDist X = [20-(10*enemynear(var(47)),Vel X < -1),86]
Trigger3 = StateNo = 11
Trigger3 = P2BodyDist X = [20-(10*enemynear(var(47)),Vel X < -1),86]
Trigger4 = StateNo = 19 || StateNo = 140
Trigger4 = P2BodyDist X = [20-(10*enemynear(var(47)),Vel X < -1),86]
Trigger5 = StateNo = 200 && time > 5
Trigger5 = P2BodyDist X = [20-(10*enemynear(var(47)),Vel X < -1),86]
;Trigger6 = prevStateNo = 400
;Trigger6 = P2BodyDist X = [20-(10*enemynear(var(47)),Vel X < -1),86]

[State -3�@���Ⴊ�ݒ��X�^���h]
Type = ChangeState
Value = 410
TriggerAll = Var(58) = 1
triggerall = random-100 < var(50)/50+(200*movetype = A) || 998 < var(50)
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
triggerall = NumHelper(2000) = 0
TriggerAll = p2StateType != L || random < 100 && P2BodyDist X = [40,76]
TriggerAll = p2StateType != A
;TriggerAll = p2moveType != A || enemynear(var(47)),time <= 6 && random < 500 || enemynear(var(47)),Facing = Facing ||stateno = 100 ||stateno = 101
TriggerAll = prevStateNo != 410
;TriggerAll = (enemynear(var(47)),HitDefAttr != SCA,NA,NT,SA,ST,HA,HT) || p2StateNo >= 5000||stateno = 100 ||stateno = 101
TriggerAll = !(prevstateno = 52 && p2stateno =[0,155])
Trigger1 = StateNo = 400 && animelemtime(4) > 0
trigger1 = p2movetype = H ;p2StateNo >= 5000
Trigger2 = StateNo = 200 && animelemtime(3) > 0
trigger2 = !MoveGuarded
trigger2 = p2StateNo >= 5000
Trigger3 = stateno = 100 && animelemtime(2) >1 ||stateno = 101
Trigger3 = P2BodyDist X = [0,76+(6*(enemynear(var(47)),Vel X+Vel X))]
Trigger4 = ctrl || StateNo = 11 || StateNo = 19 || StateNo = [120,140]
Trigger4 = P2BodyDist X = [0,76+(6*(enemynear(var(47)),Vel X))]

[State -3�@�����HP���Ⴂ�ꍇ�A�g�h�����h��]
Type = ChangeState
Value = 3050
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
triggerall = NumHelper(2000) = 0
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = Enemynear(var(47)),Movetype = H
TriggerAll = p2StateType != L
TriggerAll = p2StateType != A
TriggerAll = p2StateType != C
triggerall = (ceil(ifelse((-315*fvar(1))>-7,-7,(-315*fvar(1))))*-1) > p2life || power > 8000;����̃��C�t���Ⴂ���A�p���[������
triggerall = power >= 2000;�Q�[�W��2�ȏ゠��Ƃ������g��Ȃ�
triggerall = enemynear(var(47)),GetHitVar(hitcount) < 5;�R���{���͎g��Ȃ��B�␳�̂����łP���炢��������Ȃ���
triggerall = p2StateNo >= 5000 || Random < 200
trigger1 = StateNo = 220 || StateNo = 230 || StateNo = 210
Trigger1 = animelemtime(5) > 0

[State -3�@�ǌ��Q�@�����]
Type = ChangeState
Value = 1200
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
triggerall = random+200 < var(50)/2+100*var(9) || var(50) > 900 || life < 400
triggerall = NumHelper(2000) = 0
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2Movetype = H
triggerall = p2StateNo >= 5000 || random < 800 && (life > 100) || StateNo = 220 && random < 800
TriggerAll = p2StateType != L
TriggerAll = p2StateType != A
;TriggerAll = Var(48)
Triggerall = P2BodyDist X = [-30,120]
trigger1 = StateNo = 410
Trigger1 = time >= 6
trigger2 = StateNo = 220 || StateNo = 230 || StateNo = 210
Trigger2 = time >= 11 && enemynear(var(47)),GetHitVar(hitcount) < 35
trigger3 = StateNo = 210 && time = 9 || StateNo = 215 && animelemtime(9) > 1 
trigger3 = p2StateNo >= 5000
trigger4 = StateNo = 225 && animelemtime(9) > 1
trigger4 = p2StateNo >= 5000
trigger5 = StateNo = 220
Trigger5 = animelemtime(5) > 0
trigger6 = StateNo = 420
Trigger6 = animelemtime(4) > 0

[State -3�@�ǌ�3�@�����2��]
Type = ChangeState
Value = 1260
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
triggerall = NumHelper(2000) = 0
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2StateType != A
TriggerAll = p2StateType != L
triggerAll = StateNo = 1200
TriggerAll = animelemtime(7) > 0
TriggerAll = p2Movetype = H
triggerAll = p2StateNo < 5000
Trigger1 = p2StateType = C
Trigger1 = Random < 900
Trigger2 = p2StateType = S
Trigger2 = Random < 200

[State -3�@�ǌ�3(�K�[�h����Ȃ��ꍇ)�@�����2��]
Type = ChangeState
Value = 1250
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
triggerall = NumHelper(2000) = 0
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2moveType = H
trigger1 = StateNo = 1200
Trigger1 = animelemtime(7) > 1
trigger1 = !MoveGuarded

[State -3�@�ǌ�4�@�X�s�b�g]
Type = ChangeState
Value = 1100
TriggerAll = Var(58) = 1
triggerall = random < var(50)/2 || var(50) > 750
triggerall = roundstate = 2
triggerall = NumHelper(2000) = 0
TriggerAll = pos Y = 0 && StateType != A
trigger1 = StateNo = 1250
Trigger1 = animelemtime(5) > 0
trigger1 = p2StateNo >= 5000
trigger1 = !MoveGuarded

[State -3�@�ǌ�5�E1�@�_�b�V������]
Type = ChangeState
Value = 100
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
triggerall = Helper(2000),StateNo = [1100,1105];��Ԃ��X�s�b�g��
triggerall = Helper(2000),time < 30
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2StateType != A
;TriggerAll = p2MoveType != A
Triggerall = Ctrl || StateNo = 19 || StateNo = 0
;Trigger1 = P2BodyDist X > 20
trigger1 = p2movetype = H
trigger1 = p2StateNo != [120,155]
trigger1 = p2StateNo >= 5000

[State -3�@�ǌ�5�E2�@���W�����v��]
Type = ChangeState
Value = 39
TriggerAll = Var(58) = 1
triggerall = NumHelper(2000) = 1
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = helper(2000),AnimElemTime(8) > 3
TriggerAll = helper(2000),AnimElemTime(8) < 32
triggerall = random < var(9)*25+(var(50)/20) || 990 < var(50) || 800 < var(50) && life < 300; || enemynear(var(47)),life < life
Triggerall = p2Statetype != A
Triggerall = Var(42) < 24
Trigger1 = p2StateType != L
trigger1 = StateNo = 100
trigger1 = p2StateNo >= 5000
;trigger1 = Random < 500
;triggerall = 900 < var(51)
;Trigger1 = !(enemynear(var(47)),GetHitVar(hitcount) > 20 && Enemynear(var(47)),BackEdgeBodyDist = 0)

[State -3�@�ǌ�5�E2�@�܂��͎a��]
Type = ChangeState
Value = 220
TriggerAll = Var(58) = 1
triggerall = 999 > var(50) || Var(42) > 20
triggerall = NumHelper(2000) = 1
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = helper(2000),AnimElemTime(8) > 12
TriggerAll = helper(2000),AnimElemTime(8) < 32
Triggerall = p2Statetype != A
Trigger1 = p2StateType != L
trigger1 = StateNo = 100 && animelemtime(2) >1
trigger1 = p2StateNo >= 5000
;trigger1 = time > 15
;trigger1 = Random < 500

[State -1, ����������]
type = ChangeState
value = ifelse(p2StateType != A,ifelse(random%9 != 0,300,500),300)
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = random < 100;+200*p2movetype != H
triggerall = var(50) < 998
triggerall = var(48)
triggerall = Var(42) < 5
trigger1 = 0;ctrl || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger2 = StateNo = 0;200; && (var(41) = 1||var(41) = 2)
trigger3 = StateNo = 210; && (var(41) = 1||var(41) = 2)
trigger4 = StateNo = 220; && (var(41) = 1||var(41) = 2)
trigger5 = StateNo = 230; && (var(41) = 1||var(41) = 2)
trigger6 = StateNo = 0;400; && (var(41) = 1||var(41) = 2)
trigger7 = StateNo = 410; && (var(41) = 1||var(41) = 2)
trigger8 = StateNo = 420; && (var(41) = 1||var(41) = 2)
trigger9 = StateNo = 205; && (var(41) = 1||var(41) = 2)
trigger10 = StateNo = 215; && (var(41) = 1||var(41) = 2)
trigger11 = StateNo = 225; && (var(41) = 1||var(41) = 2)
trigger12 = StateNo = 235; && (var(41) = 1||var(41) = 2)
trigger13 = StateNo = 405; && (var(41) = 1||var(41) = 2)
trigger14 = StateNo = 415; && (var(41) = 1||var(41) = 2)
trigger15 = StateNo = 425; && (var(41) = 1||var(41) = 2)
trigger16 = StateNo = 195
trigger17 = StateNo = 196
trigger18 = StateNo = 5201





[State -1, �Q�[�W���]���Ďd���Ȃ��̂ŁA�����_���Œ��K�E�Z�B]
type = ChangeState
value = 3000
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = random < (var(51)/100)+power/2000
triggerall = statetype != A
triggerall = power >= 1000
triggerall = p2statetype != A
triggerall = p2movetype != H
triggerall = p2statetype != L
triggerall = life>200
triggerall = enemy,HitFall=0
triggerall = 990 > var(51)
trigger1 = ctrl || stateno = 19 || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)

[State -1, �����X�^���h]
type = ChangeState
value = 300
triggerall = var(58) = 1
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = random < (var(50)/40)
triggerall = var(50)+var(51)<1990
trigger1 = ctrl || stateno = 19 || (stateno = 100 && animelemtime(2) >1) || stateno = 101 || (stateno = 105 && animelemtime(2) > 1)
trigger1 = P2BodyDist X = [90,120]

[State -3, ���񐧂̉E�`�����I�b�c]
type = ChangeState
value = 310
triggerall = var(58) = 1
TriggerAll = pos Y = 0 && StateType != A
triggerall = NumHelper(2000) = 0
triggerall = roundstate = 2
triggerall = p2statetype != A
triggerall = p2statetype != L
triggerall = p2movetype != H
triggerall = p2movetype != A
triggerall = !InGuardDist
Trigger1 = P2BodyDist X = [150,200]
Trigger1 = P2BodyDist Y = [0,40]
Trigger1 = StateNo = 19
Trigger1 = Random <= 25

[State -3�@�������p���`];
Type = ChangeState
Value = 200
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2StateType = A
TriggerAll = p2StateType != L
triggerall = Helper(2000),StateNo != [1100,1105]
Trigger1 = StateNo = 19 || ctrl || StateNo = 200 && anim = 200 && Time > 6 || StateNo = 200 && anim = 201 && animelemtime(4) > 0
Trigger1 = P2BodyDist X = [10,40]
Trigger2 = StateNo = 100 && animelemtime(2) >1
Trigger2 = P2BodyDist X = [10,60]
Trigger3 = StateNo = 19 || ctrl && pos Y = 0
; || StateNo = 140
Trigger3 = enemynear(var(47)),vel X > 3;�G���_�b�V����
Trigger3 = P2BodyDist X = [10,80]
Trigger3 = P2BodyDist Y > -40

[State -3�@������a��];
Type = ChangeState
Value = 220
TriggerAll = Var(58) = 1
triggerall = random < var(50)/10 || 998 < var(50)
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2StateType != L
TriggerALL = P2BodyDist Y > -50
triggerall = (Random <= 100 || (Random <= 250 && Vel X = 0) || (Random <= 50 && Vel X > 0)) || NumHelper(2000) != 0 && p2stateno < 5000
TriggerAll = p2movetype != A
triggerall = NumHelper(2000) != 0 && p2stateno < 5000 || enemynear(var(47)),life < life
triggerall = enemynear(var(47)),Vel X > -5
triggerall = enemynear(var(47)),Vel X < 5
triggerall = !InGuardDist || NumHelper(2000) != 0 && p2stateno < 5000
Trigger1 = StateNo = 19 || ctrl
Trigger1 = (P2BodyDist X = [75,100]) ||(P2BodyDist X = [60,90]) && NumHelper(2000) != 0 && (p2stateno < 5000)
Trigger2 = (stateno = 100 && animelemtime(2) >1) 
Trigger2 = P2BodyDist X = [105,140]
Trigger3 = StateNo = 19 || ctrl && pos Y = 0
Trigger3 = p2StateNo > 5000
Trigger3 = P2BodyDist X = [0,90]

[State -3�@�������L�b�N];
Type = ChangeState
Value = 210
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2movetype != A
TriggerAll = p2StateType != L
TriggerAll = p2StateType != C
TriggerAll = p2StateType != A || enemynear(var(47)),HitFall = 1
Triggerall = Helper(2000),StateNo != [1100,1105]
Triggerall = var(50) > random
Trigger1 = StateNo = 19 && Random <= 200
Trigger1 = P2BodyDist X = [50,60]
Trigger2 = ctrl && pos Y = 0 && Random <= 200
Trigger2 = P2BodyDist X = [50,60]
Trigger3 = stateno = 100 && animelemtime(2) >1
Trigger3 = P2BodyDist X = [80,120]
Trigger3 = P2BodyDist Y = [0,-50]
Trigger4 = StateNo = 100 && animelemtime(2) >1
Trigger5 = StateNo = 0 || StateNo = 19
Trigger5 = P2BodyDist X = [0,70]
trigger5 = NumHelper(2000) = 1;�X�^���h���o�Ă��Ȃ��ꍇ
Trigger5 = enemynear(var(47)),pos Y > -50

[State -3�@���Ⴊ�ݒ��X�^���h];
Type = null;ChangeState
Value = 410
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
TriggerAll = p2StateType != A
TriggerAll = p2StateType != L
triggerall = NumHelper(2000) = 0;�X�^���h���o�Ă��Ȃ��ꍇ
Trigger1 = ctrl && pos Y = 0
Trigger1 = P2BodyDist X = [10,70]
Trigger2 = StateNo = 19
Trigger2 = P2BodyDist X = [10,70]

[State -3�@�W�����v����];
Type = ChangeState
Value = 610
TriggerAll = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = StateType = A
TriggerAll = StateNo = 50 || ctrl
Trigger1 = Vel X > 0
Trigger1 = (P2BodyDist X = [0,25]) || (random < 500 && P2BodyDist X = [0,80])
Trigger1 = p2StateNo < 5000;�G�����炢������Ȃ��ꍇ


[State -3�@�R���{��];
Type = ChangeState
Value = 610
TriggerAll = Var(58) = 1
Triggerall = !inguarddist
triggerall = roundstate = 2
TriggerAll = StateType = A
TriggerAll = p2StateType != L
TriggerAll = StateNo = 50
Triggerall = Vel Y > 2
Triggerall = p2StateNo >= 5000;�G�����炢���̏ꍇ�@�R���{�p
;Triggerall = !(var(42) < 15) || !(var(50) < 990) || !(Enemynear(var(47)),BackEdgeBodyDist = 0) || !(enemynear(var(47)),life < life)
Trigger1 = FrontEdgeBodyDist < 30;;Enemynear(var(47)),BackEdgeBodyDist < 15 || Enemynear(var(47)),FrontEdgeBodyDist < 15;�Ǎۂ̂�

[State -3�@���K�R���{�p�̌�];
Type = null;ChangeState
Value = 600
TriggerAll = Var(58) = 1
Triggerall = !inguarddist
triggerall = roundstate = 2
TriggerAll = StateType = A
TriggerAll = p2StateType != L
TriggerAll = StateNo = 50
Triggerall = Vel Y > 3.9
Triggerall = p2StateNo >= 5000;�G�����炢���̏ꍇ�@�R���{�p
Trigger1 = var(42) < 15
Trigger1 = var(50) < 990
Trigger1 = Enemynear(var(47)),BackEdgeBodyDist = 0;�Ǎۂ̂�
Trigger1 = enemynear(var(47)),life < life

[State -3�@�W�����v��A�k�r�X];
Type = ChangeState
Value = 620
TriggerAll = Var(58) = 1
Triggerall = !inguarddist
triggerall = roundstate = 2
TriggerAll = StateType = A
TriggerAll = p2StateType != L
TriggerAll = StateNo = 50
Triggerall = !(FrontEdgeBodyDist < 30 && p2StateType = C);!((Enemynear(var(47)),BackEdgeBodyDist < 15 || Enemynear(var(47)),FrontEdgeBodyDist < 15) && p2StateType = C);���肪�ǍۂŁA���Ⴊ��ł���ꍇ�͏o���Ȃ�
;Triggerall = !(var(42) < 15) || !(var(50) < 990) || !(Enemynear(var(47)),BackEdgeBodyDist = 0) || !(enemynear(var(47)),life < life)
Trigger1 = P2BodyDist X = [10,60]
Trigger1 = p2StateNo < 5000;�G�����炢������Ȃ��ꍇ
Trigger1 = Random < 200 
Trigger2 = Vel Y > -0.15
Trigger2 = p2StateNo >= 5000;�G�����炢���̏ꍇ�@�R���{�p
;Trigger2 = Enemynear(var(47)),BackEdgeBodyDist > 0


[State -3, �o�b�N�W�����v]
type = null;VarSet
var(57) = 2
Triggerall = !inguarddist
TriggerAll = Var(58) = 1
TriggerAll = pos Y = 0 && StateType != A
triggerall = roundstate = 2
TriggerAll = p2StateType != L
Triggerall = p2StateType != A
Triggerall = p2StateNo < 5000
Triggerall = Helper(2000),StateNo != [1100,1105]
triggerall = BackEdgeBodyDist > 5
;trigger1 = Random <= 900
Triggerall = StateNo = 19
Trigger1 = P2BodyDist X = [60,150]
Trigger2 = Enemynear(var(47)),StateNo = 5120

[State -3, �o�b�N�W�����v]
Type = null;ChangeState
Value = 39
Triggerall = !inguarddist
TriggerAll = Var(58) = 1
Triggerall = var(57) = 2
TriggerAll = pos Y = 0 && StateType != A
triggerall = roundstate = 2
TriggerAll = p2StateType != L
Triggerall = p2StateType != A
Triggerall = p2moveType != H
Triggerall = BackEdgeBodyDist > 5
Triggerall = P2BodyDist Y = [0,-30] 
Triggerall = StateNo = 19
Triggerall = vel X < 0;���ֈړ���
;triggerall = Random <= 700
Trigger1 = P2BodyDist X = [40,100] 
Trigger1 = enemynear(var(47)),vel X < 3
Trigger2 = P2BodyDist X = [60,150]
Trigger2 = enemynear(var(47)),vel X > 4;�G���_�b�V����

[State -3�@�󒆃`�����I�b�c];
Type = ChangeState
Value = 700
TriggerAll = Var(58) = 1
Triggerall = StateType = A
triggerall = roundstate = 2
TriggerAll = p2StateType != L
triggerall = NumHelper(2000) = 0;�X�^���h���o�Ă��Ȃ��ꍇ
triggerall = Random < 200
Trigger1 = StateNo = 50
Trigger1 = P2BodyDist X = [0,100]
Trigger1 = enemynear(var(47)),vel X < 0
Trigger2 = StateNo = 620
Trigger2 = P2BodyDist X = [0,100]
Trigger2 = animelemtime(5) > 0
;Trigger2 = p2StateNo < 5000

;[State -3�@���񐧑O�X�^���h];
;Type = ChangeState
;Value = 300
;TriggerAll = Var(58) = 1
;triggerall = roundstate = 2
;TriggerAll = pos Y = 0 && StateType != A
;TriggerAll = p2StateType != L
;trigger1 = Random <= 200
;Trigger1 = StateNo = 19
;Trigger1 = P2BodyDist X = [80,100]
;Trigger2 = ctrl&& pos Y = 0
;Trigger2 = P2BodyDist X = [80,100]

;�b��[��]��[�󒆖ډ���]
;�b�@�@�@�@��[�󒆌q��]

;[(�n��)]
;�b��[�n��ړ��֌W]
;�b��[�n�㗧�����Z�U��]









[State -3,�_�b�V��]
Type     = ChangeState
;value    = 0
Value    = 100
Triggerall = Var(58) = 1
triggerall = roundstate = 2
Triggerall = pos Y = 0 && StateType != A
triggerall = random < var(50)/5 || 998 < var(50)
Triggerall = enemynear(var(47)),pos Y > -30
Triggerall = !inguarddist
TriggerAll = p2StateType != L
triggerall = NumHelper(2000) = 0;�X�^���h���o�Ă��Ȃ��ꍇ
triggerall = p2StateNo != 0 || prevStateNo = 140
triggerall = Random <= 300 || (prevStateNo = [150,154])
Triggerall = ctrl&& pos Y = 0 || StateNo = 19
TriggerAll = enemynear(var(47)),BackEdgeBodyDist > 5
Triggerall = P2MoveType != A
Trigger1 = P2BodyDist X = [80,160]
;Trigger2 = P2BodyDist X = [145,160]
;Trigger2 = !(P2MoveType = A && enemynear(var(47)),time > 6)

[State -3,�_�b�V���\��]
Type     = null;ChangeState
;value    = 0
Value    = 100
Triggerall = Var(58) = 1
triggerall = roundstate = 2
Triggerall = pos Y = 0 && StateType != A
Triggerall = enemynear(var(47)),pos Y > -30
Triggerall = !inguarddist
TriggerAll = p2StateType != L
triggerall = NumHelper(2000) = 0;�X�^���h���o�Ă��Ȃ��ꍇ
triggerall = (p2StateNo != [0,155]) || prevStateNo = 140
triggerall = Random <= 300 || (prevStateNo = [150,154])
Triggerall = ctrl&& pos Y = 0 || StateNo = 19
Trigger1 = P2BodyDist X = [70,160]
Trigger1 = P2MoveType != A
Trigger2 = P2BodyDist X = [145,160]
Trigger2 = !(P2MoveType = A && enemynear(var(47)),time > 6)

[State -3,���肪������񂾂�_�b�V���ŋߕt��]
Type     = ChangeState
Value    = 100
Triggerall = Var(58) = 1
triggerall = roundstate = 2
Triggerall = pos Y = 0 && StateType != A
Triggerall = ctrl&& pos Y = 0 || StateNo = 19
TriggerAll = enemynear(var(47)),BackEdgeBodyDist > 5 || enemynear(var(47)),FrontEdgeBodyDist > 5
TriggerAll = FrontEdgeBodyDist > 100
Trigger1 = P2statetype = A
Trigger1 = P2stateno >= 5000
Trigger1 = P2BodyDist X > 50
Trigger1 = enemynear(var(47)),ctrl=0

[State -3,���肪�_�E�����Ă�����_�b�V�����ċߕt��]
Type     = null;ChangeState
Value    = 100
Triggerall = Var(58) = 1
triggerall = roundstate = 2
Triggerall = pos Y = 0 && StateType != A
Triggerall = !inguarddist
TriggerAll = p2StateType = L && enemynear(var(47)),vel X > -1
Trigger1 = StateNo = 19
Trigger1 = P2BodyDist X != [0,120]

[State -3,�_�b�V����~]
Type     = ChangeState
Value    = 101
Triggerall = Var(58) = 1
triggerall = roundstate = 2
TriggerAll = pos Y = 0 && StateType != A
triggerall = AnimElemTime(2) >= 1
triggerall = StateNo = 100
Triggerall = P2stateno < 5000
Trigger1 = enemynear(var(47)),pos Y < -30
Trigger2 = inguarddist
Trigger3 = P2BodyDist X < 0
Trigger4 = EnemyNear(var(47)),StateNo = 5120
Trigger5 = enemynear(var(47)),BackEdgeBodyDist < 5
Trigger5 = P2BodyDist X < 40
;Trigger2 = P2MoveType = A && P2BodyDist X != [0,20]
;Trigger4 = p2MoveType != H
;Trigger4 = P2BodyDist X = [0,50]
;Trigger4 = enemynear(var(47)),StateType = L
;Trigger4 = P2BodyDist X = [0,50]

[State -3,�W�����v]
Type     = ChangeState
Value    = 39
Triggerall = Var(58) = 1
triggerall = roundstate = 2
Triggerall = pos Y = 0 && StateType != A
Triggerall = !inguarddist
TriggerAll = p2moveType != A
TriggerAll = p2StateType != A
TriggerAll = p2StateType != L
triggerall = enemynear(var(47)),vel X < 3
triggerall = NumHelper(2000) = 0;�X�^���h���o�Ă��Ȃ��ꍇ�̂�
Trigger1 = StateNo = 100
Trigger1 = P2BodyDist X = [100,150]
trigger1 = Random <= 200+(300*p2StateType = C)
Trigger2 = StateNo = 19
Trigger2 = P2BodyDist X = [50,70]
trigger2 = Random <= 200+(300*p2StateType = C)

[State -3,�ߕt��]
type = VarSet
var(57) = 1
triggerall = !InGuardDist
triggerall = roundstate = 2
TriggerAll = Var(58) = 1
Triggerall = pos Y = 0 && StateType != A
Trigger1 = enemynear(var(47)),StateType = L;�N���U��
Trigger1 = P2BodyDist X > 70
Trigger2 = StateNo = 19

[State -3,�����]
type = VarSet
var(57) = 2
triggerall = roundstate = 2
TriggerAll = Var(58) = 1
Triggerall = pos Y = 0 && StateType != A
triggerall = !InGuardDist;�K�[�h�_�X�g���Ȃ���ɉ����낤�Ƃ���ƃK�[�h�����Ⴄ��
Trigger1 = enemynear(var(47)),StateType = L;�N���U�߂̂Ƃ��A�ߕt�������Ȃ�
Trigger1 = P2BodyDist X = [0,70]
Trigger1 = gametime%1000 > 500
trigger2 = Var(8) = 1;�X�^���h���o�Ă���ꍇ�A�X�^���h�̑O�ɂ͏o�Ȃ�
Trigger2 = P2BodyDist X < helper(2000),P2BodyDist X+60
trigger2 = p2StateNo <= 5000
trigger3 = P2BodyDist X < 20;�߂Â������Ȃ�
Trigger3 = gametime%1000 < 500
Trigger4 = P2BodyDist X = [0,30]
Trigger4 = p2StateType = A
Trigger5 = P2MoveType = A && enemynear(var(47)),Facing != Facing && enemynear(var(47)),time < 30
Trigger5 = gametime%1000 < 500;�U�����͗����
Trigger6 = gametime%1000 < 500
Trigger6 = enemynear(var(47)),StateType = L;�N���U�߂̂Ƃ��A�ߕt�������Ȃ�
Trigger6 = P2BodyDist X = [0,120]


[State -3,����ϋߕt��]
type = VarSet
triggerall = roundstate = 2
TriggerAll = Var(58) = 1
Triggerall = pos Y = 0 && StateType != A
Trigger1 = P2MoveType = H && (p2StateNo != [120,155])
Trigger1 = p2StateType != L
trigger2 = p2StateNo = 5050
Trigger2 = !((P2BodyDist X = [0,30]) && p2StateType = A)
var(57) = 1

[State -3�@���s]
type = ChangeState
value = 19
;triggerall = !InGuardDist
triggerall = random < var(51)/2 || 998 < var(50)
triggerall = roundstate = 2
TriggerAll = Var(58) = 1
Triggerall = pos Y = 0 && StateType != A
triggerall = StateNo != 39
Triggerall = P2BodyDist X != [68,72]
Triggerall = P2BodyDist X < helper(2000),P2BodyDist X+50 || Var(8) = 0
trigger1 = ctrl
trigger2 = StateNo = 0 && p2StateType != L

[State -3�@�����~�܂�]
type = ChangeState
value = 0
triggerall = roundstate = 2
TriggerAll = Var(58) = 1
Triggerall = pos Y = 0 && StateType != A
triggerall = StateNo = 19
Trigger1 = P2BodyDist X > helper(2000),P2BodyDist X+40 && Var(8) = 1

[State -3�@�_�E�������痧���~�܂�]
type = ChangeState
value = 0
Triggerall = enemynear(var(47)),StateType = L
triggerall = roundstate = 2
TriggerAll = Var(58) = 1
Triggerall = pos Y = 0 && StateType != A
triggerall = StateNo = 19
Trigger1 = P2BodyDist X = [68,72]
Trigger1 = gametime%1000 > 500;
Trigger2 = P2BodyDist X < 72 && BackEdgeBodyDist = 0
Trigger3 = gametime%1000 < 500
Trigger3 = P2BodyDist X = [115,130]


[State -1, ����]
type = null;ChangeState
value = 196
triggerall = var(58) = 1
triggerall = roundstate = 3
triggerall = StateNo = 19 || ctrl
triggerall = Var(8) = 0
triggerall = Win
triggerall = RoundNo >= 2
trigger1 = pos Y = 0 && StateType != A

[State -1, ����]
type = ChangeState
value = 195
triggerall = var(58) = 1
triggerall = roundstate = 3
triggerall = StateNo = 19 || ctrl
triggerall = Win
triggerall = RoundNo >= 2
triggerall = Var(8) = 1
trigger1 = pos Y = 0 && StateType != A





