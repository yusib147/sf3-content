Removed column effect
-was distracting and doesn't match body when fighting

Fixed SFF for palette use
Added second palette 