;++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
;++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

;                           ||||||||||||||||||||||||||||||||||||                              ;
;                           ||                                ||                              ;
;                           ||           FULGORE CMD          ||                              ;
;                           ||                                ||                              ;
;                           ||||||||||||||||||||||||||||||||||||                              ;

;++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
;++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


;-| AI/CPU Commands |-----------by Equinocio

[Command]
name = "cpu_1"
command = U, U, U, U, U, U, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_2"
command = D, D, D, D, D, D, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_3"
command = B, B, B, B, B, B, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_4"
command = F, F, F, F, F, F, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_5"
command = a, a, a, a, a, a, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_6"
command = b, b, b, b, b, b, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_7"
command = c, c, c, c, c, c, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_8"
command = x, x, x, x, x, x, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_9"
command = y, y, y, y, y, y, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_10"
command = x, x, x, x, x, x, U, U, U, U, U, U
time = 1
[Command]
name = "cpu_11"
command = U, U, U, U, U, a, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_12"
command = D, D, D, D, D, a, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_13"
command = B, B, B, B, B, a, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_14"
command = F, F, F, F, F, a, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_15"
command = U, U, U, U, U, b, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_16"
command = D, D, D, D, D, b, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_17"
command = B, B, B, B, B, b, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_18"
command = F, F, F, F, F, b, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_19"
command = U, U, U, U, U, c, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_20"
command = D, D, D, D, D, c, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_21"
command = B, B, B, B, B, c, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_22"
command = F, F, F, F, F, c, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_23"
command = U, U, U, U, U, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_24"
command = D, D, D, D, D, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_25"
command = B, B, B, B, B, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_26"
command = F, F, F, F, F, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_27"
command = U, U, U, U, U, y, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_28"
command = D, D, D, D, D, y, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_29"
command = B, B, B, B, B, y, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_30"
command = F, F, F, F, F, y, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_31"
command = U, U, U, U, U, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_32"
command = D, D, D, D, D, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_33"
command = B, B, B, B, B, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_34"
command = F, F, F, F, F, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_35"
command = U, U, U, U, a, a, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_36"
command = D, D, D, D, a, a, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_37"
command = B, B, B, B, a, a, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_38"
command = F, F, F, F, a, a, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_39"
command = U, U, U, U, b, b, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_40"
command = D, D, D, D, b, b, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_41"
command = B, B, B, B, b, b, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_42"
command = F, F, F, F, b, b, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_43"
command = U, U, U, U, c, c, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_44"
command = D, D, D, D, c, c, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_45"
command = B, B, B, B, c, c, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_46"
command = F, F, F, F, c, c, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_47"
command = U, U, U, U, x, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_48"
command = D, D, D, D, x, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_49"
command = B, B, B, B, x, x, U, U, U, U, U, U
time = 2
[Command]
name = "cpu_50"
command = F, F, F, F, x, x, U, U, U, U, U, U
time = 2

;----------| COMBO COMANDOS |-----------

[Command]
name = "insane"
command = F,F,x+y
time = 20

[Command]
name = "monster"
command = F,B,F,x+y
time = 20

[Command]
name = "beaslty"
command = F,F,a+b
time = 20

[Command]
name = "ultra"
command = F,B,F,a+b
time = 20

;----------| SUPER COMANDOS |-----------

[Command]
name = "super01"
command = ~D,DF,F,x+y
time = 20

[Command]
name = "super02"
command = ~D,DF,F,a+b
time = 20

[Command]
name = "super03"
command = ~D,DB,B,x+y
time = 20

[Command]
name = "super04"
command = ~D,DB,B,a+b
time = 20

;----------| ESPECIAL COMANDOS |-----------

[Command]
name = "eleball"
command = ~D,DF,F,x
time = 20

[Command]
name = "boom"
command = ~D,DF,F,y
time = 20

[Command]
name = "beam"
command = ~D,DF,F,z
time = 20

[Command]
name = "mini"
command = ~D,DF,F,a
time = 20

[Command]
name = "tele"
command = ~D,DF,F,b
time = 20

[Command]
name = "miss"
command = ~D,DF,F,c
time = 20

[Command]
name = "dod"
command = ~D,DB,B,x
time = 20

[Command]
name = "telek"
command = ~D,DB,B,y
time = 20

[Command]
name = "telep"
command = ~D,DB,B,z
time = 20

[Command]
name = "onda"
command = ~D,DB,B,a
time = 20

[Command]
name = "charge"
command = ~D,DB,B,b
time = 20

;---------| NORMAL COMANDOS |-----------


; Dir + Button 

[Command]
name = "fwd_x"
command = /F,x

[Command]
name = "fwd_a"
command = /F,a
time = 1

[Command]
name = "df_y"
command = /DF, y
time = 1

[Command]
name = "df_a"
command = /DF, a
time = 1

[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

[Command]
name = "DU" ;Pulo alto
command = D, $U
time = 11

[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1


[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Statedef -1]

;===========================================================================
;---------------------------------------------------------------------------
;Artificial Inteligence
;---------------------------------------------------------------------------

[State -1, Activate AI]
type = VarSet
trigger1  = command = "cpu_1"
trigger2  = command = "cpu_2"
trigger3  = command = "cpu_3"
trigger4  = command = "cpu_4"
trigger5  = command = "cpu_5"
trigger6  = command = "cpu_6"
trigger7  = command = "cpu_7"
trigger8  = command = "cpu_8"
trigger9  = command = "cpu_9"
trigger10 = command = "cpu_10"
trigger11 = command = "cpu_11"
trigger12 = command = "cpu_12"
trigger13 = command = "cpu_13"
trigger14 = command = "cpu_14"
trigger15 = command = "cpu_15"
trigger16 = command = "cpu_16"
trigger17 = command = "cpu_17"
trigger18 = command = "cpu_18"
trigger19 = command = "cpu_19"
trigger20 = command = "cpu_20"
trigger21 = command = "cpu_21"
trigger22 = command = "cpu_22"
trigger23 = command = "cpu_23"
trigger24 = command = "cpu_24"
trigger25 = command = "cpu_25"
trigger26 = command = "cpu_26"
trigger27 = command = "cpu_27"
trigger28 = command = "cpu_28"
trigger29 = command = "cpu_29"
trigger30 = command = "cpu_30"
trigger31 = command = "cpu_31"
trigger32 = command = "cpu_32"
trigger33 = command = "cpu_33"
trigger34 = command = "cpu_34"
trigger35 = command = "cpu_35"
trigger36 = command = "cpu_36"
trigger37 = command = "cpu_37"
trigger38 = command = "cpu_38"
trigger39 = command = "cpu_39"
trigger40 = command = "cpu_40"
trigger41 = command = "cpu_41"
trigger42 = command = "cpu_42"
trigger43 = command = "cpu_43"
trigger44 = command = "cpu_44"
trigger45 = command = "cpu_45"
trigger46 = command = "cpu_46"
trigger47 = command = "cpu_47"
trigger48 = command = "cpu_48"
trigger49 = command = "cpu_49"
trigger50 = command = "cpu_50"
v = 40
value = 1

;=======================================================================
;-| Artificial Inteligence - Attacks |----------------------------------

[State -1];setando var dos atacks
Type=VarSet
Trigger1=1
var(0)=StateType=S*200
[State -1];setando var dos atacks
Type=VarSet
Trigger1=1
var(1)=StateType=C*400
[State -1];setando var dos atacks
Type=VarSet
Trigger1=1
var(2)=StateType=A*600

;-------------------------------
;           SUPER        :
;-------------------------------

[State -1, SUPER 1 AI]
type=changestate
value=3000
triggerall=var(40)&&roundstate=2&&statetype!=A&&power>=3000&&P2Life>1
triggerall=(p2stateno!=[120,155])&&(p2statetype!=L)
trigger1=ctrl&&(p2bodydist x=[15,125])&&random<50
trigger2=((stateno=[200,440]))&&movehit&&random<50
persistent=1

[State -1, SUPER 2 AI]
type=changestate
value=4000
triggerall=var(40)&&roundstate=2&&statetype!=A&&power>=3000&&P2Life>1
triggerall=(p2stateno!=[120,155])&&(p2statetype!=L)
trigger1=ctrl&&(p2bodydist x=[15,125])&&random<50
trigger2=((stateno=[200,440]))&&movehit&&random<50
persistent=1

;-------------------------------
;        Golpes Normais        :
;-------------------------------

[State -1, taunt]
type=changestate
value=199
triggerall=var(40)&&roundstate=2&&statetype!=A
trigger1=p2dist x>160&&(enemynear,vel y>0)&&ctrl&&random<100
trigger1=!(enemynear,ctrl)&&(enemynear,movetype=H)

[State -1, grounddefend]
type=changestate
value=ifelse((enemynear,statetype=C),131,130)
trigger1=var(40)&&statetype!=A&&roundstate=2&&ctrl&&inguarddist&&random<900
persistent=0

[State -1, airdefend]
type=changestate
value=132
trigger1=var(40)&&statetype=A&&roundstate=2&&ctrl&&inguarddist&&random<900
persistent=0

[State -1, run]
type=changestate
value=100
trigger1=var(40)&&statetype=S&&roundstate=2&&ctrl&&random<200
trigger1=(stateno!=[100,105])&&enemynear,movetype!=A&&p2bodydist x>120
persistent=0

[State -1, dash]
type=changestate
value=105
trigger1=var(40)&&statetype=S&&roundstate=2&&ctrl&&random<200
trigger1=(stateno!=[100,105])&&enemynear,movetype=A&&backedgedist>120&&p2bodydist x<160
persistent=0

[State -1, jump]
type=changestate
value=40
triggerall=var(40)&&statetype!=A&&roundstate=2&&ctrl
trigger1=ctrl&&p2bodydist x>160&&p2dist y<-100&&random<200
trigger2=enemynear,movetype=A&&p2bodydist x<160&&enemynear,hitdefattr=SC,AT
persistent=0

[State -1, Soco Fraco]
type=changestate
value=200
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,46])&&(p2bodydist y=[-50,50])&&p2statetype!=L
trigger1=ctrl&&random<50
persistent=0

[State -1, Soco na run]
type=changestate
value=210
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall = command = "x" && Stateno =100 && p2bodydist X < 50&&(p2statetype!=L)
trigger1=ctrl&&random<50
persistent=0

[State -1, Soco Forte]
type=changestate
value=220
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,45])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<75
persistent=0

[State -1, Chute Fraco]
type=changestate
value=230
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,50])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<50
persistent=0

[State -1, Chute Forte]
type=changestate
value=240
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,50])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<75
persistent=0

[State -1, Rasteira]
type=changestate
value=250
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,50])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<100
persistent=0

[State -1, Round House]
type=changestate
value=260
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,50])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<100
persistent=0

[State -1, Soco Fraco Agachado]
type=changestate
value=400
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,40])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)&&(p2statetype!=A)
trigger1=ctrl&&random<50
trigger2=stateno=200&&movecontact&&random<100
persistent=0

[State -1, Soco Forte Agachado]
type=changestate
value=410
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,45])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<75
persistent=0

[State -1, Chute Fraco Agachado]
type=changestate
value=430
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,45])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)&&(p2statetype!=A)
trigger1=ctrl&&random<50
persistent=0

[State -1, Chute Forte Agachado]
type=changestate
value=440
triggerall=var(40)&&statetype!=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,45])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)&&(p2statetype!=A)
trigger1=ctrl&&random<75
persistent=0

[State -1, Soco Fraco Aereo]
type=changestate
value=600
triggerall=var(40)&&statetype=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,80])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<50
persistent=0

[State -1, Soco Forte Aereo]
type=changestate
value=610
triggerall=var(40)&&statetype=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,80])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<75
persistent=0

[State -1, Chute Fraco Aereo]
type=changestate
value=630
triggerall=var(40)&&statetype=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,80])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<50
persistent=0

[State -1, Chute Forte Aereo]
type=changestate
value=640
triggerall=var(40)&&statetype=A&&roundstate=2&&P2Life>1
triggerall=(p2bodydist x=[0,80])&&(p2bodydist y=[-50,50])&&(p2statetype!=L)
trigger1=ctrl&&random<75
persistent=0

;=========================================================================


;----------- Finish Him ------------

[State -1]
type = Changestate
trigger1 = ctrl
trigger1 = P2Life <= 1
trigger1 = NumHelper(9010) = 0
trigger1 = P2StateNo != 003
trigger1 = RoundNo != 1
trigger1 = var(58) >= 1
trigger1 = statetype = S
trigger1 = (p2statetype = S) || (p2statetype = C)
value = 9000

;=========================================================================
; COMANDOS
;=========================================================================

;-------------------------------
;         Golpes Combos        :
;-------------------------------

[State -1, INSANE COMBO]
type = ChangeState
value = 6000
triggerall = command = "insane"
triggerall = power >= 3000
trigger1 = (statetype = s) && ctrl
trigger2 = stateno = 200 && movecontact
trigger3 = stateno = 210 && movecontact
trigger4 = stateno = 230 && movecontact
trigger5 = stateno = 240 && movecontact
trigger6 = stateno = 400 && movecontact
trigger7 = stateno = 410 && movecontact
trigger8 = stateno = 430 && movecontact
trigger9 = stateno = 440 && movecontact
trigger10 = stateno = 650 && time > 2
trigger11 = stateno = 651 && time > 2
trigger12 = stateno = 652 && time > 2

[State -1, MONSTER COMBO]
type = ChangeState
value = 6200
triggerall = command = "monster"
triggerall = power >= 3000
trigger1 = (statetype = s) && ctrl
trigger2 = stateno = 200 && movecontact
trigger3 = stateno = 210 && movecontact
trigger4 = stateno = 230 && movecontact
trigger5 = stateno = 240 && movecontact
trigger6 = stateno = 400 && movecontact
trigger7 = stateno = 410 && movecontact
trigger8 = stateno = 430 && movecontact
trigger9 = stateno = 440 && movecontact
trigger10 = stateno = 650 && time > 2
trigger11 = stateno = 651 && time > 2
trigger12 = stateno = 652 && time > 2

[State -1, BEASTLY COMBO]
type = ChangeState
value = 6400
triggerall = command = "beaslty"
triggerall = power >= 3000
trigger1 = (statetype = s) && ctrl
trigger2 = stateno = 200 && movecontact
trigger3 = stateno = 210 && movecontact
trigger4 = stateno = 230 && movecontact
trigger5 = stateno = 240 && movecontact
trigger6 = stateno = 400 && movecontact
trigger7 = stateno = 410 && movecontact
trigger8 = stateno = 430 && movecontact
trigger9 = stateno = 440 && movecontact
trigger10 = stateno = 650 && time > 2
trigger11 = stateno = 651 && time > 2
trigger12 = stateno = 652 && time > 2

[State -1, ULTRA COMBO]
type = ChangeState
value = 6600
triggerall = command = "ultra"
triggerall = power >= 3000
trigger1 = (statetype = s) && ctrl
trigger2 = stateno = 200 && movecontact
trigger3 = stateno = 210 && movecontact
trigger4 = stateno = 230 && movecontact
trigger5 = stateno = 240 && movecontact
trigger6 = stateno = 400 && movecontact
trigger7 = stateno = 410 && movecontact
trigger8 = stateno = 430 && movecontact
trigger9 = stateno = 440 && movecontact
trigger10 = stateno = 650 && time > 2
trigger11 = stateno = 651 && time > 2
trigger12 = stateno = 652 && time > 2

;-------------------------------
;         Golpes Supers        :
;-------------------------------

[State -1, SUPER 01]
type = ChangeState
value = 3000
triggerall = command = "super01"
triggerall = power >= 3000
triggerall = statetype != A
trigger1 =  numhelper = 0
trigger1 = ctrl
trigger2 = stateno =[ 200,440]

[State -1, SUPER 02]
type = ChangeState
value = 3500
triggerall = command = "super02"
triggerall = power >= 3000&&P2Life>=2
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = (stateno = 200) && time > 1
trigger3 = (stateno = 230) && time > 2

[State -1, SUPER 03]
type = ChangeState
value = 4000
triggerall = command = "super03"
triggerall = power >= 3000&&P2Life>=2
triggerall = statetype != A
trigger1 =  numhelper = 0
trigger1 = ctrl
trigger2 = stateno =[ 200,440]

[State -1, SUUPER 04]
type = ChangeState
value = 4500
triggerall = command = "super04"
triggerall = power >= 3000 && P2BodyDist X >= 15
trigger1 = (statetype = s) && ctrl
trigger2 = stateno = 200 && movecontact
trigger3 = stateno = 210 && movecontact
trigger4 = stateno = 230 && movecontact
trigger5 = stateno = 240 && movecontact
trigger6 = stateno = 400 && movecontact
trigger7 = stateno = 410 && movecontact
trigger8 = stateno = 430 && movecontact
trigger9 = stateno = 440 && movecontact
trigger10 = stateno = 650 && time > 2
trigger11 = stateno = 651 && time > 2
trigger12 = stateno = 652 && time > 2

;-------------------------------
;        Golpes especiais      :
;-------------------------------

[State -1,ELECTRIC BALL]
type = ChangeState
value = 1000
triggerall = P2Stateno != 003&&P2life != 1
triggerall = command = "eleball"
trigger1 = NumHelper(1000) = 0
trigger1 = statetype = S
trigger1 = statetype != A
trigger1 = ctrl
trigger2 =  (stateno = [200,440]) && (stateno !=[600,640])

[State -1,SONIC BOOM]
type = ChangeState
value = 1200
triggerall = command = "boom"
trigger1 = statetype != A
trigger1 = ctrl

[State -1, TELEPORT]
type = ChangeState
value = 1300
triggerall = command = "tele"
triggerall = P2Life>=2
trigger1 = statetype = S
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = movecontact

[State -1,LASER BEAM]
type = ChangeState
value = 1400
triggerall = command = "beam"
trigger1 = statetype != A
trigger1 = ctrl

[State -1, MINGUN]
type = ChangeState
value = 1500
triggerall = command = "mini"
triggerall = statetype != A
trigger1 =  numhelper = 0
trigger1 = ctrl
trigger2 = stateno =[ 200,440]

[State -1,MISSIL]
type = ChangeState
value = 1600
triggerall = P2Stateno != 003&&P2life != 1
triggerall = command = "miss"
trigger1 = NumHelper(1000) = 0
trigger1 = statetype = S
trigger1 = statetype != A
trigger1 = ctrl
trigger2 =  (stateno = [200,440]) && (stateno !=[600,640])

[State -1, DODGE]
type = ChangeState
value = 1700
triggerall = var(59) = 0
triggerall = P2Stateno != 003&&P2life != 1
triggerall = command = "dod"
trigger1 = NumHelper(1000)= 0&&NumHelper(1100)= 0
trigger1 = statetype = S
trigger1 = statetype != A
trigger1 = ctrl
trigger2 =  (stateno = [200,440]) && (stateno !=[600,640])
trigger2 = movecontact

[State -1,ONDA SHOCK]
type = ChangeState
value = 1800
triggerall = command = "onda"
trigger1 = statetype != A
trigger1 = ctrl

[State -1, TELEPORT UNCH]
type = ChangeState
value = 1900
triggerall = command = "telep"
triggerall = P2Life>=2
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = statetype = C
trigger2 = ctrl
trigger3 = (stateno = [200,299]) || (stateno = [400,499])
trigger3 = stateno != 440 ;Except for sweep kick
trigger3 = movecontact

[State -1, TELEPORT KICK]
type = ChangeState
value = 2000
triggerall = P2Stateno != 003&&P2life != 1
triggerall = command = "telek"
trigger1 = NumHelper(1000)= 0&&NumHelper(1100)= 0
trigger1 = statetype = S
trigger1 = statetype != A
trigger1 = ctrl
trigger2 =  (stateno = [200,440]) && (stateno !=[600,640])
trigger2 = movecontact

[State -1,ELECTRIC CHARGE]
type = Changestate
value = 2500
triggerall = ctrl && Power!= Powermax && StateType !=A
trigger1 = Command = "charge"

;-------------------------------
;         Golpes Normais       :
;-------------------------------

;Run Fwd
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall= anim != 6504
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;Run Back
[State -1, Run Back]
type = ChangeState
value = 105
triggerall= anim != 6504
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;Taunt
[State -1, Taunt]
type = ChangeState
value = 199
triggerall= anim != 6504
triggerall = command = "start"
trigger1 = statetype != A
trigger1 = ctrl

;---------------------------------------------------------

;-------------------------------
;        Golpes Normais        :
;-------------------------------
;Run Fwd
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall= anim != 6504
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;Run Back
[State -1, Run Back]
type = ChangeState
value = 105
triggerall= anim != 6504
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;Taunt
;[State -1, Taunt]
;type = ChangeState
;value = 195
;triggerall= anim != 6504
;triggerall = command = "start"
;trigger1 = statetype != A
;trigger1 = ctrl

;---------------------------------------------------------

;Punch in Run
[State -1,PR]
type = ChangeState
value = 200
triggerall= anim != 6504
triggerall = command = "x" && Stateno =100 && p2bodydist X < 50
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl


;Stand Light Punch
[State -1, Stand Light Punch]
type = ChangeState
value = 210
triggerall = p2bodydist X > 50 || Stateno != 100
triggerall= anim != 6504
triggerall = command = "x"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = (stateno = 220) && time > 5
trigger3 = (stateno = 200) && time > 10

;Stand Strong Punch
[State -1, Stand Strong Punch]
type = ChangeState
value = 220
triggerall= anim != 6504
triggerall = command = "y"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = (stateno = 210) && time > 5
trigger3 = (stateno = 230) && time > 6
trigger4 = (stateno = 200) && time > 10

;Stand Strong Punch
[State -1, Stand Strong Punch]
type = ChangeState
value = 225
triggerall= anim != 6504
triggerall = command = "z"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = (stateno = 210) && time > 5
trigger3 = (stateno = 230) && time > 6
trigger4 = (stateno = 200) && time > 10

;Stand Light Kick
[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerall = command != "holdback"
triggerall= anim != 6504
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = (stateno = 210) && time > 7
trigger3 = (stateno = 230) && time > 9
trigger4 = (stateno = 200) && time > 10

;Standing Medium Kick
[State -1, Standing Strong Kick]
type = ChangeState
value = 240
triggerall = command != "holdback"
triggerall= anim != 6504
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = (stateno = 210) && time > 2
trigger3 = (stateno = 230) && time > 2
trigger4 = (stateno = 200) && time > 10

;Standing Strong Kick
[State -1, Standing Strong Kick]
type = ChangeState
value = 245
triggerall = command != "holdback"
triggerall= anim != 6504
triggerall = command = "c"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = (stateno = 210) && time > 2
trigger3 = (stateno = 230) && time > 2
trigger4 = (stateno = 200) && time > 10

;Crouching Light Punch
[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerall= anim != 6504
triggerall = command = "x"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl

;Crouching Medium Punch
[State -1, Crouching Light Punch]
type = ChangeState
value = 405
triggerall= anim != 6504
triggerall = command = "y"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl

;Crouching Strong Punch
[State -1, Crouching Strong Punch]
type = ChangeState
value = 410
triggerall= anim != 6504
triggerall = command = "z"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = (stateno = [200, 240]) || (stateno = [400,440])
trigger2 =  stateno != 410
trigger2 = (time > 9) || (movecontact && time > 5)

;Crouching Light Kick
[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerall= anim != 6504
triggerall = command = "a"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = (stateno = 400) || (stateno = 430)
trigger2 = (time > 9) || (movecontact && time > 5)

;Crouching Medium Kick
[State -1, Crouching Light Kick]
type = ChangeState
value = 440
triggerall= anim != 6504
triggerall = command = "b"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = (stateno = 400) || (stateno = 430)
trigger2 = (time > 9) || (movecontact && time > 5)

;Crouching Medium Kick
[State -1, Crouching Light Kick]
type = ChangeState
value = 250
triggerall= anim != 6504
triggerall = command = "c"
triggerall = command = "holddown"
trigger1 = statetype = c
trigger1 = ctrl =1
trigger2 = (stateno = [200, 240]) || (stateno = [400,440])


;Jump Light Punch
[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall= anim != 6504
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600
trigger2 = statetime >= 7

;Jump Medium Punch
[State -1, Jump Strong Punch]
type = ChangeState
value = 610
triggerall= anim != 6504
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600 || stateno = 630 ;jump_x or jump_a
trigger2 = movecontact

;Jump Strong Punch
[State -1, Jump Strong Punch]
type = ChangeState
value = 620
triggerall= anim != 6504
triggerall = command = "z"
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600 || stateno = 630 ;jump_x or jump_a
trigger2 = movecontact

;Jump Light Kick
[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerall= anim != 6504
triggerall = command = "a"
trigger1 = statetype = A
trigger1 = ctrl

;Jump Medium Kick
[State -1, Jump Strong Kick]
type = ChangeState
value = 640
triggerall= anim != 6504
triggerall = command = "b"
trtiggerall = Vel x != 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600 || stateno = 630 ;jump_x or jump_a
trigger2 = movecontact

;Jump Strong Kick
[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerall= anim != 6504
triggerall = command = "c"
trtiggerall = Vel x != 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 600 || stateno = 630 ;jump_x or jump_a
trigger2 = movecontact

;----------------------------------------------------------------------------
[State -1, Launcher]
type=ChangeState
trigger1=Stateno=650
trigger1=movehit
trigger1=Command="holdup"
value=40

[State -1, reseta o pulo]
type=Varset
trigger1=var(20)
trigger1=Stateno!=[40,50]
trigger1=Statetype!=A 
var(20)=0
;---------------------------------------------------------------------------


