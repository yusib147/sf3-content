Gargos:

Created new animated stance (sprites in Gargos folder)
Added custom small portrait