;-| Button Remapping |-----------------------------------------------------
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s
;-| Default Values |-------------------------------------------------------
[Defaults]
command.time = 15
command.buffer.time = 1

;-| Super Motions |--------------------------------------------------------

[Command]
name = "Shadow Flaming Bat"
command = ~D, DF, F, D, DF, x
time = 16

[Command]
name = "Shadow Flaming Bat"
command = ~D, DF, F, D, DF, ~x
time = 16

[Command]
name = "Shadow Flaming Bat"
command = ~D, DF, F, D, DF, y
time = 16

[Command]
name = "Shadow Flaming Bat"
command = ~D, DF, F, D, DF, ~y
time = 16

[Command]
name = "Shadow Flaming Bat"
command = ~D, DF, F, D, DF, z
time = 16

[Command]
name = "Shadow Flaming Bat"
command = ~D, DF, F, D, DF, ~z
time = 16

[Command]
name = "Shadow Flaming Bat Max"
command = ~D, DF, F, D, DF, x+y
time = 16

[Command]
name = "Shadow Flaming Bat Max"
command = ~D, DF, F, D, DF, y+z
time = 16

[Command]
name = "Shadow Flaming Bat Max"
command = ~D, DF, F, D, DF, x+z
time = 16

;-------------------------------------------------------------------------

[Command]
name = "Shadow Sabre Spin"
command = ~D, DB, B, D, DB, x
time = 16

[Command]
name = "Shadow Sabre Spin"
command = ~D, DB, B, D, DB, ~x
time = 16

[Command]
name = "Shadow Sabre Spin"
command = ~D, DB, B, D, DB, y
time = 16

[Command]
name = "Shadow Sabre Spin"
command = ~D, DB, B, D, DB, ~y
time = 16

[Command]
name = "Shadow Sabre Spin"
command = ~D, DB, B, D, DB, z
time = 16

[Command]
name = "Shadow Sabre Spin"
command = ~D, DB, B, D, DB, ~z
time = 16

[Command]
name = "Shadow Sabre Spin Max"
command = ~D, DB, B, D, DB, x+y
time = 16

[Command]
name = "Shadow Sabre Spin Max"
command = ~D, DB, B, D, DB, y+z
time = 16

[Command]
name = "Shadow Sabre Spin Max"
command = ~D, DB, B, D, DB, x+z
time = 16

;-------------------------------------------------------------------------

[Command]
name = "Shadow Sabre Moon Slash"
command = ~D, DB, B, D, DB, a
time = 16

[Command]
name = "Shadow Sabre Moon Slash"
command = ~D, DB, B, D, DB, ~a
time = 16

[Command]
name = "Shadow Sabre Moon Slash"
command = ~D, DB, B, D, DB, b
time = 16

[Command]
name = "Shadow Sabre Moon Slash"
command = ~D, DB, B, D, DB, ~b
time = 16

[Command]
name = "Shadow Sabre Moon Slash"
command = ~D, DB, B, D, DB, c
time = 16

[Command]
name = "Shadow Sabre Moon Slash"
command = ~D, DB, B, D, DB, ~c
time = 16

[Command]
name = "Shadow Sabre Moon Slash"
command = ~D, DB, B, D, DB, a+b
time = 16

[Command]
name = "Shadow Sabre Moon Slash Max"
command = ~D, DB, B, D, DB, b+c
time = 16

[Command]
name = "Shadow Sabre Moon Slash Max"
command = ~D, DB, B, D, DB, a+c
time = 16

;-------------------------------------------------------------------------

[Command]
name = "Shadow Sabre Roll"
command = ~D, DF, F, D, DF, a
time = 16

[Command]
name = "Shadow Sabre Roll"
command = ~D, DF, F, D, DF, ~a
time = 16

[Command]
name = "Shadow Sabre Roll"
command = ~D, DF, F, D, DF, b
time = 16

[Command]
name = "Shadow Sabre Roll"
command = ~D, DF, F, D, DF, ~b
time = 16

[Command]
name = "Shadow Sabre Roll"
command = ~D, DF, F, D, DF, c
time = 16

[Command]
name = "Shadow Sabre Roll"
command = ~D, DF, F, D, DF, ~c
time = 16

[Command]
name = "Shadow Sabre Roll Max"
command = ~D, DF, F, D, DF, a+b
time = 16

[Command]
name = "Shadow Sabre Roll Max"
command = ~D, DF, F, D, DF, b+c
time = 16

[Command]
name = "Shadow Sabre Roll Max"
command = ~D, DF, F, D, DF, a+c
time = 16

;-------------------------------------------------------------------------

[Command]
name = "Ultra Combo"
command = ~B, F, B, F, a+b
time = 32

[Command]
name = "Ultra Combo"
command = ~B, F, B, F, b+c
time = 32

[Command]
name = "Ultra Combo"
command = ~B, F, B, F, a+c
time = 32

;-| Special Motions |------------------------------------------------------

[Command]
name = "Flaming Bat"
command = ~D, DF, F, x
time = 16

[Command]
name = "Flaming Bat"
command = ~D, DF, F, ~x
time = 16

[Command]
name = "Flaming Bat"
command = ~D, DF, F, y
time = 16

[Command]
name = "Flaming Bat"
command = ~D, DF, F, ~y
time = 16

[Command]
name = "Flaming Bat"
command = ~D, DF, F, z
time = 16

[Command]
name = "Flaming Bat"
command = ~D, DF, F, ~z
time = 16

[Command]
name = "Flaming Bat Ex"
command = ~D, DF, F, x+y
time = 16

[Command]
name = "Flaming Bat Ex"
command = ~D, DF, F, y+z
time = 16

[Command]
name = "Flaming Bat Ex"
command = ~D, DF, F, x+z
time = 16

;-------------------------------------------------------------------------

[Command]
name = "Sabre Spin"
command = ~D, DB, B, x
time = 16

[Command]
name = "Sabre Spin"
command = ~D, DB, B, ~x
time = 16

[Command]
name = "Sabre Spin"
command = ~D, DB, B, y
time = 16

[Command]
name = "Sabre Spin"
command = ~D, DB, B, ~y
time = 16

[Command]
name = "Sabre Spin"
command = ~D, DB, B, z
time = 16

[Command]
name = "Sabre Spin"
command = ~D, DB, B, ~z
time = 16

[Command]
name = "Sabre Spin Ex"
command = ~D, DB, B, x+y
time = 16

[Command]
name = "Sabre Spin Ex"
command = ~D, DB, B, y+z
time = 16

[Command]
name = "Sabre Spin Ex"
command = ~D, DB, B, x+z
time = 16

;-------------------------------------------------------------------------

[Command]
name = "Sabre Roll"
command = ~D, DF, F, a
time = 16

[Command]
name = "Sabre Roll"
command = ~D, DF, F, ~a
time = 16

[Command]
name = "Sabre Roll"
command = ~D, DF, F, b
time = 16

[Command]
name = "Sabre Roll"
command = ~D, DF, F, ~b
time = 16

[Command]
name = "Sabre Roll"
command = ~D, DF, F, c
time = 16

[Command]
name = "Sabre Roll"
command = ~D, DF, F, ~c
time = 16

[Command]
name = "Sabre Roll Ex"
command = ~D, DF, F, a+b
time = 16

[Command]
name = "Sabre Roll Ex"
command = ~D, DF, F, b+c
time = 16

[Command]
name = "Sabre Roll Ex"
command = ~D, DF, F, a+c
time = 16

;-------------------------------------------------------------------------

[Command]
name = "Sabre Pounce"
command = ~D, DB, B, a
time = 16

[Command]
name = "Sabre Pounce"
command = ~D, DB, B, ~a
time = 16

[Command]
name = "Sabre Pounce"
command = ~D, DB, B, b
time = 16

[Command]
name = "Sabre Pounce"
command = ~D, DB, B, ~b
time = 16

[Command]
name = "Sabre Pounce"
command = ~D, DB, B, c
time = 16

[Command]
name = "Sabre Pounce"
command = ~D, DB, B, ~c
time = 16

[Command]
name = "Sabre Pounce Ex"
command = ~D, DB, B, a+b
time = 16

[Command]
name = "Sabre Pounce Ex"
command = ~D, DB, B, b+c
time = 16

[Command]
name = "Sabre Pounce Ex"
command = ~D, DB, B, a+c
time = 16

;-------------------------------------------------------------------------

[Command]
name = "Sabre Moon Slash"
command = ~F, D, DF, ~x
time = 16

[Command]
name = "Sabre Moon Slash"
command = ~F, D, DF, x
time = 16

[Command]
name = "Sabre Moon Slash"
command = ~F, D, DF, y
time = 16

[Command]
name = "Sabre Moon Slash"
command = ~F, D, DF, ~y
time = 16

[Command]
name = "Sabre Moon Slash"
command = ~F, D, DF, z
time = 16

[Command]
name = "Sabre Moon Slash"
command = ~F, D, DF, ~z
time = 16

[Command]
name = "Sabre Moon Slash Ex"
command = ~F, D, DF, x+y
time = 16

[Command]
name = "Sabre Moon Slash Ex"
command = ~F, D, DF, y+z
time = 16

[Command]
name = "Sabre Moon Slash Ex"
command = ~F, D, DF, x+z
time = 16

;-------------------------------------------------------------------------

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, z
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~z
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, b
time = 16

[Command]
name=  "412k" ;Zero Counter
command = ~B, DB, D, c
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~b
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~c
time = 16

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1

[Command]
name = "recovery"
command = y+z
time = 1

[Command]
name = "recovery"
command = x+z
time = 1

[Command]
name = "recovery"
command = a+x
time = 1

[Command]
name = "pp"
command = x+y
time = 1

[Command]
name = "pp"
command = x+z
time = 1

[Command]
name = "pp"
command = y+z
time = 1

[Command]
name = "kk"
command = a+b
time = 1

[Command]
name = "kk"
command = a+c
time = 1

[Command]
name = "kk"
command = b+c
time = 1

[Command]
name = "a+x"
command = a+x
time=1

[Command]
name = "b+y"
command = b+y
time = 1

[Command]
name = "c+z"
command = c+z
time = 1

;-| Dir + Button |---------------------------------------------------------
[Command]
name = "back_x"
command = /$B,x
time = 1

[Command]
name = "back_y"
command = /$B,y
time = 1

[Command]
name = "back_z"
command = /$B,z
time = 1

[Command]
name = "down_x"
command = /$D,x
time = 1

[Command]
name = "down_y"
command = /$D,y
time = 1

[Command]
name = "down_z"
command = /$D,z
time = 1

[Command]
name = "fwd_x"
command = /$F,x
time = 1

[Command]
name = "fwd_y"
command = /$F,y
time = 1

[Command]
name = "fwd_z"
command = /$F,z
time = 1

[Command]
name = "up_x"
command = /$U,x
time = 1

[Command]
name = "up_y"
command = /$U,y
time = 1

[Command]
name = "up_z"
command = /$U,z
time = 1

[Command]
name = "back_a"
command = /$B,a
time = 1

[Command]
name = "back_b"
command = /$B,b
time = 1

[Command]
name = "back_c"
command = /$B,c
time = 1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

[Command]
name = "down_c"
command = /$D,c
time = 1

[Command]
name = "fwd_a"
command = /$F,a
time = 1

[Command]
name = "fwd_b"
command = /$F,b
time = 1

[Command]
name = "fwd_c"
command = /$F,c
time = 1

[Command]
name = "up_a"
command = /$U,a
time = 1

[Command]
name = "up_b"
command = /$U,b
time = 1

[Command]
name = "up_c"
command = /$U,c
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1

;-| Single Dir |------------------------------------------------------------
[Command]
name = "fwd" ;Required (do not remove)
command = $F
time = 1

[Command]
name = "downfwd"
command = $DF
time = 1

[Command]
name = "down" ;Required (do not remove)
command = $D
time = 1

[Command]
name = "downback"
command = $DB
time = 1

[Command]
name = "back" ;Required (do not remove)
command = $B
time = 1

[Command]
name = "upback"
command = $UB
time = 1

[Command]
name = "up" ;Required (do not remove)
command = $U
time = 1

[Command]
name = "upfwd"
command = $UF
time = 1

;-| Hold Button |--------------------------------------------------------------
[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_s"
command = /s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holdfwd" ;Required (do not remove)
command = /$F
time = 1

[Command]
name = "holddownfwd"
command = /$DF
time = 1

[Command]
name = "holddown" ;Required (do not remove)
command = /$D
time = 1

[Command]
name = "holddownback"
command = /$DB
time = 1

[Command]
name = "holdback" ;Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdupback"
command = /$UB
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holdupfwd"
command = /$UF
time = 1

;---------------------------------------------------------------------------
;Release Direction
[Command]
name = "rlsfwd"
command = ~$F
time = 1

[Command]
name = "rlsback"
command = ~$B
time = 1

[Command]
name = "rlsup"
command = ~$U
time = 1

[Command]
name = "rlsdown"
command = ~$D
time = 1

;--------------------------------------------------------------------------
;Release Button
[Command]
name = "rlsx"
command = ~x
time = 1

[Command]
name = "rlsy"
command = ~y
time = 1

[Command]
name = "rlsz"
command = ~z
time = 1

[Command]
name = "rlsa"
command = ~a
time = 1

[Command]
name = "rlsb"
command = ~b
time = 1

[Command]
name = "rlsc"
command = ~c
time = 1
;---------------------------------------------------------------------------
;Other
[Command]
name = "highjump"
command = $D, $U
time = 15
;---------------------------------------------------------------------------
[Statedef -1]

[State -1, Tick Fix]
type = CtrlSet
triggerall = !ctrl
trigger1 = (StateNo = 52 || StateNo = 101 || StateNo = 5120) && !AnimTime
trigger2 = (StateNo = [200,499]) && !AnimTime
trigger3 = (StateNo = [760,762]) && !AnimTime
trigger4 = StateNo = 810 && !AnimTime
trigger5 = (StateNo = 5001 || StateNo = 5011 || StateNo = 151 || StateNo = 153) && HitOver
trigger6 = (StateNo = [700,715]) && !AnimTime
value = 1

[State -1, CtrlSet For Helpers];special thanks to 20S
type = CtrlSet
trigger1 = IsHelper
value = 0

[State -1, Hit Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(13) = 1

[State -1, Juggle Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(15) = 1

;---------------------------------------------------------------------------------------------------------------------

[State -1, Ultra Combo]
type = ChangeState
value = 3200
triggerall = !AIlevel
triggerall = command = "Ultra Combo"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3  = stateno  = 1000 && movecontact
trigger4  = stateno  = 1100 && movecontact
trigger5  = stateno  = 1200 && movecontact
trigger6  = stateno  = 1300 && movecontact
trigger7 = stateno  = 1400 && movecontact
trigger8 = stateno  = 200 && movecontact
trigger9 = stateno  = 210 && movecontact
trigger10 = stateno  = 220 && movecontact
trigger11 = stateno  = 230 && movecontact
trigger12 = stateno  = 240 && movecontact
trigger13 = stateno  = 250 && movecontact
trigger14 = stateno  = 400 && movecontact
trigger15 = stateno  = 410 && movecontact
trigger16 = stateno  = 420 && movecontact
trigger17 = stateno  = 430 && movecontact
trigger18 = stateno  = 440 && movecontact
trigger19 = stateno  = 450 && movecontact

;---------------------------------------------------------------------------------------------------------------------

[State -1, Shadow Sabre Spin Max]
type = ChangeState
value = 3035
triggerall = !AIlevel
triggerall = command = "Shadow Sabre Spin Max"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = !var(39)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3  = stateno  = 1000 && movecontact
trigger4  = stateno  = 1030 && movecontact
trigger5  = stateno  = 1100 && movecontact
trigger6  = stateno  = 1130 && movecontact
trigger7  = stateno  = 1200 && movecontact
trigger8  = stateno  = 1230 && movecontact
trigger9  = stateno  = 1300 && movecontact
trigger10 = stateno  = 1330 && movecontact
trigger11 = stateno  = 1400 && movecontact
trigger12 = stateno  = 1430 && movecontact
trigger13 = stateno  = 200 && movecontact
trigger14 = stateno  = 210 && movecontact
trigger15 = stateno  = 220 && movecontact
trigger16 = stateno  = 230 && movecontact
trigger17 = stateno  = 240 && movecontact
trigger18 = stateno  = 250 && movecontact
trigger19 = stateno  = 400 && movecontact
trigger20 = stateno  = 410 && movecontact
trigger21 = stateno  = 420 && movecontact
trigger22 = stateno  = 430 && movecontact
trigger23 = stateno  = 440 && movecontact
trigger24 = stateno  = 450 && movecontact
trigger25 = stateno  = 3000 && movecontact
trigger26 = stateno  = 3020 && movecontact
trigger27 = stateno  = 3030 && movecontact
trigger28 = stateno  = 3210 && movecontact

[State -1, Shadow Sabre Spin]
type = ChangeState
value = 3030
triggerall = !AIlevel
triggerall = command = "Shadow Sabre Spin"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = !var(39)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3  = stateno  = 1000 && movecontact
trigger4  = stateno  = 1030 && movecontact
trigger5  = stateno  = 1100 && movecontact
trigger6  = stateno  = 1130 && movecontact
trigger7  = stateno  = 1200 && movecontact
trigger8  = stateno  = 1230 && movecontact
trigger9  = stateno  = 1300 && movecontact
trigger10 = stateno  = 1330 && movecontact
trigger11 = stateno  = 1400 && movecontact
trigger12 = stateno  = 1430 && movecontact
trigger13 = stateno  = 200 && movecontact
trigger14 = stateno  = 210 && movecontact
trigger15 = stateno  = 220 && movecontact
trigger16 = stateno  = 230 && movecontact
trigger17 = stateno  = 240 && movecontact
trigger18 = stateno  = 250 && movecontact
trigger19 = stateno  = 400 && movecontact
trigger20 = stateno  = 410 && movecontact
trigger21 = stateno  = 420 && movecontact
trigger22 = stateno  = 430 && movecontact
trigger23 = stateno  = 440 && movecontact
trigger24 = stateno  = 450 && movecontact
trigger25 = stateno  = 3000 && movecontact
trigger26 = stateno  = 3020 && movecontact
trigger27 = stateno  = 3210 && movecontact

;---------------------------------------------------------------------------------------------------------------------

[State -1, Shadow Sabre Moon Slash Max]
type = ChangeState
value = 3025
triggerall = !AIlevel
triggerall = command = "Shadow Sabre Moon Slash Max"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = !var(39)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3  = stateno  = 1000 && movecontact
trigger4  = stateno  = 1030 && movecontact
trigger5  = stateno  = 1100 && movecontact
trigger6  = stateno  = 1130 && movecontact
trigger7  = stateno  = 1200 && movecontact
trigger8  = stateno  = 1230 && movecontact
trigger9  = stateno  = 1300 && movecontact
trigger10 = stateno  = 1330 && movecontact
trigger11 = stateno  = 1400 && movecontact
trigger12 = stateno  = 1430 && movecontact
trigger13 = stateno  = 200 && movecontact
trigger14 = stateno  = 210 && movecontact
trigger15 = stateno  = 220 && movecontact
trigger16 = stateno  = 230 && movecontact
trigger17 = stateno  = 240 && movecontact
trigger18 = stateno  = 250 && movecontact
trigger19 = stateno  = 400 && movecontact
trigger20 = stateno  = 410 && movecontact
trigger21 = stateno  = 420 && movecontact
trigger22 = stateno  = 430 && movecontact
trigger23 = stateno  = 440 && movecontact
trigger24 = stateno  = 450 && movecontact
trigger25 = stateno  = 3000 && movecontact
trigger26 = stateno  = 3210 && movecontact
trigger27 = stateno  = 3020 && movecontact
trigger28 = stateno  = 3030 && movecontact

[State -1, Shadow Sabre Moon Slash]
type = ChangeState
value = 3020
triggerall = !AIlevel
triggerall = command = "Shadow Sabre Moon Slash"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = !var(39)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3  = stateno  = 1000 && movecontact
trigger4  = stateno  = 1030 && movecontact
trigger5  = stateno  = 1100 && movecontact
trigger6  = stateno  = 1130 && movecontact
trigger7  = stateno  = 1200 && movecontact
trigger8  = stateno  = 1230 && movecontact
trigger9  = stateno  = 1300 && movecontact
trigger10 = stateno  = 1330 && movecontact
trigger11 = stateno  = 1400 && movecontact
trigger12 = stateno  = 1430 && movecontact
trigger13 = stateno  = 200 && movecontact
trigger14 = stateno  = 210 && movecontact
trigger15 = stateno  = 220 && movecontact
trigger16 = stateno  = 230 && movecontact
trigger17 = stateno  = 240 && movecontact
trigger18 = stateno  = 250 && movecontact
trigger19 = stateno  = 400 && movecontact
trigger20 = stateno  = 410 && movecontact
trigger21 = stateno  = 420 && movecontact
trigger22 = stateno  = 430 && movecontact
trigger23 = stateno  = 440 && movecontact
trigger24 = stateno  = 450 && movecontact
trigger25 = stateno  = 3000 && movecontact
trigger26 = stateno  = 3210 && movecontact
trigger27 = stateno  = 3030 && movecontact

;---------------------------------------------------------------------------------------------------------------------

[State -1, Shadow Sabre Roll Max]
type = ChangeState
value = 3215
triggerall = !AIlevel
triggerall = command = "Shadow Sabre Roll Max"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = !var(39)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3  = stateno  = 1000 && movecontact
trigger4  = stateno  = 1030 && movecontact
trigger5  = stateno  = 1100 && movecontact
trigger6  = stateno  = 1130 && movecontact
trigger7  = stateno  = 1200 && movecontact
trigger8  = stateno  = 1230 && movecontact
trigger9  = stateno  = 1300 && movecontact
trigger10 = stateno  = 1330 && movecontact
trigger11 = stateno  = 1400 && movecontact
trigger12 = stateno  = 1430 && movecontact
trigger13 = stateno  = 200 && movecontact
trigger14 = stateno  = 210 && movecontact
trigger15 = stateno  = 220 && movecontact
trigger16 = stateno  = 230 && movecontact
trigger17 = stateno  = 240 && movecontact
trigger18 = stateno  = 250 && movecontact
trigger19 = stateno  = 400 && movecontact
trigger20 = stateno  = 410 && movecontact
trigger21 = stateno  = 420 && movecontact
trigger22 = stateno  = 430 && movecontact
trigger23 = stateno  = 440 && movecontact
trigger24 = stateno  = 450 && movecontact
trigger25 = stateno  = 3000 && movecontact
trigger26 = stateno  = 3210 && movecontact
trigger27 = stateno  = 3020 && movecontact
trigger28 = stateno  = 3030 && movecontact

[State -1, Shadow Sabre Roll]
type = ChangeState
value = 3210
triggerall = !AIlevel
triggerall = command = "Shadow Sabre Roll"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = !var(39)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3  = stateno  = 1000 && movecontact
trigger4  = stateno  = 1030 && movecontact
trigger5  = stateno  = 1100 && movecontact
trigger6  = stateno  = 1130 && movecontact
trigger7  = stateno  = 1200 && movecontact
trigger8  = stateno  = 1230 && movecontact
trigger9  = stateno  = 1300 && movecontact
trigger10 = stateno  = 1330 && movecontact
trigger11 = stateno  = 1400 && movecontact
trigger12 = stateno  = 1430 && movecontact
trigger13 = stateno  = 200 && movecontact
trigger14 = stateno  = 210 && movecontact
trigger15 = stateno  = 220 && movecontact
trigger16 = stateno  = 230 && movecontact
trigger17 = stateno  = 240 && movecontact
trigger18 = stateno  = 250 && movecontact
trigger19 = stateno  = 400 && movecontact
trigger20 = stateno  = 410 && movecontact
trigger21 = stateno  = 420 && movecontact
trigger22 = stateno  = 430 && movecontact
trigger23 = stateno  = 440 && movecontact
trigger24 = stateno  = 450 && movecontact
trigger25 = stateno  = 3000 && movecontact
trigger26 = stateno  = 3020 && movecontact
trigger27 = stateno  = 3030 && movecontact

;---------------------------------------------------------------------------------------------------------------------

[State -1, Shadow Flaming Bat Max]
type = ChangeState
value = 3005
triggerall = !AIlevel
triggerall = command = "Shadow Flaming Bat Max"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || var(7) || (StateNo = [100,101])
trigger1 = NumHelper(3115) <= 0
trigger2 = NumHelper(3115) <= 1
trigger2 = Helper(3115),StateNo=[1014,1016]
trigger3  = stateno  = 1000 && movecontact
trigger4  = stateno  = 1030 && movecontact
trigger5  = stateno  = 1100 && movecontact
trigger6  = stateno  = 1130 && movecontact
trigger7  = stateno  = 1200 && movecontact
trigger8  = stateno  = 1230 && movecontact
trigger9  = stateno  = 1300 && movecontact
trigger10 = stateno  = 1330 && movecontact
trigger11 = stateno  = 1400 && movecontact
trigger12 = stateno  = 1430 && movecontact
trigger13 = stateno  = 200 && movecontact
trigger14 = stateno  = 210 && movecontact
trigger15 = stateno  = 220 && movecontact
trigger16 = stateno  = 230 && movecontact
trigger17 = stateno  = 240 && movecontact
trigger18 = stateno  = 250 && movecontact
trigger19 = stateno  = 400 && movecontact
trigger20 = stateno  = 410 && movecontact
trigger21 = stateno  = 420 && movecontact
trigger22 = stateno  = 430 && movecontact
trigger23 = stateno  = 440 && movecontact
trigger24 = stateno  = 450 && movecontact
trigger25 = stateno  = 3000 && movecontact
trigger26 = stateno  = 3210 && movecontact
trigger27 = stateno  = 3020 && movecontact
trigger28 = stateno  = 3030 && movecontact

[State -1, Shadow Flaming Bat]
type = ChangeState
value = 3000
triggerall = !AIlevel
triggerall = command = "Shadow Flaming Bat"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(6) || (StateNo = [100,101])
trigger1 = NumHelper(3110) <= 0
trigger2 = NumHelper(3110) <= 1
trigger2 = Helper(3110),StateNo=[1014,1016]
trigger3  = stateno  = 1000 && movecontact
trigger4  = stateno  = 1030 && movecontact
trigger5  = stateno  = 1100 && movecontact
trigger6  = stateno  = 1130 && movecontact
trigger7  = stateno  = 1200 && movecontact
trigger8  = stateno  = 1230 && movecontact
trigger9  = stateno  = 1300 && movecontact
trigger10 = stateno  = 1330 && movecontact
trigger11 = stateno  = 1400 && movecontact
trigger12 = stateno  = 1430 && movecontact
trigger13 = stateno  = 200 && movecontact
trigger14 = stateno  = 210 && movecontact
trigger15 = stateno  = 220 && movecontact
trigger16 = stateno  = 230 && movecontact
trigger17 = stateno  = 240 && movecontact
trigger18 = stateno  = 250 && movecontact
trigger19 = stateno  = 400 && movecontact
trigger20 = stateno  = 410 && movecontact
trigger21 = stateno  = 420 && movecontact
trigger22 = stateno  = 430 && movecontact
trigger23 = stateno  = 440 && movecontact
trigger24 = stateno  = 450 && movecontact
trigger25 = stateno  = 3210 && movecontact
trigger26 = stateno  = 3020 && movecontact
trigger27 = stateno  = 3030 && movecontact

;---------------------------------------------------------------------------------------------------------------------

[State -1, Sabre Moon Slash Ex]
type = ChangeState
value = 1430
triggerall = !AIlevel
triggerall = command = "Sabre Moon Slash Ex"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3  = stateno  = 200 && movecontact
trigger4  = stateno  = 210 && movecontact
trigger5  = stateno  = 220 && movecontact
trigger6  = stateno  = 230 && movecontact
trigger7  = stateno  = 240 && movecontact
trigger8  = stateno  = 250 && movecontact
trigger9  = stateno  = 400 && movecontact
trigger10 = stateno  = 410 && movecontact
trigger11 = stateno  = 420 && movecontact
trigger12 = stateno  = 430 && movecontact
trigger13 = stateno  = 440 && movecontact
trigger14 = stateno  = 450 && movecontact
trigger15 = stateno  = 1400 && movecontact

[State -1, Sabre Moon Slash]
type = ChangeState
value = 1400
triggerall = !AIlevel
triggerall = command = "Sabre Moon Slash"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3  = stateno  = 200 && movecontact
trigger4  = stateno  = 210 && movecontact
trigger5  = stateno  = 220 && movecontact
trigger6  = stateno  = 230 && movecontact
trigger7  = stateno  = 240 && movecontact
trigger8  = stateno  = 250 && movecontact
trigger9  = stateno  = 400 && movecontact
trigger10 = stateno  = 410 && movecontact
trigger11 = stateno  = 420 && movecontact
trigger12 = stateno  = 430 && movecontact
trigger13 = stateno  = 440 && movecontact
trigger14 = stateno  = 450 && movecontact

;---------------------------------------------------------------------------------------------------------------------

[State -1, Sabre Pounce Ex]
type = ChangeState
value = 1330
triggerall = !AIlevel
triggerall = command = "Sabre Pounce Ex"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3  = stateno  = 200 && movecontact
trigger4  = stateno  = 210 && movecontact
trigger5  = stateno  = 220 && movecontact
trigger6  = stateno  = 230 && movecontact
trigger7  = stateno  = 240 && movecontact
trigger8  = stateno  = 250 && movecontact
trigger9  = stateno  = 400 && movecontact
trigger10 = stateno  = 410 && movecontact
trigger11 = stateno  = 420 && movecontact
trigger12 = stateno  = 430 && movecontact
trigger13 = stateno  = 440 && movecontact
trigger14 = stateno  = 450 && movecontact
trigger15 = stateno  = 1300 && movecontact

[State -1, Sabre Pounce]
type = ChangeState
value = 1300
triggerall = !AIlevel
triggerall = command = "Sabre Pounce"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3  = stateno  = 200 && movecontact
trigger4  = stateno  = 210 && movecontact
trigger5  = stateno  = 220 && movecontact
trigger6  = stateno  = 230 && movecontact
trigger7  = stateno  = 240 && movecontact
trigger8  = stateno  = 250 && movecontact
trigger9  = stateno  = 400 && movecontact
trigger10 = stateno  = 410 && movecontact
trigger11 = stateno  = 420 && movecontact
trigger12 = stateno  = 430 && movecontact
trigger13 = stateno  = 440 && movecontact
trigger14 = stateno  = 450 && movecontact

;---------------------------------------------------------------------------------

[State -1, Sabre Roll Ex]
type = ChangeState
value = 1230
triggerall = !AIlevel
triggerall = command = "Sabre Roll Ex"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3  = stateno   = 200 && movecontact
trigger4  = stateno   = 210 && movecontact
trigger5  = stateno   = 220 && movecontact
trigger6  = stateno   = 230 && movecontact
trigger7  = stateno   = 240 && movecontact
trigger8  = stateno   = 250 && movecontact
trigger9  = stateno   = 400 && movecontact
trigger10 = stateno   = 410 && movecontact
trigger11 = stateno   = 420 && movecontact
trigger12 = stateno   = 430 && movecontact
trigger13 = stateno   = 440 && movecontact
trigger14 = stateno   = 450 && movecontact
trigger15 = stateno  = 1200 && movecontact

[State -1, Sabre Roll]
type = ChangeState
value = 1200
triggerall = !AIlevel
triggerall = command = "Sabre Roll"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3  = stateno  = 200 && movecontact
trigger4  = stateno  = 210 && movecontact
trigger5  = stateno  = 220 && movecontact
trigger6  = stateno  = 230 && movecontact
trigger7  = stateno  = 240 && movecontact
trigger8  = stateno  = 250 && movecontact
trigger9  = stateno  = 400 && movecontact
trigger10 = stateno  = 410 && movecontact
trigger11 = stateno  = 420 && movecontact
trigger12 = stateno  = 430 && movecontact
trigger13 = stateno  = 440 && movecontact
trigger14 = stateno  = 450 && movecontact

;---------------------------------------------------------------------------------

[State -1, Sabre Spin Ex]
type = ChangeState
value = 1130
triggerall = !AIlevel
triggerall = command = "Sabre Spin Ex"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3  = stateno   = 200 && movecontact
trigger4  = stateno   = 210 && movecontact
trigger5  = stateno   = 220 && movecontact
trigger6  = stateno   = 230 && movecontact
trigger7  = stateno   = 240 && movecontact
trigger8  = stateno   = 250 && movecontact
trigger9  = stateno   = 400 && movecontact
trigger10 = stateno   = 410 && movecontact
trigger11 = stateno   = 420 && movecontact
trigger12 = stateno   = 430 && movecontact
trigger13 = stateno   = 440 && movecontact
trigger14 = stateno   = 450 && movecontact
trigger15 = stateno  = 1100 && movecontact

[State -1, Sabre Spin]
type = ChangeState
value = 1100
triggerall = !AIlevel
triggerall = command = "Sabre Spin"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3  = stateno  = 200 && movecontact
trigger4  = stateno  = 210 && movecontact
trigger5  = stateno  = 220 && movecontact
trigger6  = stateno  = 230 && movecontact
trigger7  = stateno  = 240 && movecontact
trigger8  = stateno  = 250 && movecontact
trigger9  = stateno  = 400 && movecontact
trigger10 = stateno  = 410 && movecontact
trigger11 = stateno  = 420 && movecontact
trigger12 = stateno  = 430 && movecontact
trigger13 = stateno  = 440 && movecontact
trigger14 = stateno  = 450 && movecontact

;----------------------------------------------------------------------------------

[State -1, Flaming Bat Ex]
type = ChangeState
value = 1030
triggerall = !AIlevel
triggerall = command = "Flaming Bat Ex"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101]) || var(5)
trigger1 = NumHelper(2010) <= 0
trigger2 = NumHelper(2010) <= 1
trigger2 = Helper(2010),StateNo = [2016,2015]
trigger3  = stateno   = 200 && movecontact
trigger4  = stateno   = 210 && movecontact
trigger5  = stateno   = 220 && movecontact
trigger6  = stateno   = 230 && movecontact
trigger7  = stateno   = 240 && movecontact
trigger8  = stateno   = 250 && movecontact
trigger9  = stateno   = 400 && movecontact
trigger10 = stateno   = 410 && movecontact
trigger11 = stateno   = 420 && movecontact
trigger12 = stateno   = 430 && movecontact
trigger13 = stateno   = 440 && movecontact
trigger14 = stateno   = 450 && movecontact
trigger15 = stateno  = 1000 && movecontact

[State -1, Flaming Bat]
type = ChangeState
value = 1000
triggerall = !AIlevel
triggerall = command = "Flaming Bat"
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || var(5)
trigger1 = NumHelper(2010) <= 0
trigger2 = NumHelper(2010) <= 1
trigger2 = Helper(2010),StateNo = [2016,2015]
trigger3  = stateno  = 200 && movecontact
trigger4  = stateno  = 210 && movecontact
trigger5  = stateno  = 220 && movecontact
trigger6  = stateno  = 230 && movecontact
trigger7  = stateno  = 240 && movecontact
trigger8  = stateno  = 250 && movecontact
trigger9  = stateno  = 400 && movecontact
trigger10 = stateno  = 410 && movecontact
trigger11 = stateno  = 420 && movecontact
trigger12 = stateno  = 430 && movecontact
trigger13 = stateno  = 440 && movecontact
trigger14 = stateno  = 450 && movecontact

;----------------------------------------------------------------------------------

[State -1, Zero Counter]
type = ChangeState
value = 750
triggerall = !AIlevel
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = command = "412p" || command = "412k"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1, Throw Forward]
type = ChangeState
value = 800
triggerall = !AIlevel
trigger1 = (command = "holdfwd" || command = "holdback") && command = "pp" 
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl

[State -1, Throw Back]
type = ChangeState
value = 900
triggerall = !AIlevel
trigger1 = (command = "holdfwd" || command = "holdback") && command = "kk" 
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl

[State -1, Roll Forward]
type = ChangeState
value = 710
triggerall = !AIlevel
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdfwd"

[State -1, Roll Back]
type = ChangeState
value = 715
triggerall = !AIlevel
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdback"

[State -1, Power Charge]
type = ChangeState
value = 730
triggerall = !AIlevel
trigger1 = command = "hold_b" && command = "hold_y"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (StateNo = [100,101])

[State -1, MAX Mode]
type = ChangeState
value = 770
triggerall = !AIlevel
triggerall = command = "c+z"
triggerall = RoundState = 2 && StateType != A
triggerall = var(20) <= 0 && Power >= 1000
trigger1 = ctrl || (Stateno = [100,101])

[State -1, Dodge]
type = ChangeState
value = 700
triggerall = !AIlevel
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))

[State -1, Run Fwd]
type = ChangeState
value = 110
triggerall = !AIlevel
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !AIlevel
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;--------------------------------------------------------------------------
[State -1, Stand Light Punch]
type = ChangeState
value = 200
triggerall = !AIlevel
triggerall = command = "x"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])

[State -1, Stand Medium Punch]
type = ChangeState
value = 210
triggerall = !AIlevel
triggerall = command = "y"
triggerall = command != "holddown"  
triggerall = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 200 && movecontact

[State -1, Stand Strong Punch]
type = ChangeState
value = 220
triggerall = !AIlevel
triggerall = command = "z"
triggerall = command != "holddown" 
triggerall = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 210 && movecontact

[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerall = !AIlevel
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])

[State -1, Stand Medium Kick]
type = ChangeState
value = 240
triggerall = !AIlevel
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2 = stateno = 230 && movecontact

[State -1, Standing Strong Kick]
type = ChangeState
value = 250
triggerall = !AIlevel
triggerall = command = "c"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2 = stateno = 240 && movecontact

[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "x"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])

[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "y"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 400 && movecontact

[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "z"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 410 && movecontact

[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "a"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])

[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "b"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 430 && movecontact

[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "c"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 440 && movecontact

[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = !AIlevel
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Medium Punch]
type = ChangeState
value = 610
triggerall = !AIlevel
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Punch]
type = ChangeState
value = ifElse(vel x, 621, 620)
triggerAll = !AILevel
triggerAll = command = "z"
triggerAll = StateType = A
trigger1 = ctrl
trigger2 = var(4)

[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerall = !AIlevel
triggerall = command = "a"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Angled Jumping Light Kick]
type = ChangeState
value = 631
triggerAll = !AILevel
triggerAll = command = "a"
triggerAll = StateType = A
triggerAll = vel x
trigger1 = ctrl
trigger2 = var(4)

[State -1, Jump Medium Kick]
type = ChangeState
value = 640
triggerall = !AIlevel
triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Angled Jumping Medium Kick]
type = ChangeState
value = 641
triggerAll = !AILevel
triggerAll = command = "b"
triggerAll = StateType = A
triggerAll = vel x
trigger1 = ctrl
trigger2 = var(4)

[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerall = !AIlevel
triggerall = command = "c"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Angled Jumping Strong Kick]
type = ChangeState
value = 651
triggerAll = !AILevel
triggerAll = command = "c"
triggerAll = StateType = A
triggerAll = !vel x
trigger1 = ctrl
trigger2 = var(4)

[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !AIlevel
triggerall = command = "s"
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = var(5)

;=====================================
;=================AI==================
;=====================================

[State -1, Fall Recovery (Air)]
type = ChangeState
value = 5210
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && Alive
trigger1 = StateNo = 5050 && CanRecover
trigger1 = vel y > 0 && pos y < -20
trigger1 = Random < (25 * (AILevel ** 2 / 64.0))

[State -1, Fall Recovery (Ground)]
type = ChangeState
value = 5200
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && Alive
trigger1 = StateNo = 5050 && GetHitVar(fall.recover)
trigger1 = vel y > 0 && pos y >= -20
trigger1 = Random < (100 * (AILevel ** 2 / 64.0))

[State -1, Jump]
type = ChangeState
value = 40
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A && ctrl
trigger1 = EnemyNear, MoveType = A && P2BodyDist x < 160 && EnemyNear, HitDefAttr = SC, AT

[State -1, Zero Counter]
type = ChangeState
value = 750
trigger1 = AILevel && NumEnemy
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power >= 1000 && var(20) <= 60
trigger1 = Random < (25 * (AILevel ** 2 / 64.0))
trigger1 = (P2BodyDist x = [0,50]) && (Life < 0.5 * LifeMax)

[State -1, Roll Forward]
type = ChangeState
value = 710
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Random < (50 * (AILevel ** 2 / 64.0))
trigger1 = (ctrl || (StateNo = [100,101])) && var(20) <= 164 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && !(EnemyNear, HitDefAttr = SCA, AT) && (P2BodyDist x = [92,122])

[State -1, Dodge]
type = ChangeState
value = 700
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Random < (50 * (AIlevel ** 2 / 64.0))
trigger1 = (ctrl || (StateNo = [100,101])) && var(20) <= 164 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && !(EnemyNear, HitDefAttr = SCA, AT) && (P2BodyDist x = [0,60])

[State -1, Dash Backward]
type = ChangeState
value = 105
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = S
triggerAll = ctrl && (StateNo != [100,106]) && var(20) <= 150 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && BackEdgeDist >= 80 && (P2BodyDist x = [80,120]) && (EnemyNear, vel x)
trigger1 = Random < (ifElse((EnemyNear, HitDefAttr = SC, AT), 150, 50) * (AILevel ** 2 / 64.0))
trigger2 = (P2BodyDist x = [0,80]) && BackEdgeBodyDist >= 80
trigger2 = EnemyNear, StateNo = 5120 && EnemyNear, AnimTime = -4 && Random < (750 * (AILevel ** 2 / 64.0))

[State -1, Guard]
type = ChangeState
value = 120
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && InGuardDist
trigger1 = ctrl && (StateNo != [120, 155]) && !var(20)
trigger1 = !var(26) || P2BodyDist x >= 40
trigger1 = !(EnemyNear, HitDefAttr = SCA, AT) && (EnemyNear, Time < 120)
trigger1 = StateType != A || P2StateType = A
trigger1 = ifElse(StateType = A, ((var(3) != [1, 2]) || StateNo = 5210), 1)
trigger1 = Random < (ifElse((P2StateNo = [200, 699]), 100, ifElse((P2StateNo = [1000,2999]), 333, 1000)) * (AILevel ** 2 / 64.0))

[State -1, Zero Counter]
type = ChangeState
value = 750
trigger1 = AILevel && NumEnemy
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power >= 1000 && var(20) <= 60
trigger1 = Random < (25 * (AILevel ** 2 / 64.0))
trigger1 = (P2BodyDist x = [0,50]) && (Life < 0.5 * LifeMax)

[State -1, Power Charge]
type = ChangeState
value = 730
triggerAll = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power < const(data.power) && !var(20)
trigger1 = ctrl && Power < const(data.power) && Power < PowerMax && !var(20)
trigger1 = !InGuardDist && P2BodyDist x >= 160 && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Throw]
type = ChangeState
value = 800
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = S
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [-20,24]) && P2BodyDist y = 0
trigger1 = ctrl && Random < (125 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl && (P2StateNo = [120,140]) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Throw]
type = ChangeState
value = 900
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = S
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [-20,24]) && P2BodyDist y = 0
trigger1 = ctrl && Random < (125 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl && (P2StateNo = [120,140]) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Run]
type = ChangeState
value = 100
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl && (StateNo != [100,106])
trigger1 = (EnemyNear, MoveType != A) && P2BodyDist x >= 160 && Random < (25 * (AILevel ** 2 / 64.0))

[State -1, Guard]
type = ChangeState
value = 120
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && InGuardDist
trigger1 = ctrl && (StateNo != [120, 155]) && !var(20)
trigger1 = !var(26) || P2BodyDist x >= 40
trigger1 = !(EnemyNear, HitDefAttr = SCA, AT) && (EnemyNear, Time < 120)
trigger1 = StateType != A || P2StateType = A
trigger1 = ifElse(StateType = A, ((var(3) != [1, 2]) || StateNo = 5210), 1)
trigger1 = Random < (ifElse((P2StateNo = [200, 699]), 100, ifElse((P2StateNo = [1000,2999]), 333, 1000)) * (AILevel ** 2 / 64.0))

[State -1, Taunt]
type = ChangeState
value = 195
triggerAll = AILevel && NumEnemy
triggerAll = StateType != A && Life >= 0.5 * LifeMax
triggerAll = (EnemyNear, Life) <= 0.5 * (EnemyNear, LifeMax)
trigger1 = ctrl
trigger1 = P2Dist x >= 160 && !(EnemyNear, ctrl)
trigger1 = (EnemyNear, MoveType = H) && (EnemyNear, HitFall) && Random < (50 * (AILevel ** 2 / 64.0))

;----------------------------------------------------------------------------------------------------------------------------------

[State -1, Ultra Combo]
type = ChangeState
value = 3200
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 3000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 3 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (EnemyNear, MoveType != A) || (EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-46,46]) && (P2Dist y = [-69,0])
triggerAll = (EnemyNear, vel x = [-5,5]) && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && (EnemyNear, HitFall)
trigger2 = Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 3

[State -1, Shadow Sabre Moon Slash Max]
type = ChangeState
value = 3025
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 2000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 3 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-46,46]) && (P2Dist y = [-69,0])
triggerAll = (EnemyNear, vel x = [-5,5]) && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && (EnemyNear, HitFall)
trigger2 = Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger3 = var(8) && Random < (100 * (AILevel ** 2 / 64.0))
trigger3 = StateNo = 3001 && AnimElemTime(9) < 0
trigger3 = EnemyNear, GetHitVar(HitTime) >= 3

[State -1, Shadow Sabre Moon Slash]
type = ChangeState
value = 3020
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 1000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 3 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (EnemyNear, MoveType != A) || (EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-46,46]) && (P2Dist y = [-69,0])
triggerAll = (EnemyNear, vel x = [-5,5]) && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && (EnemyNear, HitFall)
trigger2 = Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 3

[State -1, Shadow Sabre Spin Max]
type = ChangeState
value = 3035
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 2000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-140,140]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Sabre Spin]
type = ChangeState
value = 3030
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 1000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-100,100]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != A
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Wind Kick Max]
type = ChangeState
value = 3215
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 2000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-140,140]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Sabre Roll]
type = ChangeState
value = 3210
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 1000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-100,100]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != A
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Flaming Bat Max]
type = ChangeState
value = 3005
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 2000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-140,140]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Flaming Bat]
type = ChangeState
value = 3000
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 1000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-100,100]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != A
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Sabre Roll]
type = ChangeState
value = ifElse((var(40) = 0 || var(40) = 3) && Power >= 500 && Random < 133, 1230, 1200)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = ((P2BodyDist x = [-10,30]) && P2StateType != A) || ((P2BodyDist x = [-10,70]) && P2StateType = A)
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = var(6) && MoveHit && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 3
trigger3 = (StateNo = 5120 || StateNo = 5201) && !AnimTime && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Sabre Pounce]
type = ChangeState
value = ifElse((var(40) = 0 || var(40) = 3) && Power >= 500 && Random < 100, 1330 + 5 * (var(40) = 3), 1300 + 5 * (var(40) = 3))
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (EnemyNear, MoveType != A) || (EnemyNear, StateNo = [200, 499])
triggerAll = (P2BodyDist x = [-8,165]) && P2StateType != A && (P2StateType != L || P2StateNo = 5120)
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101]))
trigger1 = P2BodyDist x >= 15 && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (ctrl || StateNo = 52 || (StateNo = [100,101]))
trigger2 = (EnemyNear, StateNo = 5120 || EnemyNear, StateNo = 5201) && (EnemyNear, AnimTime = -18) && Random < (125 * (AILevel ** 2 / 64.0))
trigger3 = var(6) && MoveHit && Random < (50 * (AILevel ** 2 / 64.0))
trigger3 = EnemyNear, GetHitVar(HitTime) >= 6

[State -1, Sabre Spin]
type = ChangeState
value = ifElse((var(40) = 0 || var(40) = 3) && Power >= 500 && Random < 100, 1130 + 5 * (var(40) = 3), 1100 + 5 * (var(40) = 3))
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = (EnemyNear, MoveType != A) || (EnemyNear, StateNo = [200, 499])
triggerAll = (P2BodyDist x = [-8,165]) && P2StateType != A && (P2StateType != L || P2StateNo = 5120)
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101]))
trigger1 = P2BodyDist x >= 15 && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (ctrl || StateNo = 52 || (StateNo = [100,101]))
trigger2 = (EnemyNear, StateNo = 5120 || EnemyNear, StateNo = 5201) && (EnemyNear, AnimTime = -18) && Random < (125 * (AILevel ** 2 / 64.0))
trigger3 = var(6) && MoveHit && Random < (50 * (AILevel ** 2 / 64.0))
trigger3 = EnemyNear, GetHitVar(HitTime) >= 6

[State -1, Sabre Moon Slash]
type = ChangeState
value = ifElse((var(40) = 0 || var(40) = 3) && Power >= 500 && Random < 133, 1430, 1400)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = P2StateType != L && (P2Dist y = [-80,32])
triggerAll = ((P2BodyDist x = [-48,48]) && P2StateType != A) || ((P2BodyDist x = [-140,140]) && P2StateType = A)
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = var(6) && MoveHit && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 3
trigger3 = (StateNo = 5120 || StateNo = 5201) && !AnimTime && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Flaming Bat]
type = ChangeState
value = ifElse((var(40) = 0 || var(40) = 3) && Power >= 500 && Random < 100, 1030, 1000)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(39)
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = P2BodyDist x >= 25 && P2Dist y >= -120 && EnemyNear, vel y >= 0
triggerAll = P2StateType != A || EnemyNear, vel x < 0
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (ctrl || StateNo = 52 || (StateNo = [100,101]))
trigger2 = EnemyNear, StateNo = 195 && Random < (50 * (AILevel ** 2 / 64.0))

;---------------------------------------------------------------------------------------------------------------------------

[State -1, Stand Light Punch]
type = ChangeState
value = 200
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,63]) && (P2Dist y = [-87,0]) && P2StateType != C && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Stand Medium Punch]
type = ChangeState
value = 210
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,80]) && (P2Dist y = [-129,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))
trigger3 = var(24)

[State -1, Stand Strong Punch]
type = ChangeState
value = 220
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,101]) && (P2Dist y = [-111,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,72]) && (P2Dist y = [-23,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 2) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Stand Medium Kick]
type = ChangeState
value = 240
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,60]) && (P2Dist y = [-115,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Standing Strong Kick]
type = ChangeState
value = 250
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,80]) && (P2Dist y = [-120,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 4) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,61]) && (P2Dist y = [-54,0]) && P2StateType != A && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 2) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,70]) && (P2Dist y = [-52,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && Statetype != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,50]) && (P2Dist y = [-132,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 4) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,90]) && (P2Dist y = [-27,0]) && P2StateType != A && P2StateType != L
trigger1 = (ctrl || (StateNo = [100, 101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200, 499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,111]) && (P2Dist y = [-33,0]) && P2StateType != A && P2StateType != L
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,97]) && (P2Dist y = [-33,0]) && P2StateType != A && P2StateType != L
triggerAll = (P2StateType = S || (P2StateType = C && P2MoveType = H))
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 6) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,41]) && (P2Dist y = [-56,28]) && P2StateType = S
trigger1 = ctrl
trigger1 = vel y > 0 && Random < (100 * (AIlevel ** 2 / 64.0))

[State -1, Jump Medium Punch]
type = ChangeState
value = 610
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,42]) && (P2Dist y = [-80,50]) && P2StateType = S
trigger1 = ctrl
trigger1 = vel y > 0 && Random < (100 * (AILevel ** 2 / 64.0))

[State -1, Jump Strong Punch]
type = ChangeState
value = 620
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,45]) && (P2Dist y = [-64,50]) && P2StateType = S
trigger1 = ctrl
trigger1 = vel y > 0 && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(4) && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,32]) && (P2Dist y = [-117,40]) && P2StateType != L
trigger1 = ctrl
trigger1 = vel y > 0 && Random < (ifElse(P2Dist x < 0, 250, 50) * (AILevel ** 2 / 64.0))

[State -1, Jump Medium Kick]
type = ChangeState
value = 640
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,79]) && (P2Dist y = [-60,40]) && P2StateType = A
trigger1 = ctrl
trigger1 = vel y <= 0 && Random < (100 * (AILevel ** 2 / 64.0))

[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,92]) && (P2Dist y = [-116,50]) && P2StateType = S
trigger1 = ctrl && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(4) && Random < (50 * (AILevel ** 2 / 64.0))