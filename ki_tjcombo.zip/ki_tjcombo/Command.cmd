;-| Button Remapping |-----------------------------------------------------
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s
;-| Default Values |-------------------------------------------------------
[Defaults]
command.time = 15
command.buffer.time = 1

;-| Super Motions |--------------------------------------------------------

[Command]
name = "Shadow Tumble"
command = ~D, DF, F, D, DF, x
time = 32

[Command]
name = "Shadow Tumble"
command = ~D, DF, F, D, DF, ~x
time = 32

[Command]
name = "Shadow Tumble"
command = ~D, DF, F, D, DF, y
time = 32

[Command]
name = "Shadow Tumble"
command = ~D, DF, F, D, DF, ~y
time = 32

[Command]
name = "Shadow Tumble"
command = ~D, DF, F, D, DF, z
time = 32

[Command]
name = "Shadow Tumble"
command = ~D, DF, F, D, DF, ~z
time = 32

[Command]
name = "Shadow Tumble Max"
command = ~D, DF, F, D, DF, x+y
time = 32

[Command]
name = "Shadow Tumble Max"
command = ~D, DF, F, D, DF, y+z
time = 32

[Command]
name = "Shadow Tumble Max"
command = ~D, DF, F, D, DF, x+z
time = 32

;------------------------------

[Command]
name = "Shadow Power Line"
command = ~D, DB, B, D, DB, x
time = 32

[Command]
name = "Shadow Power Line"
command = ~D, DB, B, D, DB, ~x
time = 32

[Command]
name = "Shadow Power Line"
command = ~D, DB, B, D, DB, y
time = 32

[Command]
name = "Shadow Power Line"
command = ~D, DB, B, D, DB, ~y
time = 32

[Command]
name = "Shadow Power Line"
command = ~D, DB, B, D, DB, z
time = 32

[Command]
name = "Shadow Power Line"
command = ~D, DB, B, D, DB, ~z
time = 32

[Command]
name = "Shadow Power Line Max"
command = ~D, DB, B, D, DB, x+y
time = 32

[Command]
name = "Shadow Power Line Max"
command = ~D, DB, B, D, DB, y+z
time = 32

[Command]
name = "Shadow Power Line Max"
command = ~D, DB, B, D, DB, x+z
time = 32

;------------------------------

[Command]
name = "Shadow Flying knee"
command = ~D, DF, F, D, DF, a
time = 32

[Command]
name = "Shadow Flying knee"
command = ~D, DF, F, D, DF, ~a
time = 32

[Command]
name = "Shadow Flying knee"
command = ~D, DF, F, D, DF, b
time = 32

[Command]
name = "Shadow Flying knee"
command = ~D, DF, F, D, DF, ~b
time = 32

[Command]
name = "Shadow Flying knee"
command = ~D, DF, F, D, DF, c
time = 32

[Command]
name = "Shadow Flying knee"
command = ~D, DF, F, D, DF, ~c
time = 32

[Command]
name = "Shadow Flying knee Max"
command = ~D, DF, F, D, DF, a+b
time = 32

[Command]
name = "Shadow Flying knee Max"
command = ~D, DF, F, D, DF, b+c
time = 32

[Command]
name = "Shadow Flying knee Max"
command = ~D, DF, F, D, DF, a+c
time = 32

;------------------------------

[Command]
name = "Shadow Wind Up Punch"
command = ~D, DB, B, D, DB, a
time = 32

[Command]
name = "Shadow Wind Up Punch"
command = ~D, DB, B, D, DB, ~a
time = 32

[Command]
name = "Shadow Wind Up Punch"
command = ~D, DB, B, D, DB, b
time = 32

[Command]
name = "Shadow Wind Up Punch"
command = ~D, DB, B, D, DB, ~b
time = 32

[Command]
name = "Shadow Wind Up Punch"
command = ~D, DB, B, D, DB, c
time = 32

[Command]
name = "Shadow Wind Up Punch"
command = ~D, DB, B, D, DB, ~c
time = 32

[Command]
name = "Shadow Wind Up Punch Max"
command = ~D, DB, B, D, DB, a+b
time = 32

[Command]
name = "Shadow Wind Up Punch Max"
command = ~D, DB, B, D, DB, b+c
time = 32

[Command]
name = "Shadow Wind Up Punch Max"
command = ~D, DB, B, D, DB, a+c
time = 32

;------------------------------

[Command]
name = "Shadow Tremor"
command = ~B, F, B, F, x
time = 32

[Command]
name = "Shadow Tremor"
command = ~B, F, B, F, ~x
time = 32

[Command]
name = "Shadow Tremor"
command = ~B, F, B, F, y
time = 32

[Command]
name = "Shadow Tremor"
command = ~B, F, B, F, ~y
time = 32

[Command]
name = "Shadow Tremor"
command = ~B, F, B, F, z
time = 32

[Command]
name = "Shadow Tremor"
command = ~B, F, B, F, ~z
time = 32

[Command]
name = "Shadow Tremor Max"
command = ~B, F, B, F, x+y
time = 32

[Command]
name = "Shadow Tremor Max"
command = ~B, F, B, F, y+z
time = 32

[Command]
name = "Shadow Tremor Max"
command = ~B, F, B, F, x+z
time = 32

;------------------------------

[Command]
name = "Ultra Combo"
command = ~B, F, B, F, a+b
time = 32

[Command]
name = "Ultra Combo"
command = ~B, F, B, F, b+c
time = 32

[Command]
name = "Ultra Combo"
command = ~B, F, B, F, a+c
time = 32

;-| Special Motions |------------------------------------------------------

[Command]
name = "Tumble"
command = ~$F, $B, x
time = 15

[Command]
name = "Tumble"
command = ~$F, $B, ~x
time = 15

[Command]
name = "Tumble"
command = ~$F, $B, y
time = 15

[Command]
name = "Tumble"
command = ~$F, $B, ~y
time = 15

[Command]
name = "Tumble"
command = ~$F, $B, z
time = 15

[Command]
name = "Tumble"
command = ~$F, $B, ~z
time = 15

[Command]
name = "Tumble EX"
command = ~$F, $B, x+y
time = 15

[Command]
name = "Tumble EX"
command = ~$F, $B, y+z
time = 15

[Command]
name = "Tumble EX"
command = ~$F, $B, x+z
time = 15

;-----------------------------

[Command]
name = "Power Line"
command = ~$B, $F, x
time = 15

[Command]
name = "Power Line"
command = $B, $F, ~x
time = 15

[Command]
name = "Power Line"
command = ~$B, $F, y
time = 15

[Command]
name = "Power Line"
command = ~$B, $F, ~y
time = 15

[Command]
name = "Power Line"
command = ~$B, $F, z
time = 15

[Command]
name = "Power Line"
command = ~$B, $F, ~z
time = 15

[Command]
name = "Power Line EX"
command = ~$B, $F, x+y
time = 15

[Command]
name = "Power Line EX"
command = ~$B, $F, y+z
time = 15

[Command]
name = "Power Line EX"
command = ~$B, $F, x+z
time = 15

;-----------------------------

[Command]
name = "Flying knee"
command = ~$B, $F, a
time = 16

[Command]
name = "Flying knee"
command = ~$B, $F, ~a
time = 16

[Command]
name = "Flying knee"
command = ~$B, $F, b
time = 16

[Command]
name = "Flying knee"
command = ~$B, $F, ~b
time = 16

[Command]
name = "Flying knee"
command = ~$B, $F, c
time = 16

[Command]
name = "Flying knee"
command = ~$B, $F, ~c
time = 16

[Command]
name = "Flying knee EX"
command = ~$B, $F, a+b
time = 16

[Command]
name = "Flying knee EX"
command = ~$B, $F, b+c
time = 16

[Command]
name = "Flying knee EX"
command = ~$B, $F, a+c
time = 16

;-----------------------------

[Command]
name = "Windup Punch"
command = ~$F, $B, a
time = 16

[Command]
name = "Windup Punch"
command = ~$F, $B, ~a
time = 16

[Command]
name = "Windup Punch"
command = ~$F, $B, b
time = 16

[Command]
name = "Windup Punch"
command = ~$F, $B, ~b
time = 16

[Command]
name = "Windup Punch"
command = ~$F, $B, c
time = 16

[Command]
name = "Windup Punch"
command = ~$F, $B, ~c
time = 16

[Command]
name = "Windup Punch EX"
command = ~$F, $B, a+b
time = 16

[Command]
name = "Windup Punch EX"
command = ~$F, $B, b+c
time = 16

[Command]
name = "Windup Punch EX"
command = ~$F, $B, a+c
time = 16

;-----------------------------

[Command]
name = "Tremor"
command = ~$D, $U, x
time = 15

[Command]
name = "Tremor"
command = ~$D, $U, ~x
time = 15

[Command]
name = "Tremor"
command = ~$D, $U, y
time = 15

[Command]
name = "Tremor"
command = ~$D, $U, ~y
time = 15

[Command]
name = "Tremor"
command = ~$D, $U, z
time = 15

[Command]
name = "Tremor"
command = ~$D, $U, ~z
time = 15

[Command]
name = "Tremor EX"
command = ~$D, $U, x+y
time = 15

[Command]
name = "Tremor EX"
command = ~$D, $U, y+z
time = 15

[Command]
name = "Tremor EX"
command = ~$D, $U, x+z
time = 15

;-----------------------------

[Command]
name = "Standing Forward Strong Punch"
command = /$F, z
time = 15

[Command]
name = "Standing Forward Strong Kick"
command = /$F, c
time = 15

;-----------------------------

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, z
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~z
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, b
time = 16

[Command]
name=  "412k" ;Zero Counter
command = ~B, DB, D, c
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~b
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~c
time = 16

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1

[Command]
name = "recovery"
command = y+z
time = 1

[Command]
name = "recovery"
command = x+z
time = 1

[Command]
name = "recovery"
command = a+x
time = 1

[Command]
name = "pp"
command = x+y
time = 1

[Command]
name = "pp"
command = x+z
time = 1

[Command]
name = "pp"
command = y+z
time = 1

[Command]
name = "kk"
command = a+b
time = 1

[Command]
name = "kk"
command = a+c
time = 1

[Command]
name = "kk"
command = b+c
time = 1

[Command]
name = "a+x"
command = a+x
time=1

[Command]
name = "b+y"
command = b+y
time = 1

[Command]
name = "c+z"
command = c+z
time = 1

;-| Dir + Button |---------------------------------------------------------
[Command]
name = "back_x"
command = /$B,x
time = 1

[Command]
name = "back_y"
command = /$B,y
time = 1

[Command]
name = "back_z"
command = /$B,z
time = 1

[Command]
name = "down_x"
command = /$D,x
time = 1

[Command]
name = "down_y"
command = /$D,y
time = 1

[Command]
name = "down_z"
command = /$D,z
time = 1

[Command]
name = "fwd_x"
command = /$F,x
time = 1

[Command]
name = "fwd_y"
command = /$F,y
time = 1

[Command]
name = "fwd_z"
command = /$F,z
time = 1

[Command]
name = "up_x"
command = /$U,x
time = 1

[Command]
name = "up_y"
command = /$U,y
time = 1

[Command]
name = "up_z"
command = /$U,z
time = 1

[Command]
name = "back_a"
command = /$B,a
time = 1

[Command]
name = "back_b"
command = /$B,b
time = 1

[Command]
name = "back_c"
command = /$B,c
time = 1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

[Command]
name = "down_c"
command = /$D,c
time = 1

[Command]
name = "fwd_a"
command = /$F,a
time = 1

[Command]
name = "fwd_b"
command = /$F,b
time = 1

[Command]
name = "fwd_c"
command = /$F,c
time = 1

[Command]
name = "up_a"
command = /$U,a
time = 1

[Command]
name = "up_b"
command = /$U,b
time = 1

[Command]
name = "up_c"
command = /$U,c
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1

;-| Single Dir |------------------------------------------------------------
[Command]
name = "fwd" ;Required (do not remove)
command = $F
time = 1

[Command]
name = "downfwd"
command = $DF
time = 1

[Command]
name = "down" ;Required (do not remove)
command = $D
time = 1

[Command]
name = "downback"
command = $DB
time = 1

[Command]
name = "back" ;Required (do not remove)
command = $B
time = 1

[Command]
name = "upback"
command = $UB
time = 1

[Command]
name = "up" ;Required (do not remove)
command = $U
time = 1

[Command]
name = "upfwd"
command = $UF
time = 1

;-| Hold Button |--------------------------------------------------------------
[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_s"
command = /s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holdfwd" ;Required (do not remove)
command = /$F
time = 1

[Command]
name = "holddownfwd"
command = /$DF
time = 1

[Command]
name = "holddown" ;Required (do not remove)
command = /$D
time = 1

[Command]
name = "holddownback"
command = /$DB
time = 1

[Command]
name = "holdback" ;Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdupback"
command = /$UB
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holdupfwd"
command = /$UF
time = 1

;---------------------------------------------------------------------------
;Release Direction
[Command]
name = "rlsfwd"
command = ~$F
time = 1

[Command]
name = "rlsback"
command = ~$B
time = 1

[Command]
name = "rlsup"
command = ~$U
time = 1

[Command]
name = "rlsdown"
command = ~$D
time = 1

;--------------------------------------------------------------------------
;Release Button
[Command]
name = "rlsx"
command = ~x
time = 1

[Command]
name = "rlsy"
command = ~y
time = 1

[Command]
name = "rlsz"
command = ~z
time = 1

[Command]
name = "rlsa"
command = ~a
time = 1

[Command]
name = "rlsb"
command = ~b
time = 1

[Command]
name = "rlsc"
command = ~c
time = 1
;---------------------------------------------------------------------------
;Other
[Command]
name = "highjump"
command = $D, $U
time = 15
;---------------------------------------------------------------------------
[Statedef -1]

[State -1, Tick Fix]
type = CtrlSet
triggerall = !ctrl
trigger1 = (StateNo = 52 || StateNo = 101 || StateNo = 5120) && !AnimTime
trigger2 = (StateNo = [200,499]) && !AnimTime
trigger3 = (StateNo = [760,762]) && !AnimTime
trigger4 = StateNo = 810 && !AnimTime
trigger5 = (StateNo = 5001 || StateNo = 5011 || StateNo = 151 || StateNo = 153) && HitOver
trigger6 = (StateNo = [700,715]) && !AnimTime
value = 1

[State -1, CtrlSet For Helpers];special thanks to 20S
type = CtrlSet
trigger1 = IsHelper
value = 0

[State -1, Hit Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(13) = 1

[State -1, Juggle Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(15) = 1

[State -1, ProjContact];special thanks to 20S
type = VarSet
trigger1 = IsHelper
trigger1 = MoveContact = 1 && NumTarget
var(18) = 1

[State -1, Root ProjContact];special thanks to 20S
type = ParentVarSet
trigger1 = IsHelper
trigger1 = MoveContact = 1 && NumTarget
var(18) = 1

[State -1, Ultra Combo]
type = ChangeState
value = 3200
triggerall = !AIlevel
triggerall = command = "Ultra Combo"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3  = stateno = 1000 && movecontact
trigger4  = stateno = 1001 && movecontact
trigger5  = stateno = 1002 && movecontact
trigger6  = stateno = 1003 && movecontact
trigger7  = stateno = 1010 && movecontact
trigger8  = stateno = 1011 && movecontact
trigger9  = stateno = 1012 && movecontact
trigger10 = stateno = 1013 && movecontact
trigger11 = stateno = 1020 && movecontact
trigger12 = stateno = 1021 && movecontact
trigger13 = stateno = 1022 && movecontact
trigger14 = stateno = 1023 && movecontact
trigger15 = stateno = 200 && movecontact
trigger16 = stateno = 210 && movecontact
trigger17 = stateno = 220 && movecontact
trigger18 = stateno = 230 && movecontact
trigger19 = stateno = 240 && movecontact
trigger20 = stateno = 250 && movecontact
trigger21 = stateno = 400 && movecontact
trigger22 = stateno = 410 && movecontact
trigger23 = stateno = 420 && movecontact
trigger24 = stateno = 430 && movecontact
trigger25 = stateno = 440 && movecontact
trigger26 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Shadow Tremor Max]
type = ChangeState
value = 3130
triggerall = !AIlevel
triggerall = command = "Shadow Tremor Max"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger21 = stateno = 3000 && movecontact
trigger22 = stateno = 3010 && movecontact
trigger23 = stateno = 3030 && movecontact
trigger24 = stateno = 3050 && movecontact
trigger25 = stateno = 3100 && movecontact
trigger26 = stateno = 3120 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Shadow Tremor]
type = ChangeState
value = 3120
triggerall = !AIlevel
triggerall = command = "Shadow Tremor"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Shadow Wind Up Punch Max]
type = ChangeState
value = 3110
triggerall = !AIlevel
triggerall = command = "Shadow Wind Up Punch Max"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger21 = stateno = 3000 && movecontact
trigger22 = stateno = 3010 && movecontact
trigger23 = stateno = 3030 && movecontact
trigger24 = stateno = 3050 && movecontact
trigger25 = stateno = 3100 && movecontact
trigger26 = stateno = 3120 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Shadow Wind Up Punch]
type = ChangeState
value = 3100
triggerall = !AIlevel
triggerall = command = "Shadow Wind Up Punch"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Shadow Power Line Max]
type = ChangeState
value = 3060
triggerall = !AIlevel
triggerall = command = "Shadow Power Line Max"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger21 = stateno = 3000 && movecontact
trigger22 = stateno = 3010 && movecontact
trigger23 = stateno = 3030 && movecontact
trigger24 = stateno = 3050 && movecontact
trigger25 = stateno = 3100 && movecontact
trigger26 = stateno = 3120 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Shadow Power Line]
type = ChangeState
value = 3050
triggerall = !AIlevel
triggerall = command = "Shadow Power Line"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

;-------------------------------------------------------
[State -1, Shadow Flying knee Max]
type = ChangeState
value = 3040
triggerall = !AIlevel
triggerall = command = "Shadow Flying knee Max"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger21 = stateno = 3000 && movecontact
trigger22 = stateno = 3010 && movecontact
trigger23 = stateno = 3030 && movecontact
trigger24 = stateno = 3100 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Shadow Flying knee]
type = ChangeState
value = 3030
triggerall = !AIlevel
triggerall = command = "Shadow Flying knee"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact
;-----------------------------------------------

[State -1, Shadow Tumble Max]
type = ChangeState
value = 3020
triggerall = !AIlevel
triggerall = command = "Shadow Tumble Max"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger21 = stateno = 3000 && movecontact
trigger22 = stateno = 3010 && movecontact
trigger23 = stateno = 3030 && movecontact
trigger24 = stateno = 3050 && movecontact
trigger25 = stateno = 3100 && movecontact
trigger26 = stateno = 3120 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Shadow Tumble]
type = ChangeState
value = 3000
triggerall = !AIlevel
triggerall = command = "Shadow Tumble"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = stateno = 1000 && movecontact
trigger4 = stateno = 1003 && movecontact
trigger5 = stateno = 1010 && movecontact
trigger6 = stateno = 1013 && movecontact
trigger7 = stateno = 1030 && movecontact
trigger8 = stateno = 1033 && movecontact
trigger9  = stateno = 200 && movecontact
trigger10 = stateno = 210 && movecontact
trigger11 = stateno = 220 && movecontact
trigger12 = stateno = 230 && movecontact
trigger13 = stateno = 240 && movecontact
trigger14 = stateno = 250 && movecontact
trigger15 = stateno = 400 && movecontact
trigger16 = stateno = 410 && movecontact
trigger17 = stateno = 420 && movecontact
trigger18 = stateno = 430 && movecontact
trigger19 = stateno = 440 && movecontact
trigger20 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Tremor EX]
type = ChangeState
value = 1043
triggerall = !AIlevel
triggerall = command = "Tremor EX"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger15 = stateno = 1000 && movecontact
trigger16 = stateno = 1010 && movecontact
trigger17 = stateno = 1030 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Windup Punch EX]
type = ChangeState
value = 1033
triggerall = !AIlevel
triggerall = command = "Windup Punch EX"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger15 = stateno = 1000 && movecontact
trigger16 = stateno = 1010 && movecontact
trigger17 = stateno = 1030 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Flying knee EX]
type = ChangeState
value = 1023
triggerall = !AIlevel
triggerall = command = "Flying knee EX"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger15 = stateno = 1000 && movecontact
trigger16 = stateno = 1010 && movecontact
trigger17 = stateno = 1030 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Power Line EX]
type = ChangeState
value = 1013
triggerall = !AIlevel
triggerall = command = "Power Line EX"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger15 = stateno = 1000 && movecontact
trigger16 = stateno = 1010 && movecontact
trigger17 = stateno = 1030 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Tumble EX]
type = ChangeState
value = 1003
triggerall = !AIlevel
triggerall = command = "Tumble EX"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger15 = stateno = 1000 && movecontact
trigger16 = stateno = 1010 && movecontact
trigger17 = stateno = 1030 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Tremor]
type = ChangeState
value = 1040
triggerall = !AIlevel
triggerall = command = "Tremor"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Windup Punch]
type = ChangeState
value = 1030
triggerall = !AIlevel
triggerall = command = "Windup Punch"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Flying knee]
type = ChangeState
value = 1020
triggerall = !AIlevel
triggerall = command = "Flying knee"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Power Line]
type = ChangeState
value = 1010
triggerall = !AIlevel
triggerall = command = "Power Line"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Tumble]
type = ChangeState
value = 1000
triggerall = !AIlevel
triggerall = command = "Tumble"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 200 && movecontact
trigger4 = stateno = 210 && movecontact
trigger5 = stateno = 220 && movecontact
trigger6 = stateno = 230 && movecontact
trigger7 = stateno = 240 && movecontact
trigger8 = stateno = 250 && movecontact
trigger9 = stateno = 400 && movecontact
trigger10 = stateno = 410 && movecontact
trigger11 = stateno = 420 && movecontact
trigger12 = stateno = 430 && movecontact
trigger13 = stateno = 440 && movecontact
trigger14 = stateno = 450 && movecontact
trigger27 = stateno = 225 && movecontact
trigger28 = stateno = 255 && movecontact

[State -1, Standing Forward Strong Punch]
type = ChangeState
value = 225
triggerall = !AIlevel
triggerall = command = "Standing Forward Strong Punch"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 220 && movecontact

[State -1, Standing Forward Strong Kick]
type = ChangeState
value = 255
triggerall = !AIlevel
triggerall = command = "Standing Forward Strong Kick"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 250 && movecontact

[State -1, Zero Counter]
type = ChangeState
value = 750
triggerall = !AIlevel
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = command = "412p" || command = "412k"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1, Throw Forward]
type = ChangeState
value = 800
triggerall = !AIlevel
trigger1 = (command = "holdfwd" || command = "holdback") && command = "pp" 
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl

[State -1, Throw Back]
type = ChangeState
value = 900
triggerall = !AIlevel
trigger1 = (command = "holdfwd" || command = "holdback") && command = "kk" 
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl

[State -1, Roll Forward]
type = ChangeState
value = 710
triggerall = !AIlevel
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdfwd"

[State -1, Roll Back]
type = ChangeState
value = 715
triggerall = !AIlevel
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdback"

[State -1, Power Charge]
type = ChangeState
value = 730
triggerall = !AIlevel
trigger1 = command = "hold_b" && command = "hold_y"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (StateNo = [100,101])

[State -1, MAX Mode]
type = ChangeState
value = 770
triggerall = !AIlevel
triggerall = command = "c+z"
triggerall = RoundState = 2 && StateType != A
triggerall = var(20) <= 0 && Power >= 1000
trigger1 = ctrl || (Stateno = [100,101])

[State -1, Dodge]
type = ChangeState
value = 700
triggerall = !AIlevel
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))

[State -1, Run Fwd]
type = ChangeState
value = 110
triggerall = !AIlevel
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

[State -1, Run Back]
type = ChangeState
value = 105
triggerall = !AIlevel
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;--------------------------------------------------------------------------
[State -1, Stand Light Punch]
type = ChangeState
value = 200
triggerall = !AIlevel
triggerall = command = "x"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2= (StateNo = 200 || StateNo = 400 || StateNo = 430) && Time >=5

[State -1, Stand Medium Punch]
type = ChangeState
value = 210 
triggerall = !AIlevel
triggerall = command = "y"
triggerall = command != "holddown"  
triggerall = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 200 && movecontact

[State -1, Stand Strong Punch]
type = ChangeState
value = 220 
triggerall = !AIlevel
triggerall = command = "z"
triggerall = command != "holddown" 
triggerall = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 210 && movecontact

[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerall = !AIlevel
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2 = stateno = 200 && movecontact

[State -1, Stand Medium Kick]
type = ChangeState
value = 240
triggerall = !AIlevel
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2 = stateno = 230 && movecontact

[State -1, Standing Strong Kick]
type = ChangeState
value = 250
triggerall = !AIlevel
triggerall = command = "c"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2 = stateno = 240 && movecontact

[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "x"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2= (StateNo = 200 || StateNo = 400 || StateNo = 430) && Time >=5

[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "y"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 400 && movecontact

[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "z"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 410 && movecontact

[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "a"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 400 && movecontact

[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "b"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 430 && movecontact

[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerall = !AIlevel
triggerAll = command = "holddown" && command = "c"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = stateno = 440 && movecontact

[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = !AIlevel
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Medium Punch]
type = ChangeState
value = 610
triggerall = !AIlevel
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Punch]
type = ChangeState
value = 620
triggerall = !AIlevel
triggerall = command = "z"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerall = !AIlevel
triggerall = command = "a"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Medium Kick]
type = ChangeState
value = 640
triggerall = !AIlevel
triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerall = !AIlevel
triggerall = command = "c"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !AIlevel
triggerall = command = "s"
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = var(5)

;=====================================
;=================AI==================
;=====================================

[State -1, Ultra Combo]
type = ChangeState
value = 3200
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 3000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 3 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (EnemyNear, MoveType != A) || (EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-46,46]) && (P2Dist y = [-69,0])
triggerAll = (EnemyNear, vel x = [-5,5]) && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && (EnemyNear, HitFall)
trigger2 = Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 3

[State -1, Shadow Tremor Max]
type = ChangeState
value = 3130
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 2000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-140,140]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Tremor]
type = ChangeState
value = 3120
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 1000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-100,100]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != A
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Wind Up Punch Max]
type = ChangeState
value = 3110
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 2000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-140,140]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Wind Up Punch]
type = ChangeState
value = 3100
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 1000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-100,100]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != A
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Power Line Max]
type = ChangeState
value = 3060
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 2000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-140,140]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Power Line]
type = ChangeState
value = 3050
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 1000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-100,100]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != A
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Flying knee Max]
type = ChangeState
value = 3040
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 2000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-140,140]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Flying knee]
type = ChangeState
value = 3030
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 1000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-100,100]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != A
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Tumble Max]
type = ChangeState
value = 3020
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 2000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-140,140]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Shadow Tumble]
type = ChangeState
value = 3000
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = Power >= 1000 && var(20) <= 60
triggerAll = !var(16) && (var(15) < 1 || var(20) || (StateNo = [1000,4999]))
triggerAll = !(EnemyNear, ctrl) && ((EnemyNear, StateNo != [120,155]) || EnemyNear, StateType = A)
triggerAll = (P2BodyDist x = [-100,100]) && (P2Dist y = [-32,32])
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != A
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(7) && MoveHit && Random < (ifElse((var(20) = [1,30]), 200, 50) * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 4

[State -1, Tremor]
type = ChangeState
value = ifElse(Power >= 500 && Random < 100, 1043, 1040)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(39)
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = P2BodyDist x >= 25 && P2Dist y >= -120 && EnemyNear, vel y >= 0
triggerAll = P2StateType != A || EnemyNear, vel x < 0
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (ctrl || StateNo = 52 || (StateNo = [100,101]))
trigger2 = EnemyNear, StateNo = 195 && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Windup Punch]
type = ChangeState
value = ifElse(Power >= 500 && Random < 133, 1033, 1030)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = P2StateType != L && (P2Dist y = [-80,32])
triggerAll = ((P2BodyDist x = [-70,70]) && P2StateType != A) || ((P2BodyDist x = [-80,80]) && P2StateType = A)
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = var(6) && MoveHit && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 3
trigger3 = (StateNo = 5120 || StateNo = 5201) && !AnimTime && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Flying Knee]
type = ChangeState
value = ifElse(Power >= 500 && Random < 133, 1023, 1020)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = P2StateType != L && (P2Dist y = [-80,32])
triggerAll = ((P2BodyDist x = [-70,70]) && P2StateType != A) || ((P2BodyDist x = [-80,80]) && P2StateType = A)
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = var(6) && MoveHit && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = EnemyNear, GetHitVar(HitTime) >= 3
trigger3 = (StateNo = 5120 || StateNo = 5201) && !AnimTime && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Power Line]
type = ChangeState
value = ifElse(Power >= 500 && Random < 100 && var(20) <= 60, 1013, 1010)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(39)
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = P2BodyDist x >= 25 && P2Dist y >= -120 && EnemyNear, vel y >= 0
triggerAll = P2StateType != A || EnemyNear, vel x < 0
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (ctrl || StateNo = 52 || (StateNo = [100,101]))
trigger2 = EnemyNear, StateNo = 195 && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Tumble]
type = ChangeState
value = ifElse(Power >= 500 && Random < 100, 1003, 1000)
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(39)
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = P2BodyDist x >= 25 && P2Dist y >= -120 && EnemyNear, vel y >= 0
triggerAll = P2StateType != A || EnemyNear, vel x < 0
trigger1 = (ctrl || StateNo = 52 || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (ctrl || StateNo = 52 || (StateNo = [100,101]))
trigger2 = EnemyNear, StateNo = 195 && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Zero Counter]
type = ChangeState
value = 750
trigger1 = AILevel && NumEnemy
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power >= 1000 && var(20) <= 60
trigger1 = Random < (25 * (AILevel ** 2 / 64.0))
trigger1 = (P2BodyDist x = [0,50]) && (Life < 0.5 * LifeMax)

[State -1, Throw]
type = ChangeState
value = 900
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = S
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [-20,40]) && P2BodyDist y = 0
trigger1 = ctrl && Random < (125 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl && (P2StateNo = [120,140]) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Throw]
type = ChangeState
value = 800
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = S
triggerAll = P2StateType != A && P2StateType != L && P2MoveType != H
triggerAll = (P2BodyDist x = [-20,40]) && P2BodyDist y = 0
trigger1 = ctrl && Random < (125 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl && (P2StateNo = [120,140]) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Roll Forward]
type = ChangeState
value = 710
triggerall = AIlevel && numenemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Random < (50 * (AILevel ** 2 / 64.0))
trigger1 = (ctrl || (StateNo = [100,101])) && var(20) <= 164 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && !(EnemyNear, HitDefAttr = SCA, AT) && (P2BodyDist x = [92,122])

[State -1, Roll Back]
type = ChangeState
value = 715
triggerall = AIlevel && numenemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Random < (50 * (AILevel ** 2 / 64.0))
trigger1 = (ctrl || (StateNo = [100,101])) && var(20) <= 164 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && !(EnemyNear, HitDefAttr = SCA, AT) && (P2BodyDist x = [92,122])

[State -1, Power Charge]
type = ChangeState
value = 730
triggerall = AIlevel && numenemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Power < const(data.power) && !var(20)
trigger1 = ctrl && Power < const(data.power) && Power < PowerMax && !var(20)
trigger1 = !InGuardDist && P2BodyDist x >= 160 && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Dodge]
type = ChangeState
value = 700
triggerall = AIlevel && numenemy
trigger1 = RoundState = 2 && StateType != A
trigger1 = Random < (50 * (AIlevel ** 2 / 64.0))
trigger1 = (ctrl || (StateNo = [100,101])) && var(20) <= 164 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && !(EnemyNear, HitDefAttr = SCA, AT) && (P2BodyDist x = [0,60])

[State -1, Run Fwd]
type = ChangeState
value = 110
triggerall = AIlevel && numenemy
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl && (StateNo != [100,106])
trigger1 = (EnemyNear, MoveType != A) && P2BodyDist x >= 160 && Random < (25 * (AILevel ** 2 / 64.0))

[State -1, Hop Backward]
type = ChangeState
value = 105
triggerall = AIlevel && numenemy
triggerAll = RoundState = 2 && StateType = S
triggerAll = ctrl && (StateNo != [100,106]) && var(20) <= 150 && !var(26)
trigger1 = (EnemyNear, MoveType = A) && BackEdgeDist >= 80 && (P2BodyDist x = [80,120]) && (EnemyNear, vel x)
trigger1 = Random < (ifElse((EnemyNear, HitDefAttr = SC, AT), 150, 50) * (AILevel ** 2 / 64.0))
trigger2 = (P2BodyDist x = [0,80]) && BackEdgeBodyDist >= 80
trigger2 = EnemyNear, StateNo = 5120 && EnemyNear, AnimTime = -4 && Random < (750 * (AILevel ** 2 / 64.0))

[State -1, Stand Light Punch]
type = ChangeState
value = 200
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,63]) && (P2Dist y = [-87,0]) && P2StateType != C && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Stand Medium Punch]
type = ChangeState
value = 210
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,80]) && (P2Dist y = [-129,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))
trigger3 = var(24)

[State -1, Stand Strong Punch]
type = ChangeState
value = 220
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,101]) && (P2Dist y = [-111,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Stand Forward Strong Punch]
type = ChangeState
value = 225
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,101]) && (P2Dist y = [-111,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,72]) && (P2Dist y = [-23,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 2) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Stand Medium Kick]
type = ChangeState
value = 240
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,60]) && (P2Dist y = [-115,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Standing Strong Kick]
type = ChangeState
value = 250
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,146]) && (P2Dist y = [-111,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 4) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Standing Forward Strong Kick]
type = ChangeState
value = 255
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,146]) && (P2Dist y = [-111,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 4) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,61]) && (P2Dist y = [-54,0]) && P2StateType != A && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 2) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,70]) && (P2Dist y = [-52,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && Statetype != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,50]) && (P2Dist y = [-132,0]) && P2StateType != L
triggerAll = (EnemyNear, const(size.head.pos.y) <= -40) || (EnemyNear, StateType = A)
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 4) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,90]) && (P2Dist y = [-27,0]) && P2StateType != A && P2StateType != L
trigger1 = (ctrl || (StateNo = [100, 101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200, 499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,111]) && (P2Dist y = [-33,0]) && P2StateType != A && P2StateType != L
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 3) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType != A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,97]) && (P2Dist y = [-33,0]) && P2StateType != A && P2StateType != L
triggerAll = (P2StateType = S || (P2StateType = C && P2MoveType = H))
trigger1 = (ctrl || (StateNo = [100,101])) && Random < (25 * (AILevel ** 2 / 64.0))
trigger2 = (StateNo = [200,499]) && !AnimTime && ctrl
trigger2 = MoveHit && (EnemyNear, GetHitVar(HitTime) >= 6) && Random < (250 * (AILevel ** 2 / 64.0))

[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,41]) && (P2Dist y = [-56,28]) && P2StateType = S
trigger1 = ctrl
trigger1 = vel y > 0 && Random < (100 * (AIlevel ** 2 / 64.0))

[State -1, Jump Medium Punch]
type = ChangeState
value = 610
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,42]) && (P2Dist y = [-80,50]) && P2StateType = S
trigger1 = ctrl
trigger1 = vel y > 0 && Random < (100 * (AILevel ** 2 / 64.0))

[State -1, Jump Strong Punch]
type = ChangeState
value = 620
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,45]) && (P2Dist y = [-64,50]) && P2StateType = S
trigger1 = ctrl
trigger1 = vel y > 0 && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(4) && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,32]) && (P2Dist y = [-117,40]) && P2StateType != L
trigger1 = ctrl
trigger1 = vel y > 0 && Random < (ifElse(P2Dist x < 0, 250, 50) * (AILevel ** 2 / 64.0))

[State -1, Jump Medium Kick]
type = ChangeState
value = 640
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,79]) && (P2Dist y = [-60,40]) && P2StateType = A
trigger1 = ctrl
trigger1 = vel y <= 0 && Random < (100 * (AILevel ** 2 / 64.0))

[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerAll = AILevel && NumEnemy
triggerAll = RoundState = 2 && StateType = A
triggerAll = !var(16) && (var(15) < 1 || var(20))
triggerAll = (P2BodyDist x = [0,92]) && (P2Dist y = [-116,50]) && P2StateType = S
trigger1 = ctrl && Random < (100 * (AILevel ** 2 / 64.0))
trigger2 = var(4) && Random < (50 * (AILevel ** 2 / 64.0))

[State -1, Guard]
type = ChangeState
value = 120
trigger1 = AILevel && NumEnemy
trigger1 = RoundState = 2 && InGuardDist
trigger1 = ctrl && (StateNo != [120, 155]) && !var(20)
trigger1 = !var(26) || P2BodyDist x >= 40
trigger1 = !(EnemyNear, HitDefAttr = SCA, AT) && (EnemyNear, Time < 120)
trigger1 = StateType != A || P2StateType = A
trigger1 = ifElse(StateType = A, ((var(3) != [1, 2]) || StateNo = 5210), 1)
trigger1 = Random < (ifElse((P2StateNo = [200, 699]), 100, ifElse((P2StateNo = [1000,2999]), 333, 1000)) * (AILevel ** 2 / 64.0))

[State -1, Taunt]
type = ChangeState
value = 195
triggerall = AIlevel && numenemy
triggerall = roundstate = 2 && statetype != A
trigger1 = p2dist x > 160 && (enemynear, vel y > 0) && ctrl && random < (100 * (AIlevel ** 2 / 64.0))
trigger1 = !(enemynear, ctrl) && (enemynear, movetype = H)