



[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s

[Defaults]
command.time=15
command.buffer.time=1



[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1



[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_s"
command = /s
time = 1



[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1



[Command]
name = "fwd"
command = $F
time = 1

[Command]
name = "down"
command = $D
time = 1

[Command]
name = "back"
command = $B
time = 1

[Command]
name = "up"
command = $U
time = 1



[Command]
name="NE_fwd"
command=~$F
time=1
[Command]
name="NE_back"
command=~$B
time=1
[Command]
name="NE_up"
command=~$U
time=1
[Command]
name="NE_down"
command=~$D
time=1

[Command]
name="NE_x"
command=~x
time=1
[Command]
name="NE_y"
command=~y
time=1
[Command]
name="NE_z"
command=~z
time=1
[Command]
name="NE_a"
command=~a
time=1
[Command]
name="NE_b"
command=~b
time=1
[Command]
name="NE_c"
command=~c
time=1



[Command]
name="Plants'_Commandment"
command=~D,DF,F,D,DF,x
time=30
[Command]
name="Plants'_Commandment"
command=~D,DF,F,D,DF,~x
time=30
[Command]
name="Plants'_Commandment"
command=~D,DF,F,D,DF,y
time=30
[Command]
name="Plants'_Commandment"
command=~D,DF,F,D,DF,~y
time=30
[Command]
name="Plants'_Commandment"
command=~D,DF,F,D,DF,z
time=30
[Command]
name="Plants'_Commandment"
command=~D,DF,F,D,DF,~z
time=30

[Command]
name="Natural_Disaster"
command=~D,DF,F,D,DF,a
time=30
[Command]
name="Natural_Disaster"
command=~D,DF,F,D,DF,~a
time=30
[Command]
name="Natural_Disaster"
command=~D,DF,F,D,DF,b
time=30
[Command]
name="Natural_Disaster"
command=~D,DF,F,D,DF,~b
time=30
[Command]
name="Natural_Disaster"
command=~D,DF,F,D,DF,c
time=30
[Command]
name="Natural_Disaster"
command=~D,DF,F,D,DF,~c
time=30

[Command]
name="Blessing_of_The_Sun"
command=~D,DB,B,D,DB,a
time=30
[Command]
name="Blessing_of_The_Sun"
command=~D,DB,B,D,DB,~a
time=30
[Command]
name="Blessing_of_The_Sun"
command=~D,DB,B,D,DB,b
time=30
[Command]
name="Blessing_of_The_Sun"
command=~D,DB,B,D,DB,~b
time=30
[Command]
name="Blessing_of_The_Sun"
command=~D,DB,B,D,DB,c
time=30
[Command]
name="Blessing_of_The_Sun"
command=~D,DB,B,D,DB,~c
time=30



[command]
name="Shouting_of_The_Wind"
command=~D,DF,F,x
time=15
[command]
name="Shouting_of_The_Wind"
command=~D,DF,F,~x
time=15
[command]
name="Shouting_of_The_Wind"
command=~D,DF,F,y
time=15
[command]
name="Shouting_of_The_Wind"
command=~D,DF,F,~y
time=15
[command]
name="Shouting_of_The_Wind"
command=~D,DF,F,z
time=15
[command]
name="Shouting_of_The_Wind"
command=~D,DF,F,~z
time=15

[Command]
name="Child_of_The_Earth"
command=~D,DF,F,a
time=15
[Command]
name="Child_of_The_Earth"
command=~D,DF,F,~a
time=15
[Command]
name="Child_of_The_Earth"
command=~D,DF,F,b
time=15
[Command]
name="Child_of_The_Earth"
command=~D,DF,F,~b
time=15
[Command]
name="Child_of_The_Earth"
command=~D,DF,F,c
time=15
[Command]
name="Child_of_The_Earth"
command=~D,DF,F,~c
time=15

[Command]
name="Delight_of_Green"
command=~D,DB,B,x
time=15
[Command]
name="Delight_of_Green"
command=~D,DB,B,~x
time=15
[Command]
name="Delight_of_Green"
command=~D,DB,B,y
time=15
[Command]
name="Delight_of_Green"
command=~D,DB,B,~y
time=15
[Command]
name="Delight_of_Green"
command=~D,DB,B,z
time=15
[Command]
name="Delight_of_Green"
command=~D,DB,B,~z
time=15

[Command]
name="Child_of_The_Earth-2"
command=~D,DB,B,a
time=15
[Command]
name="Child_of_The_Earth-2"
command=~D,DB,B,~a
time=15
[Command]
name="Child_of_The_Earth-2"
command=~D,DB,B,b
time=15
[Command]
name="Child_of_The_Earth-2"
command=~D,DB,B,~b
time=15
[Command]
name="Child_of_The_Earth-2"
command=~D,DB,B,c
time=15
[Command]
name="Child_of_The_Earth-2"
command=~D,DB,B,~c
time=15



[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10



[Command]
name = "recovery"
command = x+a
time = 1

[Command]
name = "s"
command = s
time = 1

[command]
name = "GuardCounter"
command = b+y
time = 1

[Command]
name="HighJmp"
command=$D,$U
time=15




;   --- Uno Tag System [Type-R] Command definition ---

[Command]
name = "aHsoNn"
command = ~D, D, D, z+c
Time = 25

[Command]
name = "sheoun"
command = ~D, DF, F, z+c
Time = 25

[Command]
name = "palit"
command = z+c
Time = 2

[Command]
name = "turtleuno"
command = s
Time = 2


[Statedef -1]


[State -1, Partner Assist]
type = VarSet
sysvar(4) = 10
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 60 && Time > 0
triggerall = teammode = Simul
triggerall = StateNo != [3000,1251199]
triggerall = hitdefattr != SCA, HA, HP, HT
triggerAll = StateNo != [130,152]
triggerall = !(StateNo = [5000,5500])
triggerall = Power >= 500
trigger1 = command = "turtleuno"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = !ctrl && Movetype = A
trigger2 = Random < (((2 * ifelse(MoveContact, ifelse(MoveHit, 2, 3),1)) + (UniqHitCount * 2)) *(AILevel**2/64.0))
trigger3 = AILevel >  0
trigger3 = StateNo = [190,199]
trigger3 = AnimElemNo(0) = 2
ignorehitpause = 1

[State -1, Team Hyper Attack]
type = ChangeState
value = 1251125
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = Partner, life > 0
triggerall = power >= 3000
triggerall = RoundState = 2
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 9		
triggerall= (StateType != A)
trigger1 = command = "sheoun"
trigger1 = (Ctrl = 1)
trigger1 = AILevel <=  0
trigger2 = command = "sheoun"
trigger2 = Anim = [200,1000]
trigger2 = movetype = A
trigger2 = hitdefattr = SC, NA
trigger2 = MoveContact
trigger2 = AILevel <=  0
trigger3 = AILevel > 0 && ctrl
trigger3 = Random < (10 + ((Life < Lifemax/6)*3))
trigger3 = NumEnemy && enemy, pos x = [0,200]
trigger4 = AILevel >  0
trigger4 = Anim = [200,1000]
trigger4 = movetype = A
trigger4 = hitdefattr = SC, NA
trigger4 = MoveContact
trigger4 = Random < (11 + ((MoveHit)*5) + ((Life < Lifemax/6)*5))
ignorehitpause = 1

[State -1, Delayed Hyper]
type = ChangeState
value = 1251127
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0
triggerall = power >= 1000
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time > 1 && Time > 45
triggerall = movetype = A
triggerall = StateNo = [2000,1251100]
triggerall = hitdefattr = SCA, HA, HP, HT || (StateNo >= 2000 && StateNo < 4000 && (hitcount < 8 || NumTarget && Target, GetHitVar(hitTime) >= 0))
trigger1 = command = "sheoun"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = NumTarget && MoveContact
trigger2 = Random < (10*(AILevel**2/64.0) + (Uniqhitcount*((Life < Partner,Life)*2)))
trigger2 = Partner, Time > 35
trigger3 = AILevel >  0
trigger3 = Partner, Time > 30 && Time > 25
trigger3 = HitCount >= 6
trigger3 = Random < (2 * Uniqhitcount * ifelse(hitcount > 9, 2, 1))
ignorehitpause = 1

[State -1, UNO Mode]
type = ChangeState
value = 1251128
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner
triggerall = RoundState = 2
triggerall = Partner, life > 0 && Power >= 1000
triggerall = Life <= (Lifemax/8)
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 20
triggerall = (StateType != A) && ((Ctrl = 1) || StateNo = 0 || (Movetype = A && hitdefattr = SC, NA))
trigger1 = command = "aHsoNn"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Partner, Life < Lifemax/4
trigger2 = Random < ((25 + ifelse((Partner, Life < Lifemax/6), 25, 5))*(AILevel**2/64.0))

[State -1, Change Attack]
type = ChangeState
value = 1251126
triggerall = NumPartner
triggerall = (sysvar(4) = 1 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),250,500)) || (sysvar(4) = 15 && power >= ifelse(((ID < Partner,ID && PowerMax <= 1000) || (ID > Partner,ID && Partner, PowerMax <= 1000)),500,1000))
triggerall = Partner, life > 0
triggerall = movetype = A && !MoveReversed
triggerall = (Partner, StateNo = 1251112 || Partner, StateNo = 1251114)  && Time > 1
triggerall = StateNo = [200,4850]
triggerall = StateNo != [1251102,1251105]
triggerall = NumTarget > 0 && Target, pos Y > -160
triggerall = (Target, StateNo != [5110,5955])
triggerall = Hitdefattr != SCA, NT && ((Target, Statetype = A || (Hitdefattr != A, NA && Target, Statetype != A)) && ((!Target, HitOver || EnemyNear, StateNo = [5000,5900]) && (MoveContact || ProjContactTime(0) < 8)))
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = UniqHitCount >= 2
trigger2 = Random < (((ifelse(sysvar(4)=15,25,50)*(AILevel**2/64.0)) + ((hitdefattr = SCA, SA, HA)*15) + ifelse(lifemax/life > 15, 15, lifemax/life)))
trigger2 = Partner, Life > Lifemax/10 || Life <= Partner, Life
trigger2 = Partner, Time > 25
trigger3 = AILevel >  0
trigger3 = Partner, Time > 27
trigger3 = Random < (25*(2*(Life = (Lifemax/4) && Life < Partner, Life)) *(AILevel**2/64.0))
trigger3 = MoveContact
ignorehitpause = 1

[State -1, TagIn]
type = ChangeState
value = 1251110
triggerall = sysvar(4) = 1 || sysvar(4) = 15
triggerall = NumPartner && NumEnemy
triggerall = RoundState = 2 
triggerall = Partner, life > 0
triggerall = Partner, StateNo = [1251112,1251114]
triggerall = Partner, Time >= 40	
triggerall = (MoveType != A && StateType != A) && (Ctrl = 1) || StateNo = 0
trigger1 = command = "palit"
trigger1 = AILevel <=  0
trigger2 = AILevel >  0
trigger2 = Random < (ifelse((LifeMax/Life > 120), 120, LifeMax/Life)+((EnemyNear,statetype=L)*25))
trigger2 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond
trigger2 = EnemyNear, movetype != A
trigger3 = AILevel >  0
trigger3 = Life < Partner, Life && Partner, Time > 1 * TicksPerSecond && Life < LifeMax * (LifeMax*0.55)
trigger3 = Random < ((ifelse(LifeMax/Life > 10, 10, LifeMax/Life) + (10+ifelse((EnemyNear, StateNo > 5000),25,1))) * ifelse((Life < Partner, Life), 1.45, 0.5))
trigger3 = Partner, Time > 1 * TicksPerSecond
trigger3= EnemyNear, statetype = L || p2bodydist x > 250 && EnemyNear, movetype != A
trigger4 = AILevel >  0
trigger4 = Life < 150 && Life < Partner, Life
trigger4 = EnemyNear, statetype = L || p2bodydist x > 200 && EnemyNear, movetype != A
trigger4 = Random < (125*(AILevel**2/64.0))

[State -1, C_6]
type = CtrlSet
value = 1
triggerall = RoundState = 2 && NumPartner
triggerall = NumTarget && Target, StateNo != [200,4999]
triggerall = StateNo != 1251106 && !Ctrl
triggerall = (Partner, StateNo != [1251128,1251129]) && (Partner, PrevStateNo != [1251128,1251129])
trigger1 = command="x"||command="y"||command="z"||command="a"||command="b"||command="c"
trigger1 = sysvar(4) = 7
trigger1 = Movetype = A
trigger1 = MoveContact
trigger1 = hitdefattr = SCA, NA, SA
trigger1 = StateNo != PrevStateNo
trigger1 = Time > 3
trigger2 = PrevStateNo = 1251106
ignorehitpause = 0

; ------ Uno Tag System [Type-R] END LINE -------

;  ;]





[state 0]
type=selfstate
trigger1=ctrl && numpartner && !ishelper && roundstate=2 && pos y=0
trigger1=sysfvar(4)>0 && sysfvar(0)>0 && playeridexist(floor(sysfvar(0)))
trigger1=playerid(floor(sysfvar(0))),var(0)=90900 && playerid(floor(sysfvar(0))),var(22)=4
value=190190
ctrl=0
ignorehitpause=1











[State -1,Blessing_of_The_Sun]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=3200
triggerall=!ailevel
triggerall=power>=3000&&!var(25)
triggerall=command="Blessing_of_The_Sun"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101||stateno=40||stateno=52


[State -1,Natural_Disaster]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=3100
triggerall=!ailevel
triggerall=power>=1000&&!var(25)||var(25)&&var(26)>=500
triggerall=command="Natural_Disaster"
triggerall=statetype!=A
triggerall=!numhelper(8020)
trigger1=ctrl||stateno=100||stateno=101||stateno=40||stateno=52


[State -1,Plants'_Commandment]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=3000
triggerall=!ailevel
triggerall=power>=1000&&!var(25)||var(25)&&var(26)>=500
triggerall=command="Plants'_Commandment"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101||stateno=40||stateno=52
trigger2=var(4)=1||var(4)=2||var(5)=1||var(5)=2
trigger3=var(4)=4||var(5)=4




[state -1,Child_of_The_Earth]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1500
triggerall=!ailevel
triggerall=command="Child_of_The_Earth"||command="Child_of_The_Earth-2"
triggerall=statetype!=A
triggerall=numhelper(8040)<2
trigger1=ctrl||stateno=100||stateno=101||stateno=40||stateno=52
trigger2=var(7)

[state -1,Delight_of_Green]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1400+(2700*(var(25)&&(command="z"||command="NE_z")))
triggerall=!ailevel
triggerall=command="Delight_of_Green"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101||stateno=40||stateno=52
trigger2=var(7)

[state -1,Shouting_of_The_Wind]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1300+(2700*(var(25)&&(command="z"||command="NE_z")))
triggerall=!ailevel
triggerall=command="Shouting_of_The_Wind"

trigger1=ctrl||stateno=100||stateno=101||stateno=40||stateno=52
trigger2=var(2)=1||var(2)=2||var(3)=1||var(3)=2
trigger3=var(2)=4||var(3)=4
trigger4=var(7)



[State -1,Power_charge]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=6000
triggerall=!ailevel
triggerall=!var(25)
triggerall=command="b"&&command="y"
triggerall=(power<powermax&&power<const(data.power))
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101

[State -1,Vigor_Mode]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=7000
triggerall=!ailevel
triggerall=power>=1000||var(25)
triggerall=command="z"&&command="c"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101



[state -1,Guard_Counter]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1100
triggerall=!ailevel
triggerall=!var(25)
triggerall=statetype!=A
triggerall=power>=1000
triggerall=command="GuardCounter"&&command!="holddown"&&command="holdfwd"
trigger1=stateno=150||stateno=152

[state -1,Dodge]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1200
triggerall=!ailevel
triggerall=statetype!=A
triggerall=command="a"&&Command="x"&&command!="holdfwd"&&command!="holdback"
trigger1=ctrl||stateno=100||stateno=101

[state -1,FwdRoll]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1205
triggerall=!ailevel
triggerall=statetype!=A
triggerall=command="a"&&Command="x"&&command="holdfwd"
trigger1=ctrl||stateno=100||stateno=101

[state -1,BackRoll]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1210
triggerall=!ailevel
triggerall=statetype!= A
triggerall=command="a"&&Command="x"&&command="holdback"
trigger1=ctrl||stateno=100||stateno=101

[state -1,Parry_Stand]
type=hitoverride
triggerall=!ailevel
triggerall=statetype=S&&command="fwd"&&command!="back"&&command!="up"&&command!="down"
trigger1=ctrl
attr=SA,AA,AP
stateno=6100
slot=0
time=2+(2*(var(25)))

[state -1,Parry_Crouch]
type=hitoverride
triggerall=!ailevel
triggerall=(statetype=S&&command="down")||(statetype=C&&command="fwd")&&command!="back"&&command!="up"
trigger1=ctrl
attr=C,AA,AP
stateno=6101
slot=0
time=2+(2*(var(25)))

[state -1,Parry_Air]
type=hitoverride
triggerall=!ailevel
triggerall=(statetype=A&&command="fwd")&&command!="back"&&command!="up"&&command!="down"
trigger1=ctrl
attr=SA,AA,AP
stateno=6102
forceair=1
slot=0
time=2+(2*(var(25)))



[State -1,Run_Fwd]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=100
triggerall=!ailevel
triggerall=statetype!=A
trigger1=command="FF"
trigger1=ctrl

[State -1,Run_Back]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=105
triggerall=!ailevel
triggerall=statetype!=A
trigger1=command="BB"
trigger1=ctrl

[State -1,Plant-Throw]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=800
triggerall=!ailevel
triggerall=command="holdfwd"||command="holdback"
triggerall=command="z"&&command!="holddown"
triggerall=p2bodydist x=[-(const(size.ground.front)/2),25]
triggerall=p2statetype!=A&&p2statetype!=L&&p2movetype!=H
triggerall=statetype!=A
trigger1=ctrl

[State -1,Vine_Grip]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=820
triggerall=!ailevel
triggerall=command="holdfwd"||command="holdback"
triggerall=command="c"&&command!="holddown"
triggerall=p2bodydist x=[-(const(size.ground.front)/2),25]
triggerall=p2statetype!=A&&p2statetype!=L&&p2movetype!=H
triggerall=statetype!=A
trigger1=ctrl

[State -1, Taunt]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=199
triggerall=!ailevel
triggerall=stateno!=199
triggerall=command="s"
trigger1=statetype!=A
trigger1=ctrl

[state -1,Recover-Ground]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=5200
trigger1=!ailevel
trigger1=stateno=5050||stateno=5071
trigger1=vel y>0
trigger1=pos y>=const(movement.air.gethit.groundrecover.ground.threshold)
trigger1=alive
trigger1=gethitvar(fall.recover)
trigger1=command="recovery"

[state -1,Recover-Air]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=5210
trigger1=!ailevel
trigger1=stateno=5050
trigger1=vel y>const(movement.air.gethit.airrecover.threshold)
trigger1=pos y<const(movement.air.gethit.groundrecover.ground.threshold)
trigger1=alive
trigger1=canrecover
trigger1=command="recovery"

[State -1,SWP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=200
triggerall=!ailevel
triggerall=command="x"&&command!="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101

[State -1,SMP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=210
triggerall=!ailevel
triggerall=command="y"&&command!="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(2)=1
trigger3=var(27)=1||var(27)=4
trigger4=var(28)=1||var(28)=4

[State -1,SSP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=220
triggerall=!ailevel
triggerall=command="z"&&command!="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(27)=1||var(27)=2||var(27)=4||var(27)=5
trigger3=var(28)=1||var(28)=2||var(28)=4||var(28)=5

[State -1,SWK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=230
triggerall=!ailevel
triggerall=command="a"&&command!="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(27)=1||var(27)=4

[State -1,SMK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=240
triggerall=!ailevel
triggerall=command="b"&&command!="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(3)=1
trigger3=var(27)=1||var(27)=2||var(27)=4||var(27)=5
trigger4=var(28)=1||var(28)=4

[State -1,SSK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=250
triggerall=!ailevel
triggerall=command="c"&&command!="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(27)=1||var(27)=2||var(27)=3||var(27)=4||var(27)=5||var(27)=6
trigger3=var(28)=1||var(28)=2||var(28)=4||var(28)=5

[State -1,CWP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=400
triggerall=!ailevel
triggerall=command="x"&&command="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101

[State -1,CMP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=410
triggerall=!ailevel
triggerall=command="y"&&command="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(2)=4
trigger3=var(27)=1||var(27)=4
trigger4=var(28)=1||var(28)=4

[State -1,CSP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=420
triggerall=!ailevel
triggerall=command="z"&&command="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(27)=1||var(27)=2||var(27)=4||var(27)=5
trigger3=var(28)=1||var(28)=2||var(28)=4||var(28)=5

[State -1,CWK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=430
triggerall=!ailevel
triggerall=command="a"&&command="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(27)=1||var(27)=4

[State -1,CMK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=440
triggerall=!ailevel
triggerall=command="b"&&command="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(3)=4
trigger3=var(27)=1||var(27)=2||var(27)=4||var(27)=5
trigger4=var(28)=1||var(28)=4

[State -1,CSK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=450
triggerall=!ailevel
triggerall=command="c"&&command="holddown"
triggerall=statetype!=A
trigger1=ctrl||stateno=100||stateno=101
trigger2=var(27)=1||var(27)=2||var(27)=3||var(27)=4||var(27)=5||var(27)=6
trigger3=var(28)=1||var(28)=2||var(28)=4||var(28)=5

[State -1,AWP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=600
triggerall=!ailevel
triggerall=command="x"
triggerall=statetype=A
trigger1=ctrl

[State -1,AMP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=610
triggerall=!ailevel
triggerall=command="y"
triggerall=statetype=A
trigger1=ctrl

[State -1,ASP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=620
triggerall=!ailevel
triggerall=command="z"
triggerall=statetype=A
trigger1=ctrl

[State -1,AWK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=630
triggerall=!ailevel
triggerall=command="a"
triggerall=statetype=A
trigger1=ctrl

[State -1,AMK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=640
triggerall=!ailevel
triggerall=command="b"
triggerall=statetype=A
trigger1=ctrl

[State -1,ASK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=650
triggerall=!ailevel
triggerall=command="c"
triggerall=statetype=A
trigger1=ctrl



[State -1,Walk]
type=Null
value=21
triggerall=ailevel
triggerall=roundstate=2
triggerall=statetype!=A
triggerall=(stateno!=[10,12])&&(prevstateno!=[10,12])
triggerall=(stateno!=[20,21])&&(prevstateno!=[20,21])
triggerall=(stateno!=[120,159])&&(prevstateno!=[120,159])
triggerall=!inguarddist
triggerall=ctrl
trigger1=numtarget&&random%3=0

[state -1,GrabDodge]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=40
triggerall=ailevel
triggerall=roundstate=2
triggerall=stateno!=40
triggerall=inguarddist
triggerall=ctrl
triggerall=statetype!=A
trigger1=enemynear,hitdefattr=SC,NT,ST,HT&&random<=600

[State -1,Guard]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=120
trigger1=ailevel
trigger1=cond(var(25),statetype!=A,1)
trigger1=roundstate=2
trigger1=inguarddist
trigger1=ctrl&&(stateno!=[120,155])&&(stateno!=[6100,6102])
trigger1=!(enemynear,hitdefattr=SCA,AT)&&(enemynear,time<70)
trigger1=random<(ifelse(statetype=A&&p2statetype!=A,0,ifelse(statetype!=A&&p2statetype=A,1000,900))*(ailevel**2/64.0))


[State -1,Run_Fwd]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=100
triggerall=ailevel
triggerall=roundstate=2
triggerall=statetype!=A
triggerall=(stateno!=[10,12])&&(prevstateno!=[10,12])
triggerall=(stateno!=[100,101])&&(prevstateno!=[100,101])
triggerall=(stateno!=[105,106])&&(prevstateno!=[105,106])
triggerall=!inguarddist
triggerall=ctrl
trigger1=(p2bodydist x>90)&&p2movetype!=A&&random<(50*(ailevel**2/64.0))
trigger2=(p2bodydist x>120)&&numtarget&&p2statetype=L&&random<(50*(ailevel**2/64.0))

[State -1,Run_Back]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=105
triggerall=ailevel
triggerall=roundstate=2
triggerall=statetype!=A
triggerall=(stateno!=[10,12])&&(prevstateno!=[10,12])
triggerall=(stateno!=[100,101])&&(prevstateno!=[100,101])
triggerall=(stateno!=[105,106])&&(prevstateno!=[105,106])
triggerall=!inguarddist
triggerall=ctrl
trigger1=frontedgedist<backedgedist
trigger1=(p2bodydist x=[0,25])&&p2stateno=5120
trigger1=random<(100*(ailevel**2/64.0))



[State -1,SWP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=200
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,90])&&(p2dist y=[-60,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))

[State -1,SMP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=210
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,100])&&(p2dist y=[-70,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=var(2)=1&&random<(100*(ailevel**2/64.0))
trigger3=(var(27)=1||var(27)=4)&&random<(100*(ailevel**2/64.0))
trigger4=(var(28)=1||var(28)=4)&&random<(100*(ailevel**2/64.0))

[State -1,SSP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=220
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,150])&&(p2dist y=[-60,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=(var(27)=1||var(27)=2||var(27)=4||var(27)=5)&&random<(100*(ailevel**2/64.0))
trigger3=(var(28)=1||var(28)=2||var(28)=4||var(28)=5)&&random<(100*(ailevel**2/64.0))

[State -1,SWK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=230
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,50])&&(p2dist y=[-30,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=(var(27)=1||var(27)=4)&&random<(100*(ailevel**2/64.0))

[State -1,SMK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=240
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,75])&&(p2dist y=[-55,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=var(3)=1&&random<(100*(ailevel**2/64.0))
trigger3=(var(27)=1||var(27)=2||var(27)=4||var(27)=5)&&random<(100*(ailevel**2/64.0))
trigger4=(var(28)=1||var(28)=4)&&random<(100*(ailevel**2/64.0))

[State -1,SSK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=250
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,80])&&(p2dist y=[-100,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=(var(27)=1||var(27)=2||var(27)=3||var(27)=4||var(27)=5||var(27)=6)&&random<(100*(ailevel**2/64.0))
trigger3=(var(28)=1||var(28)=2||var(28)=4||var(28)=5)&&random<(100*(ailevel**2/64.0))

[State -1,CWP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=400
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=p2statetype!=A
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,90])&&(p2dist y=[-30,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))

[State -1,CMP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=410
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=p2statetype!=A
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,10])&&(p2dist y=[-30,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=(var(27)=1||var(27)=4)&&random<(100*(ailevel**2/64.0))
trigger3=(var(28)=1||var(28)=4)&&random<(100*(ailevel**2/64.0))

[State -1,CSP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=420
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,170])&&(p2dist y=[-50,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=(var(27)=1||var(27)=2||var(27)=4||var(27)=5)&&random<(100*(ailevel**2/64.0))
trigger3=(var(28)=1||var(28)=2||var(28)=4||var(28)=5)&&random<(100*(ailevel**2/64.0))

[State -1,CWK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=430
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=p2statetype!=A
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,80])&&(p2dist y=[-30,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=(var(27)=1||var(27)=4)&&random<(100*(ailevel**2/64.0))

[State -1,CMK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=440
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=p2statetype!=A
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,65])&&(p2dist y=[-30,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=var(3)=4&&random<(100*(ailevel**2/64.0))
trigger4=(var(27)=1||var(27)=2||var(27)=4||var(27)=5)&&random<(100*(ailevel**2/64.0))
trigger5=(var(28)=1||var(28)=4)&&random<(100*(ailevel**2/64.0))

[State -1,CSK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=450
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=p2statetype!=A
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,75])&&(p2dist y=[-30,5])
trigger1=(ctrl||stateno=100||stateno=101)&&random<(50*(ailevel**2/64.0))
trigger2=(var(27)=1||var(27)=2||var(27)=3||var(27)=4||var(27)=5||var(27)=6)&&random<(100*(ailevel**2/64.0))
trigger3=(var(28)=1||var(28)=2||var(28)=4||var(28)=5)&&random<(100*(ailevel**2/64.0))

[State -1,AWP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=600
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype=A
triggerall=(p2bodydist x=[-5,90])&&(p2dist y=[-15,70])
trigger1=ctrl&&random<(100*(ailevel**2/64.0))

[State -1,AMP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=610
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype=A
triggerall=(p2bodydist x=[-5,10])&&(p2dist y=[-150,-55])
trigger1=ctrl&&random<(25*(ailevel**2/64.0))

[State -1,ASP]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=620
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype=A
triggerall=(p2bodydist x=[-5,80])&&(p2dist y=[-30,100])
trigger1=ctrl&&random<(100*(ailevel**2/64.0))

[State -1,AWK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=630
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype=A
triggerall=(p2bodydist x=[-5,60])&&(p2dist y=[-15,30])
trigger1=ctrl&&random<(100*(ailevel**2/64.0))

[State -1,AMK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=640
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype=A
triggerall=(p2bodydist x=[-75,90])&&(p2dist y=[-30,30])
trigger1=ctrl&&random<(100*(ailevel**2/64.0))

[State -1,ASK]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=650
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype=A
triggerall=(p2bodydist x=[-5,110])&&(p2dist y=[-15,40])
trigger1=ctrl&&random<(100*(ailevel**2/64.0))
trigger2=ctrl&&vel y>1&&random<(250*(ailevel**2/64.0))

[State -1,Plant-Throw]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=800
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=p2movetype!=H&&p2statetype!=A
triggerall=p2bodydist x=[-2,25]
triggerall=ctrl
trigger1=random<=(ifelse((p2stateno=[120,155]),200,100)*(ailevel**2/64.0))

[State -1,Vine_Grip]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=820
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=p2movetype!=H&&p2statetype!=A
triggerall=p2bodydist x=[-2,25]
triggerall=ctrl
trigger1=random<=(ifelse((p2stateno=[120,155]),200,100)*(ailevel**2/64.0))



[State -1,Shouting_of_The_Wind]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1300+(2700*(var(25)&&random<200))
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=(p2bodydist x=[0,180])&&(p2dist y=[-60,60])
trigger1=(ctrl||stateno=100||stateno=101||stateno=40||stateno=52)&&random<(50*(ailevel**2/64.0))
trigger2=(var(2)=1||var(2)=2||var(3)=1||var(3)=2)&&random<(100*(ailevel**2/64.0))
trigger3=(var(2)=4||var(3)=4)&&random<(100*(ailevel**2/64.0))

[State -1,Delight_of_Green]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1400+(2700*(var(25)&&random<200))
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,180])&&(p2dist y=[-100,5])
trigger1=(ctrl||stateno=100||stateno=101||stateno=40||stateno=52)&&random<(50*(ailevel**2/64.0))
trigger2=(ctrl||stateno=100||stateno=101||stateno=40||stateno=52)&&p2statetype=A&&enemynear,vel y>0&&(p2bodydist x=[50,150])&&random<(100*(ailevel**2/64.0))

[State -1,Child_of_The_Earth]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1500
triggerall=ailevel
triggerall=roundstate=2

triggerall=statetype!=A
triggerall=numhelper(8040)<2
triggerall=(p2bodydist x>(150-(100*(p2statetype=L))))&&(p2dist y=[-95,20])
trigger1=(ctrl||stateno=100||stateno=101||stateno=40||stateno=52)&&random<(50*(ailevel**2/64.0))
trigger2=(ctrl||stateno=100||stateno=101||stateno=40||stateno=52)&&p2bodydist x>180&&p2movetype=I&&random<(200*(ailevel**2/64.0))



[State -1,Plants'_Commandment]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=3000
triggerall=ailevel
triggerall=power>=1000&&!var(25)||var(25)&&var(26)>=500
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,100])&&(p2dist y=[-50,5])
trigger1=(ctrl||stateno=100||stateno=101||stateno=40||stateno=52)&&random<(50*(ailevel**2/64.0))
trigger2=(var(4)=1||var(4)=2||var(5)=1||var(5)=2)&&random<(100*(ailevel**2/64.0))
trigger3=(var(4)=4||var(5)=4)&&random<(100*(ailevel**2/64.0))
trigger4=stateno=52&&prevstateno=650&&numtarget&&p2statetype!=A&&random<(250*(ailevel**2/64.0))

[State -1,Natural_Disaster]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=3100
triggerall=ailevel
triggerall=power>=1000&&!var(25)||var(25)&&var(26)>=500
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=!numhelper(8020)

trigger1=(ctrl||stateno=100||stateno=101||stateno=40||stateno=52)&&random<(25*(ailevel**2/64.0))

[State -1,Blessing_of_The_Sun]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=3200
triggerall=ailevel
triggerall=power>=3000&&!var(25)
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[-50,50])&&p2statetype!=A
trigger1=(ctrl||stateno=100||stateno=101||stateno=40||stateno=52)&&random<(50*(ailevel**2/64.0))
trigger2=enemynear,statetype=A&&(enemynear,vel x>=0||backedgebodydist<=20)&&random<(150*(ailevel**2/64.0))



[state -1,Recover-Ground]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=5200
trigger1=ailevel
trigger1=roundstate=2
trigger1=stateno=5050||stateno=5071
trigger1=vel y>0
trigger1=pos y>=const(movement.air.gethit.groundrecover.ground.threshold)
trigger1=alive
trigger1=gethitvar(fall.recover)
trigger1=random<(100*(ailevel**2/64.0))

[state -1,Recover-Air]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=5210
trigger1=ailevel
trigger1=roundstate=2
trigger1=stateno=5050
trigger1=vel y>const(movement.air.gethit.airrecover.threshold)
trigger1=pos y<const(movement.air.gethit.groundrecover.ground.threshold)
trigger1=alive
trigger1=canrecover
trigger1=random<(100*(ailevel**2/64.0))



[State -1,Guard_Counter]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1100
triggerall=ailevel
triggerall=power>=1000&&!var(25)
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(p2bodydist x=[0,75])&&(p2dist y=[-45,5])
trigger1=stateno=150||stateno=152
trigger1=life<(.2*lifemax)&&random<(75*(ailevel**2/64.0))
trigger1=enemynear,vel x>=0&&enemynear,vel y>=0&&enemynear,life>55

[State -1,Dodge]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1200
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(ctrl||stateno=100||stateno=101)&&!(enemynear,hitdefattr=SCA,AT)

trigger1=p2movetype=A&&(p2stateno!=[3000,3999])&&inguarddist&&random<(75*(ailevel**2/64.0))

[State -1,Roll_Fwd]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1205
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(ctrl||stateno=100||stateno=101)&&!(enemynear,hitdefattr=SCA,AT)
trigger1=enemynear,vel x>=0&&(p2bodydist x=[-60,60])&&p2movetype=A&&random<(50*(ailevel**2/64.0))
trigger2=backedgebodydist<=5&&p2movetype=A&&random<(50*(ailevel**2/64.0))
trigger3=inguarddist&&vel x>4&&random<(50*(ailevel**2/64.0))

[State -1,Roll_Bck]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=1210
triggerall=ailevel
triggerall=roundstate=2
triggerall=p2statetype!=L&&p2stateno!=5120&&p2stateno!=5201
triggerall=statetype!=A
triggerall=(ctrl||stateno=100||stateno=101)&&!(enemynear,hitdefattr=SCA,AT)
triggerall=backedgedist!=[-10,15]
trigger1=enemynear,vel x>1&&p2movetype=A&&(p2bodydist x=[0,60])&&random<(50*(ailevel**2/64.0))

[State -1,Power_Charge]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=6000
triggerall=ailevel
triggerall=!var(25)
triggerall=(power<powermax&&power<const(data.power))
triggerall=roundstate=2
triggerall=statetype!=A
triggerall=ctrl
trigger1=enemynear,movetype!=A&&p2dist x>=160&&!enemy,numproj&&!inguarddist&&random<(25*(ailevel**2/64.0))

[State -1,Vigor_Mode]
type=ChangeState
triggerall = !NumPartner || (NumPartner && (sysvar(4) != [8,9]) && (sysvar(4) != 12) && (StateNo != [1251109,1251114])) 
value=7000
triggerall=ailevel
triggerall=power>=1000||var(25)
triggerall=roundstate=2
triggerall=statetype!=A
triggerall=ctrl
trigger1=p2movetype!=A&&p2bodydist x>200&&!var(25)&&random<(50*(ailevel**2/64.0))

