
 ====================| Ruby Heart by Buckus, POTS Style edit by 2D4&gui0007 |=========================
                                                                                                       [30/05/2019]
                       
 - Email/Contact: guiaugustosantos0007@gmail.com

 - YouTube Channel: https://www.youtube.com/user/TheGUTAA

 - Mugen Fighters Guild: http://mugenguild.com/forum/ || Mugen Free For All: http://mugenfreeforall.com/

 - Customized version of Capcom's Ruby Heart character, for Mugen 1.0+

===============<Features>===============

 - All the essential stuff
 - Mordenized POTS Style gameplay
 - Details and moves taken from her Marvel vs. Capcom 2 appearances
 - Gameplay mixed from several games, including CvS2, SFZ3 and SF3
 - Original and edited effects from various games
 - Sounds from various games, including CvS2 and NBC
 - Palette Selector, Chain Combos & Air Combos that are configurable in "config.txt"
 - Intros, win poses and special animations
 - A.I. revamped


===============<Movelist>===============

U - up          x - weak punch         a - weak kick
D - down        y - medium punch       b - medium kick
F - forward     z - strong punch       c - strong kick
B - back        p - any punch          k - any kick
s - start       2p- two punches        2k- two kicks

(Close)   - Move performed only close to the opponent.
(Air)     - Move must be performed in the air.
(Air also)- Move can be performed either on the ground or in the air.
(EX)      - Move has an EX version, performed by pressing two punch/kick buttons.
(MAX)     - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>

Anchor	                        F, z
Throw 1                         F/B, p (Close)
Throw 2                         F/B, k (Close)


<SPECIAL>

Schwarzaile (EX) (Air Also)     D, DF, F, p
Sublimation (EX)		D, DF, F, k
Fant�me (EX)			D, DB, B, k
Rafale Cannon (EX)		F, DF, D, DB, B, p


<Lv1 SUPER>

Hyper Schwarzaile (Air Also)	D, DF, F, D, DF, F, p
Hyper Sublimation (MAX)		D, DF, F, D, DF, F, k
Mille Fant�mes			D, DB, B, D, DB, B, k


<Lv3 SUPER>

Pare-tonn're			D, DB, B, D, DF, F, 2k


<SYSTEM>

Run:                   F, F (hold)
Backward Dash:         B, B
Sidestep:              a + x
Forward  Roll:         F + a + x
Backward  Roll:        B + a + x
Parry High:            (tap) F
Parry Low:             (tap) D
Air Parry:             (tap) F (Air)
Power Charge:          b+y (hold)
Zero Counter:          B, DB, D, p  (during standing or crouching guard)
Excel/Custom Combo:    c+z (Air also)
Fall Recovery:         2p (while falling from a hit)
Low Jump:              U (tap)
High Jump:             D, U
Long Low Jump:         D, U (tap)
Taunt		       s


===============<Version History>===============

<30.05.2019>
- gui0007 Update!
  .A.I. revamped
  .Retired the add004 stuff
  .Fixed ghost sprites
  .Fixed Hyper Sublimation
  .Small portrait fixed
  .Added Quotes
  .Some annoying bugs on the sprites and animations are fixed
  .Created this proper Readme.txt

<05.09.2016>
- 2Dee4ever POTS Edit release

<17.08.2013>
- Buckus original Beta release

===============<What's Missing>===============

 - Tour de Magie? Maybe?


===============<Special Thanks>===============

 - Buckus, for the original Beta of his Ruby Heart
 - Phantom.of.the.Server, Jmorphman, Infinite and DivineWolf for code base and inspiration
 - Memo, for the Modern POTS Style Template
 - 2Dee4ever, for the nice touch on the first edit
 - MUGEN Forums around and communities on Facebook for the support and love!
 - And YOU, for downloading Ruby Heart! ;)


=================<Disclaimer>=================

 - Ruby Heart� and Marvel vs. Capcom 2: New Age of Heroes� are property of Capcom�
 - This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes