
 ====================| Sonson by NDSilva, POTS Style edit by Koopa901, varo_hades & gui0007 |=========================
                                                                                                       [23/05/2019]
                       
 - Email/Contact: guiaugustosantos0007@hotmail.com

 - YT Channels
    .varo_hades: https://www.youtube.com/user/claudiohades/
    .gui0007:    https://www.youtube.com/user/TheGUTAA/

 - Mugen Fighters Guild: http://mugenguild.com/forum/ || Mugen Free For All: http://mugenfreeforall.com/

 - Customized version of Capcom's Sonson character, for Mugen 1.0+

===============<Features>===============

 - All the essential stuff
 - Mordenized POTS Style gameplay
 - Details and moves taken from her Marvel vs. Capcom 2 appearance
 - Gameplay mixed from several games, including CvS2, SFZ3 and SF3
 - Original and edited effects from various games
 - Sounds from various games, including CvS2 and NBC
 - Palette Selector, Chain Combos & Air Combos that are configurable in "config.txt"
 - Intros, win poses and special animations
 - A.I. revamped


===============<Movelist>===============

U - up          x - weak punch         a - weak kick
D - down        y - medium punch       b - medium kick
F - forward     z - strong punch       c - strong kick
B - back        p - any punch          k - any kick
s - start       2p- two punches        2k- two kicks

(Close)   - Move performed only close to the opponent.
(Air)     - Move must be performed in the air.
(Air Also)- Move can be performed either on the ground or in the air.
(EX)      - Move has an EX version, performed by pressing two punch/kick buttons.
(MAX) - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>

Gansai Hekiretsu		F, z
Throw 1                         F/B, p (Close)
Throw 2                         F/B, k (Close)


<SPECIAL>

Fuusetsu Zan (EX)(Air Also)	Press p repeatdly
Shienbu (EX)			D, DF, F, p
Seiten Rengeki (EX)		F, D, DF, p
Kingin no Hisago (EX)		D, DB, B, p
Hofuku-Zenshin                  B, DB, D, DF, F, k
Wall Climb                      D, DB, B, k
                                .Press p to cancel
                                .Press k to attack


<Lv1 SUPER>

Tenchi-Tsuken			D, DF, F, D, DF, F, p
POW				D, DF, F, D, DF, F, k


<Lv3 SUPER>

En'ou				D, DB, B, D, DB, B, pk
                                .Press y to Uppercut
                                .Press k to Breath Fire, move to aim


<SYSTEM>

Run:                   F, F (hold)
Backward Dash:         B, B
Sidestep:              a + x
Forward  Roll:         F + a + x
Backward  Roll:        B + a + x
Parry High:            (tap) F
Parry Low:             (tap) D
Air Parry:             (tap) F (Air)
Power Charge:          b+y (hold)
Zero Counter:          B, DB, D, p / B, DB, D, k  (during standing or crouching guard)
Custom Combo: 	       c+z (Air also)
Fall Recovery:         2p (while falling from a hit)
Low Jump:              U (tap)
High Jump:             D, U
Long Low Jump:         D, U (tap)
Taunt		       s


===============<Version History>===============

<20.05.2019>
- gui0007 Update!
  .A.I. revamped
  .Bug on Kingin no Hisago fixed (thanks NDSilva for the tip!)
  .LVL3 Portrait fixed
  .Power Charge animation fixed
  .Added quotes
  .Serious bugs on some sprites are fixed
  .Create this proper Readme.txt
  .Updated to work on the recent version of add004 Tag System

<07.02.2017>
- Koopa901 & varo_hades edit release

<06.04.2016>
- NDSilva original version release

===============<What's Missing>===============

 - LVL2 Supers
 - Fix the bugs on crouch strong punch and jump medium kick


===============<Special Thanks>===============

 - NDSilva for the awesome original version
 - Phantom.of.the.Server, Jmorphman, Infinite and DivineWolf for code base and inspiration
 - Memo, for the Modern POTS Style Template
 - Koopa901 and varo_hades for the first edit
 - MUGEN Forums around and communities on Facebook for the support and love!
 - And YOU, for downloading Sonson. ;)


=================<Disclaimer>=================

- Sonson and Marvel vs. Capcom 2� are property of Capcom�
- This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes