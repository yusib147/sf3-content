                            __________________________________________
===========================| Adelheid by Saikou Shiva	              |===========================
                            ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯         
                                                                               
 - Contact: Saikou_Shiva#3738
 - Customized version of Adelheid for MUGEN 1.0/1.1

=====<Version History>=====

<4/06/22>
 - First release
<4/07/22>
 - Second release (Hitbox revisions and gameplay improvement)
<4/12/22>
 - Third release (see "UPDATES.txt" file for full patch notes)
<4/13/22>
 - Fourth (?) release, mostly a small update patching up noticeable screw ups (see "UPDATES.txt" file for full patch notes)
<4/19/22>
 - Fifth release (Hitbox revision and alterations to some command/special moves)
<4/22/22>
 - Sixth release (First official release)
<4/24/22>
 - Seventh release (Minor damage patch for Grosse Sklaven)
<4/28/22>
 - Eighth release (Minor fixes and sprite corrections)
<5/13/22>
 - Ninth release (Reworked code and fixes to gameplay. See "UPDATES.txt" file for further detail)
<6/9/22>
 - Tenth release (Revamped AI and reworked Grosse Kreis, along with other minor fixes)
<6/17/22>
 - Eleventh release (Improved AI and reworked Grosse Drucken, as well as fixing Slide/Max Kreiss' corner pushback)
<6/21/22>
 - Twelfth release (Reworked G.Zerstorung, CS'd Rose, Fixed P2 position for G.Drucken/Sklaven)
<6/23/22>
 - Thirteenth release (Moves and damage overhaul, bug fixes, and sprite replacement)
<6/27/22>
 - Fourteenth release (Audio bugs fixed, new Super, palettes, and reworked G.Kronprinz)
<6/29/22>
 - Fifteenth release (Minor tweaking on Kreis, reducing pushback and damage, and making all normals cancel into Rising Kicken)
<7/20/22>
 - Sixteenth release (Patched out any leftover bugs, fixed color palettes for Rose and Adelheid, and indexed SFX colors to palettes)
<7/31/22>
 - Omega Update (Leftover bug fixes)
<9/20/22>
 - Final Update (Sprite and palette corrections, reworked specials, streamlined hit/hurtboxes, fixed all frame data issues)

=====<Special Thanks>=====

 - Varo_Hades, whose Rugal I used as a template to make Adel.
 - P.o.t.S. for code, effects, hitsparks, formatting style.
 - Chuchoryu for the Capcom-ized sprites.
 - Everyone at the Mugen Fighters Guild and UMT Discord servers for their feedback and contribution.
 - Additional thanks to IKEISLEGEND for aiding me with coding issues.

=====<Disclaimer>=====

 - The character "Adelheid Bernstein" is property of SNK
 - Capcom vs SNK is property of Capcom
 - This MUGEN character is a non-profit fan work, and may not be used for any commercial purposes

=====<Additional Info>=====

 - Color separation, palettes, and newly created/edited sprites were all done by me
 - All PRØJECT.13™ palettes were created by PRØJECT.13™ himself
 - "Adelheid EX" is not the Omega form I promised, as it was merely created for testing purposes and to give players a peek at what to expect
 - "Adelheid EX" was made simply to change a few moves here and there, as opposed to being its own character
 - All future updates will be uploaded to the original video, listed here : https://www.youtube.com/watch?v=psZLOn4M0IY
 - If there are any issues or suggestions you wish to make, then feel free to contact me through Discord

=====<PLEASE READ>=====
 - As of September twentieth 2022, There will be no further support or updates to Adelheid
   so any patches or additional "updates" found after this date are not official. (Done by me)
 - There is currently a patch in the works for Omega Adel, which might also be the last,
   due to a lack of feedback and criticism.
 - Once work for Omega Adel is completely done with, all time and resources will be directed
   towards my conversion of CvS3 King Lion and King Leo