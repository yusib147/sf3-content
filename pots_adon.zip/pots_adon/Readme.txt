                            _______________________________________
===========================|  Adon by Trololo edited by varo_hades |===========================
                            ���������������������������������������           [09.05.11]
Original: Joe Higashi by Jmorphman.

 - Contact:	Jmorphman@aol.com
 - Website:	http://network.mugenguild.com/jmorphman/

 - Customized version of Capcom's Adon character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, including CvS2, KOF, SFZ3 and SF3
 - Special intros versus Sagat, King, and Adon



=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks        3k- three kicks 

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>

.Jaguar Crunch:                         F + Y
.Jaguar Slam:                      	F/B + 2p   (near opponent)
.Jaguar Carry


<SPECIAL>

.Rising Jaguar (EX):         	   	F, D, DF, k
.Jaguar Kick (EX):                 	B, D, DB, k
--Airborne Jaguar Kick:                 D, DB, B, k (Jumping upward or forward)
.Jaguar Tooth (EX):                     F, DF, D, DB, B, k
.Thosand of Jaguars (EX):                  p, p, p, p, p


<SUPER>

.Jaguar Varied Assault (MAX):           D, DF, F, D, DF, F, p
   MAX version can be finished:
    -Thosand of Jaguars:                P (Between the fourth and fifth hits)  
    -Jaguar Assassin:                   K (Between the fourth and fifth hits)             
.Jaguar Revolver (MAX):                 D, DB, B, D, DB, B, k


<LV3 SUPER>

.Jaguar Avalanche:                      D, DF, F, D, DF, F, 3k


<SYSTEM>

.Forward Dash:                    	F, F
   .Run:                           	hold
.Backward Dash:                    	B, B
.Low Jump:                         	tap U
.High Jump:                        	tap D, U
.Long Low Jump:                    	tap D, tap U            
.Sidestep:                         	a + x
   .Sidestep Attack:               	p / k
.Forward Roll:                     	F + a + x
.Backward Roll:                    	B + a + x
.Parry High:                       	tap F
.Parry Low:                        	tap D
.Air Parry:                        	tap F           		(Air)
.Power Charge:                     	hold b+y
.Zero Counter:                     	B, DB, D, p / k 		(during standing or crouching guard)
.Custom Combo:                     	c + z           		(Air also)
.Fall Recovery:                    	2p / a + x      		(while falling and allowed)



=====<Move Details>=====

 - Keep tapping punch buttons to extend Thosand Jaguars indefinitely
 - Jaguar Assassin or Thosand Jaguars must be performed AFTER 4th PUNCH in MAX Jaguar Varied Assault!
 - The MAX Jaguar Revolver, used after Jaguar Varied Assault, lost its X velocity. After first part velocity is normal.
 - Jaguar Revolver LVL 3 have alternative command: D, DB, B, D, DF, F, 2K
 - Airborne Jaguar Kick can be performed even if enemy behind you.

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage


CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing
   faster and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start


=====<Special Thanks>=====
 - H" for making original Adon with nice sprites, what i used
 - Jmophhman for making original Joe Higashi
 - Hades for the hyper portrait and finish fonts.
 - Zombiebrock for some palettes.
 - To all people, who helps him to make this character and called in original <Special Thanks>
 - Capcom for making original character
 - To all people, who helps me with editing this char (for font for Super Finish and testing)

=====<Disclaimer>=====

 - The Adon character is property of Capcom
 - Capcom vs SNK is property of Capcom
 - This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes