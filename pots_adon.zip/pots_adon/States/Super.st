; _______________________________________
;| Adon by Trololo                       |
; ���������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<JAGUAR REVOLVER>=============================
[StateDef 3000]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 54

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = 31,-65
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 54
moveTime = 50
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, JAGUAR!]
type = PlaySnd
trigger1 = !Time
value = 3000,0
channel = 0

[State 3000, REVOLVER!!!]
type = PlaySnd
trigger1 = AnimElem = 3
value = 3000,1
channel = 0

[State 3000, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
trigger2 = AnimElem = 12
value = 1,5
channel = 1

[State 1300, Jumping Sound]
type = PlaySnd
trigger1 = AnimElem = 4  || AnimElem = 14
value = 40,0
channel = 1

[State 1300, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 5  || AnimElem = 15
value = 1,5
channel = 3

[State 1300, Golden Heel Sound]
type = PlaySnd
trigger1 = AnimElem = 6  || AnimElem = 16
value = 1300,1
channel = 4

[State 1300, StateTypeSet: Air, Physics: None]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
stateType = A
physics = N

[State 1300, Dust Helper]
type = Helper
trigger1 = AnimElem = 4  || AnimElem = 14
helperType = Normal
stateNo = 8100
ID = 8100
name = "Golden Heel Dust"
posType = P1
ownPal = 1

[State 1300, Golden Heel FX]
type = Explod
trigger1 = AnimElem = 8 || AnimElem = 18
anim = 1306
sprPriority = 3
posType = P1
bindTime = -1
scale = 0.45,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1
removeOnGetHit = 1
ignoreHitPause = 0

[State 1300, First]
type = VelSet
trigger1 = AnimElem = 2
x = 6.0
y = -9
[State 0, First]
type = VelSet
trigger1 = AnimElem = 6
x = 4.0
y = 10

[State 0, VelSet]
type = VelSet
trigger1 = pos y > -vel y
x = 0
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = pos y > -vel y
trigger2 = animelem = 10
value = 3000
elem = 11

[State 1300, Second]
type = VelSet
trigger1 = AnimElem = 12
x = 6.0
y = -4
[State 0, Second]
type = VelSet
trigger1 = AnimElem = 16
x = 4.0
y = 4

[State 1300, 1 & 3 Hits]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 8 || AnimElem = 18
ID = 1300
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = 52, 10
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 0, 36
pauseTime = 3, 3
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
animType = Low, Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 36
ground.slideTime = 36
guard.hitTime = 36
air.hitTime = 120
down.hitTime = 20
ground.velocity = -8, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 3.24
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 51), var(36) := -84
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1300, Second Kick]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || (var(15) < 2 && NumTarget(1300)) || var(20))
trigger1 = AnimElem = 9
ID = 1301
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = 52, 10
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 0, 36
pauseTime = 3, 3
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
animType = Low, Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 36
ground.slideTime = 36
guard.hitTime = 36
air.hitTime = 120
down.hitTime = 20
ground.velocity = -16, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 6.57
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 56), var(36) := -43
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1300, Final Kick]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || (var(15) < 2 && NumTarget(1300)) || var(20))
trigger1 = AnimElem = 19
ID = 1301
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = 52, 10
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 0, 36
pauseTime = 3, 3
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
animType = Low, Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
down.hitTime = 20
ground.velocity = -8, 1
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 6.57
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 56), var(36) := -43
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 3000, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(20) >= 0
moveType = I

[State 1300, End]
type = ChangeState
trigger1 = pos y > -vel y
trigger2 = Animelemtime(20) >= 0
value = 1201

;========================<JAGUAR REVOLVER MAX>=============================
[StateDef 3050]
type = S
physics = S
moveType = A
anim = 3050
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 54

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8510
name = "Superpause FX"
posType = P1
pos = 31,-65
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 54
moveTime = 50
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, JAGUAR!]
type = PlaySnd
trigger1 = !Time
value = 3000,0
channel = 0

[State 3000, REVOLVER!!!]
type = PlaySnd
trigger1 = AnimElem = 3
value = 3000,1
channel = 0

[State 3000, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
trigger2 = AnimElem = 12
trigger2 = AnimElem = 20
value = 1,5
channel = 1

[State 1300, Jumping Sound]
type = PlaySnd
trigger1 = AnimElem = 4  || AnimElem = 14  || AnimElem = 24
value = 40,0
channel = 1

[State 1300, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 5  || AnimElem = 15  || AnimElem = 25
value = 1,5
channel = 3

[State 1300, Golden Heel Sound]
type = PlaySnd
trigger1 = AnimElem = 6  || AnimElem = 16  || AnimElem = 26
value = 1300,1
channel = 4

[State 1300, StateTypeSet: Air, Physics: None]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
stateType = A
physics = N

[State 1300, Dust Helper]
type = Helper
trigger1 = AnimElem = 4  || AnimElem = 14  || AnimElem = 24
helperType = Normal
stateNo = 8100
ID = 8100
name = "Golden Heel Dust"
posType = P1
ownPal = 1

[State 1300, Golden Heel FX]
type = Explod
trigger1 = AnimElem = 8 || AnimElem = 18 || AnimElem = 28
anim = 1306
sprPriority = 3
posType = P1
bindTime = -1
scale = 0.45,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1
removeOnGetHit = 1
ignoreHitPause = 0

[State 1300, First]
type = VelSet
trigger1 = Prevstateno = 3100 && AnimElem = 2
x = 0
y = -5
[State 0, First]
type = VelSet
trigger1 = Prevstateno = 3100 && AnimElem = 6
x = 0
y = 6

[State 1300, First]
type = VelSet
trigger1 = Prevstateno != 3100 && AnimElem = 2
x = 6.0
y = -9
[State 0, First]
type = VelSet
trigger1 = Prevstateno != 3100 && AnimElem = 6
x = 4.0
y = 10

[State 0, VelSet]
type = VelSet
trigger1 = pos y > -vel y
x = 0
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = animelem = 10 
trigger2 = pos y > -vel y
value = 3050
elem = 11
[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = animelem = 20
trigger2 = pos y > -vel y
value = 3050
elem = 21

[State 1300, Second and final]
type = VelSet
trigger1 = AnimElem = 12 || AnimElem = 22
x = 6.0
y = -4
[State 0, Second and final]
type = VelSet
trigger1 = AnimElem = 16 || AnimElem = 26
x = 4.0
y = 4

[State 1300, 1, 3 & 5 Hits]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 8 || AnimElem = 18 || AnimElem = 28
ID = 1300
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = 45, 10
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 0, 36
pauseTime = 3, 3
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
animType = Low, Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 36
ground.slideTime = 36
guard.hitTime = 36
air.hitTime = 120
down.hitTime = 20
ground.velocity = -8, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 3.24
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 51), var(36) := -84
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1300, 2 & 4 Kick]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || (var(15) < 2 && NumTarget(1300)) || var(20))
trigger1 = AnimElem = 9 || AnimElem = 19
ID = 1301
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = 45, 10
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 0, 36
pauseTime = 3, 3
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
animType = Low, Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 36
ground.slideTime = 36
guard.hitTime = 36
air.hitTime = 120
down.hitTime = 20
ground.velocity = -16, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 6.57
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 56), var(36) := -43
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1300, Final Kick]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || (var(15) < 2 && NumTarget(1300)) || var(20))
trigger1 = AnimElem = 29
ID = 1301
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = 55, 10
getPower = ifElse(!var(13), 144, 72) * !var(20), 36 * !var(20)
givePower = 0, 36
pauseTime = 3, 3
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
animType = Low, Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
down.hitTime = 20
ground.velocity = -8, 1
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 6.57
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 56), var(36) := -43
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 3000, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(30) >= 0
moveType = I

[State 1300, End]
type = ChangeState
trigger1 = pos y > -vel y
trigger2 = Animelemtime(30) >= 0
value = 1201

;========================<JAGUAR BARED ASSAULT>=============================
[StateDef 3100]
type = S
physics = N
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 54

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = -17,-93
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 54
moveTime = 50
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, Left Hand Punch FX]
type = Explod
trigger1 = Animelem = 4
anim = 3105
ID = 3105
posType = P1
pos = 63,-80
scale = 0.45,0.5
bindtime = -2
ontop = 1
[State 3100, Right Hand Punch FX]
type = Explod
trigger1 = Animelem = 8
anim = 3106
ID = 3106
posType = P1
pos = 52,-58
scale = 0.45,0.5
bindtime = -2
ontop = 1
[State 3100, Left Hand Punch FX]
type = Explod
trigger1 = Animelem = 12
anim = 3106
ID = 3106
vfacing=-1
posType = P1
pos = 60,-82
scale = 0.45,0.5
bindtime = -2
ontop = 1
[State 3100, Final FX]
type = Explod
trigger1 = Animelem = 17
anim = 3107
ID = 3107
vfacing=-1
posType = P1
pos = 48,-66
scale = 0.45,0.5
bindtime = -2
ontop = 1
[State 3100, Final FX]
type = Explod
trigger1 = Animelem = 17
anim = 3107
ID = 3107
vfacing=1
posType = P1
pos = 48,-66
scale = 0.45,0.5
bindtime = -2
ontop = 1

[State 3100, Voice 1]
type = PlaySnd
trigger1 = !Time
value = 3100,0
channel = 0

[State 3100, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
trigger2 = AnimElem = 8
trigger3 = AnimElem = 13
trigger4 = AnimElem = 16
value = 1,2
ownpal = 1

[State 3100, VarSet]
type = VarSet
trigger1 = 1
var(10) = 0

[State 3100, VelAdd]
type = VelAdd
trigger1 = AnimELem = 3
x = 5.0

[State 3100, Dust Helper]
type = Helper
trigger1 = AnimElem = 15
helperType = Normal
stateNo = 8100
ID = 8100
name = "Exploding Hurricane Tiger Heel Dust"
posType = P1
ownPal = 1

[State 3100, VelAdd: Final Kick]
type = VelAdd
trigger1 = AnimElem = 15
y = -4.0

[State 3100, StateTypeSet: Air, Physics = None]
type = StateTypeSet
trigger1 = AnimElem = 15
stateType = A

[State 3100, Gravity]
type = VelAdd
trigger1 = (AnimElemTime(17) >= 1)
y = 0.5

[State 3100, Spark XY]
type = Null
trigger1 = AnimElem = 8
trigger1 = var(35) := 57 || var(36) := -59
trigger2 = AnimElem = 4
trigger2 = var(35) := 65 || var(36) := -79
trigger3 = AnimElem = 13
trigger3 = var(35) := 65 || var(36) := -79
trigger4 = AnimElem = 16
trigger4 = var(35) := 47 || var(36) := -66

[State 3100]
type = Playsnd
trigger1 = AnimELem = 3
value = S4, 1
[State 3100]
type = Playsnd
trigger1 = AnimELem = 7
value = S4, 2
[State 3100]
type = Playsnd
trigger1 = AnimELem = 12
value = S4, 3
[State 3100]
type = Playsnd
trigger1 = AnimELem = 16
value = S3100, 2

[State 3100, Hit 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 4
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6,6
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -65, -79
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120


[State 3100, Hit 2]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 8
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6,6
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -57, -59
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, Hit 3]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 13
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6,6
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,-8.0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -65, -79
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, Final]
type = HitDef
trigger1 = AnimElem = 17
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6, 6
guard.pauseTime = 4, 4
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4.32, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -7, -3
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 41), var(36) := -58
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(18) >= 0
moveType = I

[State 3100, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 1201



;========================<MAX JAGUAR BARED ASSAULT>=============================
[StateDef 3150]
type = S
physics = N
moveType = A
anim = 3150
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 0, VarSet]
type = VarSet
trigger1 = !time
var(10) = 0

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 54

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3150, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3150, Super Pause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = -17,-93
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3150, Super Pause]
type = SuperPause
trigger1 = Time = 3
time = 54
moveTime = 50
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, Left Hand Punch FX]
type = Explod
trigger1 = Animelem = 4
anim = 3105
ID = 3105
posType = P1
pos = 63,-80
scale = 0.45,0.5
bindtime = -2
ontop = 1
[State 3100, Right Hand Punch FX]
type = Explod
trigger1 = Animelem = 8
anim = 3106
ID = 3106
posType = P1
pos = 52,-58
scale = 0.45,0.5
bindtime = -2
ontop = 1
[State 3100, Left Hand Punch FX]
type = Explod
trigger1 = Animelem = 12
anim = 3105
ID = 3105
posType = P1
pos = 53,-58
scale = 0.45,0.5
bindtime = -2
ontop = 1
vfacing = -1
[State 3100, Right Hand Punch FX]
type = Explod
trigger1 = Animelem = 16
anim = 3106
ID = 3106
posType = P1
pos = 58,-83
scale = 0.45,0.5
bindtime = -2
ontop = 1
vfacing = -1
[State 3100, Left Hand Punch FX]
type = Explod
trigger1 = Animelem = 21
anim = 3106
ID = 3106
vfacing=-1
posType = P1
pos = 60,-82
scale = 0.45,0.5
bindtime = -2
ontop = 1
[State 3100, Final FX]
type = Explod
trigger1 = Animelem = 25
anim = 3107
ID = 3107
vfacing=-1
posType = P1
pos = 48,-66
scale = 0.45,0.5
bindtime = -2
ontop = 1
[State 3100, Final FX]
type = Explod
trigger1 = Animelem = 25
anim = 3107
ID = 3107
vfacing=1
posType = P1
pos = 48,-66
scale = 0.45,0.5
bindtime = -2
ontop = 1

[State 3100, VelAdd]
type = VelAdd
trigger1 = AnimELem = 4
x = 5.0

[State 3100, Dust Helper]
type = Helper
trigger1 = AnimElem = 23
helperType = Normal
stateNo = 8100
ID = 8100
name = "Exploding Hurricane Tiger Heel Dust"
posType = P1
ownPal = 1

[State 3150, Voice 1]
type = PlaySnd
trigger1 = !Time
value = 3100,0
channel = 0

[State 3150, Woosh Sound 1]
type = PlaySnd
trigger1 = AnimELem = 3
trigger2 = AnimELem = 7
trigger3 = AnimELem = 11
trigger4 = AnimELem = 15
trigger5 = AnimELem = 20
value = 1,2

[State 3150, Woosh Sound 2]
type = PlaySnd
trigger1 = AnimELem = 24
value = 1,5

[State 3150, VarSet]
type = VarSet
trigger1 = 1
var(10) = 0

[State 3100, VelAdd: Final Kick]
type = VelAdd
trigger1 = AnimElem = 23
y = -4.0

[State 3100, StateTypeSet: Air, Physics = None]
type = StateTypeSet
trigger1 = AnimElem = 23
stateType = A

[State 3100, Gravity]
type = VelAdd
trigger1 = (AnimElemTime(25) >= 1)
y = 0.5

[State 3100, Spark XY]
type = Null
trigger1 = AnimElem = 4
trigger1 = var(35) := 57 || var(36) := -59
trigger2 = AnimElem = 12
trigger2 = var(35) := 64 || var(36) := -82
trigger3 = AnimElem = 8 || AnimElem = 25
trigger3 = var(35) := 65 || var(36) := -79
trigger4 = AnimElem = 16
trigger4 = var(35) := 76 || var(36) := -63
trigger5 = AnimElem = 25
trigger5 = var(35) := 47 || var(36) := -66

[State 3100]
type = Playsnd
trigger1 = AnimELem = 3 || AnimELem = 11
value = S4, 1
[State 3100]
type = Playsnd
trigger1 = AnimELem = 15 || AnimELem = 7
value = S4, 2
[State 3100]
type = Playsnd
trigger1 = AnimELem = 19
value = S4, 3
[State 3100]
type = Playsnd
trigger1 = AnimELem = 24
value = S3100, 2


[State 3100, Hit 1]
type = HitDef
trigger1 = AnimElem = 4
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6,6
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -57, -59
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120


[State 3100, Hit 2]
type = HitDef
trigger1 = AnimElem = 8
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6,6
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -65, -79
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, Hit 3]
type = HitDef
trigger1 = AnimElem = 12
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6,6
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -66, -82
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, Hit 4]
type = HitDef
trigger1 = AnimElem = 16
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6,6
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -76, -63
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, Hit 5]
type = HitDef
trigger1 = AnimElem = 21
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6,6
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,-8.0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -65, -79
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, Final]
type = HitDef
trigger1 = AnimElem = 25
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 6, 6
guard.pauseTime = 4, 4
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4.32, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -7, -3
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 41), var(36) := -58
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(26) >= 0
moveType = I

[State 3150, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 1201

;========================<THOSAND JAGUAR FINISH>=============================
[StateDef 3151]
type = S
physics = N
moveType = A
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 1430, Voice]
type = PlaySnd
trigger1 = !Time
value = S3100, 2
channel = 0

[State 1430, End]
type = ChangeState
trigger1 = !AnimTime
value = 3152


;Looping
[StateDef 3152]
type = S
physics = N
moveType = A
anim = 3152
ctrl = 0
sprPriority = 1

[State 1431, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 1
trigger2 = AnimElem = 3
trigger3 = AnimElem = 5
trigger4 = AnimElem = 7
trigger5 = AnimElem = 9
trigger6 = AnimElem = 11
trigger7 = AnimElem = 13
trigger8 = AnimElem = 15
value = 1,2

[State 1431, VelSet]
type = VelSet
trigger1 = vel x < 0
x = 0

[State 1431, Spark XY]
type = Null
trigger1 = AnimElem = 1 || AnimElem = 9
trigger1 = var(35) := 82 || var(36) := -100
trigger2 = AnimElem = 3 || AnimElem = 11
trigger2 = var(35) := 76 || var(36) := -54
trigger3 = AnimElem = 5 || AnimElem = 13
trigger3 = var(35) := 85 || var(36) := -76
trigger4 = AnimElem = 7 || AnimElem = 15
trigger4 = var(35) := 80 || var(36) := -81

[State 1431, High]
type = HitDef
trigger1 = AnimElem = 1 || AnimElem = 9
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 18 < 7, 7, fvar(11) * 18)), 7
getPower = 0, 0
givePower = 0, 0
pauseTime = 3, 3
guard.pauseTime = 3, 3
animType = Hard
air.animType = Hard
fall.animType = Hard
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -1, -1
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -1, -1
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -82, -100
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1431, Low]
type = HitDef
trigger1 = AnimElem = 3 || AnimElem = 11
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 18 < 7, 7, fvar(11) * 18)), 7
getPower = 0, 0
givePower = 0, 0
pauseTime = 3, 3
guard.pauseTime = 3, 3
animType = Hard
air.animType = Hard
fall.animType = Hard
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -1, -1
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -1, -1
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -76, -54
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1431, Medium]
type = HitDef
trigger1 = AnimElem = 5 || AnimElem = 13
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 18 < 7, 7, fvar(11) * 18)), 7
getPower = 0, 0
givePower = 0, 0
pauseTime = 3, 3
guard.pauseTime = 3, 3
animType = Hard
air.animType = Hard
fall.animType = Hard
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -1, -1
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -1, -1
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -85, -76
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1431, Upper]
type = HitDef
trigger1 = AnimElem = 73 || AnimElem = 15
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 18 < 7, 7, fvar(11) * 18)), 7
getPower = 0, 0
givePower = 0, 0
pauseTime = 3, 3
guard.pauseTime = 3, 3
animType = Hard
air.animType = Hard
fall.animType = Hard
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -1, -1
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -1, -1
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -80, -81
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1431, End]
type = ChangeState
trigger1 = !AnimTime
value = 1402

;========================<JAGUAR ASSASSIN>=============================
[StateDef 3155]
type = S
physics = N
moveType = A
anim = 3155
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 1200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
trigger2 = AnimElemTime(5) < 0
value = SCA
time = 1

[State 1200, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4,1
channel = 0
[State 1200, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 4,2
channel = 0
[State 1200, Voice]
type = PlaySnd
trigger1 = AnimElem = 6
value = S3100,2
channel = 0

[State 1200, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 5
trigger3 = AnimElem = 7
value = 1,5
channel = 1

[State 1200, Jump Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 40,0
channel = 3

[State 1200, StateTypeSet: Air, Physics: None]
type = StateTypeSet
trigger1 = AnimElemTime(2) >= 0
stateType = A
physics = N

[State 1200, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8100
ID = 8100
name = "Tiger Kick Dust"
posType = P1
ownPal = 1

[State 1200, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 10
y = -10

[State 1200, Hit 1]
type = HitDef
trigger1 = AnimElem = 2
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 49 < 7, 7, fvar(11) * 49)), 7
;getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 0, 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -10.81
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -8.81
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 41), var(36) := -58

[State 1200, Hit 2]
type = HitDef
trigger1 = AnimElem = 5
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 42 < 7, 7, fvar(11) * 42)), 7
;getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 0, 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -8.81
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -8.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 50), var(36) := -95

[State 1200, Hit 3]
type = HitDef
trigger1 = AnimElem = 7
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 35 < 7, 7, fvar(11) * 35)), 7
;getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 0, 0
pauseTime = ifElse(var(20), 24, 24), ifElse(var(20), 24, 24)
guard.pauseTime = ifElse(var(20), 24, 24), ifElse(var(20), 24, 24)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -8.81
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -4.16, -16.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 41), var(36) := -58

[State 1200, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(10) >= 0
moveType = I

[State 0, VelSet]
type = VelSet
trigger1 = animelemtime(8) >= 2
x = 0
y = 10

[State 1300, End]
type = ChangeState
trigger1 = pos y > -vel y
trigger2 = Animelem = 10 && !movehit
value = 0
ctrl = 1

;===========================<JAGUAR AVALANCHE>===============================
[StateDef 3200]
type = S
physics = N
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
faceP2 = 1
poweradd = -1000

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 54

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
time = 1
value = SCA

[State 3200, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = 31,-65
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3200, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 54
moveTime = 50
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
value = SCA
time = 1

[State 3200, Dust Helper]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8100
ID = 8100
name = "Tiger Kick Dust"
posType = P1
ownPal = 1

[State 3200, VelSet]
type = VelSet
trigger1 = AnimElem = 3
x = 16.0
y = -10.0

[State 0, Explod]
type = Explod
trigger1 = animelem = 4
anim = 1210
pos = 42,-68
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = 8
removetime = -2
scale = 0.5,0.5
sprpriority = 1
ontop = 1
ownpal = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 3
value = S1,5
[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 4
value = S41,0

[State 3200, HitDef]
type = HitDef
trigger1 = AnimElem = 4
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 104 < 7, 7, fvar(11) * 104)), 7
getPower = 0
givePower = 36, 36
pauseTime = 6, 300
guard.pauseTime = 6, 15
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = 15
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -2.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 41), var(36) := -58
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, ChangeState]
type = ChangeState
trigger1 = frontedgebodydist = 0
value = 3205
ctrl = 0

[StateDef 3205]
type = A
physics = N
moveType = A
anim = 3205
ctrl = 0
velSet = 0,0
sprPriority = 1
faceP2 = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = p2dist x < 75 && !time
value = 3207
ctrl = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = !time
value = S2,800

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S40,0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 8
value = S1,5

[State 0, PosFreeze]
type = PosFreeze
trigger1 = !time

[State 0, Gravity]
type = Gravity
trigger1 = animelemtime(5)>=0

[State 0, VelSet X 1]
type = VelSet
trigger1 = animelemtime(2)>=0
x = p2bodydist x / 25

[State 0, VelAdd]
type = VelAdd
trigger1 = animelem = 2
y = -3

[State 0, VelAdd2]
type = VelAdd
trigger1 = animelemtime(6)>=0
y = 2

[State 0, VelSet X 2]
type = VelSet
trigger1 = p2bodydist x < 30
x = 1

[State 0, Explod]
type = Explod
trigger1 = animelem = 9
anim = 3206
pos = 48,-41
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = -1
removetime = -2
scale = 0.5,0.5
sprpriority = 1
ontop = 1
ownpal = 1

[State 1300, Hit]
type = HitDef
trigger1 = AnimElem = 9
ID = 1301
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 81 < 7, 7, fvar(11) * 81)), 7
givePower = 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
down.hitTime = 20
ground.velocity = 0, 6.57
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 6.57
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 0
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 56), var(36) := -43
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 3200, End]
type = ChangeState
trigger1 = time > 34 && pos y > -vel y
value = 3206

[StateDef 3206]
type = S
physics = N
moveType = I
velSet = 0,0
anim = 1202

[State 1201, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

[StateDef 3207]
type = A
physics = N
moveType = A
anim = 3207
ctrl = 0
velSet = 0,0
sprPriority = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = !time
value = S2,800

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S1,5

[State 0, PosFreeze]
type = PosFreeze
trigger1 = !time

[State 0, VelAdd]
type = VelAdd
trigger1 = animelemtime(3)>=0
y = 2
x = 0.5

[State 0, Explod]
type = Explod
trigger1 = animelem = 3
anim = 3206
pos = 44,-82
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = -1
removetime = -2
scale = 0.5,0.5
sprpriority = 1
ontop = 1
ownpal = 1

[State 1300, Hit]
type = HitDef
trigger1 = AnimElem = 3
ID = 3207
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 81 < 7, 7, fvar(11) * 81)), 7
givePower = 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
down.hitTime = 20
ground.velocity = 0, 6.57
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 6.57
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 0
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 48), var(36) := -83
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 3200, End]
type = ChangeState
trigger1 = time > 13 && pos y > -vel y
value = 3208

[StateDef 3208]
type = S
physics = N
moveType = I
velSet = 0,0
anim = 3208

[State 1201, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;========================<JAGUAR REVOLVER 3 LVL>=============================
[StateDef 3300]
type = S
physics = S
moveType = A
anim = 3050
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 54

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8510
name = "Superpause FX"
posType = P1
pos = 31,-65
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 54
moveTime = 50
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, JAGUAR!]
type = PlaySnd
trigger1 = !Time
value = 3000,0
channel = 0

[State 3000, REVOLVER!!!]
type = PlaySnd
trigger1 = AnimElem = 3
value = 3000,1
channel = 0

[State 3000, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
trigger2 = AnimElem = 12
trigger2 = AnimElem = 20
value = 1,5
channel = 1

[State 1300, Jumping Sound]
type = PlaySnd
trigger1 = AnimElem = 4  || AnimElem = 14  || AnimElem = 24
value = 40,0
channel = 1

[State 1300, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 5  || AnimElem = 15  || AnimElem = 25
value = 1,5
channel = 3

[State 1300, Golden Heel Sound]
type = PlaySnd
trigger1 = AnimElem = 6  || AnimElem = 16  || AnimElem = 26
value = 1300,1
channel = 4

[State 1300, StateTypeSet: Air, Physics: None]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
stateType = A
physics = N

[State 1300, Dust Helper]
type = Helper
trigger1 = AnimElem = 4  || AnimElem = 14  || AnimElem = 24
helperType = Normal
stateNo = 8100
ID = 8100
name = "Golden Heel Dust"
posType = P1
ownPal = 1

[State 1300, Golden Heel FX]
type = Explod
trigger1 = AnimElem = 5  || AnimElem = 15  || AnimElem = 25
anim = 1305
sprPriority = 3
posType = P1
bindTime = -1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1
removeOnGetHit = 1
ignoreHitPause = 0

[State 1300, First]
type = VelSet
trigger1 = AnimElem = 2
trigger1 = P2BodyDist x = [0,57]
x = 0
y = -9
[State 0, First]
type = VelSet
trigger1 = AnimElem = 6
trigger1 = P2BodyDist x = [0,57]
x = 0
y = 10

[State 1300, First]
type = VelSet
trigger1 = AnimElem = 2
trigger1 = P2BodyDist x > 57
x = 6.0
y = -9
[State 0, First]
type = VelSet
trigger1 = AnimElem = 6
trigger1 = P2BodyDist x > 57
x = 4.0
y = 10

[State 0, VelSet]
type = VelSet
trigger1 = pos y > -vel y
x = 0
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = animelem = 10 
trigger2 = pos y > -vel y
value = 3050
elem = 11
[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = animelem = 20
trigger2 = pos y > -vel y
value = 3050
elem = 21

[State 1300, Second and final]
type = VelSet
trigger1 = AnimElem = 12 || AnimElem = 22
x = 6.0
y = -4
[State 0, Second and final]
type = VelSet
trigger1 = AnimElem = 16 || AnimElem = 26
x = 4.0
y = 4

[State 1300, 1, 3 & 5 Hits]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 8 || AnimElem = 18 || AnimElem = 28
ID = 1300
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = 15, 10
getPower = 0, 0
givePower = 0, 0
pauseTime = 3, 3
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
animType = Low, Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 36
ground.slideTime = 36
guard.hitTime = 36
air.hitTime = 120
down.hitTime = 20
ground.velocity = -8, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 3.24
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 50), var(36) := -115
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1300, 2 & 4 Kick]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || (var(15) < 2 && NumTarget(1300)) || var(20))
trigger1 = AnimElem = 9 || AnimElem = 19
ID = 1301
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = 15, 10
getPower = 0, 0
givePower = 0, 0
pauseTime = 3, 3
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
animType = Low, Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 36
ground.slideTime = 36
guard.hitTime = 36
air.hitTime = 120
down.hitTime = 20
ground.velocity = -16, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 6.57
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 55), var(36) := -43
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1300, Final Kick]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || (var(15) < 2 && NumTarget(1300)) || var(20))
trigger1 = AnimElem = 29
ID = 1301
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = 15, 10
getPower = 0, 0
givePower = 0, 0
pauseTime = 3, 33
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
animType = Low, Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
down.hitTime = 20
ground.velocity = 0, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.40, 6.57
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 55), var(36) := -43
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 3000, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(30) >= 0
moveType = I

[State 1300, End]
type = ChangeState
trigger1 = pos y > -vel y
trigger2 = Animelem = 30 && !movehit
value = 1201

[State 1300, End]
type = ChangeState
trigger1 = pos y > -vel y
trigger2 = Animelem = 30 && WinKO
value = 1201

[State 1300, End]
type = ChangeState
trigger1 = pos y > -vel y
trigger2 = Animelem = 30 && movehit
value = 1202

;========================<CONNECTED>=============================
[StateDef 3350]
type = S
physics = S
moveType = A
anim = 3350
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 54

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3100, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 4
trigger3 = AnimElem = 6
trigger4 = AnimElem = 8
value = 1,2
ownpal = 1

[State 3100, VarSet]
type = VarSet
trigger1 = 1
var(10) = 0

[State 3100, VelAdd]
type = VelAdd
trigger1 = AnimELem = 1
trigger2 = AnimELem = 3
trigger3 = AnimELem = 5
trigger4 = AnimELem = 7
x = 8.0

[State 3100, Dust Helper]
type = Helper
trigger1 = AnimElem = 10
helperType = Normal
stateNo = 8100
ID = 8100
name = "Exploding Hurricane Tiger Heel Dust"
posType = P1
ownPal = 1

[State 3100, VelAdd: Final Kick]
type = VelAdd
trigger1 = AnimElem = 10
x = 15.0
y = -10.0

[State 3100, StateTypeSet: Air, Physics = None]
type = StateTypeSet
trigger1 = AnimElem = 10
stateType = A
physics = N

[State 3100, Gravity]
type = VelAdd
trigger1 = (AnimElemTime(13) >= 1)
y = 0.5

[State 3100, Spark XY]
type = Null
trigger1 = AnimElem = 2
trigger1 = var(35) := 57 || var(36) := -59
trigger2 = AnimElem = 4
trigger2 = var(35) := 65 || var(36) := -79
trigger3 = AnimElem = 6
trigger3 = var(35) := 65 || var(36) := -81
trigger4 = AnimElem = 8
trigger4 = var(35) := 65 || var(36) := -79
trigger5 = AnimElem = 12
trigger6 = var(35) := 43 || var(36) := -68

[State 3100, Right Hand Punch FX]
type = Helper
trigger1 = Animelem = 1
trigger2 = Animelem = 1
helperType = Normal
stateNo = 3106
ID = 3106
name = "Left Hand"
posType = P1
pos = 75,-87
size.xScale = 1
size.yScale = 1
[State 3100, Left Hand Punch FX]
type = Helper
trigger1 = Animelem = 3
trigger2 = Animelem = 3
helperType = Normal
stateNo = 3105
ID = 3105
name = "Right Low Hand"
posType = P1
pos = 83,-48
size.xScale = 1
size.yScale = 1
[State 3100, Right Hand Punch FX]
type = Helper
trigger1 = Animelem = 5
trigger2 = Animelem = 5
helperType = Normal
stateNo = 3105
ID = 3105
name = "Left Hand"
posType = P1
pos = 80,-51
size.xScale = 1
size.yScale = 1
[State 3100, Left Hand Punch FX]
type = Helper
trigger1 = Animelem = 7
trigger2 = Animelem = 7
helperType = Normal
stateNo = 3105
ID = 3105
name = "Right Hand"
posType = P1
pos = 80,-79
size.xScale = 1
size.yScale = 1

[State 3100]
type = Playsnd
trigger1 = AnimELem = 1
trigger2 = AnimELem = 5
value = S4, 1
[State 3100]
type = Playsnd
trigger1 = AnimELem = 3
value = S4, 2
[State 3100]
type = Playsnd
trigger1 = AnimELem = 7
value = S4, 3
[State 3100]
type = Playsnd
trigger1 = AnimELem = 10
value = S3100, 2

[State 3100, Hit 1]
type = HitDef
trigger1 = AnimElem = 2
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 0, 36
pauseTime = 11, 11
guard.pauseTime = 11, 11
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -65, -79
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3100, Hit 2]
type = HitDef
trigger1 = AnimElem = 4
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 0, 36
pauseTime = 11, 11
guard.pauseTime = 11, 11
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -57, -59
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3100, 3]
type = HitDef
trigger1 = AnimElem = 6
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 0, 36
pauseTime = 11, 11
guard.pauseTime = 11, 11
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -65, -81
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3100, Hit 4]
type = HitDef
trigger1 = AnimElem = 8
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 0, 36
pauseTime = 11, 11
guard.pauseTime = 11, 11
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.0,-13.0
ground.cornerPush.velOff = 0
guard.velocity = -3.0
guard.cornerPush.velOff = 0
air.velocity = -4.32, -7.49
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -65, -79
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0

[State 3100, Final]
type = HitDef
trigger1 = AnimElem = 12
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getPower = 0,0
givePower = 0, 36
pauseTime = 25, 25
guard.pauseTime = 25, 25
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4.32, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -7, -7
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 41), var(36) := -58
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(13) >= 0
moveType = I

[State 3100, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 1201

;--------------------------Jaguar Avalanche-------------------------------------------
[Statedef 3400]
type = S
movetype = A
physics = N
juggle   = 3
ctrl = 0
velset = 0,0
sprpriority = 2
velset = 0,0
anim = 3400
powerAdd = -3000
faceP2 = 1

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 54

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(7) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8520
ID = 8520
name = "Superpause FX"
posType = P1
pos = 1,-65
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 1300, Golden Heel FX]
type = Explod
trigger1 = AnimElem = 12
anim = 1306
sprPriority = 3
posType = P1
bindTime = -1
scale = 0.45,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1
removeOnGetHit = 1
ignoreHitPause = 0

[State 3, ???]
type = PlaySnd
trigger1 = animelem = 1
value = 3100,0
channel = 0

[State 3, ???]
type = PlaySnd
trigger1 = animelem = 4
value = 3100,1
channel = 0

[State 450, ?????]
type = PlaySnd
trigger1 = animelem = 3
value = 41, 0

[State 450, ?????]
type = PlaySnd
trigger1 = animelem = 4
value = 1200, 1

[State 450, ?????]
type = PlaySnd
trigger1 = animelem = 11
value = 1300, 1

[State 230, ?????]
type = HitDef
trigger1 = animelem = 4||animelem = 6
attr = A, SA
animtype  = hard
ground.type = High
damage    = 100,8
guardflag = M
pausetime = 6,6
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 50), var(36) := -85
ground.slidetime = 15
ground.hittime  = 15
ground.velocity = -4,-10
air.velocity = -2,-7
envshake.time = 10
envshake.freq = 5
envshake.ampl = 5
envshake.phase = 5
fall = 1
air.fall= 1
fall.recover = 0
getpower = 0
givepower = 20
forcestand = 1
kill = 0
id=3402

[State 230, ?????]
type = HitDef
trigger1 = animelem=12&& NumTarget(3402)
attr = A, HA
animtype  = hard
ground.type = High
damage    = 100,10
guardflag = M
pausetime = 10,10
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 50), var(36) := -85
ground.slidetime = 15
ground.hittime  = 18
ground.velocity = -10,20
air.velocity = -4,20
envshake.time = 10
envshake.freq = 5
envshake.ampl = 5
envshake.phase = 5
getpower = 0
givepower = 20
fall = 1
air.fall= 1
fall.recover = 0
id=3401
kill = 0

[State 230, ?????]
type = HitDef
trigger1 = animelem=12&& !NumTarget(3402)
attr = A, HA
animtype  = hard
ground.type = High
damage    = 100,10
guardflag = M
pausetime = 10,10
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 50), var(36) := -85
ground.slidetime = 15
ground.hittime  = 18
ground.velocity = -10,20
air.velocity = -4,20
envshake.time = 10
envshake.freq = 5
envshake.ampl = 5
envshake.phase = 5
getpower = 0
givepower = 20
fall = 1
air.fall= 1
fall.recover = 0
kill = 1

[State 0, p2state]
type=targetstate
trigger1= movehit && numtarget(3401)
trigger1= target(3401),Movetype=H
ID=3401
value=3425
ignorehitpause=1
[State 0, p1state]
type=changestate
trigger1= movehit && numtarget(3401)
trigger1= target(3401),Movetype=H
value=3420
ignorehitpause=1

[state 3];????
type = StatetypeSet
triggerall = statetype != A
trigger1 = Animelem = 4
value = A

[State 4];??????
type = VelSet
trigger1 = Animelem = 4
x =  6
y =  -8

[State 4];??????
type = VelSet
trigger1 = Animelem = 6
x =  0

[State 4];??????
type = VelSet
trigger1 = Animelem = 7
x =  4
y = -6

[State 5];??????????????
type = gravity
trigger1 = Animelem = 4,>= 0

[State 7];??state???
type = ChangeState
trigger1 = Animelem = 13,>= 0
trigger1 = Vel Y > 0 && Pos Y >= 0
value = 3410

;---------------
[Statedef 3410]
type    = S
physics = S
ctrl = 0
anim = 3410
velset = 0,0

[State 52, 2]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3000,00]
type = Palfx
trigger1 = AnimTime = 0
time = 1

[State 450, ?????]
type = PlaySnd
trigger1 = animelem = 1
value = 52, 0

[State 1011, ??]
type = AfterImage
trigger1 = AnimTime = 0
time = 1
trans = add

[State 52, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;-------------------
[Statedef 3420]
type     = A
movetype = A
physics  = N
anim = 3420
VelSet = 0,0
sprpriority = -3

[State 0, p1state]
type=removeexplod
trigger1= time=1

[State 1000, 3]
type = VelSet
trigger1 = time = 0
x = 3
y = -4

[State 5];??????????????
type = gravity
trigger1 = animelem = 5,<= 0

[State 1000, 3]
type = VelSet
trigger1 = animelem = 5
x = 0
y = 0

[State 3, ???]
type = PlaySnd
trigger1 = animelem = 5
value = 3100,3
channel = 0

[State 810, ??]
type = Width
trigger1 = time = 0
value = 64,64

[State 810,***]
type = TargetState
trigger1 = animelem = 5
value = 3425

[State 810, ????????]
type = TargetBind
trigger1 = animelem = 5
pos = ceil(0*const(size.xscale)),ceil(-60*const(size.yscale))
postype = P1
time = -1

[State -2, ?????]
type = PlaySnd
trigger1 = Anim = 3420
trigger1 = AnimElem = 5
value = 1, 4
ignorehitpause = 1

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 5
time = 10
freq = 60
ampl = -14
phase = 90
ignorehitpause = 1

[State 831, Hit Spark]
type = Helper
trigger1 = Anim = 3420
trigger1 = AnimElem = 10||AnimElem = 15
helperType = Normal
stateNo = 8014
ID = 8000
name = "Spark"
posType = P1
pos = ceil(10 * const(size.xScale)), ceil(-40 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State -2, ?????]
type = PlaySnd
trigger1 = Anim = 3420
trigger1 = AnimElem = 10||AnimElem = 15
value = 2, 2
ignorehitpause = 1

[State -2, 3]
type = EnvShake
trigger1 = Anim = 3420
trigger1 = AnimElem = 10||AnimElem = 15
time = 10
freq = 60
ampl = -14
phase = 90
ignorehitpause = 1

[State 5120, 4]
type = HitAdd
trigger1 = Anim = 3420
trigger1 = AnimElem = 10||AnimElem = 15
value = 1

[State -2, ??????????????]
type = TargetLifeAdd
trigger1 = Anim = 3420
trigger1 = AnimElem = 10||AnimElem = 15
value = Ceil(-20*fvar(10)*(const(data.attack)*0.01))
kill = 0

[State 5050, 6]
type = ChangeState
trigger1 = time >= 97
trigger1 = AnimElem = 11
value = 3421
;-------------------
[Statedef 3421]
type     = A
movetype = A
physics  = N
anim = 3421
VelSet = 0,0

[State -2, ?????]
type = PlaySnd
trigger1 = AnimElem = 7
value = 41, 0

[State 3, ???]
type = PlaySnd
trigger1 = time = 0
value = 3100,4
channel = 0

[State 810, ????????????]
type = TargetState
Trigger1 = AnimElem = 1
value = 3426

[State 810, ????????????]
type = TargetState
Trigger1 = AnimElem = 7
value = 3427

[State 810, ????????]
type = TargetBind
trigger1 = AnimElem =1
pos = ceil(-30*const(size.xscale)),ceil(-50*const(size.yscale))
postype = P1
time = -1

[State 810, ????????]
type = TargetBind
trigger1 = AnimElem =2
pos = ceil(-20*const(size.xscale)),ceil(-90*const(size.yscale))
postype = P1
time = -1

[State 810, ????????]
type = TargetBind
trigger1 = AnimElem =3
pos = ceil(-10*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, ????????]
type = TargetBind
trigger1 = AnimElem =4
pos = ceil(20*const(size.xscale)),ceil(-80*const(size.yscale))
postype = P1
time = -1

[State 810, ????????]
type = TargetBind
trigger1 = AnimElem =5
pos = ceil(20*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, ????????]
type = TargetBind
trigger1 = AnimElem =6
pos = ceil(20*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, ????????]
type = TargetBind
trigger1 = AnimElem =7
pos = ceil(0*const(size.xscale)),ceil(-50*const(size.yscale))
postype = P1
time = 1

[State 1000, 3]
type = VelSet
trigger1 =FrontEdgeBodyDist >= 120
trigger1 = animelem = 1
x = 3
y = -4

[State 1000, 3]
type = VelSet
trigger1 =FrontEdgeBodyDist < 120
trigger1 = animelem = 1
x = -3
y = -4

[State 5];??????????????
type = gravity
trigger1 = Animelem = 1,>= 0


[State 1000, 3]
type = VelSet
trigger1 = animelem = 8
x = 0
y = -28

[State 5];??????????????
type = veladd
trigger1 = AnimElemtime(8) > 0
y = 1

[State 5050, 6]
type = ChangeState
trigger1 = Vel Y > 0&&Pos Y > 0
value = 3422

[State 10000, ??]
type = ScreenBound
trigger1 = 1
movecamera = 0,0
;-------------------
;???????
[Statedef 3422]
type     = A
movetype = A
physics  = N
anim = 3422
VelSet = 0,0

[State 810, ]
type = posset
trigger1=AnimElem = 1
y = 0

[State 810, ????????????]
type = TargetState
Trigger1 = AnimElem = 2
value = 3429

[State 810, ????????]
type = TargetBind
trigger1 = AnimElem =1
pos = ceil(0*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = 1

[State 5120, 4]
type = HitAdd
trigger1 = AnimElem = 1
value = 1

[State 810, ??????????????]
type = TargetLifeAdd
trigger1 = AnimElem = 1
value = Ceil(-40*fvar(10)*(const(data.attack)*0.01))

[State -2, ?????]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1300, 1
ignorehitpause = 1

[State -2, ?????]
type = PlaySnd
trigger1 = AnimElem = 1
value = 2, 5
ignorehitpause = 1

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 1
time = 30
freq = 120
ampl = -23
phase = 180
ignorehitpause = 1

[State 831, Hit Spark]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8014
ID = 8000
name = "Spark"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(0 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1000, 3]
type = VelSet
trigger1 = animelem = 2
x = -3
y = -10

[State 5];??????????????
type = gravity
trigger1 = AnimElemtime(2) > 0

[State 5050, 6]
type = ChangeState
trigger1 = Vel Y > 0&&Pos Y > 0
value = 52
;------------
;?????????????1(???????)
[Statedef 3425]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2

[State 811, ????????????]
type = ChangeAnim2
Trigger1 = time = 0
value = 3425

[State 10000, ??]
type = ScreenBound
trigger1 = 1
movecamera = 0,0
;------------
;?????????????1(???????)
[Statedef 3426]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2

[State 811, ????????????]
type = ChangeAnim2
Trigger1 = time = 0
value = 3426

[State 10000, ??]
type = ScreenBound
trigger1 = 1
movecamera = 0,0
;-----------------
; ?????????????3(???????)
[Statedef 3427]
type     = L
movetype = H
physics  = N

[State 1000, 3]
type = VelSet
trigger1 = 1
y = 15

[State 5050, 6]
type = ChangeState
trigger1 = Vel Y > 0&&Pos Y > 0
value = 3428
;-----------------
; ?????????????3(???????)
[Statedef 3428]
type     = L
movetype = H
physics  = N
velset = 0,0

[State 811, ????????????]
type = ChangeAnim
Trigger1 = time = 0
value = 5100

[State 811, ????????????]
type = ChangeAnim
Trigger1 = anim = 5100 && animtime = 0
value = 5110

[State 810, ]
type = posset
trigger1=AnimElem = 1
y = 0

;-----------------
; ?????????????3(???????)
[Statedef 3429]
type     = L
movetype = H
physics  = N

[State 810, ]
type = posset
trigger1=AnimElem = 1
y = 0

[State 1000, 3]
type = VelSet
trigger1=time = 0
x =-3
y =-2

[State 811, ????????????]
type = ChangeAnim
Trigger1 = time = 0
value = 5050

[state 821,self]
type = selfstate
Trigger1 = time = 5
value = 5050
