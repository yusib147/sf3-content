                            __________________________________________
===========================| Angel by KarmaCharmeleon		      |===========================
                            ������������������������������������������        [01.01.2022]

 - Contact:	karmacharmander@gmail.com
 - Website:	https://www.imdb.com/title/tt0367279/
 - Customized version of SNK's Angel character, for MUGEN 1.0



=====<Features>=====

 - All the essential stuff
 - Details and moves taken from her various video game appearances
 - Gameplay mixed from several games, including CvS2, KOF, SFA3 and SFIII
 - Special intros versus K9999, and Kula Diamond



=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>
     
.Senseless Chatter 			F + b
.At Wasteland 				D + b           	(Air)
.Go Go Futen Girl!	         	F/B + 2p		(near opponent)
.Starlit Field				F/B + 2k		(near opponent)
     
     
<SPECIAL>
     
.Red Sky of Yaponesia (EX)		F, DF, D, DB, B, k
.Mad Murder Roulette (EX)         	B, D, DB, k

<UNCHAINED CIRCLE STARTERS>
.Formalist's Blue 			DF + a
.Citizens of the World 			DF + c
.Senseless Fists 			B, F, k
.Reppun Kamui				D, DB, B, p
.Beyond Frames				B, DB, D, DF, F, k

<UNCHAINED CIRCLE LINKS>
.Bye Bye Rouge 				U + p
.Shelter from Storm 			U + k
.Buggy and Coffin			F + p
.With a Lamp for Pathway		F + k
.Train to See Cherry Blossoms		D + p
.Impotent Symptom			D + k

<UNCHAINED CIRCLE SPECIAL>
.Omogatoki	 			B/F + p + k

<UNCHAINED CIRCLE FINISHERS>
.Crown Under Sky 			F, F, x
.Fullmoon Evening 			F, F, z
.State of Heat Haze 			F, F, k
.Cosmic Futen Swing 			D, DF, F, x
.Lost Homeland	 			D, DF, F, z
.Beyond Frames				B, DB, D, DF, F, k

<SUPER>
     
.Loyalty Test for Liberalists (MAX)	B, F, D, DF, p
.Winds Fairground			B, F, D, DF, k		(counters ground moves)
.Blue Monday Parade			B, F, D, DF, k		(counters air moves)


<Lv3 SUPER>

.Survivor's Banquet              	D, D, D, p + k


<SYSTEM>

.Forward Dash:                  	F, F
   .Run:                       			hold
.Backward Dash:                 	B, B
.Low Jump:                     		tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	a + x
   .Sidestep Attack:            		p / k
.Forward Roll:                  	F + a + x
.Backward Roll:                 	B + a + x
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold b + y
.Zero Counter:                  	B, DB, D, p / k		(during standing or crouching guard)
.Custom Combo:                  	c + z           	(Air also)
.Fall Recovery:                 	2p / a + x      	(while falling and allowed)



=====<Move Details>=====

 - Red Sky of Yaponesia has a small window of invincibility during active frames.
 - EX Red Sky of Yaponesia has full invincibility during startup and active frames.
 - EX Mad Murder Roulette has full invincibility during startup.
 - Mad Murder Roulette, Bye Bye Rouge, Shelter from Storm and Crown Under Sky can all be juggled afterwards with any attack;
   however, this can only be done once per combo.
 - Formalist's Blue, Train to See Cherry Blossoms, and Impotent Symptom are all low attacks.
 - Citizens of the World, Buggy and Coffin, With a Lamp for Pathway, and State of Heat Haze are all overhead attacks.
 - Mad Murder Roulette, Cosmic Futen Swing, and Lost Homeland are all command grabs.
 - Fullmoon Evening is unblockable. 
 - Omogatoki has a small window of invincibility during the twirl.
 - Winds Fairground and Blue Monday Parade are reversals performed with the same command:
   - When you counter ground attack, Winds Fairground comes out.
   - When you counter air attacks, Blue Monday Parade comes out.
 - Survivor's Banquet hits only OTG.

UNCHAINED CIRCLE SYSTEM:
Angel has her own sub-system of special moves, with four types of Unchain Circle moves:

 * Starters
 * Links
 * Specials
 * Finishers

 - Starters are the only ones that can be performed in neutral. They can be canceled into Links.
 - Links can only be used after Starters or other Links. They can be canceled into Finishers or other Links.
 - When canceling a Link into a Link, you can't use neither the same direction or input that the current one.
   Example: if you perform Bye Bye Rouge (U + p), you can't go into none of the Links performed with U or p.
 - Specials can only be used after Links. They can be canceled into Finishers.
 - Finishers can only be used after Links or Specials.
 - Beyond Frames is both an Unchained Circle Starter and an Unchained Circle Finisher.


=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Command, Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start



=====<Version History>=====

<v.01/01/22>
 - Visual tweaks here and there.
 - All her overheads ware nerfed, having longer startup.
 - Angel is able to command cancel from far and crouching normals back again.
 - Senseless Chatter has longer startup and longer recovery.

<v.04/12/21>
 - Minor bugfixes.

<v.30/11/21>
 - Added Color Separation made by KoFHERO77.
 - Tweaks and minor bugfixes.
 - Angel is not able to command cancel from far and crouching normals anymore.
 - Angel can't combo into command grabs anymore.

<v.06/06/21>
 - Fixed typos on the ReadMe.
 - Visual tweaks all around.
 - Angel won't sink in the ground anymore when command grabing shorter characters.
 - Survivor's Banquet impact hitsound now plays correctly.
 - Survivor's Banquet command changed to D, D, D, p + k.

<v.04/06/21>
 - First release.


=====<Special Thanks>=====
 - Everyone's Kouhai for commissioning
 - P.o.t.S. and Jmorphman for code, effects, hitsparks, formatting style
 - dampir for sprites, KoFHERO77 for Color Separation, FeLo for small edits
 - Xenocomic for the Midnight Bliss base sprite
 - Mysticus for sounds rips
 - Vans for the ArtMoney table
 - Basara, Devon, Everyone's Kouhai, KamuiKanjai, KoFHERO77, Lurker, masterkof, MCX,
   Nedflandeurse, PR�JECT.13, ShiroTori SkyDragonSliferEX and Vocalnoid for palettes
 - Everybody at the MUGEN Fighters Guild for feedback


=====<Disclaimer>=====

 - The Angel character is property of SNK
 - Capcom vs SNK is property of Capcom
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes