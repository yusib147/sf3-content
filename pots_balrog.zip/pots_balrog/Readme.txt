                            _______________________________________
===========================|           Balrog by Trololo           |===========================
                            ���������������������������������������           [17.07.19]

 - Contact:	MFG or Discord
 - Website:	http://troshack.blogspot.ru/

 - Customized version of Capcom's Balrog character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, including CvS2, KOF, SFZ3 and SF3

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks        3k- three kicks 

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>

.Sandbag Throw:                         F/B + 2p   (near opponent)
.Headbutt:                      	F/B + 2k   (near opponent)
.Air Headbutt:                          F/B + 2p   (Air, near opponent)


<SPECIAL>

.Dash Straight (EX):                 	(charge) B, F, p
.Dash Ground Straight (EX):             (charge) B, DF, p
    .Dash Swing Blow:       	        hold p
.Dash Uppercut (EX):                 	(charge) B, F, k
.Dash Ground Uppercut (EX):             (charge) B, DF, k
.Buffalo Head (EX):                 	(charge) D, U, p
.Screw Smash (EX):                 	(charge) D, U, k
.Turn Punch:                 	        Hold 2 Punch or Kick Buttons, then release


<SUPER>
       
.Crazy Buffalo (MAX):                 	(charge) B, F, B, F, p
.Ultimate Screw Smash (MAX Only):       D, DF, F, D, DF, F, 2k


<LV3 SUPER>

.Gigaton Blow:                          (charge) B, F, B, F, 2k


<SYSTEM>

.Forward Dash:                    	F, F
   .Run:                           	hold
.Backward Dash:                    	B, B
.Low Jump:                         	tap U
.High Jump:                        	tap D, U
.Long Low Jump:                    	tap D, tap U            
.Sidestep:                         	a + x
   .Sidestep Attack:               	p / k
.Forward Roll:                     	F + a + x
.Backward Roll:                    	B + a + x
.Parry High:                       	tap F
.Parry Low:                        	tap D
.Air Parry:                        	tap F           		(Air)
.Power Charge:                     	hold b+y
.Zero Counter:                     	B, DB, D, p / k 		(during standing or crouching guard)
.Custom Combo:                     	c + z           		(Air also)
.Fall Recovery:                    	2p / a + x      		(while falling and allowed)



=====<Move Details>=====

 - During Headbutt, you can mash buttons to increase the number of hits.
 - Dash Ground Straight must be blocked low.
 - Dash Swing Blow is overhead.
 - The longer you hold the buttons for Turn Punch, the stronger will move come out.
 - During Crazy Buffalo, you can alternate between Straight punches and Uppercuts by holding a kick button.

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage


CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing
   faster and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

=====<Miscellaneous>=====

- To change his voice to use "Street Fighter Alpha" or "SNK vs Capcom" voices, open the .def file and replace
  "SoundCvS.snd" with "SoundSFA.snd" or "SoundSvC.snd" respectively. To bring Capcom vs SNK voices back bring back
  "SoundCvS.snd".

=====<Special Thanks>=====
 - Jesuszilla and N-Mario for creating their Balrog I took a lot from.
 - KOFHERO77 for making that CS that got me motivated to finally update the guy.
 - SeanAltly for making custom Screw Smash sprites.
 - 2Dee4Ever for helping me out with Screw Smash sprites CS before KOFHERO77's Patch.
 - Knuckles8864 for the hyper portrait
 - Capcom for making original character

=====<Disclaimer>=====

 - The Balrog character is property of Capcom
 - Street Fighter is property of Capcom
 - This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes