; _______________________________________________
;|               Balrog by Trololo               |
; �����������������������������������������������
;==============================================================================================
;========================================<SPECIAL MOVES>=======================================
;==============================================================================================
;========================<DASH STRAIGHT>=============================
[StateDef 1000]
type = S
physics = N
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse(P2Dist x > 240, 2, ifElse((p2Dist x > 210 && P2Dist x <= 240), 1, 0))

[State 1000, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1020, ifElse(var(10) = 1, 1010, 1000))

[State 1000, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1000,1
channel = 2

[State 1000, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 10

[State 1000, Early Attack]
type = ChangeAnim
triggerall = AnimElemTime(2)>=0 && AnimElemTime(3)<0
trigger1 = P2BodyDist X <= 30
value = ifElse(var(10) = 2, 1020, ifElse(var(10) = 1, 1010, 1000))
elem = 3

[State 1000, Physics Returns]
type = StateTypeSet
trigger1 = AnimElem = 3
statetype = S
movetype = A
physics = S

[State 1000, Voice (SFA)]
type = PlaySnd
trigger1 = !Time
value = 1000,0
channel = 0

[State 1000, Voice (CvS/SvC)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1000,2
channel = 0

[State 1000, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 98 < 7, 7, fvar(11) * 98)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.07, -8.13), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.07, -8.13)
guard.cornerPush.velOff = 0
air.velocity = -4, -4.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<EX DASH STRAIGHT>=============================
[StateDef 1030]
type = S
physics = N
moveType = A
anim = 1030
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 35

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = 30 * const(size.xscale),-89 * const(size.yscale)
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1000, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1030, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1000,1
channel = 2

[State 1030, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 12.5

[State 1030, Early Attack]
type = ChangeAnim
triggerall = AnimElemTime(2)>=0 && AnimElemTime(3)<0
trigger1 = P2BodyDist X <= 30
value = 1030
elem = 3

[State 1030, Physics Returns]
type = StateTypeSet
trigger1 = AnimElem = 3
statetype = S
movetype = A
physics = S

[State 1030, Voice (SFA)]
type = PlaySnd
trigger1 = !Time
value = 1000,0
channel = 0

[State 1030, Voice (CvS/SvC)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1000,2
channel = 0

[State 1030, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 1030, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 108 < 7, 7, fvar(11) * 108)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 21 + 4 * var(9)
ground.slideTime = 21 + 4 * var(9)
guard.hitTime = 21
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -4.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1030, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 1030, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<DASH GROUND STRAIGHT>=============================
[StateDef 1100]
type = S
physics = N
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse(P2Dist x > 230, 2, ifElse((p2Dist x > 200 && P2Dist x <= 230), 1, 0))

[State 1100, Dash Swing Blow Modifier]
type = Explod
trigger1 = !time
anim = 1
ID = 1150
bindtime = 99999
removeongethit = 1

[State 1100, Dash Swing Blow Blocker (Player)]
type = RemoveExplod
triggerall = !AILevel
trigger1 = (!var(10) && command != "holdx")||(var(10)=1 && command != "holdy")||(var(10)=2 && command != "holdz")
trigger2 = AnimElemTime(3)>0
id = 1150

[State 1100, Dash Swing Blow Blocker (AI)]
type = RemoveExplod
triggerall = AILevel
trigger1 = Enemy,StateType != C
trigger2 = var(20)
id = 1150

[State 1100, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1120, ifElse(var(10) = 1, 1110, 1100))

[State 1100, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1100, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1100,1
channel = 2

[State 1100, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 10

[State 1100, Dash Swing Blow]
type = ChangeState
triggerall = NumExplod(1150)
trigger1 = AnimElemTime(3)=0
trigger2 = (AnimElemTime(2)>=0 && AnimElemTime(3)<0) && P2BodyDist X <= 30
value = 1150

[State 1100, Early Attack]
type = ChangeAnim
triggerall = AnimElemTime(2)>=0 && AnimElemTime(3)<0
trigger1 = P2BodyDist X <= 30
value = ifElse(var(10) = 2, 1120, ifElse(var(10) = 1, 1110, 1100))
elem = 3

[State 1100, Physics Returns]
type = StateTypeSet
trigger1 = AnimElem = 3
statetype = S
movetype = A
physics = S

[State 1100, Voice (SFA)]
type = PlaySnd
trigger1 = !Time
value = 1100,0
channel = 0

[State 1100, Voice (CvS/SvC)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1100,2
channel = 0

[State 1100, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 1100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = C, SA
hitFlag = MAF
guardFlag = L
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 88 < 7, 7, fvar(11) * 88)), 7
getpower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givepower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Trip
air.type = Trip
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -1, -5.38
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.07, -8.13)
guard.cornerPush.velOff = 0
air.velocity = -1, -5.38
air.cornerPush.velOff = 0
yAccel = 0.677
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 112), var(36) := -13
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 1100, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<EX DASH GROUND STRAIGHT>=============================
[StateDef 1130]
type = S
physics = N
moveType = A
anim = 1130
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1130, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1130, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1130, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 35

[State 1130, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = 30 * const(size.xscale),-89 * const(size.yscale)
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1130, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1130, Dash Swing Blow Modifier]
type = Explod
trigger1 = !time
anim = 1
ID = 1150
bindtime = 99999
removeongethit = 1

[State 1130, Dash Swing Blow Blocker (Player)]
type = RemoveExplod
triggerall = !AILevel
trigger1 = ((command != "holdz" && command != "holdy")||(command != "holdx" && command != "holdz") || (command != "holdy" && command != "holdz"))
trigger2 = AnimElemTime(3)>0
id = 1150

[State 1130, Dash Swing Blow Blocker (AI)]
type = RemoveExplod
triggerall = AILevel
trigger1 = Enemy,StateType != C
trigger2 = var(20)
id = 1150

[State 1130, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1130, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1100,1
channel = 2

[State 1130, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 12.5

[State 1100, Dash Swing Blow]
type = ChangeState
triggerall = NumExplod(1150)
trigger1 = AnimElemTime(3)=0
trigger2 = (AnimElemTime(2)>=0 && AnimElemTime(3)<0) && P2BodyDist X <= 30
value = 1150

[State 1130, Early Attack]
type = ChangeAnim
triggerall = AnimElemTime(2)>=0 && AnimElemTime(3)<0
trigger1 = P2BodyDist X <= 30
value = 1130
elem = 3

[State 1130, Physics Returns]
type = StateTypeSet
trigger1 = AnimElem = 3
statetype = S
movetype = A
physics = S

[State 1130, Voice (SFA)]
type = PlaySnd
trigger1 = !Time
value = 1100,0
channel = 0

[State 1130, Voice (CvS/SvC)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1100,2
channel = 0

[State 1130, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 1130, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = C, SA
hitFlag = MAF
guardFlag = L
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 108 < 7, 7, fvar(11) * 108)), 7
getpower = 0, 0
givepower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Trip
air.type = Trip
ground.hitTime = 21 + 4 * var(9)
ground.slideTime = 21 + 4 * var(9)
guard.hitTime = 21
air.hitTime = 120
ground.velocity = -1.25, -5.58
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -1.25, -5.58
air.cornerPush.velOff = 0
yAccel = 0.677
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 112), var(36) := -13
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 1130, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<DASH SWING BLOW>=============================
[StateDef 1150]
type = S
physics = S
moveType = A
anim = 1150
ctrl = 0
sprPriority = 1
powerAdd = 0
facep2 = 1

[State 1100, Dash Swin Blow Midifier Reset]
type = RemoveExplod
trigger1 = !time
id = 1150

[State 1150, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1150, 2
channel = 0

[State 1150, Woosh]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,2
channel = 1

[State 1150, HitDef: Normal]
type = HitDef
triggerall = PrevStateNo = 1100
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 4
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = H
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 105 < 7, 7, fvar(11) * 105)), 0
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.07, -8.13), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.07, -8.13)
guard.cornerPush.velOff = 0
air.velocity = -6, -3.68
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 84), var(36) := -34
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1180, HitDef: EX Version]
type = HitDef
triggerall = PrevStateNo = 1130
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 4
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = H
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 120 < 7, 7, fvar(11) * 120)), 0
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 21 + 4 * var(9)
ground.slideTime = 21 + 4 * var(9)
guard.hitTime = 21
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -3.68
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 84), var(36) := -34
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1150, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(5) >= 0
movetype = I

[State 1150, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<DASH UPPERCUT>=============================
[StateDef 1200]
type = S
physics = N
moveType = A
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1200, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "c" || command = "rlsc"), 2, ifElse((command = "b" || command = "rlsb"), 1, 0))

[State 1200, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse(P2Dist x > 160, 2, ifElse((p2Dist x > 130 && P2Dist x <= 160), 1, 0))

[State 1200, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1220, ifElse(var(10) = 1, 1210, 1200))

[State 1200, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1200, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1200,1
channel = 2

[State 1200, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 10

[State 1200, Early Attack]
type = ChangeAnim
triggerall = AnimElemTime(2)>=0 && AnimElemTime(3)<0
trigger1 = P2BodyDist X <= 30
value = ifElse(var(10) = 2, 1220, ifElse(var(10) = 1, 1210, 1200))
elem = 3

[State 1200, Physics Returns]
type = StateTypeSet
trigger1 = AnimElem = 3
statetype = S
movetype = A
physics = S

[State 1200, Voice (SFA)]
type = PlaySnd
trigger1 = !Time
value = 1200,0
channel = 0

[State 1200, Voice (CvS/SvC)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1200,2
channel = 0

[State 1200, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 1200, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 108 < 7, 7, fvar(11) * 108)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = ifElse(var(20), -4.07, -8.13), 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -4.07, -8.13)
guard.cornerPush.velOff = 0
air.velocity = -4, -4.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 52), var(36) := -102
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1200, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 1200, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<EX DASH UPPERCUT>=============================
[StateDef 1230]
type = S
physics = N
moveType = A
anim = 1230
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1230, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1230, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1230, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 35

[State 1230, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = 43 * const(size.xscale),-84 * const(size.yscale)
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1230, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1230, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1230, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1200,1
channel = 2

[State 1230, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 12.5

[State 1230, Early Attack]
type = ChangeAnim
triggerall = AnimElemTime(2)>=0 && AnimElemTime(3)<0
trigger1 = P2BodyDist X <= 30
value = 1230
elem = 3

[State 1230, Physics Returns]
type = StateTypeSet
trigger1 = AnimElem = 3
statetype = S
movetype = A
physics = S

[State 1230, Voice (SFA)]
type = PlaySnd
trigger1 = !Time
value = 1200,0
channel = 0

[State 1230, Voice (CvS/SvC)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1200,2
channel = 0

[State 1230, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 1230, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 6 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 118 < 7, 7, fvar(11) * 118)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 21 + 4 * var(9)
ground.slideTime = 21 + 4 * var(9)
guard.hitTime = 21
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -4.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 52), var(36) := -102
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1230, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 1230, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<DASH GROUND UPPERCUT>=============================
[StateDef 1300]
type = S
physics = N
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1300, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "c" || command = "rlsc"), 2, ifElse((command = "b" || command = "rlsb"), 1, 0))

[State 1300, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse(P2Dist x > 160, 2, ifElse((p2Dist x > 130 && P2Dist x <= 160), 1, 0))

[State 1300, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1320, ifElse(var(10) = 1, 1310, 1300))

[State 1300, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1300, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1300,1
channel = 2

[State 1300, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 10

[State 1300, Early Attack]
type = ChangeAnim
triggerall = AnimElemTime(2)>=0 && AnimElemTime(3)<0
trigger1 = P2BodyDist X <= 30
value = ifElse(var(10) = 2, 1320, ifElse(var(10) = 1, 1310, 1300))
elem = 3

[State 1300, Physics Returns]
type = StateTypeSet
trigger1 = AnimElem = 3
statetype = S
movetype = A
physics = S

[State 1300, Voice (SFA)]
type = PlaySnd
trigger1 = !Time
value = 1300,0
channel = 0

[State 1300, Voice (CvS/SvC)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1300,2
channel = 0

[State 1300, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 1300, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 88 < 7, 7, fvar(11) * 88)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6.5, -4.5
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -3.68
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 70), var(36) := -105
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1300, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 1300, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1


;========================<EX DASH GROUND UPPERCUT>=============================
[StateDef 1330]
type = S
physics = N
moveType = A
anim = 1330
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1330, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1330, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1330, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 35

[State 1330, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = 43 * const(size.xscale),-84 * const(size.yscale)
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1330, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1330, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1330, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1300,1
channel = 2

[State 1330, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = 12.5

[State 1330, Early Attack]
type = ChangeAnim
triggerall = AnimElemTime(2)>=0 && AnimElemTime(3)<0
trigger1 = P2BodyDist X <= 30
value = 1330
elem = 3

[State 1330, Physics Returns]
type = StateTypeSet
trigger1 = AnimElem = 3
statetype = S
movetype = A
physics = S

[State 1300, Voice (SFA)]
type = PlaySnd
trigger1 = !Time
value = 1300,0
channel = 0

[State 1330, Voice (CvS/SvC)]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1300,2
channel = 0

[State 1330, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 1330, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 6 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 98 < 7, 7, fvar(11) * 98)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 21 + 4 * var(9)
ground.slideTime = 21 + 4 * var(9)
guard.hitTime = 21
air.hitTime = 120
ground.velocity = -3.5, -10
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4.68, -6.5
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 70), var(36) := -102
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1330, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(6) >= 0
movetype = I

[State 1330, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1


;========================<BUFFALO HEAD>=============================
[StateDef 1400]
type = S
physics = N
moveType = A
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1400, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1400, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse(P2BodyDist x > 120, 2, ifElse(P2BodyDist x > 100, 1, 0))

[State 1400, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1420, ifElse(var(10) = 1, 1410, 1400))

[State 1400, Dust Helper]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1400, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1400,0
channel = 0

[State 1400, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1400,1
channel = 1

[State 1400, VelSet]
type = VelSet
trigger1 = AnimElemTime(3) = 0
x = ifelse(var(10)=2, 13.125, ifelse(var(10)=1, 10.625, 8.125))
y = -12

[State 1400, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(3) > 1
y = 1.125

[State 1000, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElemTime(3) = 0
statetype = A

[State 1400, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * (98 + (var(10) * 7)) < 7, 7, fvar(11) * (98 + (var(10) * 7)))), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = DiagUp
air.animType = DiagUp
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6, -3.68
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -3.68
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 62), var(36) := -86
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1400, VelSet]
type = VelSet
trigger1 = AnimElem = 4
x = 0

[State 1400, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 1400, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 1401


;Landing
[StateDef 1401]
type = S
anim = 1401
physics = N
moveType = I
velSet = 0,0

[State 1401, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 1401, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1401, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0

[State 1401, End]
type = ChangeState
trigger1 = AnimElemTime(2) = 2 && command = "holddown"
value = 11
ctrl = 1

[State 1401, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<EX BUFFALO HEAD>=============================
[StateDef 1430]
type = S
physics = N
moveType = A
anim = 1430
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1430, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1430, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1430, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 35

[State 1430, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = -20 * const(size.xscale),-21 * const(size.yscale)
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1430, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1430, Dust Helper]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1430, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1400,0
channel = 0

[State 1430, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1400,1
channel = 1

[State 1430, VelSet]
type = VelSet
trigger1 = AnimElemTime(3) = 0
x = 15.625
y = -12

[State 1430, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(3) > 1
y = 1.125

[State 1030, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElemTime(3) = 0
statetype = A

[State 1430, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 119 < 7, 7, fvar(11) * 119)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -3.68, -12
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -3.68, -12
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 62), var(36) := -86
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1430, VelSet]
type = VelSet
trigger1 = AnimElem = 4
x = 0

[State 1430, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 1430, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 1401


;========================<SCREW SMASH>=============================
[StateDef 1500]
type = S
physics = S
moveType = A
anim = 1500
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1500, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "c" || command = "rlsc"), 2, ifElse((command = "b" || command = "rlsb"), 1, 0))

[State 1500, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || PrevStateNo = 750 || Random < 333), 0, ifElse(Random < 500, 1, 2))

[State 1500, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1520, ifElse(var(10) = 1, 1510, 1500))

[State 1500, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 101,0
channel = 2

[State 1500, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1500,0
channel = 0

[State 1500, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1,5
channel = 1

[State 1500, PosAdd]
type = PosAdd
trigger1 = animelem = 2
trigger2 = animelem = 3
trigger3 = animelem = 4
x = 12 + (var(10) * 3)

[State 1500, Skid Dust]
type = Explod
trigger1 = animelem = 2
anim = 8104
sprPriority = 3
posType = P1
pos = 20 * const(size.xscale),0 * const(size.xscale)
vel = 2 + (0.25 * var(10)),0
scale = 1.25 - (0.125 * var(10)),0.5
pauseMovetime = -1
superMoveTime = -1
ownpal = 1

[State 1500, Landing Dust Explod]
type = Explod
trigger1 = AnimElem = 15
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1500, Landing Sound]
type = PlaySnd
trigger1 = AnimElem = 15
value = 52,0

[State 1500, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, SA
hitFlag = M
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 98 < 7, 7, fvar(11) * 98)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Hard
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = ifElse(var(20), 12, 24)
ground.velocity = ifelse(var(10)=2, -3, ifelse(var(10)=1, -3.5, -4)), ifelse(var(10)=2, -10, ifelse(var(10)=1, -9, -8))
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -8
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 60), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
snap = 50, -10

[State 1500, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 6 && !MoveContact
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 93 < 7, 7, fvar(11) * 93)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -5.68
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -5.68
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 80), var(36) := -96
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1500, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = AnimElem = 7 && !MoveContact
forceNoFall = !var(20)
attr = S, SA
hitFlag = AF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 88 < 7, 7, fvar(11) * 88)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -4, -3.68
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -3.68
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 84), var(36) := -125
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1500, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(8) >= 0
trigger2 = AnimElemTime(8) < 0 && MoveContact
movetype = I

[State 1500, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<EX SCREW SMASH>=============================
[StateDef 1530]
type = S
physics = N
moveType = A
anim = 1500
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1530, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1530, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1530, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 35

[State 1530, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = -19 * const(size.xscale),-60 * const(size.yscale)
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1530, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1530, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 101,0
channel = 2

[State 1530, Voice]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1500,0
channel = 0

[State 1530, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 4
value = 1,5
channel = 1

[State 1530, PosAdd]
type = PosAdd
trigger1 = animelem = 2
trigger2 = animelem = 3
trigger3 = animelem = 4
x = 18

[State 1530, Skid Dust]
type = Explod
trigger1 = animelem = 2
anim = 8104
sprPriority = 3
posType = P1
pos = 30 * const(size.xscale),0 * const(size.xscale)
vel = 3,0
scale = 1,0.5
pauseMovetime = -1
superMoveTime = -1
ownpal = 1

[State 1530, Landing Dust Explod]
type = Explod
trigger1 = AnimElem = 15
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1530, Landing Sound]
type = PlaySnd
trigger1 = AnimElem = 15
value = 52,0

[State 1530, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 5
forceNoFall = !var(20)
attr = S, SA
hitFlag = M
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 118 < 7, 7, fvar(11) * 118)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 24
ground.velocity = -4, -10
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -10
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 60), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
snap = 50, -10

[State 1530, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 6 && !MoveContact
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 113 < 7, 7, fvar(11) * 113)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -7.68
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -5, -7.68
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 80), var(36) := -96
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1530, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
trigger1 = AnimElem = 7 && !MoveContact
forceNoFall = !var(20)
attr = S, SA
hitFlag = AF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 108 < 7, 7, fvar(11) * 108)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, -4.68
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -5, -4.68
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 84), var(36) := -125
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1530, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(8) >= 0
trigger2 = AnimElemTime(8) < 0 && MoveContact
movetype = I

[State 1530, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<TURN PUNCH>=============================
[StateDef 1600]
type = S
physics = N
moveType = A
anim = 1600
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1600, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5)<=0
value = SCA,AA,AP,AT
time = 1

[State 1500, SprPriority]
type = SprPriority
trigger1 = AnimElemTime(5)<=0
persistent = 0
value = -2

[State 1500, SprPriority]
type = SprPriority
trigger1 = AnimElemTime(5)>0
persistent = 0
value = 2

[State 1600, Button Detect: Punch Charge]
type = VarSet
trigger1 = !Time && Var(54)
var(10) = var(54)

[State 1600, Button Detect: Kick Charge]
type = VarSet
trigger1 = !Time && Var(57)
var(10) = var(57)

[State 1600, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = 1600 + ifelse(var(10) = 0, 0, (var(10)-1))

[State 1600, Dust Helper]
type = Helper
trigger1 = AnimElem = 7
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1600, Voice 1]
type = PlaySnd
trigger1 = !time
value = 1610, ifelse(var(10) = 0, 1, var(10))
channel = 0

[State 1600, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 7
value = 1600,11
channel = 2

[State 1600, VelSet]
type = VelSet
trigger1 = AnimElem = 7
x = 7 + ifelse(var(10) = 0, 1, var(10))

[State 1600, Physics Returns]
type = StateTypeSet
trigger1 = AnimElem = 8
statetype = S
movetype = A
physics = S

[State 1600, Voice 2 (CvS/SvC)]
type = PlaySnd
trigger1 = AnimElem = 8
value = 1620, ifelse(var(10) = 0, 1, var(10))
channel = 0

[State 1600, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 8
value = 1,5
channel = 1

[State 1600, HitDef: Level 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = (Var(10) = 0 || Var(10) = 1) && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 98 < 7, 7, fvar(11) * 98)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -4.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1600, HitDef: Level 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Var(10) = 2 && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 147 < 7, 7, fvar(11) * 147)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -4.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1600, HitDef: Level 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Var(10) = 3 && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 196 < 7, 7, fvar(11) * 196)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -4.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1600, HitDef: Level 4]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Var(10) = 4 && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 245 < 7, 7, fvar(11) * 245)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6.13, -4.93
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -5, -5.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1600, HitDef: Level 5]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Var(10) = 5 && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 294 < 7, 7, fvar(11) * 294)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6.13, -4.93
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -5, -5.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1600, HitDef: Level 6]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Var(10) = 6 && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 343 < 7, 7, fvar(11) * 343)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6.13, -4.93
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -5, -5.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1600, HitDef: Level 7]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Var(10) = 7 && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 392 < 7, 7, fvar(11) * 392)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, -6.93
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -6.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1600, HitDef: Level 8]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Var(10) = 8 && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 441 < 7, 7, fvar(11) * 441)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, -6.93
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -6.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1600, HitDef: Level 9]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Var(10) = 9 && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 490 < 7, 7, fvar(11) * 490)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, -6.93
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -6.93
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1600, HitDef: Level 10]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = Var(10) = 10 && AnimElem = 8
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 540 < 7, 7, fvar(11) * 540)), 7
getPower = ifElse(!var(13), 216, 72) * !var(20), 36 * !var(20)
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -12, -6
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -12, -6
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
P2StateNo = 1605

[State 1600, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(9) >= 0
movetype = I

[State 1600, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;========================<HIT BY MAX TURN PUNCH>=============================
;Being Launched
[StateDef 1605]
type = A
moveType = H
physics = N
velSet = 0,0

[State 1605, ChangeAnim]
type = ChangeAnim
trigger1 = 1
value = 5002

[State 1605, End]
type = ChangeState
trigger1 = HitShakeOver
value = 1606


;Heading Towards Wall
[StateDef 1606]
type = A
moveType = H
physics = N

[State 1606, HitVelSet]
type = HitVelSet
trigger1 = !Time
x = 1
y = 1

[State 1606, Gravity]
type = VelAdd
trigger1 = 1
y = GetHitVar(yAccel)/2

[State 1606, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1
moveCamera = 0,1
ignoreHitPause = 1

[State 1606, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignoreHitPause = 1

[State 1606, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && SelfAnimExist(5900)
value = 5900

[State 1606, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && !SelfAnimExist(5900)
value = 5030

[State 1606, Bounce Off Wall]
type = ChangeState
trigger1 = BackEdgeBodyDist <= 10 || FrontEdgeBodyDist <= 10
value = 1607

[State 1606, End]
type = SelfState
trigger1 = vel y > 0 && pos y >= 0
value = 5100


;Impacting Wall
[StateDef 1607]
type = A
moveType = H
physics = N

[State 1670, Turn]
type = Turn
trigger1 = !Time
trigger1 = FrontEdgeDist < BackEdgeDist

[State 1607, PosSet]
type = PosSet
trigger1 = 1
x = -160 * Facing

[State 1607, Hitting the Wall FX]
type = Explod
trigger1= !Time
anim = F72
pos = 0, floor(ScreenPos y) - 50
posType =  Back
sprPriority = 3

[State 1607, PosFreeze]
type = PosFreeze
trigger1 = 1
x = 1
y = 1

[State 1607, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1
moveCamera = 0,1
ignoreHitPause = 1

[State 1607, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 1
ignoreHitPause = 1

[State 1607, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && SelfAnimExist(5901)
value = 5901

[State 1607, ChangeAnim]
type = ChangeAnim
trigger1 = !SelfAnimExist(5901)
value = 5000

[State 1607, Impact Sound]
type = PlaySnd
trigger1 = !Time
value = F7,0

[State 1607, End]
type = ChangeState
trigger1 = Time >= 4
value = 1608


;Bouncing Off Wall
[Statedef 1608]
type = A
moveType = H
physics = N

[State 1608, Turn]
type = Turn
trigger1 = !Time && !SelfAnimExist(5902)

[State 1608, Gravity]
type = VelAdd
trigger1 = 1
y = 0.5

[State 1608, VelSet]
type = VelSet
trigger1 = !Time
x = ifElse(SelfAnimExist(5902), 2.5, -2.5)
y = -9

[State 1608, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && SelfAnimExist(5902)
value = 5902

[State 1608, ChangeAnim]
type = ChangeAnim
trigger1 = !Time && !SelfAnimExist(5902)
value = ifElse(SelfAnimExist(5051), 5051, 5030)

[State 1608, ChangeAnim]
type = ChangeAnim
trigger1 = Anim = 5030 && !AnimTime
value = 5050

[State 1608, ChangeAnim]
type = ChangeAnim
trigger1 = vel y > -3 && Anim = 5051 && SelfAnimExist(5061)
value = 5061

[State 1608, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1
moveCamera = 0,0
ignoreHitPause = 1

[State 1608, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignoreHitPause = 1

[State 1608, End]
type = SelfState
trigger1 = vel y > 0 && pos y >= 0
value = 5100


;========================<PUNCH ZERO COUNTER>=============================
[StateDef 2900]
type = S
physics = N
moveType = A
anim = 2900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2900, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2900, Dust Helper]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 2900, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1400,0
channel = 0

[State 2900, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1400,1
channel = 1

[State 2900, VelSet]
type = VelSet
trigger1 = AnimElemTime(3) = 0
x = 8.125
y = -12

[State 2900, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(3) > 1
y = 1.125

[State 2900, StateTypeSet]
type = StateTypeSet
trigger1 = AnimElemTime(3) = 0
statetype = A

[State 2900, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 4 || var(20))
trigger1 = AnimElem = 3
forceNoFall = !var(20)
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 98 < 7, 7, fvar(11) * 98)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6, -3.68
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -3.68
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 62), var(36) := -86
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 2900, VelSet]
type = VelSet
trigger1 = AnimElem = 4
x = 0

[State 2900, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[State 2900, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 1401


;========================<KICK ZERO COUNTER>=============================
[StateDef 2910]
type = S
physics = N
moveType = A
anim = 2910
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2910, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
value = SCA
time = 1

[State 2910, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4,3
channel = 0

[State 2910, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,5
channel = 1

[State 450, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 3
attr = C, SA
hitFlag = MAF
guardFlag = L
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 42 < 7, 7, fvar(11) * 42)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Trip
air.type = Trip
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -1, -5.38
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -1, -5.38
air.cornerPush.velOff = 0
yAccel = 0.677
fall = 1
fall.recover = 1
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 112), var(36) := -13
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 2910, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
moveType = I

[State 450, End]
type = ChangeState
trigger1 = !AnimTime
value = 11
ctrl = 1