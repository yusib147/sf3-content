; _______________________________________________
;|               Balrog by Trololo               |
; �����������������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================
;========================<CRAZY BUFFALO>=============================
[StateDef 3000]
type = S
physics = N
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, Button Detect (Normal)]
type = VarSet
trigger1 = !AILevel
var(10) = ifElse((command = "holda" || command = "holdb" || command = "holdc"), 1, 0)

[State 3000, Button Detect (AI)]
type = VarSet
trigger1 = AILevel
var(10) = ifElse(P2Dist y >= 20 && P2Dist y <= 40, 1, 0)

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = Anim = 3000
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = 32 * const(size.xscale),-79 * const(size.yscale)
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 43
moveTime = 43
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Startup Voice]
type = PlaySnd
trigger1 = !time
value = 3000,0
channel = 0

[State 3000, Attack Animations]
type = ChangeAnim
trigger1 = !Animtime
value = Ifelse(var(10), 3002, 3001)
elem = 1

[State 3000, Swift Sound]
type = PlaySnd
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
value = 3000,1
channel = 2

[State 3000, VelSet]
type = VelSet
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
x = 7

[State 3000, Dust Helper]
type = Helper
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
helpertype = normal
stateno = 8103
ID = 8100
name = "Dash Dust"
postype = p1
pausemovetime = 255
supermovetime = 255
ownpal = 1

[State 3000, No Escape! (CvS/SvC)]
type = PlaySnd
trigger1 = time = 44
value = 3000,2
channel = 0

[State 3000, URRRR!!! (SFA)]
type = PlaySnd
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
value = 3000,3
channel = 0

[State 3000, Woosh Sound]
type = PlaySnd
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
value = 1,5
channel = 2

[State 3000, HitDef: Straight]
type = HitDef
trigger1 = !var(16) && var(15) < 5
trigger1 = Anim = 3001 && AnimElem = 3
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 10, 16
guard.pauseTime = 10, 16
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -5
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3000, HitDef: Uppercut]
type = HitDef
trigger1 = !var(16) && var(15) < 5
trigger1 = Anim = 3002 && AnimElem = 4
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 10, 16
guard.pauseTime = 10, 16
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -3
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 56), var(36) := -77
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3000, ChangeState]
type = ChangeState
trigger1 = time = 62
value = 3005
ctrl = 0

;Final Hit
[Statedef 3005]
type = S
movetype = A
physics = N
anim = 3005
ctrl = 0
velset = 0,0
poweradd = 0
sprpriority = 2

[State 3005, VelSet]
type = VelSet
trigger1 = AnimElem = 8
x = 10

[State 3005, Dust Helper]
type = Helper
trigger1 = AnimElem = 7
helpertype = normal
stateno = 8103
ID = 8100
name = "Dash Dust"
postype = p1
pausemovetime = 255
supermovetime = 255
ownpal = 1

[State 3005, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 7
value = 1000,1
channel = 2

[State 3005, Voice (SFA)]
type = PlaySnd
trigger1 = Animelem = 8
value = 3000, 4
channel = 0

[State 3005, Woosh Sound]
type = PlaySnd
trigger1 = Animelem = 8
value = 1, 2
channel = 2

[State 3005, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 6
trigger1 = AnimElem = 9
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 10, 10
guard.pauseTime = 10, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6, -3.67
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -3.67
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3005, Physics Returns]
type = StateTypeSet
trigger1 = animelem = 9
physics = S

[State 3005, StateTypeSet]
type = StateTypeSet
trigger1 = animelem = 10
movetype = I

[State 3005, End]
type = ChangeState
trigger1 = !Animtime
value = 0
ctrl = 1


;========================<CRAZY BUFFALO MAX>=============================
[StateDef 3050]
type = S
physics = N
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, Button Detect (Normal)]
type = VarSet
trigger1 = !AILevel
var(10) = ifElse((command = "holda" || command = "holdb" || command = "holdc"), 1, 0)

[State 3050, Button Detect (AI)]
type = VarSet
trigger1 = AILevel
var(10) = ifElse(P2Dist y >= 20 && P2Dist y <= 40, 1, 0)

[State 3050, NotHitBy]
type = NotHitBy
trigger1 = Anim = 3000
time = 1
value = SCA

[State 3050, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = 32 * const(size.xscale),-79 * const(size.yscale)
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3050, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 43
moveTime = 43
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3050, Startup Voice]
type = PlaySnd
trigger1 = !time
value = 3000,0
channel = 0

[State 3050, Attack Animations]
type = ChangeAnim
trigger1 = !Animtime
value = Ifelse(var(10), 3002, 3001)
elem = 1

[State 3050, Swift Sound]
type = PlaySnd
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
value = 3000,1
channel = 2

[State 3050, VelSet]
type = VelSet
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
x = 7

[State 3050, Dust Helper]
type = Helper
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
helpertype = normal
stateno = 8103
ID = 8100
name = "Dash Dust"
postype = p1
pausemovetime = 255
supermovetime = 255
ownpal = 1

[State 3050, No Escape! (CvS/SvC)]
type = PlaySnd
trigger1 = time = 44
value = 3000,2
channel = 0

[State 3050, URRRR!!! (SFA)]
type = PlaySnd
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
value = 3000,3
channel = 0

[State 3050, Woosh Sound]
type = PlaySnd
triggerall = (Anim = [3001,3002])
trigger1 = AnimElem = 1
value = 1,5
channel = 2

[State 3050, HitDef: Straight]
type = HitDef
trigger1 = !var(16) && var(15) < 7
trigger1 = Anim = 3001 && AnimElem = 3
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 10, 16
guard.pauseTime = 10, 16
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -5
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3050, HitDef: Uppercut]
type = HitDef
trigger1 = !var(16) && var(15) < 7
trigger1 = Anim = 3002 && AnimElem = 4
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 10, 16
guard.pauseTime = 10, 16
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -4, -3
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 56), var(36) := -77
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3050, ChangeState]
type = ChangeState
trigger1 = time = 82
value = 3055
ctrl = 0

;Final Hit
[Statedef 3055]
type = S
movetype = A
physics = N
anim = 3005
ctrl = 0
velset = 0,0
poweradd = 0
sprpriority = 2

[State 3055, VelSet]
type = VelSet
trigger1 = AnimElem = 8
x = 10

[State 3055, Dust Helper]
type = Helper
trigger1 = AnimElem = 7
helpertype = normal
stateno = 8103
ID = 8100
name = "Dash Dust"
postype = p1
pausemovetime = 255
supermovetime = 255
ownpal = 1

[State 3055, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 7
value = 1000,1
channel = 2

[State 3055, Voice (SFA)]
type = PlaySnd
trigger1 = Animelem = 8
value = 3000, 4
channel = 0

[State 3055, Woosh Sound]
type = PlaySnd
trigger1 = Animelem = 8
value = 1, 2
channel = 2

[State 3055, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 8
trigger1 = AnimElem = 9
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 10, 10
guard.pauseTime = 10, 10
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8, 0
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -6, -5
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3055, Physics Returns]
type = StateTypeSet
trigger1 = animelem = 9
physics = S

[State 3055, StateTypeSet]
type = StateTypeSet
trigger1 = animelem = 10
movetype = I

[State 3055, End]
type = ChangeState
trigger1 = !Animtime
value = 0
ctrl = 1


;========================<ULTIMATE SCREW SMASH>=============================
[StateDef 3100]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(10) < 0
time = 1
value = SCA

[State 3100, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = -35 * const(size.xscale),-54 * const(size.yscale)
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 43
moveTime = 43
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, Voice 1]
type = PlaySnd
trigger1 = Time = 3
value = 3100,0
channel = 0

[State 3100, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 7
value = 101,0
channel = 2

[State 3100, Voice 2]
type = PlaySnd
trigger1 = AnimElem = 9
value = 3100,2
channel = 0

[State 3100, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 9
value = 1,5
channel = 1

[State 3100, PosAdd]
type = PosAdd
trigger1 = animelem = 7
trigger2 = animelem = 8
trigger3 = animelem = 9
x = 21

[State 3100, Skid Dust]
type = Explod
trigger1 = animelem = 8
anim = 8104
sprPriority = 3
posType = P1
pos = 30 * const(size.xscale),0 * const(size.xscale)
vel = 3,0
scale = 1.05,0.5
pauseMovetime = -1
superMoveTime = -1
ownpal = 1

[State 3100, Landing Dust Explod]
type = Explod
trigger1 = AnimElem = 20
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 3100, Landing Sound]
type = PlaySnd
trigger1 = AnimElem = 20
value = 52,0

[State 3100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 7 || var(20))
trigger1 = AnimElem = 10
ID = 3100
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 295 < 7, 7, fvar(11) * 295)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 0, 0
guard.pauseTime = 38, 32
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8, -11
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -8, -11
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8000)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 60), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3100, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 7 || var(20))
trigger1 = AnimElem = 11 && !MoveContact
ID = 3100
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 295 < 7, 7, fvar(11) * 295)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 0, 0
guard.pauseTime = 38, 32
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8, -11
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -8, -11
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8000)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 80), var(36) := -96
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3100, ChangeState]
type = ChangeState
trigger1 = NumTarget(3100)
trigger1 = MoveHit
value = 3101

[State 3100, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(12) >= 0
movetype = I

[State 3100, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;Success
[StateDef 3101]
type = S
physics = S
moveType = A
ctrl = 0
velSet = 0,0
sprPriority = 2
anim = 3101

[State 3101, Lost Target]
type = ChangeState
trigger1 = !Time && !NumTarget
value = 0
ctrl = 1

[State 3101, TargetState]
type = TargetState
trigger1 = !Time
value = 3105

[State 3101, Hit Sound]
type = PlaySnd
trigger1 = !Time
value = 3100, 1
channel = 2
ignoreHitPause = 1

[State 3101,TargetBind]
type = TargetBind
trigger1 = !Time
pos = ceil(75 * const(size.xScale)), ceil(-92 * const(size.yScale))

[State 3101, PosAdd]
type = PosAdd
trigger1 = AnimElem = 6
x = 2

[State 3101, PosAdd]
type = PosAdd
trigger1 = AnimElem = 7
x = 28

[State 3101, PosAdd]
type = PosAdd
trigger1 = AnimElem = 8
trigger2 = AnimElem = 9
x = 22

[State 3101, PalFX: Red Color]
type = PalFX
trigger1 = Anim = 3101 && animelemtime(1) < 6
mul = 512, 0, 0
time = 2
color = 0
ignorehitpause = 1

[State 3101, PalFX: Back to Normal Colors]
type = PalFX
trigger1 = Anim = 3101 && (AnimElemTime(1) >= 6 && AnimElemTime(1) < 15)
mul = 512 - (18 * Time), 0 + (18 * Time), 0 + (18 * Time)
time = 1
color = ceil(18 * Time)
ignorehitpause = 1

[State 3101, BGPalFX]
type = BGPalFX
trigger1 = AnimElemTime(1) >= 0 && AnimElemTime(1) < 6
time = 10
add = -255, -255, -255
sinadd = 255, 255, 255, 64

[State 3101, Impact Explod]
type = Explod
trigger1 = NumTarget && !Time
anim = 8014
ID = 4
pos = var(35), var(36)
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 3101, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.1 + (0.0725 * Time), 0.1 + (0.0725 * Time)
trans = AddAlpha
alpha = 256 - (32 * Time),256

[State 3101, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 3101, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;Target
[StateDef 3105]
type = A
physics = N
moveType = H
ctrl = 0
velSet = -10, -8.5
sprPriority = 1

[State 3105, PosFreeze]
type = PosFreeze
trigger1 = Anim = 3105
value = 1
ignorehitpause = 1

[State 3105, ChangeAnim]
type = ChangeAnim2
trigger1 = Anim != 3105 && !Time
value = 3105

[State 3105, Anim]
type = changeanim
trigger1 = AnimElemTime(2)=1
trigger1 = Anim != 5052 && SelfAnimExist(5052)
value = 5052

[State 3105, ScreenBound]
type = ScreenBound
trigger1 = animelemtime(1)>=0 && animelemtime(2)<0
value = 1
movecamera = 1,0

[State 3105, PalFX: Red Color]
type = PalFX
trigger1 = Anim = 3105 && animelemtime(1) < 6
mul = 512, 0, 0
time = 2
color = 0
ignorehitpause = 1

[State 3105, PalFX: Back to Normal Colors]
type = PalFX
trigger1 = Anim = 3105 && (AnimElemTime(1) >= 6 && AnimElemTime(1) < 15)
mul = 512 - (18 * Time), 0 + (18 * Time), 0 + (18 * Time)
time = 1
color = ceil(18 * Time)
ignorehitpause = 1

[State 3105, PosFreeze]
type = PosFreeze
trigger1 = anim = 3105
value = 1
ignorehitpause = 1

[State 3105, PosAdd]
type = PosAdd
trigger1 = Anim = 3105 && AnimElem = 2
y = 72

[State 3105, ChangeAnim]
type = ChangeAnim2
trigger1 = Anim = 3105 && AnimTime = 0
value = 5050

[State 3105, VelAdd]
type = VelAdd
trigger1 = time >= 38
y = 0.58

[State 3105, End]
type = SelfState
trigger1 = vel y > 0
trigger1 = pos y >= 25
value = 5100


;========================<GIGATON BLOW>==============================
[Statedef 3200]
type = S
movetype = A
physics = N
juggle   = 3
ctrl = 0
velset = 0,0
sprpriority = 2
velset = 0,0
anim = 3200
powerAdd = -3000
faceP2 = 1

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(14) < 0
time = 1
value = SCA

[State 3200, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = P1
pos = -35 * const(size.xscale),-54 * const(size.yscale)
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3200, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 43
moveTime = 43
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, Voice 1]
type = PlaySnd
trigger1 = Time = 3
value = 3200,0
channel = 0

[State 3200, Swift Sound]
type = PlaySnd
trigger1 = AnimElem = 12
value = 3200,1
channel = 2

[State 3200, Voice 2]
type = PlaySnd
trigger1 = AnimElem = 12
value = 3200,3
channel = 0

[State 3200, Whirl Sound]
type = PlaySnd
trigger1 = AnimElem = 14
value = 3200,2
channel = 3

[State 3200, Width]
type = Width
trigger1 = AnimElem = 12
value = 0,14

[State 3200, VelSet]
type = VelSet
trigger1 = AnimElem = 12
x = 15

[State 3200, VelAdd]
type = VelAdd
trigger1 = AnimElemTime(12) > 0 && Vel X > 0
x = -0.5

[State 3200, Complete Stop]
type = VelSet
trigger1 = AnimElemTime(12) > 0 && Vel X <= 0
x = 0

[State 3200, Dust Helper]
type = Helper
trigger1 = animelem = 12
helpertype = normal
stateno = 8103
ID = 8100
name = "Dash Dust"
postype = p1
pausemovetime = 255
supermovetime = 255
ownpal = 1

[State 3200, Effect (Overlay)]
type = Explod
trigger1 = AnimElem = 14
anim = 3201
ID = 3201
pos = 0,0
postype = p1
ownpal = 1
bindtime = -1
sprpriority = 3
supermovetime = -1
scale = 0.5 * const(Size.xscale), 0.5 * const(Size.yscale)
removetime = -2
removeongethit = 1
ignorehitpause = 0
persistent = 0

[State 3200, Effect (Underlay)]
type = Explod
trigger1 = AnimElem = 14
anim = 3202
ID = 3202
pos = 0,0
postype = p1
ownpal = 1
bindtime = -1
sprpriority = 1
supermovetime = -1
scale = 0.5 * const(Size.xscale), 0.5 * const(Size.yscale)
removetime = -2
removeongethit = 1
ignorehitpause = 0
persistent = 0

[State 3200, Effect]
type = Explod
trigger1 = AnimElem = 13
anim = 3203
ID = 3203
pos = 50 * const(Size.xscale),10 * const(Size.yscale)
postype = p1
ownpal = 1
bindtime = 0
sprpriority = 3
supermovetime = -1
scale = 0.5 * const(Size.xscale), 0.5 * const(Size.yscale)
removetime = -2
removeongethit = 0
ignorehitpause = 1
persistent = 0

[State 3000, HitDef: High]
type = HitDef
trigger1 = !var(16) && var(15) < 13
trigger1 = AnimElem = 15 || AnimElem = 17 || AnimElem = 19 || AnimElem = 21
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 43 < 7, 7, fvar(11) * 43)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 5, 5
guard.pauseTime = 5, 5
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8, 0
ground.cornerPush.velOff = 0
guard.velocity = -8
guard.cornerPush.velOff = 0
air.velocity = -6, -1
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3000, HitDef: Low]
type = HitDef
trigger1 = !var(16) && var(15) < 13
trigger1 = AnimElem = 14 || AnimElem = 16 || AnimElem = 18 || AnimElem = 20
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 43 < 7, 7, fvar(11) * 43)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 5, 5
guard.pauseTime = 5, 5
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8, 0
ground.cornerPush.velOff = 0
guard.velocity = -8
guard.cornerPush.velOff = 0
air.velocity = -6, -1
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 0
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3000, HitDef: Final]
type = HitDef
trigger1 = !var(16) && var(15) < 13
trigger1 = AnimElem = 22
attr = S, HA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 56 < 7, 7, fvar(11) * 56)), 7
getPower = 0, 0
givePower = 36, 36
pauseTime = 3, 3
guard.pauseTime = 3, 3
animType = Hard
air.animType = Hard
fall.animType = Hard
ground.type = Low
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.13, -6
ground.cornerPush.velOff = 0
guard.velocity = -8.13
guard.cornerPush.velOff = 0
air.velocity = -8.13, -3
air.cornerPush.velOff = 0
yAccel = 0.58
forcestand = 1
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 130), var(36) := -66
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3200, StateTypeSet]
type = StateTypeSet
trigger1 = animelem = 23
movetype = I

[State 3200, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 0
ctrl = 1