; _________________________________________
;| Character by Author Name                |
; ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
;==============================================================================================
;========================================<SPECIAL MOVES>========================================
;==============================================================================================

;------------------------------------------------------------------------
;Bull Head
[StateDef 1000]
type = S
movetype = A
physics = N
juggle   = 3
ctrl = 0
velset = 0,0
sprpriority = 2
powerAdd = 72 * !var(20)
faceP2 = 1

[state -2, Varset]
type = VarSet
trigger1 = time = 0
var(10) = 0
ignorehitpause = 1
Persistent = 1

[State 1001, Varset]
type = VarSet
triggerall = Time = 0
trigger1 = Time = 0
var(10) = ifelse((command="y" || command="rlsy"),1,ifelse((command="z" || command="rlsz"),2,0))
IgnoreHitPause = 1
Persistent = 1

[State -3, ]
type = VarSet
triggerall = roundstate = 2
trigger1 = Time = 0
trigger1 = !var(10)
v = 1
value = ifelse(P2bodydist X > 280,2,ifelse((P2bodydist X = [180,280]),1,0))
IgnoreHitPause = 1
Persistent = 1

[State 1000, Bull Head Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1000,0
channel = 0

[State 3000, NotHitby]
type = NotHitBy
trigger1 = numhelper(1004)
value = SCA,AA,AP
ignorehitpause=1

[State 40, 3]
type = ChangeAnim
trigger1 = Time = 0
value = ifelse(var(10)=1,1001,ifelse(var(10)=0,1000,ifelse(var(10)=3,1050,1002)))

[State 40, 3]
type = ChangeAnim
triggerall = animelemtime(2) >= 0&&animelemtime(3) <  0
trigger1 = P2Dist x <= 90
value = ifelse(var(10)=1,1001,ifelse(var(10)=0,1000,1002))
elem = 3

[State 4]
type = VelSet
trigger1 = Animelem = 2
x = ifelse(var(10)=1,7,ifelse(var(10)=0,6,8))

[State 4]
type = VelSet
trigger1 = Animelem = 4
x = 0

[State 1000, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 240, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 2
trigger1 = time = 0
attr = S, SA
animtype  = Hard
damage = ceil(ifElse(fvar(11) * 12 < 7, 7, fvar(11) * 90)), 7
guardflag = M
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
ground.type = H
ground.slidetime = 10
ground.hittime  = ifelse(var(10)=1,23,ifelse(var(10)=2,24,19))
ground.velocity = -5,-4
air.velocity = -5,-4
envshake.time = 20
envshake.freq = 120
envshake.ampl = -4
envshake.phase = 160
fall = 1
air.fall = 1
fall.recover = 0
getpower = 60
givepower = 20

[State 240, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 1
trigger1 = time = 0
attr = S, SA
animtype  = Hard
damage = ceil(ifElse(fvar(11) * 12 < 7, 7, fvar(11) * 80)), 7
guardflag = M
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
ground.type = H
ground.slidetime = 10
ground.hittime  = ifelse(var(10)=1,23,ifelse(var(10)=2,24,19))
ground.velocity = -5,-4
air.velocity = -5,-4
envshake.time = 20
envshake.freq = 120
envshake.ampl = -4
envshake.phase = 160
fall = 1
air.fall = 1
fall.recover = 0
getpower = 60
givepower = 20

[State 240, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = var(10) = 0
trigger1 = time = 0
attr = S, SA
animtype  = Hard
damage = ceil(ifElse(fvar(11) * 12 < 7, 7, fvar(11) * 70)), 7
guardflag = M
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
ground.type = H
ground.slidetime = 10
ground.hittime  = ifelse(var(10)=1,23,ifelse(var(10)=2,24,19))
ground.velocity = -5,-4
air.velocity = -5,-4
envshake.time = 20
envshake.freq = 120
envshake.ampl = -4
envshake.phase = 160
fall = 1
air.fall = 1
fall.recover = 0
getpower = 60
givepower = 20

[State 1000, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 101,0
channel = 1

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;EX Bull Head
[StateDef 1050]
type = S
physics = N
moveType = A
anim = 1050
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[state 2910,Helper]
type=helper
triggerall=!ishelper
triggerall = var(10) = 3
trigger1=!numhelper(1004)&& animelemtime(4) <=  0
stateno=1004
name="armor"
id=1004
pos=0,0
postype=p1
ownpal=0
keyctrl=0
ignorehitpause=1
pausemovetime=99999
supermovetime=99999

[State 3000, NotHitby]
type = NotHitBy
trigger1 = numhelper(1004)
value = SCA,AA,AP
ignorehitpause=1

[state -2, Varset]
type = VarSet
trigger1 = time = 0
var(10) = 0
ignorehitpause = 1
Persistent = 1

[State 1001, Varset]
type = VarSet
trigger1 = Time = 0
var(10) = ifelse((command="y"),1,ifelse((command="z"),2,0))
IgnoreHitPause = 1
Persistent = 1

[State -3, ]
type = VarSet
triggerall = roundstate = 2
trigger1 = Time = 0
trigger1 = !var(10)
v = 1
value = ifelse(P2bodydist X > 280,2,ifelse((P2bodydist X = [180,280]),1,0))
IgnoreHitPause = 1
Persistent = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 44

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 0

[State 1030, Voice]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1000,0
channel = 1

[State 40, 3]
type = ChangeAnim
trigger1 = Time = 0
value = ifelse(var(10)=1,1001,ifelse(var(10)=0,1000,ifelse(var(10)=3,1050,1002)))

[State 40, 3]
type = ChangeAnim
triggerall = animelemtime(2) >= 0&&animelemtime(3) <  0
trigger1 = P2Dist x <= 90
value = ifelse(var(10)=1,1001,ifelse(var(10)=0,1000,1002))
elem = 3

[State 4]
type = VelSet
trigger1 = Animelem = 2
x = ifelse(var(10)=1,7,ifelse(var(10)=0,6,8))

[State 4]
type = VelSet
trigger1 = Animelem = 4
x = 0

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 240, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = time = 0
attr = S, SA
animtype  = Hard
damage = ceil(ifElse(fvar(11) * 100 < 7, 7, fvar(11) * 100)), 0
guardflag = M
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
ground.type = H
ground.slidetime = 10
ground.hittime  = ifelse(var(10)=1,23,ifelse(var(10)=2,24,19))
ground.velocity = -5,-4
air.velocity = -5,-4
envshake.time = 20
envshake.freq = 120
envshake.ampl = -4
envshake.phase = 160
fall = 1
air.fall = 1
fall.recover = 0
getpower = ifelse(var(10)=3,0,60)
givepower = 20

[State 1030, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 101,0
channel = 2

[State 1030, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;---------------------------------------------------------------------------
;Birdie Helper
[Statedef 1004]
type=S
movetype=I

[state 1004,Selfstate]
type=selfstate
trigger1=!ishelper
value=50
ctrl=1

[state 1004,Assertspecial]
type=assertspecial
trigger1=ishelper(1004)
flag=invisible
flag2=noshadow
ignorehitpause=1

[state 1004,Bindtoroot]
type=bindtoroot
trigger1=ishelper(1004)
ignorehitpause=1

[State 1004, NotHitby]
type = NotHitBy
trigger1=ishelper(1004)
value = ,AT

[state 1004,Hitoverride]
type=hitoverride
trigger1=ishelper(1004)
time=-1
attr=SCA,AA,AP
slot=0
stateno=1004
ignorehitpause=1

[state 1004, Changeanim]
type=changeanim
triggerall=root,movetype != H
trigger1=ishelper(1004)
trigger1=anim!=root,anim
value=root,anim
ignorehitpause=1

[state 1004,??]
type=playerpush
trigger1=ishelper(1004)
value=1
ignorehitpause=1

[state 1004, Turn]
type=turn
trigger1=ishelper(1004)
trigger1=facing!=root,facing
ignorehitpause=1

[state 1004,Destroyself]
type=destroyself
triggerall=ishelper
trigger1=name!="Birdie"
trigger2=roundstate>2
trigger3=root,stateno != [1000,2999]
trigger4=root,movetype = H
trigger5=root,stateno = 1030 && animelemtime(5) >=  0
ignorehitpause=1


[Statedef 1100]
type = S
physics = N
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 4
value = 4, 0

[State 0, VelSet]
type = VelSet
trigger1 = Animelem = 5
x = 8

[State 0, ChangeState]
type = ChangeState
triggerall = animelemtime(5) >= 0
trigger1 = P2Dist x <= 90
value =1110
ctrl = 0
elem = 3

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = time = 0
value = SCA,NA,SA,HA,NP,SP,HP
time = 22

;Conect
[Statedef 1110]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0,0
anim = 1110
juggle = 5

[State 0, VelSet]
type = VelSet
trigger1 = time >= 0
x = 4

[State 0, VelSet]
type = VelSet
trigger1 = time >= 3
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 7
x = 1

[State 0, VelSet]
type = VelSet
trigger1 = time >= 10
x = 0

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Animelem=2
priority = 4, Hit
attr = S,SA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
GivePower = 36, 36
pausetime = 10,12
guard.pausetime = 10,10
ground.slidetime = 17
ground.hittime = 17
air.hittime = 20
guard.hittime = 14
guard.ctrltime =14
ground.velocity = -3,-8
air.velocity = -3,-8
yaccel = 0.55
guard.velocity = -12
ground.cornerpush.veloff =  0
guard.cornerpush.veloff =  0
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
fall = 1
air.fall = 1
fall.recover = 1
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem =1
value = s101,0

[State 0, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value =0
ctrl = 1

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

;Bull Horn 2 hits
[Statedef 1120]
type = S
physics = N
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 4
value = s4,1

[State 0, VelSet]
type = VelSet
trigger1 = Animelem = 5
x = 8

[State 0, ChangeState]
type = ChangeState
triggerall = animelemtime(5) >= 0
trigger1 = P2Dist x <= 90
value =1121
ctrl = 0
elem = 3

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = time = 0
value = SCA,NA,SA,HA,NP,SP,HP
time = 22

;Conect
[Statedef 1121]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0,0
anim = 1111
juggle = 5

[State 0, VelSet]
type = VelSet
trigger1 = time >= 0
x = 6

[State 0, VelSet]
type = VelSet
trigger1 = time >= 3
x = 3

[State 0, VelSet]
type = VelSet
trigger1 = time >= 7
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 10
x = 0

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem=2
priority = 4, Hit
attr = S,SA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
GivePower = 36, 36
pausetime = 10,12
guard.pausetime = 10,10
ground.slidetime = 17
ground.hittime = 17
air.hittime = 20
guard.hittime = 14
guard.ctrltime =14
ground.velocity = -8
air.velocity = -3,-8
yaccel = 0.55
guard.velocity = -8
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
fall = 0
air.fall = 1
fall.recover = 1
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem=3
priority = 4, Hit
attr = S,SA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 30)), 7
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
GivePower = 36, 36
pausetime = 10,12
guard.pausetime = 10,10
ground.slidetime = 17
ground.hittime = 17
air.hittime = 20
guard.hittime = 14
guard.ctrltime =14
ground.velocity = -3,-8
air.velocity = -3,-8
yaccel = 0.55
guard.velocity = -12
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
fall = 1
air.fall = 1
fall.recover = 1
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem =1
value = s101,0

[State 0, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value =0
ctrl = 1

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

;Bull Horn 3 Hits
[Statedef 1130]
type = S
physics = N
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 4
value = s4,2

[State 0, VelSet]
type = VelSet
trigger1 = Animelem = 5
x = 8

[State 0, ChangeState]
type = ChangeState
triggerall = animelemtime(5) >= 0
trigger1 = P2Dist x <= 90
value =1131
ctrl = 0
elem = 3

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = time = 0
value = SCA,NA,SA,HA,NP,SP,HP
time = 22

;Conect
[Statedef 1131]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0,0
anim = 1112
juggle = 5

[State 0, VelSet]
type = VelSet
trigger1 = time >= 0
x = 6

[State 0, VelSet]
type = VelSet
trigger1 = time >= 3
x = 3

[State 0, VelSet]
type = VelSet
trigger1 = time >= 7
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 10
x = 0

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem=2
trigger2 = animelem=3
priority = 4, Hit
attr = S,SA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
GivePower = 36, 36
pausetime = 10,12
guard.pausetime = 10,10
ground.slidetime = 17
ground.hittime = 17
air.hittime = 20
guard.hittime = 14
guard.ctrltime =14
ground.velocity = -8
air.velocity = -3,-8
yaccel = 0.55
guard.velocity = -8
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
fall = 0
air.fall = 1
fall.recover = 1
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem=4
priority = 4, Hit
attr = S,SA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
GivePower = 36, 36
pausetime = 10,12
guard.pausetime = 10,10
ground.slidetime = 17
ground.hittime = 17
air.hittime = 20
guard.hittime = 14
guard.ctrltime =14
ground.velocity = -3,-8
air.velocity = -3,-8
yaccel = 0.55
guard.velocity = -12
ground.cornerpush.veloff =  0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
fall = 1
air.fall = 1
fall.recover = 1
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 0, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value =0
ctrl = 1

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

;Bull Horn 4 Hits
[Statedef 1140]
type = S
physics = N
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 4
value = s4,3

[State 0, VelSet]
type = VelSet
trigger1 = Animelem = 5
x = 8

[State 0, ChangeState]
type = ChangeState
triggerall = animelemtime(5) >= 0
trigger1 = P2Dist x <= 90
value =1141
ctrl = 0
elem = 3

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = time = 0
value = SCA,NA,SA,HA,NP,SP,HP

;Conect
[Statedef 1141]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0,0
anim = 1113
juggle = 5

[State 0, VelSet]
type = VelSet
trigger1 = time >= 0
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >= 3
x = 4

[State 0, VelSet]
type = VelSet
trigger1 = time >= 7
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 10
x = 0

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem=2
trigger2 = animelem=3
trigger3 = animelem=4
priority = 4, Hit
attr = S,SA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
GivePower = 36, 36
pausetime = 10,12
guard.pausetime = 10,10
ground.slidetime = 17
ground.hittime = 17
air.hittime = 20
guard.hittime = 14
guard.ctrltime =14
ground.velocity = -8
air.velocity = -3,-8
yaccel = 0.55
guard.velocity = -8
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
fall = 0
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem=5
priority = 4, Hit
attr = S,SA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
GivePower = 36, 36
pausetime = 10,12
guard.pausetime = 10,10
ground.slidetime = 17
ground.hittime = 17
air.hittime = 20
guard.hittime = 14
guard.ctrltime =14
ground.velocity = -3,-8
air.velocity = -3,-8
yaccel = 0.55
guard.velocity = -12
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
fall = 1
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem =1
value = s101,0

[State 0, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value =0
ctrl = 1

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

;Bull Horn 5 Hits
[Statedef 1150]
type = S
physics = N
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 4
value = s4,4

[State 0, VelSet]
type = VelSet
trigger1 = Animelem = 5
x = 8

[State 0, ChangeState]
type = ChangeState
triggerall = animelemtime(5) >= 0
trigger1 = P2Dist x <= 90
value =1151
ctrl = 0
elem = 3

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = time = 0
value = SCA,NA,SA,HA,NP,SP,HP
time = 22

;Conect
[Statedef 1151]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0,0
anim = 1114
juggle = 5

[State 0, VelSet]
type = VelSet
trigger1 = time >= 0
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >= 3
x = 6

[State 0, VelSet]
type = VelSet
trigger1 = time >= 7
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 10
x = 0

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem=2
trigger2 = animelem=3
trigger3 = animelem=4
trigger4 = animelem=5
priority = 4, Hit
attr = S,SA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
GivePower = 36, 36
pausetime = 10,12
guard.pausetime = 10,10
ground.slidetime = 17
ground.hittime = 17
air.hittime = 20
guard.hittime = 14
guard.ctrltime =14
ground.velocity = -8
air.velocity = -3,-8
yaccel = 0.55
guard.velocity = -8
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
fall = 0
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 1000, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem=6
priority = 4, Hit
attr = S,SA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
GivePower = 36, 36
pausetime = 10,12
guard.pausetime = 10,10
ground.slidetime = 17
ground.hittime = 17
air.hittime = 20
guard.hittime = 14
guard.ctrltime =14
ground.velocity = -3,-8
air.velocity = -3,-8
yaccel = 0.55
guard.velocity = -12
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
fall = 1
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem =1
value = 101,0

[State 0, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value =0
ctrl = 1

[State 0, VarSet]
type = VarSet
trigger1 = time=0
v = 33
value = 0

;--------------------------------------------------------------------
;Murderer Chain
[Statedef 1200]
type     = S
movetype = A
physics  = S
juggle   = 0
velset   = 0,0
poweradd = 50
ctrl     = 0
anim     =1200
sprpriority = 2

[state -2, Verset]
type = VarSet
trigger1 = time = 0
var(10) = 0
ignorehitpause = 1
Persistent = 1

[State 1001, Button detected]
type = VarSet
trigger1 = Time = 0
var(10) = ifelse((command="y"),1,ifelse((command="z"),2,0))
IgnoreHitPause = 1
Persistent = 1

[State -3, Distance]
type = VarSet
triggerall = roundstate = 2
trigger1 = Time = 0
trigger1 = !var(10)
v = 1
value = ifelse(P2bodydist X <= 10,2,ifelse((P2bodydist X = [10,20]),1,0))
IgnoreHitPause = 1
Persistent = 1

[State 40, 3]
type = ChangeAnim
trigger1 = Time = 0
value = ifelse(var(10)=1,1201,ifelse(var(10)=0,1200,ifelse(var(10)=3,1200,1202)))

[State 3, Sound]
type = PlaySnd
trigger1 = animelem = 3
value = 800,0
channel = 0

[State 800, HitDef]
type = HitDef
trigger1 = EnemyNear,movetype = H
trigger1 = Time = 0
attr = S, ST
hitflag = M+
priority = 1, Miss
sparkno = -1
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 1210
guard.dist = 0
hitSound = S2,800
fall = 1
fall.recover = 0
id = 1200
down.bounce = 0

[State 800, HitDef]
type = HitDef
trigger1 = EnemyNear,movetype != H
trigger1 = Time = 0
attr = S, ST
hitflag = M-
priority = 1, Miss
sparkno = -1
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 1210
guard.dist = 0
hitSound = S2,800
fall = 1
fall.recover = 0
id = 1200
down.bounce = 0

[State 800, ChangeState]
type = ChangeState
Trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Hit conect
[Statedef 1210]
type     = S
movetype = A
physics  = N
anim = 1210
VelSet = 0,0
sprpriority = 1

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 1||AnimElem = 9
value = 2

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 3||AnimElem = 11
value = -1

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810, Target]
type = TargetState
trigger1 = time = 0
value = 1215

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 1
pos = ceil(-20*const(size.xscale)),ceil(-60*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 2
pos = ceil(60*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 3
pos = ceil(80*const(size.xscale)),ceil(-130*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 4
pos = ceil(75*const(size.xscale)),ceil(-135*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 5
pos = ceil(70*const(size.xscale)),ceil(-140*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 6
pos = ceil(45*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 7
pos = ceil(25*const(size.xscale)),ceil(-40*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 8
pos = ceil(-30*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 9
pos = ceil(20*const(size.xscale)),ceil(-60*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 10
pos = ceil(-60*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 11
pos = ceil(-80*const(size.xscale)),ceil(-130*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 12
pos = ceil(-75*const(size.xscale)),ceil(-135*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 13
pos = ceil(-70*const(size.xscale)),ceil(-140*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 14
pos = ceil(-45*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 15
pos = ceil(-25*const(size.xscale)),ceil(-40*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 16
pos = ceil(30*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = 1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 8||AnimElem = 16
value = Ceil(ifelse(var(10)=1,-70,ifelse(var(10)=0,-60,-80))*fvar(10)*(const(data.attack)*0.01))

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4,3
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1200,0
channel = 0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 3||AnimElem = 11
value = 5,1

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 8||AnimElem = 16
value = 1200,1

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 8||AnimElem = 16
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 8
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = -20, 5
ownPal = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 16
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 30, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 8
helperType = Normal
stateNo = 8103
pos = 40,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 8
helperType = Normal
stateNo = 8103
pos = 50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 16
helperType = Normal
stateNo = 8103
pos = -50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 16
helperType = Normal
stateNo = 8103
pos = -60,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, Target]
type = TargetState
triggerall = !NumTarget(1200)
trigger1 = AnimElem = 16
value = 1216

[State 810, Target]
type = TargetState
triggerall = NumTarget(1200) >= 1
triggerall =target(1200),alive = 1
trigger1 = AnimElem = 16
value = 1216

[State 810, Target]
type = TargetState
triggerall = NumTarget(1200) >= 1
triggerall =target(1200),life <= 0
trigger1 = AnimElem = 16
value = 5150

[State 810, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 1211

;Anim Hit
[Statedef 1211]
type    = A
physics = A
ctrl = 0
anim = 41
sprpriority = 1
velset = -3,-5

[State 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 105, 3]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 52

;Anim Hit
[Statedef 1215]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2


[State 811, Anim]
type = ChangeAnim2
Trigger1 = time = 0
value = 1215

[State 10000, Screen]
type = ScreenBound
trigger1 = 1
movecamera = 0,0

; Dead
[Statedef 1216]
type     = A
movetype = H
physics  = N
velset = -4,-4

[State 600, 4]
type = Gravity
trigger1 =1

[state 821,self]
type = selfstate
trigger1 = Vel Y > 0&&Pos Y >= 0
value = 5050

;========================<Ex Murderer Chain>=============================
[Statedef 1230]
type     = S
movetype = A
physics  = S
juggle   = 0
velset   = 0,0
powerAdd = -500
ctrl     = 0
anim     =1200
sprpriority = 2

[state -2, Verset]
type = VarSet
trigger1 = time = 0
var(10) = 0
ignorehitpause = 1
Persistent = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 104

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State -3, Distance]
type = VarSet
triggerall = roundstate = 2
trigger1 = Time = 0
trigger1 = !var(10)
v = 1
value = ifelse(P2bodydist X <= 10,2,ifelse((P2bodydist X = [10,20]),1,0))
IgnoreHitPause = 1
Persistent = 1

[State 40, 3]
type = ChangeAnim
trigger1 = Time = 0
value = ifelse(var(10)=1,1201,ifelse(var(10)=0,1200,ifelse(var(10)=3,1200,1202)))

[State 3, Sound]
type = PlaySnd
trigger1 = animelem = 3
value = 800,0
channel = 0

[State 800, HitDef]
type = HitDef
trigger1 = EnemyNear,movetype = H
trigger1 = Time = 0
attr = S, ST
hitflag = M+
priority = 1, Miss
sparkno = -1
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 1240
guard.dist = 0
hitSound = S2,800
fall = 1
fall.recover = 0
id = 1200
down.bounce = 0

[State 800, HitDef]
type = HitDef
trigger1 = EnemyNear,movetype != H
trigger1 = Time = 0
attr = S, ST
hitflag = M-
priority = 1, Miss
sparkno = -1
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 1240
guard.dist = 0
hitSound = S2,800
fall = 1
fall.recover = 0
id = 1200
down.bounce = 0

[State 800, ChangeState]
type = ChangeState
Trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Hit conect
[Statedef 1240]
type     = S
movetype = A
physics  = N
anim = 1210
VelSet = 0,0
sprpriority = 1

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 1||AnimElem = 9
value = 2

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 3||AnimElem = 11
value = -1

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810, Target]
type = TargetState
trigger1 = time = 0
value = 1215

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 1
pos = ceil(-20*const(size.xscale)),ceil(-60*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 2
pos = ceil(60*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 3
pos = ceil(80*const(size.xscale)),ceil(-130*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 4
pos = ceil(75*const(size.xscale)),ceil(-135*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 5
pos = ceil(70*const(size.xscale)),ceil(-140*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 6
pos = ceil(45*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 7
pos = ceil(25*const(size.xscale)),ceil(-40*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 8
pos = ceil(-30*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 9
pos = ceil(20*const(size.xscale)),ceil(-60*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 10
pos = ceil(-60*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 11
pos = ceil(-80*const(size.xscale)),ceil(-130*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 12
pos = ceil(-75*const(size.xscale)),ceil(-135*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 13
pos = ceil(-70*const(size.xscale)),ceil(-140*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 14
pos = ceil(-45*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 15
pos = ceil(-25*const(size.xscale)),ceil(-40*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 16
pos = ceil(30*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = 1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 8||AnimElem = 16
value = Ceil(-97 *fvar(10)*(const(data.attack)*0.01))

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4,3
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 195,1
channel = 0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 3||AnimElem = 11
value = 5,1

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 8||AnimElem = 16
value = 1200,1

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 8||AnimElem = 16
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 8
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = -20, 5
ownPal = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 16
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 30, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 8
helperType = Normal
stateNo = 8103
pos = 40,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 8
helperType = Normal
stateNo = 8103
pos = 50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 16
helperType = Normal
stateNo = 8103
pos = -50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 16
helperType = Normal
stateNo = 8103
pos = -60,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, Target]
type = TargetState
triggerall = !NumTarget(1200)
trigger1 = AnimElem = 16
value = 1216

[State 810, Target]
type = TargetState
triggerall = NumTarget(1200) >= 1
triggerall =target(1200),alive = 1
trigger1 = AnimElem = 16
value = 1216

[State 810, Target]
type = TargetState
triggerall = NumTarget(1200) >= 1
triggerall =target(1200),life <= 0
trigger1 = AnimElem = 16
value = 5150

[State 810, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 1211

;---------------------------------------------------------------------------
;Bandit Chain
[Statedef 1300]
type     = S
movetype = A
physics  = S
juggle   = 0
velset   = 0,0
poweradd = 50
ctrl     = 0
anim     =1200
sprpriority = 2

[state -2, Verset]
type = VarSet
trigger1 = time = 0
var(10) = 0
ignorehitpause = 1
Persistent = 1

[State 1001, Button detected]
type = VarSet
trigger1 = Time = 0
var(10) = ifelse((command="b"),1,ifelse((command="c"),2,0))
IgnoreHitPause = 1
Persistent = 1

[State -3, Distance]
type = VarSet
triggerall = roundstate = 2
trigger1 = Time = 0
trigger1 = !var(1)
v = 1
value = ifelse(P2bodydist X <= 10,2,ifelse((P2bodydist X = [10,20]),1,0))
IgnoreHitPause = 1
Persistent = 1

[State 40, 3]
type = ChangeAnim
trigger1 = Time = 0
value = ifelse(var(10)=1,1201,ifelse(var(10)=0,1200,ifelse(var(10)=3,1200,1202)))

[State 3, Sound]
type = PlaySnd
trigger1 = animelem = 3
value = 800,0
channel = 0

[State 800, HitDef]
type = HitDef
trigger1 = EnemyNear,movetype = H
trigger1 = Time = 0
attr = S, ST
hitflag = M+
priority = 1, Miss
sparkno = -1
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 1310
guard.dist = 0
hitsound   = S2,800
fall = 1
fall.recover = 0
id = 1300
down.bounce = 0

[State 800, HitDef]
type = HitDef
trigger1 = EnemyNear,movetype != H
trigger1 = Time = 0
attr = S, ST
hitflag = M-
priority = 1, Miss
sparkno = -1
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 1310
guard.dist = 0
hitsound   = S2,800
fall = 1
fall.recover = 0
id = 1300
down.bounce = 0

[State 800, ChangeState]
type = ChangeState
Trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Hit conect
[Statedef 1310]
type     = S
movetype = A
physics  = N
anim = 1310
sprpriority =  -1

[State 210, 3]
type = Turn
trigger1 = animtime = 0

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 5
value = 2

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 6
value = -1

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810,***]
type = TargetState
trigger1 = time = 0
value = 1315

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 1
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 4
pos = ceil(-10*const(size.xscale)),ceil(-100*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 = AnimElem = 5
pos = ceil(-30*const(size.xscale)),ceil(-80*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 = AnimElem = 6
pos = ceil(0*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 7
pos = ceil(80*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 10
pos = ceil(-10*const(size.xscale)),ceil(-100*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 = AnimElem = 11
pos = ceil(-40*const(size.xscale)),ceil(-150*const(size.yscale))
postype = P1
time = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 8
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 50, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 8
helperType = Normal
stateNo = 8103
pos = 10,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 8
helperType = Normal
stateNo = 8103
pos = 0,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, Target]
type = TargetState
trigger1 = AnimElem = 11
value = 1316

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4,0
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 10
value = 1,5
channel = 1

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 10
value = 0,4

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 1
value = 5,0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 7
value = 1200,1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 7||AnimElem = 11
value = Ceil(ifelse(var(10)=1,-70,ifelse(var(10)=0,-60,-80))*fvar(10)*(const(data.attack)*0.01))

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 7
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 810, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Anim Hit
[Statedef 1315]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2

[State 811, Anim]
type = ChangeAnim2
Trigger1 = time = 0
value = 1315

[State 10000, Screen]
type = ScreenBound
trigger1 = 1
movecamera = 0,0

;Dead
[Statedef 1316]
type     = S
movetype = H
physics  = N
velset   = 5,-3

[State 600, 4]
type = Gravity
trigger1 =1

[state 821,self]
type = selfstate
trigger1 = Vel Y > 0&&Pos Y >= 0
value = 5050

;========================<Ex Bandit Chain>=============================
[Statedef 1330]
type     = S
movetype = A
physics  = S
juggle   = 0
velset   = 0,0
powerAdd = -500
ctrl     = 0
anim     =1200
sprpriority = 2

[state -2, Verset]
type = VarSet
trigger1 = time = 0
var(10) = 0
ignorehitpause = 1
Persistent = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 104

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State -3, Distance]
type = VarSet
triggerall = roundstate = 2
trigger1 = Time = 0
trigger1 = !var(1)
v = 1
value = ifelse(P2bodydist X <= 10,2,ifelse((P2bodydist X = [10,20]),1,0))
IgnoreHitPause = 1
Persistent = 1

[State 40, 3]
type = ChangeAnim
trigger1 = Time = 0
value = ifelse(var(10)=1,1201,ifelse(var(10)=0,1200,ifelse(var(10)=3,1200,1202)))

[State 3, Sound]
type = PlaySnd
trigger1 = animelem = 3
value = 800,0
channel = 0

[State 800, HitDef]
type = HitDef
trigger1 = EnemyNear,movetype = H
trigger1 = Time = 0
attr = S, ST
hitflag = M+
priority = 1, Miss
sparkno = -1
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 1340
guard.dist = 0
hitsound   = S2,800
fall = 1
fall.recover = 0
id = 1300
down.bounce = 0

[State 800, HitDef]
type = HitDef
trigger1 = EnemyNear,movetype != H
trigger1 = Time = 0
attr = S, ST
hitflag = M-
priority = 1, Miss
sparkno = -1
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 1340
guard.dist = 0
hitsound   = S2,800
fall = 1
fall.recover = 0
id = 1300
down.bounce = 0

[State 800, ChangeState]
type = ChangeState
Trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Hit conect
[Statedef 1340]
type     = S
movetype = A
physics  = N
anim = 1310
sprpriority =  -1

[State 210, 3]
type = Turn
trigger1 = animtime = 0

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 5
value = 2

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 6
value = -1

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810,***]
type = TargetState
trigger1 = time = 0
value = 1315

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 1
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 4
pos = ceil(-10*const(size.xscale)),ceil(-100*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 = AnimElem = 5
pos = ceil(-30*const(size.xscale)),ceil(-80*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 = AnimElem = 6
pos = ceil(0*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 7
pos = ceil(80*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 10
pos = ceil(-10*const(size.xscale)),ceil(-100*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 = AnimElem = 11
pos = ceil(-40*const(size.xscale)),ceil(-150*const(size.yscale))
postype = P1
time = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 8
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 50, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 8
helperType = Normal
stateNo = 8103
pos = 10,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 8
helperType = Normal
stateNo = 8103
pos = 0,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, Target]
type = TargetState
trigger1 = AnimElem = 11
value = 1316

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4,0
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 10
value = 1,5
channel = 1

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 10
value = 0,4

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 1
value = 5,0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 7
value = 1200,1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 7||AnimElem = 11
value = Ceil(-97 *fvar(10)*(const(data.attack)*0.01))

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 7
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 810, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
;AERIAL Bull Horn (SF V)
[Statedef 1400]
type = S
physics = S
moveType = A
ctrl=0
velset=0,0
sprpriority=1
poweradd=72*!var(20)
facep2=1

[State 1200, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1200, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1200, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 0, 1400, ifElse(var(10) = 1, 1401, 1402))

[State 40, Dust]
type = helper
trigger1 = ANIMELEM = 6
stateno = 8100
ID = 8100
name = "Jump Dust"
postype = p1
ownpal = 1

[State 1000, Vel]
type = veladd
trigger1 = animelem = 6
x = ifelse(var(10) = 2, 2.5, ifelse(var(10) = 1, 1.75, 1))
y = ifelse(var(10) = 2, -9.1, ifelse(var(10) = 1, -8.3, -7.5))

[State Accel]
type = veladd
trigger1 = AnimElemTime(6) >= 0
y = 0.61

[State 1000, StateTypeSet: Air, Physics: None]
type = StateTypeSet
trigger1 = animelem = 6
stateType = A
physics = N

[State 1000, PlaySnd]
type = PlaySnd
trigger1 = animelem = 4
value = 1400,0
channel = 0

[State 1300, PlaySnd]
type = PlaySnd
trigger1 = animelem = 6
value = 41,0
channel = 1

[State 1200, Hit]
type=hitdef
trigger1= !var(16) && (var(15)<15 || var(20))
trigger1= animelem = 6
ID = 1400
attr = S,SA
hitflag = HAF
guardflag = M
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 90, ifElse(var(10), 83, 76)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 90, ifElse(var(10), 83, 76)))), 7
getpower = ifelse(!var(13), 216, 72)*!var(20), 36*!var(20)
givepower = 36, 36
pausetime = ifelse(var(20), 6, 12), ifelse(var(20), 6, 12)
guard.pausetime = ifelse(var(20), 6, 12), ifelse(var(20), 6, 12)
animtype = Hard
air.animtype = back
fall.animtype = back
ground.type = Low
air.type = Low
ground.hittime = 18
ground.slidetime = 18
guard.hittime = 18
air.hittime = 120
ground.velocity = -4,-8
ground.cornerpush.veloff = 0
guard.velocity = ifelse(var(20), -9.61, -12.89)
guard.cornerpush.veloff = 0
air.velocity = -4,-8
air.cornerPush.velOff = 0
yaccel = .45
fall = 1
air.fall = 1
fall.recover = 0
fall.recovertime = 120
forcestand = 1
hitsound = -1 + 0*(var(31):=2)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8001)
sparkxy = -10 + 0*(var(35):=92), var(36):=-77
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1400, End]
type = ChangeState
trigger1 = pos y > -vel y
value = 1405

;---Land---
[Statedef 1405]
type=S
physics=N
movetype=I
ctrl=0
anim=1405
velset=0,0
sprpriority=1
movehitpersist=1

[State 1010, Pos]
type=posset
trigger1= 1
y=0

[State 1010, Snd]
type=playsnd
trigger1= !time
value=0,52

[State 1010, Dust]
type=explod
trigger1= !time
anim=8102
sprpriority=-3
postype=p1
scale=.5,.5
pausemovetime=-1
supermovetime=-1
ownpal=1

[State 1010, End]
type=changestate
trigger1= !animtime
value=0
ctrl=1

[Statedef 1450]
type     = S
movetype = A
physics  = S
juggle   = 0
velset   = 0,0
powerAdd = -500
ctrl     = 0
anim     =1450
sprpriority = 2

[state -2, Verset]
type = VarSet
trigger1 = time = 0
var(10) = 0
ignorehitpause = 1
Persistent = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 104

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = animelem = 3
value = 1400,0
channel = 0

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 5
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 4]
type = VelSet
trigger1 = Animelem = 5
x = 12

[State 4]
type = VelSet
trigger1 = Animelem = 8
x = 0

[State 1000, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 7
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 45 < 7, 7, fvar(11) * 45)), 15
getPower = 0,0
givePower = 36, 36
pauseTime = 3,3
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 17 + 4 * var(9)
guard.hitTime = 14
air.hitTime = 120
ground.velocity = -2, 0
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -3.36, -6.52)
guard.cornerPush.velOff = 0
air.velocity = ifElse(var(20), -2.36, -4), -7.5
air.cornerPush.velOff = 0
yAccel = ifElse(var(20),.5,.6)
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
trigger1 = AnimElem = 8
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 45 < 7, 7, fvar(11) * 45)), 15
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Up
air.animType = Up
fall.animType = Up
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 17 + 4 * var(9)
guard.hitTime = 14
air.hitTime = 120
ground.velocity = -3, -12
ground.cornerPush.velOff = 0
guard.velocity = ifElse(var(20), -3.36, -6.52)
guard.cornerPush.velOff = 0
air.velocity = ifElse(var(20), -2.36, -4), -7.5
air.cornerPush.velOff = 0
yAccel = ifElse(var(20),.5,.6)
fall = 1
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -70
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1


;PUNCH ZERO COUNTER
[STATEDEF 2900]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0, 0
sprpriority = 1
poweradd = 0
faceP2 = 1

[STATE 2900,POSSET]
type=posset
trigger1=!time
y=0

[STATE 2900,ANIM]
type=changeanim
trigger1=!time
value=2900

[STATE 2900,DUST]
type = helper
trigger1 = Animelem=3
stateno = 8100
ID = 8100
name = "Jump Dust"
postype = p1
ownpal = 1

[STATE 2900,WIDTH]
type = Width
trigger1 = 1
edge = 30,0

[STATE 2900,NOT HIT BY]
type = NotHitBy
trigger1 = Anim = 2900
trigger1 = AnimElemNo(0) = [1,5]
value = SCA
time = 1

[STATE 2900,HIT]
type=hitdef
trigger1= !var(16) && (var(15)<15 || var(20))
trigger1= !Time
ID = 2900
attr = S,SA
hitflag = MAF
guardflag = M
damage = ceil(ifelse(fvar(11) * 100 < 7, 7, fvar(11) * 100)), 7
getpower = 0
givepower = 0, 0
pausetime = ceil(13*(2-(var(20)>0))/2),ceil(13*(2-(var(20)>0))/2)
guard.pausetime = ceil(10*(2-(var(20)>0))/2),ceil(10*(2-(var(20)>0))/2)
animtype = Heavy
air.animtype = Heavy
fall.animtype = Diagup
ground.type = hIGH
air.type = Low
ground.hittime = 18
ground.slidetime = 18
guard.hittime = 9 - var(10)
air.hittime = 120
ground.velocity = -3,-7.5
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2,-7
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forcestand = 1
hitsound = -1 + 0*(var(31):=2)
guardsound = -1 + 0*(var(32):=0)
sparkno = S-1 + 0*(var(33):=8013)
guard.sparkno = S-1 + 0*(var(34):=8001)
sparkxy = -10 + 0*(var(35):=92), var(36):=-77
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envshake.freq = 120

[STATE 2900,IDLE]
type = StateTypeSet
trigger1 = AnimElemTime(5) >= 0
moveType = I

[STATE 2900,CHANGE STATE]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
 
;KICK ZERO COUNTER
[STATEDEF 2910]
type = S
physics = N
movetype = A
ctrl = 0
velset = 0, 0
sprpriority = 1
poweradd = 0

[STATE 2910,POSSET]
type=posset
trigger1=!time
y=0

[STATE 2910,ANIM]
type=changeanim
trigger1=!time
value=2910

[STATE 2910,NOT HIT BY]
type = nothitby
trigger1 = animelemtime(6) < 0
value = SCA
time = 1
ignorehitpause = 1

[STATE 2910,WIDTH]
type = Width
trigger1 = 1
edge = 40,0

[STATE 2910,HIT]
type = hitdef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = !Time
ID = 2910
attr = S, SA
hitFlag = MAF
guardFlag = M
damage =ceil(ifelse(fvar(11) * 100 < 7, 7, fvar(11) * 100)), 7
getPower = 0, 0
givePower = 0, 0
pausetime = ceil(13*(2-(var(20)>0))/2),ceil(13*(2-(var(20)>0))/2)
guard.pausetime = ceil(10*(2-(var(20)>0))/2),ceil(10*(2-(var(20)>0))/2)
animType = Back
air.animType = Back
fall.animType = Diagup
ground.type = High
air.type = Low
ground.hitTime = 18 + 4 * var(9)
ground.slideTime = 18 + 4 * var(9)
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6,-5.5
ground.cornerPush.velOff = 0
guard.velocity = -6
guard.cornerPush.velOff = 0
air.velocity = -6.46, -4.25
air.cornerPush.velOff = 0
yaccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
hitsound = -1 + 0*(var(31):=5)
guardsound = -1 + 0*(var(32):=0)
sparkno = S-1 + 0*(var(33):=8013)
guard.sparkno = S-1 + 0*(var(34):=8001)
sparkxy = -10 + 0*(var(35):=76), var(36):=-83
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48

[STATE 2910,IDLE]
type = StateTypeSet
trigger1 = AnimElemTime(4) >= 0
movetype = I

[STATE 2910,CHANGE STATE]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1