; _________________________________________
;| Character by Author Name                |
; ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
;==============================================================================================
;========================================<SUPER MOVES>========================================
;==============================================================================================

;---------------------------------------------------------------------------
;Bull Revenger
[StateDef 3000]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 1001, Button Detected]
type = VarSet
Triggerall = PrevStateno != 3000
trigger1 = Time = 0
var(10) = ifelse(command="z" || command="c",2,ifelse(command="y" || command="b",1,0))
IgnoreHitPause = 1
Persistent = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NHB]
type = nothitby
trigger1 = 1
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(50 * const(size.xScale)), ceil(-70 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 44
moveTime = 44
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = 3000,0
channel = 0

[State 3000, Jump Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 3000,1
channel = 1

[State 3000, StateTypeSet: Air, Physics: None]
type = StateTypeSet
trigger1 = AnimElem = 6
stateType = A
physics = N

[State 3000, Dust Helper]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8100
ID = 8100
name = "Dust"
posType = P1
ownPal = 1

[State 3000, VelSet]
type = VelSet
trigger1 = Animelem = 2
trigger1 = var(10) = 0
x = 10
y = -13
Persistent = 1

[State 3000, VelSet]
type = VelSet
trigger1 = Animelem = 2
trigger1 = var(10) = 1
x = 20
y = -13
Persistent = 1

[State 3000, VelSet]
type = VelSet
trigger1 = Animelem = 2
trigger1 = var(10) = 2
x = 30
y = -13
Persistent = 1

[State 3000, VelAdd]
type = Veladd
trigger1 = Animelem = 2, >= 0
y = 1
Persistent = 1

[State 3000, ChangeState]
type = ChangeState
trigger1 = pos y > -vel y
value = 3001

;Throw
[StateDef 3001]
type = S
anim = 3001
physics = N
moveType = A
velSet = 0,0
sprpriority = 2

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3001, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0

[State 3001, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 800,0
channel = 0

[State 3001, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 800, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype = H
trigger1 = Time = 0
attr = S, HT
hitflag = M+
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3002
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3002
down.bounce = 0

[State 800, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype != H
trigger1 = Time = 0
attr = S, HT
hitflag = M-
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3002
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3002
down.bounce = 0

[State 3001, ChangeState]
type = ChangeState
Trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Conect
[StateDef 3002]
type = S
anim = 3011
physics = N
moveType = I
velSet = 0,0
sprpriority =  -1

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 5||AnimElem = 10||AnimElem = 18
value = 2

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 6||AnimElem = 12||AnimElem = 20
value = -1

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810, TargetState]
type = TargetState
trigger1 = time = 0
value = 3003

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 1
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 4
pos = ceil(-10*const(size.xscale)),ceil(-100*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 5
pos = ceil(-30*const(size.xscale)),ceil(-80*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 6
pos = ceil(0*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 7
pos = ceil(80*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 10
pos = ceil(-20*const(size.xscale)),ceil(-60*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 11
pos = ceil(60*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 12
pos = ceil(80*const(size.xscale)),ceil(-130*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 13
pos = ceil(75*const(size.xscale)),ceil(-135*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 14
pos = ceil(70*const(size.xscale)),ceil(-140*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 15
pos = ceil(45*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 16
pos = ceil(25*const(size.xscale)),ceil(-40*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 17
pos = ceil(-30*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 18
pos = ceil(20*const(size.xscale)),ceil(-60*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 19
pos = ceil(-60*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 20
pos = ceil(-80*const(size.xscale)),ceil(-130*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 21
pos = ceil(-75*const(size.xscale)),ceil(-135*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 22
pos = ceil(-70*const(size.xscale)),ceil(-140*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 23
pos = ceil(-45*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 24
pos = ceil(-25*const(size.xscale)),ceil(-40*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 25
pos = ceil(30*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = 1

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 3010,0
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 12
value = 4,1
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 21
value = 3010,1
channel = 0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 1||AnimElem = 12||AnimElem = 21
value = 5,0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 7||AnimElem = 17||AnimElem = 25
value = 1200,1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 7||AnimElem = 17
value = Ceil(-60*fvar(10)*(const(data.attack)*0.01))
kill = 0

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 25
value = Ceil(-84*fvar(10)*(const(data.attack)*0.01))

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 7||AnimElem = 17||AnimElem = 25
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 7
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 50, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 7
helperType = Normal
stateNo = 8103
pos = -50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 7
helperType = Normal
stateNo = 8103
pos = -60,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 17
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = -20, 5
ownPal = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 25
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 30, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 17
helperType = Normal
stateNo = 8103
pos = 40,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 17
helperType = Normal
stateNo = 8103
pos = 50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 25
helperType = Normal
stateNo = 8103
pos = -50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 25
helperType = Normal
stateNo = 8103
pos = -60,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, TargetState]
type = TargetState
triggerall = !NumTarget(3002)
trigger1 = AnimElem = 25
value = 1216

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3002) >= 1
triggerall =target(3002),alive = 1
trigger1 = AnimElem = 25
value = 1216

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3002) >= 1
triggerall =target(3002),life <= 0
trigger1 = AnimElem = 25
value = 5150

[State 810, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 1211

;Anim Player 2
[Statedef 3003]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2

[State 811, Anim]
type = ChangeAnim2
Trigger1 = time = 0
value = 3016

[State 10000, Screen]
type = ScreenBound
trigger1 = 1
movecamera = 0,0

;========================<Max Bull Revenger>=============================
[StateDef 3050]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 1001, Button Detected]
type = VarSet
Triggerall = PrevStateno != 3050
trigger1 = Time = 0
var(10) = ifelse((command="z" && command="y" || command="c" && command="b"),2,ifelse((command="z" && command="x" || command="c" && command="a"),1,0))
IgnoreHitPause = 1
Persistent = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NHB]
type = nothitby
trigger1 = 1
time = 1
value = SCA

[State 3050, Super Pause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(50 * const(size.xScale)), ceil(-70 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3050, Super Pause]
type = SuperPause
trigger1 = Time = 3
time = 44
moveTime = 44
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = 3000,0
channel = 0

[State 3000, Jump Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 3000,1
channel = 1

[State 3050, StateTypeSet: Air, Physics: None]
type = StateTypeSet
trigger1 = AnimElem = 6
stateType = A
physics = N

[State 3050, Dust Helper]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8100
ID = 8100
name = "Dust"
posType = P1
ownPal = 1

[State 3000, VelSet]
type = VelSet
trigger1 = Animelem = 2
trigger1 = var(10) = 0
x = 10
y = -13
Persistent = 1

[State 3000, VelSet]
type = VelSet
trigger1 = Animelem = 2
trigger1 = var(10) = 1
x = 20
y = -13
Persistent = 1

[State 3000, VelSet]
type = VelSet
trigger1 = Animelem = 2
trigger1 = var(10) = 2
x = 30
y = -13
Persistent = 1

[State 3000, VelAdd]
type = Veladd
trigger1 = Animelem = 2, >= 0
y = 1
Persistent = 1

[State 3000, ChangeState]
type = ChangeState
trigger1 = pos y > -vel y
value = 3051

;Throw
[StateDef 3051]
type = S
anim = 3001
physics = N
moveType = A
velSet = 0,0
sprpriority = 2

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(3) < 0
time = 1
value = SCA

[State 3001, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0

[State 3001, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 800,0
channel = 0

[State 3051, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 800, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype = H
trigger1 = Time = 0
attr = S, HT
hitflag = M+
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3052
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3052
down.bounce = 0

[State 800, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype != H
trigger1 = Time = 0
attr = S, HT
hitflag = M-
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3052
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3052
down.bounce = 0

[State 3001, ChangeState]
type = ChangeState
Trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Conect
[StateDef 3052]
type = S
anim = 3012
physics = N
moveType = A
velSet = 0,0

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 5||AnimElem = 11||AnimElem = 16||AnimElem = 24
value = 2

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 6||AnimElem = 12||AnimElem = 18||AnimElem = 26
value = -1

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810, TargetState]
type = TargetState
trigger1 = time = 0
value = 3053

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 1
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 4||AnimElem = 10
pos = ceil(-10*const(size.xscale)),ceil(-100*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 5||AnimElem = 11
pos = ceil(-30*const(size.xscale)),ceil(-80*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 6||AnimElem = 12
pos = ceil(0*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 7||AnimElem = 13
pos = ceil(80*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 16
pos = ceil(-20*const(size.xscale)),ceil(-60*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 17
pos = ceil(60*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 18
pos = ceil(80*const(size.xscale)),ceil(-130*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 19
pos = ceil(75*const(size.xscale)),ceil(-135*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 20
pos = ceil(70*const(size.xscale)),ceil(-140*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 21
pos = ceil(45*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 22
pos = ceil(25*const(size.xscale)),ceil(-40*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 23
pos = ceil(-30*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 24
pos = ceil(20*const(size.xscale)),ceil(-60*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 25
pos = ceil(-60*const(size.xscale)),ceil(-70*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 26
pos = ceil(-80*const(size.xscale)),ceil(-130*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 27
pos = ceil(-75*const(size.xscale)),ceil(-135*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 28
pos = ceil(-70*const(size.xscale)),ceil(-140*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 29
pos = ceil(-45*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 30
pos = ceil(-25*const(size.xscale)),ceil(-40*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 31
pos = ceil(30*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = 1

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 3010,0
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 19
value = 4,1
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 27
value = 3010,1
channel = 0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 1||AnimElem = 10||AnimElem = 19||AnimElem = 27
value = 5,0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 7||AnimElem = 13||AnimElem = 23||AnimElem = 31
value = 1200,1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 7||AnimElem = 13||AnimElem = 23
value = Ceil(-84*fvar(10)*(const(data.attack)*0.01))
kill = 0

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 31
value = Ceil(-80*fvar(10)*(const(data.attack)*0.01))

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 7||AnimElem = 13||AnimElem = 23||AnimElem = 31
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 7
trigger2 = AnimElem = 13
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 50, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 7
trigger2 = AnimElem = 13
helperType = Normal
stateNo = 8103
pos = -50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 7
trigger2 = AnimElem = 13
helperType = Normal
stateNo = 8103
pos = -60,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 23
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = -20, 5
ownPal = 1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 31
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 30, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 23
helperType = Normal
stateNo = 8103
pos = 40,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 23
helperType = Normal
stateNo = 8103
pos = 50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 31
helperType = Normal
stateNo = 8103
pos = -50,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 31
helperType = Normal
stateNo = 8103
pos = -60,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, TargetState]
type = TargetState
triggerall = !NumTarget(3052)
trigger1 = AnimElem = 31
value = 1216

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3052) >= 1
triggerall =target(3052),alive = 1
trigger1 = AnimElem = 31
value = 1216

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3052) >= 1
triggerall =target(3052),life <= 0
trigger1 = AnimElem = 31
value = 5150

[State 810, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 1211

;Anim Player 2
[Statedef 3053]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2

[State 811, Anim]
type = ChangeAnim2
Trigger1 = time = 0
value = 3017

[State 10000, Screen]
type = ScreenBound
trigger1 = 1
movecamera = 0,0



;-----------------------------------------------
;Angry Bull

[StateDef 3100]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(25 * const(size.xScale)), ceil(-20 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 44
moveTime = 44
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4,3
channel = 0

[State 3100, Woosh Sound 1]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 800, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype = H
trigger1 = Time = 0
attr = S, HT
hitflag = M+
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3101
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3101
down.bounce = 0

[State 800, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype != H
trigger1 = Time = 0
attr = S, HT
hitflag = M-
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3101
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3101
down.bounce = 0

[State 200, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Conect Kick
[Statedef 3101]
type     = S
movetype = A
physics  = N
anim = 3110
sprpriority =  3

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810, TargetState]
type = TargetState
trigger1 = time = 0
value = 3115

[State 810, TargetState]
type = TargetState
trigger1 = AnimElem = 6
value = 3116

[State -2, Varset]
type = Varset
Trigger1 = PrevStateno != 3101
trigger1 = time = 0
var(2) = 0

[State -2, Varadd]
type = Varadd
trigger1 = AnimElem = 7
var(2) = 1
Persistent = 1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 1
pos = ceil(40*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 3
pos = ceil(60*const(size.xscale)),ceil(-50*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 4
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 4
trigger2 = AnimElem = 7
value = 4,1
channel = 0

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 4
trigger2 = AnimElem = 7
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 50, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 4
trigger2 = AnimElem = 7
helperType = Normal
stateNo = 8103
pos = 10,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 4
trigger2 = AnimElem = 7
helperType = Normal
stateNo = 8103
pos = 0,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 4||AnimElem = 7
value = Ceil(-30*fvar(10)*(const(data.attack)*0.01))
kill = 0

[State -2, Sound]
type = PlaySnd
trigger1 = AnimElem = 4||AnimElem = 7
value = 1, 3
ignorehitpause = 1

[State -2, Sound]
type = PlaySnd
trigger1 = AnimElem = 4||AnimElem = 7
value = 2, 2
ignorehitpause = 1

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 4||AnimElem = 7
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 810, ChangeState]
type = ChangeState
trigger1 = var(2) = 3
trigger1 = AnimTime = 0
value = 3102

;Conect Kick 2
[Statedef 3102]
type     = S
movetype = A
physics  = N
anim = 3111
sprpriority =  3

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810, TargetState]
type = TargetState
trigger1 = AnimElem = 1
value = 3117

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 1
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 5
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = 1

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 1
value = 180,0
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = time = 60
value = 184,0
channel = 0

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 5
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 50, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 5
helperType = Normal
stateNo = 8103
pos = 10,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 5
helperType = Normal
stateNo = 8103
pos = 0,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 5
value = Ceil(-60*fvar(10)*(const(data.attack)*0.01))

[State -2, Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 1, 4
ignorehitpause = 1

[State -2, Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 2, 5
ignorehitpause = 1

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 5
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 810, TargetState]
type = TargetState
triggerall = !NumTarget(3101)
trigger1 = AnimElem = 6
value = 816

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3101) >= 1
triggerall =target(3101),alive = 1
trigger1 = AnimElem = 6
value = 816

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3101) >= 1
triggerall =target(3101),life <= 0
trigger1 = AnimElem = 6
value = 5150

[State 810, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Anim Player 2
[Statedef 3115]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2

[State 811, Anim]
type = ChangeAnim2
Trigger1 = time = 0
value = 3115

[State 10000, Screen]
type = ScreenBound
trigger1 = 1
movecamera = 0,0

;Anim 2 Player 2
[Statedef 3116]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2

[State 811, Anim]
type = ChangeAnim2
Trigger1 = time = 0
value = 3116

[State 10000, Screen]
type = ScreenBound
trigger1 = 1
movecamera = 0,0

;Anim 3 Player 2
[Statedef 3117]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2

[State 811, Anim]
type = ChangeAnim2
Trigger1 = time = 0
value = 3117

[State 10000, Screen]
type = ScreenBound
trigger1 = 1
movecamera = 0,0

;========================<Max Bull Angry>=============================
[StateDef 3150]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3150, Super Pause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(25 * const(size.xScale)), ceil(-20 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3150, Super Pause]
type = SuperPause
trigger1 = Time = 3
time = 44
moveTime = 44
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, Voice 1]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4,3
channel = 0

[State 3100, Woosh Sound 1]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,5
channel = 1

[State 800, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype = H
trigger1 = Time = 0
attr = S, HT
hitflag = M+
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3151
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3151
down.bounce = 0

[State 800, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype != H
trigger1 = Time = 0
attr = S, HT
hitflag = M-
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3151
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3151
down.bounce = 0

[State 200, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Conect Kick
[Statedef 3151]
type     = S
movetype = A
physics  = N
anim = 3110
sprpriority =  3

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810, TargetState]
type = TargetState
trigger1 = time = 0
value = 3115

[State 810, TargetState]
type = TargetState
trigger1 = AnimElem = 6
value = 3116

[State -2, Varset]
type = Varset
Trigger1 = PrevStateno != 3101
trigger1 = time = 0
var(2) = 0

[State -2, Varadd]
type = Varadd
trigger1 = AnimElem = 7
var(2) = 1
Persistent = 1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 1
pos = ceil(40*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 =  AnimElem = 3
pos = ceil(60*const(size.xscale)),ceil(-50*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 4
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 4
trigger2 = AnimElem = 7
value = 4,1
channel = 0

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 4
trigger2 = AnimElem = 7
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 50, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 4
trigger2 = AnimElem = 7
helperType = Normal
stateNo = 8103
pos = 10,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 4
trigger2 = AnimElem = 7
helperType = Normal
stateNo = 8103
pos = 0,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 4||AnimElem = 7
value = Ceil(-30*fvar(10)*(const(data.attack)*0.01))
kill = 0

[State -2, Sound]
type = PlaySnd
trigger1 = AnimElem = 4||AnimElem = 7
value = 1, 3
ignorehitpause = 1

[State -2, Sound]
type = PlaySnd
trigger1 = AnimElem = 4||AnimElem = 7
value = 2, 2
ignorehitpause = 1

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 4||AnimElem = 7
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 810, ChangeState]
type = ChangeState
trigger1 = var(2) = 5
trigger1 = AnimTime = 0
value = 3152

;Conect Kick 2
[Statedef 3152]
type     = S
movetype = A
physics  = N
anim = 3111
sprpriority =  3

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810, TargetState]
type = TargetState
trigger1 = AnimElem = 1
value = 3117

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 1
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, TargetBind]
type = TargetBind
trigger1 = AnimElem = 5
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = 1

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 1
value = 180,0
channel = 0

[State 3, Sound]
type = PlaySnd
trigger1 = time = 60
value = 184,0
channel = 0

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 5
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 50, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 5
helperType = Normal
stateNo = 8103
pos = 10,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 5
helperType = Normal
stateNo = 8103
pos = 0,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 5
value = Ceil(-60*fvar(10)*(const(data.attack)*0.01))

[State -2, Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 1, 4
ignorehitpause = 1

[State -2, Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 2, 5
ignorehitpause = 1

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 5
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 810, TargetState]
type = TargetState
triggerall = !NumTarget(3101)
trigger1 = AnimElem = 6
value = 816

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3101) >= 1
triggerall =target(3101),alive = 1
trigger1 = AnimElem = 6
value = 816

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3101) >= 1
triggerall =target(3101),life <= 0
trigger1 = AnimElem = 6
value = 5150

[State 810, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1


;---------------------------------------------------------------------------
;The Birdie
[StateDef 3200]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NHB]
type = nothitby
trigger1 = 1
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(50 * const(size.xScale)), ceil(-70 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 44
moveTime = 44
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, Voice 1]
type = PlaySnd
Trigger1 = PrevStateno != 3200
trigger1 = time = 0
value = 730, 1
channel = 0
Persistent = 1

[State 3200, Voice 2]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4,0
channel = 1

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,4
channel = 2

[State 40, 3]
type = ChangeAnim
triggerall = animelemtime(2) > 0 && animelemtime(3) <  0
trigger1 = P2Dist x <= 90
value = 3200
elem = 3

[State 1200, 9]
type = Width
trigger1 = animelemtime(3) >= 0&&animelemtime(6) <  0
value =60,0

[State 1]
type = NotHitBy
trigger1 = time <= 21
value = SCA

[State 4]
type = VelSet
trigger1 = Animelem = 2
x = 6
Persistent = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 101,0
channel = 3

[State 200, ChangeState]
type = ChangeState
trigger1 = Time = 40
value = 3201

;Continue Hits
[Statedef 3201]
type = S
movetype = A
physics = N
juggle   = 3
ctrl = 0
sprpriority = 2
anim = 3201

[State 0, NotHitBy]
type = NotHitBy
trigger1 = time = 0
value = SCA, NA, SA, NP, SP, NT, ST
time = 12

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000,0]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = time = 0
priority = 4, Hit
attr = S,HA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 7
getPower = 0,0
givePower = 36, 36
pausetime = 10,10
guard.pausetime = 10,10
ground.slidetime = 20
ground.hittime = 20
air.hittime = 20
guard.hittime = 17
guard.ctrltime =17
ground.velocity = -4
air.velocity = -3,-10
yaccel = 0.55
guard.velocity = -4
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
fall = 0
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4,1
channel = 0

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,4
channel = 1

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 101,0
channel = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 4
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >=26
x = 4

[State 0, VelSet]
type = VelSet
trigger1 = time >=28
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >=31
x = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = p2bodydist X <=40
trigger1=time<25
trigger2=time=26
value =3202
ctrl = 0

;Conect Hits Part 2
[Statedef 3202]
type = S
movetype = A
physics = N
velset = 0, 0
ctrl = 0
anim = 3202
juggle = 0
poweradd = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = time = 0
value = SCA, NA, SA, NP, SP, NT, ST
time = 12

[State 105, Dust Helper]
type = Helper
trigger1 = AnimElem= 2
trigger2 = AnimElem= 11
trigger3 = AnimElem= 18
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000,0]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = animelem=2
trigger2 = animelem=11
priority = 4, Hit
attr = S,HA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
getPower = 0,0
givePower = 36, 36
pausetime = 10,18
guard.pausetime = 10,12
ground.slidetime = 20
ground.hittime = 20
air.hittime = 20
guard.hittime = 17
guard.ctrltime =20
ground.velocity = -6
air.velocity = -3,-10
yaccel = 0.55
guard.velocity = -6
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
fall = 0
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 1000,0]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = animelem=18
priority = 4, Hit
attr = S,HA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getPower = 0,0
givePower = 36, 36
pausetime = 12,20
guard.pausetime = 12,12
ground.slidetime = 25
ground.hittime = 20
air.hittime = 20
guard.hittime = 17
guard.ctrltime =22
ground.velocity = -6,-8
air.velocity = -4,-8
yaccel = 0.55
guard.velocity = -12
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
fall = 1
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 11
trigger3 = AnimElem = 18
value = 4,1
channel = 0

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 11
trigger3 = AnimElem = 18
value = 1,4
channel = 1

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 11
trigger3 = AnimElem = 18
value = 101,0
channel = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 0
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >= 4
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 6
x = 1

[State 0, VelSet]
type = VelSet
trigger1 = time >= 8
x = 0

[State 0, VelSet]
type = VelSet
trigger1 = time >= 21
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >= 25
x = 4

[State 0, VelSet]
type = VelSet
trigger1 = time >= 27
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 30
x = 0

[State 0, VelSet]
type = VelSet
trigger1 = time >= 38
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >= 41
x = 4

[State 0, VelSet]
type = VelSet
trigger1 = time >= 45
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 55
x = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 0
ctrl = 1


[StateDef 3250]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NHB]
type = nothitby
trigger1 = 1
time = 1
value = SCA

[State 3050, Super Pause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(50 * const(size.xScale)), ceil(-70 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3050, Super Pause]
type = SuperPause
trigger1 = Time = 3
time = 44
moveTime = 44
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, Voice 1]
type = PlaySnd
Trigger1 = PrevStateno != 3200
trigger1 = time = 0
value = 730, 1
channel = 0
Persistent = 1

[State 3200, Voice 2]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4,0
channel = 1

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,4
channel = 2

[State 40, 3]
type = ChangeAnim
triggerall = animelemtime(2) > 0 && animelemtime(3) <  0
trigger1 = P2Dist x <= 90
value = 3200
elem = 3

[State 1200, 9]
type = Width
trigger1 = animelemtime(3) >= 0&&animelemtime(6) <  0
value =60,0

[State 1]
type = NotHitBy
trigger1 = time <= 21
value = SCA

[State 4]
type = VelSet
trigger1 = Animelem = 2
x = 6
Persistent = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 101,0
channel = 3

[State 200, ChangeState]
type = ChangeState
trigger1 = Time = 40
value = 3251

;Continue Hits
[Statedef 3251]
type = S
movetype = A
physics = N
juggle   = 3
ctrl = 0
sprpriority = 2
anim = 3201

[State 0, NotHitBy]
type = NotHitBy
trigger1 = time = 0
value = SCA, NA, SA, NP, SP, NT, ST
time = 12

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000,0]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = time = 0
priority = 4, Hit
attr = S,HA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 7
getPower = 0,0
givePower = 36, 36
pausetime = 10,10
guard.pausetime = 10,10
ground.slidetime = 20
ground.hittime = 20
air.hittime = 20
guard.hittime = 17
guard.ctrltime =17
ground.velocity = -4
air.velocity = -3,-10
yaccel = 0.55
guard.velocity = -4
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
fall = 0
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4,1
channel = 0

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,4
channel = 1

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 101,0
channel = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 4
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >=26
x = 4

[State 0, VelSet]
type = VelSet
trigger1 = time >=28
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >=31
x = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = p2bodydist X <=40
trigger1=time<25
trigger2=time=26
value =3252
ctrl = 0

;Conect Hits Part 2
[Statedef 3252]
type = S
movetype = A
physics = N
velset = 0, 0
ctrl = 0
anim = 3202
juggle = 0
poweradd = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = time = 0
value = SCA, NA, SA, NP, SP, NT, ST
time = 12

[State 0, Pause]
type = Pause
trigger1 = time=41
time = 10
movetime = 1
ignorehitpause =1
persistent = 0
pausebg = 0

[State 105, Dust Helper]
type = Helper
trigger1 = AnimElem= 2
trigger2 = AnimElem= 11
trigger3 = AnimElem= 18
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1000,0]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = animelem=2
trigger2 = animelem=11
priority = 4, Hit
attr = S,HA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getPower = 0,0
givePower = 36, 36
pausetime = 10,18
guard.pausetime = 10,12
ground.slidetime = 20
ground.hittime = 20
air.hittime = 20
guard.hittime = 17
guard.ctrltime =20
ground.velocity = -6
air.velocity = -3,-10
yaccel = 0.55
guard.velocity = -6
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
fall = 0
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10

[State 1000,0]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = animelem=18
priority = 4, Hit
attr = S,HA
hitflag = MAF
guardflag = M
animtype = hard
air.animtype = hard
ground.type = high
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 7
getPower = 0,0
givePower = 36, 36
pausetime = 12,20
guard.pausetime = 12,12
ground.slidetime = 25
ground.hittime = 20
air.hittime = 20
guard.hittime = 17
guard.ctrltime =22
ground.velocity = -6,-8
air.velocity = -4,-8
yaccel = 0.55
guard.velocity = -12
ground.cornerpush.veloff = 0
guard.cornerpush.veloff = 0
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
fall = 1
air.fall = 1
fall.recover = 0
envshake.time = 10
envshake.freq = 100
envshake.ampl = 10
fall.envshake.time = 10
fall.envshake.freq = 100
fall.envshake.ampl = 10
p2stateno = 3214

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 11
trigger3 = AnimElem = 18
value = 4,1
channel = 0

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 11
trigger3 = AnimElem = 18
value = 1,4
channel = 1

[State 3200, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = AnimElem = 11
trigger3 = AnimElem = 18
value = 101,0
channel = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 0
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >= 4
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 6
x = 1

[State 0, VelSet]
type = VelSet
trigger1 = time >= 8
x = 0

[State 0, VelSet]
type = VelSet
trigger1 = time >= 21
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >= 25
x = 4

[State 0, VelSet]
type = VelSet
trigger1 = time >= 27
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 30
x = 0

[State 0, VelSet]
type = VelSet
trigger1 = time >= 38
x = 8

[State 0, VelSet]
type = VelSet
trigger1 = time >= 41
x = 4

[State 0, VelSet]
type = VelSet
trigger1 = time >= 45
x = 2

[State 0, VelSet]
type = VelSet
trigger1 = time >= 55
x = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = movehit
trigger1 =animelem=23
value =3253
ctrl = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = !movehit
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Conect Hits Part 3
[Statedef 3253]
type = S
movetype = A
physics = N
juggle   = 3
ctrl = 0
sprpriority = 2
anim = 3203

[State 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 640, Sound]
type = PlaySnd
trigger1 = Animelem = 1
value = 3200, 0
channel = 0

[State 240, Sound]
type = ChangeState
trigger1 = AnimTime = 0
value = 3254

;Conect Hits Part 4
[Statedef 3254]
type = S
movetype = A
physics = N
juggle   = 3
ctrl = 0
sprpriority = 2
anim = 3204

[State 1200, 9]
type = Width
trigger1 = animelemtime(3) >= 0&&animelemtime(6) <  0
trigger2 = animelemtime(11) >= 0&&animelemtime(14) <  0
value =60,0

[State 40, 3]
type = ChangeAnim
triggerall = animelemtime(2) > 0&&animelemtime(3) <  0
trigger1 = P2Dist x <= 90
value = 3204
elem = 3

[State 40, 3]
type = ChangeAnim
triggerall = animelemtime(10) > 0&&animelemtime(11) <  0
trigger1 = P2Dist x <= 90
value = 3204
elem = 11

[State 4]
type = VelSet
trigger1 = Animelem = 2||Animelem = 10
x = 10

[State 4]
type = VelSet
trigger1 = Animelem = 4||Animelem = 12
x = 0

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3
trigger2 = AnimElem= 11
helperType = Normal
stateNo = 8103
pos = 70,10
ID = 8100
name = "Dash Dust"
posType = P1
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 240, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = Animelem = 3
attr = S, HA
animtype  = Hard
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
guardflag = M
pausetime = 6,18
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
ground.type = H
ground.slidetime = 10
ground.hittime  = 60
ground.velocity = -2,-4
air.velocity = -2,-4
envshake.time = 20
envshake.freq = 120
envshake.ampl = -4
envshake.phase = 160
getpower = 0,0
givepower = 36,36
fall = 1
air.fall = 1
fall.recover = 0
Persistent = 1

[State 240, HitDef]
type = HitDef
trigger1 = Animelem = 11
attr = S, HA
animtype  = Hard
damage = ceil(ifElse(fvar(11) * 50 < 7, 7, fvar(11) * 50)), 7
guardflag = M
pausetime = 12,12
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 107), var(36) := -60
ground.type = H
ground.slidetime = 10
ground.hittime  = 30
ground.velocity = -5,-4
air.velocity = -5,-4
envshake.time = 20
envshake.freq = 120
envshake.ampl = -4
envshake.phase = 160
fall = 1
air.fall = 1
fall.recover = 0
getpower = 0,0
givepower = 36,36

[State 640, Sound]
type = PlaySnd
trigger1 = Animelem = 3
value = 4, 0
channel = 0

[State 640, Sound]
type = PlaySnd
trigger1 = Animelem = 11
value = 4, 1
channel = 1

[State 640, Sound]
type = PlaySnd
trigger1 = Animelem = 3||Animelem = 11
value = 1, 4
channel = 2

[State 640, Sound]
type = PlaySnd
trigger1 = Animelem = 3||Animelem = 11
value = 101, 0
channel = 3

[State 240, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Anim Player 2
[Statedef 3214]
type     = S
movetype = H
physics  = N
velset   = 0,0

[State 3011, Anim]
type = ChangeAnim
Trigger1 =  time = 0
value = 5012

[state 3012,self]
type = Changestate
trigger1 = animtime = 0
value = 3215

;Anim 2 Player 2
[Statedef 3215]
type     = A
movetype = H
physics  = N
velset   = -5, -8

[State 3011, Anim]
type = ChangeAnim
Trigger1 =  time = 0
value = 5050

[State 3012, 4]
type = Gravity
trigger1 = 1

[state 3012,self]
type = Changestate
trigger1 = Vel Y > 0&&Pos Y > 0
value = 3216

;Anim 3 Player 2
[Statedef 3216]
type     = L
movetype = H
physics  = N
velset   = 0,0

[State 8]
type = PosSet
trigger1 = time = 0
y = 0

[State 3011, Anim]
type = ChangeAnim
Trigger1 =  time = 0
value = 5110

[state 3012,self]
type = Changestate
trigger1 = time  > 30
value = 3217

;Anim 4 Player 2
[Statedef 3217]
type     = S
movetype = H
physics  = N
velset   = 0,0

[State 3011, Anim]
type = ChangeAnim
Trigger1 =  time = 0
value = 5120

[state 3012,self]
type = Changestate
trigger1 = animtime = 0
value = 3218

;Anim 5 Player 2
[Statedef 3218]
type = S
movetype = H
physics = S
ctrl = 0
velset = 0,0
sprpriority = 2

[State 3011, Anim]
type = ChangeAnim
Trigger1 =  time = 0
value = 5300

[State 9]
type = selfstate
trigger1 = time = 90
value = 0
ctrl = 1




;-----------------------------------------------
;LVL 3 Super
[StateDef 3500]
type = S
physics = S
moveType = A
ctrl = 0
velSet = 0,0
sprpriority = 1
powerAdd = -3000
faceP2 = 1

[State 3500, Anim]
type=changeanim
trigger1=!time
value=3500

[state 3500,Posset]
type=posset
trigger1=!time
y=0

[State 3000, Super Cancel Flag]
type = varset
trigger1 = !time
var(21) = ((prevstateno = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = varset
trigger1 = !time
var(22) = (prevstateno = [3000, 4999]) && var(8)

[State 3000, CC Reset]
type = palfx
trigger1 = !time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = varset
trigger1 = time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 40

[State 3000, Super Cancel Flash]
type = palfx
trigger1 = var(21) || var(22)
trigger1 = !(time % 2) && time <= 12
time = 1
add = 255, 255, 255
ignorehitpause = 1

[State 3000, Super Cancel Juggle]
type = varset
trigger1 = !time
trigger1 = var(21) || var(22)
var(15) = 0
ignorehitpause = 1

[State 3500, Super Pause FX]
type = Helper
trigger1 = animelem = 1
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = 11, -63
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3500, Super Pause]
type = SuperPause
trigger1 = animelem = 1
time = 43
moveTime = 43
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 800, AttackDist]
type = AttackDist
trigger1 = 1
value = 0

[State 800, HitDef]
type = HitDef
trigger1 = AnimElem = 2
attr = S, HT
hitflag = MAF
priority = 5, Hit
getpower = 0,0
givepower = 0,0
hitsound = S200,30
guardsound = S-1,0
fall = 1
fall.recover = 1
numhits = 0
p1stateno = 3501

[State 800, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 3
value = 800,0
channel = 0
volumescale = 200

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 1
value = 182,0

[State 800, PlaySnd]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,1
channel = 1

[State 800, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(3) >= 0
moveType = I

[State 800, End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
; Skip To My Chain Launched
[StateDef 3501]
type = S
movetype = A
physics = S
anim = 3501
ctrl = 0
velSet = 0,0
sprPriority = 0

[State 210, 3]
type = Turn
trigger1 = animtime = 0

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 5
value = 2

[State 210, 3]
type = SprPriority
trigger1 =  AnimElem = 6
value = -1

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 1
value = 3500,0

[State 810, Width]
type = Width
trigger1 = 1
value = 32,32

[State 810,***]
type = TargetState
trigger1 = time = 0
value = 3520

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 1
pos = ceil(60*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 4
pos = ceil(-10*const(size.xscale)),ceil(-100*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 = AnimElem = 5
pos = ceil(-30*const(size.xscale)),ceil(-80*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 = AnimElem = 6
pos = ceil(0*const(size.xscale)),ceil(-120*const(size.yscale))
postype = P1
time = -1

[State 810, Target]
type = TargetBind
trigger1 =  AnimElem = 7
pos = ceil(80*const(size.xscale)),ceil(0*const(size.yscale))
postype = P1
time = -1

[State 13055, Impact Dust]
type = Helper
trigger1 = AnimElem = 7
helperType = Normal
stateNo = 8110
ID = 8110
name = "Impact Dust"
posType = P1
pos = 50, 5
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 7
helperType = Normal
stateNo = 8103
pos = 10,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 7
helperType = Normal
stateNo = 8103
pos = 0,0
ID = 8100
name = "Dash Dust"
posType = P2
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4,0
channel = 0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 1
value = 5,0

[State 810, 4]
type = PlaySnd
trigger1 = AnimElem = 7
value = 1200,1

[State 810, Life]
type = TargetLifeAdd
trigger1 = AnimElem = 7
value = Ceil(-60 *fvar(10)*(const(data.attack)*0.01))

[State -2, 3]
type = EnvShake
trigger1 = AnimElem = 7
time = 20
freq = 60
ampl = -4
phase = 90
ignorehitpause = 1

[State 810, TargetState]
type = TargetState
triggerall = !NumTarget(3501)
trigger1 = AnimElem = 9
value = 3530

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3501) >= 1
triggerall =target(3501),alive = 1
trigger1 = AnimElem = 9
value = 3530

[State 810, TargetState]
type = TargetState
triggerall = NumTarget(3501) >= 1
triggerall =target(3501),life <= 0
trigger1 = AnimElem = 9
value = 5150

[State 1000, End]
type = ChangeState
trigger1 = Time >= 40
value = 3502
ctrl = 0

;---------------------------------------------------------------------------
; Skip To My Chain Throwing
[StateDef 3502]
type = S
movetype = A
physics = N
anim = 3502
ctrl = 0
velset = 0,0
sprpriority = 1
poweradd = 0

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 12
value = 3500,4

[State 3, Sound]
type = PlaySnd
trigger1 = AnimElem = 12
value = 3500,6


[State 3000, VarSet]
type = VarSet
trigger1 = !Time
var(36) = 1
persistent = 0
ignorehitpause = 1

[State 200, VarAdd]
type = VarAdd
triggerall = !(var(27) || var(28))
trigger1 = NumTarget && AnimElemtime(2) = 0
trigger2 = NumTarget && AnimElemtime(6) = 9
trigger3 = NumTarget && AnimElemtime(12) = 0
triggerall = var(52) = 0
var(30) = -4
;persistent = 0
ignorehitpause = 1

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElemtime(6) = 9
value = floor(ifelse(var(1) >= 24, -7, -95))
kill = 0

[State 810, Damage]
type = TargetLifeAdd
trigger1 = NumTarget && AnimElem = 12
value = floor(ifelse(var(1) >= 24, -7, -275))

[State 810, TargetPowerAdd]
type = TargetPowerAdd
trigger1 = NumTarget && AnimElem = 2
trigger2 = NumTarget && AnimElemtime(6) = 9
trigger3 = NumTarget && AnimElem = 12
value = 36

[State 810, HitAdd]
type = HitAdd
trigger1 = NumTarget && AnimElem = 2
trigger2 = NumTarget && AnimElemtime(6) = 9
trigger3 = NumTarget && AnimElem = 12
value = 1

[State 831, VarAdd]
type = VarAdd
trigger1 = NumTarget && AnimElem = 2
trigger2 = NumTarget && AnimElemtime(6) = 9
trigger3 = NumTarget && AnimElem = 12
var(1) = 1

[State 1005, Explod]
type = Explod
trigger1 = NumTarget && AnimElem = 12
anim = 3510
id = 3510
sprpriority = 0
postype = p1
pos = 200,0
scale = .5,.5
ownpal = 1

[State -2, VarAdd]
type = VarAdd
trigger1 = NumTarget && AnimElem = 2
trigger2 = NumTarget && AnimElemtime(6) = 9
trigger3 = NumTarget && AnimElem = 12
triggerall = var(52) = 0
var(5) = ifelse(var(5)<100,6,0)
ignorehitpause = 1

[State 200, PlaySnd]
type = PlaySnd
trigger1 = Time=0
value = 3500,1
volumescale = 200
channel = 2

[State 816, EnvShake]
type = EnvShake
triggerall = NumTarget
trigger1 = Animelem = 2
trigger2 = animelemtime(6)=9
time = 4
ampl = -4
freq = 120

[State 816, EnvShake]
type = EnvShake
triggerall = NumTarget
trigger1 = Animelem = 12
time = 20
ampl = -10
freq = 120

[State 3, Sound]
type = PlaySnd
trigger1 = animelemtime(6)=9
value = 3500,5

[State 200, HitSpark]
type = Helper
triggerall = NumTarget
trigger1 = Animelem = 2
stateno = 8012
ID = 8012
name = "HitSpark"
pos = 95, 0
postype = P1
ownpal = 1
keyctrl = 0
sprpriority = 5
ignorehitpause = 1
supermovetime = 9999
pausemovetime = 9999

[State 200, HitSpark]
type = Helper
triggerall = NumTarget
trigger1 = animelemtime(6)=9
stateno = 8012
ID = 8012
name = "HitSpark"
pos = 40, ceil(pos y-pos y*2)
postype = P1
ownpal = 1
keyctrl = 0
sprpriority = 5
ignorehitpause = 1
supermovetime = 9999
pausemovetime = 9999

[State 200, HitSpark]
type = Helper
triggerall = NumTarget
trigger1 = animelemtime(12)=0
stateno = 8012
ID = 8012
name = "HitSpark"
pos = 200, 0
postype = P1
ownpal = 1
keyctrl = 0
sprpriority = 5
ignorehitpause = 1
supermovetime = 9999
pausemovetime = 9999

[State 0, TargetBind]
type = TargetBind
trigger1 = numtarget
trigger1 = animelem = 1
pos = 80,0
ignorehitpause = 1

[State 0, TargetState]
type = TargetState
triggerall = NumTarget
trigger1 = Animelem = 1
value = 3522
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
trigger1 = numtarget
trigger1 = animelem = 2
pos = 125,5
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
trigger1 = numtarget
trigger1 = animelem = 3
pos = 80,-10
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
trigger1 = numtarget
trigger1 = animelem = 4
pos = 75,20
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
trigger1 = numtarget
trigger1 = animelem = 5
pos = 50,20
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
trigger1 = numtarget
trigger1 = animelemtime(5) = 1
pos = 5,30
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelem = 6
pos = -30,35
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 1
pos = -50,20
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 2
pos = -75,-30
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 3
pos = -68,-90
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 4
pos = -35,-130
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 5
pos = 20,-130
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 6
pos = 75,-98
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 7
pos = 90,-40
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 8
pos = 70,20
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 9
pos = 10,30
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 10
pos = -50,20
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 11
pos = -80,-35
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 12
pos = -70,-90
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 13
pos = -30,-125
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 14
pos = 30,-115
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 15
pos = 85,-75
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 16
pos = 95,-35
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 17
pos = 65,20
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 18
pos = 0,40
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 19
pos = -48,25
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 20
pos = -80,-30
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 21
pos = -70,-90
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 22
pos = -30,-120
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 23
pos = 30,-130
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 24
pos = 70,-100
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 25
pos = 95,-45
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 26
pos = 60,10
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 27
pos = 0,30
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(6) = 28
pos = -70,0
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(7) = 0
pos = -120,35
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(8) >= 0 && animelemtime(9) < 0
pos = -150,-90
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(9) = 0
pos = -95,-125
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(10) = 0
pos = 60,-155
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(11) = 0
pos = 180,-150
ignorehitpause = 1

[State 0, TargetBind]
type = TargetBind
triggerall = numtarget
trigger1 = animelemtime(12) = 0
pos = 200,0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = Animelem = 10
x = 0
y = 0
ignorehitpause = 1

[State 0, PosSet]
type = PosSet
trigger1 = Animelem = 10
y = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = pos y < 0
trigger1 = animelemtime(8) >= 8
y = .7225
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = pos y < 0
trigger1 = animelemtime(6) < 0
y = 3.25;1.7225
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = AnimElem = 4
x = 0
y = -15
ignorehitpause = 1

[State 0, VelSet]
type = VelAdd
trigger1 = animelemtime(8) >= 0 && animelemtime(8) < 8
x = 0
y = .1
ignorehitpause = 1

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
ignorehitpause = 1

[State 0, AngleSet]
type = AngleSet
trigger1 = !Time
trigger2 = animelemtime(8) = 0
value = 0
ignorehitpause = 1

[State 0, AngleSet]
type = AngleSet
trigger1 = animelemtime(4) = 0
value = -25
ignorehitpause = 1

[State 0, AngleSet]
type = AngleSet
trigger1 = animelemtime(7) = 0
value = 25
ignorehitpause = 1

[State 0, AngleSet]
type = AngleSet
trigger1 = animelemtime(5) = 0
value = 40
ignorehitpause = 1

[State 0, AngleAdd]
type = AngleAdd
trigger1 = Animelemtime(5) >= 0 && animelemtime(7) < 0
trigger1 = time%1=0
value = -40
ignorehitpause = 1

[State 200, PlaySnd]
type = PlaySnd
trigger1 = Animelem = 3
value = 3500,1
volumescale = 200
channel = 2

[State 1005, Explod]
type = Explod
trigger1 = Animelem = 3
anim = 8104
id = 8104
sprpriority = 3
postype = p1
pos = 0,0
scale = .75,.75
removeongethit = 1
ownpal = 1

[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = 3
postype = p1
pos = 0,0
vel = 0,.5
scale = .5,.5
;removeongethit = 1
ownpal = 1

[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = -3
postype = p1
pos = 0,-10
vel = 0,-.25
scale = .45,.45
;removeongethit = 1
ownpal = 1

[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = 3
postype = p1
vel = -2,0
pos = -10,0
scale = .5,.5
;removeongethit = 1
ownpal = 1
[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = -3
postype = p1
vel = -2,0
pos = -10,-10
scale = .45,.45
;removeongethit = 1
ownpal = 1

[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = 3
postype = p1
vel = -1,.5
pos = -5,0
scale = .5,.5
;removeongethit = 1
ownpal = 1
[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = -3
postype = p1
vel = -1,-.25
pos = -5,-10
scale = .45,.45
;removeongethit = 1
ownpal = 1

[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = 3
postype = p1
vel = 2,0
pos = 10,0
scale = .5,.5
;removeongethit = 1
ownpal = 1
[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = -3
postype = p1
vel = 2,0
pos = 10,-10
scale = .45,.45
;removeongethit = 1
ownpal = 1

[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = 3
postype = p1
vel = 1,.5
pos = 5,0
scale = .5,.5
;removeongethit = 1
ownpal = 1
[State 1005, Explod]
type = Explod
trigger1 = animelem=10
anim = 8100
id = 8100
sprpriority = -3
postype = p1
vel = 1,-.25
pos = 5,-10
scale = .45,.45
;removeongethit = 1
ownpal = 1

[State -2, Helper]
type = Helper
trigger1 = Animelemtime(2) = 0
stateno = 8110
ID = 8110
name = "target floor fx"
ownpal = 1
pos = 95,-10
sprpriority = 8
ignorehitpause = 1

[State -2, Helper]
type = Helper
trigger1 = Animelemtime(6) = 8
stateno = 8110
ID = 8110
name = "target floor fx"
ownpal = 1
pos = 40,-20
sprpriority = 8
ignorehitpause = 1

[State -2, Helper]
type = Helper
trigger1 = Animelemtime(5) >= 0 && animelemtime(7) < 0
trigger1 = time%8=0
stateno = 4008
ID = 4008
name = "spin fx"
ownpal = 1
pos = 5-random%10,-70+random%10
sprpriority = 2
ignorehitpause = 1

[State -2, Helper]
type = Helper
trigger1 = Animelemtime(12) = 0
stateno = 8110
ID = 8110
name = "target floor fx"
ownpal = 1
pos = 200,-20
sprpriority = 8
ignorehitpause = 1


[State 1000, End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
; Skip To My Chain Missed
[StateDef 3509]
type = S
movetype = A
physics = S
anim = 3503
ctrl = 0
velset = 0,0
sprpriority = 1
poweradd = 0

[State 1000, End]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
; Skip To My Chain Target Thrown
[StateDef 3520]
type     = S
movetype = H
velset   = 0,0
sprpriority = 2

[State 815, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time
value = 3520

[State 10000, Screen]
type = ScreenBound
trigger1 = 1
movecamera = 0,0

[State 816, Continued]
type = ChangeState
trigger1 = !animtime
value = 3522

;---------------------------------------------------------------------------
; Skip To My Chain Target Throwing
[StateDef 3522]
type = A
movetype = H
physics = N
velset = 0,0
ctrl = 0
sprpriority = 1

[State 815, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time
value = 3526

[State 815, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 0,0
IgnoreHitPause = 1

[State 905, End]
type = ChangeState
trigger1 = Animtime=0
value = 826
ctrl = 0



[StateDef 3530]
type = A
movetype = H
physics = N
velset = 0,0
ctrl = 0
sprpriority = 2

[State 0, VelSet]
type = VelSet
trigger1 = 1
x = 0
y = 0
ignorehitpause = 1

[State 815, ChangeAnim2]
type = ChangeAnim2
trigger1 = !Time
value = 3525

[State 815, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 0,0
IgnoreHitPause = 1

[State 905, End]
type = ChangeState
trigger1 = Time >= 7
value = 3231
ctrl = 0