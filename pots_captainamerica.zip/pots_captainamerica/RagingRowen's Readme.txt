
Movelist:

Normals:

Double Kick			b, b
Anti-Ground Kick		D, c	(Air)
1-Hand Slam                	F + 2p		(near opponent)
Ground Launch                	B + 2p		(near opponent)

Specials:

Shield Slash			D, DF, F, p	(Air also)
Stars & Stripes (EX)		F, D, DF, p
Charging Star (EX)		D, DF, F, k
Backflip			F, DF, D, DB, B, p

Supers:

Hyper Stars & Stripes		D, DF, F, D, DF, F, p
Hyper Charging Star (MAX)	D, DF, F, D, DF, F, k

Level 3 Super:

Final Justice			D, DB, B, D, DB, B, 2p

System:

Run:				F, F (hold F)
Backward Dash:			B, B
Low Jump:			N/A (Coming Soon)
High Jump:			N/A (Coming Soon)
Long Low Jump:			N/A (Coming Soon)
Dodge:				a + x
Dodge Attack:			p or k during dodge
Forward Roll:			F + a + x
Backward Roll:			B + a + x
Parry:				tap F
Parry Low:			tap D
Air Parry:			tap F (Air)
Power Charge:			hold b + y
Zero Counter:			B, DB, D, p or k (during guard)
Fall Recovery:			N/A (Coming Soon)


Version History:
<RagingRowen's Third Update>
- Kick Shield Intro fixed.
- Not being able to do Normals while running fixed.

<RagingRowen's Second Update>
- New Big Port and Victory Port.
- Added L-M-H Chain Combos (Imported from Buckus' Original).
- Crouching HP no longer launches (For now).
- Air Hitsparks Fixed (Hopefully).
- Bodyslam now uses PotS-style impact.
- Dodges pushing fixed.
- Anti-Air Shield Slash (No EX for now).
- Proper Heavy and EX Stars & Stripes.

<RagingRowen's Update>
- Added Tick Fix.
- Added proper Zero Counters.
- Double Kick re-added.
- Hitsound changes for specials and supers.
- Applied missing palettes.
- Added MAX Hyper Charging Star.
- Hyper Stars & Stripes superpause fixed.
- Misc. Adjustments and Tweaks.

<ShinRei's Edit>
- PotS Style Conversion

<SeanAltly's Edit>
- CvtW Style Conversion

<5/15/13>
- Original Release

To Do:
- Add more Jumps (Super Jump especially).
- Fall Recovery.
- Apply more FX.
- Seperate his Throws better.
- Something for z+c.
- MAX Hyper S&S

