;-| Button Remapping |-----------------------------------------------------
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s
;-| Default Values |-------------------------------------------------------
[Defaults]
command.time = 15
command.buffer.time = 1

;-| Super Motions |--------------------------------------------------------
[Command]
name="MAXAnkokuOrochiNagi"
command=~D, DB, B, D, DF, F, x+y
time=32
[Command]
name="MAXAnkokuOrochiNagi"
command=~D, DB, B, D, DF, F, y+z
time=32
[Command]
name="MAXAnkokuOrochiNagi"
command=~D, DB, B, D, DF, F, x+z
time=32

[Command]
name="AnkokuOrochiNagi"
command=~D, DB, B, D, DF, F, x
time=32
[Command]
name="AnkokuOrochiNagi"
command=~D, DB, B, D, DF, F, y
time=32
[Command]
name="AnkokuOrochiNagi"
command=~D, DB, B, D, DF, F, z
time=32
[Command]
name="AnkokuOrochiNagi"
command=~D, DB, B, D, DF, F, ~x
time=32
[Command]
name="AnkokuOrochiNagi"
command=~D, DB, B, D, DF, F, ~y
time=32
[Command]
name="AnkokuOrochiNagi"
command=~D, DB, B, D, DF, F, ~z
time=32

[Command]
name="MAXTwister Drive"
command=~D, DB, B, D, DB, a+b
time=32
[Command]
name="MAXTwister Drive"
command=~D, DB, B, D, DB, b+c
time=32
[Command]
name="MAXTwister Drive"
command=~D, DB, B, D, DB, c+a
time=32

[Command]
name="Twister Drive"
command=~D, DB, B, D, DB, a
time=32
[Command]
name="Twister Drive"
command=~D, DF, B, D, DB, b
time=32
[Command]
name="Twister Drive"
command=~D, DB, B, D, DB, c
time=32
[Command]
name="Twister Drive"
command=~D, DB, B, D, DB, ~a
time=32
[Command]
name="Twister Drive"
command=~D, DB, B, D, DB, ~b
time=32
[Command]
name="Twister Drive"
command=~D, DB, B, D, DB, ~c
time=32

[Command]
name="MAXChainSlideTouch"
command=~D, DF, F, D, DF, x+y
time=32
[Command]
name="MAXChainSlideTouch"
command=~D, DF, F, D, DF, y+z
time=32
[Command]
name="MAXChainSlideTouch"
command=~D, DF, F, D, DF, z+x
time=32

[Command]
name="ChainSlideTouch"
command=~D, DF, F, D, DF, x
time=32
[Command]
name="ChainSlideTouch"
command=~D, DF, F, D, DF, y
time=32
[Command]
name="ChainSlideTouch"
command=~D, DF, F, D, DF, z
time=32
[Command]
name="ChainSlideTouch"
command=~D, DF, F, D, DF, ~x
time=32
[Command]
name="ChainSlideTouch"
command=~D, DF, F, D, DF, ~y
time=32
[Command]
name="ChainSlideTouch"
command=~D, DF, F, D, DF, ~z
time=32

[Command]
name="DaichiNoKurauGouka"
command=~D, DF, F, D, DF, x
time=32
[Command]
name="DaichiNoKurauGouka"
command=~D, DF, F, D, DF, y
time=32
[Command]
name="DaichiNoKurauGouka"
command=~D, DF, F, D, DF, z
time=32
[Command]
name="DaichiNoKurauGouka"
command=~D, DF, F, D, DF, ~x
time=32
[Command]
name="DaichiNoKurauGouka"
command=~D, DF, F, D, DF, ~y
time=32
[Command]
name="DaichiNoKurauGouka"
command=~D, DF, F, D, DF, ~z
time=32

[Command]
name="MAXDaichiNoKurauGouka"
command=~D, DF, F, D, DF, x+y
time=32
[Command]
name="MAXDaichiNoKurauGouka"
command=~D, DF, F, D, DF, y+z
time=32
[Command]
name="MAXDaichiNoKurauGouka"
command=~D, DF, F, D, DF, z+x
time=32

[Command]
name="DaichioHarauGouka"
command=~D, DB, B, D, DB, x
time=32
[Command]
name="DaichioHarauGouka"
command=~D, DB, B, D, DB, y
time=32
[Command]
name="DaichioHarauGouka"
command=~D, DB, B, D, DB, z
time=32
[Command]
name="DaichioHarauGouka"
command=~D, DB, B, D, DB, ~x
time=32
[Command]
name="DaichioHarauGouka"
command=~D, DB, B, D, DB, ~y
time=32
[Command]
name="DaichioHarauGouka"
command=~D, DB, B, D, DB, ~z
time=32

[Command]
name="MAXDaichioHarauGouka"
command=~D, DB, B, D, DB, x+y
time=32
[Command]
name="MAXDaichioHarauGouka"
command=~D, DB, B, D, DB, y+z
time=32
[Command]
name="MAXDaichioHarauGouka"
command=~D, DB, B, D, DB, z+x
time=32

[Command]
name="SanagiYaburiwowamauchou"
command=~D, DF, F, D, DF, F, a+b
time=32
[Command]
name="SanagiYaburiwowamauchou"
command=~D, DF, F, D, DF, F, b+c
time=32
[Command]
name="SanagiYaburiwowamauchou"
command=~D, DF, F, D, DF, F, c+a
time=32

[Command]
name = "dark"
command = ~D, DF, F, D, DF, s
time = 30
;-| Special Motions |------------------------------------------------------

[Command]
name = "SlideTouch1"
command = ~D, DF, F, x
time = 15
[Command]
name = "SlideTouch2"
command = ~D, DF, F, y
time = 15
[Command]
name = "SlideTouch3"
command = ~D, DF, F, z
time = 15
[Command]
name = "SlideTouch1"
command = ~D, DF, F, ~x
time = 15
[Command]
name = "SlideTouch2"
command = ~D, DF, F, ~y
time = 15
[Command]
name = "SlideTouch3"
command = ~D, DF, F, ~z
time = 15

[Command]
name = "SlideTouchEX"
command = ~D, DF, F, x+y
time = 15
[Command]
name = "SlideTouchEX"
command = ~D, DF, F, y+z
time = 15
[Command]
name = "SlideTouchEX"
command = ~D, DF, F, x+z
time = 15

[Command]
name = "HuntingAir1"
command = ~F, D, DF, a
time = 15
[Command]
name = "HuntingAir2"
command = ~F, D, DF, b
time = 15
[Command]
name = "HuntingAir3"
command = ~F, D, DF, c
time = 15
[Command]
name = "HuntingAir1"
command = ~F, D, DF, ~a
time = 15
[Command]
name = "HuntingAir2"
command = ~F, D, DF, ~b
time = 15
[Command]
name = "HuntingAir3"
command = ~F, D, DF, ~c
time = 15

[Command]
name = "HuntingAirEX"
command = ~F, D, DF, a+b
time = 15
[Command]
name = "HuntingAirEX"
command = ~F, D, DF, b+c
time = 15
[Command]
name = "HuntingAirEX"
command = ~F, D, DF, a+c
time = 15

[Command]
name = "TsukiwoTsumuHonoo1"
command = ~F, D, DF, x
time = 18
[Command]
name = "TsukiwoTsumuHonoo2"
command = ~F, D, DF, y
time = 18
[Command]
name = "TsukiwoTsumuHonoo3"
command = ~F, D, DF, z
time = 18
[Command]
name = "TsukiwoTsumuHonoo1"
command = ~F, D, DF, ~x
time = 18
[Command]
name = "TsukiwoTsumuHonoo2"
command = ~F, D, DF, ~y
time = 18
[Command]
name = "TsukiwoTsumuHonoo3"
command = ~F, D, DF, ~z
time = 18

[Command]
name = "TsukiwoTsumuHonooEX"
command = ~F, D, DF, x+y
time = 18
[Command]
name = "TsukiwoTsumuHonooEX"
command = ~F, D, DF, y+z
time = 18
[Command]
name = "TsukiwoTsumuHonooEX"
command = ~F, D, DF, x+z
time = 18

[Command]
name = "Directionchange1"
command = ~F, D, DF, x
time = 18

[Command]
name = "Directionchange1"
command = ~F, D, DF, ~x
time = 18

[Command]
name = "Directionchange2"
command = ~F, D, DF, y
time = 18

[Command]
name = "Directionchange2"
command = ~F, D, DF, ~y
time = 18

[Command]
name = "Directionchange3"
command = ~F, D, DF, z
time = 18

[Command]
name = "Directionchange3"
command = ~F, D, DF, ~z
time = 18

[Command]
name = "EXdirectionchange"
command = ~F, D, DF, x+y
time = 18

[Command]
name = "EXdirectionchange"
command = ~F, D, DF, y+z
time = 18

[Command]
name = "EXdirectionchange"
command = ~F, D, DF, x+z
time = 18

[Command]
name = "ScrambleDash1"
command = ~D, DF, F, a
time = 15

[Command]
name = "ScrambleDash1"
command = ~D, DF, F, b
time = 15
[Command]
name = "ScrambleDash2"
command = ~D, DF, F, c
time = 15
[Command]
name = "ScrambleDash1"
command = ~D, DF, F, ~a
time = 15
[Command]
name = "ScrambleDash1"
command = ~D, DF, F, ~b
time = 15
[Command]
name = "ScrambleDash2"
command = ~D, DF, F, ~c
time = 15

[Command]
name = "ScrambleDashEX"
command = ~D, DF, F, a+b
time = 15
[Command]
name = "ScrambleDashEX"
command = ~D, DF, F, c+b
time = 15
[Command]
name = "ScrambleDashEX"
command = ~D, DF, F, c+a
time = 15

[Command]
name = "GliderStomp1"
command = ~D, DF, F, a
time = 15

[Command]
name = "GliderStomp1"
command = ~D, DF, F, ~a
time = 15

[Command]
name = "GliderStomp2"
command = ~D, DF, F, b
time = 15

[Command]
name = "GliderStomp2"
command = ~D, DF, F, ~b
time = 15

[Command]
name = "GliderStomp3"
command = ~D, DF, F, c
time = 15

[Command]
name = "GliderStomp3"
command = ~D, DF, F, ~c
time = 15

[Command]
name = "GliderStompEX"
command = ~D, DF, F, a+b
time = 15

[Command]
name = "GliderStompEX"
command = ~D, DF, F, b+c
time = 15

[Command]
name = "GliderStompEX"
command = ~D, DF, F, a+c
time = 15

[Command]
name = "KagamiwoHofuruHonoo1"
command = ~D, DB, B, x
time = 15
[Command]
name = "KagamiwoHofuruHonoo2"
command = ~D, DB, B, y
time = 15
[Command]
name = "KagamiwoHofuruHonoo3"
command = ~D, DB, B, z
time = 15
[Command]
name = "KagamiwoHofuruHonoo1"
command = ~D, DB, B, ~x
time = 15
[Command]
name = "KagamiwoHofuruHonoo2"
command = ~D, DB, B, ~y
time = 15
[Command]
name = "KagamiwoHofuruHonoo3"
command = ~D, DB, B, ~z
time = 15

[Command]
name = "KagamiwoHofuruHonooEX"
command = ~D, DB, B, x+y
time = 15
[Command]
name = "KagamiwoHofuruHonooEX"
command = ~D, DB, B, y+z
time = 15
[Command]
name = "KagamiwoHofuruHonooEX"
command = ~D, DB, B, x+z
time = 15

[Command]
name = "TaiyouwoIruHonoo1"
command = ~D, DF, F, x
time = 15
[Command]
name = "TaiyouwoIruHonoo2"
command = ~D, DF, F, y
time = 15
[Command]
name = "TaiyouwoIruHonoo3"
command = ~D, DF, F, z
time = 15
[Command]
name = "TaiyouwoIruHonoo1"
command = ~D, DF, F, ~x
time = 15
[Command]
name = "TaiyouwoIruHonoo2"
command = ~D, DF, F, ~y
time = 15
[Command]
name = "TaiyouwoIruHonoo3"
command = ~D, DF, F, ~z
time = 15

[Command]
name = "TaiyouwoIruHonooEX"
command = ~D, DF, F, x+y
time = 15
[Command]
name = "TaiyouwoIruHonooEX"
command = ~D, DF, F, y+z
time = 15
[Command]
name = "TaiyouwoIruHonooEX"
command = ~D, DF, F, x+z
time = 15

[Command]
name = "ShootingDancerThrust1"
command = ~F, DF, D, DB, B, x
time = 30
[Command]
name = "ShootingDancerThrust2"
command = ~F, DF, D, DB, B, y
time = 30
[Command]
name = "ShootingDancerThrust3"
command = ~F, DF, D, DB, B, z
time = 30
[Command]
name = "ShootingDancerThrust1"
command = ~F, DF, D, DB, B, ~x
time = 30
[Command]
name = "ShootingDancerThrust2"
command = ~F, DF, D, DB, B, ~y
time = 30
[Command]
name = "ShootingDancerThrust3"
command = ~F, DF, D, DB, B, ~z
time = 30

[Command]
name = "ShootingDancerThrustEX"
command = ~F, DF, D, DB, B, y+z
time = 30
[Command]
name = "ShootingDancerThrustEX"
command = ~F, DF, D, DB, B, x+y
time = 30
[Command]
name = "ShootingDancerThrustEX"
command = ~F, DF, D, DB, B, x+z
time = 30

[Command]
name = "ShootingDancerStep1"
;command = ~F, DF, D, DB, B, a
command = ~D, DB, B, a
time = 30
[Command]
name = "ShootingDancerStep2"
;command = ~F, DF, D, DB, B, b
command = ~D, DB, B, b
time = 30
[Command]
name = "ShootingDancerStep3"
;command = ~F, DF, D, DB, B, c
command = ~D, DB, B, c
time = 30
;[Command]
;name = "ShootingDancerStep1"
;command = ~F, DF, D, DB, B, ~a
;time = 30
;[Command]
;name = "ShootingDancerStep2"
;command = ~F, DF, D, DB, B, ~b
;time = 30
;[Command]
;name = "ShootingDancerStep3"
;command = ~F, DF, D, DB, B, ~c
;time = 30

[Command]
name = "ShootingDancerStepEX"
command = ~F, DF, D, DB, B, a+b
time = 30
[Command]
name = "ShootingDancerStepEX"
command = ~F, DF, D, DB, B, c+b
time = 30
[Command]
name = "ShootingDancerStepEX"
command = ~F, DF, D, DB, B, c+a
time = 30

[Command]
name = "ShishiwoKamuHonoo"
command = ~B, DB, D, DF, F, a
time = 30
[Command]
name = "ShishiwoKamuHonoo2"
command = ~B, DB, D, DF, F, b
time = 30
[Command]
name = "ShishiwoKamuHonoo3"
command = ~B, DB, D, DF, F, c
time = 30
[Command]
name = "ShishiwoKamuHonoo"
command = ~B, DB, D, DF, F, ~a
time = 30
[Command]
name = "ShishiwoKamuHonoo2"
command = ~B, DB, D, DF, F, ~b
time = 30
[Command]
name = "ShishiwoKamuHonoo3"
command = ~B, DB, D, DF, F, ~c
time = 30

[Command]
name = "ShishiwoKamuHonooEX"
command = ~B, DB, D, DF, F, a+b
time = 30

[Command]
name = "ShishiwoKamuHonooEX"
command = ~B, DB, D, DF, F, b+c
time = 30

[Command]
name = "ShishiwoKamuHonooEX"
command = ~B, DB, D, DF, F, a+c
time = 30

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, x
time = 16
[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, y
time = 16
[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, z
time = 16
[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~x
time = 16
[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~y
time = 16
[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~z
time = 16
[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, a
time = 16
[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, b
time = 16
[Command]
name=  "412k" ;Zero Counter
command = ~B, DB, D, c
time = 16
[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~a
time = 16
[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~b
time = 16
[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~c
time = 16
;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1
[Command]
name="recovery"
command=a+x
time=1
[Command]
name = "recovery"
command = y+z
time=1
[Command]
name = "recovery"
command = x+z
time=1
[Command]
name = "recovery"
command = a+b
time=1
[Command]
name = "recovery"
command = b+c
time=1
[Command]
name = "recovery"
command = a+c
time=1

[Command]
name = "pp"
command = x+y
time = 1
[Command]
name = "pp"
command = x+z
time = 1
[Command]
name = "pp"
command = y+z
time = 1
[Command]
name = "kk"
command = a+b
time = 1
[Command]
name = "kk"
command = a+c
time = 1
[Command]
name = "kk"
command = b+c
time = 1
[Command]
name = "a+x"
command = a+x
time=1
[Command]
name = "b+y"
command = b+y
time = 1
[Command]
name = "c+z"
command = c+z
time = 1
;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1
[Command]
name = "b"
command = b
time = 1
[Command]
name = "c"
command = c
time = 1
[Command]
name = "x"
command = x
time = 1
[Command]
name = "y"
command = y
time = 1
[Command]
name = "z"
command = z
time = 1
[Command]
name = "s"
command = s
time = 1
;-| Single Dir |------------------------------------------------------------
[Command]
name = "fwd" ;Required (do not remove)
command = $F
time = 1
[Command]
name = "downfwd"
command = $DF
time = 1
[Command]
name = "down" ;Required (do not remove)
command = $D
time = 1
[Command]
name = "downback"
command = $DB
time = 1
[Command]
name = "back" ;Required (do not remove)
command = $B
time = 1
[Command]
name = "upback"
command = $UB
time = 1
[Command]
name = "up" ;Required (do not remove)
command = $U
time = 1
[Command]
name = "upfwd"
command = $UF
time = 1
;-| Hold Button |--------------------------------------------------------------
[Command]
name = "hold_x"
command = /x
time = 1
[Command]
name = "hold_y"
command = /y
time = 1
[Command]
name = "hold_z"
command = /z
time = 1
[Command]
name = "hold_a"
command = /a
time = 1
[Command]
name = "hold_b"
command = /b
time = 1
[Command]
name = "hold_c"
command = /c
time = 1
[Command]
name = "hold_s"
command = /s
time = 1
;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1
[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1
[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1
[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1
[Command]
name = "holdfwd" ;Required (do not remove)
command = /$F
time = 1
[Command]
name = "holddownfwd"
command = /$DF
time = 1
[Command]
name = "holddown" ;Required (do not remove)
command = /$D
time = 1
[Command]
name = "holddownback"
command = /$DB
time = 1
[Command]
name = "holdback" ;Required (do not remove)
command = /$B
time = 1
[Command]
name = "holdupback"
command = /$UB
time = 1
[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1
[Command]
name = "holdupfwd"
command = /$UF
time = 1
;---------------------------------------------------------------------------
;Release Direction
[Command]
name = "rlsfwd"
command = ~$F
time = 1
[Command]
name = "rlsback"
command = ~$B
time = 1
[Command]
name = "rlsup"
command = ~$U
time = 1
[Command]
name = "rlsdown"
command = ~$D
time = 1
;--------------------------------------------------------------------------
;Release Button
[Command]
name = "rlsx"
command = ~x
time = 1
[Command]
name = "rlsy"
command = ~y
time = 1
[Command]
name = "rlsz"
command = ~z
time = 1
[Command]
name = "rlsa"
command = ~a
time = 1
[Command]
name = "rlsb"
command = ~b
time = 1
[Command]
name = "rlsc"
command = ~c
time = 1
;---------------------------------------------------------------------------
;Other
[Command]
name = "highjump"
command = $D, $U
time = 15
[Command]
name = "DU"
command = D, U
time = 18
[Command]
name = "DU"
command = DB, UF
time = 18
[Command]
name = "DU"
command = DF, UB
time = 18
[Command]
name = "DU"
command = $D, UF
time = 18
[Command]
name = "DU"
command = $D, UB
time = 18
;---------------------------------------------------------------------------
[Statedef -1]

[State -1, Tick Fix]
type = CtrlSet
triggerall = !ctrl
trigger1 = (StateNo = 52 || StateNo = 101 || StateNo = 5120) && !AnimTime
trigger2 = (StateNo = [200,499]) && !AnimTime
trigger3 = StateNo = 810 && !AnimTime
trigger4 = (StateNo = 5001 || StateNo = 5011 || StateNo = 151 || StateNo = 153) && HitOver
trigger5 = (StateNo = [700,715]) && !AnimTime
trigger6 = (StateNo = [6080,6082]) && !AnimTime
value = 1
;-----------------------------------------------------------------
[State -1, Parry Stand]
type = HitOverride
triggerall =!AILevel
triggerall = command = "fwd" && command!= "back" && command != "up" && command != "down"
trigger1 = Ctrl
attr = SA,AA,AP
stateno = 6080
slot = 0
time = 5
;------------------------------------------------------------------
[State -1, Crouching Parry]
type = HitOverride
triggerall =!AILevel
triggerall = (statetype = S && command = "down")|| (statetype = C && command = "fwd") && command != "back" && command != "up"
trigger1 = Ctrl
attr = C,AA,AP
stateno = 6081
slot = 0
time =5
;-------------------------------------------------------------------
[State -1, Aerial Parry]
type= HitOverride
triggerall =!AILevel
triggerall = (statetype= A && command = "fwd") && command != "back" && command != "up" && command != "down"
trigger1 = Ctrl
attr = SA,AA,AP
stateno = 6082
forceair = 1
slot = 0
time = 5

;[State -1, modechange]
;type = changestate
;value = 4400
;triggerall = !AIlevel
;triggerall = command = "dark" && palno<=6
;triggerall = roundstate = 2 && statetype != A && power >= 1000 && var(20) <= 60
;trigger1 = ctrl || ((stateno = [200, 299]) && time <= 2) || (stateno = 200 || stateno = 230 || stateno = 245)
;trigger2 = (stateno = [200, 250]) && stateno != 222 && (movecontact = [1, 8])
;trigger3 = ((stateno = [1100, 1199]) || (stateno = [1200, 1230]) || stateno = 3100 || stateno = 3200 || stateno = 4101) && (movecontact = [1, 24])
;trigger4 = (stateno = [1000, 4999]) && numhelper(stateno + 5) && var(10) <= 6
;trigger4 = helper(stateno + 5), var(3)
;trigger5 = var(20) && (stateno = [200, 289])
;trigger6 = var(20) && ((stateno = [1000, 2999]) || stateno = 52 && (prevstateno = [1000, 2999])) && movecontact
;trigger7 = var(20) && (stateno = [1000, 2999]) && numhelper(stateno + 5)
;trigger7 = helper(stateno + 5), var(3)
;trigger8 = stateno = 52 && (prevstateno = [1000, 4999]) && (movecontact = [1, 24])
;----------------------------------------------------------------------
[State -1, Honoo no Sadame no Kurisu]
type=ChangeState
value=3700
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3050 &&var(20) <= 60 && power >= 3000
triggerall=!var(11) && command="SanagiYaburiwowamauchou"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7)
;----------------------------------------------------------------------
[State -1, MAX Ankoku Orochi Nagi]
type=ChangeState
value=3350
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3350 &&var(20) <= 60 && power >= 2000
triggerall=var(11) && command="MAXAnkokuOrochiNagi"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7)
;----------------------------------------------------------------------
[State -1, MAX Twister Drive]
type=ChangeState
value=3150
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3000 &&var(20) <= 60 && power >= 1000
triggerall=!var(11) &&  command="MAXTwister Drive"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7)

[State -1, Twister Drive]
type=ChangeState
value=3100
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3000 &&var(20) <= 60 && power >= 1000
triggerall=!var(11) && command="Twister Drive"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)

[State -1, Max Chain Slide Touch]
type=ChangeState
value=3050
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3050 &&var(20) <= 60 && power >= 2000
triggerall=!var(11) && command="MAXChainSlideTouch"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7)
;----------------------------------------------------------------------
[State -1, Chain Slide Touch]
type=ChangeState
value=3000
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3000 &&var(20) <= 60 && power >= 1000
triggerall=!var(11) && command="ChainSlideTouch"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)
;----------------------------------------------------------------------
[State -1, Ankoku Orochi Nagi]
type=ChangeState
value=3300
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3300 &&var(20) <= 60 && power >= 1000
triggerall=var(11) && command="AnkokuOrochiNagi"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)
;----------------------------------------------------------------------
[State -1,Max Daichi no Kurau Gouka]
type=ChangeState
value=3450
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3450 &&var(20) <= 60 && power >= 2000
triggerall=var(11) && command="MAXDaichiNoKurauGouka"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7)

[State -1, Daichi no Kurau Gouka]
type=ChangeState
value=3400
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3400 &&var(20) <= 60 && power >= 1000
triggerall=var(11) && command="DaichiNoKurauGouka"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)
;----------------------------------------------------------------------
[State -1, Daichi o Harau Gouka]
type=ChangeState
value=3550
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3550 &&var(20) <= 60 && power >= 2000
triggerall=var(11) && command="MAXDaichioHarauGouka"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)||var(7)

[State -1, Daichi o Harau Gouka]
type=ChangeState
value=3500
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3500 &&var(20) <= 60 && power >= 1000
triggerall=var(11) && command="DaichioHarauGouka"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)
;----------------------------------------------------------------------
[State -1, Daichi o Harau Gouka]
type=ChangeState
value=3600
triggerall=!AILevel && RoundState=2 && StateType != A && stateno!=3600 &&var(20) <= 60 && power >= 3000
triggerall=var(11) && command="SanagiYaburiwowamauchou"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7)

[State -1,EX GliderStomp]
type=ChangeState
value=1630
triggerall=!AILevel && RoundState=2 && StateType = A && Pos y <= -30  && !var(11)
triggerall=(command="GliderStompEX"&&power>=500&&var(20) <= 60)
trigger1=ctrl
trigger2=var(5)

[State -1,EX Direction Change]
type = ChangeState
value = 1530
triggerall=!AILevel
triggerall = command = "EXdirectionchange"
triggerall = RoundState = 2 && StateType != A && !var(11)
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1,EX Shooting Dancer Step]
type = ChangeState
value = 1430
triggerall=!AILevel
triggerall = command = "ShootingDancerStepEX"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0) && !var(11)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
;========================================================================
[State -1,EX Tsuki wo Tsumu Honoo]
type=ChangeState
value = 1925
triggerall = var(11)
triggerall=!AILevel && RoundState=2 && StateType != A && (command="TsukiwoTsumuHonooEX" &&power>=500&&var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact

[State -1, Tsuki wo Tsumu Honoo]
type=ChangeState
value=1902
triggerall = var(11)
triggerall=!AILevel && RoundState=2 && StateType != A  && command="TsukiwoTsumuHonoo3"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact

[State -1, Tsuki wo Tsumu Honoo]
type=ChangeState
value=1901
triggerall = var(11)
triggerall=!AILevel && RoundState=2 && StateType != A  && command="TsukiwoTsumuHonoo2"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact

[State -1, Tsuki wo Tsumu Honoo]
type=ChangeState
value=1900
triggerall = var(11)
triggerall=!AILevel && RoundState=2 && StateType != A  && command="TsukiwoTsumuHonoo1"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact
;========================================================================
[State -1, Hunting Air]
type=ChangeState
value=Ifelse(command="HuntingAirEX"&&var(20) <= 60&&power>=500,1225,1200)
triggerall=!AILevel && RoundState=2 && StateType != A ;&& !var(11)
triggerall=((command="HuntingAir1")||(command="HuntingAir2")||(command="HuntingAir3")||(command="HuntingAirEX"&&power>=500&&var(20) <= 60))
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact && (command="HuntingAirEX"&&power>=500&&var(20) <= 60)
;========================================================================
[State -1, Scramble Dash]
type=ChangeState
value=Ifelse(command="ScrambleDashEX"&&var(20) <= 60&&power>=500,1325,1300)
triggerall=!AILevel && RoundState=2 && StateType != A && !var(11)
triggerall=((command="ScrambleDash1")||(command="ScrambleDash2")||(command="ScrambleDashEX"&&power>=500&&var(20) <= 60))
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact && (command="ScrambleDashEX"&&power>=500&&var(20) <= 60)
;========================================================================
[State -1, EX ShishiwoKamuHonoo]
type=ChangeState
value=2103
triggerall=!AILevel && RoundState=2 && StateType != A && var(11) && P2BodyDist x < 30
triggerall=(command="ShishiwoKamuHonooEX" &&power>=500 &&var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)

[State -1, Strong ShishiwoKamuHonoo]
type=ChangeState
value=2102
triggerall=!AILevel && RoundState=2 && StateType != A && var(11) && P2BodyDist x < 30
triggerall=(command="ShishiwoKamuHonoo3"&&var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)

[State -1, Medium ShishiwoKamuHonoo]
type=ChangeState
value=2101
triggerall=!AILevel && RoundState=2 && StateType != A && var(11) && P2BodyDist x < 30
triggerall=(command="ShishiwoKamuHonoo2"&&var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)

[State -1, Weak ShishiwoKamuHonoo]
type=ChangeState
value=2100
triggerall=!AILevel && RoundState=2 && StateType != A && var(11) && P2BodyDist x < 30
triggerall=(command="ShishiwoKamuHonoo"&&var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)

[State -1, GliderStomp]
type=ChangeState
value=1620
triggerall=!AILevel && RoundState=2 && StateType = A && Pos y <= -30 ;&& !var(11)
triggerall=(command="GliderStomp3"&&var(20) <= 60)
trigger1=ctrl
trigger2=var(5)

[State -1, GliderStomp]
type=ChangeState
value=1610
triggerall=!AILevel && RoundState=2 && StateType = A && Pos y <= -30 ;&& !var(11)
triggerall=(command="GliderStomp2"&&var(20) <= 60)
trigger1=ctrl
trigger2=var(5)

[State -1, GliderStomp]
type=ChangeState
value=1600
triggerall=!AILevel && RoundState=2 && StateType = A && Pos y <= -30 ;&& !var(11)
triggerall=(command="GliderStomp1"&&var(20) <= 60)
trigger1=ctrl
trigger2=var(5)

[State -1, Direction Change3]
type = ChangeState
value = 1520
triggerall=!AILevel
triggerall = command = "Directionchange3"
triggerall = RoundState = 2 && StateType != A && !var(11)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Direction Change2]
type = ChangeState
value = 1510
triggerall=!AILevel
triggerall = command = "Directionchange2"
triggerall = RoundState = 2 && StateType != A && !var(11)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Direction Change1]
type = ChangeState
value = 1500
triggerall=!AILevel
triggerall = command = "Directionchange1"
triggerall = RoundState = 2 && StateType != A && !var(11)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Shooting Dancer Step]
type = ChangeState
value = 1420
triggerall=!AILevel
triggerall = command = "ShootingDancerStep3"
triggerall = RoundState = 2 && StateType != A ;&& !var(11)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Shooting Dancer Step]
type = ChangeState
value = 1410
triggerall=!AILevel
triggerall = command = "ShootingDancerStep2"
triggerall = RoundState = 2 && StateType != A ;&& !var(11)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Shooting Dancer Step]
type = ChangeState
value = 1400
triggerall=!AILevel
triggerall = command = "ShootingDancerStep1"
triggerall = RoundState = 2 && StateType != A ;&& !var(11)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
;========================================================================
[State -1, Shooting Dancer: Thrust]
type=ChangeState
value=Ifelse(command="ShootingDancerThrustEX"&&var(20) <= 60&&power>=500,1125,1100)
triggerall=!AILevel && RoundState=2 && StateType != A && !var(11)
triggerall=((command="ShootingDancerThrust1")||(command="ShootingDancerThrust2")||(command="ShootingDancerThrust3")||(command="ShootingDancerThrustEX"&&power>=500&&var(20) <= 60))
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact && (command="ShootingDancerThrustEX"&&power>=500&&var(20) <= 60)
;========================================================================
[State -1, Slide Touch]
type=ChangeState
value=Ifelse(command="SlideTouchEX"&&var(20) <= 60&&power>=500,1025,1000)
triggerall=!AILevel && RoundState=2 && StateType != A && !var(11)
triggerall=((command="SlideTouch1")||(command="SlideTouch2")||(command="SlideTouch3")||(command="SlideTouchEX"&&power>=500&&var(20) <= 60))
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact && (command="SlideTouchEX"&&power>=500&&var(20) <= 60)
;========================================================================
[State -1, Taiyou wo Iru Honoo]
type=ChangeState
value=Ifelse(command="TaiyouwoIruHonooEX"&&var(20) <= 60&&power>=500,1825,1800)
triggerall=!AILevel && RoundState=2 && StateType != A && var(11) && !NumHelper(1810) && !NumHelper(1811)
triggerall=((command="TaiyouwoIruHonoo1")||(command="TaiyouwoIruHonoo2")||(command="TaiyouwoIruHonoo3")||(command="TaiyouwoIruHonooEX"&&power>=500&&var(20) <= 60))
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact && (command="TaiyouwoIruHonooEX"&&power>=500&&var(20) <= 60)
;========================================================================
[State -1,EX  Kagami wo Hofuru Honoo]
type=ChangeState
value = 2025
triggerall = var(11)
triggerall=!AILevel && RoundState=2 && StateType != A && (command="KagamiwoHofuruHonooEX" &&power>=500&&var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact

[State -1, Kagami wo Hofuru Honoo]
type=ChangeState
value=2002
triggerall = var(11)
triggerall=!AILevel && RoundState=2 && StateType != A  && command="KagamiwoHofuruHonoo3"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact

[State -1, Kagami wo Hofuru Honoo]
type=ChangeState
value=2001
triggerall = var(11)
triggerall=!AILevel && RoundState=2 && StateType != A  && command="KagamiwoHofuruHonoo2"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact

[State -1, Kagami wo Hofuru Honoo]
type=ChangeState
value=2000
triggerall = var(11)
triggerall=!AILevel && RoundState=2 && StateType != A  && command="KagamiwoHofuruHonoo1"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact

;========================================================================
[State -1, Zero Counter]
type = ChangeState
value = 750
triggerall=!AILevel
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = command = "412p" || command = "412k"
trigger1 = !AILevel&&RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)
;------------------------------------------------------------------------
[State -1, Throw]
type=ChangeState
value =800
triggerall=!AILevel
trigger1=(command="holdfwd"||command="holdback")&&(command="pp"||command="kk")
trigger1=!AILevel&&RoundState=2 && Statetype!=A && !var(20)
trigger1=ctrl
;-------------------------------------------------------------------------
[State -1, Power Charge]
type = ChangeState
value = 730
triggerall=!AILevel
trigger1 = command = "hold_b" && command = "hold_y"
trigger1 = !AILevel&&RoundState = 2 && StateType != A
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (StateNo = [100,101])
;--------------------------------------------------------------------------
[State -1, Super Jump]
type = ChangeState
value = 123
triggerall= !AILevel && var(55)=2 && roundstate=2 && statetype != A
trigger1 = ctrl && command = "DU"
trigger2 = stateno=420 && animelemtime(6)>=1 && movehit && command = "holdup"
;--------------------------------------------------------------------------
[State -1, SIdestep/Dodge]
type = ChangeState
value = Ifelse(command="holdfwd",710,Ifelse(command="holdback",715,700))
triggerall = command = "a+x"
triggerall = !AILevel && RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))
;--------------------------------------------------------------------------
[State -1, Custom Combo]
type = ChangeState
value = Ifelse(StateType = A,905,900)
triggerAll = !AILevel && command = "c+z" && RoundState = 2 && power >= 1000 && !var(20)
trigger1 = ctrl || StateNo = 52 || (StateNo = [100,101])
;--------------------------------------------------------------------------
[State -1, Run /Dash Back]
type = ChangeState
value = Ifelse(command = "BB",105,100)
trigger1 = !AILevel&&Roundstate=2&&statetype = S
trigger1 = command = "FF"||command = "BB"
trigger1 = ctrl
;--------------------------------------------------------------------------
[State -1, Standing Low Punch]
type=ChangeState
value=200
triggerall=!AILevel&& roundstate=2 && statetype != A&&command != "holddown"&& command="x"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=(stateno=[430,439])&&movecontact&&!var(55)
trigger4 = StateNo = 200 && MoveContact  && Time >= 4

[State -1, Fwd Standing High Punch]
type=ChangeState
value=222
triggerall=!AILevel&& roundstate=2 && statetype != A&&command = "holdfwd"&& command="x"
triggerall = command != "holddown"
trigger1=ctrl
trigger2=var(4)
trigger3=((stateno=[200,219])||(stateno=[230,249])||(stateno=[400,419])||(stateno=[430,449]))&&movecontact&&var(55)
trigger4=(stateno=[200,210])&&movecontact&&!var(55)
;---------------------------------------------------------------------------
[State -1, Standing Medium Punch]
type=ChangeState
value=210
triggerall=!AILevel&& roundstate=2 && statetype != A&&command != "holddown"&& command="y"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,209])||(stateno=[230,239])||(stateno=[400,409])||(stateno=[430,439]))&&movecontact&&var(55)
trigger4=((stateno=[200,209])||(stateno=[400,409]))&&movecontact&&!var(55)
trigger5=(stateno=[430,439])&&movecontact&&!var(55)
;---------------------------------------------------------------------------
[State -1, Standing High Punch]
type=ChangeState
value=220
triggerall=!AILevel&& roundstate=2 && statetype != A&&command != "holddown"&& command="z"
trigger1=ctrl ||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,219])||(stateno=[230,249])||(stateno=[400,419])||(stateno=[430,449]))&&movecontact&&var(55)
trigger4=(stateno=[200,209])&&movecontact&&!var(55)
;---------------------------------------------------------------------------
[State -1, Standing Low Kick]
type=ChangeState
value=230
triggerall=!AILevel&& roundstate=2 && statetype != A&&command != "holddown"&& command="a"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=(stateno=[200,209])&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Standing Medium Kick]
type=ChangeState
value=240
triggerall=!AILevel&& roundstate=2 && statetype != A&&command != "holddown"&& command="b"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,219])||(stateno=[230,239])||(stateno=[400,419])||(stateno=[430,439]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Standing High Kick]
type=ChangeState
value=250
triggerall=!AILevel&& roundstate=2 && statetype != A&&command != "holddown"&& command="c"
trigger1=ctrl ||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,249])||(stateno=[400,449]))&&movecontact&&var(55)
trigger4=((stateno=[230,239])||(stateno=[430,439]))&&movecontact&&!var(55)
;---------------------------------------------------------------------------
[State -1, Crouching Low Punch]
type=ChangeState
value=400
triggerall=!AILevel&& roundstate=2 && statetype != A&&command="holddown"&& command="x"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3 = StateNo = 400 && MoveContact && Time >= 4
;---------------------------------------------------------------------------
[State -1, Crouching Medium Punch]
type=ChangeState
value=410
triggerall=!AILevel&& roundstate=2 && statetype != A&&command= "holddown"&& command="y"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,209])||(stateno=[230,239])||(stateno=[400,409])||(stateno=[430,439]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Crouching High Punch]
type=ChangeState
value=420
triggerall=!AILevel&& roundstate=2 && statetype != A&&command="holddown"&& command="z"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,219])||(stateno=[230,249])||(stateno=[400,419])||(stateno=[430,449]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Crouching Low Kick]
type=ChangeState
value=430
triggerall=!AILevel&& roundstate=2 && statetype != A&&command="holddown"&& command="a"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,209])||(stateno=[400,409]))&&movecontact&&var(55)
trigger4=((stateno=[400,409])||(stateno=[430,439]))&&movecontact&&!var(55)
;---------------------------------------------------------------------------
[State -1, Crouching Medium Kick]
type=ChangeState
value=440
triggerall=!AILevel&& roundstate=2 && statetype != A&&command="holddown"&& command="b"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,219])||(stateno=[230,239])||(stateno=[400,419])||(stateno=[430,439]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Crouching High Kick]
type=ChangeState
value=450
triggerall=!AILevel&& roundstate=2 && statetype != A&&command="holddown"&& command="c"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,249])||(stateno=[400,449]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Jumping Low Punch]
type=ChangeState
value=600
triggerall=!AILevel&& roundstate=2 && statetype=A&&command="x"
trigger1=ctrl
trigger2=var(4)
;---------------------------------------------------------------------------
[State -1, Jumping Medium Punch]
type=ChangeState
value=610
triggerall=!AILevel&& roundstate=2 && statetype=A&&command="y"
trigger1=ctrl
trigger2=var(4)
trigger3=((stateno=[600,609])||(stateno=[630,639]))&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Jumping High Punch]
type=ChangeState
value=620
triggerall=!AILevel&& roundstate=2 && statetype=A&&command="z"
trigger1=ctrl
trigger2=var(4)
trigger3=((stateno=[600,619])||(stateno=[630,649]))&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Jumping Low Kick]
type=ChangeState
value=630
triggerall=!AILevel&& roundstate=2 && statetype=A&&command="a"
trigger1=ctrl
trigger2=var(4)
trigger3=(stateno=[600,609])&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Jumping Medium Kick]
type=ChangeState
value=640
triggerall=!AILevel&& roundstate=2 && statetype=A&&command="b"
trigger1=ctrl
trigger2=var(4)
trigger3=((stateno=[600,619])||(stateno=[630,639]))&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Jumping High Kick]
type=ChangeState
value=650
triggerall=!AILevel&& roundstate=2 && statetype=A&&command="c"
trigger1=ctrl
trigger2=var(4)
trigger3=(stateno=[600,649])&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = command = "s"
triggerall = !AILevel&& roundstate=2 && statetype != A
triggerall = StateNo != [200,699]
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = var(5)
;--------------------------------------------------------------------------
;AI
;--------------------------------------------------------------------------
;----------------------------------------------------------------
[State -1, AI Parry Stand]
type = HitOverride
triggerall = AILevel&&statetype != A && ctrl
trigger1 = random < (250 * (AIlevel ** 2 / 64.0))
slot = 0
stateno = 6080
attr = SA, AA, AP
time = 3
;---------------------------------------------------------------
[State -1, AI Crouching Parry]
type = HitOverride
triggerall = AILevel&&statetype != A && ctrl
trigger1 =random < (250 * (AIlevel ** 2 / 64.0))
slot = 0
stateno = 6081
attr = C, AA, AP
time = 3
;---------------------------------------------------------------
[State -1, AI Aerial Parry]
type = HitOverride
triggerall = AILevel&& statetype = A && ctrl
trigger1 = random < (250 * (AIlevel ** 2 / 64.0))
slot = 0
stateno = 6082
attr = SCA, AA, AP
time = 3

[State -1, AI Guard]
type = ChangeState
triggerall = AILevel
triggerall = RoundState = 2
triggerall = Alive
triggerall = Ctrl
triggerall = MoveType != H
triggerall = StateType != A
triggerall = NumEnemy
triggerall = P2MoveType = A
triggerall = P2BodyDist X < 60
trigger1 = Random < 600
value = 120

[State -1, AI Guard]
type = ChangeState
triggerall = AILevel
triggerall = RoundState = 2
triggerall = Alive
triggerall = Ctrl
triggerall = MoveType != H
triggerall = StateType != A
triggerall = p2StateType = C
triggerall = NumEnemy
triggerall = P2MoveType = A
triggerall = P2BodyDist X < 60
trigger1 = Random < 600
value = 131

[State -1, AI combo 01 pt01]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S && movetype != H
triggerall = p2statetype = S
triggerall = p2statetype != L
triggerall = p2stateno != 5050
trigger1 = Random <=600
trigger1 = p2bodydist X <= 30 && Random <=800
trigger1 = statetype != A
trigger1 = ctrl
value = 200

[State -1, AI combo 01 pt02]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S
triggerall = p2statetype != A
triggerall = stateno = 200 && movecontact && Random <=900
trigger1 = Random <=500
value = 230

[State -1, AI combo 01 pt03]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S
triggerall = p2statetype != A
triggerall = stateno = 230 && movecontact && Random <=900
trigger1 = Random <=500
value = 220

[State -1, AI combo 04 pt01]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S
triggerall = p2statetype != A
triggerall = stateno = 220 && movecontact && Random <=900
trigger1 = Random <=500
value = 1900;1900

;[State -1, AI combo 04 pt01.02]
;type = changestate
;triggerall = AILevel && NumEnemy
;triggerall = RoundState = 2 && Alive
;triggerall = statetype = S
;triggerall = p2statetype != A
;triggerall = stateno = 1000 && movecontact && Random <=900
;trigger1 = Random <=800
;value = 1001

[State -1, AI combo 04 pt02]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S
triggerall = p2statetype != A
triggerall = stateno = 220 && movecontact && Random <=900
trigger1 = Random <=500
value = 2000

[State -1, AI crounch combo 01 pt01]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = p2statetype = C
triggerall = p2statetype != A
triggerall = statetype != A && movetype != H
triggerall = p2stateno != 5050
triggerall = p2statetype != L
trigger1 = Random <=600
trigger1 = p2bodydist X <= 30 && Random <=800
trigger1 = ctrl
value = 400

[State -1, AI crounch combo 01 pt02]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = C
triggerall = p2statetype != A
triggerall = stateno = 400 && movecontact && Random <=900
trigger1 = Random <=500
value = 430

[State -1, AI crounch combo 01 pt03]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = C
triggerall = p2statetype != A
triggerall = stateno = 430 && movecontact && Random <=900
trigger1 = Random <=500
value = 450

[State -1, AI special 01]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S && movetype != H
triggerall = p2statetype != A
triggerall = p2statetype != L
triggerall = p2stateno != 5050
triggerall = p2stateno != 1000
trigger1 = Random <=350
trigger1 = p2bodydist X <= 40 && Random <=600
trigger1 = statetype != A
trigger1 = ctrl
value = 2000

[State -1, AI special 02]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S && movetype != H
triggerall = p2statetype != A
triggerall = p2statetype != L
triggerall = p2stateno != 5050
triggerall = p2stateno != 1000
trigger1 = Random <=350
trigger1 = p2bodydist X <= 60 && Random <=600
trigger1 = statetype != A
trigger1 = ctrl
value = 1800

[State -1, AI Super Light 01]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S && movetype != H
triggerall = p2statetype != A
triggerall = p2stateno != 5050
triggerall = power >=1000
trigger1 = Random <=880
triggerall = p2statetype != L
trigger1 = p2bodydist X <= 40 && Random <=900
trigger1 = statetype != A
trigger1 = ctrl
value = 3300

[State -1, AI Super Medium 01]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S && movetype != H
triggerall = p2statetype != A
triggerall = p2stateno != 5050
triggerall = power >=2000
trigger1 = Random <=880
triggerall = p2statetype != L
trigger1 = p2bodydist X <= 65 && Random <=900
trigger1 = statetype != A
trigger1 = ctrl
value = 3450

[State -1, AI Super Medium 02]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S && movetype != H
triggerall = p2statetype != A
triggerall = p2stateno != 5050
triggerall = power >=2000
trigger1 = Random <=880
triggerall = p2statetype != L
trigger1 = p2bodydist X <= 40 && Random <=900
trigger1 = statetype != A
trigger1 = ctrl
value = 3350

[State -1, AI Super MAX]
type = changestate
triggerall = AILevel && NumEnemy
triggerall = RoundState = 2 && Alive
triggerall = statetype = S && movetype != H
triggerall = p2statetype != A
triggerall = p2stateno != 5050
triggerall = p2stateno != 3600
triggerall = power >=3000
trigger1 = Random <=900
triggerall = p2statetype != L
trigger1 = p2bodydist X <= 60 && Random <=1000
trigger1 = statetype != A
trigger1 = ctrl
value = 3600
