;-| Button Remapping |-----------------------------------------------------
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s
;-| Default Values |-------------------------------------------------------
[Defaults]
command.time = 15
command.buffer.time = 1

;-| Super Motions |--------------------------------------------------------

[Command]
Name = "SGS"
Command = ~D, DB, B, D, DB, x+y
Time = 32

[Command]
Name = "SGS"
Command = ~D, DB, B, D, DB, x+z
Time = 32

[Command]
Name = "SGS"
Command = ~D, DB, B, D, DB, z+y
Time = 32

[Command]
Name = "ShinShoryuken"
Command = ~D, DF, F, $D, B, x+y
Time = 40

[Command]
Name = "ShinShoryuken"
Command = ~D, DF, F, $D, B, x+z
Time = 40

[Command]
Name = "ShinShoryuken"
Command = ~D, DF, F, $D, B, y+z
Time = 40

[Command]
name = "Shoryureppa"
command = ~D, DF, F, D, DF, a
time = 32

[Command]
name = "Shoryureppa"
command = ~D, DF, F, D, DF, ~a
time = 32

[Command]
name = "Shoryureppa"
command = ~D, DF, F, D, DF, b
time = 32

[Command]
name = "Shoryureppa"
command = ~D, DF, F, D, DF, ~b
time = 32

[Command]
name = "Shoryureppa"
command = ~D, DF, F, D, DF, c
time = 32

[Command]
name = "Shoryureppa"
command = ~D, DF, F, D, DF, ~c
time = 32

[Command]
name = "ShoryureppaMax"
command = ~D, DF, F, D, DF, a+b
time = 32

[Command]
name = "ShoryureppaMax"
command = ~D, DF, F, D, DF, a+c
time = 32

[Command]
name = "ShoryureppaMax"
command = ~D, DF, F, D, DF, b+c
time = 32

[Command]
name = "Chou Shoryuken"
command = ~D, DB, B, D, DB, a
time = 32

[Command]
name = "Chou Shoryuken"
command = ~D, DB, B, D, DB, ~a
time = 32

[Command]
name = "Chou Shoryuken"
command = ~D, DB, B, D, DB, b
time = 32

[Command]
name = "Chou Shoryuken"
command = ~D, DB, B, D, DB, ~b
time = 32

[Command]
name = "Chou Shoryuken"
command = ~D, DB, B, D, DB, c
time = 32

[Command]
name = "Chou Shoryuken"
command = ~D, DB, B, D, DB, ~c
time = 32

[Command]
name = "Chou ShoryukenMAX"
command = ~D, DB, B, D, DB, a+b
time = 32

[Command]
name = "Chou ShoryukenMAX"
command = ~D, DB, B, D, DB, a+c
time = 32

[Command]
name = "Chou ShoryukenMAX"
command = ~D, DB, B, D, DB, c+b
time = 32

[Command]
name = "Shinku Hadouken"
command = ~D, DF, F, D, DF, x
time = 32

[Command]
name = "Shinku Hadouken"
command = ~D, DF, F, D, DF, ~x
time = 32

[Command]
name = "Shinku Hadouken"
command = ~D, DF, F, D, DF, y
time = 32

[Command]
name = "Shinku Hadouken"
command = ~D, DF, F, D, DF, ~y
time = 32

[Command]
name = "Shinku Hadouken"
command = ~D, DF, F, D, DF, z
time = 32

[Command]
name = "Shinku Hadouken"
command = ~D, DF, F, D, DF, ~z
time = 32

[Command]
name = "Shinku HadoukenMax"
command = ~D, DF, F, D, DF, x+y
time = 32

[Command]
name = "Shinku HadoukenMax"
command = ~D, DF, F, D, DF, y+z
time = 32

[Command]
name = "Shinku HadoukenMax"
command = ~D, DF, F, D, DF, x+z
time = 32

;-| Special Motions |------------------------------------------------------
[Command]
name = "Nana Otosi Geri"
command = ~D, DF, F, a
time = 15

[Command]
name = "Nana Otosi Geri"
command = ~D, DF, F, ~a
time = 15

[Command]
name = "Kama Harai Geri"
command = ~D, DF, F, b
time = 15

[Command]
name = "Kama Harai Geri"
command = ~D, DF, F, ~b
time = 15

[Command]
name = "Osoto Mawashi Geri"
command = ~D, DF, F, c
time = 15

[Command]
name = "Osoto Mawashi Geri"
command = ~D, DF, F, ~c
time = 15

[Command]
name = "Shoryuken"
command = ~F, D, DF, x
time = 18

[Command]
name = "Shoryuken"
command = ~F, D, DF, ~x
time = 18

[Command]
name = "Shoryuken2"
command = ~F, D, DF, y
time = 18

[Command]
name = "Shoryuken2"
command = ~F, D, DF, ~y
time = 18

[Command]
name = "Shoryuken3"
command = ~F, D, DF, z
time = 18

[Command]
name = "Shoryuken3"
command = ~F, D, DF, ~z
time = 18

[Command]
name = "EX Shoryuken"
command = ~F, D, DF, x+y
time = 18

[Command]
name = "EX Shoryuken"
command = ~F, D, DF, y+z
time = 18

[Command]
name = "EX Shoryuken"
command = ~F, D, DF, x+z
time = 18

[Command]
name = "Hadouken"
command = ~D, DF, F, x
time = 15

[Command]
name = "Hadouken"
command = ~D, DF, F, ~x
time = 15

[Command]
name = "Hadouken"
command = ~D, DF, F, y
time = 15

[Command]
name = "Hadouken"
command = ~D, DF, F, ~y
time = 15

[Command]
name = "Hadouken"
command = ~D, DF, F, z
time = 15

[Command]
name = "Hadouken"
command = ~D, DF, F, ~z
time = 15

[Command]
name = "EX Hadouken"
command = ~D, DF, F, x+y
time = 15

[Command]
name = "EX Hadouken"
command = ~D, DF, F, x+z
time = 15

[Command]
name = "EX Hadouken"
command = ~D, DF, F, z+y
time = 15

[Command]
name = "Tatsumaki Senpukyaku"
command = ~D, DB, B, a
time = 15

[Command]
name = "Tatsumaki Senpukyaku"
command = ~D, DB, B, ~a
time = 15

[Command]
name = "Tatsumaki Senpukyaku2"
command = ~D, DB, B, b
time = 15

[Command]
name = "Tatsumaki Senpukyaku2"
command = ~D, DB, B, ~b
time = 15

[Command]
name = "Tatsumaki Senpukyaku3"
command = ~D, DB, B, c
time = 15

[Command]
name = "Tatsumaki Senpukyaku3"
command = ~D, DB, B, ~c
time = 15

[Command]
name = "Airborne Tatsumaki Senpukyaku"
command = ~D, DB, B, a
time = 15

[Command]
name = "Airborne Tatsumaki Senpukyaku"
command = ~D, DB, B, ~a
time = 15

[Command]
name = "Airborne Tatsumaki Senpukyaku"
command = ~D, DB, B, b
time = 15

[Command]
name = "Airborne Tatsumaki Senpukyaku"
command = ~D, DB, B, ~b
time = 15

[Command]
name = "Airborne Tatsumaki Senpukyaku"
command = ~D, DB, B, c
time = 15

[Command]
name = "Airborne Tatsumaki Senpukyaku"
command = ~D, DB, B, ~c
time = 15

[Command]
name = "EX Tatsumaki Senpukyaku"
command = ~D, DB, B, a+b
time = 15

[Command]
name = "EX Tatsumaki Senpukyaku"
command = ~D, DB, B, b+c
time = 15

[Command]
name = "EX Tatsumaki Senpukyaku"
command = ~D, DB, B, a+c
time = 15

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, z
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~z
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, b
time = 16

[Command]
name=  "412k" ;Zero Counter
command = ~B, DB, D, c
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~b
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~c
time = 16

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1

[Command]
name = "recovery"
command = y+z
time = 1

[Command]
name = "recovery"
command = x+z
time = 1

[Command]
name = "recovery"
command = a+x
time = 1

[Command]
name = "pp"
command = x+y
time = 1

[Command]
name = "pp"
command = x+z
time = 1

[Command]
name = "pp"
command = y+z
time = 1

[Command]
name = "kk"
command = a+b
time = 1

[Command]
name = "kk"
command = a+c
time = 1

[Command]
name = "kk"
command = b+c
time = 1

[Command]
name = "a+x"
command = a+x
time=1

[Command]
name = "b+y"
command = b+y
time = 1

[Command]
name = "c+z"
command = c+z
time = 1

;-| Dir + Button |---------------------------------------------------------
[Command]
name = "back_x"
command = /$B,x
time = 1

[Command]
name = "back_y"
command = /$B,y
time = 1

[Command]
name = "back_z"
command = /$B,z
time = 1

[Command]
name = "down_x"
command = /$D,x
time = 1

[Command]
name = "down_y"
command = /$D,y
time = 1

[Command]
name = "down_z"
command = /$D,z
time = 1

[Command]
name = "fwd_x"
command = /$F,x
time = 1

[Command]
name = "fwd_y"
command = /$F,y
time = 1

[Command]
name = "fwd_z"
command = /$F,z
time = 1

[Command]
name = "fwd_s"
command = /$F,s
time = 1

[Command]
name = "up_x"
command = /$U,x
time = 1

[Command]
name = "up_y"
command = /$U,y
time = 1

[Command]
name = "up_z"
command = /$U,z
time = 1

[Command]
name = "back_a"
command = /$B,a
time = 1

[Command]
name = "back_b"
command = /$B,b
time = 1

[Command]
name = "back_c"
command = /$B,c
time = 1

[Command]
name = "back_s"
command = /$B,s
time = 1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

[Command]
name = "down_c"
command = /$D,c
time = 1

[Command]
name = "fwd_a"
command = /$F,a
time = 1

[Command]
name = "fwd_b"
command = /$F,b
time = 1

[Command]
name = "fwd_c"
command = /$F,c
time = 1

[Command]
name = "up_a"
command = /$U,a
time = 1

[Command]
name = "up_b"
command = /$U,b
time = 1

[Command]
name = "up_c"
command = /$U,c
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1

;-| Single Dir |------------------------------------------------------------
[Command]
name = "fwd" ;Required (do not remove)
command = $F
time = 1

[Command]
name = "downfwd"
command = $DF
time = 1

[Command]
name = "down" ;Required (do not remove)
command = $D
time = 1

[Command]
name = "downback"
command = $DB
time = 1

[Command]
name = "back" ;Required (do not remove)
command = $B
time = 1

[Command]
name = "upback"
command = $UB
time = 1

[Command]
name = "up" ;Required (do not remove)
command = $U
time = 1

[Command]
name = "upfwd"
command = $UF
time = 1

;-| Hold Button |--------------------------------------------------------------
[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_s"
command = /s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holdfwd" ;Required (do not remove)
command = /$F
time = 1

[Command]
name = "holddownfwd"
command = /$DF
time = 1

[Command]
name = "holddown" ;Required (do not remove)
command = /$D
time = 1

[Command]
name = "holddownback"
command = /$DB
time = 1

[Command]
name = "holdback" ;Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdupback"
command = /$UB
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holdupfwd"
command = /$UF
time = 1

;---------------------------------------------------------------------------
;Release Direction
[Command]
name = "rlsfwd"
command = ~$F
time = 1

[Command]
name = "rlsback"
command = ~$B
time = 1

[Command]
name = "rlsup"
command = ~$U
time = 1

[Command]
name = "rlsdown"
command = ~$D
time = 1

;--------------------------------------------------------------------------
;Release Button
[Command]
name = "rlsx"
command = ~x
time = 1

[Command]
name = "rlsy"
command = ~y
time = 1

[Command]
name = "rlsz"
command = ~z
time = 1

[Command]
name = "rlsa"
command = ~a
time = 1

[Command]
name = "rlsb"
command = ~b
time = 1

[Command]
name = "rlsc"
command = ~c
time = 1
;---------------------------------------------------------------------------
;Other
[Command]
name = "highjump"
command = $D, $U
time = 15
;---------------------------------------------------------------------------
[Statedef -1]

[State -1, Tick Fix]
type = CtrlSet
triggerall = !ctrl
trigger1 = (StateNo = 52 || StateNo = 101 || StateNo = 5120) && !AnimTime
trigger2 = (StateNo = [200,499]) && !AnimTime
trigger3 = (StateNo = [760,762]) && !AnimTime
trigger4 = StateNo = 810 && !AnimTime
trigger5 = (StateNo = 5001 || StateNo = 5011 || StateNo = 151 || StateNo = 153) && HitOver
trigger6 = (StateNo = [700,715]) && !AnimTime
value = 1

[State -1, CtrlSet For Helpers];special thanks to 20S
type = CtrlSet
trigger1 = IsHelper
value = 0

[State -1, Hit Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(13) = 1

[State -1, Juggle Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(15) = 1

[State -1, ProjContact];special thanks to 20S
type = VarSet
trigger1 = IsHelper
trigger1 = MoveContact = 1 && NumTarget
var(18) = 1

[State -1, Root ProjContact];special thanks to 20S
type = ParentVarSet
trigger1 = IsHelper
trigger1 = MoveContact = 1 && NumTarget
var(18) = 1

[State -1, Cyborg Destruction]
type = ChangeState
value = 4100
triggerall = command = "SGS"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)
trigger3 = (StateNo =[200,250])

[State -1, Shoryureppa Max]
type = ChangeState
value = 3150
triggerall = command = "Chou ShoryukenMAX"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)

[State -1, Chou Shoryuken]
type = ChangeState
value = 3100
triggerall = command = "Chou Shoryuken"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)

[State -1, Shoryureppa Max]
type = ChangeState
value = 3250
triggerall = command = "ShoryureppaMax"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)

[State -1, Shoryureppa]
type = ChangeState
value = 3200
triggerall = command = "Shoryureppa"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)

[State -1, Shinku Hadouken Max]
type = ChangeState
value = 3050
triggerall = command = "Shinku HadoukenMax" 
triggerall = RoundState = 2 && StateType != A
triggerall = !Var(39)
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101]) || var(6) || var(7) 
trigger1 = NumHelper(3060) <= 0
trigger2 = NumHelper(3060) <= 1
trigger2 = Helper(3060),StateNo = [3015,3016]

[State -1, Shinku Hadouken]
type = ChangeState
value = 3000
triggerall = command = "Shinku Hadouken" 
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101]) || var(6)
trigger1 = NumHelper(3010) <= 0
trigger2 = NumHelper(3010) <= 1
trigger2 = Helper(3010),StateNo = [3015,3016]

[State -1, EX Airborne Tatsumaki Senpukyaku]
type = ChangeState
value = 1265
triggerall = command = "EX Tatsumaki Senpukyaku"
triggerall = RoundState = 2 && StateType = A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerAll = (var(3) != [1,2])
trigger1 = ctrl
trigger2 = StateNo = 600 && MoveContact
trigger3 = (StateNo = 630 || StateNo = 635) && MoveContact

[State -1, EX Tatsumaki Senpukyaku]
type = ChangeState
value = 1250
triggerall = command = "EX Tatsumaki Senpukyaku"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, EX Shoryuken]
type = ChangeState
value = 1050
triggerall = command = "EX Shoryuken"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, EX Hadouken]
type = ChangeState
value = 1150
triggerall = command = "EX Hadouken"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
triggerall = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101]) || var(5)
trigger1 = NumHelper(1110) <= 0
trigger2 = NumHelper(1110) <= 1
trigger2 = Helper(1110),StateNo = [1115,1116]

[State -1, Airborne Tatsumaki Senpukyaku]
type = ChangeState
value = 1260
triggerall = command = "Airborne Tatsumaki Senpukyaku"
triggerall = RoundState = 2 && StateType = A
triggerAll = (var(3) != [1,2])
trigger1 = ctrl
trigger2 = StateNo = 600 && MoveContact
trigger3 = (StateNo = 630 || StateNo = 635) && MoveContact

[State -1, Strong Tatsumaki Senpukyaku]
type = ChangeState
value = 1220
triggerall = command = "Tatsumaki Senpukyaku3"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Medium Tatsumaki Senpukyaku]
type = ChangeState
value = 1210
triggerall = command = "Tatsumaki Senpukyaku2"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Light Tatsumaki Senpukyaku]
type = ChangeState
value = 1200
triggerall = command = "Tatsumaki Senpukyaku"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Strong Shoryuken]
type = ChangeState
value = 1020
triggerall = command = "Shoryuken3"
triggerall = RoundState = 2 && StateType != A
triggerall = !Var(51)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Medium Shoryuken]
type = ChangeState
value = 1010
triggerall = command = "Shoryuken2"
triggerall = RoundState = 2 && StateType != A
triggerall = !Var(51)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Light Shoryuken]
type = ChangeState
value = 1000
triggerall = command = "Shoryuken"
triggerall = RoundState = 2 && StateType != A
triggerall = !Var(51)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Osoto Mawashi Geri]
type = ChangeState
value = 1320
triggerall = command = "Osoto Mawashi Geri"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Kama Harai Geri]
type = ChangeState
value = 1310
triggerall = command = "Kama Harai Geri"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Nana Otosi Geri]
type = ChangeState
value = 1300
triggerall = command = "Nana Otosi Geri"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Inazuma Kakato Geri (Special)]
type = ChangeState
value = 1305
triggerAll = command = "hold_a" || command = "hold_b" || command = "hold_c"
triggerAll = RoundState = 2 && StateType != A
trigger1 = StateNo = 1300 && AnimElem = 6 ;&& MoveContact
trigger2 = StateNo = 1310 && AnimElem = 4 ;&& MoveContact
trigger3 = StateNo = 1320 && AnimElem = 6 

[State -1, Hadouken]
type = ChangeState
value = 1100
triggerall = command = "Hadouken"
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101]) || var(5)
trigger1 = NumHelper(1110) <= 0
trigger2 = NumHelper(1110) <= 1
trigger2 = Helper(1110),StateNo = [1115,1116]

[State -1, Zero Counter]
type = ChangeState
value = 750
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = command = "412p" || command = "412k"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1, Air Throw]
type = ChangeState
value = 870
triggerAll = Var(51)
triggerAll = RoundState = 2 && StateType = A
triggerAll = ctrl && pos y <= -32
trigger1 = (command = "holdfwd" || command = "holdback") && command = "pp" 

[State -1, Throw]
type = ChangeState
value = 800
trigger1 = (command = "holdfwd" || command = "holdback") && (command = "pp"||command = "kk")
trigger1 = RoundState = 2 && StateType = S
trigger1 = ctrl

[State -1, Roll Forward]
type = ChangeState
value = 710
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdfwd"

[State -1, Roll Back]
type = ChangeState
value = 715
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdback"

[State -1, Power Charge]
type = ChangeState
value = 730
trigger1 = command = "hold_b" && command = "hold_y"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (StateNo = [100,101])

[State -1, MAX Mode]
type = ChangeState
value = 770
triggerall = command = "c+z"
triggerall = RoundState = 2 && StateType != A
triggerall = var(20) <= 0 && Power >= 1000
trigger1 = ctrl || (Stateno = [100,101])

[State -1, Dodge]
type = ChangeState
value = 700
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))

[State -1, Dash Forward/Run]
type = ChangeState
value = 100
trigger1 = command = "FF"
trigger1 = roundstate = 2 && StateType = S
trigger1 = ctrl

[State -1, Run Back]
type = ChangeState
value = 105
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;--------------------------------------------------------------------------

[State -1, Inazuma Kakato Wari]
type = ChangeState
value = 249
triggerAll = command != "holddown"  
triggerall = command = "holdfwd" && command = "b"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])

[State -1, Stand Light Punch]
type = ChangeState
value = 200 + (Abs(P2BodyDist X) <= 25) * 5
triggerall = command = "x"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2 = (StateNo = 200 || Stateno = 205 || StateNo = 400 || StateNo = 430) && Time >=5 && Time >=5

[State -1, Stand Medium Punch]
type = ChangeState
value = 210 + (Abs(P2BodyDist X) <= 15) * 5
triggerall = command = "y"
triggerall = command != "holddown"  
triggerall = StateType != A
triggerall = !var(51)
trigger1 = ctrl || (StateNo = [100,101])

[State -1, Target Combo 1]
type = ChangeState
value = 226
triggerall = command = "z"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1 = StateNo = 215 && AnimElemTime(5) < 0 && MoveContact

[State -1, Stand Strong Punch]
type = ChangeState
value = 220 + (Abs(P2BodyDist X) <= 25) * 5
triggerall = command = "z"
triggerall = command != "holddown" 
triggerall = StateType != A
trigger1 = ctrl || (StateNo = [100,101])

[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])

[State -1, Stand Medium Kick]
type = ChangeState
value = 240 + (Abs(P2BodyDist X) <= 15) * 5
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])

[State -1, Standing Strong Kick]
type = ChangeState
value = 250 + (Abs(P2BodyDist X) <= 25) * 5
triggerall = command = "c"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])

[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerAll = command = "holddown" && command = "x"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2= (StateNo = 200 || StateNo = 400 || StateNo = 430) && Time >=5

[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerAll = command = "holddown" && command = "y"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])

[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
triggerAll = command = "holddown" && command = "z"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])

[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerAll = command = "holddown" && command = "a"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2= (StateNo = 200 || StateNo = 400 || StateNo = 430) && Time >=5

[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerAll = command = "holddown" && command = "b"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = StateNo = 410 && AnimElemTime(3) = [3,4]

[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerAll = command = "holddown" && command = "c"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = StateNo = 410 && AnimElemTime(3) = 4

[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Medium Punch]
type = ChangeState
value = 610
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Punch]
type = ChangeState
value = 620
triggerall = command = "z"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerall = (command = "a") && (Vel X != 0)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Light Kick]
type = ChangeState
value = 635
triggerall = (command = "a") && (Vel X = 0)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Medium Kick]
type = ChangeState
value = 640
triggerall = (command = "b") && (Vel X != 0)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Medium Kick]
type = ChangeState
value = 645
triggerall = (command = "b") && (Vel X = 0)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerall = (command = "c") && (Vel X != 0)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Kick]
type = ChangeState
value = 655
triggerall = (command = "c") && (Vel X = 0)
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Taunt 3]
type = ChangeState
value = 199
triggerall = command = "back_s"
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Taunt 2]
type = ChangeState
value = 198
triggerall = command = "fwd_s"
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Taunt]
type = ChangeState
value = 195
triggerall = command = "s"
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = var(5)