                                                                     
                                ___________________________________
===============================|        Cyborg by V�ctorys         |==============================
                                �����������������������������������        [07.05.2014]
 
 - Email: yiazmat.omega_victorys@hotmail.com
 - Website: http://yiazmatomegavictorys.wix.com/mugenvictorys
 - Customized version of Capcom's Cyborg character, for Mugen 1.0


=====<Features>=====

 - All the essential stuff.
 - Moves taken from Ryu and Ken.
 - Gameplay mixed from several games, such as CvS2, SFZ3 and SF3.

=====<Palette Selection>=====

This character has an unique method of selecting palettes. In the folder "Palette Configuration", there is a text file. The palettes chosen in that text file determine which palettes are able to be selected in MUGEN. Inside the "Palette Configuration" folder, there is another folder called "Palette Guides"; inside, there are images of all the avaliable palettes, each has a number in its filename. Choose what button you want the pal to be assigned by editing it like in the following example: 
 
[State 5900, Palette 1 (x)] 
type = VarSet 
trigger1 = PalNo = 1 
var(0) = 1 ;CHANGE THIS LINE
 
This represents the palette chosen if you select Cyborg using the x button. Simply change the number to the right of "var(O) =" with the desired palette number. So, if we wanted the palette number 3 to be used for x we would use 
 
[State 5900, Palette 1 (x)] 
type = VarSet 
trigger1 = PalNo = 1 
var(0) = 3 ;CHANGE THIS LINE
 

=====<Movelist>=====

 U - Up          x - Weak Punch         a - Weak Kick
 D - Down        y - Medium Punch       b - Medium Kick
 F - Forward     z - Strong Punch       c - Strong Kick
 B - Back        p - Any Punch          k - Any Kick
 s - Start       2p- Two Punches        2k- Two Kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>

.Seoi Nage:                             F/B + 2p                (near opponent)
.Tomoe Nage:                            F/B + 2k                (near opponent)

<COMMAND MOVES>

.Inazuma Kakato Wari:                   F + b 
.Target Combo 1:                        y, c                    (near opponent)

<SPECIAL MOVES>

.Hadouken (EX):                         D, DF, F, p		
.Shoryuken (EX):                        F, D, DF, p
.Tatsumaki Senpukyaku (EX):	        D, DB, B, k
.Airborne Tatsumaki Senpukyaku (EX):    D, DB, B, k		(Air)  
.Nata Otosi Geri:         		D, DF, F, a
.Kama Harai Geri:         		D, DF, F, b
.Osoto Mawashi Geri:			D, DF, F, c
    .Inazuma Kakato Wari:       	hold k                  (after any Geri move)

<SUPER MOVES>

.Shinku Hadouken (MAX):                 D, DF, F, D, DF, F, p   
.Shoryureppa (MAX):                     D, DF, F, D, DF, F, k
.Chou Shoryuken (MAX):                  D, DB, B, D, DB, B, k

<Lv3 SUPER MOVES>

.Cyborg Destruction                     D, DB, B, D, DB, D, 2p


=====<Move Details>=====
 
 - Both versions of Inazuma Kakato Wari are overheads. 
 - EX Airborne Tatsumaki Senpukyaku resets the juggle points.
 - Cyborg Destruction is very damaging, but it also leaves Cyborg near death.

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special or a Super move into a Super move resets the juggle points
   but also reduces its damage

MAX MODE:
 - Your attack and defense is increased while in MAX Mode
 - EX moves can be performed at no power cost, though take away from time sustained in MAX mode
 - All Lv1 supers can be performed at no power cost, though immediately uses up all time in MAX mode
 - All Lv2 and higher supers will cost 1 power bar, along with using up all time in MAX mode
 - Even without a power bar, as long as you have time left in MAX mode, you can perform Lv1 supers/EX moves
 - You can not Power Charge/gain power while in MAX mode
 - You can not perform a Zero Counter while in MAX Mode

=====<Version History>=====

<01.09.15>
 - Added MAX Mode damage buff to projectiles.
 - Tweaked (MAX) Shinku Hadouken projectile coding.
 - Fixed angled Air MK having no priority.

<07.13.14>
 - j.LK/j.LP are now cancelable into (EX) Airborne Tatsumaki Senpukyaku.
 - Fixed facing of (EX) Airborne Tatsumaki Senpukyaku.
 - Made Shin Shoryuken the MAX version of Chou Shoryuken.
 - Fixed guardflags of both versions of Shoryureppa and Chou Shoryuken.
 - Fixed guardflags of Geri moves.
 - Now all special Geri moves can cancel into Inazuma Kakato Wari even if they don't connect.
 - Nerfed down Backward Dash.
 - c.HK is now cancelable.
 - Tweaked Dodge and Rolling anims.
 - Changed (EX) Airborne Tatsumaki Senpukyaku velocities.
 - Added some link combos from ST (cr.MP -> cr.MK and cr.MP -> cr.HK)
 - Made Cyborg Destruction a bit more "dramatic" (sounds and envshake)

<07.05.14> 
 - Initial release


=====<What's Missing>=====

  - AI
  - Midnight Bliss
  - CvS-Ish sprites (?)

=====<Special Thanks>=====

 - DivineWolf: Used his KFM as a template for this character, as well as testing and teaching me more about
   general stuff, thanks a lot man.
 - Jmorphman: Ken's moves reference, specially the Airborne Tatsumaki D:<
 - POTS: Too much to tell.
 - Enscripture: SFIITM Cyborg sprite rips.
 - Masa, Zion, Basara-kun: Taken some sprites from their versions of Cyborg (thanks a lot). Borrowed
   the robotic SF2 voice samples from Basara's Cyborg too. 
 - Hades: Small portrait and palettes.
 - Hungry Wolf: Big portrait.
 - Chazzanova: Hyper portrait.
 - Blackchaos: Taken the selfdestruct sound from his Mech Zangief.
 - Ness, Calhoun Tubbs87, Project13, sabockee, Taybear, JDM: Palettes. 
 - Infinite: Tatsumaki Senpukyaku FX sprites/code, useful color separation tutorial.
 - Mugenguild people for being cool c: (if I forgot someone, tell me please)


=====<Disclaimer>=====

 - The Cyborg character is property of Capcom
 - Capcom vs SNK is property of Capcom
 - This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes