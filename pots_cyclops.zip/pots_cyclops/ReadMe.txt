==================| Cyclops by GoldEX |==================|

 - Customized version of Dick Buckus' Cyclops character
 - For MUGEN 1.0 and above

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks
 
 (Air) - Move must be performed in the air.
 (A)   - Move can be performed in the ground and air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

-IF YOU DON'T WANT CHAIN COMBOS GO TO THE CONFIG AND CHANGE THE VALUE UNDER VAR 55
TO 0 AND SAVE.Turning off the chain combos will give the character more of a 
cvs-ish type damage for normal attacks. 


<THROWS>

.Slam Throw                         F/B + 2p                      (near opponent)
.Burst Throw                        F/B + 2k                      (near opponent)
.Leg Throw                          DF/DB + 2p/2k                 (near opponent)
.Air Throw                          F/B + 2p/2k                   (Air, near opponent)


<UNIQUE MOVES>

.Double Jump                        U/UB/UF                       (Air)
.Optic Burst                        B/DB + z
.Optic Bullet                       F/DF + z                      (Can be enabled in config.txt)
.Horizontal Chop                    D + y                         (Air)
.Focus Shot                         D + z                         (Air)
.Anti-Ground Kick                   D + a                         (Air)
.Side Kick                          D + b                         (Air)
.Drop Kick                          D + c                         (Air)
.Double Fist                        x, x
.Double Leg                         a, a
.Double Kick                        c, c


<SPECIAL MOVES>

.Optic Blast (EX)                   D, DF, F, p                   (A)
.Gene Splice (EX)                   F, D, DF, p
.Optic Sweep (EX)                   D, DF, F, k
.Cyclone Kick (EX)                  D, DB, B, k
.Neck Breaker Drop (EX)             (charge)B, F, k
.Rapid Punch (EX)                   (charge)B, F, p, (tap) p/k
.Beam Throw (EX)                    F, DF, D, DB, B, p


<SUPER MOVES>

 <LEVEL 1>

.Super Optic Blast (MAX)            D, DF, F, D, DF, F, p
.Super Cyclone Kick (MAX)           D, DB, B, D, DB, B, k


 <LEVEL 3>

.Mega Optic Blast                    D, DB, B, D, DB, B, 2p



=====<System>=====

.Forward Dash                       F, F
  .Run                               -> hold
.Backward Dash                      B, B
.Low Jump                           tap U
.High Jump                          tap D, U
.Long Low Jump                      tap D, tap U            
.Sidestep                           x + a
  .Sidestep Attack                   -> p / k
.Forward Roll                       F + x + a
.Backward Roll                      B + x + a
.Parry High                         tap F
.Parry Low                          tap D
.Air Parry                          tap F                         (Air)
.Power Charge                       hold y + b
.Guard Cancel Roll                  F/B + a + x                   (during standing or crouching guard) (1 power bar)
.Zero Counter (New Input)           F + 2p / 2k                   (during standing or crouching guard) (1 power bar)
.Zero Counter (Classic Input)       B, DB, D + p / k              (during standing or crouching guard) (1 power bar)
.Custom Combo                       z + c                         (Air also) (1 power bar)
.Fall Recovery                      2p / 2k / a + x               (while falling and allowed)



=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Normal Attacks are able to chain into other normal attacks.
 - Normal attacks can be canceled into Command, Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into other Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage


CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start



=====<Credits=====

[Marvel]
 The original character

[Dick Buckus]
  The original color separation, animation file and some coding

[Wuwo]
[Kong]
[Just No Point]
  Original sprites and FX

[davismaximus]
  New color separation

[Reza]
[ZVitor]
[Warusaki3]
[Vyn]
[Sunboy]
[Mouser]
[Acey]
  Coding base

[Cloudius]
[One Winged Angel]
  Sounds

[FerchoGTX]
  Some FX and sounds

[Phantom.of.the.Server]
[Infinite]
  Tutorials and open source coding

[Sennou Room]
[R@CE AKIR@]
  Coding base for add-ons



=====<Disclaimer>=====

 - Cyclops is property of Elecbyte
 - Capcom vs SNK is property of Capcom
 - This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes