                            __________________________________________
===========================| Dee Jay by varo_hades	              |===========================
                            ������������������������������������������        [12.23.19] - Varo_Hades        
                                                                              [4.21.20] - BahamianKing
 - Contact:varo_hades@hotmail.com
 - Website:https://varohades.wixsite.com/varohadesmugen
 - Customized version of Capcom's Dee Jay character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, including SSF2T, SFA3 and SF4

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p - two punches       2k - two kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

<NORMAL>
.Knee Shoot			        D + a			(Air)
.Funky Shout:		         	F/B + 2p		(near opponent)
.Monkey Flip:				F/B + 2k		(near opponent)
.Air Monkey Flip:			F/B + 2p		(Air, near opponent)

<SPECIAL>

.Air Slasher (EX)			(charge) B, F, p
.Machine Gun Upper (EX)			(charge) D, U, p
.Double Rolling Sobat (EX)		(charge) B, F, k
.Jackknife Maximum (EX)			(charge) D, U, k

<SUPER>

.Climax Break (MAX):			D, DF, F, D, DF, F, p
.Sobat Carnival (MAX):			D, DF, F, D, DF, F, k
.Theme Of Sunrise (MAX):		D, DB, B, D, DB, B, k

<Lv3 SUPER>

.Climax Beat:                		D, DF, F, D, DB, B, 2p
.Sobat Festival:			D, DF, F, D, DB, B, 2k   

<SYSTEM>

.Forward Dash:                  	F, F
.Run:                        	        hold
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	a + x
.Sidestep Attack:            	        p / k
.Forward Roll:                  	F + a + x
.Backward Roll:                 	B + a + x
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold b + y
.Zero Counter:                  	B, DB, D, p / k 	(during standing or crouching guard)
.Special Move Zero Counter:             F + b + y 	        (during standing or crouching guard)
.Custom Combo:                  	c + z           	(Air also)
.Fall Recovery:                 	a + x      	        (while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

=====<Version History>=====

<1/07/20>
 - Added few pals from Quickfist.

<12/23/19>
 - First release

=====<Special Thanks>=====
 - BajanFlash for code, anims
 - P.o.t.S. for code, effects, hitsparks, formatting style
 - Descolor for sprites, code and anims
 - Jesuszilla for some sprites
 - Hades for hyper fonts and hyper portrait
 - Everybody at the MUGEN Fighters Guild for feedback
 - The MUGEN Fighters Guild for providing hosting

=====<Disclaimer>=====

 - Dee Jay character is property of Capcom
 - Capcom vs SNK is property of Capcom
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes
