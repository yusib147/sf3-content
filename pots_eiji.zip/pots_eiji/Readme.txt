;==========================================================================
;--------------------------------------------------------------------------
;--------------------------------------------------------------------------
;---------------------Eiji Kisarigi by Koopa901----------------------------
;--------------------------------------------------------------------------
;--------------------------------------------------------------------------
;==========================================================================

11/26/2015

Customized version of SNK PLAYMORE's Eiji Kisarigi character, for MUGEN 1.0

*NOTE! THIS IS A BETA RELEASE.....THERE WILL BE CORRECTIONS AND COMPLETION IN THE NEAR  FUTURE!

=====<Movelist>=====

 U - up          LP - light punch        LK - light kick
 D - down        MP - medium punch       MK - medium kick
 F - forward     HP - heavy punch        HK - heavy kick
 B - back        P - any punch           K - any kick
 s - start       2P- two punches         2K- two kicks
 
[Special Moves]

Kikou Hou -------------------------- D,DF,F, P
Kasumi Kiri ------------------------ D,DB,B, P
Ryu Ei Jin ------------------------- D,DB,B, K
Tenba Kyuaku ----------------------- B,D,DB, K
�Kotsu Hazaki Kiri------------------- D, DF,F,K
Kage Utsushi ----------------------- F,D,DF, K

[EX Special Moves] 
Kikou Hou -------------------------- D,DF,F, 2P
Kasumi Kiri ------------------------ D,DB,B, 2P
 
[Super Moves]------------------------ 1 SUPER BAR REQUIRED

Zantetsu Ha------------------------- D, DF, F, D, DF, F, P
Zantetsu Tourou Ken ---------------- D,DF,F,DF,D,DB,B, K

[Level 3 Super]--------------------- 3 SUPER BARS REQUIRED
Tantetsu Touroh Ken ---------------- D, DF, F, D, DF, F, 2P

THANKS TO -

SNK-For creating the original character.

Elecbyte-For Making the MUGEN engine.

Virtualtek-For creating Fighter Factory.

Infinite/R@CE45/DivineWolf/HungryWolf - For the template, the insperation, and all those dope adss characters you guys released
Eddie Mort for sound selection (Lol thought i wasn't gonna do it huh lol)
And to anyone who took out the time and space on there computer to download this character



=====<Disclaimer>=====

 - Eiji Kisarigi is property of SNK
 - Art of Fighting and KOF is property of SNK
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes