; _________________________________________
;| Gambit by varo_hades                    |
; �����������������������������������������
;==============================================================================================
;========================================<SPECIAL MOVES>=======================================
;==============================================================================================

;=====================<KINETIC CARD>==========================
[StateDef 1000]
type = S
physics = S
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1000, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1020, ifElse(var(10) = 1, 1010, 1000))

[State 1000, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1000, 1]
type = PlaySnd
trigger1 = animelem = 4
value = s1000, 0
channel = 0

[State 1000, Helper]
type = Helper
trigger1 = animelem = 3
helpertype = normal ;player
name = "Energy"
ID = 1001
stateno = 1001
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1000, Projectile]
type = Helper
trigger1 = AnimElem = 6
helperType = Normal
stateNo = 1005
ID = 1005
name = "Kinectic Card Projectile"
posType = P1
pos = 0, 0
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 1000, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;Hit by Kinetic Card
[Statedef 1025]
type = A
movetype = H
physics = N
velset = 0,0

[State 1025, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1030

[State 1025, 2]
type = Changestate
trigger1 = var(10) = 0
trigger1 = time = 23
value = 1026

[State 1025, 2]
type = Changestate
trigger1 = var(10) = 1
trigger1 = time = 25
value = 1026

[State 1025, 2]
type = Changestate
trigger1 = var(10) = 2
trigger1 = time = 27
value = 1026

[State 1025, 2]
type = Changestate
trigger1 = var(10) = 3
trigger1 = time = 27
value = 1026

[State 1025, 2]
type = Changestate
trigger1 = time = 30
value = 1026

;Hit by Kinetic Card
[Statedef 1026]
type = A
movetype = H
physics = N
velset = -3,-4

[State 1026, VelAdd]
type = VelAdd
trigger1 = 1
y = .4

[State 1026, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1035

[State 1026, 1]
type = ChangeAnim
Trigger1 = Time = 6
value = 5050

[State 1026, 2]
type = SelfState
trigger1 = Vel Y > 0 && Pos Y >= 0
value = 5100

;=====================<EX KINETIC CARD>==========================
[StateDef 1030]
type = S
physics = S
moveType = A
anim = 1020
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, 1]
type = PlaySnd
trigger1 = animelem = 4
value = s1000, 0
channel = 0

[State 1030, Helper]
type = Helper
trigger1 = animelem = 3
helpertype = normal ;player
name = "Energy"
ID = 1001
stateno = 1001
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1030, Projectile]
type = Helper
trigger1 = AnimElem = 6
helperType = Normal
stateNo = 1035
ID = 1005
name = "EX Kinectic Card Projectile"
posType = P1
pos = 0, 0
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 1030, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 1030, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<AIR KINETIC CARD>==========================
[StateDef 1050]
type = A
physics = A
moveType = A
anim = 1050
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1050, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1050, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1050, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1070, ifElse(var(10) = 1, 1060, 1050))

[State 1050, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1050, 1]
type = PlaySnd
trigger1 = animelem = 4
value = s1000, 0
channel = 0

[State 1050, Helper]
type = Helper
trigger1 = animelem = 1
helpertype = normal ;player
name = "Energy"
ID = 1051
stateno = 1051
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1050, Helper]
type = Helper
trigger1 = animelem = 6
helpertype = normal ;player
name = "Projectile"
ID = 1005
stateno = 1055
postype = p1
pos = ceil(28*const(size.xscale)), ceil(-37*const(size.yscale))
size.xscale = 1
size.yscale = 1
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1050, 1]
type = VelMul
trigger1 = AnimElem = 18, < 0
y = .5

[State 1050, 2]
type = VelMul
trigger1 = Time = 0
x = .1

[State 1050]
type = statetypeset
trigger1 = animelemtime(18)>=0
movetype = I

[State 1050, 9]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -1
trigger1 = AnimElem = 18, < 0
x = 0
y = 0

;=====================<EX AIR KINETIC CARD>==========================
[StateDef 1080]
type = A
physics = A
moveType = A
anim = 1070
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1080, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1080, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1080, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1080, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1080, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1080, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1080, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1080, 1]
type = PlaySnd
trigger1 = animelem = 4
value = s1000, 0
channel = 0

[State 1080, Helper]
type = Helper
trigger1 = animelem = 1
helpertype = normal ;player
name = "Energy"
ID = 1051
stateno = 1051
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1080, Helper]
type = Helper
trigger1 = animelem = 6
helpertype = normal ;player
name = "Projectile"
ID = 1005
stateno = 1085
postype = p1
pos = ceil(28*const(size.xscale)), ceil(-37*const(size.yscale))
size.xscale = 1
size.yscale = 1
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1080, 1]
type = VelMul
trigger1 = AnimElem = 18, < 0
y = .5

[State 1080, 2]
type = VelMul
trigger1 = Time = 0
x = .1

[State 1080]
type = statetypeset
trigger1 = animelemtime(18)>=0
movetype = I

[State 1080, 9]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -1
trigger1 = AnimElem = 18, < 0
x = 0
y = 0

;========================<CAJUN SLASH>=============================
[StateDef 1100]
type = S
physics = S
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1100, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "z" || command = "rlsz"), 2, ifElse((command = "y" || command = "rlsy"), 1, 0))

[State 1100, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 333), 2, ifElse(Random < 500, 1, 0))

[State 1100, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1120, ifElse(var(10) = 1, 1110, 1100))

[State 1100, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1100, VelSet]
type = VelSet
trigger1 = var(10) = 0
trigger1 = animelem=1
x = 12

[State 1100, VelSet]
type = VelSet
trigger1 = var(10) = 0
trigger1 = animelem=5
x = 0

[State 1100, 1]
type = PlaySnd
trigger1 = var(10) = 0
trigger1 = AnimElem = 1
value = s1, 2
channel = 1

[State 1100, 1]
type = PlaySnd
trigger1 = var(10) = 0
trigger1 = AnimElem = 1
value = 1100, 0
channel = 0

[State 1100, Explod]
type = Explod
trigger1 = var(10) = 0
trigger1 = AnimElem = 2
anim = 1130
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1100, RemoveExplod]
type = RemoveExplod
trigger1 = var(10) = 0
trigger1 = AnimElem = 5
id = 200
ignorehitpause = 1

[State 1100, Dust Helper]
type = Helper
trigger1 = var(10) = 0
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1100, VelSet]
type = VelSet
trigger1 = var(10) = 1
trigger1 = animelem = 2
x = 2
y = -4

[State 1100, StateTypeSet]
type = StateTypeSet
trigger1 = var(10) = 1
trigger1 = time>=2
statetype = A
physics = N

[State 1100, VelAdd]
type = VelAdd
trigger1 = var(10) = 1
trigger1 = time>=3
y = .3

[State 1100, 1]
type = PlaySnd
trigger1 = var(10) = 1
trigger1 = AnimElem = 5
value = s1, 2
channel = 1

[State 1100, 1]
type = PlaySnd
trigger1 = var(10) = 1
trigger1 = AnimElem = 3
value = 1100, 0
channel = 0

[State 1100, Dust Helper]
type = Helper
trigger1 = var(10) = 1
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1100, Explod]
type = Explod
trigger1 = var(10) = 1
trigger1 = AnimElem = 6
anim = 1131
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1100, RemoveExplod]
type = RemoveExplod
trigger1 = var(10) = 1
trigger1 = AnimElem = 8
id = 200
ignorehitpause = 1

[State 0, PosSet]
type = PosSet
trigger1 = var(10) = 2
trigger1 = 1
y = 0

[State 1100, VelSet]
type = VelSet
trigger1 = var(10) = 2
trigger1 = animelem=1
x = 12

[State 1100, VelSet]
type = VelSet
trigger1 = var(10) = 2
trigger1 = animelem=4
x = 0

[State 1100, 1]
type = PlaySnd
trigger1 = var(10) = 2
trigger1 = AnimElem = 1
value = s1, 2
channel = 1

[State 1100, Explod]
type = Explod
trigger1 = var(10) = 2
trigger1 = AnimElem = 2
anim = 1132
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1100, RemoveExplod]
type = RemoveExplod
trigger1 = var(10) = 2
trigger1 = AnimElem = 5
id = 200
ignorehitpause = 1

[State 1100, 1]
type = PlaySnd
trigger1 = var(10) = 2
trigger1 = AnimElem = 1
value = 1100, 0
channel = 0

[State 1100, Dust Helper]
type = Helper
trigger1 = var(10) = 2
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1100, HitDef 1]
type = HitDef
trigger1 = var(10) = 0
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 110 < 7, 7, fvar(11) * 110)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6.7, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5.7, -2
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 1]
type = HitDef
trigger1 = var(10) = 1
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 6
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -4, -2
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, HitDef 1]
type = HitDef
trigger1 = var(10) = 2
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = S, NA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 44 < 7, 7, fvar(11) * 44)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -1
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1100, ChangeState]
type = ChangeState
trigger1 = var(10) = 2
trigger1 = AnimTime = 0
value = 1101
ctrl = 0

[State 1100, ChangeState]
type = ChangeState
trigger1 = var(10) = 1
trigger1 = Vel Y > 0 && Pos Y >= 0
value = 1101

[State 1100, End]
type = ChangeState
trigger1 = var(10) = 0
trigger1 = !AnimTime
value = 0
ctrl = 1

;Cajun Slash 2
[Statedef 1101]
type = S
movetype = A
physics = S
juggle = 2
poweradd = 0
velset = 0,0
anim = 1111
ctrl = 0
sprpriority = 2

[State 1101, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1121, ifElse(var(10) = 1, 1111, 1100))

[State 1101, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1101, PosSet]
type = PosSet
trigger1 = var(10) = 1
trigger1 = 1
y = 0

[State 1101, VelSet]
type = VelSet
trigger1 = var(10) = 1
trigger1 = animelem=1
x = 7

[State 1101, VelSet]
type = VelSet
trigger1 = var(10) = 1
trigger1 = animelem=4
x = 0

[State 1101, 1]
type = PlaySnd
trigger1 = var(10) = 1
trigger1 = AnimElem = 1
value = s1, 2
channel = 1

[State 1101, Dust Helper]
type = Helper
trigger1 = var(10) = 1
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1101, Explod]
type = Explod
trigger1 = var(10) = 1
trigger1 = AnimElem = 2
anim = 1132
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1101, RemoveExplod]
type = RemoveExplod
trigger1 = var(10) = 1
trigger1 = AnimElem = 5
id = 200
ignorehitpause = 1

[State 1101, PosSet]
type = PosSet
trigger1 = var(10) = 2
trigger1 = 1
y = 0

[State 1101, VelSet]
type = VelSet
trigger1 = var(10) = 2
trigger1 = animelem=1
x = 12

[State 1101, VelSet]
type = VelSet
trigger1 = var(10) = 2
trigger1 = animelem=5
x = 0

[State 1101, 1]
type = PlaySnd
trigger1 = var(10) = 2
trigger1 = AnimElem = 1
value = s1, 2
channel = 1

[State 1101, Dust Helper]
type = Helper
trigger1 = var(10) = 2
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1101, Explod]
type = Explod
trigger1 = var(10) = 2
trigger1 = AnimElem = 3
anim = 1134
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1101, RemoveExplod]
type = RemoveExplod
trigger1 = var(10) = 2
trigger1 = AnimElem = 6
id = 200
ignorehitpause = 1

[State 1101, HitDef 1]
type = HitDef
trigger1 = var(10) = 1
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = S, NA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1101, HitDef 1]
type = HitDef
trigger1 = var(10) = 2
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = S, NA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 44 < 7, 7, fvar(11) * 44)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -1
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -69
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1101, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 1102
ctrl = 0

;Cajun Slash 3
[Statedef 1102]
type = S
movetype = A
physics = S
juggle = 2
poweradd = 0
velset = 0,0
anim = 1112
ctrl = 0
sprpriority = 2

[State 1102, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1122, ifElse(var(10) = 1, 1112, 1100))

[State 1102, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1102, VelSet]
type = VelSet
trigger1 = var(10) = 1
trigger1 = animelem=1
x = 12

[State 1102, VelSet]
type = VelSet
trigger1 = var(10) = 1
trigger1 = animelem=6
x = 0

[State 1102, 1]
type = PlaySnd
trigger1 = var(10) = 1
trigger1 = AnimElem = 1
value = s1, 2
channel = 1

[State 1102, Dust Helper]
type = Helper
trigger1 = var(10) = 1
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1102, Explod]
type = Explod
trigger1 = var(10) = 1
trigger1 = AnimElem = 3
anim = 1133
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1102, RemoveExplod]
type = RemoveExplod
trigger1 = var(10) = 1
trigger1 = AnimElem = 6
id = 200
ignorehitpause = 1

[State 1102, PosSet]
type = PosSet
trigger1 = var(10) = 2
trigger1 = 1
y = 0

[State 1102, VelSet]
type = VelSet
trigger1 = var(10) = 2
trigger1 = animelem=1
x = 12

[State 1102, VelSet]
type = VelSet
trigger1 = var(10) = 2
trigger1 = animelem=4
x = 0

[State 1102, 1]
type = PlaySnd
trigger1 = var(10) = 2
trigger1 = AnimElem = 1
value = s1, 2
channel = 1

[State 1102, Dust Helper]
type = Helper
trigger1 = var(10) = 2
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1102, Explod]
type = Explod
trigger1 = var(10) = 2
trigger1 = AnimElem = 2
anim = 1135
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1102, RemoveExplod]
type = RemoveExplod
trigger1 = var(10) = 2
trigger1 = AnimElem = 4
id = 200
ignorehitpause = 1

[State 1102, HitDef 1]
type = HitDef
trigger1 = var(10) = 1
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 4
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6.7, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -7.5, 4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1102, HitDef 1]
type = HitDef
trigger1 = var(10) = 2
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 40 < 7, 7, fvar(11) * 40)), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6.7, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5.7, -2
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -47
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1102, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<EX CAJUN SLASH>=============================
[StateDef 1130]
type = S
physics = S
moveType = A
anim = 1120
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1130, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1130, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1130, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 131

[State 1130, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = P1
pos = ceil(17 * const(size.xScale)), ceil(-85 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1130, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1130, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1130, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 1130, VelSet]
type = VelSet
trigger1 = animelem=1
x = 12

[State 1130, VelSet]
type = VelSet
trigger1 = animelem=4
x = 0

[State 1130, 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = s1, 2
channel = 2

[State 1130, Explod]
type = Explod
trigger1 = AnimElem = 2
anim = 1132
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1130, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 5
id = 200
ignorehitpause = 1

[State 1130, 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1100, 0
channel = 0

[State 1130, Dust Helper]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1130, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Animelem = 2
trigger2 = Animelem = 3
attr = S, NA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -1
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1130, ChangeState]
type = ChangeState
trigger1 = AnimTime = 0
value = 1131
ctrl = 0

;Cajun Slash 2
[Statedef 1131]
type = S
movetype = A
physics = S
juggle = 2
poweradd = 0
velset = 0,0
anim = 1121
ctrl = 0
sprpriority = 2

[State 1131, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1131, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 1131, VelSet]
type = VelSet
trigger1 = animelem=1
x = 12

[State 1131, VelSet]
type = VelSet
trigger1 = animelem=5
x = 0

[State 1131, 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = s1, 2
channel = 1

[State 1131, Dust Helper]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1131, Explod]
type = Explod
trigger1 = AnimElem = 3
anim = 1134
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1131, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 6
id = 200
ignorehitpause = 1

[State 1131, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Animelem = 3
trigger2 = Animelem = 4
attr = S, NA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
guard.pauseTime = ifElse(var(20), 4, 8), ifElse(var(20), 4, 8)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -8.5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.5, -1
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 143), var(36) := -69
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1131, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 1132
ctrl = 0

;Cajun Slash 3
[Statedef 1132]
type = S
movetype = A
physics = S
juggle = 2
poweradd = 0
velset = 0,0
anim = 1122
ctrl = 0
sprpriority = 2

[State 1132, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1132, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 1132, VelSet]
type = VelSet
trigger1 = animelem=1
x = 12

[State 1132, VelSet]
type = VelSet
trigger1 = animelem=4
x = 0

[State 1132, 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = s1, 2
channel = 1

[State 1132, Dust Helper]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1132, Explod]
type = Explod
trigger1 = AnimElem = 2
anim = 1135
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 1132, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 4
id = 200
ignorehitpause = 1

[State 1132, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 2
attr = S, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 28 < 7, 7, fvar(11) * 28)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -6.7, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5.7, -2
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -47
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1132, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<CAJUN STRIKE>==========================
[StateDef 1200]
type = S
physics = S
moveType = A
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1200, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1200, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1200, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1200, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 1202
ctrl = 0

;Cajun Strike (Punch) -Jump Backward
[Statedef 1201]
type = S
physics = S
moveType = A
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1201, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1201, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1201, 1]
type = Turn
trigger1 = Time = 0

[State 1201, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1201, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 1202
ctrl = 0

;Cajun Strike (Punch) -In Air
[Statedef 1202]
type = A
movetype = I
physics = N
velset = 20,-9
anim = 1202
ctrl = 0
sprpriority = 2

[State 1202, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 1202, Snd]
type = playsnd
trigger1 = !time
value = 40,0

[State 1202, 1]
type = VelAdd
trigger1 = 1
y = .3

[State 1202, 2]
type = changestate
trigger1 = pos y < -90
trigger1 = backedgebodydist = 0 || frontedgebodydist = 0
value = 1203

[State 1202, 3]
type = VarSet
trigger1 = time = 0
var(1) = 1

[State 1202, 4]
type = Playerpush
trigger1 = 1
value = 0

[State 1202, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;Cajun Strike (Punch) -On Wall
[Statedef 1203]
type = A
movetype = I
physics = N
anim = 1203
velset = 0,0

[State 1203, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 1203, 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = s40, 0

[State 1203, 1]
type = Turn
trigger1 = Time = 0

[State 1203, 2]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "holdfwd"
value = 1205

[State 1203, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "x" || command = "y" || command = "z"
value = 1204

[State 1203, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "a"
value = 1220

[State 1203, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "b"
value = 1221

[State 1203, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "c"
value = 1222

[State 1203, 3]
type = ChangeState
trigger1 = time >= 15
value = 1212

;Cajun Strike (Punch) -Jump Near
[Statedef 1204]
type = A
movetype = I
physics = N
anim = 1202
velset = 10,-6

[State 1204, 1]
type = VelAdd
trigger1 = 1
y = .38

[State 1204, Snd]
type = playsnd
trigger1 = !time
value = 40,0

[State 1204, 2]
type = VelAdd
trigger1 = p2bodydist x < 30
trigger1 = vel x != 0
x = -.4

[State 1204, 3]
type = velset
trigger1 = p2bodydist x < -40
x = 0

[State 1204, 4]
type = VarSet
trigger1 = time = 0
var(1) = 1

[State 1204, 5]
type = ChangeState
triggerall = !AILevel && time >= 6
trigger1 = command = "x" || command = "y" || command = "z"
value = 1210

[State 1204, 5]
type = ChangeState
triggerall = AILevel
trigger1 = (p2bodydist x=[-50,50]) && (p2bodydist y=[-80,80])
value = 1210

[State 1204, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;Cajun Strike (Punch) -Jump To Other Side
[Statedef 1205]
type = A
movetype = I
physics = N
anim = 1202
velset = 20,-6

[State 1205, 1]
type = VelAdd
trigger1 = 1
y = .38

[State 1205, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 1205, 1]
type = changestate
trigger1 = time > 2
trigger1 = backedgebodydist = 0 || frontedgebodydist = 0
value = 1206

[State 1205, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;Cajun Strike (Punch) -On Wall
[Statedef 1206]
type = A
movetype = I
physics = N
anim = 1203
velset = 0,0

[State 1206, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 1206, 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = s40, 0

[State 1206, 1]
type = Turn
trigger1 = Time = 0

[State 1206, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "x" || command = "y" || command = "z"
value = 1204

[State 1206, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "a"
value = 1220

[State 1206, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "b"
value = 1221

[State 1206, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "c"
value = 1222

[State 1206, 3]
type = ChangeState
trigger1 = time >= 15
value = 1212

;Cajun Strike (Punch) -Attack
[Statedef 1210]
type = A
movetype = A
physics = N
poweradd = 0
juggle = 3
anim = 1210
ctrl = 0

[State 1210, 1]
type = VelAdd
trigger1 = 1
y = .38

[State 1210, 2]
type = VelAdd
trigger1 = p2bodydist x < 30
trigger1 = vel x != 0
x = -.4

[State 1210, 3]
type = velset
trigger1 = p2bodydist x < -50
x = 0

[State 1210, ChangeAnim]
type = ChangeAnim
triggerall = AnimElemTime(2) <= 1
trigger1 = movecontact = 1
value = anim
elem = (animelemno(0))+1
ignorehitpause = 1

[State 1210, Explod]
type = Explod
trigger1 = AnimElem = 1
anim = 1230
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 1
pausemovetime = 99

[State 1210, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 2
id = 200
ignorehitpause = 1

[State 1210, Explod]
type = Explod
trigger1 = AnimElem = 2
anim = 1231
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 1
pausemovetime = 99

[State 1210, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 3
id = 200
ignorehitpause = 1

[State 1210, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -3
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -8, 12
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1210, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1,2

[State 1210, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4,3
channel = 0

[State 1221, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;Cajun Strike Landing
[Statedef 1212]
type = A
movetype = I
physics = N
anim = 1212
velset = 2,-2

[State 1212, PosSet]
type = Veladd
trigger1 = 1
y = .5

[State 1212, CtrlSet]
type = CtrlSet
trigger1 = time >=4
value = 1
;ignorehitpause =
;persistent =

[State 1212, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;Cajun Strike Land
[Statedef 1215]
type = S
movetype = I
physics = S
anim = 1215
velset = 0,0

[State 1215, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 1215, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 1215, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0

[State 1215, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1215, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Cajun Strike (Kick) -Attack
[Statedef 1220]
type = A
movetype = A
physics = A
anim = 1220
velset = 3,0

[State 1220, VelAdd]
type = VelAdd
trigger1 = 1
y = .5

[State 1224, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -8, 12
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -8
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1220, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1200,0
channel = 0

[State 1220, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;Cajun Strike (Kick) -Attack
[Statedef 1221]
type = A
movetype = A
physics = A
anim = 1220
velset = 8,0

[State 1221, VelAdd]
type = VelAdd
trigger1 = 1
y = .5

[State 1221, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -8, 12
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -8
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1221, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1200,0
channel = 0

[State 1221, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;Cajun Strike (Kick) -Attack
[Statedef 1222]
type = A
movetype = A
physics = A
anim = 1220
velset = 13,0

[State 1222, VelAdd]
type = VelAdd
trigger1 = 1
y = .5

[State 1222, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Time = 0
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -8, 12
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -8
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1222, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1200,0
channel = 0

[State 1222, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;=====================<EX CAJUN STRIKE>==========================
[StateDef 1230]
type = S
physics = S
moveType = A
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1230, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1230, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1230, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1230, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1230, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1230, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1230, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1200, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 1232
ctrl = 0

;Cajun Strike (Punch) -Jump Backward
[Statedef 1231]
type = S
physics = S
moveType = A
anim = 1200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1231, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1231, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1231, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1231, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1231, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1231, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1231, 1]
type = Turn
trigger1 = Time = 0

[State 1231, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1231, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 1232
ctrl = 0

;Cajun Strike (Punch) -In Air
[Statedef 1232]
type = A
movetype = I
physics = N
velset = 20,-9
anim = 1202
ctrl = 0
sprpriority = 2

[State 1232, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 1232, Snd]
type = playsnd
trigger1 = !time
value = 40,0

[State 1232, 1]
type = VelAdd
trigger1 = 1
y = .3

[State 1232, 2]
type = changestate
trigger1 = pos y < -90
trigger1 = backedgebodydist = 0 || frontedgebodydist = 0
value = 1233

[State 1232, 3]
type = VarSet
trigger1 = time = 0
var(1) = 1

[State 1232, 4]
type = Playerpush
trigger1 = 1
value = 0

[State 1232, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1245
ctrl = 0

;Cajun Strike (Punch) -On Wall
[Statedef 1233]
type = A
movetype = I
physics = N
anim = 1203
velset = 0,0

[State 1233, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 1233, 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = s40, 0

[State 1233, 1]
type = Turn
trigger1 = Time = 0

[State 1233, 2]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "holdfwd"
value = 1235

[State 1233, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "x" || command = "y" || command = "z"
value = 1234

[State 1233, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "a"
value = 1250

[State 1233, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "b"
value = 1251

[State 1233, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "c"
value = 1252

[State 1233, 3]
type = ChangeState
trigger1 = time >= 15
value = 1242

;Cajun Strike (Punch) -Jump Near
[Statedef 1234]
type = A
movetype = I
physics = N
anim = 1202
velset = 10,-6

[State 1234, 1]
type = VelAdd
trigger1 = 1
y = .38

[State 1234, Snd]
type = playsnd
trigger1 = !time
value = 40,0

[State 1234, 2]
type = VelAdd
trigger1 = p2bodydist x < 30
trigger1 = vel x != 0
x = -.4

[State 1234, 3]
type = velset
trigger1 = p2bodydist x < -40
x = 0

[State 1234, 4]
type = VarSet
trigger1 = time = 0
var(1) = 1

[State 1234, 5]
type = ChangeState
triggerall = !AILevel && time >= 6
trigger1 = command = "x" || command = "y" || command = "z"
value = 1240

[State 1234, 5]
type = ChangeState
triggerall = AILevel
trigger1 = (p2bodydist x=[-50,50]) && (p2bodydist y=[-80,80])
value = 1240

[State 1234, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1245
ctrl = 0

;Cajun Strike (Punch) -Jump To Other Side
[Statedef 1235]
type = A
movetype = I
physics = N
anim = 1202
velset = 20,-6

[State 1235, 1]
type = VelAdd
trigger1 = 1
y = .38

[State 1235, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 1235, 1]
type = changestate
trigger1 = time > 2
trigger1 = backedgebodydist = 0 || frontedgebodydist = 0
value = 1236

[State 1235, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1245
ctrl = 0

;Cajun Strike (Punch) -On Wall
[Statedef 1236]
type = A
movetype = I
physics = N
anim = 1203
velset = 0,0

[State 1236, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 1236, 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = s40, 0

[State 1236, 1]
type = Turn
trigger1 = Time = 0

[State 1236, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "x" || command = "y" || command = "z"
value = 1234

[State 1236, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "a"
value = 1250

[State 1236, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "b"
value = 1251

[State 1236, 3]
type = ChangeState
trigger1 = time = [0,15]
trigger1 = command = "c"
value = 1252

[State 1236, 3]
type = ChangeState
trigger1 = time >= 15
value = 1242

;Cajun Strike (Punch) -Attack
[Statedef 1240]
type = A
movetype = A
physics = N
poweradd = 0
juggle = 3
anim = 1210
ctrl = 0

[State 1240, 1]
type = VelAdd
trigger1 = 1
y = .38

[State 1240, 2]
type = VelAdd
trigger1 = p2bodydist x < 30
trigger1 = vel x != 0
x = -.4

[State 1240, 3]
type = velset
trigger1 = p2bodydist x < -50
x = 0

[State 1240, ChangeAnim]
type = ChangeAnim
triggerall = AnimElemTime(2) <= 1
trigger1 = movecontact = 1
value = anim
elem = (animelemno(0))+1
ignorehitpause = 1

[State 1240, Explod]
type = Explod
trigger1 = AnimElem = 1
anim = 1230
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 1
pausemovetime = 99

[State 1240, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 2
id = 200
ignorehitpause = 1

[State 1240, Explod]
type = Explod
trigger1 = AnimElem = 2
anim = 1231
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 1
pausemovetime = 99

[State 1240, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 3
id = 200
ignorehitpause = 1

[State 1240, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Animelem = 2
trigger2 = Animelem = 3
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 63 < 7, 7, fvar(11) * 63)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -3
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -8, 12
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1240, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1,2

[State 1240, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4,3
channel = 0

[State 1240, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1245
ctrl = 0

;Cajun Strike Landing
[Statedef 1242]
type = A
movetype = I
physics = N
anim = 1212
velset = 2,-2

[State 1242, PosSet]
type = Veladd
trigger1 = 1
y = .5

[State 1242, CtrlSet]
type = CtrlSet
trigger1 = time >=4
value = 1
;ignorehitpause =
;persistent =

[State 1242, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1245
ctrl = 0

;Cajun Strike Land
[Statedef 1245]
type = S
movetype = I
physics = S
anim = 1215
velset = 0,0

[State 1245, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 1245, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 1245, Landing Sound]
type = PlaySnd
trigger1 = !Time
value = 52,0

[State 1245, Landing Dust Explod]
type = Explod
trigger1 = !Time
anim = 8102
sprPriority = -3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1245, ChangeState]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Cajun Strike (Kick) -Attack
[Statedef 1250]
type = A
movetype = A
physics = A
anim = 1240
velset = 3,0

[State 1250, VelAdd]
type = VelAdd
trigger1 = 1
y = .5

[State 1250, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Animelem = 1
trigger2 = Animelem = 2
trigger3 = Animelem = 3
trigger4 = Animelem = 4
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 63 < 7, 7, fvar(11) * 63)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -8, 12
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -8
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1250, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1200,0
channel = 0

[State 1250, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1245
ctrl = 0

;Cajun Strike (Kick) -Attack
[Statedef 1251]
type = A
movetype = A
physics = A
anim = 1240
velset = 8,0

[State 1251, VelAdd]
type = VelAdd
trigger1 = 1
y = .5

[State 1251, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Animelem = 1
trigger2 = Animelem = 2
trigger3 = Animelem = 3
trigger4 = Animelem = 4
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 63 < 7, 7, fvar(11) * 63)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -8, 12
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -8
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1251, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1200,0
channel = 0

[State 1251, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1245
ctrl = 0

;Cajun Strike (Kick) -Attack
[Statedef 1252]
type = A
movetype = A
physics = A
anim = 1240
velset = 13,0

[State 1252, VelAdd]
type = VelAdd
trigger1 = 1
y = .5

[State 1252, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = Animelem = 1
trigger2 = Animelem = 2
trigger3 = Animelem = 3
trigger4 = Animelem = 4
attr = A, SA
hitFlag = MAF
guardFlag = HA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 63 < 7, 7, fvar(11) * 63)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Heavy
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -2
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -8, 12
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 57), var(36) := -8
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1252, 5]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1200,0
channel = 0

[State 1252, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1245
ctrl = 0

;=====================<TRICK CARD>==========================
[StateDef 1300]
type = S
physics = S
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1300, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1300, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1300, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1320, ifElse(var(10) = 1, 1310, 1300))

[State 1300, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1300, 1]
type = PlaySnd
trigger1 = animelem = 4
value = s1300, 0
channel = 0

[State 1300, Helper]
type = Helper
trigger1 = animelem = 4
helpertype = normal ;player
name = "Energy"
ID = 1351
stateno = 1351
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1300, Projectile]
type = Helper
trigger1 = AnimElem = 7
helperType = Normal
stateNo = 1305
ID = 1005
name = "Trick Card Projectile"
posType = P1
pos = ceil(28*const(size.xscale)), 0
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 1300, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 1300, 7]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<EX TRICK CARD>==========================
[StateDef 1330]
type = S
physics = S
moveType = A
anim = 1320
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1330, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1330, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1330, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1330, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1330, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1330, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1330, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1330, 1]
type = PlaySnd
trigger1 = animelem = 4
value = s1300, 0
channel = 0

[State 1330, Helper]
type = Helper
trigger1 = animelem = 4
helpertype = normal ;player
name = "Energy"
ID = 1351
stateno = 1351
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1330, Projectile]
type = Helper
trigger1 = AnimElem = 7
helperType = Normal
stateNo = 1335
ID = 1005
name = "EX Trick Card Projectile"
posType = P1
pos = ceil(28*const(size.xscale)), 0
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 1330, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 1330, 7]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<KINETIC BURST>==========================
[StateDef 1400]
type = S
physics = S
moveType = A
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1400, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1400, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1400, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1420, ifElse(var(10) = 1, 1410, 1400))

[State 1400, 1]
type = PlaySnd
trigger1 = animelem = 1
value = s810, 0
channel = 0

[State 1400, 1]
type = PlaySnd
trigger1 = animelem = 3
value = s3300, 1
channel = 1

[State 1400, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1400, Explod]
type = Explod
trigger1 = var(10) = 0
trigger1 = AnimElem = 3
anim = 1405
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = 1.3 * const(size.xscale),1.3 * const(size.yscale)
sprpriority = 3
ownpal = 1
ignoreHitPause = 1

[State 1400, Explod]
type = Explod
trigger1 = var(10) = 1
trigger1 = AnimElem = 3
anim = 1405
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = 1.5 * const(size.xscale),1.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
ignoreHitPause = 1

[State 1400, Explod]
type = Explod
trigger1 = var(10) = 2
trigger1 = AnimElem = 3
anim = 1405
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = 1.8 * const(size.xscale),1.8 * const(size.yscale)
sprpriority = 3
ownpal = 1
ignoreHitPause = 1

[State 1400, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10), 119, 105)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10), 119, 105)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -10.81
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -50
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1400, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<EX KINETIC BURST>==========================
[StateDef 1430]
type = S
physics = S
moveType = A
anim = 1430
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1430, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1430, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1430, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1430, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1430, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1430, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 2

[State 1430, 1]
type = PlaySnd
trigger1 = animelem = 1
value = s810, 0
channel = 0

[State 1430, 1]
type = PlaySnd
trigger1 = animelem = 3
value = s3300, 1
channel = 1

[State 1430, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1430, Explod]
type = Explod
trigger1 = AnimElem = 3
anim = 1405
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = 1.8 * const(size.xscale),1.8 * const(size.yscale)
sprpriority = 3
ownpal = 1
ignoreHitPause = 1

[State 1430, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 67 < 7, 7, fvar(11) * 67)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = 0, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 0
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -50
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1430, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 4
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 67 < 7, 7, fvar(11) * 67)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -2.16, -10.81
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -2.16, -10.81
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -50
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1430, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;=====================<TRAP CARD>==========================
[StateDef 1500]
type = A
physics = A
moveType = A
anim = 1050
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1500, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" || command = "rlsa"), 0, ifElse((command = "b" || command = "rlsb"), 1, 2))

[State 1500, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1500, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1070, ifElse(var(10) = 1, 1060, 1050))

[State 1500, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1500, 1]
type = PlaySnd
trigger1 = animelem = 4
value = s1300, 0
channel = 0

[State 1500, Helper]
type = Helper
trigger1 = animelem = 1
helpertype = normal ;player
name = "Energy"
ID = 1051
stateno = 1051
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1500, Helper]
type = Helper
trigger1 = animelem = 6
helpertype = normal ;player
name = "Projectile"
ID = 1005
stateno = 1505
postype = p1
pos = ceil(28*const(size.xscale)), ceil(-37*const(size.yscale))
size.xscale = 1
size.yscale = 1
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1500, 1]
type = VelMul
trigger1 = AnimElem = 18, < 0
y = .5

[State 1500, 2]
type = VelMul
trigger1 = Time = 0
x = .1

[State 1500]
type = statetypeset
trigger1 = animelemtime(18)>=0
movetype = I

[State 1500, 9]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -1
trigger1 = AnimElem = 18, < 0
x = 0
y = 0

;=====================<EX TRAP CARD>==========================
[StateDef 1530]
type = A
physics = A
moveType = A
anim = 1070
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1530, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1530, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1530, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1530, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 124

[State 1530, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1530, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1530, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 1530, 1]
type = PlaySnd
trigger1 = animelem = 4
value = s1300, 0
channel = 0

[State 1530, Helper]
type = Helper
trigger1 = animelem = 1
helpertype = normal ;player
name = "Energy"
ID = 1051
stateno = 1051
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1530, Helper]
type = Helper
trigger1 = animelem = 6
helpertype = normal ;player
name = "Projectile"
ID = 1005
stateno = 1535
postype = p1
pos = ceil(28*const(size.xscale)), ceil(-37*const(size.yscale))
size.xscale = 1
size.yscale = 1
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 1530, 1]
type = VelMul
trigger1 = AnimElem = 18, < 0
y = .5

[State 1530, 2]
type = VelMul
trigger1 = Time = 0
x = .1

[State 1530]
type = statetypeset
trigger1 = animelemtime(18)>=0
movetype = I

[State 1530, 9]
type = VelSet
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -1
trigger1 = AnimElem = 18, < 0
x = 0
y = 0

;========================<PUNCH ZERO COUNTER>=============================
[StateDef 2900]
type = S
physics = N
moveType = A
anim = 2900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2900, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2900, Voice]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, ifElse(Random < 500, 2, 3)
channel = 0

[State 2900, Woosh]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1,2
channel = 1

[State 2900, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 2900, Width]
type = Width
triggerall = anim = 2900
trigger1 = (AnimElemTime (2) >= 0) && (AnimElemTime (7) < 0)
value = 15,0

[State 2900, Explod]
type = Explod
trigger1 = AnimElem = 4
anim = 221
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 1
pausemovetime = 99

[State 2900, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 5
id = 200
ignorehitpause = 1

[State 2900, Explod]
type = Explod
trigger1 = AnimElem = 5
anim = 222
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = 3
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 1
pausemovetime = 99

[State 2900, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 6
id = 200
ignorehitpause = 1

[State 2900, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 4
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 47 < 7, 7, fvar(11) * 47)), 0
getpower = 0,0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 135), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2900, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(5) >= 0
movetype = I

[State 2900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<KICK ZERO COUNTER>=============================
[StateDef 2910]
type = S
physics = N
moveType = A
anim = 2910
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2910, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2910, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, 3
channel = 0

[State 2910, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1,5
channel = 1

[State 2910, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 4
attr = C, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 47 < 7, 7, fvar(11) * 47)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 196), var(36) := -10
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 0

[State 2910, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(5) >= 0
moveType = I

[State 2910, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
