; _________________________________________
;| Gambit by varo_hades                    |
; �����������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<ROYAL FLUSH>=============================
[StateDef 3000]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = time = [12,54]
value = SCA;,NA,SA,HA,NP,SP,HP,NT,ST,HT

[State 3000, SuperPause FX]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-8 * const(size.xScale)), ceil(-22 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = AnimElem = 3
time = 45
moveTime = 45
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 3000, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 3000, Helper]
type = Helper
trigger1 = !time
helpertype = normal ;player
name = "Stick"
ID = 3004
stateno = 3004
postype = p1
pos = -15, -95
size.xscale = 1
size.yscale = 1
sprpriority = 4
facing = 1
ownpal = 1
ignorehitpause = 0

[State 3000, Helper]
type = Helper
trigger1 = animelem = 7
helpertype = normal ;player
name = "Energy"
ID = 3001
stateno = 3001
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 3000, Helper]
type = Helper
trigger1 = animelem=7||animelem=10||animelem=13
trigger2 = animelem=17||animelem=20||animelem=23
trigger3 = animelem=27||animelem=30||animelem=33
helpertype = normal
name = "Projectile"
ID = 1005
stateno = 3005
postype = p1
pos = 0, 0
size.xscale = 1
size.yscale = 1
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 3000, Helper]
type = Helper
trigger1 = animelem=34
helpertype = normal
name = "Projectile"
ID = 3005
stateno = 3015
postype = p1
pos = 0, 0
size.xscale = 1
size.yscale = 1
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 3000, 2]
type = PlaySnd
trigger1 = AnimElem = 3
value = 3000, 0
channel = 0

[State 3000, 2]
type = PlaySnd
trigger1 = AnimElem = 7
value = 3000, 1
channel = 0

[State 3000, 2]
type = PlaySnd
trigger1 = AnimElem = 42
value = 3000, 2
channel = 0

[State 3000]
type = statetypeset
trigger1 = animelemtime(44)>=0
movetype = I

[State 3000, 7]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Hit by Kinetic Card
[Statedef 3002]
type = A
movetype = H
physics = N
velset = 0,0

[State 3002, HitFallSet]
type = HitFallSet
trigger1 = 1
value = -1

[State 3002, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 1030

[State 3002, 2]
type = Changestate
trigger1 = time = 21
value = 1026

;Royal Flush Stick
[Statedef 3004]
type = A
movetype = A
physics = N
juggle = 4
velset = .5,-11
anim = 3004
ctrl = 0
sprpriority = 4

[State 3004, VelAdd]
type = VelAdd
trigger1 = 1
x = 0
y = .27

[State 3004, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3004, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3004, 2]
type = HitDef
trigger1 = 1
attr = A, HA
animtype  = Back
accel = 0,.27
damage = ceil(ifElse(fvar(11) * 15 < 7, 7, fvar(11) * 15)), 8
hitflag = A
guardflag = A
pausetime = 0,0
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := 0
ground.type = Low
getPower = 0, 0
givePower = 36, 36
ground.slidetime = 20
ground.hittime  = 20
ground.velocity = -6,0
air.type = Low
air.velocity = -8,4
fall = 1
fall.recover = 0

[State 3004, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3004, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3004, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3004, end]
type = destroyself
trigger1 = time >= 82
trigger2 = (root,stateno!=3000||root,anim!=3000)

;========================<MAX ROYAL FLUSH>=============================
[StateDef 3050]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, NotHitBy]
type = NotHitBy
trigger1 = time = [12,54]
value = SCA;,NA,SA,HA,NP,SP,HP,NT,ST,HT

[State 3050, SuperPause FX]
type = Helper
trigger1 = AnimElem = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-8 * const(size.xScale)), ceil(-22 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3050, SuperPause]
type = SuperPause
trigger1 = AnimElem = 3
time = 45
moveTime = 45
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3050, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 3050, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 3050, Helper]
type = Helper
trigger1 = !time
helpertype = normal ;player
name = "Stick"
ID = 3004
stateno = 3054
postype = p1
pos = -15, -95
size.xscale = 1
size.yscale = 1
sprpriority = 4
facing = 1
ownpal = 1
ignorehitpause = 0

[State 3050, Helper]
type = Helper
trigger1 = animelem = 7
helpertype = normal ;player
name = "Energy"
ID = 3001
stateno = 3001
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 3050, Helper]
type = Helper
trigger1 = animelem=7||animelem=8||animelem=10||animelem=11||animelem=13||animelem=14
trigger2 = animelem=17||animelem=18||animelem=20||animelem=21||animelem=23||animelem=24
trigger3 = animelem=27||animelem=28||animelem=30||animelem=31||animelem=33
helpertype = normal
name = "Projectile"
ID = 1005
stateno = 3055
postype = p1
pos = 0, 0
size.xscale = 1
size.yscale = 1
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 3050, Helper]
type = Helper
trigger1 = animelem=34
helpertype = normal
name = "Projectile"
ID = 3005
stateno = 3065
postype = p1
pos = 0, 0
size.xscale = 1
size.yscale = 1
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0

[State 3050, 2]
type = PlaySnd
trigger1 = AnimElem = 3
value = 3000, 0
channel = 0

[State 3050, 2]
type = PlaySnd
trigger1 = AnimElem = 7
value = 3000, 1
channel = 0

[State 3050, 2]
type = PlaySnd
trigger1 = AnimElem = 42
value = 3000, 2
channel = 0

[State 3050]
type = statetypeset
trigger1 = animelemtime(44)>=0
movetype = I

[State 3050, 7]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;Royal Flush Stick
[Statedef 3054]
type = A
movetype = A
physics = N
juggle = 4
velset = .5,-11
anim = 3004
ctrl = 0
sprpriority = 4

[State 3054, VelAdd]
type = VelAdd
trigger1 = 1
x = 0
y = .27

[State 3054, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 3054, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 3054, 2]
type = HitDef
trigger1 = 1
attr = A, HA
animtype  = Back
accel = 0,.27
damage = ceil(ifElse(fvar(11) * 15 < 7, 7, fvar(11) * 15)), 8
hitflag = A
guardflag = A
pausetime = 0,0
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := 0
ground.type = Low
getPower = 0, 0
givePower = 36, 36
ground.slidetime = 20
ground.hittime  = 20
ground.velocity = -6,0
air.type = Low
air.velocity = -8,4
fall = 1
fall.recover = 0

[State 3054, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 3054, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3054, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 3054, end]
type = destroyself
trigger1 = time >= 82
trigger2 = (root,stateno!=3050||root,anim!=3000)

;========================<CAJUN ASSAULT>=============================
[StateDef 3100]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = time = [0,50]
value = SCA;,NA,SA,HA,NP,SP,HP,NT,ST,HT

[State 3100, Super Pause FX]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(4 * const(size.xScale)), ceil(-104 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = AnimElem = 1
time = 45
moveTime = 45
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 3100, VelSet]
type = VelSet
trigger1 = animelem=2
trigger2 = animelem=22
x = 5

[State 3100, VelSet]
type = VelSet
trigger1 = animelem=12
trigger2 = animelem=17
x = 8

[State 3100, VelSet]
type = VelSet
trigger1 = animelem=7
x = 11

[State 3100, VelSet]
type = VelSet
trigger1 = animelem=31
trigger2 = animelem=38
x = 14

[State 3100, VelSet]
type = VelSet
trigger1 = animelem=4
trigger2 = animelem=10
trigger3 = animelem=15
trigger4 = animelem=19
trigger5 = animelem=24
trigger6 = animelem=34
trigger7 = animelem=41
x = 0

[State 3100, 2]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1100, 0
channel = 0

[State 3100, 1]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = animelem=7
trigger3 = animelem=12
trigger4 = animelem=17
trigger5 = animelem=24
trigger6 = animelem=31
trigger7 = animelem=38
value = s1, 2
channel = 1

[State 3100, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 3100, Explod]
type = Explod
trigger1 = AnimElem = 3
anim = 3101
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 3100, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 43
id = 200
ignorehitpause = 1

[State 3100, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 4
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, HitDef 2]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 8
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, HitDef 3]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 13
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -69
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, HitDef 4]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 18
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, HitDef 5]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 25
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, HitDef 6]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 32
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -47
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, HitDef 7]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 39
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = UP
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -4.7, -13
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.7, -13
air.cornerPush.velOff = 0
yAccel = 0.7
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -113
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3100, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<MAX CAJUN ASSAULT>=============================
[StateDef 3150]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3150, NotHitBy]
type = NotHitBy
trigger1 = time = [0,50]
value = SCA;,NA,SA,HA,NP,SP,HP,NT,ST,HT

[State 3150, Super Pause FX]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(4 * const(size.xScale)), ceil(-104 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3150, SuperPause]
type = SuperPause
trigger1 = AnimElem = 1
time = 45
moveTime = 45
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3150, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 3150, VelSet]
type = VelSet
trigger1 = animelem=2
trigger2 = animelem=22
x = 5

[State 3150, VelSet]
type = VelSet
trigger1 = animelem=12
trigger2 = animelem=17
x = 8

[State 3150, VelSet]
type = VelSet
trigger1 = animelem=7
x = 11

[State 3150, VelSet]
type = VelSet
trigger1 = animelem=31
trigger2 = animelem=38
x = 14

[State 3150, VelSet]
type = VelSet
trigger1 = animelem=4
trigger2 = animelem=10
trigger3 = animelem=15
trigger4 = animelem=19
trigger5 = animelem=24
trigger6 = animelem=34
trigger7 = animelem=41
x = 0

[State 3150, 2]
type = PlaySnd
trigger1 = AnimElem = 3
value = 1100, 0
channel = 0

[State 3150, 1]
type = PlaySnd
trigger1 = AnimElem = 2
trigger2 = animelem=7
trigger3 = animelem=12
trigger4 = animelem=17
trigger5 = animelem=24
trigger6 = animelem=31
trigger7 = animelem=38
value = s1, 2
channel = 1

[State 3150, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 3150, Explod]
type = Explod
trigger1 = AnimElem = 3
anim = 3101
ID = 200
postype = p1  ;p2,front,back,left,right
bindtime = -1
removetime = -1
scale = .5 * const(size.xscale),.5 * const(size.yscale)
sprpriority = 3
ownpal = 1
removeongethit = 1
ignorehitpause = 0

[State 3150, RemoveExplod]
type = RemoveExplod
trigger1 = AnimElem = 43
id = 200
ignorehitpause = 1

[State 3150, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 3
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, HitDef 2]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 4
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, HitDef 3]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 8
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, HitDef 4]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 9
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, HitDef 5]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 13
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -69
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, HitDef 6]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 14
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -69
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, HitDef 7]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 18
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, HitDef 8]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 25
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -80
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, HitDef 9]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 32
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -3.5,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.5, -2
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -47
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, HitDef 10]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = AnimElem = 39
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,12
guard.pauseTime = 4,4
animType = UP
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = -4.7, -13
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = -4.7, -13
air.cornerPush.velOff = 0
yAccel = 0.7
fall = 1
air.fall = 1
fall.recover = 0
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 164), var(36) := -113
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3150, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<KINETIC OVERLOAD>=============================
[StateDef 3200]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = time = [0,50]
value = SCA;,NA,SA,HA,NP,SP,HP,NT,ST,HT

[State 3200, Super Pause FX]
type = Helper
trigger1 = AnimElem =  1
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(20 * const(size.xScale)), ceil(-82 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = AnimElem =  1
time = 45
moveTime = 45
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 3200, StateTypeSet]
type = StateTypeSet
trigger1 = animelem >=12
statetype = A
physics = A

[State 3200, VelSet]
type = StatetypeSet
trigger1 = time > 47
statetype = A
physics = N

[State 3200, VelAdd]
type = VelAdd
trigger1 = animelem =12
x = 9.3
y = -4

[State 3200, VelAdd]
type = VelAdd
trigger1 = time >=47
;x = 1
y = .5

[State 3200, PlaySnd]
type = PlaySnd
trigger1 = animelem = 5
value = S195,0
channel = 0

[State 3200, PlaySnd]
type = PlaySnd
trigger1 = animelem = 12
value = S4,2
channel = 0
persistent = 0

[State 3200, PlaySnd]
type = PlaySnd
trigger1 = animelem = 12
value = S40,0
channel = -1

[State 3200, HitDef 1]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = Time = 0
attr = S, HA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 53 < 7, 7, fvar(11) * 53)), 7
getPower = 0,0
givePower = 36, 36
pauseTime = 4,4
guard.pauseTime = 4,4
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 30
ground.slideTime = 30
guard.hitTime = 30
air.hitTime = 120
ground.velocity = 0,0
ground.cornerPush.velOff = 0
guard.velocity = 0
guard.cornerPush.velOff = 0
air.velocity = 0, 0
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -60
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120
kill = 0
numhits = 0

[State 3200, 6]
type = ChangeState
trigger1 = movehit
value = 3210
ctrl = 0

[State 3200, 7]
type = ChangeState
triggerall = time > 45
trigger1 = vel y >0 && pos y > 0
value = 3201
ctrl = 0

;Fail
[Statedef 3201]
type = S
movetype = I
physics = S
juggle = 0
velset = 0,0
anim = 3201
ctrl = 0
sprpriority = 2

[State 3201, PlaySnd]
type = PlaySnd
trigger1 = animelem = 1
value = S52,0
channel = -1

[State 3201, 6]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Grab
[Statedef 3210]
type = S
movetype = A
physics = S
juggle = 0
velset = 0,0
anim = 3210
ctrl = 0
sprpriority = 2

[State 3210, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA;,NA,SA,HA,NP,SP,HP,NT,ST,HT

[State 3210, 1]
type = VelSet
trigger1 = Time = 0
y = 0

[State 3210, 2]
type = PosSet
trigger1 = Time = 0
y = 0

[State 3210, TargetState]
type = TargetState
trigger1 = time = 0
value = 3220

[State 3210, Width]
type = width
trigger1 = 1
edge = 90,0

[State 3210, PlaySnd]
type = PlaySnd
trigger1 = animelem = 4
value = S810,0
channel = 0

[State 3210, PlaySnd]
type = PlaySnd
trigger1 = animelem=6||animelem=8||animelem=10||animelem=12
trigger2 = animelem=14||animelem=16||animelem=18||animelem=20
trigger3 = animelem=22||animelem=24||animelem=26||animelem=28
trigger4 = animelem=30||animelem=32||animelem=34||animelem=36
trigger5 = animelem=38||animelem=40
value = S810,1

[State 3210, Charge]
type = Explod
trigger1 = AnimElem=5
xscale = ceil(1*const(size.xscale))
yscale = ceil(1*const(size.yscale))
removetime = 72
anim = 3211
sprpriority = 5

[State 3210, Bind 2]
type = TargetBind
trigger1 = AnimElemTime(1)>=0 && AnimElemTime(4)<0
pos = ceil(56*const(size.xscale)), 0

[State 3210, Bind 2]
type = TargetBind
trigger1 = AnimElemTime(4)>=0 && AnimElemTime(5)<0
pos = ceil(52*const(size.xscale)), 0

[State 3210, Bind 2]
type = TargetBind
trigger1 = AnimElemTime(5)>=0 && AnimElemTime(41)<0
pos = ceil(34*const(size.xscale)), -79

[State 3210, targetBind]
type = TargetBind
trigger1 = AnimElem = 41
pos = ceil(44*const(size.xscale)), -79

[State 3210, Hit Spark]
type = Helper
trigger1 = AnimElem = 43
helperType = Normal
stateNo = 8012
ID = 8000
name = "Spark"
posType = P1
pos = ceil(78 * const(size.xScale)), ceil(-50 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 3210, PlaySnd]
type = PlaySnd
trigger1 = animelem =42
value = S1,5

[State 3210, PlaySnd]
type = PlaySnd
trigger1 = animelem = 43
value = S4,3
channel = 0

[State 3210, PlaySnd]
type = PlaySnd
trigger1 = animelem =43
value = S2,6

[State 3210, PlaySnd]
type = PlaySnd
trigger1 = animelem = 46
value = S190,1
channel = 0

[State 3210, TargetState]
type = TargetState
trigger1 = animelem = 43
value = 3221

[State 3210, targetBind]
type = TargetBind
trigger1 = AnimElem = 43
pos = ceil(78*const(size.xscale)), 0

[State 3210, Hurt]
type = TargetLifeAdd
trigger1 = animelem=6||animelem=8||animelem=10||animelem=12
trigger2 = animelem=14||animelem=16||animelem=18||animelem=20
trigger3 = animelem=22||animelem=24||animelem=26||animelem=28
trigger4 = animelem=30||animelem=32||animelem=34||animelem=36
trigger5 = animelem=38||animelem=40||animelem=43
value = ceil(ifelse((-18*fvar(11))>-7,-7,(-18*fvar(11))))
kill = 0

[State 3210, burn]
type = Helper
trigger1 = animelem = 45,=1
name = "Explosion"
ID = 3214
postype = p2
pos = target, const(size.mid.pos.x), target, const(size.mid.pos.y)
stateno = 3214
ownpal = 1
size.xscale = 1
size.yscale = 1
sprpriority = 4
supermovetime; = 99999
pausemovetime; = 99999
ignorehitpause = 1
persistent = 0

[State 3210, burn]
type = Helper
trigger1 = animelem = 52
name = "Explosion"
ID = 3215
postype = p2
pos = target, const(size.mid.pos.x), target, const(size.mid.pos.y)
stateno = 3215
ownpal = 1
sprpriority = 4
supermovetime = 99999
pausemovetime = 99999
ignorehitpause = 1
persistent = 0

[State 3210, 3]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl = 1

;Player 2
[Statedef 3220]
type = A
movetype = H
physics = N
velset = 0,0

[State 3220, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3220

[State 3220, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 0,0

[State 3220, 2]
type = selfstate
trigger1 = time = 250
value = 5050

;Player 2
[Statedef 3221]
type = A
movetype = H
physics = N
velset = 0,0

[State 3221, VelSet]
type = VelSet
trigger1 = time = 0
x = -3

[State 3221, VelSet]
type = VelSet
trigger1 = time>=13
x = 0

[State 3221, 1]
type = ChangeAnim2
Trigger1 = Time = 0
value = 3221

[State 3221, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1
movecamera = 0,0

[State 3221, 2]
type = selfstate
trigger1 = time = 250
value = 5050

;Kinetic Overload Opp
[Statedef 3225]
type = C
movetype = H
physics = N
velset = 0,0

[State 3225, screenbound]
type = screenbound
trigger1 = 1
value = 1
movecamera = 320,0

[State 3225, 2]
type = ChangeAnim2
trigger1 = Time = 0
value = 3225

[State 3225, 5] ;State type gets set to aerial if getting hit up
type = StateTypeSet
triggerall = Time = 0
trigger1 = GetHitVar(yvel) != 0 || GetHitVar(fall)
trigger2 = Pos Y != 0
statetype = a

[State 3225, 7]
type = ChangeState
trigger1 = HitShakeOver
value = 3226

;Destroyer Opp
[Statedef 3226]
type = A
movetype = H
physics = N
velset = 0,0

[State 3226, screenbound]
type = screenbound
trigger1 = 1
value = 1
movecamera = 320,0

[State 3226, 2]
type = ChangeAnim2
trigger1 = Time = 0
value = 3226

[State 3226, 5]
type = ChangeState
trigger1 = HitShakeOver
value = 3227

;HITA_UP (initial going up)
[Statedef 3227]
type = A
movetype = H
physics = N
ctrl = 0

[State 3227, screenbound]
type = screenbound
trigger1 = 1
value = 1
movecamera = 320,0

[State 3227, 1]
type = VelAdd;Gravity
trigger1 = 1
y = GetHitVar(yaccel)

[State 3227, 2]
type = HitVelSet
trigger1 = Time = 0
x = 1
y = 1

[State 3227, 4]
type = SelfState
trigger1 = HitOver
trigger2 = Vel Y > 0
trigger2 = Pos Y >= 10
value = 5100

;========================<CAJUN EXPLOSION>=============================
[Statedef 3300]
type = S
physics = S
anim = 1200
ctrl = 0

;[State 3300, 1]
;type = ChangeState
;trigger1 = Time = 0
;trigger1 = command = "holdback"
;value = 3301
;ctrl = 0

[State 3300, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 3300, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 3302
ctrl = 0

;Cajun Strike (Punch) -Jump Backward
[Statedef 3301]
type = S
physics = S
anim = 1200
ctrl = 0

[State 3301, 1]
type = Turn
trigger1 = Time = 0

[State 3301, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 3301, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 3302
ctrl = 0

;Cajun Strike (Punch) -In Air
[Statedef 3302]
type = A
movetype = I
pyshics = N
velset = 20,-9
anim = 1202
ctrl = 0
sprpriority = 2

[State 3302, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 3302, 1]
type = VelAdd
trigger1 = 1
y = .3

[State 3302, 2]
type = changestate
trigger1 = pos y < -90
trigger1 = backedgebodydist = 0 || frontedgebodydist = 0
value = 3303

[State 3302, 3]
type = VarSet
trigger1 = time = 0
var(1) = 1

[State 3302, 4]
type = Playerpush
trigger1 = 1
value = 0

[State 3302, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;Cajun Explosion  -On Wall
[StateDef 3303]
type = A
physics = N
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000

[State 3303, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3303, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3303, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3303, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3303, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3303, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3303, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3303, NotHitBy]
type = NotHitBy
trigger1 = time = [0,56]
value = SCA;,NA,SA,HA,NP,SP,HP,NT,ST,HT

[State 3303, Super Pause FX]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-24 * const(size.xScale)), ceil(-90 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3303, SuperPause]
type = SuperPause
trigger1 = AnimElem = 1
time = 45
moveTime = 45
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3303, 2]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, 3
channel = 0

[State 3303, Helper]
type = Helper
trigger1 = animelem = 1
helpertype = normal ;player
name = "Energy"
ID = 1051
stateno = 1051
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0
supermovetime = 9999999

[State 3303, Helper]
type = Helper
trigger1 = animelem = 7
helpertype = normal ;player
name = "Energy"
ID = 3305
stateno = 3305
pos = 30, 0
scale = 1,1;ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 5
facing = 1
ownpal = 1
ignorehitpause = 0
supermovetime = 9999999

[State 3303, Helper]
type = Helper
trigger1 = animelem = 11
helpertype = normal ;player
name = "Energy"
ID = 3305
stateno = 3305
pos = 120, 0
scale = 1,1;ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 5
facing = 1
ownpal = 1
ignorehitpause = 0
supermovetime = 9999999

[State 3303, Helper]
type = Helper
trigger1 = animelem = 16
helpertype = normal ;player
name = "Energy"
ID = 3305
stateno = 3305
pos = 240, 0
scale = 1,1;ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 5
facing = 1
ownpal = 1
ignorehitpause = 0
supermovetime = 9999999

[State 3303, ScreenBound]
type = ScreenBound
trigger1 = anim = 3300
trigger2 = 1
value = 1
movecamera = 0,0

[State 3303, 1]
type = Turn
trigger1 = Time = 0

[State 3303, VelAdd]
type = VelAdd
trigger1 = time >= 88
y = .3

[State 3303]
type = statetypeset
trigger1 = animelemtime(18)>=0
movetype = I

[State 3303, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;========================<MAX CAJUN EXPLOSION>=============================
[Statedef 3350]
type = S
physics = S
anim = 1200
ctrl = 0

;[State 3350, 1]
;type = ChangeState
;trigger1 = Time = 0
;trigger1 = command = "holdback"
;value = 3351
;ctrl = 0

[State 3350, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 3350, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 3352
ctrl = 0

;Cajun Strike (Punch) -Jump Backward
[Statedef 3351]
type = S
physics = S
anim = 1200
ctrl = 0

[State 3351, 1]
type = Turn
trigger1 = Time = 0

[State 3351, RemoveExplod]
type = RemoveExplod
trigger1 = !time
id = 200
ignorehitpause = 1

[State 3351, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 3352
ctrl = 0

;Cajun Strike (Punch) -In Air
[Statedef 3352]
type = A
movetype = I
pyshics = N
velset = 20,-9
anim = 1202
ctrl = 0
sprpriority = 2

[State 3352, ScreenBound]
type = ScreenBound
trigger1 = anim = 1202
trigger2 = anim = 1203
trigger3 = 1
value = 1
movecamera = 0,0

[State 3352, 1]
type = VelAdd
trigger1 = 1
y = .3

[State 3352, 2]
type = changestate
trigger1 = pos y < -90
trigger1 = backedgebodydist = 0 || frontedgebodydist = 0
value = 3353

[State 3352, 3]
type = VarSet
trigger1 = time = 0
var(1) = 1

[State 3352, 4]
type = Playerpush
trigger1 = 1
value = 0

[State 3352, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0

;Cajun Explosion  -On Wall
[StateDef 3353]
type = A
physics = N
moveType = A
anim = 3300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000

[State 3353, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3353, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3353, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3353, Corner Push]
type = VarSet
trigger1 = time = 3
fvar(5) = 0

[State 3353, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3353, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3353, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3353, NotHitBy]
type = NotHitBy
trigger1 = time = [0,56]
value = SCA;,NA,SA,HA,NP,SP,HP,NT,ST,HT

[State 3353, Super Pause FX]
type = Helper
trigger1 = AnimElem = 1
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-24 * const(size.xScale)), ceil(-90 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3353, SuperPause]
type = SuperPause
trigger1 = AnimElem = 1
time = 45
moveTime = 45
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3353, 2]
type = PlaySnd
trigger1 = AnimElem = 3
value = 4, 3
channel = 0

[State 3353, Helper]
type = Helper
trigger1 = animelem = 1
helpertype = normal ;player
name = "Energy"
ID = 1051
stateno = 1051
postype = p1
scale = ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 2
facing = 1
ownpal = 1
ignorehitpause = 0
supermovetime = 9999999

[State 3353, Helper]
type = Helper
trigger1 = animelem = 7
helpertype = normal ;player
name = "Energy"
ID = 3305
stateno = 3355
pos = 30, 0
scale = 1,1;ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 5
facing = 1
ownpal = 1
ignorehitpause = 0
supermovetime = 9999999

[State 3353, Helper]
type = Helper
trigger1 = animelem = 11
helpertype = normal ;player
name = "Energy"
ID = 3305
stateno = 3355
pos = 120, 0
scale = 1,1;ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 5
facing = 1
ownpal = 1
ignorehitpause = 0
supermovetime = 9999999

[State 3353, Helper]
type = Helper
trigger1 = animelem = 16
helpertype = normal ;player
name = "Energy"
ID = 3305
stateno = 3355
pos = 240, 0
scale = 1,1;ceil(1*const(size.xscale)), ceil(1*const(size.yscale))
sprpriority = 5
facing = 1
ownpal = 1
ignorehitpause = 0
supermovetime = 9999999

[State 3353, ScreenBound]
type = ScreenBound
trigger1 = anim = 3300
trigger2 = 1
value = 1
movecamera = 0,0

[State 3353, 1]
type = Turn
trigger1 = Time = 0

[State 3353, VelAdd]
type = VelAdd
trigger1 = time >= 88
y = .3

[State 3353]
type = statetypeset
trigger1 = animelemtime(18)>=0
movetype = I

[State 3353, 5]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 1215
ctrl = 0
