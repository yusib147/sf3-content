;-| Button Remapping |-----------------------------------------------------
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s
;-| Default Values |-------------------------------------------------------
[Defaults]
command.time = 15
command.buffer.time = 1

;-| Super Motions |--------------------------------------------------------
[Command]
name = "FlamingSkull"
command = ~D, DF, F, D, DF, F, x
time = 32
[Command]
name = "FlamingSkull"
command = ~D, DF, F, D, DF, F, y
time = 32
[Command]
name = "FlamingSkull"
command = ~D, DF, F, D, DF, F, z
time = 32
[Command]
name = "FlamingSkull"
command = ~D, DF, F, D, DF, F, ~x
time = 32
[Command]
name = "FlamingSkull"
command = ~D, DF, F, D, DF, F, ~y
time = 32
[Command]
name = "FlamingSkull"
command = ~D, DF, F, D, DF, F, ~z
time = 32

[Command]
name = "MAXFlamingSkull"
command = ~D, DF, F, D, DF, F, x+y
time = 32
[Command]
name = "MAXFlamingSkull"
command = ~D, DF, F, D, DF, F, y+z
time = 32
[Command]
name = "MAXFlamingSkull"
command = ~D, DF, F, D, DF, F, x+z
time = 32

[Command]
name = "HellCycle"
command = ~D, DF, F, D, DF, F, a
time = 32
[Command]
name = "HellCycle"
command = ~D, DF, F, D, DF, F, b
time = 32
[Command]
name = "HellCycle"
command = ~D, DF, F, D, DF, F, c
time = 32
[Command]
name = "HellCycle"
command = ~D, DF, F, D, DF, F, ~a
time = 32
[Command]
name = "HellCycle"
command = ~D, DF, F, D, DF, F, ~b
time = 32
[Command]
name = "HellCycle"
command = ~D, DF, F, D, DF, F, ~c
time = 32

[Command]
name = "MAXHellCycle"
command = ~D, DF, F, D, DF, F, a+b
time = 32
[Command]
name = "MAXHellCycle"
command = ~D, DF, F, D, DF, F, b+c
time = 32
[Command]
name = "MAXHellCycle"
command = ~D, DF, F, D, DF, F, a+c
time = 32

[Command]
name = "ComboFlameWhipAttack"
command = ~D, DB, B, D, DB, B, x
time = 32
[Command]
name = "ComboFlameWhipAttack"
command = ~D, DB, B, D, DB, B, y
time = 32
[Command]
name = "ComboFlameWhipAttack"
command = ~D, DB, B, D, DB, B, z
time = 32
[Command]
name = "ComboFlameWhipAttack"
command = ~D, DB, B, D, DB, B, ~x
time = 32
[Command]
name = "ComboFlameWhipAttack"
command = ~D, DB, B, D, DB, B, ~y
time = 32
[Command]
name = "ComboFlameWhipAttack"
command = ~D, DB, B, D, DB, B, ~z
time = 32

[Command]
name = "MAXComboFlameWhipAttack"
command = ~D, DB, B, D, DB, B, x+y
time = 32
[Command]
name = "MAXComboFlameWhipAttack"
command = ~D, DB, B, D, DB, B, y+z
time = 32
[Command]
name = "MAXComboFlameWhipAttack"
command = ~D, DB, B, D, DB, B, x+z
time = 32

[Command]
name = "FlameMouth"
command = ~D, DB, B, D, DB, B, a
time = 32
[Command]
name = "FlameMouth"
command = ~D, DB, B, D, DB, B, b
time = 32
[Command]
name = "FlameMouth"
command = ~D, DB, B, D, DB, B, c
time = 32
[Command]
name = "FlameMouth"
command = ~D, DB, B, D, DB, B, ~a
time = 32
[Command]
name = "FlameMouth"
command = ~D, DB, B, D, DB, B, ~b
time = 32
[Command]
name = "FlameMouth"
command = ~D, DB, B, D, DB, B, ~c
time = 32

[Command]
name = "MAXFlameMouth"
command = ~D, DB, B, D, DB, B, a+b
time = 32
[Command]
name = "MAXFlameMouth"
command = ~D, DB, B, D, DB, B, b+c
time = 32
[Command]
name = "MAXFlameMouth"
command = ~D, DB, B, D, DB, B, a+c
time = 32

[Command]
name = "PenanceStare"
command = ~D, DF, F, D, DF, F, a+x
time = 32
[Command]
name = "PenanceStare"
command = ~D, DF, F, D, DF, F, b+y
time = 32
[Command]
name = "PenanceStare"
command = ~D, DF, F, D, DF, F, c+z
time = 32

[Command]
name = "214214pk"
command = ~D, DB, B, D, DB, B, a+x
time = 32
[Command]
name = "214214pk"
command = ~D, DB, B, D, DB, B, b+y
time = 32
[Command]
name = "214214pk"
command= ~D, DB, B, D, DB, B, c+z
time = 32

;-| Special Motions |------------------------------------------------------
[Command]
name = "FlamingUppercut"
command = ~F, D, DF, x
time = 18
[Command]
name = "FlamingUppercut"
command = ~F, D, DF, y
time = 18
[Command]
name = "FlamingUppercut"
command = ~F, D, DF, z
time = 18
[Command]
name = "FlamingUppercut"
command = ~F, D, DF, ~x
time = 18
[Command]
name = "FlamingUppercut"
command = ~F, D, DF, ~y
time = 18
[Command]
name = "FlamingUppercut"
command = ~F, D, DF, ~z
time = 18

[Command]
name = "EXFlamingUppercut"
command = ~F, D, DF, x+y
time = 18
[Command]
name = "EXFlamingUppercut"
command = ~F, D, DF, y+z
time = 18
[Command]
name = "EXFlamingUppercut"
command = ~F, D, DF, x+z
time = 18


[Command]
name = "FlamingCharge"
command = ~F, D, DF, a
time = 18
[Command]
name = "FlamingCharge"
command = ~F, D, DF, b
time = 18
[Command]
name = "FlamingCharge"
command = ~F, D, DF, c
time = 18
[Command]
name = "FlamingCharge"
command = ~F, D, DF, ~a
time = 18
[Command]
name = "FlamingCharge"
command = ~F, D, DF, ~b
time = 18
[Command]
name = "FlamingCharge"
command = ~F, D, DF, ~c
time = 18

[Command]
name = "EXFlamingCharge"
command = ~F, D, DF, a+b
time = 18
[Command]
name = "EXFlamingCharge"
command = ~F, D, DF, b+c
time = 18
[Command]
name = "EXFlamingCharge"
command = ~F, D, DF, a+c
time = 18

[Command]
name = "FireBall"
command = ~D, DF, F, x
time = 15
[Command]
name = "FireBall"
command = ~D, DF, F, y
time = 15
[Command]
name = "FireBall"
command = ~D, DF, F, z
time = 15
[Command]
name = "FireBall"
command = ~D, DF, F, ~x
time = 15
[Command]
name = "FireBall"
command = ~D, DF, F, ~y
time = 15
[Command]
name = "FireBall"
command = ~D, DF, F, ~z
time = 15

[Command]
name = "EXFireBall"
command = ~D, DF, F, x+y
time = 15
[Command]
name = "EXFireBall"
command = ~D, DF, F, y+z
time = 15
[Command]
name = "EXFireBall"
command = ~D, DF, F, x+z
time = 15

[Command]
name = "AirFlameWhip"
command = ~D, DF, F, x
time = 15
[Command]
name = "AirFlameWhip"
command = ~D, DF, F, y
time = 15
[Command]
name = "AirFlameWhip"
command = ~D, DF, F, z
time = 15
[Command]
name = "AirFlameWhip"
command = ~D, DF, F, ~x
time = 15
[Command]
name = "AirFlameWhip"
command = ~D, DF, F, ~y
time = 15
[Command]
name = "AirFlameWhip"
command = ~D, DF, F, ~z
time = 15

[Command]
name = "EXAirFlameWhip"
command = ~D, DF, F, x+y
time = 15
[Command]
name = "EXAirFlameWhip"
command = ~D, DF, F, y+z
time = 15
[Command]
name = "EXAirFlameWhip"
command = ~D, DF, F, x+z
time = 15

[Command]
name = "FlameWhip"
command = ~D, DB, B, x
time = 15
[Command]
name = "FlameWhip"
command = ~D, DB, B, y
time = 15
[Command]
name = "FlameWhip"
command = ~D, DB, B, z
time = 15
[Command]
name = "FlameWhip"
command = ~D, DB, B, ~x
time = 15
[Command]
name = "FlameWhip"
command = ~D, DB, B, ~y
time = 15
[Command]
name = "FlameWhip"
command = ~D, DB, B, ~z
time = 15

[Command]
name = "EXFlameWhip"
command = ~D, DB, B, x+y
time = 15
[Command]
name = "EXFlameWhip"
command = ~D, DB, B, y+z
time = 15
[Command]
name = "EXFlameWhip"
command = ~D, DB, B, x+z
time = 15

[Command]
name = "FlameBreath"
command = ~D, DF, F, a
time = 15
[Command]
name = "FlameBreath"
command = ~D, DF, F, b
time = 15
[Command]
name = "FlameBreath"
command = ~D, DF, F, c
time = 15
[Command]
name = "FlameBreath"
command = ~D, DF, F, ~a
time = 15
[Command]
name = "FlameBreath"
command = ~D, DF, F, ~b
time = 15
[Command]
name = "FlameBreath"
command = ~D, DF, F, ~c
time = 15

[Command]
name = "EXFlameBreath"
command = ~D, DF, F, a+b
time = 15
[Command]
name = "EXFlameBreath"
command = ~D, DF, F, b+c
time = 15
[Command]
name = "EXFlameBreath"
command = ~D, DF, F, a+c
time = 15

[Command]
name = "FirePillar"
command = ~D, DB, B, a
time = 15
[Command]
name = "FirePillar"
command = ~D, DB, B, b
time = 15
[Command]
name = "FirePillar"
command = ~D, DB, B, c
time = 15
[Command]
name = "FirePillar"
command = ~D, DB, B, ~a
time = 15
[Command]
name = "FirePillar"
command = ~D, DB, B, ~b
time = 15
[Command]
name = "FirePillar"
command = ~D, DB, B, ~c
time = 15

[Command]
name = "EXFirePillar"
command = ~D, DB, B, a+b
time = 15
[Command]
name = "EXFirePillar"
command = ~D, DB, B, b+c
time = 15
[Command]
name = "EXFirePillar"
command = ~D, DB, B, a+c
time = 15

[Command]
name = "46k"
command = ~$B, $F, a
time = 15
[Command]
name = "46k"
command = ~$B, $F, b
time = 15
[Command]
name = "46k"
command = ~$B, $F, c
time = 15
[Command]
name = "46k"
command = ~$B, $F, ~a
time = 15
[Command]
name = "46k"
command = ~$B, $F, ~b
time = 15
[Command]
name = "46k"
command = ~$B, $F, ~c
time = 15

[Command]
name = "46kk"
command = ~$B, $F, a+b
time = 15
[Command]
name = "46kk"
command = ~$B, $F, b+c
time = 15
[Command]
name = "46kk"
command = ~$B, $F, a+c
time = 15

[Command]
name = "46p"
command = ~$B, $F, x
time = 15
[Command]
name = "46p"
command = ~$B, $F, y
time = 15
[Command]
name = "46p"
command = ~$B, $F, z
time = 15
[Command]
name = "46p"
command = ~$B, $F, ~x
time = 15
[Command]
name = "46p"
command = ~$B, $F, ~y
time = 15
[Command]
name = "46p"
command = ~$B, $F, ~z
time = 15

[Command]
name = "46pp"
command = ~$B, $F, x+y
time = 15
[Command]
name = "46pp"
command = ~$B, $F, y+z
time = 15
[Command]
name = "46pp"
command = ~$B, $F, x+z
time = 15

[Command]
name = "28k"
command = ~$D, $U, a
time = 15
[Command]
name = "28k"
command = ~$D, $U, b
time = 15
[Command]
name = "28k"
command = ~$D, $U, c
time = 15
[Command]
name = "28k"
command = ~$D, $U, ~a
time = 15
[Command]
name = "28k"
command = ~$D, $U, ~b
time = 15
[Command]
name = "28k"
command = ~$D, $U, ~c
time = 15

[Command]
name = "28kk"
command = ~$D, $U, a+b
time = 15
[Command]
name = "28kk"
command = ~$D, $U, b+c
time = 15
[Command]
name = "28kk"
command = ~$D, $U, a+c
time = 15

[Command]
name = "28p"
command = ~$D, $U, x
time = 15
[Command]
name = "28p"
command = ~$D, $U, y
time = 15
[Command]
name = "28p"
command = ~$D, $U, z
time = 15
[Command]
name = "28p"
command = ~$D, $U, ~x
time = 15
[Command]
name = "28p"
command = ~$D, $U, ~y
time = 15
[Command]
name = "28p"
command = ~$D, $U, ~z
time = 15

[Command]
name = "28pp"
command = ~$D, $U, x+y
time = 15
[Command]
name = "28pp"
command = ~$D, $U, y+z
time = 15
[Command]
name = "28pp"
command = ~$D, $U, x+z
time = 15

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1
[Command]
name = "recovery"
command = a+x
time = 1
[Command]
name = "recovery"
command = y+z
time = 1
[Command]
name = "recovery"
command = x+z
time = 1
[Command]
name = "recovery"
command = a+b
time = 1
[Command]
name = "recovery"
command = b+c
time = 1
[Command]
name = "recovery"
command = a+c
time = 1

[Command]
name = "pp"
command = x+y
time = 1
[Command]
name = "pp"
command = x+z
time = 1
[Command]
name = "pp"
command = y+z
time = 1
[Command]
name = "kk"
command = a+b
time = 1
[Command]
name = "kk"
command = a+c
time = 1
[Command]
name = "kk"
command = b+c
time = 1

[Command]
name = "ppp"
command = x+y+z
time = 1
[Command]
name = "kkk"
command = a+b+c
time = 1
;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1
[Command]
name = "b"
command = b
time = 1
[Command]
name = "c"
command = c
time = 1
[Command]
name = "x"
command = x
time = 1
[Command]
name = "y"
command = y
time = 1
[Command]
name = "z"
command = z
time = 1
[Command]
name = "s"
command = s
time = 1
;-| Single Dir |------------------------------------------------------------
[Command]
name = "fwd" ;Required (do not remove)
command = $F
time = 1
[Command]
name = "downfwd"
command = $DF
time = 1
[Command]
name = "down" ;Required (do not remove)
command = $D
time = 1
[Command]
name = "downback"
command = $DB
time = 1
[Command]
name = "back" ;Required (do not remove)
command = $B
time = 1
[Command]
name = "upback"
command = $UB
time = 1
[Command]
name = "up" ;Required (do not remove)
command = $U
time = 1
[Command]
name = "upfwd"
command = $UF
time = 1
;-| Hold Button |--------------------------------------------------------------
[Command]
name = "hold_x"
command = /x
time = 1
[Command]
name = "hold_y"
command = /y
time = 1
[Command]
name = "hold_z"
command = /z
time = 1
[Command]
name = "hold_a"
command = /a
time = 1
[Command]
name = "hold_b"
command = /b
time = 1
[Command]
name = "hold_c"
command = /c
time = 1
[Command]
name = "hold_s"
command = /s
time = 1
;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1
[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1
[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1
[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1
[Command]
name = "holdfwd" ;Required (do not remove)
command = /$F
time = 1
[Command]
name = "holddownfwd"
command = /$DF
time = 1
[Command]
name = "holddown" ;Required (do not remove)
command = /$D
time = 1
[Command]
name = "holddownback"
command = /$DB
time = 1
[Command]
name = "holdback" ;Required (do not remove)
command = /$B
time = 1
[Command]
name = "holdupback"
command = /$UB
time = 1
[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1
[Command]
name = "holdupfwd"
command = /$UF
time = 1
;---------------------------------------------------------------------------
;Release Direction
[Command]
name = "rlsfwd"
command = ~$F
time = 1
[Command]
name = "rlsback"
command = ~$B
time = 1
[Command]
name = "rlsup"
command = ~$U
time = 1
[Command]
name = "rlsdown"
command = ~$D
time = 1
;--------------------------------------------------------------------------
;Release Button
[Command]
name = "rlsx"
command = ~x
time = 1
[Command]
name = "rlsy"
command = ~y
time = 1
[Command]
name = "rlsz"
command = ~z
time = 1
[Command]
name = "rlsa"
command = ~a
time = 1
[Command]
name = "rlsb"
command = ~b
time = 1
[Command]
name = "rlsc"
command = ~c
time = 1
;---------------------------------------------------------------------------
;Other
[Command]
name = "highjump"
command = $D, $U
time = 15
[Command]
name = "DU"
command = D, U
time = 18
[Command]
name = "DU"
command = DB, UF
time = 18
[Command]
name = "DU"
command = DF, UB
time = 18
[Command]
name = "DU"
command = $D, UF
time = 18
[Command]
name = "DU"
command = $D, UB
time = 18

[Command]
name = "412p"
command = ~B, DB, D, x
time = 18
[Command]
name = "412p"
command = ~B, DB, D, y
time = 18
[Command]
name = "412p"
command = ~B, DB, D, z
time = 18
[Command]
name = "412p"
command = ~B, DB, D, ~x
time = 18
[Command]
name = "412p"
command = ~B, DB, D, ~y
time = 18
[Command]
name = "412p"
command = ~B, DB, D, ~z
time = 18

[Command]
name = "412pp"
command = ~B, DB, D, x+y
time = 18
[Command]
name = "412pp"
command = ~B, DB, D, y+z
time = 18
[Command]
name = "412pp"
command = ~B, DB, D, x+z
time = 18


[Command]
name = "412k"
command = ~B, DB, D, a
time = 18
[Command]
name = "412k"
command = ~B, DB, D, b
time = 18
[Command]
name = "412k"
command = ~B, DB, D, c
time = 18
[Command]
name = "412k"
command = ~B, DB, D, ~a
time = 18
[Command]
name = "412k"
command = ~B, DB, D, ~b
time = 18
[Command]
name = "412k"
command = ~B, DB, D, ~c
time = 18

[Command]
name = "412kk"
command = ~B, DB, D, a+b
time = 18
[Command]
name = "412kk"
command = ~B, DB, D, b+c
time = 18
[Command]
name = "412kk"
command = ~B, DB, D, a+c
time = 18
;---------------------------------------------------------------------------
[Statedef -1]

[State -1, Tick Fix]
type = CtrlSet
triggerall = 0
triggerall = RoundState = 2
triggerall = !ctrl
triggerall = MoveType != H
trigger1 = (stateno = 52 || stateno = 101 || stateno = 5120) && !AnimTime
trigger2 = (stateno = [200,299]) && !AnimTime
trigger3 = (stateno = [400,499]) && !AnimTime
trigger4 = (stateno = [700,715]) && !AnimTime
trigger5 = (stateno = [6080,6082]) && (!AnimTime || Time >= 15)
value = 1
;----------------------------------------------------------------------
[State -1, Penance Stare]
type=ChangeState
value=3400
triggerall=!AILevel && RoundState=2 && StateType != A && var(20)<=0&& power >= 3000&&command ="PenanceStare"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)
;----------------------------------------------------------------------
[State -1, MAX Flame Mouth]
type=ChangeState
value=3350
triggerall=!AILevel && RoundState=2 && StateType != A && var(20) <= 60 && power >= 2000 && command ="MAXFlameMouth"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7) && var(22) < 1
;----------------------------------------------------------------------
[State -1, Flame Mouth]
type=ChangeState
value=3300
triggerall=!AILevel && RoundState=2 && (stateno!=[3000,3050]) && StateType != A && !Numhelper(3305) && var(20) <= 60 && power >= 1000 && command ="FlameMouth"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7) && var(22) < 2 && var(52)
;----------------------------------------------------------------------
[State -1, MAX HellCycle]
type=ChangeState
value=3250
triggerall=!AILevel && RoundState=2 && StateType != A
triggerall=(stateno!=3250) && var(20) <= 60 && power >= 2000
triggerall= command="MAXHellCycle" && !numtarget(3250) && !var(0)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[10,12])|| StateNo=106 || (StateNo=[100,101])
trigger2=var(6)|| var(7) && var(22) < 1
;----------------------------------------------------------------------
[State -1, HellCycle]
type=ChangeState
value=3200
triggerall=!AILevel && RoundState=2 && StateType != A
triggerall=var(20) <= 60 && power >= 1000||var(0) && var(8)>1
triggerall= command="HellCycle" && (stateno!=[3200,3210]) && !numtarget(3200) 
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[10,12])|| StateNo=106 || (StateNo=[100,101])
trigger2=var(6)|| var(7) && var(22) < 2 && var(52)
;----------------------------------------------------------------------
[State -1, MAX Combo Flame Whip Attack]
type=ChangeState
value=3150
triggerall=!AILevel && RoundState=2 && !Numtarget(3150) && stateno!= 3150 && StateType != A && var(20) <= 60 && power >= 2000 && command ="MAXComboFlameWhipAttack"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7) && var(22) < 1
;----------------------------------------------------------------------
[State -1, Combo Flame Whip Attack]
type=ChangeState
value=3100
triggerall=!AILevel && RoundState=2 && !Numtarget(3100) && stateno!= 3100  && StateType != A && var(20) <= 60 && power >= 1000 && command ="ComboFlameWhipAttack"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7) && var(22) < 2 && var(52)
;----------------------------------------------------------------------
[State -1, MMX Flaming Skull]
type=ChangeState
value=3050
triggerall=!AILevel && RoundState=2 && Stateno!=3050 && StateType != A && !Numhelper(3055) && var(20) <= 60 && power >= 2000&&command ="MAXFlamingSkull"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7) && var(22) < 1
;----------------------------------------------------------------------
[State -1, Flaming Skull]
type=ChangeState
value=3000
triggerall=!AILevel && RoundState=2 && Stateno!=3000 && StateType != A && var(20) <= 60 && power >= 1000&&command ="FlamingSkull"
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7) && var(22) < 2 && var(52)
;========================================================================
[State -1, Fire Pillar]
type=ChangeState
value=Ifelse(command="EXFirePillar"&&var(20) <= 60&&power>=500,1650,1600)
triggerall=!AILevel && RoundState=2 && StateType != A && Ifelse(!var(20),!Numhelper(1605),Numhelper(1605)<5)
triggerall= ((command="FirePillar")||(command="EXFirePillar" && power>=500 && var(20) <= 60))
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
;----------------------------------------------------------------------
[State -1, Flaming Charge]
type=ChangeState
value=Ifelse(command="EXFlamingCharge"&&var(20) <= 60&&power>=500,1550,1500)
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && RoundState=2 && StateType != A
triggerall= (command="FlamingCharge"||command="EXFlamingCharge")
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
;----------------------------------------------------------------------
[State -1, Flame Breath]
type=ChangeState
value=Ifelse(command="EXFlameBreath" && var(20) <= 60 && power>=500,1450,1400)
triggerall=!AILevel && RoundState=2 && StateType != A 
triggerall= (command="FlameBreath")||(command="EXFlameBreath" && power>=500 && var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,103])
trigger2=var(5)
;----------------------------------------------------------------------
[State -1, Flame Whip]
type=ChangeState
value=Ifelse(command="EXFlameWhip" && var(20) <= 60 && power>=500,1350,1300)
triggerall=!AILevel && RoundState=2 && StateType != A && (command="FlameWhip"||command="EXFlameWhip" && power>=500 && var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
;----------------------------------------------------------------------
[State -1, Air Flame Whip]
type=ChangeState
value=Ifelse(command="EXAirFlameWhip" && var(20) <=60 && power>=500,1250,1200)
triggerall=!AILevel && RoundState=2 
triggerall=pos y <=-20 && StateType=A 
triggerall=(command="AirFlameWhip")||(command="EXAirFlameWhip" && power>=500 && var(20) <=60)
trigger1=ctrl 
trigger2=var(5)
trigger3=(stateno=[600,650]) && movecontact
;----------------------------------------------------------------------
[State -1, Flaming Uppercut]
type=ChangeState
value=Ifelse(command="EXFlamingUppercut"&&var(20) <= 60&&power>=500,1150,1100)
triggerall=!AILevel && RoundState=2 && StateType != A && (command="FlamingUppercut")||(command="EXFlamingUppercut"&&power>=500&&var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact && (command="EXFlamingUppercut"&&power>=500&&var(20) <= 60)
;----------------------------------------------------------------------
[State -1, Fire Ball]
type=ChangeState
value=Ifelse(command="EXFireBall"&&var(20) <= 60&&power>=500,1050,1000)
triggerall=!AILevel && RoundState=2 && StateType != A && Ifelse(!var(20),!Numhelper(1005),Numhelper(1005)<5)
triggerall= (command="FireBall")||(command="EXFireBall"&&power>=500&&var(20) <= 60)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
trigger3=(stateno = 450) && movecontact && (command="EXFireBall"&&power>=500&&var(20) <= 60)
;========================================================================
[State -1, Zero Counter]
type = ChangeState
value = 750
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = var(51) >= 1 && (command = "holdfwd" && (command = "pp" || command = "kk")) || var(51) != 1 && (command = "412p") || (command = "412k")
trigger1 = !AILevel && !IsHelper&&RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)
;------------------------------------------------------------------------
[State -1, Guard Cancel Roll]
type = ChangeState
value = 740
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = (command = "holdfwd" || command = "holdback") && command = "a" && command = "x"
trigger1 = !AILevel && !IsHelper&&RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)
;------------------------------------------------------------------------
[State -1, Throw]
type=ChangeState
value =800
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
trigger1=(command="holdfwd"||command="holdback")&&(command="pp"||command="kk")
trigger1=!AILevel && !IsHelper&&RoundState=2 && Statetype=S
trigger1=ctrl
;------------------------------------------------------------------------
[State -1, Air Throw]
type=Null;ChangeState
value =850
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
trigger1=(command="holdfwd"||command="holdback")&&(command="pp")
trigger1=!AILevel && !IsHelper&&RoundState=2 && Statetype=A && Pos Y<=-30
trigger1=ctrl
;-------------------------------------------------------------------------
[State -1, Power Charge]
type = ChangeState
value = 730
trigger1 = command = "b" && command = "y"
trigger1 = !AILevel && !IsHelper&&RoundState = 2 && StateType != A  && !numhelper(3850)
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (StateNo = [100,101])
;--------------------------------------------------------------------------
[State -1, Super Jump]
type = ChangeState
value = 123
triggerall= !AILevel && !IsHelper && var(55)=2 && roundstate=2 && statetype != A
trigger1 = ctrl && command = "DU" 
trigger2 = stateno=420 && movehit && command = "holdup"
;--------------------------------------------------------------------------
[State -1, Roll]
type = ChangeState
value = Ifelse(((command = "holdback" && p2dist x >= 0) || (command = "holdfwd" && p2dist x < 0)), 715, 710)
triggerall = command = "a" && command = "x" && (command = "holdfwd" || command = "holdback")
triggerall = !AILevel && !IsHelper && RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))
;--------------------------------------------------------------------------
[State -1, Sidestep]
type = ChangeState
value = 700
triggerall = command = "a" && command = "x"
triggerall = !AILevel && !IsHelper && RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))
;--------------------------------------------------------------------------
[State -1, Custom Combo]
type = ChangeState
value = Ifelse(StateType = A,905,900)
triggerAll = !AILevel && !IsHelper && command = "c" && command = "z" && RoundState = 2 && power >= 1000 && !var(20)
trigger1 = ctrl || StateNo = 52 || (StateNo = [100,101])
;--------------------------------------------------------------------------
[State -1, Run /Dash Back]
type = ChangeState
value = Ifelse(((command = "BB" && p2dist x >= 0) || (command = "FF" && p2dist x < 0)), 105, 102)
trigger1 = !AILevel && !IsHelper&&Roundstate=2&&statetype = S
trigger1 = command = "FF"||command = "BB"
trigger1 = ctrl
;--------------------------------------------------------------------------
;--------------------------------------------------------------------------
[State -1, Standing Low Punch]
type=ChangeState
value=200
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command != "holddown"&& command="x"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=!var(55)&&stateno=200&&(movecontact|animelemtime(3)>0)
;---------------------------------------------------------------------------
[State -1, Standing Medium Punch]
type=ChangeState
value=210
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command != "holddown"&& command="y"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,209])||(stateno=[230,239])||(stateno=[400,409])||(stateno=[430,439]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Standing High Punch]
type=ChangeState
value=220
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command != "holddown"&& command="z"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,219])||(stateno=[230,249])||(stateno=[400,419])||(stateno=[430,449]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Standing Low Kick]
type=ChangeState
value=230
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command != "holddown"&& command="a"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=(stateno=[200,209])&&movecontact
trigger4=(stateno=[400,409])&&movecontact&&var(55)
trigger5=!var(55)&&stateno=230&&(movecontact|animelemtime(3)>0)
;---------------------------------------------------------------------------
[State -1, Standing Medium Kick]
type=ChangeState
value=240
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command != "holddown"&& command="b"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,219])||(stateno=[230,239])||(stateno=[400,419])||(stateno=[430,439]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Standing High Kick]
type=ChangeState
value=250
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command != "holddown"&& command="c"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,249])||(stateno=[400,449]))&&movecontact&&var(55)&&prevstateno!=750
;---------------------------------------------------------------------------
[State -1, Crouching Low Punch]
type=ChangeState
value=400
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command="holddown"&& command="x"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=!var(55)&&stateno=400&&(movecontact|animelemtime(3)>0)
;---------------------------------------------------------------------------
[State -1, Crouching Medium Punch]
type=ChangeState
value=410
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command= "holddown"&& command="y"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,209])||(stateno=[230,239])||(stateno=[400,409])||(stateno=[430,439]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Crouching High Punch]
type=ChangeState
value=420
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command="holddown"&& command="z"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,219])||(stateno=[230,249])||(stateno=[400,419])||(stateno=[430,449]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Crouching Low Kick]
type=ChangeState
value=430
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command="holddown"&& command="a"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,209])||(stateno=[400,409]))&&movecontact;&&var(55)
trigger4=!var(55)&&stateno=430&&(movecontact|animelemtime(2)>0)
;---------------------------------------------------------------------------
[State -1, Crouching Medium Kick]
type=ChangeState
value=440
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command="holddown"&& command="b"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,219])||(stateno=[230,239])||(stateno=[400,419])||(stateno=[430,439]))&&movecontact&&var(55)
;---------------------------------------------------------------------------
[State -1, Crouching High Kick]
type=ChangeState
value=450
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype != A&&command="holddown"&& command="c"
trigger1=ctrl||stateno=[100,101]
trigger2=var(4)
trigger3=((stateno=[200,249])||(stateno=[400,449]))&&movecontact&&var(55)&&prevstateno!=750
;---------------------------------------------------------------------------
[State -1, Jumping Low Punch]
type=ChangeState
value=600
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype=A&&command="x"
trigger1=ctrl
trigger2=var(4)
;---------------------------------------------------------------------------
[State -1, Jumping Medium Punch]
type=ChangeState
value=610
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype=A&&command="y"
trigger1=ctrl
trigger2=var(4)
trigger3=((stateno=[600,609])||(stateno=[630,639]))&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Jumping High Punch]
type=ChangeState
value=620
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype=A&&command="z"
trigger1=ctrl
trigger2=var(4)
trigger3=((stateno=[600,619])||(stateno=[630,649]))&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Jumping Low Kick]
type=ChangeState
value=630
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype=A&&command="a"
trigger1=ctrl
trigger2=var(4)
trigger3=(stateno=[600,609])&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Jumping Medium Kick]
type=ChangeState
value=640
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype=A&&command="b"
trigger1=ctrl
trigger2=var(4)
trigger3=((stateno=[600,619])||(stateno=[630,639]))&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Jumping High Kick]
type=ChangeState
value=650
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=!AILevel && !IsHelper&&Roundstate=2&&statetype=A&&command="c"
trigger1=ctrl
trigger2=var(4)
trigger3=(stateno=[600,649])&&movecontact&&var(55)=2
;---------------------------------------------------------------------------
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = command = "s"
triggerall = !AILevel && !IsHelper&&Roundstate=2&&StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = var(5)
;--------------------------------------------------------------------------
;AI
;--------------------------------------------------------------------------
[State -1, Idle]
type = changestate
value = 0
triggerall = numenemy
triggerall = AILevel && !IsHelper &&roundstate = 2 && statetype != A && enemynear, movetype = A && (p2stateno=[5100,5220])
trigger1=ctrl

[State -1, run]
type = changestate
value = 102
trigger1 = AILevel && !IsHelper && numenemy
trigger1 = statetype = S && roundstate = 2 && ctrl && random < (300 * (var(59) ** 2 / 64.0))
trigger1 = (stateno != [100, 105]) && enemynear, movetype != A && p2bodydist x > 120

[State -1, dash]
type = changestate
value = 105
triggerall = AILevel && !IsHelper && numenemy
triggerall = statetype = S && roundstate = 2 && ctrl && !numhelper(6085)
triggerall = (p2bodydist x = [0, 80]) && backedgebodydist > 80 && (stateno != [100, 105])
trigger1 = enemynear, movetype = A && random < (50 * (var(59) ** 2 / 64.0))
trigger2 = enemynear, stateno = 5120 && enemynear, animtime = -3 && random < (300 * (var(59) ** 2 / 64.0))

[State -1, Jump]
type = changestate
value = 40
trigger1 = AIlevel && numenemy && random < (350 * (AIlevel ** 2 / 64.0))
trigger1 = roundstate = 2 && statetype != A && ctrl
trigger1 = enemynear, movetype = A && p2bodydist x < 120 && enemynear, hitdefattr = SC, AT

[state -1,AI Air Guard]
type = ChangeState
value = 132
triggerall = AIlevel && numenemy&& roundstate = 2&&InGuardDist
triggerall = ctrl&&statetype = A
trigger1 = enemynear,numproj
trigger2 = enemynear,HitDefAttr = SCA, NA,SA,HA
trigger2 = random <=ifelse(backedgedist<=10,950,900)

[State -1, Guard]
type = changestate
value = 120
trigger1 = AIlevel && numenemy
trigger1 = roundstate = 2 && inguarddist
trigger1 = ctrl && (stateno != [120, 155]) && !var(20)
trigger1 = !(enemynear, hitdefattr = SCA, AT) && (enemynear, time < 120)
trigger1 = !numhelper(6085) && (P2Dist x >= 0 || StateType != A)
trigger1 = random < (ifelse((p2stateno = [200, 699]), 700, ifelse((p2stateno = [1000, 2999]), 850, 1000)) * (AIlevel ** 2 / 64.0))

[State -1, Guard]
type = ChangeState
value = 120
triggerall= AILevel && numenemy&& (StateNo!=[120,155]) && !(enemynear,ctrl) && random < (750 * (AIlevel ** 2 / 64.0))
triggerall= Ctrl||stateno = 21
triggerall=enemynear,Movetype=A && !(enemynear,hitdefattr=SCA,AT) 
trigger1 = inguarddist

[State -1, Super Jump]
type = ChangeState
value = 123
triggerall = AILevel && numenemy && var(55)=2 && statetype != A && roundstate = 2 && (p2bodydist y = [-320,5])
triggerall = stateno != 100 && pos y = 0 && (enemynear,Statetype!=C)
trigger1 = ctrl && enemy,vel y < -1 && (p2bodydist x = [ 10, 70]) && enemynear,movetype != A && random < (200 * (AIlevel ** 2 / 64.0))
trigger2 = ctrl && enemy,vel y < -1 && random < (150 * (AIlevel ** 2 / 64.0))
trigger2 = enemynear,movetype = H && (enemynear,stateno=5040)
trigger2 = p2bodydist x <= 50 && random < (150 * (AIlevel ** 2 / 64.0))
trigger3 = ctrl && enemynear,MoveType != H&&P2BodyDist Y < -90&& enemy,vel y <= 0 && random < (350 * (AIlevel ** 2 / 64.0))
trigger4 = stateno=420 && MoveHit && random < (800 * (AIlevel ** 2 / 64.0))
trigger5 = ctrl && (p2bodydist x<=140) && (enemynear,statetype!=A) && (enemynear,movetype=A) && (enemynear,stateno=[2000,4999]) && random < (750 * (AIlevel ** 2 / 64.0))

[State -1, Zero Counter]
type = changestate
value = 750
trigger1 = AIlevel && numenemy
trigger1 = (p2dist x = [-90, 90]) && stateno = 150 || stateno = 152
trigger1 = roundstate = 2 && power >= 2000 && !var(20) && life < 500 && random < (10 * (AIlevel ** 2 / 64.0))

[State -1, Guard Cancel Roll]
type = ChangeState
value = 740
trigger1 = AILevel && !IsHelper && numenemy
trigger1 = stateno = 150 || stateno = 152
trigger1 = roundstate = 2 && statetype != A
trigger1 = power >= 1000 && !var(20)
trigger1 = (p2bodydist x = [0,50]) && (life < 0.5 * lifemax)
trigger1 = enemynear, animtime = [-45,-30]
trigger1 = random < (power / 10.0)
trigger1 = random < (50 * (var(59) ** 2.0 / 64.0))

[State -1, powercharge]
type = changestate
value = 730
trigger1 = AIlevel && numenemy
trigger1 = roundstate = 2 && statetype != A && ctrl
trigger1 = power < const(data.power) && power < powermax && !var(20)
trigger1 = random < (50 * (AIlevel ** 2 / 64.0)) && !inguarddist && p2movetype != A && p2dist x >= 190

[State -1, roll forward]
type = changestate
value = 710
triggerall= AIlevel && numenemy
triggerall= roundstate=2 && statetype!=A && !var(20)
triggerall= (facing=1 && (enemynear,facing=-1)) || (facing=-1 && (enemynear,facing=1))
triggerall= (ctrl || (stateno=[100,101])) && !(enemy,hitdefattr=SC,ST,HT,AT)
trigger1= enemynear,movetype=A && (p2bodydist x=[80,120]) && random<200*(AIlevel**2/64.0)
trigger2= ((enemynear,stateno>=1000 && enemynear,animtime<=-30) || (enemynear,numproj) || (enemynear,numhelper)) && p2bodydist x>=80 && inguarddist && random<250*(AIlevel**2/64.0)

[State -1, roll backward]
type=changestate
value=715
triggerall= AIlevel && numenemy
triggerall= roundstate=2 && statetype!=A 
triggerall= !(enemy,hitdefattr=SC,AT) && !var(20)
triggerall= backedgebodydist>=80 && !(enemy,hitdefattr=SC,ST,HT,AT)
triggerall= !(stateno=[6080,6081]) && !numtarget && !(enemynear,stateno=5300)
triggerall= !(enemynear,stateno=[1110000,1115120])
triggerall= (ctrl || (stateno=[100,101])) && (p2bodydist x=[25,50])
trigger1= enemynear,movetype=A && random<200*(AIlevel**2/64.0)
trigger2= enemynear,statetype=L && random<250*(AIlevel**2/64.0)

[State -1, dodge]
type=changestate
value=700
triggerall= AIlevel && numenemy
triggerall= roundstate=2 && statetype!=A && !var(28)
triggerall= (facing=1 && (enemynear,facing=-1)) || (facing=-1 && (enemynear,facing=1))
triggerall= (ctrl || (stateno=[100,101])) && !(enemy,hitdefattr=SC,ST,HT,AT)
trigger1= enemynear,movetype=A && (p2bodydist x=[0,40]) && !var(15) && random<200*(AIlevel**2/64.0)
trigger2= ((enemynear,numproj) || (enemynear,numhelper)) && inguarddist && p2bodydist x>=50 && random<250*(AIlevel**2/64.0)
;-------------------------------------------------------------------
[State -1, Throw]
type = ChangeState
value = 800
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = numenemy
triggerall = AILevel && !IsHelper&&random < (500 * (var(59) ** 2 / 64.0))
triggerall = roundstate=2&&statetype!=A&& enemynear,statetype!=L&&(enemynear,stateno!=[5120,5201]) && !var(20)
triggerall = enemynear,movetype!=H&&enemynear,statetype!=A&&enemynear,Hitover&&(p2bodydist x =[0,30])
triggerall = ctrl||stateno=100||stateno=52
trigger1 = random>=800
trigger2 = enemynear,stateno=[120,155]
trigger2 = random>=500
trigger3 = stateno=100
trigger4=(p2bodydist x=[0,30])&&random<250
trigger5=(p2stateno=[120,155])&&(p2bodydist x=[0,30])&&random<500
;-------------------------------------------------------------------
[State -1, Air Throw]
type = Null;ChangeState
value = 850
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = numenemy
triggerall = AILevel && !IsHelper&&random < (500 * (var(59) ** 2 / 64.0))
triggerall = roundstate=2&&statetype=A&& enemynear,statetype!=L&&(enemynear,stateno!=[5120,5201]) && !var(20)
triggerall = enemynear,movetype!=H&&enemynear,statetype=A&&enemynear,Hitover&&(p2bodydist x =[0,30])&&(p2bodydist y =[-50,0])
triggerall = ctrl
trigger1 = random>=800
trigger2 = enemynear,stateno=[120,155]
trigger2 = random>=500
trigger3=(p2bodydist x=[0,30])&&random<250
trigger4=(p2stateno=[120,155])&&(p2bodydist x=[0,30])&&random<500
;------------------------------------------------------------------------
[State -1, Standing Low Punch AI]
type = ChangeState
value = 200
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy&&roundstate=2&&StateType != A
triggerall = p2bodydist x <=45&&(p2bodydist y = [-80,5])&&P2statetype != A&&P2statetype != C&&P2statetype != L&& random < (650 * (var(59) ** 2 / 64.0))
trigger1 = ctrl
trigger2 = (stateno = [100,101]) && random < 100
;---------------------------------------------------------------------------
[State -1, Standing Medium Punch AI]
type = ChangeState
value = 210
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A && P2statetype != A && P2statetype != C
triggerall = (p2bodydist x = [0, 30]) && p2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (150 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [200,209])|| (stateno = [230,239])||(stateno = [400,409])||(stateno = [430,439]))&& movehit&&var(55)
trigger2 = random < 350
;---------------------------------------------------------------------------
[State -1, Standing High Punch AI]
type = ChangeState
value = 220
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A
triggerall = (p2bodydist x = [0, 55]) && (p2bodydist y = [ -80, 80]) && p2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (80 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [210,219])|| (stateno = [240,249])||(stateno = [410,419])||(stateno = [440,449]))&& movehit&&var(55)
trigger2 = random < 650
;---------------------------------------------------------------------------
[State -1, Standing Low Kick AI]
type = ChangeState
value = 230
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A && P2statetype != A
triggerall = (p2bodydist x = [0, 40]) && p2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (80 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [200,209])|| (stateno = [400,409]))&& movehit&&var(55)
trigger2 = random < 200
trigger3 = (stateno = [100,101]) && random < 100
;---------------------------------------------------------------------------
[State -1, Standing Medium Kick AI]
type = ChangeState
value = 240
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A && P2statetype != A && P2statetype != C
triggerall = (p2bodydist x = [0, 55]) && p2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (100 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [210,219])|| (stateno = [230,239])||(stateno = [410,419])||(stateno = [430,439]))&& movehit&&var(55)
trigger2 = random < 350
;---------------------------------------------------------------------------
[State -1, Standing High Kick AI]
type = ChangeState
value = 250
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A && P2statetype != C
triggerall = (p2bodydist x = [0, 60]) && (p2bodydist y = [ -60, 50]) && p2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (100 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [240,249])|| (stateno = [440,449]))&& movehit && stateno != 225&&var(55)&&prevstateno!=750
trigger2 = random < 800
;---------------------------------------------------------------------------
[State -1, Crouching Low Punch]
type = ChangeState
value = 400
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A
triggerall = (p2bodydist x = [0, 40]) &&(p2bodydist y = [-50,25]) && P2statetype != A && P2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (100 * (var(59) ** 2 / 64.0))
trigger2 = stateno = [100,101]
;---------------------------------------------------------------------------
[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A
triggerall = (p2bodydist x = [0, 55]) &&(p2bodydist y = [-50,25]) && P2statetype != A && P2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (150 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [200,209])|| (stateno = [230,239])||(stateno = [400,409])||(stateno = [430,439]))&& movehit&&var(55)
trigger2 = random < 800
;---------------------------------------------------------------------------
[State -1, Crouching High Punch]
type = ChangeState
value = 420
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A
triggerall = (p2bodydist x = [0, 70]) &&(p2bodydist y = [-80,5]) && P2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (125 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [210,219])|| (stateno = [240,249])||(stateno = [410,419])||(stateno = [440,449]))&& movehit&&var(55)
trigger2 = random < 600
;---------------------------------------------------------------------------
[State -1, Crouching Low Kick]
type = ChangeState
value = 430
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A
triggerall = (p2bodydist x = [0, 35]) &&(p2bodydist y = [-50,25]) && P2statetype != A && P2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (50 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [200,209])|| (stateno = [400,409]))&& movehit&&var(55)
;---------------------------------------------------------------------------
[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A
triggerall = (p2bodydist x = [0, 45]) &&(p2bodydist y = [-50,25]) && P2statetype != A && P2statetype != L && !(enemynear, hitfall)
trigger1 = ctrl && random < (75 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [210,219])|| (stateno = [230,239])||(stateno = [410,419])||(stateno = [430,439]))&& movehit&&var(55)
trigger2 = random < 350
;---------------------------------------------------------------------------
[State -1, Crouching High Kick]
type = ChangeState
value = 450
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy && roundstate=2 && StateType != A && P2statetype != A
triggerall = (p2bodydist x = [0, 55]) && (p2bodydist y = [ -50, 50]) && p2statetype != L && p2statetype = S && !(enemynear, hitfall)
trigger1 = ctrl && random < (100 * (var(59) ** 2 / 64.0))
trigger2 = ((stateno = [220,229])|| (stateno = [240,249])||(stateno = [420,429])||(stateno = [440,449]))&& movehit&&var(55)&&prevstateno!=750
trigger2 = random < 900
;---------------------------------------------------------------------------
[State -1, Jumping Low Punch]
type = ChangeState
value = 600
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy&&roundstate=2&&statetype = A && (p2bodydist x = [0,60]) && (p2bodydist y = [ -50, 50]) && p2statetype != L
trigger1 = ctrl && random < (500 * (var(59) ** 2 / 64.0))
;---------------------------------------------------------------------------
[State -1, Jumping Medium Punch]
type = ChangeState
value = 610
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy&&roundstate=2&&statetype = A && (p2bodydist x = [0, 70]) && (p2bodydist y = [ -50, 50]) && p2statetype != L 
trigger1 = ctrl && random < (ifelse((vel x > 0 && p2statetype = A), 250, 125) * (var(59) ** 2 / 64.0)) 
trigger2 = (stateno = [600,609])&& movehit && var(55)=2 && random < 750
trigger3 = (stateno = [630,639])&& movehit && var(55)=2 && random < 250
;---------------------------------------------------------------------------
[State -1, Jumping High Punch]
type = ChangeState
value = 620
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy&&roundstate=2&&statetype = A && (p2bodydist x = [0, 100]) && (p2bodydist y = [ -80, 50]) && p2statetype != L 
trigger1 = ctrl && random < (150 * (var(59) ** 2 / 64.0)) && !(enemynear, hitfall)
trigger2 = (stateno = [610,619])&& movehit && var(55)=2 && random < 700
trigger3 = (stateno = [640,649])&& movehit && var(55)=2 && random < 200
;---------------------------------------------------------------------------
[State -1, Jumping Low Kick]
type = ChangeState
value = 630
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy&&roundstate=2&&statetype = A && (p2bodydist x = [0, 70]) && (p2bodydist y = [ -50, 50]) && p2statetype != L 
trigger1 = ctrl && random < (50 * (var(59) ** 2 / 64.0))
trigger2 = (stateno = [600,609])&& movehit && var(55)=2 && random < 250
;---------------------------------------------------------------------------
[State -1, Jumping Medium Kick]
type = ChangeState
value = 640
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy&&roundstate=2&&statetype = A && (p2bodydist x = [0, 90]) && (p2bodydist y = [ -50, 50]) && p2statetype != L 
trigger1 = ctrl && random < (250 * (var(59) ** 2 / 64.0)) && !(enemynear, hitfall)
trigger2 = (stateno = [610,619])&& movehit && var(55)=2 && random < 100
trigger3 = (stateno = [630,639])&& movehit && var(55)=2 && random < 750
;---------------------------------------------------------------------------
[State -1, Jumping High Kick]
type = ChangeState
value = 650
triggerall = !var(58)||(var(58)&&sysfvar(4)=0)
triggerall = AILevel && !IsHelper && numenemy &&roundstate=2&&statetype = A && (p2bodydist x = [0, 130]) && (p2bodydist y = [ -50, 50]) && p2statetype != L 
trigger1 = ctrl && random < (250 * (var(59) ** 2 / 64.0)) && !(enemynear, hitfall) 
trigger2 = (stateno = [610,619])&& movehit && var(55)=2 && random < 250
trigger3 = (stateno = [640,649])&& movehit && var(55)=2 && random < 750
;=======================================================================
[State -1, AI Penance Stare]
type=ChangeState
value=3400
triggerall=AILevel && numenemy && RoundState=2 && StateType != A &&var(20)<=0&& power >= 3000 && random < (500 * (AIlevel ** 2 / 64.0))
triggerall=(p2stateno != [150, 155]) && (enemynear,statetype != L) && !(enemynear, hitfall)&&(enemynear,stateno!=[5100,5220]) &&(p2bodydist x =[5,60]) && (p2bodydist y =[-70,5]) &&(enemynear, statetype != A)&&(enemynear, statetype != C)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)&&movehit
;----------------------------------------------------------------------
[State -1, AI Flame Mouth]
type=ChangeState
value=Ifelse(power>=2000 && random<=150,3350,3300)
triggerall=AILevel && numenemy && RoundState=2 && (stateno!=3300) && StateType != A && var(20)<=60 && power >= 1000 && random < (70 * (AIlevel ** 2 / 64.0))
triggerall=(enemynear,statetype != L) && (enemynear,statetype != C) && (enemynear,stateno!=[5100,5220]) 
triggerall=!Numhelper(3305) && (p2bodydist x =[45,220]) && (p2bodydist y=[-120,5]) && (enemynear,stateno!=[120,155])
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(6)|| var(7)
;----------------------------------------------------------------------
[State -1, AI MAX HellCycle]
type=ChangeState
value=3250
triggerall=AILevel && RoundState=2 && StateType != A
triggerall=(stateno!=3250) && var(20) <= 60 && power >= 2000
triggerall=numenemy && !numtarget(3150) && !var(0) && random < (200* (AIlevel ** 2 / 64.0))
triggerall=(p2stateno != [120, 155]) && (p2bodydist x =[30,250]) && (p2bodydist y =[-120,5]) 
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[10,12])|| StateNo=106 || (StateNo=[100,101])
trigger2=var(6)|| var(7)
;----------------------------------------------------------------------
[State -1, AI HellCycle]
type=ChangeState
value=3100
triggerall=AILevel && RoundState=2 && StateType != A
triggerall=var(20) <= 60 && power >= 1000||var(0)=1
triggerall=numenemy && (stateno!=[3200,3240]) && !numtarget(3100) && random < (150* (AIlevel ** 2 / 64.0))
triggerall=!(enemynear, hitfall) && p2statetype != A 
triggerall=(p2stateno != [120, 155]) && p2statetype != L &&(p2bodydist x =[30,250]) && (p2bodydist y =[-120,5]) 
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[10,12])|| StateNo=106 || (StateNo=[100,101])
trigger2=var(6)|| var(7)
;----------------------------------------------------------------------
[State -1, AI Combo Flame Whip Attack]
type=ChangeState
value=Ifelse(power>=2000 && random<=50,3150,3100)
triggerall=AILevel && numenemy && RoundState=2 && (stateno!=3100) && StateType != A && var(20)<=60 && power >= 1000 
triggerall=(enemynear,statetype != L) && (enemynear,stateno!=[5100,5220])&&(p2bodydist x =[-50,60])&&(p2bodydist y=[-70,5]) && !(enemynear, hitfall)
triggerall=(enemynear,movetype != A) && (enemynear,statetype != A) && !var(16)
trigger1=(ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])) && random < (150 * (AIlevel ** 2 / 64.0))
trigger2=(var(6)|| var(7)) && random < (300 * (AIlevel ** 2 / 64.0))
;--------------------------------------------------------------------
[State -1, AI MAX Flaming Skull]
type=ChangeState
value=3050
triggerall=AILevel && RoundState=2 && numenemy && Stateno!=3050 && StateType != A && !Numhelper(3055) && var(20) <= 60 && power >= 2000
triggerall=(p2bodydist x=[5,280]) && (p2bodydist y = [ -90, 5]) && !(enemynear,canrecover) && random < (50 * (AIlevel ** 2 / 64.0))
triggerall=enemynear,Statetype!=L && (enemynear,stateno!=[5120,5220]) && (enemynear,stateno!=[120,155])
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=(var(6)) && movehit && random<200
trigger3=(var(7)) && movehit && random<20
;----------------------------------------------------------------------
[State -1, AI Flaming Skull]
type=ChangeState
value=3000
triggerall=AILevel && RoundState=2 && numenemy && Stateno!=3000 && StateType != A && var(20) <= 60 && power >= 1000
triggerall=(p2bodydist x=[5,160]) && (p2bodydist y = [ -80, 5]) && !(enemynear,canrecover) && random < (100 * (AIlevel ** 2 / 64.0))
triggerall=enemynear,Statetype!=L && enemynear,Statetype!=C && enemynear,Statetype!=A && (enemynear,stateno!=[5120,5220]) && (enemynear,stateno!=[120,155])
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=(var(6)) && movehit && random<200
trigger3=(var(7)) && movehit && random<20
;=======================================================================
[State -1, AI Fire Pillar]
type=ChangeState
value=Ifelse(power>=1500 && random<=50,1650,1600)
triggerall=AILevel && numenemy && RoundState=2 && StateType != A && Ifelse(!var(20),!Numhelper(1605),Numhelper(1605)<5) && random < (100 * (AIlevel ** 2 / 64.0))
triggerall=(enemynear,stateno!=[5120,5220]) && (enemynear,stateno!=[120,155]) && (var(15)<4||var(20)) 
triggerall=(p2bodydist x=[45,225]) && (enemynear,vel y=0||(p2bodydist y=[-320,-60])) 
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,103])
trigger2=var(5)
;-------------------------------------------------------------------------
[State -1, AI Flaming Charge]
type=ChangeState
value=Ifelse((var(20) <= 60 && power >= 500 && random < 300), 1550, 1500)
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=AILevel && numenemy && RoundState=2 && StateType != A && random < (150 * (var(59) ** 2 / 64.0))
triggerall=(enemynear,statetype != L)&&(enemynear,stateno!=[5100,5220])&&(enemynear,stateno!=[120,155])
triggerall=(p2bodydist x =[80,200])&&(p2bodydist y=[-80,5])&&(enemynear,statetype!=A)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
;-------------------------------------------------------------------------
[State -1, AI Flame Breath]
type=ChangeState
value=Ifelse((var(20) <= 60 && power >= 500 && random < 100), 1450, 1400)
triggerall=!var(58)||(var(58)&&sysfvar(4)=0)
triggerall=AILevel && numenemy
triggerall=RoundState=2 && StateType != A &&var(20)<=60&& random < (150 * (var(59) ** 2 / 64.0))
triggerall=(p2stateno != [120, 155]) && (enemynear,statetype != L) && !(enemynear, hitfall)&&(enemynear,stateno!=[5100,5220]) &&(p2bodydist x =[10,80]) && (p2bodydist y =[-90,5]) &&(enemynear, statetype != A)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
;-------------------------------------------------------------------------
[State -1, AI Flame Whip]
type=ChangeState
value=Ifelse((power >= 500 && !Numtarget(1350) && random < 150), 1350, 1300)
triggerall=AILevel && numenemy && RoundState=2 && StateType != A && var(20)<=60 && random < (150 * (AIlevel ** 2 / 64.0))
triggerall=(enemynear,statetype != L) && (enemynear,statetype != A) && (enemynear,stateno!=[5100,5220]) && (var(13)||(p2bodydist x =[10,80])) && (p2bodydist y =[-80,5]) && enemynear, vel x >= 0 
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
;-------------------------------------------------------------------------
[State -1, AI Air Flame Whip]
type=ChangeState
value=Ifelse(power>=500 && ((enemynear,statetype=L) || random<100),1250,1200)
triggerall=AILevel && numenemy && RoundState=2 
triggerall=StateType=A && Pos y<=-20 
triggerall=(enemynear,stateno!=[5120,5220]) && random < (200 * (AIlevel ** 2 / 64.0))
triggerall=(enemynear,stateno!=[120,155]) && (p2bodydist x=[10,85]) && (p2bodydist y=[-60,205])
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5) && movehit
;-------------------------------------------------------------------------
[State -1, AI Flaming Uppercut]
type=ChangeState
value=Ifelse((power >= 500 && random < 200), 1150, 1100)
triggerall=AILevel && numenemy && RoundState=2 && StateType != A && random < (300 * (AIlevel ** 2 / 64.0))
triggerall=(enemynear,statetype!=L)&&(enemynear,stateno!=[5100,5220])&&(enemynear,stateno!=[120,155])
triggerall=(p2bodydist x =[20,75])&&(p2bodydist y=[-110,5])&&(enemynear,statetype!=C)
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)
;-------------------------------------------------------------------------
[State -1, AI Fire Ball]
type=ChangeState
value=Ifelse((power >= 500 && random < 100), 1050, 1000)
triggerall=AILevel && numenemy && RoundState=2 && StateType != A &&(enemynear,statetype!=A) && random < (70 * (AIlevel ** 2 / 64.0))
triggerall=Ifelse(!var(20),!Numhelper(1005),Numhelper(1005)<5)
triggerall=(enemynear,statetype!=L)&&(enemynear,stateno!=[5100,5220])&&(enemynear,stateno!=[120,155])&&(p2bodydist x >=50)&&(p2bodydist y=[-80,5])
trigger1=ctrl || StateNo=40 || StateNo=52 || (StateNo=[100,101])
trigger2=var(5)