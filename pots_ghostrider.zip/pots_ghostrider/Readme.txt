==================| Ghost Rider (Johnny Blaze) by ZoneSeven |==================|

 - Customized version of Marvel's Ghost Rider (Johnny Blaze) character
 - For MUGEN 1.0 and above

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks
 
 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

-IF YOU DON'T WANT CHAIN COMBOS GO TO THE CONFIG AND CHANGE THE VALUE UNDER VAR 55
TO 0 AND SAVE.Turning off the chain combos will give the character more of a 
cvs-ish type damage for normal attacks. 


<THROWS>

.Throwing the opponent              F/B + 2p+2k                   (near opponent)


<UNIQUE MOVES>

.-


<SPECIAL MOVES>

.Fire Ball (EX)                     D, DF, F, p
.Flaming Uppercut (EX)              F, D, DF, p
.Air Flame Whip (EX)                D, DF, F, p                   (Air)
.Flame Whip (EX)                    D, DB, B, p
.Flame Breath (EX)                  D, DF, F, k
.Flaming Charge (EX)                F, D, DF, k
.Fire Pillar (EX)                   D, DB, B, k


<SUPER MOVES>

 <LEVEL 1>

.Flaming Skull (MAX)                D, DF, F, D, DF, F, p
.Combo Flame Whip Attack (MAX)      D, DB, B, D, DB, B, p
.HellCycle (MAX)                    D, DF, F, D, DF, F, k
.Flame Mouth (MAX)                  D, DB, B, D, DB, B, k

 <LEVEL 3>

.Penance Stare                      D, DF, F, D, DF, F, p+k



=====<System>=====

.Forward Dash                       F, F
  .Run                               -> hold
.Backward Dash                      B, B
.Low Jump                           tap U
.High Jump                          tap D, U
.Long Low Jump                      tap D, tap U            
.Sidestep                           x + a
  .Sidestep Attack                   -> p / k
.Forward Roll                       F + x + a
.Backward Roll                      B + x + a
.Parry High                         tap F
.Parry Low                          tap D
.Air Parry                          tap F                         (Air)
.Power Charge                       hold y + b
.Guard Cancel Roll                  F/B + a + x                   (during standing or crouching guard) (1 power bar)
.Zero Counter (New Input)           F + 2p / 2k                   (during standing or crouching guard) (1 power bar)
.Zero Counter (Classic Input)       B, DB, D + p / k              (during standing or crouching guard) (1 power bar)
.Custom Combo                       z + c                         (Air also) (1 power bar)
.Fall Recovery                      2p / 2k / a + x               (while falling and allowed)



=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Normal Attacks are able to chain into other normal attacks.
 - Normal attacks can be canceled into Command, Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into other Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage


CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start



=====<Credits>=====

[Marvel]
 The original character

[Dark Rider]
  The original sprites and animation

[Gus Saint]
  Created a CVS palette and Small Portraits

[Sennou Room]
[R@CE AKIR@]
[GoldEX]
[Infinite]
[Mallboro Games]
[DivineWolf]
  Coding base for add-ons

=====<Disclaimer>=====

 - Ghost Rider is property of Marvel
 - Capcom vs SNK is property of Capcom
 - This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes