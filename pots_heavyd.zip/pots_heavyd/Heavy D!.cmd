;-| Button Remapping |-----------------------------------------------------
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s
;-| Default Values |-------------------------------------------------------
[Defaults]
command.time = 15
command.buffer.time = 1

;-| Super Motions |--------------------------------------------------------
[Command]
name = "D.Crazy"
command = ~D, B, D, F, x
time = 32

[Command]
name = "D.Crazy"
command = ~D, B, D, F, y
time = 32

[Command]
name = "D.Crazy"
command = ~D, B, D, F, z
time = 32
;==========================
[Command]
name = "MaxD.Crazy"
command = ~D, B, D, F, x+y
time = 32

[Command]
name = "MaxD.Crazy"
command = ~D, B, D, F, y+z
time = 32


[Command]
name = "MaxD.Crazy"
command = ~D, B, D, F, x+z
time = 32
;=============================
[Command]
name = "D.Magnum"
command = ~D, DF, F, D, DF, x
time = 32

[Command]
name = "D.Magnum"
command = ~D, DF, F, D, DF, ~x
time = 32

[Command]
name = "D.Magnum"
command = ~D, DF, F, D, DF, y
time = 32

[Command]
name = "D.Magnum"
command = ~D, DF, F, D, DF, ~y
time = 32

[Command]
name = "D.Magnum"
command = ~D, DF, F, D, DF, z
time = 32

[Command]
name = "D.Magnum"
command = ~D, DF, F, D, DF, ~z
time = 32

[Command]
name = "MaxD.Magnum"
command = ~D, DF, F, D, DF, x+y
time = 32

[Command]
name = "MaxD.Magnum"
command = ~D, DF, F, D, DF, y+z
time = 32

[Command]
name = "MaxD.Magnum"
command = ~D, DF, F, D, DF, x+z
time = 32

[Command]
name = "D.Medley"
command = ~D, DB, B, D, DB, x+y
time = 32

[Command]
name = "D.Medley"
command = ~D, DB, B, D, DB, y+z
time = 32

[Command]
name = "D.Medley"
command = ~D, DB, B, D, DB, x+z
time = 32

[Command]
name = "D.End"
command = ~D, DB, B, D, DB, b+y
time = 32

;-| Special Motions |------------------------------------------------------
[Command]
name = "LRSD"
command = D, DF, F, x
time = 15

[Command]
name = "MRSD"
command = ~D, DF, F, y
time = 15

[Command]
name = "MRSD"
command = ~D, DF, F, ~y
time = 15

[Command]
name = "SRSD"
command = ~D, DF, F, z
time = 15

[Command]
name = "SRSD"
command = ~D, DF, F, ~z
time = 15

[Command]
name = "EXRSD"
command = ~D, DF, F, x+y
time = 15

[Command]
name = "EXRSD"
command = ~D, DF, F, y+z
time = 15

[Command]
name = "EXRSD"
command = ~D, DF, F, x+z
time = 15

[Command]
name = "LDB"
command = ~F, D, DF, x
time = 16

[Command]
name = "LDB"
command = ~F, D, DF, ~x
time = 16

[Command]
name = "MDB"
command = ~F, D, DF, y
time = 16

[Command]
name = "MDB"
command = ~F, D, DF, ~y
time = 16

[Command]
name = "SDB"
command = ~F, D, DF, z
time = 16

[Command]
name = "SDB"
command = ~F, D, DF, ~z
time = 16

[Command]
name = "EXDB"
command = ~F, D, DF, x+y
time = 16

[Command]
name = "EXDB"
command = ~F, D, DF, y+z
time = 16

[Command]
name = "EXDB"
command = ~F, D, DF, x+z
time = 16

[Command]
name = "DCL"
command = ~D, DB, B, x
time = 15

[Command]
name = "DCL"
command = ~D, DB, B, ~x
time = 15

[Command]
name = "DCO"
command = ~D, DB, B, x
time = 15

[Command]
name = "DCO"
command = ~D, DB, B, ~x
time = 15

[Command]
name = "EXDCO"
command = ~D, DB, B, x
time = 15

[Command]
name = "EXDCO"
command = ~D, DB, B, ~x
time = 15

[Command]
name = "EXDCS"
command = ~D, DB, B, y
time = 15

[Command]
name = "EXDCS"
command = ~D, DB, B, ~y
time = 15

[Command]
name = "DCS"
command = ~D, DB, B, y
time = 15

[Command]
name = "DCS"
command = ~D, DB, B, ~y
time = 15

[Command]
name = "MDC"
command = ~D, DB, B, y
time = 15

[Command]
name = "MDC"
command = ~D, DB, B, ~y
time = 15

[Command]
name = "EXDCH"
command = ~D, DB, B, z
time = 15

[Command]
name = "EXDCH"
command = ~D, DB, B, ~z
time = 15


[Command]
name = "DCH"
command = ~D, DB, B, z
time = 15

[Command]
name = "DCH"
command = ~D, DB, B, ~z
time = 15

[Command]
name = "HDC"
command = ~D, DB, B, z
time = 15

[Command]
name = "HDC"
command = ~D, DB, B, ~z
time = 15

[Command]
name = "EXDC"
command = ~D, DB, B, x+y
time = 15

[Command]
name = "EXDC"
command = ~D, DB, B, y+z
time = 15

[Command]
name = "EXDC"
command = ~D, DB, B, x+z
time = 15

[Command]
name = "WBU"
command = ~D, DF, F, a
time = 15

[Command]
name = "WBU"
command = ~D, DF, F, ~a
time = 15

[Command]
name = "MBU"
command = ~D, DF, F, b
time = 15

[Command]
name = "MBU"
command = ~D, DF, F, ~b
time = 15

[Command]
name = "SBU"
command = ~D, DF, F, c
time = 15

[Command]
name = "SBU"
command = ~D, DF, F, ~c
time = 15

[Command]
name = "EXBU"
command = ~D, DF, F, a+b
time = 15

[Command]
name = "EXBU"
command = ~D, DF, F, b+c
time = 15

[Command]
name = "EXBU"
command = ~D, DF, F, a+c
time = 15

[Command]
name = "WSF"
command = ~D, DB, B, a
time = 15

[Command]
name = "WSF"
command = ~D, DB, B, ~a
time = 15

[Command]
name = "MSF"
command = ~D, DB, B, ~b
time = 15

[Command]
name = "MSF"
command = ~D, DB, B, b
time = 15

[Command]
name = "SSF"
command = ~D, DB, B, ~c
time = 15

[Command]
name = "SSF"
command = ~D, DB, B, c
time = 15


[Command]
name = "EXSF"
command = ~D, DB, B, a+b
time = 15


[Command]
name = "EXSF"
command = ~D, DB, B, a+c
time = 15


[Command]
name = "EXSF"
command = ~D, DB, B, b+c
time = 15


[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, z
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~z
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, b
time = 16

[Command]
name=  "412k" ;Zero Counter
command = ~B, DB, D, c
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~b
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~c
time = 16

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1

[Command]
name = "recovery"
command = y+z
time = 1

[Command]
name = "recovery"
command = x+z
time = 1

[Command]
name = "recovery"
command = a+x
time = 1

[Command]
name = "pp"
command = x+y
time = 1

[Command]
name = "pp"
command = x+z
time = 1

[Command]
name = "pp"
command = y+z
time = 1

[Command]
name = "kk"
command = a+b
time = 1

[Command]
name = "kk"
command = a+c
time = 1

[Command]
name = "kk"
command = b+c
time = 1

[Command]
name = "a+x"
command = a+x
time=1

[Command]
name = "b+y"
command = b+y
time = 1

[Command]
name = "c+z"
command = c+z
time = 1

;-| Dir + Button |---------------------------------------------------------
[Command]
name = "back_x"
command = /$B,x
time = 1

[Command]
name = "back_y"
command = /$B,y
time = 1

[Command]
name = "back_z"
command = /$B,z
time = 1

[Command]
name = "down_x"
command = /$D,x
time = 1

[Command]
name = "down_y"
command = /$D,y
time = 1

[Command]
name = "down_z"
command = /$D,z
time = 1

[Command]
name = "fwd_x"
command = /$F,x
time = 1

[Command]
name = "fwd_y"
command = /$F,y
time = 1

[Command]
name = "fwd_z"
command = /$F,z
time = 1

[Command]
name = "up_x"
command = /$U,x
time = 1

[Command]
name = "up_y"
command = /$U,y
time = 1

[Command]
name = "up_z"
command = /$U,z
time = 1

[Command]
name = "back_a"
command = /$B,a
time = 1

[Command]
name = "back_b"
command = /$B,b
time = 1

[Command]
name = "back_c"
command = /$B,c
time = 1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

[Command]
name = "down_c"
command = /$D,c
time = 1

[Command]
name = "fwd_a"
command = /$F,a
time = 1

[Command]
name = "fwd_b"
command = /$F,b
time = 1

[Command]
name = "fwd_c"
command = /$F,c
time = 1

[Command]
name = "up_a"
command = /$U,a
time = 1

[Command]
name = "up_b"
command = /$U,b
time = 1

[Command]
name = "up_c"
command = /$U,c
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1

;-| Single Dir |------------------------------------------------------------
[Command]
name = "fwd" ;Required (do not remove)
command = $F
time = 1

[Command]
name = "downfwd"
command = $DF
time = 1

[Command]
name = "down" ;Required (do not remove)
command = $D
time = 1

[Command]
name = "downback"
command = $DB
time = 1

[Command]
name = "back" ;Required (do not remove)
command = $B
time = 1

[Command]
name = "upback"
command = $UB
time = 1

[Command]
name = "up" ;Required (do not remove)
command = $U
time = 1

[Command]
name = "upfwd"
command = $UF
time = 1

;-| Hold Button |--------------------------------------------------------------
[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_s"
command = /s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holdfwd" ;Required (do not remove)
command = /$F
time = 1

[Command]
name = "holddownfwd"
command = /$DF
time = 1

[Command]
name = "holddown" ;Required (do not remove)
command = /$D
time = 1

[Command]
name = "holddownback"
command = /$DB
time = 1

[Command]
name = "holdback" ;Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdupback"
command = /$UB
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holdupfwd"
command = /$UF
time = 1

;---------------------------------------------------------------------------
;Release Direction
[Command]
name = "rlsfwd"
command = ~$F
time = 1

[Command]
name = "rlsback"
command = ~$B
time = 1

[Command]
name = "rlsup"
command = ~$U
time = 1

[Command]
name = "rlsdown"
command = ~$D
time = 1

;--------------------------------------------------------------------------
;Release Button
[Command]
name = "rlsx"
command = ~x
time = 1

[Command]
name = "rlsy"
command = ~y
time = 1

[Command]
name = "rlsz"
command = ~z
time = 1

[Command]
name = "rlsa"
command = ~a
time = 1

[Command]
name = "rlsb"
command = ~b
time = 1

[Command]
name = "rlsc"
command = ~c
time = 1
;---------------------------------------------------------------------------
;Other
[Command]
name = "highjump"
command = $D, $U
time = 15
;---------------------------------------------------------------------------
[Statedef -1]

[State -1, Tick Fix]
type = CtrlSet
triggerall = !ctrl
trigger1 = (StateNo = 52 || StateNo = 101 || StateNo = 5120) && !AnimTime
trigger2 = (StateNo = [200,499]) && !AnimTime
trigger3 = (StateNo = [760,762]) && !AnimTime
trigger4 = StateNo = 810 && !AnimTime
trigger5 = (StateNo = 5001 || StateNo = 5011 || StateNo = 151 || StateNo = 153) && HitOver
trigger6 = (StateNo = [700,715]) && !AnimTime
value = 1

[State -1, CtrlSet For Helpers];special thanks to 20S
type = CtrlSet
trigger1 = IsHelper
value = 0

[State -1, Hit Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(13) = 1

[State -1, Juggle Count For Helpers];special thanks to 20S
type = ParentVarAdd
trigger1 = IsHelper
trigger1 = MoveHit = 1
trigger1 = !HitPauseTime 
trigger1 = !(HitDefAttr = SCA, AT)
var(15) = 1

;[State -1, ProjContact];special thanks to 20S
;type = VarSet
;trigger1 = IsHelper
;trigger1 = MoveContact = 1 && NumTarget
;var(18) = 1

;[State -1, Root ProjContact];special thanks to 20S
;type = ParentVarSet
;trigger1 = IsHelper
;trigger1 = MoveContact = 1 && NumTarget
;var(18) = 1
[State -1, D.End]
type = ChangeState
value = 4000
triggerall = command = "D.End"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 3000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)

[State -1, D,Medley]
type = ChangeState
value = 3100
triggerall = command = "D.Medley"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)

[State -1, MaxD.Magnum]
type = ChangeState
value = 3050
triggerall = command = "MaxD.Magnum"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)

[State -1, D.Magnum]
type = ChangeState
value = 3000
triggerall = command = "D.Magnum"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >=0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)

[State -1, MaxD.Crazy]
type = ChangeState
value = 2050
triggerall = command = "MaxD.Crazy"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 2000, power >= 1000)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6) || var(7)



[State -1, D.Crazy]
type = ChangeState
value = 2000
triggerall = command = "D.Crazy"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 1000, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(6)

[State -1, EX Dancing Beat]
type = ChangeState
value = 1120
triggerall = command = "EXDB"
triggerall = p2bodydist X < 70
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger2 = stateno = 200 && animelem = 3,>0
trigger3 = stateno = 210 && animelem = 2,>0
trigger4 = stateno = 220 && movecontact
trigger5 = stateno = 230 && animelem = 2,>0
trigger6 = stateno = 240 && animelem = 3,>0
trigger7 = stateno = 250 && movecontact
trigger8 = stateno = 400 && movecontact
trigger9 = stateno = 410 && animelem = 5,>0
trigger10= stateno = 420 && animelem = 3,>0
trigger11= stateno = 430 && animelem = 3,>0
trigger12= stateno = 440 && movecontact

[State -1, EXDC]
type = ChangeState
value = 1220
triggerall = command = "EXDC"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = StateNo = 250 && MoveContact && Time >=22

[State -1,EX Blast Upper]
type = ChangeState
value = 1430
triggerall = command = "EXBU"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = StateNo = 210 && MoveContact
trigger4 = StateNo = 240 && MoveContact
trigger5 = StateNo = 220 && MoveContact
trigger6 = StateNo = 250 && MoveContact

[State -1, EXRSD]
type = ChangeState
value = 1030
triggerall = command = "EXRSD"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = StateNo = 200 && MoveContact 
trigger4 = StateNo = 220 && MoveContact
trigger5 = StateNo = 250 && MoveContact && Time >=22
trigger6 = StateNo = 218 && MoveContact

[State -1, EXSF]
type = ChangeState
value = 1530
triggerall = command = "EXSF"
triggerall = RoundState = 2 && StateType != A
triggerall = ifelse(var(20) <= 0, power >= 500, power >= 0)
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = stateno = 1200 && movecontact



[State -1, Dancing Beat]
type = ChangeState
value = 1110
triggerall = command = "SDB"
triggerall = StateType != A
triggerall = enemy,stateno != [120,159]
triggerall = var(24) = 0
triggerall = enemy,statetype = S || enemy,statetype = C
trigger1 = ctrl 
triggerall = p2bodydist X < 70
trigger2 = stateno = 200 && animelem = 3,>0
trigger3 = stateno = 210 && animelem = 2,>0
trigger4 = stateno = 220 && movecontact
trigger5 = stateno = 230 && animelem = 2,>0
trigger6 = stateno = 240 && animelem = 3,>0
trigger7 = stateno = 250 && movecontact
trigger8 = stateno = 400 && movecontact
trigger9 = stateno = 410 && animelem = 5,>0
trigger10= stateno = 420 && animelem = 3,>0
trigger11= stateno = 430 && animelem = 3,>0
trigger12= stateno = 440 && movecontact

[State -1, Dancing Beat]
type = ChangeState
value = 1105
triggerall = var(24) = 0
triggerall = command = "MDB"
triggerall = statetype != A
triggerall = enemy,statetype = S || enemy,statetype = C
triggerall = P2dist X <=70
triggerall = enemy,stateno != [120,159]
trigger1 = ctrl
trigger2 = stateno = 200 && animelem = 3,>0
trigger3 = stateno = 210 && animelem = 2,>0
trigger4 = stateno = 220 && movecontact
trigger5 = stateno = 230 && animelem = 2,>0
trigger6 = stateno = 240 && animelem = 3,>0
trigger7 = stateno = 250 && movecontact
trigger8 = stateno = 400 && movecontact
trigger9 = stateno = 410 && animelem = 5,>0
trigger10= stateno = 420 && animelem = 3,>0
trigger11= stateno = 430 && animelem = 3,>0
trigger12= stateno = 440 && movecontact

[State -1, Dancing Beat]
type = ChangeState
value = 1100
triggerall = var(24) = 0
triggerall = command = "LDB"
triggerall = statetype != A
triggerall = enemy,statetype = S || enemy,statetype = C
triggerall = P2dist X <=70
triggerall = enemy,stateno != [120,159]
trigger1 = ctrl
trigger2 = stateno = 200 && animelem = 3,>0
trigger3 = stateno = 210 && animelem = 2,>0
trigger4 = stateno = 220 && movecontact
trigger5 = stateno = 230 && animelem = 2,>0
trigger6 = stateno = 240 && animelem = 3,>0
trigger7 = stateno = 250 && movecontact
trigger8 = stateno = 400 && movecontact
trigger9 = stateno = 410 && animelem = 5,>0
trigger10= stateno = 420 && animelem = 3,>0
trigger11= stateno = 430 && animelem = 3,>0
trigger12= stateno = 440 && movecontact

[State -1, Ducking Combination]
type = ChangeState
value = 1210
triggerall = command = "HDC"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State Ducking Combination]
type = ChangeState
value = 1205
triggerall = var(24) = 0
triggerall = command = "MDC"
triggerall = statetype != A
trigger1 = ctrl


[State Ducking Combination]
type = ChangeState
value = 1200
triggerall = var(24) = 0
triggerall = command = "DCL"
triggerall = statetype != A
trigger1 = ctrl
trigger2 = StateNo = 210 && MoveContact
trigger3 = StateNo = 240 && MoveContact
trigger4 = StateNo = 220 && MoveContact
trigger5 = StateNo = 250 && MoveContact && Time >=20
trigger6 = StateNo = 200 && MoveContact
trigger7 = StateNo = 230 && MoveContact
trigger8 = StateNo = 400 && MoveContact
trigger9 = StateNo = 410 && MoveContact
trigger10 = StateNo = 420 && MoveContact
trigger11 = StateNo = 430 && MoveContact
trigger12 = StateNo = 440 && MoveContact



[State -1, Blast Upper]
type = ChangeState
value = 1420
triggerall = command = "SBU"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger2 = StateNo = 210 && MoveContact
trigger3 = StateNo = 240 && MoveContact
trigger4 = StateNo = 220 && MoveContact
trigger5 = StateNo = 250 && MoveContact
trigger6 = StateNo = 1420 && MoveContact && Time >=10

[State -1, Blast Upper]
type = ChangeState
value = 1410
triggerall = command = "MBU"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger2 = StateNo = 210 && MoveContact
trigger3 = StateNo = 240 && MoveContact
trigger4 = StateNo = 220 && MoveContact
trigger5 = StateNo = 250 && MoveContact
trigger6 = StateNo = 1410 && MoveContact && Time >=10

[State -1, Blast Upper]
type = ChangeState
value = 1400
triggerall = command = "WBU"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger2 = StateNo = 210 && MoveContact
trigger3 = StateNo = 240 && MoveContact
trigger4 = StateNo = 1400 && MoveContact && Time >=10


[State -1, RSD]
type = ChangeState
value = 1020
triggerall = command = "SRSD"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = StateNo = 200 && MoveContact 
trigger4 = StateNo = 220 && MoveContact
trigger5 = StateNo = 250 && MoveContact && Time >=22
trigger6 = StateNo = 218 && MoveContact

[State -1, RSD]
type = ChangeState
value = 1010
triggerall = command = "MRSD"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = StateNo = 200 && MoveContact 
trigger4 = StateNo = 220 && MoveContact
trigger5 = StateNo = 250 && MoveContact&& Time >=22
trigger6 = StateNo = 218 && MoveContact

[State -1, RSD]
type = ChangeState
value = 1000
triggerall = command = "LRSD"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)
trigger3 = StateNo = 200 && MoveContact 
trigger4 = StateNo = 220 && MoveContact
trigger5 = StateNo = 250 && MoveContact && Time >=22
trigger6 = StateNo = 218 && MoveContact


[State -1, Soul Flower]
type = ChangeState
value = 1500
triggerall = command = "WSF"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Soul Flower]
type = ChangeState
value = 1510
triggerall = command = "MSF"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Soul Flower]
type = ChangeState
value = 1520
triggerall = command = "SSF"
triggerall = RoundState = 2 && StateType != A
trigger1 = ctrl || StateNo = 40 || StateNo = 52 || (StateNo = [100,101])
trigger2 = var(5)

[State -1, Zero Counter]
type = ChangeState
value = 750
trigger1 = StateNo = 150 || StateNo = 152
trigger1 = command = "412p" || command = "412k"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power >= 1000 && !var(20)

[State -1]
type = ChangeState
value = 900
triggerall = StateNo != 100
triggerall = statetype = S
triggerall = (p2statetype = S) || (p2statetype = C)
triggerall = p2movetype != H
triggerall = p2bodydist X < 8
triggerall = !var(59)
triggerall = ctrl = 1
trigger1 = command = "fwd_y"
trigger1 = p2bodydist X < 8
trigger2 = command = "fwd_b"
trigger2 = p2bodydist X < 8
trigger3 = command = "back_y"
trigger3 = p2bodydist X < 15
trigger4 = command = "back_b"
trigger4 = p2bodydist X < 15

[State -1, Roll Forward]
type = ChangeState
value = 710
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdfwd"

[State -1, Roll Back]
type = ChangeState
value = 715
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101])) && command = "holdback"

[State -1, Power Charge]
type = ChangeState
value = 730
trigger1 = command = "hold_b" && command = "hold_y"
trigger1 = RoundState = 2 && StateType != A
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (StateNo = [100,101])

[State -1, MAX Mode]
type = ChangeState
value = 770
triggerall = command = "c+z"
triggerall = RoundState = 2 && StateType != A
triggerall = var(20) <= 0 && Power >= 1000
trigger1 = ctrl || (Stateno = [100,101])

[State -1, Dodge]
type = ChangeState
value = 700
triggerall = command = "a+x"
triggerall = RoundState = 2 && StateType != A
trigger1 = (ctrl || (StateNo = [100,101]))

[State -1, Run Fwd]
type = ChangeState
value = 100
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

[State -1, Run Back]
type = ChangeState
value = 105
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;--------------------------------------------------------------------------
[State -1, Fwd+Strong Punch]
type = Changestate
value = 218
triggerall = command = "x" && command = "holdfwd"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = statetype = S
trigger1 = ctrl || (stateno=[100,101])
trigger2 = StateNo = 200 && MoveContact && Time >=4
trigger3 = StateNo = 210 && MoveContact && Time >=6
trigger4 = StateNo = 235 && MoveContact && Time >=4
trigger5 = StateNo = 230 && MoveContact && Time >=4
trigger6 = StateNo = 240 && MoveContact && Time >=12
trigger7 = StateNo = 400 && MoveContact && Time >=4
trigger8 = StateNo = 430 && MoveContact && Time >=4


[State -1, Stand Light Punch]
type = ChangeState
value = 200
triggerall = command = "x" 
triggerall = command != "holddown" 
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2 = StateNo = 200 && MoveContact && Time >=10
trigger3 = StateNo = 430 && MoveContact && Time >=5
 
[State -1, Stand Medium Punch]
type = ChangeState
value = 210 
triggerall = command = "y"
triggerall = command != "holddown"  
triggerall = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = StateNo = 200 && MoveContact && Time >=6
trigger3 = StateNo = 440 && MoveContact && Time >=10


[State -1, Stand Strong Punch]
type = ChangeState
value = 220 
triggerall = command = "z"
triggerall = command != "holddown" 
triggerall = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = StateNo = 218 && MoveContact && Time >=4

[State -1, Close Stand Light kick]
type = ChangeState
value = 235
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype = S
triggerall = p2bodydist X < 10
trigger1 = ctrl



[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])


[State -1, Stand Medium Kick]
type = ChangeState
value = 240
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2 = StateNo = 200 && MoveContact && Time >=5
trigger3 = StateNo = 430 && MoveContact && Time >=4

[State -1, Standing Strong Kick]
type = ChangeState
value = 250
triggerall = command = "c"
triggerall = command != "holddown"
trigger1 = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2 = StateNo = 218 && MoveContact && Time >=4


[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerAll = command = "holddown" && command = "x"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2= (StateNo = 200 || StateNo = 430) && Time >=10
trigger3 = StateNo = 400 && MoveContact && Time >=10

[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerAll = command = "holddown" && command = "y"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])


[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
triggerAll = command = "holddown" && command = "z"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])

[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerAll = command = "holddown" && command = "a"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2= (StateNo = 200 || StateNo = 400 || StateNo = 430) && Time >=10

[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerAll = command = "holddown" && command = "b"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])

[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerAll = command = "holddown" && command = "c"
triggerAll = StateType != A
trigger1 = ctrl || (StateNo = [100,101])

[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Medium Punch]
type = ChangeState
value = 610
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Punch]
type = ChangeState
value = 620
triggerall = command = "z"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerall = command = "a"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Medium Kick]
type = ChangeState
value = 640
triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerall = command = "c"
trigger1 = statetype = A
trigger1 = ctrl

[State -1, Taunt]
type = ChangeState
value = 195
triggerall = command = "s"
triggerall = StateType != A
triggerall = StateNo != [200,699]
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = var(5)