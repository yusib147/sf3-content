				 HEAVY D! By HAIRLINE733
___________________________________________________________ 1/20/17
Contact:	kingtwan1313@gmail.com
Customized version of SNK's Heavy D! character, for MUGEN 1.0


=====<Movelist>=====

 U - up          LP - light punch        LK - light kick
 D - down        MP - medium punch       MK - medium kick
 F - forward     HP - heavy punch        HK - heavy kick
 B - back        P - any punch           K - any kick
 s - start       2P- two punches         2K- two kicks
 
 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

<NORMAL>

.Unbreakable FWD		        F + P		(near opponent)
.Unbreakable BCK		        F + K		(near opponent)
.Overhead Punch                         F + LP          (Overhead, chain into HP,HK,RSD,Blast Upper)


<SPECIAL>

.RSD (EX)                       	D,DF,F+P 
.Dancing Beat (EX)	                F,D,DF+P 
.Ducking Combination (EX)	        D,DB,B+P 
.DC Followups
-Overhead (EX)                          D,DB,B+LP
-Sweep (EX)                             D,DB,B+MP
-Hook (EX)                              D,DB,B+HP
.Soul Flower (EX) 	                D,DB,B+K (Ex Version Hits Grounded Oppenent)
.Blast Upper (EX)	                D,DF,F+K 




<SUPERS>

.D.MAGNUM                        	D,DF,F,D,DF,F+P  POWER>=1000  
.D.CRAZY 	                        D,B,D,F+P        POWER>=1000


.Max D.MAGNUM                           D,DF,F,D,DF,F+2P POWER>=2000
.D.MEDLEY                	        D,DB,B,D,DB,B+2K POWER>=2000 
.Max D.CRAZY                            D,B,D,F+2P       POWER>=2000


.D.CATASTROPHE		                D,DB,B,D,DB,B+PK POWER>=3000



<SYSTEM>

.Run:          		        	F, F
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	LP + LK
.Forward Roll:                  	F + LP + LK
.Backward Roll:                 	B + LP + LK
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold MP + MK
.Zero Counter:                  	B, DB, D, P / K 	(during standing or crouching guard)
.MAX Mode:                       	HP + HK          	(Air also)
.Fall Recovery:                 	2P / 2K  	    	(while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
- he has a couple different combos, with his normals, i figured hes a boxer so he needs to throw punches in bunches!
- the overhead punch is the main setup for combos, but you can use other normals of course
- he can chain the close ducking combination and ex ducking combination but not the medium or far version

COMBOS:
-LP, MP, FWD+LP, HP, D.Medley
-LP, MP, FWD+LP, HK, Close Ducking combinaion
-LP, MP, FWD+LP, HK, EX Ducking Combinaion
-LP, MP, FWD+LP, HK, RSD, Any Super
-Crouch LP, LP, FWD+LP, HK, RSD, Any Super
-Crouch LK, MK, FWD+LP, HK, RSD, Any Super
-Jump HK, Crouch LK, MK, FWD+LP, HK, RSD, Any Super
-Jump HK, Crouch MK, MP, FWD+LP, HK, RSD, Any Super
-Crouch LK, FWD+Punch, HK, Close Ducking combination overhead, EX Soul Flower, D.Magnum
-(Corner) Jump HK, Crouch LK, MK, FWD+LP, HK, EX Dancing Beat, FWD+LP or HK, EX Soul Flower, D.Magnum

Of course you can mix and match these to your likings and probably find more!

MAX MODE:
 - Your attack and defense is increased while in MAX Mode
 - EX moves can be performed at no power cost, though take away from time sustained in MAX mode
 - All Lv1 supers can be performed at no power cost, though immediately uses up all time in MAX mode
 - All Lv2 and higher supers will cost 1 power bar, along with using up all time in MAX mode
 - Even without a power bar, as long as you have time left in MAX mode, you can perform Lv1 supers/EX moves
 - You can not Power Charge/gain power while in MAX mode
 - You can not perform a Zero Counter while in MAX Mode

Extra Notes:
Ive never actually played kof98 but mugen introduced me to him. after some time playing with him in full games and what not i decided F it i want him
in pots/divine/morph style. i tried to make him fun to play with as theres plenty comboability in there but not to much where he becomes broken. please 
let me know if there are bugs. this is my first character so i expect some.

Credit:
Divinewolf for the kfm template because without it i probably would've had a bad time lol.
Spazmaster for the hi res effects
Ahuron for some code in his heavy d!
Hades for coming thru with the super texts
snk for making this awesome dude originally
elecybyte for mugen period
everyone that helped me out answering questions so that i could move forward








=====<Disclaimer>=====

 - Heavy D! is property of SNK
 - King of the Fighters '98 was made by SNK 
 - Capcom Vs. SNK was made by Capcom
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes