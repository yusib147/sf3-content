             
======================| Malin by Night_Stalker/Laslab Games|=========================== [6/XX/2022]            

 - Customized version of Malin, for Mugen 1.0

------------------<Features>---------------------

 - All essential stuff
 - Gameplay mixed from several games, including CvS2, KOF, SFZ3, and SF3
 - Various palettes to choose from
 - Vans' "Tiny Buffering" System
 - Vans' Chizuru "Skill Lock" compatibility

-----------------<Movelist>----------------------

 U = Up
 D = Down
 F = Forward
 B = Back
 UF = Up Forward
 UB = Up Back
 DF = Down Forward
 DB = Down Back
 LP = Light Punch
 MP = Medium Punch
 HP = Heavy Punch
 LK = Light Kick
 MK = Medium Kick
 HK = Heavy Kick
 S = Start

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>

 Malin Rocket				F(or B) + any 2 punches (grab)
 Crimson Scorpion			F + MK
 Taunt					S					

<SPECIALS>

 Yellow Jacket (Terrestrial)(EX) 	D, DF, F, + any punch
 Yellow Jacket (Aerial)(EX)		F, D, DF, + any punch
 Yellow Jacket (Direction Change)	any direction + any 2 punches (in air or during Yellow Jacket (Terrestrial), up to 2 times)
 Demon Arachnid(Ex)			D, DB, B, + any punch
 Poison Scorpion(EX)			D, DF, F, + any kick

<SUPERS>

 Mayfly(MAX)		        	D, DF, F(x2), + any kick
 Queen Bee(MAX)		        	D, DF, F(x2), + any punch (while in air)
  
<LV3 SUPERS>

 Smashing Salamander			D, DF, F,(x2) + any 2 punches (while on ground)

<SYSTEM BUILD>

 -GROOVE GAUGE-

 (*)N + C + S Groove
  *Allows: MAX Mode			HP + HK (Requires 1 power bar)
           Max Cancelling
           Special Cancelling
           Super Cancelling
           EX Specials
	   Power Charge			Hold MK + MP

 -SYSTEM MECHANICS-

 Parry = O 				Tap F(or D), timed with incoming High/Air/Low attacks respectively.
 Just Defense = X
 Chain Combo = X
 Air Chain Combo = X
 Super Combo Cancel = O
 Cancel Any Move = X

 -SUB SYSTEM MECHANICS-

 Dash = X
 Run = O 				Tap F, F, then hold F
 Dodge = O 				LP + LK (While stationary, vulnerable to grabs)
 Dodge Attack = O 			Any punch or kick during Dodge
 Rolling = O 				F(or B) + LP + LK (Vulnerable to grabs)
 Small Jump = O 			Tap U
 Long Small Jump = O 	  		Tap D then U quickly
 Long Jump = O	        		D, then U
 Alpha Counter(Attack) = O		B, DB, D + any punch or kick while guarding an attack. (Requires 1 power bar)
 Safe Fall = O		    		Any 2 punches or LP + LK (While falling and allowed)
 Counter Movement = O			Tap F(or B) + LP + LK while guarding an attack. (Requires 1 power bar)
 Tactical Recovery = X
 Air Guard = O