                            ____________________________________________
===========================| Quicksilver by ZVitor & Emerie The G.O.A.T |===========================
                            ���������������������������������������������          [06.10.22]

 - Contact:	Jmorphman@gmail.com
 - Website:	http://network.mugenguild.com/jmorphman/

 - Customized version of Marvel's Quicksilver character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, including CvS2, Ultimate Marvel vs Capcom 3



=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>

.Shoulder Throw:                      	F/B + 2p   (near opponent)
.Knees to face:                   	F/B + 2k   (near opponent)


<SPECIAL>

.Tornado (EX):             		B, DB, D, DF, F, p
.Sivler Punch (EX):                  	B, DB, D, DF, F, k
.Sivlersault (EX):         	   	F, D, DF, k
.Sivler Heel (EX):                 	D, DB, B, k
.Sivler Punches (EX):                   p, p, p, p
    .Sivler Fist:                	D, DF, F, x / y   
    .Sivler Uppercut:               	D, DF, F, z   


<SUPER>

.Super Tornado (MAX):                	D, DF, F, D, DF, F, p
.Silver Assault (MAX):  		D, DF, F, DF, D, DB, B, p
.Super Sivlersault (MAX):               D, DF, F, UF, k 		(hold to delay)


<LV3 SUPER>

.Double Tornado:                  	D, DB, B, D, DB, B, p


<SYSTEM>

.Forward Dash:                    	F, F
   .Run:                           	hold
.Backward Dash:                    	B, B
.Low Jump:                         	tap U
.High Jump:                        	tap D, U
.Long Low Jump:                    	tap D, tap U            
.Sidestep:                         	a + x
   .Sidestep Attack:               	p / k
.Forward Roll:                     	F + a + x
.Backward Roll:                    	B + a + x
.Parry High:                       	tap F
.Parry Low:                        	tap D
.Air Parry:                        	tap F           		(Air)
.Power Charge:                     	hold b+y
.Zero Counter:                     	B, DB, D, p / k 		(during standing or crouching guard)
.Custom Combo:                     	c + z           		(Air also)
.Fall Recovery:                    	2p / a + x      		(while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage


CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing
   faster and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start