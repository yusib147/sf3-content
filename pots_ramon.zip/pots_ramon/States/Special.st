;==================<Zmugens is the creator of this character>============
[Statedef 1000]
type    = S
movetype= A
physics = S
velset = 0,0
ctrl = 0
anim = 1000
poweradd=72*!var(20)
sprpriority = 2
juggle = 14


[State 1300]
type = NotHitBy
trigger1 = AnimElem = 12, < 0
value = SCA
time = 1


[State 1070]
type = varset
trigger1 = time = 0
var(19) = 0

[State 1000]
type = posadd
trigger1 = animelem = 5
trigger2 = animelem = 9
x = 10

[State 1000]
type = posadd
trigger1 = animelem = 15
x = 5

[State 0]
type = HitDef
trigger1 = AnimElem = 12
trigger1 = enemy,movetype = A;stateno =[1000,4999]
attr = S, SA
damage = 50,10
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
animtype = hard
guardflag = MA
hitflag = MAF
priority = 5, Hit
pausetime = 6,6
ground.type = High
ground.slidetime = 12
ground.hittime  = 16
ground.velocity = -3,-4
guard.slidetime = 10;떷궚뵿귡렄듩
guard.hittime = 10;떷궚뵿귟뭷궻렄듩
guard.velocity = -10
airguard.velocity = -3,-4
air.type = high
air.velocity = -3,-5
air.hittime = 16
ground.cornerpush.veloff = -6
guard.cornerpush.veloff = -10
down.cornerpush.veloff = -10
fall.recover=0
fall=1
p2stateno=7025
p2facing=1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 0]
type = HitDef
trigger1 = AnimElem = 12
trigger1 = enemy,movetype != A; !=[1000,4999]
attr = S, SA
damage = 50,10
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
animtype = hard
guardflag = MA
hitflag = MAF
priority = 5, Hit
pausetime = 10,10
ground.type = High
ground.slidetime = 12
ground.hittime  = 16
ground.velocity = -4,-5
guard.slidetime = 10;떷궚뵿귡렄듩
guard.hittime = 10;떷궚뵿귟뭷궻렄듩
guard.velocity = -10
airguard.velocity = -3,-4
air.type = high
air.velocity = -3,-5
air.hittime = 16
ground.cornerpush.veloff = -6
guard.cornerpush.veloff = -10
down.cornerpush.veloff = -10
fall.recover=0
fall=1
;p2stateno=1020
p2facing=1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1000]
type = PlaySnd
trigger1 =animelem=10
value =1,5
channel=1

[State 1000]
type = PlaySnd
trigger1 =animelem=5
value =0,11
channel=0

[STate 1000];뭤뽋뤧똼
type=Explod
trigger1 = movehit
trigger1 = enemy,stateno = 1060
anim = 8102
pos=0,0
postype = p2
sprpriority=-3
ownpal=1
persistent = 0
scale = .5,.5

[State 1000]
type = PlaySnd
trigger1 = movehit
trigger1 = enemy,stateno = 1060
value = 820,1
channel=1

[State 1000]
type = TargetBind
trigger1 = Movehit
trigger1 = Numtarget
trigger1 = target,stateno = 1020 && target,animElem = 2
pos = 50,-60
persistent = 0

[State 1000]
type = ChangeState
triggerall = movehit && (enemy,stateno != [7025,7050])
triggerall = Animelem = 12,>=0
triggerall = animelem = 14,<=0
trigger1 = !var(59)
trigger1 = command = "holdfwd" && command = "a" || command = "holdfwd" && command = "b" || command = "holdfwd" && command = "c"
trigger2 = var(1) && random <= 888
trigger3 = var(59) && Random <= var(59)*100 && Enemy,alive
value = 1030

[State 1000]
type = ChangeState
triggerall = movehit && (enemy,stateno = [7025,7050])
triggerall = Animelem = 12,>=0
triggerall = animelem = 14,<=0
trigger1 = !var(59) 	;AI뾭
trigger1 = command = "holdfwd" && command = "a" || command = "holdfwd" && command = "b" || command = "holdfwd" && command = "c"
trigger2 = var(1) && random <= 888
trigger3 = var(59) && Random <= var(59)*100
value = 1031

[State 1000]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1
;---------------------------------------------------------------------------

[Statedef 1001]
type=S
physics=S
movetype=A
ctrl=0
velset=0,0
sprpriority=1
poweradd=-500
facep2=1

[State 1050, MAX Timer Drain]
type = VarAdd
trigger1 = !Time
trigger1 = var(53) > 0
var(53) = -500

[State 1050, Anim]
type=changeanim
trigger1=!time
value=1001

[State 1050,Posset]
type=posset
trigger1=!time
y=0

[State 1050, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1050, Custom Combo Juggle Points Reset]
type = varset
trigger1 = !time && var(20)
var(15) = 0
ignorehitpause = 1

[State 1050, CC Reset]
type = palfx
trigger1 = !time
trigger1 = var(20) := -1
time = 1

[State 1050, ExFX]
type = varset
trigger1 = !time
var(25) = 44

[State 1050, ExFX]
type = explod
trigger1 = !time
anim = 8210
sprpriority = 3
postype = p1
pos = -31, -86
scale = 0.5, 0.5
pausemovetime = -1
supermovetime = -1
ownpal = 1

[State 1050, ExFX]
type = playsnd
trigger1 = !time
value = 0, 1000
channel = 1

[State 1070]
type = varset
trigger1 = time = 0
var(19) = 0

[State 1000]
type = posadd
trigger1 = animelem = 5
trigger2 = animelem = 9
x = 12

[State 1000]
type = posadd
trigger1 = animelem = 15
x = 5

[State 1300]
type = NotHitBy
trigger1 = AnimElem = 12, < 0
value = SCA
time = 1


[State 0]
type = HitDef
trigger1 = AnimElem = 12
trigger1 = enemy,movetype = A;enemy,stateno =[1000,4999]
attr = A, SA
damage = 69,10
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
animtype = hard
guardflag = HA
hitflag = MAF
priority = 5, Hit
pausetime = 6,6
ground.type = High
ground.slidetime = 12
ground.hittime  = 16
ground.velocity = -3,-4
guard.slidetime = 10;떷궚뵿귡렄듩
guard.hittime = 10;떷궚뵿귟뭷궻렄듩
guard.velocity = -10
airguard.velocity = -3,-4
air.type = high
air.velocity = -3,-5
air.hittime = 16
ground.cornerpush.veloff = -6
guard.cornerpush.veloff = -10
down.cornerpush.veloff = -10
fall.recover=0
fall=1
p2stateno=7025
p2facing=1
p2facing=1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 0]
type = HitDef
trigger1 = AnimElem = 12
trigger1 = enemy,movetype != A;enemy,stateno !=[1000,4999]
attr = S, SA
damage = 69,10
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
animtype = hard
guardflag = HA
hitflag = MAF
priority = 5, Hit
pausetime = 10,10
ground.type = High
ground.slidetime = 12
ground.hittime  = 16
ground.velocity = -4,-5
guard.slidetime = 10;떷궚뵿귡렄듩
guard.hittime = 10;떷궚뵿귟뭷궻렄듩
guard.velocity = -10
airguard.velocity = -3,-4
air.type = high
air.velocity = -3,-5
air.hittime = 16
ground.cornerpush.veloff = -6
guard.cornerpush.veloff = -10
down.cornerpush.veloff = -10

fall.recover=0
fall=1
;p2stateno=1020
p2facing=1
p2facing=1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48


[State 1000]
type = TargetBind
trigger1 = Movehit
trigger1 = Numtarget
trigger1 = target,stateno = 1020 && target,animElem = 2
pos = 50,-60
persistent = 0

[State 1000]
type = PlaySnd
trigger1 =animelem=10
value =1,5
channel=1

[State 1000]
type = PlaySnd
trigger1 =animelem=5
value =0,11
channel=0


[STate 1000];뭤뽋뤧똼
type=Explod
trigger1 = movehit
trigger1 = enemy,stateno = 1060
anim = 8102
pos=0,0
postype = p2
sprpriority=-3
ownpal=1
persistent = 0
scale = .5,.5

[State 1000]
type = PlaySnd
trigger1 = movehit
trigger1 = enemy,stateno = 1060
value = 820,1
channel=1

[State 1000]
type = ChangeState
triggerall = movehit && (enemy,stateno != [7025,7050])
triggerall = Animelem = 12,>=0
triggerall = animelem = 14,<=0
trigger1 = !var(59) 
trigger1 = command = "holdfwd" && command = "a" || command = "holdfwd" && command = "b" || command = "holdfwd" && command = "c"
trigger2 = var(1) && random <= 888
trigger3 = var(59) && Random <= var(59)*100 && Enemy,Alive
value = 1030

[State 1000]
type = ChangeState
triggerall = movehit && (enemy,stateno = [7025,7050])
triggerall = Animelem = 12,>=0
triggerall = animelem = 14,<=0
trigger1 = !var(59) 
trigger1 = command = "holdfwd" && command = "a" || command = "holdfwd" && command = "b" || command = "holdfwd" && command = "c"
trigger2 = var(1) && random <= 888
trigger3 = var(59) && Random <= var(59)*100 && Enemy,Alive
value = 1031

[State 1001]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------

[Statedef 1020]
type    = A
movetype= H
physics = N
poweradd= 80
ctrl = 0
sprpriority = -2
velset=0,0

[State 1020]
type = changeanim2
trigger1 = time=0
value = 1020

[State 1020]
type = velset
trigger1 = animelem=2
x=-4
y=-4

[State 1020]
type = veladd
trigger1 = animelem=2,>=0
y=.4

[State 1020]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
value = 1060
;---------------------------------------------------------------------------

[Statedef 1040]
type    = L
movetype= H
physics = S
poweradd= 0
ctrl = 0
sprpriority = -2
velset=-9,0

[State 1040]
type = changeanim2
trigger1 = time=0
value = 1040

[State 1040]
type = posset
trigger1 = time=0
y=0

[State 1040]
type = makedust
trigger1 = time <= 10
pos = -20,0
spacing = 1

[State 1040]
type = selfstate
trigger1 = alive = 0
trigger1 = animtime=0
value = 5150

[State 1040]
type = selfstate
trigger1 = alive
trigger1 = animtime=0
value = 5120

;---------------------------------------------------------------------------

[Statedef 1060]
type    = L
movetype= H
physics = N
poweradd= 0
ctrl = 0
sprpriority = -2
velset=0,0

[State 1040]
type = posset
trigger1 = time=0
y=0

[State 1020]
type = changeanim2
trigger1 = time=0
value = 1060

[State 1020]
type = velset
trigger1 = animelem=2
x=-2.5
y=-3

[State 1020]
type = veladd
trigger1 = animelem=2,>=0
y=.4

[State 1020]
type = selfstate
trigger1 = pos Y>=0 && vel Y>0
value = 5110

;---------------------------------------------------------------------------
;
[Statedef 1030]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1030
poweradd = 0
sprpriority = 2
juggle = 0

[State 1030]
type = TargetBind
trigger1 = Numtarget
trigger1 = target,stateno = 1020 && target,animElem = 2
pos = 50,-60
persistent = 0

[State 1030]
type = varset
trigger1 = time = 0
var(19) = 0

[State 200, 1]
type = HitDef
trigger1 = AnimElem = 10
attr = A, SA
damage = 50
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
animtype = hard
guardflag =
hitflag = MAFD
priority = 5, Hit
pausetime = 8,10
ground.type = High
ground.slidetime = 12
ground.hittime  = 16
ground.velocity = -3,-4
airguard.velocity = -3,-4
air.type = high
air.velocity = -3,-5
air.hittime = 16
getpower=120,60
fall.recover=0
fall=1
p2facing=1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-40
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48


[State 1030]
type = velset
trigger1 = animelem = 7
x = 6
y = -5

[State 1030]
type = veladd
trigger1 = animelem = 7,>=0
y = .4

[State 1000]
type = PlaySnd
trigger1 =animelem=7
value =1,22
channel=1

[State 1030]
type = varset
trigger1 = !var(59) ;AI뾭
trigger1 = command = "x"
trigger2 = command = "holdfwd" && command = "a" || command = "holdfwd" && command = "b" || command = "holdfwd" && command = "c"
var(19) = 1

[State 1000]
type = ChangeState
triggerall = movehit
triggerall = pos Y >= 20 && vel Y>0
trigger1 = var(19) = 1
trigger2 = var(1) && random <= 777
trigger3 = var(59) && Random <= var(59)*100 && Enemy,Alive
value = 1070

[State 1001]
type = ChangeState
trigger1 = pos Y >= 20 && vel Y>0
value = 1035
;---------------------------------------------------------------------------
;
[Statedef 1031]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1030
poweradd = 0
sprpriority = 2
juggle = 0

[State 1030]
type = varset
trigger1 = time = 0
var(19) = 0

[State 200, 1]
type = HitDef
trigger1 = AnimElem = 10
attr = A, SA
damage = 50
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
animtype = digup
guardflag =
hitflag = MAFD
priority = 5, Hit
pausetime = 8,10
ground.type = High
ground.slidetime = 12
ground.hittime  = 16
ground.velocity = -3,-4
airguard.velocity = -3,-4
air.type = high
air.velocity = -4,-6
air.hittime = 16
fall.recover=0
fall=1
p2facing=1
p1stateno = 1570
p2stateno =1580
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-40
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1030]
type = velset
trigger1 = animelem = 7
x = 4.6
y = -8.5

[State 1030]
type = veladd
trigger1 = animelem = 7,>=0
y = .4

[State 1000]
type = PlaySnd
trigger1 =animelem=7
value =1,22
channel=1

[State 1001]
type = ChangeState
trigger1 = pos Y >= 20 && vel Y>0
value = 1035

;======================================
;
[Statedef 1035]
type    = S
movetype= I
physics = S
velset = 0,0
ctrl = 0
anim = 1140
sprpriority = 2
poweradd=0

[State 1035]
type = posset
trigger1 = time=0
y=0

[State 1035]
type = turn
trigger1 = time=0

[STate 1035]
type=Explod
trigger1=animelem=1
anim=8102
ownpal=1
pos=0,0
postype=p1
sprpriority=-3
scale = .5,.5

[State 1035]
type = playsnd
trigger1 = animelem = 1
value =1,2

[State 1035]
type = changestate
trigger1 = animtime=0
value = 0
ctrl=1

;---------------------------------------------------------------------------
;
[Statedef 1070]
type    = S
movetype= A
physics = S
velset = 0,0
ctrl = 0
anim = 1070
poweradd = 0
sprpriority = 2
juggle = 0

[State 1070]
type = posset
trigger1 = time = 0
y = 0

[State 1070]
type = posadd
trigger1 = time = 0
trigger1 = frontedgebodydist <= 40
x = -50

[State 1070]
type = targetstate
trigger1 = time = 0
value = 1080

[State 1070]
type = targetbind
trigger1 = animelem=1
pos = 30,0

[State 1070]
type = targetbind
trigger1 = animelem=2
pos = 30,0

[State 1070]
type = targetbind
trigger1 = animelem=3
pos = 25,-15

[State 1070]
type = targetbind
trigger1 = animelem=5
pos = 25,-7

[State 1070]
type = targetbind
trigger1 = animelem=6
pos = 25,-40

[State 1070]
type = targetbind
trigger1 = animelem=7
pos = 15,-45

[State 1070]
type = targetbind
trigger1 = animelem=8
pos = 15,-70

[State 1070]
type = targetbind
trigger1 = animelem=9
pos = 20,-70

[State 1070]
type = targetbind
trigger1 = animelem=10
pos = 30,-70

[State 1070]
type = targetbind
trigger1 = animelem=11
pos = 35,0

[State 1070]
type = varset
trigger1 = time = 0
var(19) = 0

[State 1070]
type = HitDef
trigger1 = AnimElem = 15
attr = S, SA
damage = 25,1
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
animtype = hard
guardflag =
hitflag = MAFD
priority = 5, Hit
pausetime = 0,10
ground.type = low
ground.slidetime = 35
ground.hittime  = 35
ground.velocity = -4
airguard.velocity = 0,0
air.type = high
air.velocity = 0,0
air.hittime = 16
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
p2facing=1
p2stateno = 1090
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-80
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1070]
type = Explod
trigger1 = Animelem = 4
anim = 2030
id = 2030
pos = 30,-5
ownpal = 1
sprpriority = 3

[State 1070]
type = Explod
trigger1 = Animelem = 5
anim = f81
id = 2061
pos = 25,-7
ownpal = 1
sprpriority = 3

[State 1000]
type = PlaySnd
trigger1 =animelem=5
value =1,21

[State 1000]
type = PlaySnd
trigger1 =animelem=3
value =0,24

[State 1000]
type = PlaySnd
trigger1 =animelem=4
value =1,11

[State 1070]
type = envshake
trigger1 = time =0
trigger2 = animelem = 4
ampl=7
time = 8

[State 1001]
type = ChangeState
trigger1 = animtime = 0
value = 0
ctrl=1

;---------------------------------------------------------------------------
;
[Statedef 1080]
type    = S
movetype= H
physics = S
poweradd= 0
ctrl = 0
sprpriority = -2
velset=0,0

[State 1080]
type = changeanim2
trigger1 = time=0
value = 1080

[State 1090]
type=StatetypeSet
trigger1 = 1
value = S

[State 1080]
type = posset
trigger1 = animelem = 7,>=0
y = 0

[State 1080]
type = velset
trigger1 = animelem=7
x=-5

[State 1080]
type = selfstate
trigger1 = animtime=0
value = 5100
;---------------------------------------------------------------------------
;
[Statedef 1090]
type    = S
movetype= H
physics = S
poweradd= 0
ctrl = 0
sprpriority = -2
velset=0,0

[State 1090]
type = changeanim2
trigger1 = time=0
value = 1090

[State 1090]
type = posset
trigger1 = 1
y = 0

[State 1090]
type = velset
trigger1 = animelem = 2
x = -7

[State 1090]
type = velset
trigger1 = animelem = 2
trigger1 = alive = 0
y = -4

[State 1090]
type = changeanim
trigger1 = animelem = 2
trigger1 = alive = 0
value = 5030

[State 1090]
type = selfstate
trigger1 = anim = 5030
value = 5030

[State 1090]
type = selfstate
trigger1 = animtime = 0
trigger1 = alive
value = 0
ctrl=1

;---------------------------------------------------------------------------
;
[Statedef 1100]
type    = S
movetype= I
physics = S
poweradd= 100
ctrl = 0
anim = 1100
sprpriority = 2
velset=-3.5,0

[State 1100]
type=varSet
trigger1=Time=0
var(21)=0

[State 1100]
type=ChangeState
trigger1=Animtime=0
value=1121
;---------------------------------------------------------------------------
;
[Statedef 1120]
type    = S
movetype= I
physics = N
poweradd= 0
ctrl = 0
anim = 1120
sprpriority = 2
velset=0,0

[State 1100]
type=velset
trigger1=animelem=2
x=4

[State 1100]
type=varadd
trigger1=Time=0
var(21)=1

[State 1100]
type=ChangeState
trigger1=var(21)<3
trigger1=Animtime=0
value=1121


[State 1100]
type=ChangeState
trigger1=var(21)=3
trigger1=Animtime=0
trigger2=command!="Golpeholdx"
trigger2=animelem=2,>=0
value=1130

;---------------------------------------------------------------------------
;
[Statedef 1121]
type    = S
movetype= I
physics = N
poweradd= 0
ctrl = 0
anim = 1121
sprpriority = 2

[State 1100]
type=velset
trigger1=animelem=2
x=-4

[State 1100]
type=ChangeState
;trigger1=var(21)<4
trigger1=Animtime=0
value=1120

[State 1100]
type=ChangeState
trigger1 = !var(59)
trigger1=command!="Golpeholdx"
trigger1=animelem=2,>=0
trigger2 = var(59) && time = 0
value=1130

;---------------------------------------------------------------------------
;
[Statedef 1130]
type    = A
movetype= A
physics = N
poweradd= 100
ctrl = 0
anim = 1130
sprpriority = 2
velset=0,0
juggle = 1

[State 1100]
type=varSet
trigger1=Time=0
var(21)=0

[State 1100, 3]
type = HitDef
trigger1 = time=0
trigger1 = enemy,movetype = A
attr = A, SA
damage = 69,10
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
guardflag = MA
priority = 4
pausetime = 8,8
animtype = hard
ground.type = High
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-4
air.velocity = -4,-4
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
fall=1
p2stateno =7025
p2facing = 1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-80
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1100, 3]
type = HitDef
trigger1 =time=0
trigger1 = enemy,movetype != A
attr = A, SA
damage = 69,10
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
guardflag = HA
priority = 4
pausetime = 8,8
animtype = hard
ground.type = High
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-4
air.velocity = -4,-4
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
fall=1
p2stateno =1135
p2facing = 1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-80
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1130]
type = velset
trigger1 = animelem= 4
x=5
y=-5

[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 0,12
channel = 0

[State 1685]
type = playsnd
trigger1 = animelem = 4
value = 1,25

[State 1130]
type = veladd
trigger1 = animelem= 4,>=0
y=.3

[State 1130]
type = changestate
trigger1 = Animtime = 0
value = 1140
;---------------------------------------------------------------------------
;
[Statedef 1135]
type    = A
movetype= H
physics = N
poweradd= 50
ctrl = 0
sprpriority = -2
velset=0,0

[State 1135]
type = changeanim2
trigger1 = time = 0
value = 1135

[State 1135]
type = velset
trigger1 = Animelem = 3
x=-5
y=-5

[State 1135]
type = veladd
trigger1 = Animelem = 3,>= 0
y=.4

[State 1135]
type = changestate
trigger1 = pos Y>=20 && vel Y>0
value = 1040

;---------------------------------------------------------------------------
;
[Statedef 1140]
type    = S
movetype= I
physics = S
poweradd= 0
ctrl = 0
anim = 1140
sprpriority = 2
velset=0,0

[State 1140]
type=PosSet
trigger1=Time=0
y=0

[State 1140]
type=varSet
trigger1=Time=0
var(21)=0

[State 1140]
type = Explod
trigger1 = Animelem = 1
anim = 2080
id = 2080
pos = 0,0
ownpal = 1
sprpriority = -3

[State 1140]
type = playsnd
trigger1 = animelem = 1
value =1,12

[State 1140]
type=ChangeState
trigger1=Animtime=0
value=0
ctrl=1
;---------------------------------------------------------------------------
;
[Statedef 1150]
type    = S
movetype= I
physics = S
poweradd= 50
ctrl = 0
anim = 1100
sprpriority = 2
velset=-3.5,0

[State 1100]
type=varSet
trigger1=Time=0
var(21)=0

[State 1100]
type=ChangeState
trigger1=Animtime=0
value=1171
;---------------------------------------------------------------------------
;
[Statedef 1170]
type    = S
movetype= I
physics = N
poweradd= 0
ctrl = 0
anim = 1120
sprpriority = 2
velset=0,0

[State 1100]
type=velset
trigger1=animelem=2
x=4

[State 1100]
type=varadd
trigger1=Time=0
var(21)=1

[State 1100]
type=ChangeState
trigger1=var(21)<3
trigger1=Animtime=0
value=1171

[State 1100]
type=ChangeState
trigger1=var(21)=3
trigger1=Animtime=0
trigger2=command!="Golpeholdx"
trigger2=animelem=2,>=0
value=1190



;---------------------------------------------------------------------------
;
[Statedef 1171]
type    = S
movetype= I
physics = N
poweradd= 0
ctrl = 0
anim = 1121
sprpriority = 2

[State 1100]
type=velset
trigger1=animelem=2
x=-4

[State 1100]
type=ChangeState
trigger1=Animtime=0
value=1170

[State 1100]
type=ChangeState
triggerall=animelem=2,>=0
trigger1 = !var(59)
trigger1 =command!="Golpeholdx"
trigger2 = var(1) && var(3)
value=1190

[State 1100, AI]
type = ChangeState
triggerall = var(59)
trigger1 = time = 0
value = 1180

;---------------------------------------------------------------------------
;
[Statedef 1190]
type    = A
movetype= A
physics = N
poweradd= 100
ctrl = 0
anim = 1130
sprpriority = 2
velset=0,0
juggle = 1

[State 1100]
type=varSet
trigger1=Time=0
var(21)=0

[State 1100, 3]
type = HitDef
trigger1 = time=0
trigger1 = enemy,movetype = A
attr = A, SA
damage = 69,10
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
guardflag = MA
priority = 4
pausetime = 8,8
animtype = hard
ground.type = High
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-4
air.velocity = -4,-4
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
fall=1
p2stateno =7025
p2facing = 1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-80
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1100, 3]
type = HitDef
trigger1 =time=0
trigger1 = enemy,movetype != A
attr = A, SA
damage = 69,10
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
guardflag = HA
priority = 4
pausetime = 8,8
animtype = hard
ground.type = High
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-4
air.velocity = -4,-4
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
fall=1
p2stateno =1135
p2facing = 1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-80
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1130]
type = velset
trigger1 = animelem= 4
x=7.5
y=-5

[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 0,12
channel = 0

[State 1685]
type = playsnd
trigger1 = animelem = 4
value = 1,25

[State 1130]
type = veladd
trigger1 = animelem= 4,>=0
y=.3

[State 1130]
type = changestate
trigger1 = Animtime = 0
value = 1140

;---------------------------------------------------------------------------
;
[Statedef 1180]
type    = S
movetype= I
physics = S
poweradd= 0
ctrl = 0
anim = 1125
sprpriority = 2

[State 1100]
type=velSet
trigger1=Time=0
x=(ifelse(prevstateno=1170,0,-3))

[State 1100]
type=velSet
trigger1=Time=0
var(21)=0

[State 1100]
type=ChangeState
trigger1=Animtime=0
value=ifelse(command="holddown",11,0)
ctrl=1

;----------------------------------------------------
[Statedef 1200]
type=S
movetype=I
physics=S
velset=0,0
ctrl=0
anim=1200
sprpriority=2
poweradd=50

[State 1200]
type=PosAdd
trigger1=Time=0
trigger1=prevstateno =720
x=15

[State 1200]
type=PosAdd
trigger1=animelem = 5
x=20

[State 1200]
type = nothitby
trigger1 = animelem = 4,<=0
value = SAC

[State 1200]
type = statetypeset
trigger1 = animelem = 3
movetype = A

[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
trigger1=enemy,stateno!=[120,155]
trigger1=(enemy,stateno!=[40,51])&&(enemy,stateno!=[53,60])
attr=S,ST
hitflag=M
priority=6
sparkno=-1
hitsound = s800,0
sprpriority=1
p1facing=1
p2facing=1
p1stateno=1210
p2stateno=1220

[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
trigger1=enemy,stateno!=[120,155]
trigger1=(enemy,stateno!=[40,51])&&(enemy,stateno!=[53,60])
trigger1=enemy,stateno!=5001&&enemy,stateno!=5011&&enemy,stateno!=5021
attr=S,ST
hitflag=M
priority=6
sparkno=-1
hitsound = s800,0
sprpriority=1
p1facing=1
p2facing=1
p1stateno=1210
p2stateno=1220

[State 1200,2]
type=ChangeState
Trigger1=animTime=0
value=0
ctrl=1

;---------------------------------------------------------------------------

[Statedef 1210]
type=S
movetype=A
physics=S
velset=0,0
ctrl=0
anim=1210
sprpriority=2
poweradd=100

[State 1210]
type = posadd
trigger1 = time = 0
trigger1 = backedgebodydist <=50
x = 40

[State 1210]
type = posadd
trigger1 = animelem = 13
trigger1 = backedgebodydist <=60
x = 40

[State 1210]
type=TargetBind
trigger1=Animelem=1
pos=20,-80

[State 3010]
type=Explod
trigger1=Animelem=1
anim=f81
pos=20,-80
sprpriority = 1
ownpal=1

[State 1210]
type = playsnd
trigger1 = animelem = 1
value =1,21
channel = 1

[State 1210]
type = playsnd
trigger1 = animelem = 4
value = 0,13

[State 1210]
type=posadd
trigger1=Animelem=11
trigger1=backedgebodydist > 40
x=-40

[State 1210]
type=TargetBind
trigger1=Animelem=2
pos=15,-75

[State 1210]
type=TargetBind
trigger1=Animelem=3
pos=15,-70

[State 1210]
type=TargetBind
trigger1=Animelem=4
trigger2=animelem =8
pos=20,-60

[State 1210]
type=TargetBind
trigger1=Animelem=5
pos=25,-55

[State 1210]
type=TargetBind
trigger1=Animelem=6
pos=25,-50

[State 1210]
type=TargetBind
trigger1=Animelem=7
pos=25,-48

[State 1210]
type=TargetBind
trigger1=Animelem=9
pos=10,-70

[State 1210]
type=TargetBind
trigger1=Animelem=10
trigger2=Animelem=11
pos=0,-65

[State 1210]
type=TargetBind
trigger1=Animelem=12
pos=-10,-60

[State 1210]
type=TargetBind
trigger1=Animelem=13
pos=-15,-20

[State 1210]
type=TargetBind
trigger1=Animelem=14
pos=-20,-10

[State 1210]
type=Envshake
trigger1=animelem=14
ampl=8
time=10

[State 1210]
type = targetlifeadd
trigger1 = animelem=14
value = -150

[State 1210]
type=Explod
trigger1=animelem=14
anim=8102
pos=-50,0
postype=p1
sprpriority = -3
ownpal=1
scale = .5,.5

[State 1210]
type=Explod
trigger1=animelem=14
anim=8105
pos=-50,0
postype=p1
sprpriority = 3
ownpal=1
scale = .5,.5


[State 1210]
type = playsnd
trigger1 = animelem = 14
value = 1,11
channel = 1


[State 1210]
type=Turn
trigger1=Animtime=0



[State ]
type = changestate
trigger1 = Animtime = 0
value = 0
ctrl = 1
;---------------------------------------------------------------------------
;
[Statedef 1220]
type=A
movetype=H
physics=N
velset=0,0
ctrl=0
poweradd=100
sprpriority=-2

[STate 1220]
type=ChangeAnim2
trigger1=Time=0
value=1220

[State 1220]
type=VelSet
trigger1=Animelem=10
x=3
y=-6

[State 1220]
type=Veladd
trigger1=Animelem=10,>=0
y=.4

[State 1220]
type = Screenbound
trigger1 = animelem = 9,<= 0
value = 0

[State 1220]
type=SelfState
trigger1=pos Y>=-20 && vel Y>0
value=5100

;--------------------------------------------------------------------
[Statedef 1300]
type    = S
physics = S
anim = 1300
sprpriority = 2
velset=0,0
ctrl = 0
poweradd=50

[State 1300, 1]
type = VelSet
trigger1 = animelem = 3,>=0
x = const(velocity.run.fwd.x)

[State 1300]
type = playsnd
trigger1 = animelem = 3,>=0
trigger1 = timemod = 12,0
value = 100, ifElse((AnimElem = 3), 0, 1)
channel = 13



[State 1300, 2]
type = AssertSpecial
trigger1 = 1
flag = NoWalk

[State 1305,2]
type=ChangeState
trigger1 = !var(59)
Trigger1=animelem =3,>=0
trigger1 = command = "z"|| command ="c"
value=1306

[State 1300]
type = changestate
trigger1 = time >= 40
trigger2 = animelem = 3,>=0
trigger2 = p2bodydist X <= 5
value = 1305
;---------------------------------------------------------------------------
;
[Statedef 1301]
type    = S
physics = S
anim = 1300
sprpriority = 2
velset=0,0
ctrl = 0
poweradd=50

[State 1300, 1]
type = VelSet
trigger1 = animelem = 3,>=0
x = const(velocity.run.fwd.x)

[State 1300]
type = playsnd
trigger1 = animelem = 3,>=0
trigger1 = timemod = 12,0
value = 100, ifElse((AnimElem = 3), 0, 1)
channel = 13

[State 1300, 2]
type = AssertSpecial
trigger1 = 1
flag = NoWalk

[State 1305,2]
type=ChangeState
trigger1 = !var(59)
Trigger1=animelem =3,>=0
trigger1 = command = "z"|| command ="c"
value=1306

[State 1300]
type = changestate
trigger1 = time >= 50
trigger2 = animelem = 3,>=0
trigger2 = p2bodydist X <= 5
value = 1305

;---------------------------------------------------------------------------
;
[Statedef 1305]
type=S
movetype=A
physics=S
velset=0,0
ctrl=0
anim=1305
sprpriority=2
poweradd=0

[State 1300,1]
type=HitDef
Trigger1=Time=0
trigger1=enemy,stateno!=[120,155]
trigger1=(enemy,stateno!=[40,51])&&(enemy,stateno!=[53,60])
attr=S,ST
hitflag=M
priority=6,miss
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=1310
p2stateno=1320

[State 1300,1]
type=HitDef
Trigger1=Time=0
trigger1=enemy,stateno!=[120,155]
trigger1=(enemy,stateno!=[40,51])&&(enemy,stateno!=[53,60])
trigger1=enemy,stateno!=5001&&enemy,stateno!=5011&&enemy,stateno!=5021
attr=S,ST
hitflag=M
priority=6,miss
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=1310
p2stateno=1320

[State 1305,2]
type=ChangeState
Trigger1=animTime=0
value=0
ctrl=1

;----------------------------------------------------------
[Statedef 1306]
type=S
movetype=I
physics=S
velset=0,0
anim=1306
ctrl=0

[STate 1306]
type=AfterImagetime
trigger1=Time=0
time=0

[State 1306]
type=Changestate
trigger1=animtime=0
value=0
ctrl=1
;//////////////////////////////////////
[Statedef 1310]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1310
sprpriority = 2
poweradd=100

[State 1310]
type = posadd
trigger1 = time = 0
trigger1 = backedgebodydist <= 50
x = 50

[State 1310]
type = targetbind
trigger1 = time = 0
pos = 20,0

[State 1310]
type = BindToTarget
trigger1 = animelem = 5
pos = 0,0,mid

[State 1310]
type = BindToTarget
trigger1 = animelem = 6
pos = -5,0,mid

[State 1310]
type = BindToTarget
trigger1 = animelem = 7
pos = -10,0,mid

[State 1310]
type = posadd
trigger1 = animelem = 8
x = -40

[State 1310]
type = targetlifeadd
trigger1 = animelem = 6
value = -140 - var(7)*15
kill=0

[State 1310]
type = targetlifeadd
trigger1 = animelem = 8
value = -10

[State 1310]
type = velset
trigger1 = animelem = 8
x = -2
y = -4

[State 1310]
type = veladd
trigger1 = animelem = 8,>=0
y = .4


[State 1310]
type = Helper
trigger1 = Animelem = 6
stateno = 8013
id = 8013
pos = 0,0
ownpal = 1
sprpriority = 3

[State 1800]
type = playsnd
trigger1 = animelem = 2
value =1,21

[State 1800]
type = playsnd
trigger1 = animelem = 6
value =1,11

[State 1800]
type = playsnd
trigger1 = animelem = 7
value =0,10

[State 1310]
type = changestate
trigger1 = pos Y>0 && vel Y>0
value = 1330

;======================================

[Statedef 1330]
type    = S
movetype= I
physics = S
velset = 0,0
ctrl = 0
anim = 1330
sprpriority = 2
poweradd=0

[State 1540]
type = posset
trigger1 = time=0
y=0

[STate 1330]
type=Explod
trigger1=animelem=1
anim=8102
ownpal=1
pos=0,0
postype=p1
sprpriority=-3
scale = .5,.5

[State 1330]
type = playsnd
trigger1 = animelem = 1
value =1,2

[State 1330]
type = changestate
trigger1 = animtime=0
value = 0
ctrl=1

;---------------------------------------------------------------------------

[Statedef 1320]
type    = A
movetype= H
physics = N
poweradd= 50
ctrl = 0
sprpriority = -2
velset=0,0

[State 1135]
type = changeanim2
trigger1 = time=0
value = 1320

[State 1310]
type = posadd
trigger1 = animelem = 4
trigger2 = animelem = 5
x = -5

[State 1135]
type = velset
trigger1 = animelem=6
x=-4
y=-4

[State 1135]
type = veladd
trigger1 = animelem=6,>=0
y=.4

[State 1135]
type = selfstate
trigger1 = pos Y>=25 && vel Y>0
value = 5100

;======================================

[Statedef 1500]
type    = S
movetype= A
physics = S
velset = 0,0
ctrl = 0
anim = 1500
sprpriority = 2
poweradd=70

[State 1500]
type = varset
trigger1 = time = 0
var(19) = 0

[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 0,23
channel=0

[State 1500]
type = turn
trigger1 = animtime = 0

[State 1500]
type = changestate
trigger1 = animtime = 0
value = 1510

;======================================
;
[Statedef 1510]
type    = S
movetype= I
physics = N
velset = 8,0
ctrl = 0
anim = 1510
sprpriority = 2
poweradd=0

[State 1510]
type=ChangeState
trigger1 = !var(59)
trigger1 = command = "z" || command ="c"
value=1515

[State 1510]
type = changestate
trigger1 = frontedgebodydist <= 40
trigger2 = time >= 60
value = 1520
;---------------------------------------------------------------------------
;
[Statedef 1515]
type    = S
movetype= A
physics = S
juggle  = 0
poweradd= 100
ctrl = 0
anim = 1515
sprpriority = 2
velset=0,0

[State 1510]
type = turn
trigger1 = time = 0

[State 1510]
type=posadd
trigger1 = time = 0
x = 25

[State 1515]
type = HitDef
trigger1 =animelem=3
attr = S, SA
damage = 50,1
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
guardflag = MA
priority = 7
pausetime = 10,12
animtype = digup
ground.type = High
ground.slidetime = 20
ground.hittime  = 20
ground.velocity = -5,-4
air.velocity = -4,-4
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
fall = 1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1510]
type = changestate
trigger1 = animtime = 0
value = 0
ctrl = 1

;======================================
;
[Statedef 1520]
type    = A
movetype= I
physics = N
velset = 0,0
ctrl = 0
anim = 1520
sprpriority = 2
poweradd=0

[STate 1520]
type=ScreenBound
trigger1=1
value=1
movecamera=0,1

[State 1510]
type=ChangeState
trigger1 = !var(59)
trigger1 = animelem =2,<=0
trigger1 = command = "z" || command ="c"
value=1515

[State 1520]
type = velset
trigger1 = animelem=3
x = 4
y = -10
persistent=0

[State 1520]
type = veladd
trigger1 = animelem=3,>=0
y = .4

[State 1510]
type = changestate
trigger1 = frontedgebodydist <= 15
trigger1 = animelem =4, >=0
value = 1530

[State 1510]
type = changestate
trigger1 = pos Y>=10 && vel Y>0
value = 52
ctrl=1
facing = -1
;======================================
;
[Statedef 1540]
type    = S
movetype= I
physics = S
velset = 0,0
ctrl = 0
anim = 1540
sprpriority = 2
poweradd=0

[State 1540]
type = posset
trigger1 = time=0
y=0

[STate 1540]
type=Explod
trigger1=animelem=2
anim=8102
ownpal=1
pos=0,0
postype=p1
sprpriority=-3
scale = .5,.5

[State 1540]
type = playsnd
trigger1 = animelem = 2
value =1,2

[STate 1540]
type=AfterImageTime
trigger1=Time=0
time=0

[State 1540]
type = changestate
trigger1 = animtime=0
value = 0
ctrl=1

;======================================
;
[Statedef 1530]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1530
sprpriority = 2
poweradd=0

[State 1530]
type = turn
trigger1 = time = 0

[State 1530]
type = posset
trigger1 = Animelem = 1,>=0
trigger1 = Animelem = 3,<=0
y = -60
x = ifelse(facing=1,-360,360)

[State 1500]
type = varset
trigger1 = command = "b"
trigger2 = var(1) && random < 333
trigger3 = var(59) && Random <= 50
var(19) = 1

[State 1500]
type = varset
trigger1 = command = "x"
trigger2 = var(1) && (random = [350,800])
trigger3 = var(59) && Random <= var(59)*100
var(19) = 2

[State 1530]
type = HitDef
trigger1 =animelem=7
attr = A, SA
damage = 60,1
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
guardflag = H
priority = 5
pausetime = 20,20
guard.pausetime = 20,25
animtype = digup
ground.type = low
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = -7,10
air.velocity = -5,20
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
ground.cornerpush.veloff = -15
guard.cornerpush.veloff = -10
fall=1
fall.recover=0
envshake.time = 20
envshake.ampl = 10
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-35
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1530]
type = changestate
triggerall = animelem = 3
trigger1 = var(19) = 1
trigger2 = var(1) && var(3) && random <= 333
value = 1550

[State 1530]
type = changestate
triggerall = animelem = 3
trigger1 = var(19) = 2
trigger2 = var(1) && var(3) && random <= 666
value = 1560

[State 1530]
type = velset
trigger1 = animelem=3
x = 2
y = -5

[State 1530]
type = veladd
trigger1 = animelem=3,>=0
y = .4

[State 1530]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
value = 1540
;======================================
;
[Statedef 1550]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1550
sprpriority = 2
poweradd=100

[State 1550]
type = velset
trigger1 = time <= 3
y=-((p2dist Y)/60)-2.5

[State 1550]
type = velset
trigger1 = time <= 5
x=((p2dist X)/25)-1.2

[State 1550]
type = veladd
trigger1 = 1
y = .44

[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 1,22

[State 1550]
type = varset
trigger1 = time =0
var(19) = 0

[State 1550]
type = HitDef
trigger1 =animelem=4
attr = A, SA
damage = 75,1
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
guardflag = H
priority = 5
pausetime = 10,10
animtype = hard
ground.type = high
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = -5,-5
air.velocity = -5,-5
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
ground.cornerpush.veloff = -15
guard.cornerpush.veloff = -10
fall=1
envshake.time = 10
envshake.ampl = 6
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1550]
type = changestate
trigger1 = pos Y>=15 && vel Y>0
value = 1540

;======================================
;
[Statedef 1560]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1560
sprpriority = 2
poweradd=100

[State 1560]
type = velset
trigger1 = time <= 3
y=-((p2dist Y)/60)-2.5

[State 1560]
type = velset
trigger1 = time <= 5
x=((p2dist X)/25)-1.5

[State 1560]
type = veladd
trigger1 = 1
y = .44

[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 1,22

[State 1560]
type = varset
trigger1 = time =0
var(19) = 0

[State 1560]
type = HitDef
trigger1 = enemy,statetype = S || enemy,statetype = C
trigger1 =animelem=4,>=0
attr = A, SA
damage = 0,0
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
guardflag =
hitflag = MAF
priority = 7,miss
pausetime = 10,10
animtype = hard
ground.type = low
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = -7
air.velocity = -5,-4
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
ground.cornerpush.veloff = -15
guard.cornerpush.veloff = -10
fall=1
fall.recover=0
p1stateno = 1590
p2stateno =1595
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1560]
type = HitDef
trigger1 = enemy,statetype = A
trigger1 =animelem=4,>=0
attr = A, SA
damage = 0,0
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
guardflag =
hitflag = MAF
priority = 7,miss
pausetime = 0,0
animtype = hard
ground.type = low
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = -7
air.velocity = -5,-4
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
ground.cornerpush.veloff = -15
guard.cornerpush.veloff = -10
fall=1
fall.recover=0
p1stateno = 1570
p2stateno =1580
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[State 1560]
type = changestate
trigger1 = pos Y>=15 && vel Y>0
value = 1540

;======================================
;
[Statedef 1570]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1570
sprpriority = 2

[State 1570]
type = posadd
trigger1 = time = 0
x = 40
y = -140

[State 1570]
type = targetbind
trigger1 = animelem = 1,>=0
trigger1 = animelem = 5,<=0
pos = -10,0

[State 1570]
type = targetbind
trigger1 = animelem = 6,>=0
pos = 0,0

[State 1570]
type = veladd
trigger1 = animelem = 7,>=0
y = .55

[State 1500]
type = playsnd
trigger1 = animelem = 7
value = 0,47

[State 1570]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
value = 1575

;======================================
;
[Statedef 1575]
type    = S
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1575
sprpriority = 2

[State 1570]
type = posset
trigger1 = time = 0
y = 0

[State 1570]
type = targetbind
trigger1 = animelem = 1
pos = -30,0

[State 1590]
type = targetlifeadd
trigger1 = animelem = 1
value = -125 - var(7)*15

[State 1570]
type = targetstate
trigger1 = time = 0
value = 1585

[State 1590]
type = envshake
trigger1 = animelem = 1
ampl = 10
time = 10

[State 1590]
type=Explod
trigger1=Animelem=1
anim=8102
postype=p1
pos=-20,10
sprpriority=-5
ownpal=1
scale = .5,.5

[State 1590]
type=Explod
trigger1=Animelem=1
anim=8105
postype=p1
pos=-20,10
sprpriority=5
ownpal=1
scale = .5,.5


[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 1,47

[State 1575]
type = changestate
trigger1 = animtime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
;
[Statedef 1580]
type=A
movetype=H
physics=N
velset=0,0
ctrl=0
poweradd=100
sprpriority=1

[STate 1595]
type=ChangeAnim2
trigger1=Time=0
value=1580

[State 1595]
type = Screenbound
trigger1 = 1
value = 0

;---------------------------------------------------------------------------
;
[Statedef 1585]
type=A
movetype=H
physics=N
velset=0,0
ctrl=0
poweradd=100
sprpriority=1

[STate 1585]
type=ChangeAnim2
trigger1=Time=0
value=1585

[State 1585]
type = velset
trigger1 = animelem = 2
x = 3
y = -4

[State 1585]
type = veladd
trigger1 = animelem = 2,>=0
y = .4

[State 1585]
type = SelfState
trigger1 = pos Y>0 && vel Y >0
value = 5100


;======================================
;
[Statedef 1590]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1590
sprpriority = 2

[State 1590]
type = posset
trigger1 = time = 0
y = 0

[State 1590]
type = sprpriority
trigger1 = animelem = 8
value = -2

[State 1590]
type = targetbind
trigger1 = animelem = 1,>=0
trigger1 = animelem = 4,<=0
pos = 0,0

[State 1590]
type = targetbind
trigger1 = animelem = 5
pos = -10,-70

[State 1590]
type = targetbind
trigger1 = animelem = 6
pos = 0,-70

[State 1590]
type = targetbind
trigger1 = animelem = 7
pos = 10,-60

[State 1590]
type = targetbind
trigger1 = animelem = 8
pos = 10,-90

[State 1590]
type = targetbind
trigger1 = animelem = 9
pos = -20,-46

[State 1590]
type = targetbind
trigger1 = animelem = 10
pos = -30,-25

[State 1590]
type = targetbind
trigger1 = animelem = 11
pos = -35,-10

[State 1590]
type = targetlifeadd
trigger1 = animelem = 11
value = -110 - var(7)*15

[State 1590]
type = envshake
trigger1 = animelem = 11
ampl = 10
time = 10

[State 1500]
type = playsnd
trigger1 = animelem = 11
value = 1,47

[State 1590]
type=Explod
trigger1=Animelem=11
anim=2110
postype=p1
pos=-20,10
sprpriority=-5
ownpal=1

[State 1590]
type=Explod
trigger1=Animelem=11
anim=2111
postype=p1
pos=-20,10
sprpriority=5
ownpal=1

[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 0,46

[State 1590]
type = changestate
trigger1 = Animtime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
;
[Statedef 1595]
type=S
movetype=H
physics=N
velset=0,0
ctrl=0
poweradd=100
sprpriority=1

[STate 1595]
type=ChangeAnim2
trigger1=Time=0
value=1595

[State 1595]
type = Screenbound
trigger1 = animelem = 8,<=0
value = 0

[State 1595]
type = velset
trigger1 = animelem = 9
x = 3
y = -4

[State 1595]
type = veladd
trigger1 = animelem = 9,>=0
y = .4

[State 1595]
type = SelfState
trigger1 = pos Y>0 && vel Y >0
value = 5100

;------------------------------------------------------------
[Statedef 1800]
type    = S
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1800
sprpriority = 2
poweradd=100

[State 1800]
type = statetypeset
trigger1 = animelem = 8
value = A
[State 1550]
type = velset
trigger1 = animelem = 8
x=1.8
y=-9

[State 1550]
type = veladd
trigger1 = animelem = 8,>=0
y = .55

[State 1550]
type = varset
trigger1 = time =0
var(19) = 0

[State 1800]
type = playsnd
trigger1 = animelem = 8
value =0,10
channel = 0

[State 1800]
type = HitDef
trigger1 =animelem=13
trigger1 = enemy,statetype = C
attr = A, SA
damage    = 70,1
guardflag = M
hitflag = MAFD
priority = 5
pausetime = 0,5
sparkno = s2030
guard.sparkno=s2050
sparkxy = -10,-30
hitsound = s1,11
guardsound = s1,15
animtype = digup
ground.type = high
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = 0,10
air.velocity = -5,-4
down.velocity = -1,-5
getpower=150,100
givepower=100,50
ground.cornerpush.veloff = -8
guard.cornerpush.veloff = -7
fall=1
fall.recover = 0
envshake.time = 12
envshake.ampl = 10

[State 1800]
type = HitDef
trigger1 =animelem=13
trigger1 = enemy,statetype != C
attr = A, SA
damage    = 70,1
guardflag = M
hitflag = MAFD
priority = 5
pausetime = 0,5
sparkno = s2030
guard.sparkno=s2050
sparkxy = -10,-30
hitsound = s1,11
guardsound = s1,15
animtype = digup
ground.type = low
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = -6,-5
air.velocity = -5,-4
down.velocity = -1,-5
getpower = 50 * !var(20), 30 * !var(20)
givepower = 35, 35
ground.cornerpush.veloff = -8
guard.cornerpush.veloff = -7
fall=1
envshake.time = 12
envshake.ampl = 10

[State 1800]
type = changestate
trigger1 = pos Y>=10 && vel Y>0
value = 1810
;======================================
;
[Statedef 1810]
type    = S
movetype= I
physics = S
velset = 0,0
ctrl = 0
anim = 1810
sprpriority = 2
poweradd=0

[State 1810]
type = posset
trigger1 = time=0
y=0

[STate 1810]
type=Explod
trigger1=animelem=1
anim=2080
ownpal=1
pos=0,0
postype=p1
sprpriority=-3

[State 1810]
type = playsnd
trigger1 = animelem = 1
value =1,12

[State 1810]
type = playsnd
trigger1 = animelem = 1
value =1,16

[State 1810]
type = playerpush
trigger1 = time <= 10
value = 0

[State 1810]
type = changestate
trigger1 = animtime=0
value = 0
ctrl=1




