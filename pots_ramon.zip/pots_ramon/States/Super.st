;==================<Zmugens is the creator of this character>============
;Tiger Spin
[Statedef 3000]
type    = S
movetype= A
physics = S
velset = 0,0
ctrl = 0
anim = 3000
poweradd = ifelse(var(20) > 0, 0, -1000)
sprpriority = 2
facep2 = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3000, No Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 50

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = (PrevStateNo = [1000,2999]) && var(6)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(7)

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle Reset]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 2
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = -10,-80
superMoveTime = 255
supermove=-1
size.xScale = 1
size.yScale = 1
ownPal = 1




[STate 3000]
type = changeanim
trigger1 = prevstateno = 1070 || prevstateno = 1515
trigger1 = time = 0
value = 3001

;////////////////////


[State 3100,3]
type=superpause
trigger1=time=2
anim=-1
pos=10,-90
postype=p1
sound = s8500,0
time=25
movetime=16
p2defmul = 1


[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
trigger1=prevstateno = 1070 || prevstateno = 1515
attr=S,HT
hitflag=MAFD
priority=6
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=3010
p2stateno=3020

[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
trigger1=enemy,stateno!=[120,155]
trigger1=(enemy,stateno!=[40,51])&&(enemy,stateno!=[53,60])
attr=S,HT
hitflag=M
priority=6
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=3010
p2stateno=3020

[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
trigger1=enemy,stateno!=[120,155]
trigger1=(enemy,stateno!=[40,51])&&(enemy,stateno!=[53,60])
trigger1=enemy,stateno!=5001&&enemy,stateno!=5011&&enemy,stateno!=5021
attr=S,HT
hitflag=M
priority=6
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=3010
p2stateno=3020

[State 3000, 2]
type = ChangeState
Trigger1 =animtime=0
value = 0
ctrl=1

;======================================

[Statedef 3001]
type    = S
movetype= A
physics = S
velset = 0,0
ctrl = 0
anim = 3001
sprpriority = 2
poweradd=-1000


[STate 3000]
type=AssertSpecial
trigger1=prevstateno = 1070 || prevstateno = 1630 || prevstateno = 1515
flag=nojugglecheck

[State 3000]
type=PalFx
trigger1=Time=0
trigger1=prevstateno = 1070 || prevstateno = 1630 || prevstateno = 1515
time=5
add=255,255,255

;////////////////////


[State 3100,3]
type=superpause
trigger1=time=2
anim=-1
pos=10,-90
postype=p1
sound = s8500,0
time=25
movetime=16
p2defmul = 1


[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
attr=S,HT
hitflag=MAF
priority=6
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=3010
p2stateno=3020

[State 3000, 2]
type = ChangeState
Trigger1 =animtime=0
value = 0
ctrl=1


[Statedef 3010]
type    = S
movetype= A
physics = S
juggle  = 0
velset = 0,0
ctrl = 0
anim = 3050
sprpriority = 2

[State 3010,0]
type=PosAdd
trigger1=BackEdgeBodyDist<=40&&Time=0
x=30

[State 3100,3]
type=superpause
trigger1=time=0
anim=-1
pos=10,-90
postype=p1
sound = s8500,0
time=25
movetime=10
p2defmul = 1


[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 2
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = -10,-80
superMoveTime = 255
supermove=-1
size.xScale = 1
size.yScale = 1
ownPal = 1


[STate 3010,1]
type=PlaySnd
trigger1=Animelem=4
value=1,21

[STate 3010,1]
type=PlaySnd
trigger1=Animelem=3
value=0,14

[STate 3010,1]
type=PlaySnd
trigger1=Animelem=3
value=1,6

[State 3010,2]
type=TargetBind
trigger1=Animelem=1,>=0
trigger1=Animelem=2,<=0
pos=15,0

[State 3010,2]
type=TargetBind
trigger1=Animelem=3,>=0
trigger1=Animelem=4,<=0
pos=15,0

[State 3010,2]
type=TargetBind
trigger1=Animelem=5,>=0
trigger1=Animelem=6,<=0
pos=-15,0

[State 3010,2]
type=TargetBind
trigger1=Animelem=7
pos=-15,0

[State 3010]
type=TargetBind
trigger1=Animelem=8,>=0
trigger1=animelem=11,<=0
pos=-20,0

[State 3010]
type=TargetBind
trigger1=Animelem=12,>=0
trigger1=animelem=15,<=0
pos=-15,0

[State 3010]
type=TargetBind
trigger1=Animelem=16,>=0
trigger1=animelem=18,<=0
pos=-20,0

[State 3010]
type=TargetBind
trigger1=Animelem=19
pos=-30,-70

[State 3010]
type=TargetBind
trigger1=Animelem=20
pos=-30,-60

[State 3010]
type=TargetBind
trigger1=Animelem=21
pos=-25,-70

[State 3010]
type=TargetBind
trigger1=Animelem=22
pos=0,-60

[State 3010]
type=TargetBind
trigger1=Animelem=23
pos=15,-30

[State 3010]
type=TargetBind
trigger1=Animelem=24
pos=20,-15

[State 3010,3]
type=Targetlifeadd
trigger1=Animelem=24
value=-220

[State 3010,2]
type=null;Targetstate
trigger1=Animelem=24
value=3030

[State 3010,10]
type=envshake
trigger1=Animelem=24
ampl=8
time=15

[State 1210,4]
type=Explod
trigger1=Animelem=24
anim=8105
postype=p1
pos=20,0
sprpriority=-5
ownpal=1
scale = .5,.5

[State 1210,4]
type=Explod
trigger1=Animelem=24
anim=8105
postype=p1
pos=20,0
sprpriority=5
ownpal=1
scale = .5,.5

[STate 3010,11]
type=BgpalFx
trigger1=Animelem=24
time=1
value=255,255,255

[State 3010,12]
type=PlaySnd
trigger1=Animelem=24
value=1,11
channel=2

[STate 3010,0];
type=Explod
trigger1=animelem=24
anim=2030
pos=20,0
postype=p1
sprpriority=6
ownpal=1

[State 3010,20]
type=Changestate
trigger1=Animtime=0
value=0
ctrl=1


[Statedef 3020]
type    = S
movetype= H
physics = N
juggle  = 0
velset = 0,0
ctrl = 0
sprpriority = -2

[State 3020,1]
type=Changeanim2
trigger1=Time=0
value=3020

[State 3020,3]
type=ScreenBound
trigger1 = animelem = 10,<0
value=0

[State 1320,5]
type=DestroySelf
trigger1=Ishelper

[State 3020]
type = velset
trigger1 = animelem=10
x=-3
y=-5

[State 3020]
type = veladd
trigger1 = animelem = 10,>=0
y=.4

[State 3030,2]
type=Changeanim
trigger1=pos Y>=0&&Vel Y>0
trigger1=SelfAnimExist(5062)=1
value=5062

[State 3020]
type = selfstate
trigger1 = pos Y>=0 && vel Y>0
value = 5100
;---------------------------------------------------------------------------
[Statedef 3030]
type    = A
movetype= H
physics = N
poweradd = 0
ctrl=0

[State 930,1]
type=Changeanim2
trigger1=Time=0
value=3070

[State 3030,2]
type=Changestate
trigger1=time=6
value=3040

[State 3020,3]
type=ScreenBound
trigger1=1
value=0

[State 1320,5]
type=DestroySelf
trigger1=Ishelper

[Statedef 3040]
type    = A
movetype= H
physics = N
poweradd = 0
ctrl=0
velset=-4,0

;[STate 3040,0]
;type=Turn
;trigger1=Time=0

[State 930,1]
type=VelSet
trigger1=animelem=1
y=-3

[State 930,1]
type=Veladd
trigger1=1
y=.4

[State 3030,2]
type=Changeanim
trigger1=pos Y>=0&&Vel Y>0
trigger1=SelfAnimExist(5062)=1
value=5062

[State 930,2]
type=SelfState
trigger1=Pos Y>=0&&Vel Y>0
value=5100

;Max Tiger Spin
[Statedef 3200]
type    = S
movetype= A
physics = S
velset = 0,0
ctrl = 0
anim = 3000
sprpriority = 2
poweradd=-2000



[State 2000, 3]
type = EnvColor
trigger1 = Time = 0
value = 0,0,0
time = 30
under = 1

[State 3100,3]
type=superpause
trigger1=time=2
anim=-1
pos=10,-90
postype=p1
sound = s8500,0
time=25
movetime=16
p2defmul = 1

[State 3050, Super Pause FX]
type = Helper
trigger1 = Time = 2
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = -10,-80
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
trigger1=prevstateno = 1070 || prevstateno = 1515
attr=S,HT
hitflag=MAFD
priority=6
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=3210
p2stateno=3220

[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
trigger1=enemy,stateno!=[120,155]
trigger1=(enemy,stateno!=[40,51])&&(enemy,stateno!=[53,60])
attr=S,HT
hitflag=M
priority=6
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=3210
p2stateno=3220

[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
trigger1=enemy,stateno!=[120,155]
trigger1=(enemy,stateno!=[40,51])&&(enemy,stateno!=[53,60])
trigger1=enemy,stateno!=5001&&enemy,stateno!=5011&&enemy,stateno!=5021
attr=S,HT
hitflag=M
priority=6
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=3210
p2stateno=3220

[State 3200, 2]
type = ChangeState
Trigger1 =animtime=0
value = 0
ctrl=1
;======================================

[Statedef 3201]
type    = S
movetype= A
physics = S
velset = 0,0
ctrl = 0
anim = 3001
sprpriority = 2
poweradd=-2000



[STate 3000]
type=AssertSpecial
trigger1=prevstateno = 1070 || prevstateno = 1630 || prevstateno = 15155 || prevstateno = 3110
flag=nojugglecheck

[State 3000]
type=PalFx
trigger1=Time=0
trigger1=prevstateno = 1070 || prevstateno = 1630 || prevstateno = 1515 || prevstateno = 3110
time=5
add=255,255,255

;////////////////////
[STate 3000,1]
type=envcolor
trigger1=Time=2
value=0,0,0
time=25
under=1

[State 3100,3]
type=superpause
trigger1=time=2
anim=-1
pos=10,-90
postype=p1
sound=s8500,0
time=25
movetime=16
p2defmul = 1

[State 3050, Super Pause FX]
type = Helper
trigger1 = Time = 2
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = -10,-80
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 1200,1]
type=HitDef
triggerall = p2bodydist X>=-8
Trigger1=Time=0
attr=S,HT
hitflag=MAF
priority=6
sparkno=-1
sprpriority=1
p1facing=1
p2facing=1
p1stateno=3210
p2stateno=3220

[State 3200, 2]
type = ChangeState
Trigger1 =animtime=0
value = 0
ctrl=1

;---------------------------------------------------------------------------
;
[Statedef 3210]
type    = S
movetype= A
physics = C
juggle  = 0
velset = 0,0
ctrl = 0
anim = 3210
sprpriority = 2

[State 3310,0]
type=PosAdd
trigger1=Time=0
trigger1=backEdgeBodydist <=30
x=40



[State 3100,3]
type=superpause
trigger1=time=0
anim=-1
pos=10,-90
postype=p1
sound=s8500,0
time=25
movetime=10
p2defmul = 1


[State 3050, Super Pause FX]
type = Helper
trigger1 = Time = 2
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = -10,-80
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1


[State 3310,1]
type=PlaySnd
trigger1=animelem=2
value=0,25
channel=0
[State 3310,1]
type=PlaySnd
trigger1=animelem=2
value=1,21
channel=1

[State 1200,3]
type=posadd
trigger1=Animelem=13
x=-50
[State 1200,3]
type=posadd
trigger1=Animelem=15
x=-30

[State 1210,1]
type=TargetBind
trigger1=Animelem=1
pos=20,0
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=2
pos=5,-60
postype=p1
[State 1210,1]
type=TargetBind
trigger1=Animelem=3
pos=10,-60
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=4
pos=10,-55
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=5
pos=13,-55
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=6
pos=12,-53
postype=p1
[State 1210,1]
type=TargetBind
trigger1=Animelem=7
pos=14,-50
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=8
pos=15,-60
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=9
pos=-7,-60
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=10
pos=-20,-60
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=11
pos=-26,-70
postype=p1

[State 3310,1]
type=TargetBind
trigger1=Animelem=12
pos=-45,-45
postype=p1

[State 3310,1]
type=TargetBind
trigger1=Animelem=13
pos=-15,-10
postype=p1

[State 3310,1]
type=TargetBind
trigger1=Animelem=14
pos=-30,0
postype=p1
[State 3310,1]
type=TargetBind
trigger1=Animelem=15
pos=-30,0
postype=p1

[State 3310,1]
type=TargetBind
trigger1=Animelem=17
pos=20,0
postype=p1

;-----------------
[State 3310,1]
type=Targetlifeadd
trigger1=Animelem=15
value=-80
kill=0
[State 3310,2]
type=EnvShake
trigger1=Animelem=14
ampl=10
time=12



[State 1210,4]
type=Explod
trigger1=Animelem=14
anim=8105
postype=p1
pos=-20,0
sprpriority=-5
ownpal=1
scale = .5,.5

[State 1210,4]
type=Explod
trigger1=Animelem=14
anim=8105
postype=p1
pos=-20,0
sprpriority=5
ownpal=1
scale = .5,.5

[STate 3010,0];
type=Helper
trigger1=animelem=14
stateno=8013
pos=-20,0
postype=p1
sprpriority=6
ownpal=1
scale = .5,.5

[STate 3310,3]
type=PlaySnd
trigger1=Animelem=14
value=1,11
channel=3
[State 1200, 2]
type = ChangeState
Trigger1 = AnimTime = 0
value = 3215
;---------------------------------------------------------------------------
;
[Statedef 3215]
type    = S
movetype= A
physics = C
juggle  = 0
velset = 0,0
ctrl = 0
anim = 3215
sprpriority = 2

[State 1200,3]
type=posadd
trigger1=Animelem=13
x=-55

[State 1200,3]
type=posadd
trigger1=Animelem=15
x=-30

[State 3315,0]
type=TargetState
trigger1=time=0
value=3220

[State 1210,1]
type=TargetBind
trigger1=Animelem=1
pos=0,0
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=2
pos=5,-60
postype=p1
[State 1210,1]
type=TargetBind
trigger1=Animelem=3
pos=10,-60
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=4
pos=10,-55
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=5
pos=13,-55
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=6
pos=12,-53
postype=p1
[State 1210,1]
type=TargetBind
trigger1=Animelem=7
pos=14,-50
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=8
pos=15,-60
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=9
pos=-7,-64
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=10
pos=-20,-60
postype=p1

[State 1210,1]
type=TargetBind
trigger1=Animelem=11
pos=-26,-70
postype=p1

[State 3310,1]
type=TargetBind
trigger1=Animelem=12
pos=-55,-45
postype=p1

[State 3310,1]
type=TargetBind
trigger1=Animelem=13
pos=-12,-10
postype=p1

[State 3310,1]
type=TargetBind
trigger1=Animelem=14
pos=-30,0
postype=p1

[State 3310,1]
type=TargetBind
trigger1=Animelem=15
pos=0,0
postype=p1

[State 3310,1]
type=TargetBind
trigger1=Animelem=17
pos=20,0
postype=p1

[State 3310,1]
type=Targetlifeadd
trigger1=Animelem=15
value=-120
kill=0

[State 3310,2]
type=EnvShake
trigger1=Animelem=14
ampl=10
time=12

[State 1210,4]
type=Explod
trigger1=Animelem=14
anim=8105
postype=p1
pos=-20,0
sprpriority=-5
ownpal=1
scale = .5,.5

[State 1210,4]
type=Explod
trigger1=Animelem=14
anim=8105
postype=p1
pos=-20,0
sprpriority=5
ownpal=1
scale = .5,.5

[STate 3010,0];
type=helper
trigger1=animelem=14
stateno=8013
pos=-20,0
postype=p1
sprpriority=6
ownpal=1
scale = .5,.5

[STate 3310,3]
type=PlaySnd
trigger1=Animelem=14
value=1,11
channel=3

[State 1200, 2]
type = ChangeState
Trigger1 = AnimTime = 0
value = 3230

;------------------------------------------------------------
[Statedef 3230]
type    = S
movetype= A
physics = S
juggle  = 0
velset = 0,0
ctrl = 0
anim = 3230
sprpriority = 2

[State 3010,0]
type=PosAdd
trigger1=BackEdgeBodyDist<=40&&Time=0
x=30



[STate 3010,1]
type=PlaySnd
trigger1=Animelem=4
value=1,21

[STate 3010,1]
type=PlaySnd
trigger1=Animelem=3
value=0,14

[STate 3010,1]
type=PlaySnd
trigger1=Animelem=3
value=1,6

[State 3010,2]
type=Targetstate
trigger1=time = 0
value = 3240

[State 3010,2]
type=TargetBind
trigger1=Animelem=1,>=0
trigger1=Animelem=2,<=0
pos=15,0

[State 3010,2]
type=TargetBind
trigger1=Animelem=3,>=0
trigger1=Animelem=4,<=0
pos=15,0

[State 3010,2]
type=TargetBind
trigger1=Animelem=5,>=0
trigger1=Animelem=6,<=0
pos=-15,0

[State 3010,2]
type=TargetBind
trigger1=Animelem=7
pos=-15,0

[State 3010]
type=TargetBind
trigger1=Animelem=8,>=0
trigger1=animelem=11,<=0
pos=-20,0

[State 3010]
type=TargetBind
trigger1=Animelem=12,>=0
trigger1=animelem=15,<=0
pos=-15,0

[State 3010]
type=TargetBind
trigger1=Animelem=16,>=0
trigger1=animelem=18,<=0
pos=-20,0

[State 3010]
type=TargetBind
trigger1=Animelem=19
pos=-30,-70

[State 3010]
type=TargetBind
trigger1=Animelem=20
pos=-30,-60

[State 3010]
type=TargetBind
trigger1=Animelem=21
pos=-25,-70

[State 3010]
type=TargetBind
trigger1=Animelem=22
pos=0,-60

[State 3010]
type=TargetBind
trigger1=Animelem=23
pos=15,-30

[State 3010]
type=TargetBind
trigger1=Animelem=24
pos=20,-15

[State 3010,3]
type=Targetlifeadd
trigger1=Animelem=24
value=-250

[State 3010,10]
type=envshake
trigger1=Animelem=24
ampl=10
time=20

[State 1210,4]
type=Explod
trigger1=Animelem=24
anim=8105
postype=p1
pos=20,0
sprpriority=-5
ownpal=1
scale = .5,.5

[State 1210,4]
type=Explod
trigger1=Animelem=24
anim=8105
postype=p1
pos=20,0
sprpriority=5
ownpal=1
scale = .5,.5



[State 3010,12]
type=PlaySnd
trigger1=Animelem=24
value=1,11
channel=2

[State 3010,12]
type=PlaySnd
trigger1=Animelem=24
value=1,47

[STate 3010,0];
type=Explod
trigger1=animelem=24
anim=2070
pos=20,0
postype=p1
sprpriority=6
ownpal=1

[State 3010,20]
type=Changestate
trigger1=Animtime=0
value=0
ctrl=1

;---------------------------------------------------------------------------
;
[Statedef 3220]
type    = S
movetype= H
physics = N
juggle  = 0
velset = 0,0
ctrl = 0
sprpriority = -2

[State 3320,1]
type=Changeanim2
trigger1=Time=0
value=3220

[State 3320,2]
type=ScreenBound
trigger1=1
value=0

[State 1320,5]
type=DestroySelf
trigger1=Ishelper

;-------------------------------------------------
[Statedef 3240]
type    = S
movetype= H
physics = N
juggle  = 0
velset = 0,0
ctrl = 0
sprpriority = -2

[State 3020,1]
type=Changeanim2
trigger1=Time=0
value=3260

[State 3020,3]
type=ScreenBound
trigger1 = animelem = 10,<0
value=0

[State 1320,5]
type=DestroySelf
trigger1=Ishelper

[State 3020]
type = velset
trigger1 = animelem=10
x=-3
y=-5

[State 3020]
type = veladd
trigger1 = animelem = 10,>=0
y=.4

[State 3030,2]
type=Changeanim
trigger1=pos Y>=0&&Vel Y>0
trigger1=SelfAnimExist(5062)=1
value=5062

[State 3020]
type = selfstate
trigger1 = pos Y>=-20 && vel Y>0
value = 5100
;Diablo Amarillo Ramon
[Statedef 3100]
type=S
physics=N
movetype=A
ctrl=0
velset=0,0
sprpriority=1
poweradd=-1000
facep2=1

[State 3000, Anim]
type=changeanim
trigger1=!time
value=3100

[state 3000,Posset]
type=posset
trigger1=!time
y=0

[State 3000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 3000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 3000, Super Cancel Flag]
type = varset
trigger1 = !time
var(21) = ((prevstateno = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = varset
trigger1 = !time
var(22) = (prevstateno = [3000, 4999]) && var(8)

[State 3000, CC Reset]
type = palfx
trigger1 = !time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = varset
trigger1 = time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 40

[State 3000, Super Cancel Flash]
type = palfx
trigger1 = var(21) || var(22)
trigger1 = !(time % 2) && time <= 12
time = 1
add = 255, 255, 255
ignorehitpause = 1

[State 3000, Super Cancel Juggle]
type = varset
trigger1 = !time
trigger1 = var(21) || var(22)
var(15) = 0
ignorehitpause = 1

[State 3000, Superpause FX]
type = helper
trigger1 = animelem = 4
stateno = 8500
ID = 8500
name = "Superpause FX"
postype = p1
pos = 10,-80
supermovetime = 255
size.xscale = 1
size.yscale = 1
ownpal = 1

[State 3000, Superpause]
type = superpause
trigger1 = animelem = 4
time = 40
movetime = 40
p2defmul = 1
unhittable = 1
anim = -1
sound = s8500,0
darken = 0


[STate 3100,2]
type=NotHitBy
trigger1=Time<=22
value=SAC

[State 3100,4]
type=Changestate
trigger1=Animtime=0
value=3105

[Statedef 3101]
type=S
physics=N
movetype=A
ctrl=0
velset=0,0
sprpriority=1
poweradd=-1000
facep2=1

[State 3000, Anim]
type=changeanim
trigger1=!time
value=3101

[state 3000,Posset]
type=posset
trigger1=!time
y=0

[State 3000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 3000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 3000, Super Cancel Flag]
type = varset
trigger1 = !time
var(21) = ((prevstateno = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = varset
trigger1 = !time
var(22) = (prevstateno = [3000, 4999]) && var(8)

[State 3000, CC Reset]
type = palfx
trigger1 = !time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = varset
trigger1 = time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 40

[State 3000, Super Cancel Flash]
type = palfx
trigger1 = var(21) || var(22)
trigger1 = !(time % 2) && time <= 12
time = 1
add = 255, 255, 255
ignorehitpause = 1

[State 3000, Super Cancel Juggle]
type = varset
trigger1 = !time
trigger1 = var(21) || var(22)
var(15) = 0
ignorehitpause = 1

[State 3000, Superpause FX]
type = helper
trigger1 = animelem = 4
stateno = 8500
ID = 8500
name = "Superpause FX"
postype = p1
pos = 10,-80
supermovetime = 255
size.xscale = 1
size.yscale = 1
ownpal = 1

[State 3000, Superpause]
type = superpause
trigger1 = animelem = 4
time = 40
movetime = 40
p2defmul = 1
unhittable = 1
anim = -1
sound = s8500,0
darken = 0


[State 3100,4]
type=Changestate
trigger1=Animtime=0
value=3106
;========================
[Statedef 3105]
type=S
movetype=A
physics=N
velset=0,0
anim=3130
ctrl=0
juggle = 15

[STate 3105,1]
type=VelSet
trigger1=Animelem=1
x=8

[STate 3100]
type=AssertSpecial
trigger1=enemy,stateno = 1090
flag=nojugglecheck

[State 1010, 2]
type = HitDef
trigger1 =movecontact=0&&Vel X!=0
attr = S,HA
damage    = 0,0
getpower=0,0
hitflag=MAF
guardflag = MA
priority = 7
pausetime = 5,5
guard.pausetime=10,10
animtype = hard
ground.type = high
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -3
air.velocity = -2,-4
p2facing = 1
p1stateno = 3110
p2stateno = 3140
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-70
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48

[STate 3105,3]
type=AfterImage
trigger1=Time=0
time=1000
trans=Add1
length=10

[State 3105,4]
type=Changestate
trigger1=time=20
trigger2=P2Bodydist X<=0&&P2statetype=L
trigger3=FrontedgeBodydist<=0&&Time>=12
value=3108

[State 3105,4]
type=Changestate
trigger1=Moveguarded=1
value=3109

[Statedef 3106]
type=S
movetype=A
physics=N
velset=0,0
anim=3130
ctrl=0
juggle = 15

[STate 3105,1]
type=VelSet
trigger1=Animelem=1
x=8

[STate 3100]
type=AssertSpecial
trigger1=enemy,stateno = 1090
flag=nojugglecheck

[State 1010, 2]
type = HitDef
trigger1 =movecontact=0&&Vel X!=0
attr = S,HA
damage    = 0,0
getpower=0,0
hitflag=MAF
guardflag = MA
priority = 7
pausetime = 5,5
guard.pausetime=10,10
animtype = hard
ground.type = high
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -3
air.velocity = -2,-4
p2facing = 1
p1stateno = 3110
p2stateno = 3140
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-70
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[STate 3105,3]
type=AfterImage
trigger1=Time=0
time=1000
trans=Add1
length=10

[State 3105,4]
type=Changestate
trigger1=time=32
trigger2=P2Bodydist X<=0&&P2statetype=L
trigger3=FrontedgeBodydist<=0&&Time>=20
trigger4=Moveguarded=1
value=3108

[State 3105,4]
type=Changestate
trigger1=Moveguarded=1
value=3109

[Statedef 3108]
type=S
movetype=I
physics=S
velset=0,0
anim=3105
ctrl=0

[STate 3105,3]
type=AfterImagetime
trigger1=Time=0
time=0

[State 3105,4]
type=Changestate
trigger1=animtime=0
value=0
ctrl=1

[Statedef 3109]
type=S
movetype=I
physics=S
velset=0,0
anim=3106
ctrl=0

[STate 3105,3]
type=AfterImagetime
trigger1=Time=0
time=0

[State 3105,4]
type=Changestate
trigger1=animtime=0
value=0
ctrl=1

[Statedef 3110]
type=S
movetype=A
physics=S
velset=0,0
anim=3110
ctrl=0

[State 3102,5]
type=NotHitBy
trigger1=1
value=SAC

[State 3110,0]
type=POsAdd
trigger1=Time=0&&Frontedgebodydist<=30
x=-30

[State 3110,0]
type=TargetBind
trigger1 = animelem = 53,<=0
pos=40,0

[State 1010, 2]
type = HitDef
trigger1 =animelem=3
trigger2=Animelem=17
trigger3=Animelem=27
trigger4=Animelem=39
trigger5=Animelem=51
attr = S,HA
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 4
getpower=0,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 0,5
guard.pausetime=0,5
animtype = hard
ground.type = high
ground.slidetime = 25
ground.hittime  = 30
ground.velocity = 0
air.velocity = -2,-4
p2facing = 1
kill=0
p2stateno = 3140
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-70
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 1010, 2]
type = HitDef
trigger1 =animelem=7
trigger2=Animelem=12
trigger3=Animelem=23
trigger4=Animelem=32
trigger5=Animelem=37
trigger6=Animelem=43
attr = S,HA
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 4
getpower=0,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 0,5
guard.pausetime=0,5
animtype = hard
ground.type = low
ground.slidetime = 25
ground.hittime  = 30
ground.velocity = 0
air.velocity = -2,-4
p2facing = 1
kill=0
p2stateno = 3141
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-30
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 1010, 2]
type = HitDef
trigger1 =animelem=52
attr = S,HA
damage    = 80/(hitcount+1)
getpower=0,0
hitflag=MAF
guardflag = MA
priority = 7
pausetime = 0,10
guard.pausetime=0,10
animtype = hard
ground.type = high
ground.slidetime = 45
ground.hittime  = 50
ground.velocity = -3
air.velocity = -2,-4
p2facing = 1
kill=0
p2stateno=5300
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-80
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[STate 3105,3]
type=AfterImage
trigger1=Time=0
time=1000
trans=Add1
length=8

[State 3105,4]
type=Changestate
trigger1=Animtime=0
value=3115

[State 3110,10]
type=PlayerPush
trigger1=FrontEdgebodydist>=50
value=0

[Statedef 3115]
type=S
movetype=A
physics=N
velset=-2,0
anim=3115
ctrl=0

[State 3102,5]
type=NotHitBy
trigger1=1
value=SAC

[State 3115,0]
type=VelAdd
trigger1=Time>=15
trigger1 = vel X<0
x=.1

[State 3115,0]
type=Velset
trigger1=Time>=15
trigger1 = vel X>=0
x=0

[State 3115,1]
type=Changestate
;trigger1=Time>=15
;trigger1=vel X>=0
trigger1 = animtime = 0
value=3120

[Statedef 3120]
type    = A
movetype= A
physics = N
juggle  = 0
velset = 0,0
ctrl = 0
anim = 3120
sprpriority = 2

[State 3102,5]
type=NotHitBy
trigger1=1
value=SAC

[State 1120,1]
type=Width
trigger1=1
value=10,0

[State 1120,2]
type=PlayerPush
trigger1=1
value=1

[STate 3120]
type=Velset
trigger1=animelem=5
x=5
y=-5

[STate 1050,0]
type=VelAdd
trigger1=animelem=5,>=0
y=.3

[STate 1120,3]
type=PlaySnd
trigger1=Animelem=6
value=1,1
channel=1

[STate 1120,3]
type=PlaySnd
trigger1=Animelem=5
value=4,3
channel=0

[State 1010, 2]
type = HitDef
trigger1 =animelem=9
attr = S, HA
damage    = 50
getpower=0,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 25,30
guard.pausetime=30,30
animtype =digup
ground.type = high
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -4,-6
air.velocity = -2,-6
can.recover=0
fall=1
fall.recover=0
envshake.time=20
envshake.ampl=8
p2stateno = 3150
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120


[State 1010,1]
type=Changestate
trigger1=pos Y>10&&Vel Y>0
value=3130

[State 3110,10]
type=bgpalfx
trigger1 =animelem=9
time=1
value=255,255,255
under=0

[Statedef 3130]
type    = S
movetype= I
physics = S
juggle  = 0
velset = 0,0
ctrl = 0
anim = 3125
sprpriority = 2

[STate 3105,3]
type=AfterImagetime
trigger1=Time=0
time=0

[STate 1050,2]
type=Explod
trigger1=Time=0
anim=8102
ownpal=1
pos=0,0
postype=p1
sprpriority=-3
scale = .5,.5

[STate 1330,2]
type=PlaySnd
trigger1=Time=0
value=1,12
channel=1

[STate 1130,0]
type=posset
trigger1=1
y=0

[State 1130,1]
type=Changestate
trigger1=animtime=0
value=0
ctrl=1
[State 3102,5]
type=NotHitBy
trigger1=1
value=SAC

[Statedef 3140]
type=S
movetype=H
physics=S
velset=0,0
anim=5002
ctrl=0

[STate 3140]
type=PosSet
trigger1 = 1
y = 0

[STate 3140]
type=statetypeset
trigger1 = 1
value = S

[State 3140]
type = selfstate
trigger1 = time = 20
value = 5100


[Statedef 3141]
type=S
movetype=H
physics=S
velset=0,0
anim=5012
ctrl=0

[STate 3140]
type=PosSet
trigger1 = 1
y = 0

[STate 3140]
type=statetypeset
trigger1 = 1
value = S

[State 3140]
type = selfstate
trigger1 = time = 20
value = 5100
;---------------------------------------------------------------------------

[Statedef 3150]
type    = A
movetype= H
physics = N
poweradd= 80
ctrl = 0
sprpriority = -2
velset=0,0

[State 3150]
type = changeanim2
trigger1 = time=0
value = 3145

[State 3150]
type = velset
trigger1 = animelem=2
x=-5
y=-5

[State 3150]
type = veladd
trigger1 = animelem=2,>=0
y=.4

[State 3150]
type = changestate
trigger1 = pos Y>=20 && vel Y>0
value = 3155
;---------------------------------------------------------------------------

[Statedef 3155]
type    = L
movetype= H
physics = S
poweradd= 0
ctrl = 0
sprpriority = -2
velset=-9,0

[State 1040]
type = changeanim2
trigger1 = time=0
value = 1040

[State 1040]
type = posset
trigger1 = time=0
y=0

[State 1040]
type = makedust
trigger1 = time <= 10
pos = -20,0
spacing = 1

[State 1040]
type = selfstate
trigger1 = alive = 0
trigger1 = animtime=0
value = 5150

[State 1040]
type = selfstate
trigger1 = alive
trigger1 = animtime=0
value = 5120

;Max Diablo Amarillo Ramon
[Statedef 3300]
type=S
movetype=A
physics=N
poweradd=-2000
ctrl=0
velset=0,0
sprpriority=1
facep2=1

[State 3050, Anim]
type=changeanim
trigger1=!time
value=3100

[state 3050,Posset]
type=posset
trigger1=!time
y=0

[State 3050, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 40

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, Super Pause FX]
type = Helper
trigger1 = animelem = 4
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = 10,-80
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3050, Super Pause]
type = SuperPause
trigger1 = animelem = 4
time = 40
moveTime = 40
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0


[STate 3100,2]
type=NotHitBy
trigger1=Time<=29
value=SAC

[STate 3000,1]
type=envcolor
trigger1=Time=0
value=0,0,0
time=33
under=1


[State 3300,4]
type=Changestate
trigger1=Animtime=0
value=3305

[Statedef 3305]
type=S
movetype=A
physics=N
velset=0,0
anim=3130
ctrl=0
juggle = 14

[STate 3105,3]
type=AfterImage
trigger1=Time=0
time=1000
trans=Add1
length=8

[STate 3105,1]
type=VelSet
trigger1=Animelem=1
x=8

[STate 3300]
type=AssertSpecial
trigger1=enemy,stateno = 1090
flag=nojugglecheck

[State 3310, 2]
type = HitDef
trigger1 =movecontact=0&&Vel X!=0
attr = S,HA
damage    = 0,0
getpower=0,0
hitflag=MAF
guardflag = MA
priority = 7
pausetime = 5,5
guard.pausetime=10,10
animtype = hard
ground.type = high
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -3
air.velocity = -2,-4
p2facing = 1
p1stateno = 3310
p2stateno = 3140
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-70
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120



[State 3305,4]
type=Changestate
trigger1=time=35
trigger2=P2Bodydist X<=0&&P2statetype=L
trigger3=FrontedgeBodydist<=0&&Time>=20
trigger4=Moveguarded=1
value=3108

[State 3305,4]
type=Changestate
trigger1=Moveguarded=1
value=3109


[Statedef 3310]
type=A
movetype=A
physics=N
velset=0,0
anim=3300
ctrl=0

[State 3102,5]
type=NotHitBy
trigger1=1
value=SAC

[State 3310,0]
type=POsAdd
trigger1=Time=0&&Frontedgebodydist<=30
x=-30

[State 3310,0]
type=POsAdd
trigger1=Time=0&&backedgebodydist<=30
x=40

[State 3310,0]
type=TargetBind
trigger1 = animelem = 105,<=0
pos=40,0

[State 3310]
type = playsnd
trigger1 = animelem = 9
value =0,48

[State 1010, 2]
type = HitDef
trigger1 =animelem=4
trigger2=Animelem=20
trigger3=Animelem=31
trigger4=Animelem=44
trigger5=Animelem=55
trigger6=Animelem=64
trigger7=Animelem=69
trigger8=Animelem=75
trigger9=Animelem=86
trigger10=Animelem=95
attr = S,HA
damage = ceil(ifElse(fvar(11) * 10 < 7, 7, fvar(11) * 10)), 4
getpower=0,0
givepower = 10,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 0,5
guard.pausetime=0,5
animtype = hard
ground.type = high
ground.slidetime = 25
ground.hittime  = 30
ground.velocity = 0
air.velocity = -2,-4
p2facing = 1
kill=0
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-70
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 1010, 2]
type = HitDef
trigger1 =animelem=13
trigger2=Animelem=26
trigger3=Animelem=37
trigger4=Animelem=52
trigger5=Animelem=60
trigger6=Animelem=101
attr = S,HA
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 4
getpower=0,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 0,5
guard.pausetime=0,5
animtype = hard
ground.type = low
ground.slidetime = 25
ground.hittime  = 30
ground.velocity = 0
air.velocity = -2,-4
p2facing = 1
kill=0
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-30
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 1010, 2]
type = HitDef
trigger1 =animelem=106
attr = S,HA
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 4
getpower=0,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 10,20
guard.pausetime=0,10
animtype = hard
ground.type = high
ground.slidetime = 45
ground.hittime  = 50
ground.velocity = -3
air.velocity = -2,-4
p2facing = 1
kill=0
p2stateno=5310
envshake.time = 10
envshake.ampl = 6
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3310,10]
type=PlayerPush
trigger1=FrontEdgebodydist>=50
value=0


[State 3310]
type = playsnd
trigger1 = animelem = 113
value =1,25

[State 3310]
type = velset
trigger1 = animelem = 113
x = -5
y = -8

[State 3310]
type = veladd
trigger1 = animelem = 113,>=0
y = .5

[State 3105,4]
type=Changestate
trigger1=pos Y>=5 && vel Y>0
value=3330
;---------------------------------------------------------------------------

[Statedef 3330]
type    = A
movetype= A
physics = N
juggle  = 0
velset = 0,0
ctrl = 0
anim = 3310
sprpriority = 2

[STate 3105,3]
type=AfterImage
trigger1=Time=0
time=1000
trans=Add1
length=8

[STate 3330]
type=Explod
trigger1=Time=0
anim=8102
ownpal=1
pos=0,0
postype=p1
sprpriority=-3
scale = .5,.5

[STate 3330]
type=PlaySnd
trigger1=Time=0
value=1,12

[State 3330]
type = posset
trigger1 = time = 0
y = 0

[State 3330]
type = HitDef
trigger1 =animelem=22
attr = A,HA
damage = ceil(ifElse(fvar(11) * 80 < 7, 7, fvar(11) * 80)), 4
getpower=0,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 15,15
guard.pausetime=0,10
animtype = digup
ground.type = high
ground.slidetime = 45
ground.hittime  = 50
ground.velocity = -5,-5
air.velocity = -5,-5
p2facing = 1
fall = 1
fall.recover = 0
envshake.time = 10
envshake.ampl = 8
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-80
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3310]
type = playsnd
trigger1 = animelem = 2
value =0,44

[State 3310]
type = playsnd
trigger1 = animelem = 18
value =0,34

[State 3310]
type = playsnd
trigger1 = animelem = 18
value =0,34

[State 3310]
type = playsnd
trigger1 = animelem = 20
value =0,35

[State 3310]
type = playsnd
trigger1 = animelem = 20
value =0,36

[State 3310,10]
type=PlayerPush
trigger1=FrontEdgebodydist>=50
value=0


[State 3310]
type = playsnd
trigger1 = animelem = 18
value = 1,22

[State 3310]
type = velset
trigger1 = animelem = 18
x = 10
y = -6.6

[State 3310]
type = veladd
trigger1 = animelem = 18,>=0
y = .5

[State 3105,4]
type=Changestate
trigger1=pos Y>=15 && vel Y>0
value=1540

;Savage Fire Cat
[Statedef 3500]
type    = S
movetype= I
physics = S
velset = 0,0
ctrl = 0
anim = 1500
sprpriority = 2
poweradd=-1000

[State 1500]
type = varset
trigger1 = time = 0
var(19) = 0



[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 0,23
channel=0

[State 1500]
type = turn
trigger1 = animtime = 0

[State 1500]
type = changestate
trigger1 = animtime = 0
value = 3510

;======================================
[Statedef 3510]
type    = S
movetype= I
physics = N
velset = 10,0
ctrl = 0
anim = 1510
sprpriority = 2
poweradd=0

[State 3510]
type = changestate
trigger1 = frontedgebodydist <= 40
trigger2 = time >= 60
value = 3520
;======================================

[Statedef 3520]
type    = A
movetype= I
physics = N
velset = 0,0
ctrl = 0
anim = 1520
sprpriority = 2
poweradd=0

[STate 1520]
type=ScreenBound
trigger1=1
value=1
movecamera=0,1

[State 1520]
type = velset
trigger1 = animelem=3
x = 4
y = -10
persistent=0

[State 1520]
type = veladd
trigger1 = animelem=3,>=0
y = .4

[State 1510]
type = changestate
trigger1 = frontedgebodydist <= 15
trigger1 = animelem =4, >=0
value = 3530

[State 1510]
type = changestate
trigger1 = pos Y>=10 && vel Y>0
value = 52
ctrl=1
facing = -1
;======================================
[Statedef 3530]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 3530
sprpriority = 2
poweradd=0

[State 1530]
type = turn
trigger1 = time = 0

[STate 3000,1]
type=envcolor
trigger1=Time=0
value=0,0,0
time=25
under=1


[State 3000, Superpause FX]
type = helper
trigger1 = animelem = 2
stateno = 8500
ID = 8500
name = "Superpause FX"
postype = p1
pos = 0,-60
supermovetime = 255
size.xscale = 1
size.yscale = 1
ownpal = 1
sprpriority = -1


[State 3000,5]
type = SuperPause
trigger1 = animelem = 2
movetime = 13
time = 25
anim = -1
sound = s8500,0
p2defmul = 1

[State 1530]
type = posset
trigger1 = Animelem = 1,>=0
trigger1 = Animelem = 3,<=0
y = -60
x = ifelse(facing=1,-360,360)

[State 1530]
type = velset
trigger1 = animelem=3
x = 2
y = -5

[State 1530]
type = veladd
trigger1 = animelem=3,>=0
y = .4

[State 1530]
type = changestate
trigger1 = animtime = 0
value = 3550

[State 1530]
type = changestate
trigger1 = pos Y>=0 && vel Y>0
value = 1540
;======================================
[Statedef 3550]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 1550
sprpriority = 2
poweradd=0

[STate 3105,3]
type=AfterImage
trigger1=Time=0
time=1000
trans=Add1
length=8


[State 1550]
type = velset
trigger1 = time <= 3
y=-((p2dist Y)/60)-2

[State 1550]
type = velset
trigger1 = time <= 5
x=((p2dist X)/25)+.5

[State 1550]
type = veladd
trigger1 = 1
y = .5

[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 1,22

[State 1550]
type = varset
trigger1 = time =0
var(19) = 0

[State 1550]
type = HitDef
trigger1 =animelem=4
attr = A, HA
damage    = 0,1
guardflag =
priority = 5
pausetime = 10,10
animtype = hard
ground.type = low
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = -7
air.velocity = -5,-4
getpower=0,0
givepower=100,50
ground.cornerpush.veloff = -15
guard.cornerpush.veloff = -10
fall=1
fall.recover=0
p1stateno = 3560
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120


[State 3500]
type=Afterimage
trigger1=Time=0
time=1000
trans=add1
length=10

[State 1550]
type = changestate
trigger1 = pos Y>=15 && vel Y>0
value = 1540

;======================================

[Statedef 3560]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 3500
sprpriority = 2

[STate 3105,3]
type=AfterImage
trigger1=Time=0
time=1000
trans=Add1
length=8


[State 3560]
type = targetBind
trigger1 = time = 0
pos = 10,-30

[State 3560]
type = playsnd
trigger1 = animelem = 1
value =0,48

[State 3550]
type = HitDef
trigger1 =animelem=3
trigger2 = animelem = 10
trigger3 = animelem = 19
trigger4 = animelem = 32
trigger5 = animelem = 36
trigger6 = animelem = 45
trigger7 = animelem = 51
attr = A, HA
damage    = 70/(hitcount+1)
guardflag =
priority = 7
pausetime = 0,4
animtype = hard
ground.type = high
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = 0,-2
air.velocity = 0,-1.5
getpower=0,0
givepower=10,5
fall=1
fall.recover=0
kill = 0
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-75
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3550]
type = HitDef
trigger1 =animelem=14
trigger2 = animelem = 10
trigger3 = animelem = 25
trigger4 = animelem = 40
attr = A, HA
damage    = 70/(hitcount+1)
guardflag =
priority = 7
pausetime = 0,4
animtype = hard
ground.type = low
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = 0,-2
air.velocity = 0,-1.5
getpower=0,0
givepower=10,5
fall=1
fall.recover=0
kill = 0
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-50
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3550]
type = HitDef
trigger1 =animelem=58
attr = A, HA
damage    = 50
guardflag =
priority = 7
pausetime = 8,12
animtype = digup
ground.type = high
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = -5,-5
air.velocity = -6,-5
getpower=0,0
givepower=10,5
fall=1
fall.recover=0
envshake.time = 12
envshake.ampl = 10
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3510]
type = velset
trigger1 = animelem = 59
x = 2

[State 3510]
type = veladd
trigger1 = animelem = 59,>=0
y = .5


[State 3510]
type = changestate
trigger1 = pos Y >10 && vel Y>0
value = 3570
;---------------------------------------------------------------------------

[Statedef 3570]
type    = S
movetype= I
physics = S
poweradd= 0
ctrl = 0
anim = 3510
sprpriority = 2
velset=0,0

[STate 3105,3]
type=AfterImage
trigger1=Time=0
time=1000
trans=Add1
length=8


[State 3570]
type=PosSet
trigger1=Time=0
y=0

[State 3570]
type=varSet
trigger1=Time=0
var(21)=0

[STate 3570]
type=Explod
trigger1=animelem=1
anim=8102
ownpal=1
pos=0,0
postype=p1
sprpriority=-3
scale = .5,.5

[State 3570]
type = playsnd
trigger1 = animelem = 1
value =1,12

[State 3570]
type=Afterimagetime
trigger1=Time=0
time=0

[State 3570]
type=ChangeState
trigger1=Animtime=0
value=0
ctrl=1

;Hyper Hypnotic Tiger
[Statedef 3700]
type=S
movetype=A
physics=N
velset=0,0
anim=3700
ctrl=0
juggle=0
poweradd=-3000


[STate 3700,2]
type=NotHitBy
trigger1=time = 0
value=SAC
time = 55


[State 3500, Super Pause FX]
type = Helper
trigger1 = Time = 14
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = 0,-80
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3700]
type = playsnd
trigger1 = animelem = 1
value =0,17

[State 3700,5]
type = SuperPause
trigger1 = animelem = 7
movetime = 30
time = 30
anim = -1
sound = s8500,0
p2defmul = 1

[State 3700]
type = velset
trigger1 = animelem = 11
x = 12

[State 3550]
type = HitDef
trigger1 =animelem=11
attr = S, HA
damage    = 30,10
guardflag = M
priority = 7,miss
pausetime = 5,5
animtype = high
ground.type = high
ground.slidetime = 20
ground.hittime  = 22
ground.velocity = 0
air.velocity = -.5,-5
getpower=0,0
givepower=10,5
p1stateno = 3710
p2facing = 1
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-60
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120
kill = 0

[State 3700]
type=Changestate
trigger1=time>=68
trigger2=P2Bodydist X<=0&&P2statetype=L
trigger3=FrontedgeBodydist<=0&&vel X>0
value=3108

[State 3700]
type=Changestate
trigger1=Moveguarded=1
value=3109

;========================

[Statedef 3710]
type=S
movetype=A
physics=N
velset=0,0
anim=3710
ctrl=0

[State 3710]
type = posadd
trigger1 = time = 0
trigger1 = backedgebodydist <=60
x = 70

[State 3710]
type = targetbind
trigger1 = animelem = 140,<=0
pos = 30,0

[State 3710]
type = velset
trigger1 =animelem=5
x = .4


[State 3710]
type = HitDef
trigger1 =animelem=5
trigger2 =animelem=22
trigger3 =animelem=33
trigger4 =animelem=39
trigger5 =animelem=59
trigger6 =animelem=64
trigger7 =animelem=77
trigger8 =animelem=93
trigger9 =animelem=109
attr = S, HA
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 4
guardflag =
priority = 7
pausetime = 0,5
animtype = heavy
ground.type = high
ground.slidetime = 50
ground.hittime  = 60
ground.velocity = 0
air.velocity = -.5,-5
getpower=0,0
givepower=10,5
kill = 0
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-70
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3710]
type = HitDef
trigger1 =animelem=3
trigger2 =animelem=13
trigger3 =animelem=45
trigger4 =animelem=52
trigger5 =animelem=123
trigger6 =animelem=130
trigger7 =animelem=134
attr = S, HA
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 4
guardflag =
priority = 7
pausetime = 0,5
animtype = heavy
ground.type = low
ground.slidetime = 50
ground.hittime  = 60
ground.velocity = 0
air.velocity = -.5,-5
getpower=0,0
givepower=10,5
kill = 0
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-40
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

;/////////////////////////////
[State 3710]
type = velset
trigger1 =animelem=73
trigger2 = frontedgebodydist <= 40
x = 0

[State 1610]
type = targetstate
trigger1 = animelem = 141
value = 3720

[State 1610]
type = targetbind
trigger1 = animelem = 141
pos = 55,-70

[State 1610]
type = targetbind
trigger1 = animelem = 142
pos = 55,-60

[State 1610]
type = targetbind
trigger1 = animelem = 143
trigger2 = animelem = 144
pos = 65,-60

[State 1610]
type = targetbind
trigger1 = animelem = 145
pos = 60, -65

[State 1610]
type = targetbind
trigger1 = animelem = 146
pos = 60,-55

[State 1610]
type = targetbind
trigger1 = animelem = 147
pos = 55,-45

[State 1610]
type = targetbind
trigger1 = animelem = 148
pos = 10,-50

[State 1610]
type = targetbind
trigger1 = animelem = 149
pos = 0,-60

[State 1610]
type = targetbind
trigger1 = animelem = 150
pos = -5,-60

[State 1610]
type = targetbind
trigger1 = animelem = 151
pos = -20,0

[State 1610]
type = targetbind
trigger1 = animelem = 152
pos = -40,0

[State 1610]
type = targetstate
trigger1 = animelem = 152
value = 3760

[State 1610]
type = sprpriority
trigger1 = animelem = 149
value = 2

[State 1610]
type=Explod
trigger1=Animelem=142
anim=f81
pos=55,-60
sprpriority = 1
ownpal=1

[State 1610]
type = playsnd
trigger1 = animelem = 142
value =1,21

[STate 1610]
type=PlaySNd
trigger1=Animelem=55
value=0,48

[STate 1610]
type=PlaySNd
trigger1=Animelem=146
value=0,49

[State 99,99]
type = PlaySnd
trigger1 =animelem=150
value =1,26
channel=1

[State 1610]
type = turn
trigger1 = animtime = 0

[State 3730]
type = null;changestate
trigger1 = enemy,stateno = 3770
trigger1 = p2bodydist X <= 150
value = 3735

[State 1610]
type = changestate
trigger1 = animtime = 0
value = 3730

;---------------------------------------------------------------------------

[Statedef 3720]
type=S
movetype=H
physics=N
velset=0,0
ctrl=0
poweradd=0
sprpriority=1

[STate 3720]
type=ChangeAnim2
trigger1=Time=0
value=3720

[State 3720]
type = Screenbound
trigger1 = 1
value = 0
;---------------------------------------------------------------------------

[Statedef 3730]
type=S
movetype=A
physics=S
velset=0,0
ctrl=0
anim=0
sprpriority=-2
poweradd=0

[State 3730]
type = changestate
trigger1 = enemy,stateno = 3770
;trigger1 = p2bodydist X <= 150
trigger2 = time >= 10
trigger2 = enemy,stateno = 3765
trigger2 = p2bodydist X <= 70
value = 3800

[State 3730]
type = null;changestate
trigger1 = time >= 5
trigger1 = enemy,stateno = 3765
trigger1 = p2bodydist X <= 70
value = 3750

[State 1630]
type = ctrlset
trigger1 = p2bodydist X <= -20
value = 1

;---------------------------------------------------------------------------

[Statedef 3750]
type    = A
movetype= A
physics = N
poweradd= 0
ctrl = 0
anim = 3750
sprpriority = 2
velset=0,0

[State 1100]
type=varSet
trigger1=Time=0
var(21)=0

[State 1100, 3]
type = HitDef
trigger1 =animelem=8
attr = A, HA
damage    = 220
guardflag = HA
priority = 4
pausetime = 8,8
animtype = digup
ground.type = High
ground.slidetime = 16
ground.hittime  = 18
ground.velocity = -4,-4
air.velocity = -4,-4
getpower=150,75
fall=1
fall.recover = 0
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-40
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 1130]
type = velset
trigger1 = animelem= 4
x=5
y=-5

[State 1500]
type = playsnd
trigger1 = animelem = 1
value = 0,12
channel = 0

[State 1685]
type = playsnd
trigger1 = animelem = 4
value = 1,25

[State 1130]
type = veladd
trigger1 = animelem= 4,>=0
y=.3

[STate 3750]
type=AfterImagetime
trigger1=animTime=0
time=0

[State 3750]
type = changestate
trigger1 = Animtime = 0
value = 1140

;---------------------------------------------------------------------------

[Statedef 3760]
type=S
movetype=H
physics=N
velset=0,0
ctrl=0
poweradd=100
sprpriority=2
anim = 100

[STate 1220]
type=ChangeAnim
trigger1=Time=0
trigger1=animexist(100)=0
value=20

[STate 1220]
type=ChangeAnim2
trigger1=Time=0
trigger1=name ="Tin's potemkin"
value=1625

[State 1620]
type=VelSet
trigger1=1
x=10

[State 1625]
type = changestate
trigger1 = frontedgebodydist <= 10
value = 3765

[State 1625]
type = playerpush
trigger1 = 1
value = 0
;---------------------------------------------------------------------------

[Statedef 3765]
type=S
movetype=H
physics=S
velset=0,0
ctrl=0
poweradd=0
sprpriority=2

[STate 1220]
type=ChangeAnim2
trigger1=Time=0
value=1640

[State 1640]
type = turn
trigger1 =  time = 0

[State 1620]
type=VelSet
trigger1=animelem = 2
x=-2

[State 1625]
type = changestate
trigger1 = animtime = 0
value = 3770

;---------------------------------------------------------------------------

[Statedef 3770]
type=S
movetype=H
physics=N
velset=0,0
ctrl=0
poweradd=0
sprpriority=2
anim = 100

[STate 1220]
type=ChangeAnim
trigger1=Time=0
trigger1=animexist(100)=0
value=20

[STate 1220]
type=ChangeAnim2
trigger1=Time=0
trigger1=name ="Tin's potemkin"
value=1625

[State 1620]
type=VelSet
trigger1=1
x=5.5

[State 1620]
type=Veladd
trigger1=time >= 15
x=1

[State 1625]
type = playerpush
trigger1 = 1
value = 0

[State 3770]
type=SelfState
trigger1 = frontedgebodydist <= 10
value=5100

;========================

[Statedef 3800]
type=S
movetype=A
physics=N
velset=0,0
anim=3810
ctrl=0

[STate 3105,1]
type=VelSet
trigger1=Animelem=1
x=8

[State 1625]
type = changestate
trigger1 = (p2bodydist X=[80,130]) && random <= 80 && time >= 3
value = 3750
persistent = 0

[State 1010, 2]
type = HitDef
trigger1 =movecontact=0
attr = S,HA
damage    = 0,0
getpower=0,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 5,5
guard.pausetime=10,10
animtype = hard
ground.type = high
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -3
air.velocity = -2,-4
p2facing = 1
p1stateno = 3810
p2stateno = 3820
numhits = 0
hitsound = -1 + 0*(var(31):=6)
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-70
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[STate 3105,3]
type=AfterImage
trigger1=Time=0
time=1000
trans=Add1
length=10

[State 3105,4]
type=Changestate
trigger1=time=80
value=3108

[State 3105,4]
type=Changestate
trigger1=Moveguarded=1
value=3109

;//////////////////////////////////////
[Statedef 3810]
type    = A
movetype= A
physics = N
velset = 0,0
ctrl = 0
anim = 3800
sprpriority = 2
poweradd=0

[State 1310]
type = posadd
trigger1 = time = 0
trigger1 = backedgebodydist <= 50
x = 50

[State 1310]
type = targetbind
trigger1 = time = 0
pos = 20,0

[State 1310]
type = BindToTarget
trigger1 = animelem = 5
pos = 0,0,mid

[State 1310]
type = BindToTarget
trigger1 = animelem = 6
pos = -5,0,mid

[State 1310]
type = BindToTarget
trigger1 = animelem = 7
pos = -10,0,mid

[State 1310]
type = posadd
trigger1 = animelem = 8
x = -40

[State 1310]
type = targetlifeadd
trigger1 = animelem = 6
value = -50 - var(7)*15
kill=0

[State 1310]
type = velset
trigger1 = animelem = 8
y = -7

[State 1310]
type = veladd
trigger1 = animelem = 8,>=0
y = .4



[State 1310]
type = Helper
trigger1 = Animelem = 6
stateno = 8013
id = 8013
pos = 0,0
ownpal = 1
sprpriority = 3

[State 1800]
type = playsnd
trigger1 = animelem = 2
value =1,21

[State 1800]
type = playsnd
trigger1 = animelem = 6
value =1,11

[State 1800]
type = playsnd
trigger1 = animelem = 7
value =0,10

[State 1310]
type = changestate
trigger1 =  animtime = 0 && random <= 700
value = 3830

[State 1310]
type = changestate
trigger1 =  animtime = 0
value = 3835

;========================
[Statedef 3830]
type=A
movetype=A
physics=N
anim=3830
ctrl=0

[STate 3105,1]
type=Veladd
trigger1=1
y = .4

[State 3830]
type = playsnd
trigger1 = time = 0
value =1,6

[State 1010, 2]
type = HitDef
trigger1 =movecontact=0
attr = S,HA
damage    = 100,0
getpower=0,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 15,15
guard.pausetime=10,10
animtype = digup
ground.type = high
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -5,-5
air.velocity = -5,-5
p2facing = 1
envshake.time = 10
envshake.ampl = 8
fall = 1
fall.recover = 0
hitsound = s1,11
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-50
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3830]
type = changestate
trigger1 = pos Y>=15 && vel Y>0
value = 1540
persistent = 0

;========================
[Statedef 3835]
type=A
movetype=A
physics=N
velset=.5,-2
anim=3835
ctrl=0

[STate 3105,1]
type=posadd
trigger1=time = 0
x = 15
y = -15

[STate 3105,1]
type=Veladd
trigger1=1
y = .4

[State 3830]
type = playsnd
trigger1 = time = 0
value =1,6

[State 1010, 2]
type = HitDef
trigger1 =movecontact=0
attr = S,HA
damage    = 120,0
getpower=0,0
hitflag=MAF
guardflag =
priority = 7
pausetime = 15,15
guard.pausetime=10,10
animtype = digup
ground.type = high
ground.slidetime = 15
ground.hittime  = 20
ground.velocity = -5,-5
air.velocity = -5,-5
p2facing = 1
envshake.time = 12
envshake.ampl = 15
fall = 1
fall.recover = 0
hitsound = s1,11
guardsound = -1 + 0*(var(32):=0)
sparkno = -1 + 0*(var(33):=8013)
guard.sparkno = -1 + 0*(var(34):=8000)
sparkxy = -10 + 0*(var(35):=63), var(36):=-40
palfx.time = 12*var(9)
palfx.add = 255,255,255
palfx.sinadd= -255,-255,-255,48
envshake.time = 14
envshake.ampl = 4
envShake.freq = 120

[State 3830]
type = changestate
trigger1 = pos Y>=15 && vel Y>0
value = 1540
persistent = 0
;---------------------------------------------------------------------------
[Statedef 3820]
type    = A
movetype= H
physics = N
poweradd= 50
ctrl = 0
sprpriority = -2
velset=0,0

[State 1135]
type = changeanim2
trigger1 = time=0
value = 3820

[State 1310]
type = posadd
trigger1 = animelem = 4
trigger2 = animelem = 5
x = -5
;---------------------------------------------------------------------------

[Statedef 3999]
type    = C
movetype= I
physics = C
poweradd= 0
ctrl = 0
anim = 3999
sprpriority = 2

[State 3999,0]
type=PosSet
trigger1=1
y=0

[state 3999,1]
type=VelSet
trigger1=Time=0
y=0

[State 3999,2]
type=NotHitBy
trigger1=1
value=SAC,NT,ST,HT

[State 3999,3]
type=Changestate
trigger1=Animtime=0
value=0
ctrl=1

[State 3999,4]
type=PalFx
trigger1=Time=0
add=255,255,255
time=5

[STate 3999,5]
type=PlaySnd
trigger1=Time=0
value=0,8

[State 3999,6]
type=VelAdd
trigger1=Time=0
trigger1=Vel X>0
x=8

[State 3999,7]
type=VelAdd
trigger1=Time=0
trigger1=Vel X<=0
x=-8

[STate 3999,8]
type=PlaySnd
trigger1=Time=0
value=1,12
channel=1
