             
======================| Rogue by Laslab Games|=========================== [2023 Version]            

 - Customized version of Kong's Rogue character, for Mugen 1.0

------------------<Features>---------------------

 - All essential stuff
 - Gameplay mixed from several games, including CvS2, KOF, SFZ3, and SF3
 - Various palettes to choose from
 - Color Separation(thanks Drex)
 - Palette Selector (Thanks to FalconTheRipper)
 - MAX Mode/Custom Combo Selection System (Thanks to POTS & DivineWolf)
 - Vans' Chizuru "Skill Lock" compatibility
 - Projectile Reflection compatibility
 - AI by Laslab Games

-----------------<Movelist>----------------------

 U = Up
 D = Down
 F = Forward
 B = Back
 UF = Up Forward
 UB = Up Back
 DF = Down Forward
 DB = Down Back
 LP = Light Punch
 MP = Medium Punch
 HP = Heavy Punch
 LK = Light Kick
 MK = Medium Kick
 HK = Heavy Kick
 S = Start

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>

 Axe Handle Toss			F(or B) + any 2 punches (grab)
 Diving Kick(Air)			D + HK
 Reverse Spin Kick			F + HK
 Air Dash(Air)				F, F or B,B
 Taunt					S

<SPECIALS>

 Repeating Punch(EX)			D, DF, F, + any punch (air ok!)
 Rising Repeating Punch(EX)		F, D, DF, + any punch
 Power Dive Punch(EX)			D, DB, B, + any punch
 Power Drain				D, DB, B, + any kick (air ok!)
 Steal Special(EX)			D, DF, F, + any kick (After stealing someone with power drain)

<SUPERS>

 Goodnight Sugar(MAX)			D, DF, F(x2), + any punch
 Hyper Repeating Punch(MAX)		D, DB, B(x2), + any punch
 Steal Super(MAX)			D, DF, F(x2), + any kick

<LV3 SUPERS>

 Goodbye Sugar				D, DB, B(x2), + any 2 kicks
 Power Punch Rush			D, DF, F, DF, D, DB, B, + any 2 punches
 Ultimate Repeating Punch		D, DF, F, DF, D, DB, B, + any 2 kicks
 Shun Goku Satsu			LP, LP, F + LK, HP (Cane be enabled in the config.txt)

<SYSTEM BUILD>

 -GROOVE GAUGE-

 (*)N + C + S Groove
  *Allows: MAX Mode/Custom Combo	HP + HK (Requires 1 power bar)
           Max Cancelling
           Special Cancelling
           Super Cancelling
           EX Specials
	   Power Charge			Hold MK + MP

 -SYSTEM MECHANICS-

 Parry = O 				Tap F(or D), timed with incoming High/Air/Low attacks respectively.
 Just Defense = X
 Chain Combo = X
 Air Chain Combo = X
 Super Combo Cancel = O
 Cancel Any Move = X

 -SUB SYSTEM MECHANICS-

 Dash = O 				Tap F, F,
 Run = O 				Tap F, F, then hold F
 Dodge = O 				LP + LK (While stationary, vulnerable to grabs)
 Dodge Attack = O 			Any punch or kick during Dodge
 Rolling = O 				F(or B) + LP + LK (Vulnerable to grabs)
 Small Jump = O 			Tap U
 Long Small Jump = O 	  		Tap D then U quickly
 Long Jump = O	        		D, then U
 Alpha Counter(Attack) = O		B, DB, D + any punch or kick while guarding an attack. (Requires 1 power bar)
 Safe Fall = O		    		Any 2 punches or LP + LK (While falling and allowed)
 Counter Movement = O			Tap F(or B) + LP + LK while guarding an attack. (Requires 1 power bar)
 Tactical Recovery = O			LP + LK/2P (while falling and allowed)
 Air Guard = O
 
----------------<Move Details>-------------------

 - Reverse Spin Kick is a overhead attack
 - LV1 & LV2 Goodnight Sugar and Goodbye Sugar finishes with Power Drain, enabling move steal too
 - When using Power Drain on characters that Rogue don't have steal moves, a random buff  is garanted, whichi can be Defense, Attack, Life, Power, Speed or Super Armor
 - EX Power Dive Punch leaves P2 in a longer hitstun on ground, allowing follow up attacks
 - EX Repeating Punch bounces foes off walls, allowing you to follow up with attacks
 - EX Rising Repeating Punch bounces foes off the floor, allowing you to follow up with attacks
  
---------------<Gameplay Notes>------------------

COMBO SYSTEM:
 - Most Normal standing/crouching attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Performing a Super/MAX Cancel resets the juggle points but also reduces damage dealt
   
MAX MODE:
 - Your attack and defense is increased while in MAX Mode
 - EX moves can be performed at no power cost, though take away from time sustained in MAX mode
 - All Lv1 supers can be performed at no power cost, though immediately uses up all time in MAX mode
 - All Lv2 and higher supers will cost 1 power bar, along with using up all time in MAX mode
 - Even without a power bar, as long as you have time left in MAX mode, you can perform Lv1 supers/EX moves
 - You can not Power Charge/gain power while in MAX mode
 - You can not perform a Alpha Counter/Counter Movement while in MAX Mode

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

-------------------<Disclaimer>----------------------

 - The Rogue character is property of Marvel
 - Capcom vs SNK is property of Capcom
 - This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes