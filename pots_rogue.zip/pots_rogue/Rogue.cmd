;-| Button Remapping |-----------------------------------------------------
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s
 
;-| Default Values |-------------------------------------------------------
[Defaults]
; Default value for the "time" parameter of a Command. Minimum 1.
command.time = 15
; Default value for the "buffer.time" parameter of a Command. Minimum 1,
; maximum 30.
command.buffer.time = 1

;-| Hyper |-----------------------------------------------------------------
[Command]
name = "Shun Goku Satsu"
command = x, x, F, a, z
time = 60
buffer.time = 1

[Command]
name = "Shun Goku Satsu"
command = x, x, F, a+z
time = 60
buffer.time = 1

[Command]
name = "MAX Steal Super"
command = ~D, DF, F, D, DF, F, a+b
time = 30
buffer.time = 1

[Command]
name = "MAX Steal Super"
command = ~D, DF, F, D, DF, F, b+c
time = 30
buffer.time = 1

[Command]
name = "MAX Steal Super"
command = ~D, DF, F, D, DF, F, a+c
time = 30
buffer.time = 1

[Command]
name = "Steal Super"
command = ~D, DF, F, D, DF, F, a
time = 30
buffer.time = 1

[Command]
name = "Steal Super"
command = ~D, DF, F, D, DF, F, b
time = 30
buffer.time = 1

[Command]
name = "Steal Super"
command = ~D, DF, F, D, DF, F, c
time = 30
buffer.time = 1

[Command]
name = "Ultimate Repeating Punch"
command = ~D, DF, F, DF, D, DB, B, a+b
time = 36
buffer.time = 1

[Command]
name = "Ultimate Repeating Punch"
command = ~D, DF, F, DF, D, DB, B, b+c
time = 36
buffer.time = 1

[Command]
name = "Ultimate Repeating Punch"
command = ~D, DF, F, DF, D, DB, B, a+c
time = 36
buffer.time = 1

[Command]
name = "MAX Goodnight Sugar"
command = ~D, DF, F, D, DF, F, x+y
time = 30
buffer.time = 1

[Command]
name = "MAX Goodnight Sugar"
command = ~D, DF, F, D, DF, F, y+z
time = 30
buffer.time = 1

[Command]
name = "MAX Goodnight Sugar"
command = ~D, DF, F, D, DF, F, x+z
time = 30
buffer.time = 1

[Command]
name = "Goodbye Sugar"
command = ~D, DB, B, D, DB, B, a+b
time = 30
buffer.time = 1

[Command]
name = "Goodbye Sugar"
command = ~D, DB, B, D, DB, B, b+c
time = 30
buffer.time = 1

[Command]
name = "Goodbye Sugar"
command = ~D, DB, B, D, DB, B, a+c
time = 30
buffer.time = 1

[Command]
name = "MAX Hyper Repeating Punch"
command = ~D, DB, B, D, DB, B, x+y
time = 30
buffer.time = 1

[Command]
name = "MAX Hyper Repeating Punch"
command = ~D, DB, B, D, DB, B, y+z
time = 30
buffer.time = 1

[Command]
name = "MAX Hyper Repeating Punch"
command = ~D, DB, B, D, DB, B, x+z
time = 30
buffer.time = 1

[Command]
name = "Power Punch Rush"
command = ~D, DF, F, DF, D, DB, B, x+y
time = 30
buffer.time = 1

[Command]
name = "Power Punch Rush"
command = ~D, DF, F, DF, D, DB, B, y+z
time = 30
buffer.time = 1

[Command]
name = "Power Punch Rush"
command = ~D, DF, F, DF, D, DB, B, x+z
time = 30
buffer.time = 1

;-| Super |-----------------------------------------------------------------
[Command]
name = "Goodnight Sugar"
command = ~D, DF, F, D, DF, F, x
time = 30
buffer.time = 1

[Command]
name = "Goodnight Sugar"
command = ~D, DF, F, D, DF, F, y
time = 30
buffer.time = 1

[Command]
name = "Goodnight Sugar"
command = ~D, DF, F, D, DF, F, z
time = 30
buffer.time = 1

[Command]
name = "Hyper Repeating Punch"
command = ~D, DB, B, D, DB, B, x
time = 30
buffer.time = 1

[Command]
name = "Hyper Repeating Punch"
command = ~D, DB, B, D, DB, B, y
time = 30
buffer.time = 1

[Command]
name = "Hyper Repeating Punch"
command = ~D, DB, B, D, DB, B, z
time = 30
buffer.time = 1

;-| EX Special |------------------------------------------------------------
[Command]
name = "EX Repeating Punch"
command = ~D, DF, F, x+y
time = 15
buffer.time = 1

[Command]
name = "EX Repeating Punch"
command = ~D, DF, F, y+z
time = 15
buffer.time = 1

[Command]
name = "EX Repeating Punch"
command = ~D, DF, F, x+z
time = 15
buffer.time = 1

[Command]
name = "EX Power Dive Punch"
command = ~D, DB, B, x+y
time = 15
buffer.time = 1

[Command]
name = "EX Power Dive Punch"
command = ~D, DB, B, y+z
time = 15
buffer.time = 1

[Command]
name = "EX Power Dive Punch"
command = ~D, DB, B, x+z
time = 15
buffer.time = 1

[Command]
name = "EX Rising Repeating Punch"
command = ~F, D, DF, x+y
time = 15
buffer.time = 1

[Command]
name = "EX Rising Repeating Punch"
command = ~F, D, DF, y+z
time = 15
buffer.time = 1

[Command]
name = "EX Rising Repeating Punch"
command = ~F, D, DF, x+z
time = 15
buffer.time = 1

[Command]
name = "EX Steal Move"
command = ~D, DF, F, a+b
time = 15
buffer.time = 1

[Command]
name = "EX Steal Move"
command = ~D, DF, F, b+c
time = 15
buffer.time = 1

[Command]
name = "EX Steal Move"
command = ~D, DF, F, a+c
time = 15
buffer.time = 1

;-| Special |---------------------------------------------------------------
[Command]
name = "Repeating Punch"
command = ~D, DF, F, x
time = 15
buffer.time = 1

[Command]
name = "Repeating Punch"
command = ~D, DF, F, y
time = 15
buffer.time = 1

[Command]
name = "Repeating Punch"
command = ~D, DF, F, z
time = 15
buffer.time = 1

[Command]
name = "Power Dive Punch"
command = ~D, DB, B, x
time = 15
buffer.time = 1

[Command]
name = "Power Dive Punch"
command = ~D, DB, B, y
time = 15
buffer.time = 1

[Command]
name = "Power Dive Punch"
command = ~D, DB, B, z
time = 15
buffer.time = 1

[Command]
name = "Power Drain"
command = ~D, DB, B, a
time = 15
buffer.time = 1

[Command]
name = "Power Drain"
command = ~D, DB, B, b
time = 15
buffer.time = 1

[Command]
name = "Power Drain"
command = ~D, DB, B, c
time = 15
buffer.time = 1

[Command]
name = "Rising Repeating Punch"
command = ~F, D, DF, x
time = 15
buffer.time = 1

[Command]
name = "Rising Repeating Punch"
command = ~F, D, DF, y
time = 15
buffer.time = 1

[Command]
name = "Rising Repeating Punch"
command = ~F, D, DF, z
time = 15
buffer.time = 1

[Command]
name = "Steal Move"
command = ~D, DF, F, a
time = 15
buffer.time = 1

[Command]
name = "Steal Move"
command = ~D, DF, F, b
time = 15
buffer.time = 1

[Command]
name = "Steal Move"
command = ~D, DF, F, c
time = 15
buffer.time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1
buffer.time = 1
 
[Command]
name = "b"
command = b
time = 1
buffer.time = 1
 
[Command]
name = "c"
command = c
time = 1
buffer.time = 1
 
[Command]
name = "x"
command = x
time = 1
buffer.time = 1
 
[Command]
name = "y"
command = y
time = 1
buffer.time = 1
 
[Command]
name = "z"
command = z
time = 1
buffer.time = 1
 
[Command]
name = "start"
command = s
time = 1
buffer.time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holddownfwd"
command = /$DF
time = 1

[Command]
name = "holddownback"
command = /$DB
time = 1

[Command]
name = "holdupback"
command = /$UB
time = 1

[Command]
name = "holdupfwd"
command = /$UF
time = 1
 
;-| Hold Button |-----------------------------------------------------------
[Command]
name = "hold_a"
command = /a
time = 1
buffer.time = 1
 
[Command]
name = "hold_b"
command = /b
time = 1
buffer.time = 1
 
[Command]
name = "hold_c"
command = /c
time = 1
buffer.time = 1
 
[Command]
name = "hold_x"
command = /x
time = 1
buffer.time = 1
 
[Command]
name = "hold_y"
command = /y
time = 1
buffer.time = 1
 
[Command]
name = "hold_z"
command = /z
time = 1
buffer.time = 1
 
[Command]
name = "hold_start"
command = /s
time = 1
buffer.time = 1

;-| Special Motions |--------------------------------------------------------

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, z
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~x
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~y
time = 16

[Command]
name = "412p" ;Zero Counter
command = ~B, DB, D, ~z
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, b
time = 16

[Command]
name=  "412k" ;Zero Counter
command = ~B, DB, D, c
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~a
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~b
time = 16

[Command]
name = "412k" ;Zero Counter
command = ~B, DB, D, ~c
time = 16

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1

[Command]
name = "recovery";Required (do not remove)
command = x+z
time = 1

[Command]
name = "recovery";Required (do not remove)
command = y+z
time = 1

[Command]
name = "recovery";Required (do not remove)
command = x+a
time = 1

[Command]
name = "2p"
command = x+y
time = 1
buffer.time = 1

[Command]
name = "2p"
command = y+z
time = 1
buffer.time = 1

[Command]
name = "2p"
command = x+z
time = 1
buffer.time = 1

[Command]
name = "2k"
command = a+b
time = 1
buffer.time = 1

[Command]
name = "2k"
command = b+c
time = 1
buffer.time = 1

[Command]
name = "2k"
command = a+c
time = 1
buffer.time = 1

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

;-| Single Dir |------------------------------------------------------------
[Command]
name = "fwd" ;Required (do not remove)
command = F;$F
time = 1

[Command]
name = "downfwd"
command = DF;$DF
time = 1

[Command]
name = "down" ;Required (do not remove)
command = D;$D
time = 1

[Command]
name = "downback"
command = DB;$DB
time = 1

[Command]
name = "back" ;Required (do not remove)
command = B;$B
time = 1

[Command]
name = "upback"
command = UB;$UB
time = 1

[Command]
name = "up" ;Required (do not remove)
command = U;$U
time = 1

[Command]
name = "upfwd"
command = UF;$UF
time = 1

;---------------------------------------------------------------------------
;Release Direction
[Command]
name = "rlsfwd"
command = ~$F
time = 1

[Command]
name = "rlsback"
command = ~$B
time = 1

[Command]
name = "rlsup"
command = ~$U
time = 1

[Command]
name = "rlsdown"
command = ~$D
time = 1

;--------------------------------------------------------------------------
;Release Button
[Command]
name = "rlsx"
command = ~x
time = 1
buffer.time = 1

[Command]
name = "rlsy"
command = ~y
time = 1
buffer.time = 1

[Command]
name = "rlsz"
command = ~z
time = 1
buffer.time = 1

[Command]
name = "rlsa"
command = ~a
time = 1
buffer.time = 1

[Command]
name = "rlsb"
command = ~b
time = 1
buffer.time = 1

[Command]
name = "rlsc"
command = ~c
time = 1
buffer.time = 1

[Command]
name = "rlss"
command = ~s
time = 1
buffer.time = 1

;---------------------------------------------------------------------------
;Other
[Command]
name = "highjump"
command = $D, $U
time = 15

;---------------------------------------------------------------------------
;Moves
[Statedef -1]

[State -1, Tick Fix]
type = CtrlSet
triggerall = RoundState = 2
triggerall = !ctrl
triggerall = movetype!=H
trigger1 = (stateno = 52 || stateno = 101 || stateno = 5120) && !AnimTime
trigger2 = (stateno = [200,299]) && !AnimTime
trigger3 = (stateno = [400,499]) && !AnimTime
trigger4 = (stateno = [700,715]) && !AnimTime
trigger5 = (stateno = [760,762]) && !AnimTime
value = 1

[State -1, CtrlSet For Helpers];special thanks to 20S
type = CtrlSet
trigger1 = IsHelper
value = 0

[State -1, AI Guard Fix]
type = Assertspecial
triggerall = ailevel
trigger1 = stateno != [120,159]
trigger1 = stateno != 5210
flag = noairguard
flag2 = nocrouchguard
flag3 = nostandguard

[State -1, Shun Goku Satsu]
type = ChangeState
value = 3500
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Shun Goku Satsu"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=3000,ifelse(var(20) <= 0, power >= 3000, power >= 1000))
triggerall = var(53) = 1 || (var(50) = 8 && var(51) > 0)
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(6)

[State -1, Goodbye Sugar]
type = ChangeState
value = 3400
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Goodbye Sugar"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=3000,ifelse(var(20) <= 0, power >= 3000, power >= 1000))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(6)

[State -1, Power Punch Rush]
type = ChangeState
value = 3300
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Power Punch Rush"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=3000,ifelse(var(20) <= 0, power >= 3000, power >= 1000))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(6)

[State -1, Ultimate Repeating Punch]
type = ChangeState
value = 3200
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Ultimate Repeating Punch"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=3000,ifelse(var(20) <= 0, power >= 3000, power >= 1000))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(6)

[State -1, Hyper Repeating Punch Max]
type = ChangeState
value = 3150
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "MAX Hyper Repeating Punch"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=2000,ifelse(var(20) <= 0, power >= 2000, power >= 1000))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(6) || var(7)

[State -1, Hyper Repeating Punch]
type = ChangeState
value = 3100
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Hyper Repeating Punch"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=1000,ifelse(var(20) <= 0, power >= 1000, power >= 0))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(6)

[State -1, Goodnight Sugar Max]
type = ChangeState
value = 3050
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "MAX Goodnight Sugar"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=2000,ifelse(var(20) <= 0, power >= 2000, power >= 1000))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(6) || var(7)

[State -1, Goodnight Sugar]
type = ChangeState
value = 3000
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Goodnight Sugar"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=1000,ifelse(var(20) <= 0, power >= 1000, power >= 0))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(6)

[State -1, EX Power Dive Punch]
type = ChangeState
value = 1230
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "EX Power Dive Punch"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20) <= 60 && power>=500,ifelse(var(20) <= 0, power >= 500, power >= 0))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(5)

[State -1, EX Rising Repeating Punch]
type = ChangeState
value = 1130
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "EX Rising Repeating Punch"
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20) <= 60 && power>=500,ifelse(var(20) <= 0, power >= 500, power >= 0))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(5)

[State -1, EX Repeating Punch]
type = ChangeState
value = 1030
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "EX Repeating Punch"
triggerall = roundstate = 2 ;&& statetype != A
triggerall = ifelse(var(56),var(20) <= 60 && power>=500,ifelse(var(20) <= 0, power >= 500, power >= 0))
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(5)

[State -1, Alpha Counter]
type = ChangeState
value = 750
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "412p" || command = "412k"
trigger1 = stateno = 150 || stateno = 152
trigger1 = roundstate = 2 && statetype != A
trigger1 = ifelse(var(56),power >= 1000,power >= 1000 && !var(20))

[State -1, Power Drain]
type = ChangeState
value = 1300
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Power Drain"
triggerall = roundstate = 2 ;&& statetype != A
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(5)

[State -1, Power Dive Punch]
type = ChangeState
value = 1200
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Power Dive Punch"
triggerall = roundstate = 2 && statetype != A
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(5)

[State -1, Rising Repeating Punch]
type = ChangeState
value = 1100
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Rising Repeating Punch"
triggerall = roundstate = 2 && statetype != A
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(5)

[State -1, Repeating Punch]
type = ChangeState
value = 1000
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "Repeating Punch"
triggerall = roundstate = 2 ;&& statetype != A
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = var(5)

[State -1, Counter Movement]
type = ChangeState
value = 740
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "x" && command = "a"
triggerall = (command = "holdfwd" || command = "holdback")
trigger1 = stateno = 150 || stateno = 152
trigger1 = roundstate = 2 && statetype != A
trigger1 = power >= 1000 && !var(20)

[State -1, Throw]
type = ChangeState
value = IfElse(StateType = A, 850,800)
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "2p"
trigger1 = command = "holdfwd"|| command = "holdback"
trigger1 = RoundState = 2
trigger1 = ctrl

[State -1, Roll Forward]
type = ChangeState
value = 710
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "x" && command = "a"
triggerall = roundstate = 2 && statetype != A
trigger1 = (ctrl || (stateno = [100,101])) && command = "holdfwd"

[State -1, Roll Back]
type = ChangeState
value = 715
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "x" && command = "a"
triggerall = roundstate = 2 && statetype != A
trigger1 = (ctrl || (stateno = [100,101])) && command = "holdback"; <--- See above why no Tiny Buffer!

[State -1, Power Charge]
type = ChangeState
value = 730
triggerall = !ailevel
trigger1 = command = "hold_b" && command = "hold_y"
trigger1 = roundstate = 2 && statetype != A
trigger1 = power < const(data.power) && power < PowerMax && !var(20)
trigger1 = ctrl || (stateno = [100,101])

[State -1, MAX Mode]
type = ChangeState
value = 770
triggerall = !ailevel
triggerall = !var(56)
triggerall = !IsHelper
triggerall = command = "z" && command = "c"
triggerall = roundstate = 2 && statetype != A
triggerall = var(20) <= 0 && Power >= 1000
trigger1 = ctrl || (stateno = [100,101])

[State -1, Custom Combo]
type = ChangeState
value = ifelse(statetype = A, 905, 900)
triggerall = !ailevel
triggerall = var(56)
triggerall = !IsHelper
triggerall = command = "z" && command = "c"
triggerall = roundstate = 2
triggerall = var(20) <= 0 && Power >= 1000
trigger1 = ctrl || (stateno = [100,101])

[State -1, Dodge]
type = ChangeState
value = 700
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "x" && command = "a"
triggerall = roundstate = 2 && statetype != A
trigger1 = (ctrl || (stateno = [100,101]))

[State -1, Air Run]
type = ChangeState
value = ifelse(command = "FF", 1350, 1351)
triggerall = !ailevel
trigger1 = command = "FF" || command = "BB"
trigger1 = roundstate = 2 && statetype = A
trigger1 = ctrl

[State -1, Run Back]
type = ChangeState
value = ifelse(command = "FF", 102, 105)
triggerall = !ailevel
trigger1 = command = "FF" || command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;|Normal Commands|--------------------------------------------------------
[State -1, Dive Kick]
type = ChangeState
value = 300
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "c" && command = "holddown"
triggerall = statetype = A
trigger1 = ctrl
trigger2= var(4)

[State -1, Reverse Spin Kick]
type = ChangeState
value = 310
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "c" && command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl
trigger1= ctrl || (stateno=[100,101])
trigger2= var(4)

[State -1, Stand Light Punch]
type = ChangeState
value = 200
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "x"
triggerall =command != "holddown"
;^Be sure to include the dir buffer check if needed DW!
triggerall = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2= (stateno = 200 || stateno = 400 || stateno = 430) && (Time >=5 || MoveContact)
trigger3= var(4)

[State -1, Stand Medium Punch]
type = ChangeState
value = 210
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "y"
triggerall =command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger2= var(4)

[State -1, Stand Strong Punch]
type = ChangeState
value = 220 
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "z"
triggerall =command != "holddown" 
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger2= var(4)

[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "a"
triggerall =command != "holddown"
triggerall = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2= var(4)

[State -1, Stand Medium Kick]
type = ChangeState
value = 240
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "b"
triggerall =command != "holddown"
triggerall = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2= var(4)

[State -1, Standing Strong Kick]
type = ChangeState
value = 250
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "c"
triggerall =command != "holddown"
triggerall = statetype != A
trigger1= ctrl || (stateno=[100,101])
trigger2= var(4)

[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger2= (stateno = 200 || stateno = 400 || stateno = 430) && (Time >=5 || MoveContact)
trigger3= var(4)

[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger2= var(4)

[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger2= var(4)

[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger2= (stateno = 200 || stateno = 400 || stateno = 430) && (Time >=5 || MoveContact)
trigger3= var(4)

[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger2= var(4)

[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger2= var(4)

[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "x"
triggerall = statetype = A
trigger1 = ctrl
trigger2= var(4)

[State -1, Jump Med Punch]
type = ChangeState
value = 610
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl
trigger2= var(4)

[State -1, Jump Strong Punch]
type = ChangeState
value = 620
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl
trigger2= var(4)

[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl
trigger2= var(4)

[State -1, Jump Med Kick]
type = ChangeState
value = 640
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl
trigger2= var(4)

[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl
trigger2= var(4)

[State -1, Taunt]
type = ChangeState
value = 195
triggerall = !ailevel
triggerall = !IsHelper
triggerall = command = "start"
triggerall = statetype != A
triggerall = stateno != [200,699]
trigger1 = ctrl || (stateno = [100,101])
trigger2 = var(5)

;============================================================================
; AI System Moves -----------------------------------------------------------
;============================================================================
[state -1, AI 20 Walk]
type = changestate
value = 20
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = statetype = S
triggerall = p2stateno != 5120 && p2stateno != 5201 || enemynear,ctrl
;condition
trigger1 = ctrl
trigger1 = p2bodydist x = [cond(numtarget, -const240p(8), const240p(32)), const240p(160)]
trigger1 = p2movetype != A
trigger1 = !(enemynear, numproj)
trigger1 = stateno != [20, 119]
trigger1 = prevstateno != [20, 119]
trigger1 = gametime % floor(42 - (ailevel * 4.0)) = [0, ailevel]

[State -1, AI 5210 Fall Recovery (Air)]
type = changestate
value = 5210
trigger1 = ailevel && numenemy
trigger1 = roundstate = 2 && alive
; condition
trigger1 = stateno = 5050 && canrecover
trigger1 = vel y > const(movement.air.gethit.airrecover.threshold)
trigger1 = random < (25 * (ailevel ** 2.0 / 64.0))

[State -1, AI 5200 Fall Recovery (Ground)]
type = changestate
value = 5200
trigger1 = ailevel && numenemy
trigger1 = roundstate = 2 && alive
; condition
trigger1 = stateno = 5050 && canrecover
trigger1 = vel y > 0 && pos y >= const(movement.air.gethit.groundrecover.ground.threshold)
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0))

[State -1, AI 40 Jump]
type = changestate
value = 40
triggerall = ailevel && numenemy
triggerall = roundstate = 2 && statetype != A
; condition
trigger1 = ctrl || (stateno = [100, 101]) || (stateno = [120, 131])
trigger1 = enemynear, movetype = A && p2bodydist x < 160 && enemynear, hitdefattr = SC, AT
trigger1 = random < (250 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = ctrl || (stateno = [100, 101])
trigger2 = backedgebodydist <= const240p(32)
trigger2 = p2statetype = L
trigger2 = p2bodydist x < const240p(128)
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))
; condition
trigger3 = ctrl || (stateno = [100, 101]) || (stateno = [120, 131])
trigger3 = p2movetype = A
trigger3 = p2statetype != A
trigger3 = (p2stateno = [1000, 1999]) || (enemynear, hitdefattr = SCA, SA, SP, ST)
trigger3 = enemynear, animtime < -32
trigger3 = p2bodydist x > const240p(90) || frontedgebodydist < const240p(60) || backedgebodydist < const240p(32)
trigger3 = (random < (25 * (ailevel ** 2.0 / 64.0))) || (enemynear, time = [7, 12])
trigger3 = (random < (25 * (ailevel ** 2.0 / 64.0))) || p2bodydist x > const240p(120)
trigger3 = random < (200 * (ailevel ** 2.0 / 64.0))

[State -1, AI 710 Roll Forward]
type = ChangeState
value = 710
triggerall = ailevel && numenemy
triggerall = RoundState = 2 && StateType != A
triggerall = ctrl || (stateno = [100,101])
; condition
triggerall = enemynear,hitdefattr != SC,AT
; condition
trigger1 = (enemynear, p2bodydist x = [24, 120]) || backedgebodydist <= const240p(32)
trigger1 = enemynear, animtime = [-48,-36]
trigger1 = enemynear, hitdefattr = SCA, AA, AP
trigger1 = frontedgebodydist > const240p(100)
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = stateno = [100, 101]
trigger2 = p2movetype = A
trigger2 = p2bodydist x >= 120
trigger2 = enemynear, p2bodydist x > 0
trigger2 = random < (100 * (ailevel ** 2.0 / 64.0))
; condition
trigger3 = ctrl || (stateno = [100, 101]) || (stateno = [120,131])
trigger3 = p2statetype = A
trigger3 = p2movetype != H
trigger3 = enemynear, vel x > 0
trigger3 = enemynear, vel y < const240p(1)
trigger3 = p2dist x < const240p(32)
trigger3 = random < (100 * (ailevel ** 2.0 / 64.0))

[State -1, AI 715 Roll Back]
type = ChangeState
value = 715
triggerall = ailevel && numenemy
triggerall = roundstate = 2 && statetype != A
triggerall = ctrl || (stateno = [100, 101]) || (stateno = [120, 131])
triggerall = frontedgedist < backedgedist
; condition
triggerall = enemynear,hitdefattr != SC,AT
; condition
trigger1 = p2bodydist x = [0, 32]
trigger1 = p2statetype != A && p2movetype = A
trigger1 = !(enemynear, hitdefattr = SCA, NA) || (enemynear, animtime = [-32, -42])
trigger1 = random < (50 * (ailevel ** 2.0 / 64.0))

[State -1, AI 700 Dodge]
type = changestate
value = 700
triggerall = ailevel && numenemy
triggerall = roundstate = 2 && statetype != A
; condition
triggerall = enemynear,hitdefattr != SC,AT
; condition
trigger1 = ctrl || (stateno = [100, 101]) || ((stateno = [120, 131]) && random < (25 * (ailevel ** 2 / 64.0)))
trigger1 = inguarddist
trigger1 = p2bodydist x > 32 || backedgebodydist <= const240p(32)
trigger1 = p2statetype != A
trigger1 = (enemynear, hitdefattr != SCA, NA)  || enemynear, animtime < -40
trigger1 = random < ((lifemax-life)/(lifemax/const(data.life)))/(13.0 - ailevel)

[State -1, AI 105 Back Dash]
type = changestate
value = 105
triggerall = ailevel && numenemy
triggerall = statetype != A && roundstate = 2
; condition
trigger1 = ctrl && (stateno != [100, 119])
trigger1 = backedgebodydist > const240p(80)
trigger1 = p2statetype = L
trigger1 = p2bodydist x = [-const240p(8), const240p(120)]
trigger1 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 120 Guard]
type = changestate
value = 120
trigger1 = ailevel && numenemy
trigger1 = roundstate = 2 && inguarddist
; condition
trigger1 = ctrl && (stateno != [120, 155])
trigger1 = !var(26) && p2bodydist x >= const(size.ground.front) * 2.5
trigger1 = !(enemynear, hitdefattr = SCA, AT) && (enemynear, time < 120)
triggerall = statetype != A || p2statetype = A
trigger1 = ifelse(statetype = A, ((var(3) != [1, 2]) || stateno = 5210), 1)
trigger1 = random < (ifelse((p2stateno = [200, 699]), 100, ifelse((p2stateno = [1000, 2999]), 333, 1000)) * (AIlevel ** 2 / 64.0))

[State -1, AI 750 Zero Counter]
type = changestate
value = 750
trigger1 = ailevel && numenemy
trigger1 = stateno = 150 || stateno = 152
trigger1 = roundstate = 2 && statetype != A
trigger1 = power >= 1000 && !var(20)
trigger1 = life < 0.9 * p2life || life < (0.5 * lifemax)
trigger1 = p2bodydist x = [cond(p2statetype = A, const240p(32), const240p(8)), const240p(54)]
trigger1 = random < (3 ** (floor(power / 750.0)))

[State -1, AI 740 Counter Movement]
type = ChangeState
value = 740
trigger1 = ailevel && numenemy
trigger1 = stateno = 150 || stateno = 152
trigger1 = roundstate = 2 && statetype != A
trigger1 = power >= 1000 && !var(20)
; condition
trigger1 = (p2bodydist x = [0,50]) && (life < 0.5 * lifemax)
trigger1 = enemynear, animtime = [-45,-30]
trigger1 = random < (power / 10.0)
trigger1 = random < (50 * (ailevel ** 2.0 / 64.0))

[State -1, AI 730 Power Charge]
type = changestate
value = 730
triggerall = ailevel && numenemy
trigger1 = roundstate = 2 && statetype != A
; condition
trigger1 = ctrl && power < const(data.power) && power < powerMax && prevstateno != 5120 && !var(20)
trigger1 = !inguarddist && p2bodydist x >= 160
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0))

[State -1, AI 770 MAX Mode]
type = ChangeState
value = 770
triggerall = !Var(56)
triggerall = ailevel && numenemy
triggerall = roundstate = 2 && statetype != A
triggerall = var(20) <= 0 && Power >= 1000
triggerall = enemynear, life > (enemynear, lifemax / 4.0)
triggerall = life > (lifemax / 5.0)
triggerall = power < 3000
triggerall = ctrl || (stateno = [100,101])
; condition
trigger1 = p2bodydist x >= 160
trigger1 = enemynear, movetype != A
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = enemynear, stateno = 5110
trigger2 = enemynear, time < enemynear, const(data.liedown.time) - 20
trigger2 = random < (100 * (ailevel ** 2.0 / 64.0))
; condition
trigger3 = p2statetype = L
trigger3 = p2bodydist x >= 160
trigger3 = random < (100 * (ailevel ** 2.0 / 64.0))

[State -1, AI 900 Custom COmbo]
type = ChangeState
value = ifelse(StateType = A, 905, 900)
triggerall = Var(56)
triggerall = ailevel && numenemy
triggerall = roundstate = 2
triggerall = var(20) <= 0 && Power >= 1000
triggerall = enemynear, life > (enemynear, lifemax / 4.0)
triggerall = life > (lifemax / 5.0)
triggerall = power < 3000
triggerall = ctrl || (stateno = [100,101])
; condition
trigger1 = p2bodydist x >= 160
trigger1 = enemynear, movetype != A
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = enemynear, stateno = 5110
trigger2 = enemynear, time < enemynear, const(data.liedown.time) - 20
trigger2 = random < (100 * (ailevel ** 2.0 / 64.0))
; condition
trigger3 = p2statetype = L
trigger3 = p2bodydist x >= 160
trigger3 = random < (100 * (ailevel ** 2.0 / 64.0))

[State -1, AI 800 Throw]
type = changestate
value = 800
triggerall = ailevel && numenemy
triggerall = roundstate = 2 && statetype = S
triggerall = !enemynear, ctrl && p2statetype != L && p2movetype != H
;Clsn1: 1
;  Clsn1[0] = 7, -48, 35, 0
triggerall = (p2bodydist x = [-8, 35 - const(size.ground.front)]) && (p2dist y = [-72, 8])
; condition
trigger1 = ctrl
trigger1 = random < (125 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = ctrl && (p2stateno = [120,140])
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 100 Run]
type = changestate
value = 100
triggerall = ailevel && numenemy
triggerall = roundstate = 2 && statetype = S
trigger1 = ctrl && (stateno != [100,106])
trigger1 = (enemynear, movetype != A) && p2bodydist x >= 160
trigger1 = random < (200 * (ailevel ** 2.0 / 64.0))
; condition for Divine KFM in particular
trigger2 = ctrl
trigger2 = numtarget(1220)
trigger2 = target, stateno = 1290
trigger2 = random < (400 * (ailevel ** 2.0 / 64.0))

;=========================================================================
; AI Normal Commands -----------------------------------------------------
;=========================================================================
[State -1, AI 440 Crouching Medium Kick]
type = changestate
value = 440
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 4
;Clsn1: 1
;  Clsn1[0] = 17, -20, 81, 0
triggerall = p2bodydist x = [-const240p(8), (75 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-98 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = p2statetype != A
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = random < (150 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 4))
;condition
trigger2 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger2 = enemynear, gethitvar(hittime) >= 4
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 240 Stand Medium Kick]
type = changestate
value = 240
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 6
;Clsn1: 1
;  Clsn1[0] = 16, -43, 68, -23
triggerall = p2bodydist x = [-const240p(8), (99 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-101 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = p2statetype != A
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = random < (150 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 6))
;condition
trigger2 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger2 = enemynear, gethitvar(hittime) >= 6
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 410 Crouching Medium Punch]
type = changestate
value = 410
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 4
;Clsn1: 1
;  Clsn1[0] = 8, -51, 56, -36
; startup = 8
;Clsn1: 1
;  Clsn1[0] = 25, -88, 55, -43
triggerall = p2statetype != A
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (59 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-78 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (125 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 4))
;condition
trigger2 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger2 = enemynear, gethitvar(hittime) >= 4
trigger2 = p2bodydist x = [-const240p(8), (55 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-78 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 430 Crouching Light Kick]
type = changestate
value = 430
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 4
;Clsn1: 1
;  Clsn1[0] = 10, -15, 68, 0
triggerall = p2bodydist x = [-const240p(8), (68 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-17 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = p2statetype != A
;condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = random < (125 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 4))
;condition
trigger2= (stateno = 200 || stateno = 400 || stateno = 430) && (Time >=5 || MoveContact)
trigger2 = (random < (25 * (ailevel ** 2.0 / 64.0))) || movecontact
trigger2 = random < (100 * (ailevel ** 2.0 / 64.0))
;condition
trigger3 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger3 = enemynear, gethitvar(hittime) >= 4
trigger3 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 400 Crouching Light Punch]
type = changestate
value = 400
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 4
;Clsn1: 1
;  Clsn1[0] = 8, -51, 56, -36
triggerall = p2bodydist x = [-const240p(8), (56 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-51 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = p2statetype != A
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = random < (125 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 4))
; condition
trigger2= (stateno = 200 || stateno = 400 || stateno = 430) && (Time >=5 || MoveContact)
trigger2 = (random < (25 * (ailevel ** 2.0 / 64.0))) || movecontact
trigger2 = random < (100 * (ailevel ** 2.0 / 64.0))
; condition
trigger3 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger3 = enemynear, gethitvar(hittime) >= 4
trigger3 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 210 Stand Medium Punch]
type = changestate
value = 210
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 7
;Clsn1: 1
;  Clsn1[0] = 27, -88, 73, -59
triggerall = p2bodydist x = [-const240p(8), (105 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-71 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = p2statetype = A
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
triggerall = p2statetype = S || (p2statetype = A && numtarget)
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 7))
;condition
trigger2 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger2 = enemynear, gethitvar(hittime) >= 7
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 250 Standing Strong Kick]
type = changestate
value = 250
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 8
;Clsn1: 1
;  Clsn1[0] = 5, -70, 70, -50
triggerall = p2bodydist x = [-const240p(8), (115 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-122 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
triggerall = p2statetype != A
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = p2bodydist x > (40 - const(size.ground.front)) * const(size.xscale)
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 8))
;condition
trigger2 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger2 = enemynear, gethitvar(hittime) >= 8
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 200 Stand Light Punch]
type = changestate
value = 200
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 5
;Clsn1: 1
;  Clsn1[0] = 17, -84, 63, -67
triggerall = p2bodydist x = [-const240p(8), (83 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-72 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
triggerall = p2statetype = S || (p2statetype = A && numtarget)
;condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = random < (125 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 5))
;condition
trigger2= (stateno = 200 || stateno = 400 || stateno = 430) && (Time >=5 || MoveContact)
trigger2 = (random < (25 * (ailevel ** 2.0 / 64.0))) || movecontact
trigger2 = random < (100 * (ailevel ** 2.0 / 64.0))
;condition
trigger3 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger3 = enemynear, gethitvar(hittime) >= 5
trigger3 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 230 Stand Light Kick]
type = changestate
value = 230
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 5
;Clsn1: 1
;  Clsn1[0] = 16, -43, 68, -23
triggerall = p2bodydist x = [-const240p(8), (68 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-43 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = p2statetype != A
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = random < (125 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 5))
;condition
trigger2 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger2 = enemynear, gethitvar(hittime) >= 5
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 450 Crouching Strong Kick]
type = changestate
value = 450
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 7
;Clsn1: 1
;  Clsn1[0] = 17, -20, 81, 0
triggerall = p2bodydist x = [-const240p(8), (81 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-20 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = (p2statetype = S || (p2statetype = C && p2movetype = H)) && !(enemynear, hitfall)
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = !enemynear, ctrl && (enemynear, stateno != [120,155])
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 7))
;condition
trigger2 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger2 = enemynear, gethitvar(hittime) >= 7
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 220 Stand Strong Punch]
type = changestate
value = 220 
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 7
;Clsn1: 1
;  Clsn1[0] = 16, -76, 65, -56
triggerall = p2bodydist x = [-const240p(8), (65 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-76 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
triggerall = p2statetype = S || (p2statetype = A && numtarget)
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = random < (75 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 7))
;condition
trigger2 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger2 = enemynear, gethitvar(hittime) >= 7
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

[State -1, AI 420 Crouching Strong Punch]
type = changestate
value = 420
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; condition
; startup = 7
;Clsn1: 1
;  Clsn1[0] = 20, -65, 64, -42
triggerall = p2bodydist x = [-const240p(8), (64 - const(size.ground.front)) * const(size.xscale)]
triggerall = p2dist y = [(-65 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
triggerall = p2statetype != A
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
; condition
triggerall = statetype != A
trigger1 = ctrl || (stateno = [100,101])
trigger1 = random < (75 * (ailevel ** 2.0 / 64.0)) + (ailevel * 48.0 * (enemynear, gethitvar(hittime) >= 7))
;condition
trigger2 = (((stateno = [200, 499]) && !animtime && movehit) || (ctrl && (enemynear, gethitvar(damage))))
trigger2 = enemynear, gethitvar(hittime) >= 7
trigger2 = random < (250 * (ailevel ** 2.0 / 64.0))

;============================================================================
; AI Jumping Moves ----------------------------------------------------------
;============================================================================
[State -1, AI 640 Jump Med Kick]
type = changestate
value = 640
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
;
triggerall = p2statetype = A
; startup = 7
;Clsn1: 1
;  Clsn1[0] = -20, -47, 67, -26
; condition
triggerall = (vel y >= 0.5 && p2dist y >= -50) || p2statetype = A
; condition
triggerall = statetype = A
trigger1 = ctrl
trigger1 = p2bodydist x >= (-20 - const(size.ground.front)) * const(size.xscale)
trigger1 = p2bodydist x <= (47 + (7 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)
trigger1 = p2dist y = [(-47 - 16) * const(size.yscale), (-26 + 72 + (32 * vel y * (vel y > 0))) * const(size.yscale)]
trigger1 = random < (150 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = statetype = A
trigger2 = ctrl
trigger2 = p2bodydist x >= (-20 - const(size.ground.front)) * const(size.xscale)
trigger2 = p2bodydist x <= (47 + (7 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)
trigger2 = p2dist y = [(-47 - 16) * const(size.yscale), (-26 + 72 + 32 * (vel y > 2.0)) * const(size.yscale)]
trigger2 = p2statetype != A && vel y >= 0.5
trigger2 = random < 300 * (ailevel ** 2.0 / 64.0)

[State -1, AI 620 Jump Strong Punch]
type = changestate
value = 620
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
;
; startup = 7
;Clsn1: 1
;  Clsn1[0] = 15, -71, 58, -41
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
triggerall = (vel y >= 0.5 && p2dist y >= -50) || p2statetype = A
;
triggerall = statetype = A
trigger1 = ctrl
trigger1 = p2bodydist x = [-const240p(8), (58 + (7 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-71 - 16) * const(size.yscale), (-41 + 72 + (32 * vel y * (vel y > 0))) * const(size.yscale)]
trigger1 = random < (150 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = statetype = A
trigger2 = ctrl
trigger2 = p2bodydist x = [-const240p(8), (58 + (7 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-71 - 16) * const(size.yscale), (-41 + 72 + 32 * (vel y > 2.0)) * const(size.yscale)]
trigger2 = p2statetype != A && vel y >= 0.5
trigger2 = random < 300 * (ailevel ** 2.0 / 64.0)

[State -1, AI 610 Jump Med Punch]
type = changestate
value = 610
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
; startup = 7
;Clsn1: 1
;  Clsn1[0] = 15, -71, 58, -41
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
triggerall = (vel y >= 0.5 && p2dist y >= -50) || p2statetype = A
;
triggerall = statetype = A
trigger1 = ctrl
trigger1 = p2bodydist x = [-const240p(8), (58 + (7 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-71 - 16) * const(size.yscale), (-41 + 72 + (32 * vel y * (vel y > 0))) * const(size.yscale)]
trigger1 = random < (150 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = statetype = A
trigger2 = ctrl
trigger2 = p2bodydist x = [-const240p(8), (65 + (5 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-71 - 16) * const(size.yscale), (-41 + 72 + 32 * (vel y > 2.0)) * const(size.yscale)]
trigger2 = p2statetype != A && vel y >= 0.5
trigger2 = random < 300 * (ailevel ** 2.0 / 64.0)

[State -1, AI 650 Jump Strong Kick]
type = changestate
value = 650
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
;
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
; startup = 7
;Clsn1: 1
;  Clsn1[0] = 1, -108, 44, -48
; condition
triggerall = vel y <= 2.0 && p2statetype = A
;
triggerall = statetype = A
trigger1 = ctrl
trigger1 = p2bodydist x = [-const240p(8), (44 + (7 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-108 - 16) * const(size.yscale), (-48 + 72) * const(size.yscale)]
trigger1 = random < (200 * (ailevel ** 2.0 / 64.0))

[State -1, AI 600 Jump Light Punch]
type = changestate
value = 600
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
;
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
; startup = 4
;Clsn1: 1
;  Clsn1[0] = 10, -78, 51, -53
; condition
triggerall = (vel y >= 0.5 && p2dist y >= -40) || p2statetype = A
;
triggerall = statetype = A
trigger1 = ctrl
trigger1 = p2bodydist x = [-const240p(8), (51 + (4 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-78 - 16) * const(size.yscale), (-53 + 72 + (32 * vel y * (vel y > 0))) * const(size.yscale)]
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = statetype = A
trigger2 = ctrl
trigger2 = p2bodydist x = [-const240p(8), (51 + (4 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-78 - 16) * const(size.yscale), (-53 + 72 + 32 * (vel y > 2.0)) * const(size.yscale)]
trigger2 = p2statetype != A && vel y >= 0.5
trigger2 = random < 200 * (ailevel ** 2.0 / 64.0)

[State -1, AI 630 Jump Light Kick]
type = changestate
value = 630
triggerall = ailevel
triggerall = roundstate = 2
triggerall = numenemy
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 1)
;
; startup = 7
;Clsn1: 1
;  Clsn1[0] = 3, -56, 39, -34
triggerall = (enemynear, const(size.head.pos.y) <= -const240p(40)) || (enemynear, statetype = A && numtarget)
triggerall = (vel y >= 0.5 && p2dist y >= -40) || p2statetype = A
;
triggerall = statetype = A
trigger1 = ctrl
trigger1 = p2bodydist x = [-const240p(8), (39 + (7 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-56 - 16) * const(size.yscale), (-34 + 72 + (32 * vel y * (vel y > 0))) * const(size.yscale)]
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0))
; condition
trigger2 = statetype = A
trigger2 = ctrl
trigger2 = p2bodydist x = [-const240p(8), (39 + (7 * (vel x + (enemynear,vel x))) - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-56 - 16) * const(size.yscale), (-34 + 72 + 32 * (vel y > 2.0)) * const(size.yscale)]
trigger2 = p2statetype != A && vel y >= 0.5
trigger2 = random < 200 * (ailevel ** 2.0 / 64.0)

;============================================================================
; AI Supers -----------------------------------------------------------------
;============================================================================

[State -1, Shun Goku Satsu]
type = ChangeState
value = 3500
triggerall = ailevel && numenemy && !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=3000,ifelse(var(20) <= 0, power >= 3000, power >= 1000))
triggerall = var(53) = 1 || (var(50) = 8 && var(51) > 0)
triggerall = !(enemynear, ctrl) && ((enemynear, stateno != [120, 155]) || enemynear, statetype = A)
triggerall = !numtarget(1030) && var(4)
triggerall = enemynear, life >= 0.20 * enemynear, lifemax
triggerall = !enemynear, ctrl && (p2stateno != [120, 155])
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (126 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-36 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (cond(p2statetype != A, 25, 50 * (ailevel ** 2.0 / 64.0)))
trigger2 = var(6)
trigger2 = p2bodydist x = [-const240p(8), (126 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-36 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 10
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)

[State -1, Goodbye Sugar]
type = ChangeState
value = 3400
triggerall = ailevel && numenemy && !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=3000,ifelse(var(20) <= 0, power >= 3000, power >= 1000))
triggerall = !(enemynear, ctrl) && ((enemynear, stateno != [120, 155]) || enemynear, statetype = A)
triggerall = !numtarget(1030) && var(4)
triggerall = enemynear, life >= 0.20 * enemynear, lifemax
triggerall = !enemynear, ctrl && (p2stateno != [120, 155])
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (146 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-72 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (cond(p2statetype != A, 25, 50 * (ailevel ** 2.0 / 64.0)))
trigger2 = var(6)
trigger2 = p2bodydist x = [-const240p(8), (146 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-72 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 10
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)

[State -1, Power Punch Rush]
type = ChangeState
value = 3300
triggerall = ailevel && numenemy && !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=3000,ifelse(var(20) <= 0, power >= 3000, power >= 1000))
triggerall = !(enemynear, ctrl) && ((enemynear, stateno != [120, 155]) || enemynear, statetype = A)
triggerall = !numtarget(1030) && var(4)
triggerall = enemynear, life >= 0.20 * enemynear, lifemax
triggerall = !enemynear, ctrl && (p2stateno != [120, 155])
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (132 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-210 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (cond(p2statetype != A, 25, 50 * (ailevel ** 2.0 / 64.0)))
trigger2 = var(6)
trigger2 = p2bodydist x = [-const240p(8), (93 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 10
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)

[State -1, Ultimate Repeating Punch]
type = ChangeState
value = 3200
triggerall = ailevel && numenemy && !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = roundstate = 2 && statetype != A
triggerall = ifelse(var(56),var(20)<=60&&power>=3000,ifelse(var(20) <= 0, power >= 3000, power >= 1000))
triggerall = !(enemynear, ctrl) && ((enemynear, stateno != [120, 155]) || enemynear, statetype = A)
triggerall = !numtarget(1030) && var(4)
triggerall = enemynear, life >= 0.20 * enemynear, lifemax
triggerall = !enemynear, ctrl && (p2stateno != [120, 155])
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (132 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-210 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (cond(p2statetype != A, 25, 50 * (ailevel ** 2.0 / 64.0)))
trigger2 = var(6)
trigger2 = p2bodydist x = [-const240p(8), (93 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 10
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)

[State -1, Hyper Repeating Punch Max]
type = ChangeState
value = 3150
triggerall = ailevel && numenemy && !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = enemynear, life >= 0.15 * enemynear, lifemax
triggerall = !enemynear, ctrl && (p2stateno != [120, 155])
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = roundstate = 2 && statetype != A
triggerall = !numtarget(1030) && var(4)
triggerall = ifelse(var(56),var(20)<=60&&power>=2000,ifelse(var(20) <= 0, power >= 2000, power >= 1000))
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (132 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-210 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0))
;Condition: Mid-Combo
trigger2 = var(6) || var(7)
trigger2 = p2bodydist x = [-const240p(8), (93 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 10
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)

[State -1, Hyper Repeating Punch]
type = ChangeState
value = 3100
triggerall = ailevel && numenemy && !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = enemynear, life >= 0.15 * enemynear, lifemax
triggerall = !enemynear, ctrl && (p2stateno != [120, 155])
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = roundstate = 2 && statetype != A
triggerall = !numtarget(1030) && var(4)
triggerall = ifelse(var(56),var(20)<=60&&power>=1000,ifelse(var(20) <= 0, power >= 1000, power >= 0))
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (132 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-210 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (50 * (ailevel ** 2.0 / 64.0))
;Condition: Mid-Combo
trigger2 = var(6)
trigger2 = p2bodydist x = [-const240p(8), (93 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 10
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)

[State -1, Goodnight Sugar Max]
type = ChangeState
value = 3050
triggerall = ailevel && numenemy && !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = enemynear, life >= 0.15 * enemynear, lifemax
triggerall = !enemynear, ctrl && (p2stateno != [120, 155])
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = roundstate = 2 && statetype != A
triggerall = !numtarget(1030) && var(4)
triggerall = ifelse(var(56),var(20)<=60&&power>=2000,ifelse(var(20) <= 0, power >= 2000, power >= 1000))
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (146 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-72 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (100 * (ailevel ** 2.0 / 64.0))
;Condition: Mid-Combo
trigger2 = var(6) || var(7)
trigger2 = p2bodydist x = [-const240p(8), (146 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-72 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 10
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)

[State -1, Goodnight Sugar]
type = ChangeState
value = 3000
triggerall = ailevel && numenemy && !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = enemynear, life >= 0.15 * enemynear, lifemax
triggerall = !enemynear, ctrl && (p2stateno != [120, 155])
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = roundstate = 2 && statetype != A
triggerall = !numtarget(1030) && var(4)
triggerall = ifelse(var(56),var(20)<=60&&power>=1000,ifelse(var(20) <= 0, power >= 1000, power >= 0))
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (146 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-72 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (50 * (ailevel ** 2.0 / 64.0))
;Condition: Mid-Combo
trigger2 = var(6)
trigger2 = p2bodydist x = [-const240p(8), (146 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-72 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 10
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)

;============================================================================
; AI EX Moves ---------------------------------------------------------------
;============================================================================

[State -1, AI EX Repeating Punch]
type = ChangeState
value = 1030
triggerall = ailevel && numenemy
triggerall = !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = p2stateno != [120, 155]
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = ifelse(var(56),var(20) <= 60 && power>=500,ifelse(var(20) <= 0, power >= 500, power >= 0))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = roundstate = 2 ;&& statetype != A
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (132 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-210 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (75 * (ailevel ** 2.0 / 64.0))
;Condition: Mid-Combo
trigger2 = var(5)
trigger2 = p2bodydist x = [-const240p(8), (93 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 8
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)
;Condition: Ground Rebound Combo
trigger3 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger3 = p2bodydist x = [-const240p(8), (93 - const(size.ground.front)) * const(size.xscale)]
trigger3 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger3 = NumTarget(1130)
trigger3 = random < 100 + (ailevel * 64.0)

[State -1, AI EX Rising Repeating Punch]
type = ChangeState
value = 1130
triggerall = ailevel && numenemy
triggerall = !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = p2stateno != [120, 155]
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = ifelse(var(56),var(20) <= 60 && power>=500,ifelse(var(20) <= 0, power >= 500, power >= 0))
triggerall = roundstate = 2 && statetype != A
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (52 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-282 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (75 * (ailevel ** 2.0 / 64.0))
;Condition: Mid-Combo
trigger2 = var(5)
trigger2 = p2bodydist x = [-const240p(8), (52 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-122 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 8
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)
;Condition: Ground Rebound Combo
trigger3 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger3 = p2bodydist x = [-const240p(8), (52 - const(size.ground.front)) * const(size.xscale)]
trigger3 = p2dist y = [(-122 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger3 = NumTarget(1030)
trigger3 = random < 100 + (ailevel * 64.0)

[State -1, AI EX Power Dive Punch]
type = ChangeState
value = 1230
triggerall = ailevel && numenemy
triggerall = !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = p2stateno != [120, 155]
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = ifelse(var(56),var(20) <= 60 && power>=500,ifelse(var(20) <= 0, power >= 500, power >= 0))
triggerall = roundstate = 2 && statetype != A
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (136 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (75 * (ailevel ** 2.0 / 64.0))
;Condition: Ground Rebound Combo
trigger2 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = p2bodydist x = [-const240p(8), (136 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = NumTarget(1130)
trigger2 = random < 100 + (ailevel * 64.0)

;============================================================================
; AI Special Moves ----------------------------------------------------------
;============================================================================

[State -1, AI Power Drain]
type = ChangeState
value = 1300
triggerall = ailevel && numenemy
triggerall = !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = p2stateno != [120, 155]
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = roundstate = 2 ;&& statetype != A
triggerall = var(51) = 0
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (146 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-72 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (50 * (ailevel ** 2.0 / 64.0))
;Condition: Mid-Combo
trigger2 = var(5)
trigger2 = p2bodydist x = [-const240p(8), (146 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-72 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 10
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)

[State -1, AI Repeating Punch]
type = ChangeState
value = 1000
triggerall = ailevel && numenemy
triggerall = !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = p2stateno != [120, 155]
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = roundstate = 2 ;&& statetype != A
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (132 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-210 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (50 * (ailevel ** 2.0 / 64.0))
;Condition: Mid-Combo
trigger2 = var(5)
trigger2 = p2bodydist x = [-const240p(8), (93 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 8
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)
;Condition: Ground Rebound Combo
trigger3 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger3 = p2bodydist x = [-const240p(8), (93 - const(size.ground.front)) * const(size.xscale)]
trigger3 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger3 = NumTarget(1130)
trigger3 = random < 100 + (ailevel * 64.0)

[State -1, AI Rising Repeating Punch]
type = ChangeState
value = 1100
triggerall = ailevel && numenemy
triggerall = !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = p2stateno != [120, 155]
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = roundstate = 2 && statetype != A
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (52 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-282 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (50 * (ailevel ** 2.0 / 64.0))
;Condition: Mid-Combo
trigger2 = var(5)
trigger2 = p2bodydist x = [-const240p(8), (52 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-122 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = enemynear, gethitvar(hittime) >= 8
trigger2 = p2statetype != A
trigger2 = random < (ailevel * 64.0)
;Condition: Ground Rebound Combo
trigger3 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger3 = p2bodydist x = [-const240p(8), (52 - const(size.ground.front)) * const(size.xscale)]
trigger3 = p2dist y = [(-122 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger3 = NumTarget(1030)
trigger3 = random < 100 + (ailevel * 64.0)

[State -1, AI Power Dive Punch]
type = ChangeState
value = 1200
triggerall = ailevel && numenemy
triggerall = !IsHelper
triggerall = p2statetype != L && p2stateno != 5120 && p2stateno != 5201
triggerall = p2stateno != [120, 155]
triggerall = !var(16) && (var(15) < 2 + HitCount || (var(56) && var(20)))
triggerall = !(((stateno = [200,699]) && Time <= 2) && numtarget)
triggerall = roundstate = 2 && statetype != A
;Condition: Control
trigger1 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger1 = p2bodydist x = [-const240p(8), (136 - const(size.ground.front)) * const(size.xscale)]
trigger1 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger1 = random < (50 * (ailevel ** 2.0 / 64.0))
;Condition: Ground Rebound Combo
trigger2 = ctrl || stateno = 40 || stateno = 52 || (stateno = [100,101])
trigger2 = p2bodydist x = [-const240p(8), (136 - const(size.ground.front)) * const(size.xscale)]
trigger2 = p2dist y = [(-66 - (enemynear, vel y * (enemynear, vel y > 0))) * const(size.yscale), const240p(8)]
trigger2 = NumTarget(1130)
trigger2 = random < 100 + (ailevel * 64.0)

;============================================================================
; AI Taunts -----------------------------------------------------------------
;============================================================================
[State -1, AI 195 Taunt]
type = changestate
value = 195
triggerall = ailevel && numenemy
triggerall = statetype != A && Life >= 0.5 * LifeMax
triggerall = (enemynear, Life) <= 0.5 * (enemynear, LifeMax)
; condition
trigger1 = ctrl || (stateno = [100,101])
trigger1 = p2dist x >= 160 && !(enemynear, ctrl)
trigger1 = (enemynear, movetype = H) && (enemynear, hitfall)
trigger1 = random < (25 * (ailevel ** 2.0 / 64.0))