                            __________________________________________
===========================| Strider Hiryu by varo_hades              |===========================
                            ������������������������������������������        [22.08.15]

 - Contact:	varo_hades@hotmail.com
 - Website:	Comming soon
 - Customized version of Capcom's Strider Hiryu character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, including MVC and MVC2

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks
 		 3p- three punches      3k- three kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

<NORMAL>

.Slide Kick				DF + c
.Izuna	      		   		F/B + 2p		(near opponent)
.Hook:					F/B + 2k		(near opponent)
.Air Hook:				F/B + 2p		(Air, near opponent)

<SPECIAL>

.Standing Ghram (EX)			 F ,D, DF, p
.Crouching Ghram (EX)			 F ,D, DF, k
.Formation (EX)				 D ,DB, B, k
.Ame No Murakam (EX)			 D ,DF, F, p
.Robo Panther (EX)			 D ,DF, F, k
.Satellite (EX)				 (charge) B, F, p
.Robo Hawke (EX)			 (charge) B, F, k
.Excalibur (Air) (EX)			 D ,DF, F, k
.Wall Climb (EX)			 D ,DB, B, p
.Teleport			 	 B ,D, DB, k

<SUPER>

.Ouroboros (MAX):			 D, DF, F, D, DF, F, p
 .Ouroboros Attack:			 p (Only if Ouroboros is active)
.Legion (MAX):				 D, DF, F, D, DF, F, k

<Lv3 SUPER>

.Ragnarok:                		 D, DF, F, D, DF, F, 3p

<SYSTEM>

.Forward Dash:                  	F, F
   .Run:                        	hold
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	a + x
   .Sidestep Attack:            	p / k
.Forward Roll:                  	F + a + x
.Backward Roll:                 	B + a + x
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold b + y
.Zero Counter:                  	B, DB, D, p / k 	(during standing or crouching guard)
.Custom Combo:                  	c + z           	(Air also)
.Fall Recovery:                 	2p / a + x      	(while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

=====<Miscellaneous>=====

- To change his size to TV aspect ratio (a.k.a. CvS scale), open the .def file and replace
  "Constants.cns" with "ConstantsCvS.cns".

- If you don't like having to charge directions to perform Super moves, open the .def file and replace
  "Command.cmd" with "CommandEasy.cmd".
  All charge charge commands used in Supers will be replaced with double quarter circle motions, as follows:
	Satellite (charge) B, F     ->  B, F
	Robo Hawke (charge) B, F  ->  B, F


=====<Special Thanks>=====
 - Hades for hyper portrait, hyper fonts, effects, small portrait, big portrait clean, palettes, and his much effort with all.
 - P.o.t.S. for code, effects, hitsparks, formatting style
 - Syn for the sprites and code.
 - Girad for the color separation.
 - Infinite for some code and sprites.
 - Everybody at the MUGEN Fighters Guild for feedback

=====<Disclaimer>=====

 - The Strider Hiryu character is property of Capcom
 - Marvel vs Capcom is property of Capcom
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes