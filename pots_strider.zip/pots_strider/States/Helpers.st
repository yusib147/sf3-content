; _________________________________________
;| Strider Hiryu by varo_hades             |
; �����������������������������������������
;==============================================================================================
;=======================================<HELPER STATES>========================================
;==============================================================================================

;====================<PARRY HELPER>=========================
[StateDef 765]
type = A
physics = N
moveType = I
anim = ifElse(Root, StateType = C, 766, ifElse(Root, StateType = A, 767, 765))
velSet = 0,0
ctrl = 0

[State 765, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 765, BindToRoot]
type = BindToRoot
trigger1 = 1
time = -1

[State 765, Change to Crouching]
type = ChangeAnim
triggerAll = !Time
trigger1 = !(Root, AILevel) && Root, command = "down"
trigger2 = Root, AILevel && (Root, StateType != A) && P2StateType = C
value = 766

[State 765, Change to Standing / Jumping]
type = ChangeAnim
triggerAll = !Time
trigger1 = !(Root, AILevel) && Root, command = "fwd"
trigger2 = Root, AILevel && Anim != 766
value = ifElse((Root, StateType = A), 767, 765)

[State 765, Change to Standing / Jumping]
type = ChangeAnim
trigger1 = Anim = 765 || Anim = 767
value = ifElse((Root, StateType = A), 767, 765)

[State 765, Disable]
type = VarSet
trigger1 = Time >= ifElse((Root, StateType = A), 7, 8)
trigger2 = Facing != (Root, Facing)
trigger3 = !(Root, ctrl)
trigger3 = (Root, StateNo != [760,762]) && (Root, StateNo != 5120)
var(0) = 1

[State 765, Disable]
type = VarSet
triggerAll = !(Root, AILevel)
trigger1 = (Root, command = "holdback")
trigger2 = Time < 4 && (Root, command = "holdfwd" + Root, command = "holddown") > 1
trigger3 = Time >= 4 && (Root, command = "holdfwd" || Root, command = "holddown")
trigger4 = Time >= 1 && (((Anim = 765 || Anim = 767) && Root, command = "fwd") || (Anim = 766 && Root, command = "down"))
var(0) = 1

[State 765, Disable]
type = ChangeAnim
trigger1 = var(0) = 1
value = 1

[State 765, Standing/Air]
type = ReversalDef
trigger1 = !var(0) && (Anim = 765 || Anim = 767)
trigger1 = (Root, StateNo != 5120) || !(Root, AnimTime)
reversal.attr = SCA,AA
p1StateNo = 766
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, Crouching]
type = ReversalDef
trigger1 = !var(0) && Anim = 766
reversal.attr = SC,AA
p1StateNo = 766
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, Disable]
type = ReversalDef
trigger1 = var(0) = 1
reversal.attr =
pauseTime = 0,0
sparkNo = -1
numHits = 0

[State 765, End]
type = DestroySelf
trigger1 = Time >= 18
trigger2 = (Root, MoveType != I)
trigger3 = !(Root, ctrl) && (Root, StateNo != [760,762]) && (Root, StateNo != 5120)
trigger4 = (Root, StateNo = [760,762]) && (Root, Time <= 1)


;Success
[StateDef 766]
moveType = I
ctrl = 0

[State 766, Disable]
type = VarSet
trigger1 = 1
var(0) = 1

[State 766, End]
type = DestroySelf
trigger1 = Root, StateNo = [760,762]
trigger2 = Time >= 2

;----------------------------
;Sword Helper 1
;----------------------------
[Statedef 1005]
type = S
ctrl = 0
anim = 1005
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;----------------------------
;Sword Helper 2
;----------------------------
[Statedef 1015]
type = S
ctrl = 0
anim = 1015
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = 0.5,0.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != [1001,1101]
ignorehitpause = 1

;----------------------------
;Sword Helper 2
;----------------------------
[Statedef 1016]
type = S
ctrl = 0
anim = 1015
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = 0.6,0.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != [1001,1101]
ignorehitpause = 1

;----------------------------
;Sword Helper 2
;----------------------------
[Statedef 1017]
type = S
ctrl = 0
anim = 1015
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = 0.7,0.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != [1001,1101]
ignorehitpause = 1

;----------------------------
;Sword Helper 2
;----------------------------
[Statedef 1018]
type = S
ctrl = 0
anim = 1045
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = 0.7,0.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != [1031,1131]
ignorehitpause = 1

;----------------------------
;Sword Helper 1
;----------------------------
[Statedef 9203]
type = s
movetype = i
physics = n
sprpriority = 4
ignorehitpause = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = root,stateno = [1202,1232]
pos = -40,-7
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = [1202,1232]
trigger1 = time = 0
value = 9203
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != [1202,1232]
ignorehitpause = 1

;----------------------------
;Sword Helper 3
;----------------------------
[Statedef 2705]
type = S
sprpriority = 4

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, BindToRoot]
type = BindToRoot
trigger1 = 1
time = -1
pos = 17,-49

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, Ragnarok Start]
type = ChangeAnim
trigger1 = root,anim = 1700
trigger1 = root,stateno = 1700 && time = 0
value = 1705

[State 0, Ragnarok Start]
type = ChangeAnim
trigger1 = root,anim = 1700
trigger1 = root,stateno = 1730 && time = 0
value = 1705

[State 0, Ragnarok lk]
type = ChangeAnim
trigger1 = root,anim = 1701
trigger1 = root,stateno = 1701 && time = 0
value = 1706

[State 0, Ragnarok lk]
type = ChangeAnim
trigger1 = root,anim = 1701
trigger1 = root,stateno = 1731 && time = 0
value = 1706

[State 0, Ragnarok mk]
type = ChangeAnim
trigger1 = root,anim = 1702
trigger1 = root,stateno = 1702 && time = 0
value = 1707

[State 0, Ragnarok mk]
type = ChangeAnim
trigger1 = root,anim = 1702
trigger1 = root,stateno = 1732 && time = 0
value = 1707

[State 0, Ragnarok hk]
type = ChangeAnim
trigger1 = root,anim = 1703
trigger1 = root,stateno = 1703 && time = 0
value = 1708

[State 0, Ragnarok hk]
type = ChangeAnim
trigger1 = root,anim = 1703
trigger1 = root,stateno = 1733 && time = 0
value = 1708

[State 0, BindToParent]
type = BindToParent
trigger1 = parent,stateno = [1704,1706]
time = -1
pos = 17,-49

[State 0, BindToParent]
type = BindToParent
trigger1 = parent,stateno = [1734,1736]
time = -1
pos = 17,-49

[State 0, Trans]
type = Trans
triggerall = parent,ishelper(1710)
trigger1 = parent,stateno = [1704,1706]
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = parent,ishelper(1710)
trigger1 = parent,stateno = [1734,1736]
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = parent,ishelper(1711)
trigger1 = parent,stateno = [1704,1706]
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = parent,ishelper(1711)
trigger1 = parent,stateno = [1734,1736]
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = parent,ishelper(1712)
trigger1 = parent,stateno = [1704,1706]
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = parent,ishelper(1712)
trigger1 = parent,stateno = [1734,1736]
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != [1700,1710]
trigger2 = root,stateno != [1730,1736]
ignorehitpause = 1

;----------------------------
;Sword Helper 4
;----------------------------
[Statedef 2706]
type = s
movetype = i
physics = n
sprpriority = 4
ignorehitpause = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = root,stateno = [1701,1703]
pos = 19,-51
time = -1
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = root,stateno = [1731,1733]
pos = 19,-51
time = -1
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1701
trigger1 = time = 0
value = 1711
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1731
trigger1 = time = 0
value = 1711
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1702
trigger1 = time = 0
value = 1712
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1732
trigger1 = time = 0
value = 1712
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1703
trigger1 = time = 0
value = 1713
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1733
trigger1 = time = 0
value = 1713
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != [1700,1710]
trigger2 = root,stateno != [1730,1736]
ignorehitpause = 1

;=====================<Robo Panther PROJECTILE>=========================
[StateDef 1405]
type = S
physics = S
moveType = A
ctrl = 0
anim = 1405
sprPriority = 3

[State 1405, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 1407
ignoreHitPause = 1

[State 1405, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S185,0
volume = 255
channel = -1
persistent = 0

[State 1405, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 1405
value = 1405

[State 1405, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[State 1405, VelSet]
type = VelSet
trigger1 = 1
x = ifElse(Root, StateNo =  193, 5.25, 3.25 + var(10))

[State 1405, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1405, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3 || animelem = 4
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pos = 0,0
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1405, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1405, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = Root, StateNo != 193
attr = S,SA
hitflag = MAFD
guardflag = MA
animtype = light
air.animtype = light
fall.animtype = light
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 110, ifElse(var(10), 100, 90)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 110, ifElse(var(10), 100, 90)))), ifElse(var(10) >= 2, 8, 7)
getPower = ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)), 36 * !(Root, var(20))
givePower = 36, 36
pauseTime = 0, ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 0, ifElse((Root, var(20)), 6, 12)
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4.5,-6.56
ground.cornerpush.veloff = -10.5
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4.5,-6.56
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1405, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 1406
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250


;Hit Pause
[StateDef 1406]
type = A
physics = N
moveType = A
ctrl = 0
anim = 1405
sprPriority = 3
moveHitPersist = 1

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3 || animelem = 4
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pos = 0,0
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1406, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1406, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1406, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1406, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1406, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1406, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1406, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1400,1430]
var(18) = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250



;Disappear
[StateDef 1407]
type = A
physics = N
moveType = A
anim = 1406
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 0, VelSet]
type = VelSet
trigger1 = 1
x = -7.36
y = -2.56

[State 0, VelAdd]
type = VelAdd
trigger1 = 1
x = -.73
y = -.32

[State 0, Trans]
type = Trans
trigger1 = 1
trans = addalpha
alpha = 256-(time*12),256

[State 0, DestroySelf]
type = DestroySelf
trigger1 = backedgedist < -250


;Wait
[StateDef 1408]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 1408, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)



;=====================<EX Robo Panther PROJECTILE>=========================
[StateDef 1435]
type = S
physics = N
moveType = A
ctrl = 0
anim = 1405
sprPriority = 3

[State 1435, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = ifElse(var(2) < 2, 1435, 1407)
ignoreHitPause = 1

[State 1435, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S185,0
volume = 255
channel = -1
persistent = 0

[State 1435, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 1405 && !PrevStateNo
value = 1405

[State 1435, VarAdd]
type = VarAdd
trigger1 = !Time
var(2) = 1

[State 1435, VelSet]
type = VelSet
trigger1 = 1
x = ifElse((Time < 2 && var(2) > 1), 1, 8.25)

[State 1435, VelSet]
type = VelSet
trigger1 = 1
x = ifElse((Time < 2 && var(2) > 2), 1, 8.25)

[State 1435, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1435, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 105, Dust Helper]
type = Helper
trigger1 = animelem = 3 || animelem = 4
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pos = 0,0
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 1435, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1435, Hit 1]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = var(2) < 2
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 4 * (var(2) < 2), ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 4 * (var(2) < 2), ifElse((Root, var(20)), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -10.52, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4.31, -7.36
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1435, Hit 2]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = var(2) >= 2
attr = S,SA
hitflag = MAFD
guardflag = MA
animtype = light
air.animtype = light
fall.animtype = light
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 4 * (var(2) < 2), ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 4 * (var(2) < 2), ifElse((Root, var(20)), 6, 12)
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4.5,-6.56
ground.cornerpush.veloff = -10.5
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4.5,-6.56
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd = -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1435, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 1435, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1435, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1435, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 1435, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 1435, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 1435, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1400,1430]
var(18) = 1
persistent = 0

[State 1435, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = ifElse(var(2) < 2, 1435, 1406)
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250

;----------------------------------------------
;Ouroboros
;----------------------------------------------
[Statedef 1505]
type = S
anim = 1410
sprpriority = 3

[State 0, Turn]
type = Turn
trigger1 = root,p2bodydist x < 0 && root,time = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = 1
time = -1
pos = -33,-49

[State 0, ChangeState]
type = ChangeState
trigger1 = root,anim = [1403,1404]
trigger1 = root,animelem = 4
value = 1506

[State 0, ChangeState]
type = ChangeState
trigger1 = roundstate = 4 || root,loseko
value = 1511

;----------------------------------------------
;Ouroboros Attack
;----------------------------------------------
[Statedef 1506]
type = S
anim = 1411
sprpriority = 2
velset = 0,0
facep2 = 1
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = time = 0
time = 1
pos = -33,-49

[State 110, VelSet]
type = VelSet
trigger1 =1
x = 8.5

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal ;player
name = "Fireball Fx"
ID = 1507
stateno = 1507
pos = 0,0
postype = p1    ;p2,front,back,left,right
keyctrl = 0
ownpal = 1
size.xscale = .5
size.yscale = .5

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250
trigger2 = helper(1507),movecontact
trigger3 = helper(1507),anim = 1413
trigger4 = helper(1507),stateno = 1510
ignorehitpause = 1

;=====================<Ouroboros PROJECTILE>=========================
[StateDef 1507]
type = S
physics = N
moveType = A
ctrl = 0
anim = 1412
sprPriority = 3

[State 1005, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = 1509
ignoreHitPause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S1500,1
volume = 255
channel = -1

[State 1005, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 1005, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 1412
value = 1412

[State 1005, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[State 1005, VelSet]
type = VelSet
trigger1 = 1
x = 8.5

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1005, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 1005, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1005, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
attr = S,SP        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAF        ;HLAFD+-
guardflag = MA       ;HLA
animtype = light         ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 100, ifElse(var(10), 90, 80)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 100, ifElse(var(10), 90, 80)))), ifElse(var(10) >= 2, 8, 7)
getPower = ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)), 36 * !(Root, var(20))
givePower = 36, 36
pauseTime = 0, ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 0, ifElse((Root, var(20)), 6, 12)
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4.5,-6.56
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4.5,-6.56
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
sprpriority = 4
palfx.time = 15
palfx.add = 240,50,0
palfx.mul = 250,224,120
palfx.sinadd = 110,55,85,10
palfx.invertall = 1
ignorehitpause = 1

[State 1005, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 1508
ignoreHitPause = 1

[State 1005, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1509
ignoreHitPause = 1

[State 1005, End]
type = DestroySelf
trigger1 = parent,frontedgedist < -250


;Hit Pause
[StateDef 1508]
type = A
physics = N
moveType = A
ctrl = 0
sprPriority = 3
moveHitPersist = 1

[State 1006, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1006, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1500,1530]
var(18) = 1

[State 1006, End]
type = ChangeState
trigger1 = Time >= 0
value = ifElse(var(12) < 2 && var(10) = 3, 1535, 1509)


;Disappear
[StateDef 1509]
type = A
physics = N
moveType = A
anim = 1413
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 1007, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 2,6
channel = 3
volume = -128
lowPriority = 1

[State 1007, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 1007, End]
type = ChangeState
trigger1 = !AnimTime
value = 1510


;Wait
[StateDef 1510]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 1008, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)

;----------------------------------------------
;Ouroboros Walk away After Round
;----------------------------------------------
[Statedef 1511]
type = S
anim = 1414
sprpriority = 3
velset = 0,6.3
facep2 = 1

[State 0, SprPriority]
type = SprPriority
trigger1 = root,loseko
value = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = time = 0
time = 1
pos = -33,-49

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = pos y >= -15
value = 199
elem = 5
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = !anim = 199
y = 0

[State 0, PosSet]
type = PosSet
trigger1 = anim = 199
y = 0

[State 0, VelSet]
type = VelSet
triggerall = root,facing = 1
trigger1 = animelem = 8
trigger1 = anim = 199
x = -2.3

[State 0, VelSet]
type = VelSet
triggerall = root,facing = -1
trigger1 = animelem = 8
trigger1 = anim = 199
x = 2.3

;----------------------------------------------
;Ex Ouroboros
;----------------------------------------------
[Statedef 1535]
type = S
anim = 1410
sprpriority = 3

[State 0, Turn]
type = Turn
trigger1 = root,p2bodydist x < 0 && root,time = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = 1
time = -1
pos = -33,-49

[State 0, ChangeState]
type = ChangeState
trigger1 = root,anim = [1403,1404]
trigger1 = root,animelem = 4
value = 1536

[State 0, ChangeState]
type = ChangeState
trigger1 = roundstate = 4 || root,loseko
value = 1511

;----------------------------------------------
;Ex Ouroboros Attack
;----------------------------------------------
[Statedef 1536]
type = S
anim = 1411
sprpriority = 2
velset = 0,0
facep2 = 1
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = time = 0
time = 1
pos = -33,-49

[State 110, VelSet]
type = VelSet
trigger1 =1
x = 10.5

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal ;player
name = "Fireball Fx"
ID = 1537
stateno = 1537
pos = 0,0
postype = p1    ;p2,front,back,left,right
keyctrl = 0
ownpal = 1
size.xscale = .5
size.yscale = .5

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250
trigger2 = helper(1537),movecontact
trigger3 = helper(1537),anim = 1413
trigger4 = helper(1537),stateno = 1510
ignorehitpause = 1

;=====================<EX Ouroboros PROJECTILE>=========================
[StateDef 1537]
type = S
physics = N
moveType = A
ctrl = 0
anim = 1412
sprPriority = 3

[State 1035, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,AA,AP,AT
time = -1
stateno = ifElse(var(2) < 2, 1537, 1509)
ignoreHitPause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S1500,1
volume = 255
channel = -1

[State 1035, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1
ignoreHitPause = 1

[State 1035, ChangeAnim]
type = ChangeAnim
trigger1 = Anim != 1412 && !PrevStateNo
value = 1412

[State 1035, VarAdd]
type = VarAdd
trigger1 = !Time
var(2) = 1

[State 1035, VelSet]
type = VelSet
trigger1 = 1
x = 10.5

[State 1035, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1035, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1035, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 1035, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1035, Hit 1]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = var(2) < 2
attr = S, SP
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 55 < 7, 7, fvar(11) * 55)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 4 * (var(2) < 2), ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 4 * (var(2) < 2), ifElse((Root, var(20)), 6, 12)
animType = Hard
air.animType = Back
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -10.52, 0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4.31, -7.36
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1035, Hit 2]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
trigger1 = var(2) >= 2
attr = S,SP
hitflag = MAF
guardflag = MA
animtype = light
air.animtype = light
fall.animtype = light
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 55 < 7, 7, fvar(11) * 55)), 8
getPower = 0, 0
givePower = 36, 36
pauseTime = 4 * (var(2) < 2), ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 4 * (var(2) < 2), ifElse((Root, var(20)), 6, 12)
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -4.5,-6.56
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4.5,-6.56
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
sprpriority = 4
palfx.time = 15
palfx.add = 240,50,0
palfx.mul = 250,224,120
palfx.sinadd = 110,55,85,10
palfx.invertall = 1
ignorehitpause = 1

[State 1035, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
persistent = 0
ignorehitPause = 1

[State 1035, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1035, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
persistent = 0
ignoreHitPause = 1

[State 1035, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1
persistent = 0

[State 1035, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1
persistent = 0

[State 1035, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1
persistent = 0

[State 1035, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1000,1030]
var(18) = 1
persistent = 0

[State 1035, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = ifElse(var(2) < 2, 1537, 1509)
ignoreHitPause = 1

[State 1035, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1509
ignoreHitPause = 1

[State 1035, End]
type = DestroySelf
trigger1 = parent,frontedgedist < -250

;----------------------------------------------
;Robo Hawk
;----------------------------------------------
[Statedef 1605]
type = S
anim = 1415
sprpriority = 1
velset = 5.5,.35

[State 0, PosSet]
type = PosSet
trigger1 = time = 1
y = -186

[State 0, VelSet]
type = VelSet
triggerall = root,var(10) = 0
trigger1 = root,facing = 1
trigger1 = pos x >= -75
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = root,var(10) = 0
trigger1 = root,facing = 1
trigger1 = pos x >= -75
value = 1415
persistent = 0

[State 0, VelSet]
type = VelSet
triggerall = root,var(10) = 0
trigger1 = root,facing = -1
trigger1 = pos x <= -95
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = root,var(10) = 0
trigger1 = root,facing = -1
trigger1 = pos x <= -95
value = 1415
persistent = 0

[State 0, VelSet]
type = VelSet
triggerall = root,var(10) = 1
trigger1 = root,facing = 1
trigger1 = pos x >= 0
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = root,var(10) = 1
trigger1 = root,facing = 1
trigger1 = pos x >= 0
value = 1415
persistent = 0

[State 0, VelSet]
type = VelSet
triggerall = root,var(10) = 1
trigger1 = root,facing = -1
trigger1 = pos x <= 0
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = root,var(10) = 1
trigger1 = root,facing = -1
trigger1 = pos x <= 0
value = 1415
persistent = 0

[State 0, VelSet]
type = VelSet
triggerall = root,var(10) = 2
trigger1 = root,facing = 1
trigger1 = pos x >= 95
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = root,var(10) = 2
trigger1 = root,facing = 1
trigger1 = pos x >= 95
value = 1415
persistent = 0

[State 0, VelSet]
type = VelSet
triggerall = root,var(10) = 2
trigger1 = root,facing = -1
trigger1 = pos x <= 75
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = root,var(10) = 2
trigger1 = root,facing = -1
trigger1 = pos x <= 75
value = 1415
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 2
value = S189,0
volume = 0
channel = -1

[State 0, Helper]
type = Helper
triggerall = root,var(10) = 0
trigger1 = time = 8
helpertype = normal
name = "Bomb Drop"
ID = 1606
stateno = 1606
pos = 0,0
postype = p1
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
triggerall = root,var(10) = 1
trigger1 = time = 8
helpertype = normal
name = "Bomb Drop"
ID = 1606
stateno = 1606
pos = 0,0
postype = p1
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
triggerall = root,var(10) = 2
trigger1 = time = 8
helpertype = normal
name = "Bomb Drop"
ID = 1606
stateno = 1606
pos = 0,0
postype = p1
ownpal = 1
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250

;------------------------------------------------
;Bomb carried by Robo Hawk
;------------------------------------------------
[Statedef 1606]
type = A
physics = N
anim = 1417
sprpriority = 2

[State 0, BindToParent]
type = BindToParent
trigger1 = 1
time = -1

[State 0, ChangeState]
type = ChangeState
trigger1 = time=22
triggerall = root,var(10) = 0
value = 1607
ctrl = 0
persistent = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = time=34
triggerall = root,var(10) = 1
value = 1607
ctrl = 0
persistent = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = time=51
triggerall = root,var(10) = 2
value = 1607
ctrl = 0
persistent = 0

;=====================<Robo Hawk PROJECTILE>=========================
[StateDef 1607]
type = S
physics = N
moveType = A
ctrl = 0
anim = 1418
velset = 0,2.15
sprPriority = 3

[State 0, BindToParent]
type = BindToParent
trigger1 = time = 0
time = 0

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 1609
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 1005, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1005, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1005, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
attr = S,SA
hitflag = HLA
guardflag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * ifElse(root,var(10) = 2, 100, ifElse(root,var(10), 90, 80)) < 7, 7, fvar(11) * ifElse(root,var(10) = 2, 100, ifElse(root,var(10), 90, 80)))), ifElse(root,var(10) >= 2, 8, 7)
getPower = ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)), 36 * !(Root, var(20))
givePower = 36, 36
pauseTime = 0, ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 0, ifElse((Root, var(20)), 6, 12)
animType = Hard
air.animtype = hard
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -11.5,0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4.5,-3.4
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
p2stateno = 1611
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1005, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 1608
ignoreHitPause = 1

[State 1005, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1609
ignoreHitPause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = pos y >= 0 || movecontact
value = 1998;3014
elem = 3
persistent = 0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = anim = 1998;3014
x = 0
y = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = pos y >= 0 || movecontact
value = S1500,2
volume = 255
channel = -1
ignorehitpause = 1
persistent = 0

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = anim = 1998;3014
flag = noshadow
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = anim = 1998;3014
trigger1 = !animtime

;Hit Pause
[StateDef 1608]
type = A
physics = N
moveType = A
ctrl = 0
sprPriority = 3
moveHitPersist = 1

[State 1006, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 1500), ifElse(MoveGuarded, 0, 2)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1006, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1600,1630]
var(18) = 1

[State 1006, End]
type = ChangeState
trigger1 = Time >= 0
value = ifElse(var(12) < 2 && var(10) = 3, 1635, 1609)


;Disappear
[StateDef 1609]
type = A
physics = N
moveType = A
anim = 1998
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 1007, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 2,6
channel = 3
volume = -128
lowPriority = 1

[State 1007, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 1007, End]
type = ChangeState
trigger1 = !AnimTime
value = 1610


;Wait
[StateDef 1610]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 1008, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)

;------------------------------------------------
;P2 Hit by Bomb (Custom State)
;------------------------------------------------
[Statedef 1611]
type = A
movetype = H
physics = N

[State 0, PalFXWiz]
type = PalFX
trigger1 = 1
time = 35
add = 240,50,0
mul = 250,224,120
sinadd = 110,55,85,10
invertall = 1
color = 0

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 1420
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = 0
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = animelem = 2
x = 0
y = -8.5      ;A,C,S,N

[State 5040, 5]
type = VelAdd
trigger1 = time > 5
y = .51

[State 0, SelfState]
type = SelfState
trigger1 = time > 20
value = 5040

[State 0, SelfState]
type = SelfState
trigger1 = !alive
value = 5000

;------------------------------------------------
;P2 Hit by Bomb (Custom State)
;------------------------------------------------
[Statedef 1612]
type = A
movetype = H
physics = N

[State 0, PalFXWiz]
type = PalFX
trigger1 = 1
time = 35
add = 240,50,0
mul = 250,224,120
sinadd = 110,55,85,10
invertall = 1
color = 0

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 1420
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = 0
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = animelem = 2
x = -5
y = -8.5      ;A,C,S,N

[State 5040, 5]
type = VelAdd
trigger1 = time > 5
y = .51

[State 0, SelfState]
type = SelfState
trigger1 = time > 20
value = 5040

[State 0, SelfState]
type = SelfState
trigger1 = !alive
value = 5000

;----------------------------------------------
;EX Robo Hawk
;----------------------------------------------
[Statedef 1635]
type = S
anim = 1415
sprpriority = 1
velset = 5.5,.35

[State 0, PosSet]
type = PosSet
trigger1 = time = 1
y = -186

[State 0, VelSet]
type = VelSet
trigger1 = root,facing = 1
trigger1 = pos x >= -75
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,facing = 1
trigger1 = pos x >= -75
value = 1415
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = root,facing = -1
trigger1 = pos x <= -95
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,facing = -1
trigger1 = pos x <= -95
value = 1415
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 2
value = S189,0
volume = 0
channel = -1

[State 0, Helper]
type = Helper
trigger1 = time = 8
helpertype = normal
name = "Bomb Drop"
ID = 1636
stateno = 1636
pos = 0,0
postype = p1
ownpal = 1
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250

;------------------------------------------------
;EX Bomb carried by Robo Hawk
;------------------------------------------------
[Statedef 1636]
type = A
physics = N
anim = 1417
sprpriority = 2

[State 0, BindToParent]
type = BindToParent
trigger1 = 1
time = -1

[State 0, ChangeState]
type = ChangeState
trigger1 = time = 25
value = 1637
ctrl = 0
persistent = 0

;----------------------------------------------
;EX Robo Hawk
;----------------------------------------------
[Statedef 1645]
type = S
anim = 1415
sprpriority = 1
velset = 5.5,.35

[State 0, PosSet]
type = PosSet
trigger1 = time = 1
y = -186

[State 0, VelSet]
type = VelSet
trigger1 = root,facing = 1
trigger1 = pos x >= -75
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,facing = 1
trigger1 = pos x >= -75
value = 1415
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = root,facing = -1
trigger1 = pos x <= -95
y = -2.15

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,facing = -1
trigger1 = pos x <= -95
value = 1415
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 2
value = S189,0
volume = 0
channel = -1

[State 0, Helper]
type = Helper
trigger1 = time = 8
helpertype = normal
name = "Bomb Drop"
ID = 1646
stateno = 1646
pos = 0,0
postype = p1
ownpal = 1
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250

;------------------------------------------------
;EX Bomb carried by Robo Hawk
;------------------------------------------------
[Statedef 1646]
type = A
physics = N
anim = 1417
sprpriority = 2

[State 0, BindToParent]
type = BindToParent
trigger1 = 1
time = -1

[State 0, ChangeState]
type = ChangeState
trigger1 = time = 45
value = 1637
ctrl = 0
persistent = 0

;=====================<EX Robo Hawk PROJECTILE>=========================
[StateDef 1637]
type = S
physics = N
moveType = A
ctrl = 0
anim = 1418
velset = 0,2.15
sprPriority = 3

[State 0, BindToParent]
type = BindToParent
trigger1 = time = 0
time = 0

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 1639
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 1005, Button Detect]
type = VarSet
trigger1= !Time && !PrevStateNo
var(10) = Root, var(10)

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1005, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 1005, HitDef]
type = HitDef
trigger1 = !(Root, var(16)) && (Root, var(15) < 1 || Root, var(20))
attr = S,SA
hitflag = HLA
guardflag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 60 < 7, 7, fvar(11) * 60)), 8
getPower = ifElse(!(Root, var(13)), 144, 72) * !(Root, var(20)), 36 * !(Root, var(20))
givePower = 36, 36
pauseTime = 0, ifElse((Root, var(20)), 6, 12)
guard.pauseTime = 0, ifElse((Root, var(20)), 6, 12)
animType = Hard
air.animtype = hard
fall.animType = Back
ground.type = High
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 60
airGuard.ctrlTime = 16
ground.velocity = -11.5,0
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -4.5,-3.4
air.cornerPush.velOff = 0
airGuard.velocity = -5, 0
airGuard.cornerPush.velOff = 0
p2stateno = 1612
yAccel = 0.58
fall = 0
air.fall = 1
fall.recover = 1
fall.recoverTime = 22 + ifElse(var(20), 6, 12)
forceStand = 1
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
palFX.time = 12 * var(9)
palFX.add = 255,255,255
palFX.sinAdd= -255,-255,-255,48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
sprPriority = 3

[State 1005, ChangeState]
type = ChangeState
trigger1 = MoveContact
value = 1638
ignoreHitPause = 1

[State 1005, ChangeState]
type = ChangeState
trigger1 = MoveReversed
value = 1639
ignoreHitPause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = pos y >= 0 || movecontact
value = 1998;3014
elem = 3
persistent = 0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = anim = 1998;3014
x = 0
y = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = pos y >= 0 || movecontact
value = S1500,2
volume = 255
channel = -1
ignorehitpause = 1
persistent = 0

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = anim = 1998;3014
flag = noshadow
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = anim = 1998;3014
trigger1 = !animtime

;Hit Pause
[StateDef 1638]
type = A
physics = N
moveType = A
ctrl = 0
sprPriority = 3
moveHitPersist = 1

[State 1006, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 1500), ifElse(MoveGuarded, 0, 2)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 1006, ProjContact]
type = ParentVarSet
trigger1 = MoveContact && NumTarget
trigger1 = Root, StateNo = [1600,1630]
var(18) = 1

[State 1006, End]
type = ChangeState
trigger1 = Time >= 0
value = 1639


;Disappear
[StateDef 1639]
type = A
physics = N
moveType = A
anim = 1998
ctrl = 0
velSet = 0,0
sprPriority = 3
moveHitPersist = 1

[State 1007, PlaySnd]
type = PlaySnd
trigger1 = !Time
value = 2,6
channel = 3
volume = -128
lowPriority = 1

[State 1007, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 1007, End]
type = ChangeState
trigger1 = !AnimTime
value = 1640


;Wait
[StateDef 1640]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 1008, End]
type = DestroySelf
trigger1 = !NumTarget
trigger2 = NumTarget
trigger2 = Target, Time <= 1 && !(Target,HitShakeOver)

;----------------------------
;Slash Helper 1
;----------------------------
[Statedef 2210]
type = S
ctrl = 0
anim = 211
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 210
ignorehitpause = 1

;----------------------------
;Slash Helper 2
;----------------------------
[Statedef 2220]
type = S
ctrl = 0
anim = 221
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 220
ignorehitpause = 1

;----------------------------
;Slash Helper 3
;----------------------------
[Statedef 2240]
type = S
ctrl = 0
anim = 241
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 240
ignorehitpause = 1

;----------------------------
;Slash Helper 4
;----------------------------
[Statedef 2250]
type = S
ctrl = 0
anim = 251
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 250
ignorehitpause = 1

;----------------------------
;Slash Helper 5
;----------------------------
[Statedef 2410]
type = S
ctrl = 0
anim = 411
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 410
ignorehitpause = 1

;----------------------------
;Slash Helper 6
;----------------------------
[Statedef 2420]
type = S
ctrl = 0
anim = 421
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 420
ignorehitpause = 1

;----------------------------
;Slash Helper 7
;----------------------------
[Statedef 2440]
type = S
ctrl = 0
anim = 441
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 440
ignorehitpause = 1

;----------------------------
;Slash Helper 8
;----------------------------
[Statedef 2450]
type = S
ctrl = 0
anim = 451
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 450
ignorehitpause = 1

;----------------------------
;Slash Helper 9
;----------------------------
[Statedef 2610]
type = S
ctrl = 0
anim = 611
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;----------------------------
;Slash Helper 10
;----------------------------
[Statedef 2620]
type = S
ctrl = 0
anim = 621
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;----------------------------
;Slash Helper 11
;----------------------------
[Statedef 2640]
type = S
ctrl = 0
anim = 641
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;----------------------------
;Slash Helper 12
;----------------------------
[Statedef 2650]
type = S
ctrl = 0
anim = 651
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;----------------------------
;Slash Helper special 1
;----------------------------
[Statedef 2130]
type = s
movetype = i
physics = n
sprpriority = 4
ignorehitpause = 1

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = root,stateno = 1300
pos = 0,0
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1300
trigger1 = time = 0
value = 1306
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 1300
ignorehitpause = 1

;----------------------------
;Slash Helper special 2
;----------------------------
[Statedef 2131]
type = s
movetype = i
physics = n
sprpriority = 4
ignorehitpause = 1

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = root,stateno = 1300
pos = 0,0
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1300
trigger1 = time = 0
value = 1307
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 1300
ignorehitpause = 1

;----------------------------
;Slash Helper special 3
;----------------------------
[Statedef 2132]
type = s
movetype = i
physics = n
sprpriority = 4
ignorehitpause = 1

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = root,stateno = 1300
pos = 0,0
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1300
trigger1 = time = 0
value = 1308
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 1300
ignorehitpause = 1

;----------------------------
;Slash Helper special 4
;----------------------------
[Statedef 2133]
type = s
movetype = i
physics = n
sprpriority = 4
ignorehitpause = 1

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = root,stateno = 1330
pos = 0,0
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1330
trigger1 = time = 0
value = 1309
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 1330
ignorehitpause = 1

;----------------------------
;Slash Helper x
;----------------------------
[Statedef 2805]
type = S
ctrl = 0
anim = 1805
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 1800 || time = 10
ignorehitpause = 1

;----------------------------
;Slash Helper x
;----------------------------
[Statedef 2835]
type = S
ctrl = 0
anim = 1805
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 1830 || time = 10
ignorehitpause = 1

;----------------------------
;Slash Helper 1
;----------------------------
[Statedef 2930]
type = S
ctrl = 0
anim = 211
sprpriority = 2

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S0,5
volume = 255
channel = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H
trigger2 = root,stateno != 2900
ignorehitpause = 1

;----------------------------------------------
;Ouroboros
;----------------------------------------------
[StateDef 3010]
type = S
movetype = A
anim = 3001
ctrl = 0
sprpriority = 4

[State 0, VarAdd]
type = VarAdd
trigger1 = 1
v = 1
value = 1
ignorehitpause = 1

[State 0, VarAdd]
type = VarAdd
trigger1 = 1
fv = 1
value = -3

[State 0, BindToRoot]
type = BindToRoot
trigger1 = 1
time = -1
pos = 0,-47
ignorehitpause = 1

[State 0, Ouroboros]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Ouroboros Attack Helper"
ID = 3011
stateno = 3011
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1

[State 0, Ouroboros]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Ouroboros Attack Helper"
ID = 3012
stateno = 3011
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1

[State 0, Ouroboros]
type = Helper
trigger1 = var(1) > 240 && animelem = 16
trigger2 = root,stateno = 3202 && animelem = 16
trigger3 = !root,alive && animelem = 16
helpertype = normal
stateno = 3012
id = 3013
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = var(1) > 240 && animelem = 16
trigger2 = root,stateno = 3202 && animelem = 16
trigger3 = !root,alive && animelem = 16
value = 3012

;----------------------------------------------
;Ouroboros rotating Hit Box
;----------------------------------------------
[Statedef 3011]
type = S
movetype = A
anim = 3002
ctrl = 0
sprpriority = 3
juggle = -1

[State 0, VarAdd]
type = VarAdd
trigger1 = 1
fv = 1
value = 6.85

[State 0, BindToParent]
type = BindToParent
trigger1 = ishelper(3011)
trigger1 = time >= 0
pos = 50*cos(fvar(1)*-Pi/180),50*sin(fvar(1)*-Pi/180)

[State 0, BindToParent]
type = BindToParent
trigger1 = ishelper(3012)
trigger1 = time >= 0
pos = -50*cos(fvar(1)*-Pi/180),-50*sin(fvar(1)*-Pi/180)

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NP,SP,HP
time = -1
stateno = 3011

[State 0, Turn]
type = Turn
trigger1 = p2dist x <= -35 ;&& root,statetype != A
ignorehitpause = 1

[State 1035, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1035, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1035, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 0, HitDef]
type = HitDef
trigger1 = time > 30
trigger1 = enemynear,hitshakeover
trigger2 = time > 60
trigger2 = enemynear,stateno = [910,921]
attr = SCA,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA          ;B,E,F
animtype = light          ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 12 < 7, 7, fvar(11) * 12)), 0
pausetime = 0,14
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 135), var(36) := -79
ground.type = High      ;Low,Trip,None
air.type = High
ground.hittime = 5
ground.slidetime = 10
air.hittime = 5
ground.velocity = -12,0
air.velocity = -6,ifelse(enemynear,pos y >= 0,-2.1,0)
p2facing = 1
sprpriority = 3
envshake.time = 5
envshake.freq = 60
envshake.ampl = -4
envshake.phase = 90
ignorehitpause = 1

[State 0, HitDef]
type = HitDef
triggerall = time > 30
trigger1 = (enemynear,stateno = 5110 || enemynear,stateno = 5150 && enemynear,alive)
attr = SCA,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = DF        ;HLAFD+-
guardflag = MA          ;B,E,F
animtype = light          ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 12 < 7, 7, fvar(11) * 12)), 0
pausetime = 0,14
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 135), var(36) := -79
ground.type = High      ;Low,Trip,None
air.type = High
ground.hittime = 5
ground.slidetime = 10
air.hittime = 5
ground.velocity = -12,0
air.velocity = -6,ifelse(enemynear,pos y >= 0,-2.1,0)
p2facing = 1
sprpriority = 3
envshake.time = 5
envshake.freq = 60
envshake.ampl = -4
envshake.phase = 90
ignorehitpause = 1
p2stateno = ifelse((enemynear,name = "Hiryu" && enemynear,authorname = "ImmortaL -SyN-"),911,910)

[State 1006, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 3206, VarSet]
type = VarAdd
trigger1 = 1
var(14) = 1

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3000,3050]
var(18) = 1

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit = 1
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1

[State 0, Ouroboros Projectile]
type = Helper
trigger1 = (root,command = "x" || root,command = "y" || root,command = "z")
helpertype = normal
name = "Ouroboros Projectile"
ID = 3014
stateno = 3013
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1
size.xscale = .5
size.yscale = .5
ignorehitpause = 1
persistent = 30

[State 0, DestroySelf]
type = DestroySelf
trigger1 = parent,var(1) > 240
trigger2 = root,stateno = 3202
trigger3 = root,loseko
ignorehitpause = 1

;----------------------------------------------
;Ouroboros Walk away
;----------------------------------------------
[Statedef 3012]
type = S
movetype = A
anim = 1414
sprpriority = 5
facep2 = 1

[State 0, ParentVarSet]
type = ParentVarSet
triggerall = root,var(25) != 2
trigger1 = time = 0
v = 25    ;fv =
value = 0
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(3010)
trigger1 = time = 0
time = 1
pos = 1,-85
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(3013)
trigger1 = time = 0
time = 1
pos = 1,-3
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3010)
trigger1 = time <= 10
y = -1.1
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3013)
y = 3.3
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3010)
trigger1 = anim != 199
y = .35
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3013)
trigger1 = anim != 199
y = 1.35
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = pos y >= -15
value = 199
elem = 5
persistent = 0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = anim = 199
y = 0
ignorehitpause = 1

[State 0, PosSet]
type = PosSet
trigger1 = anim = 199
y = 0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = animelem = 8
trigger1 = anim = 199
x = -3.32
persistent = 0
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = backedgedist <= -50

;------------------------------------------
;Ouroboros Projectiles
;------------------------------------------
[Statedef 3013]
type = A
movetype = A
physics = N
anim = 3003
velset = 5.02,0
sprpriority = 4
ignorehitpause = 1
juggle = -1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 0, BindToParent]
type = BindToParent
trigger1 = time = 0
time = 1
pos = 0,0
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = 1
value = ifelse(root,var(25) = 2 && (root,stateno = [3201,3202]), 3004,3003)
ignorehitpause = 1

[State 0, ]
type = AfterImage
trigger1 = time = 0
time = -1
length = 7
PalBright =  0,0,0
PalContrast = 120,120,220
PalAdd = 20,23,23
PalMul = .77,.77,.77
trans = add
TimeGap = 2
FrameGap = 2
ignorehitpause = 1

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = SCA,HP        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA
getpower = 0,0
givepower = 10,5         ;B,E,F
animtype = light          ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 12 < 7, 7, fvar(11) * 12)), 0
pausetime = 2,6
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
ground.type = High      ;Low,Trip,None
air.type = High
ground.hittime = 20
ground.slidetime = 20
air.hittime = 20
ground.velocity = -12,0
air.velocity = -3,ifelse(enemynear,pos y >= 0,-2.1,0)
sprpriority = 3
envshake.time = 5
envshake.freq = 60
envshake.ampl = -4
envshake.phase = 90
ignorehitpause = 1
persistent = 0
ignorehitpause = 1

[State 3206, VarSet]
type = VarAdd
trigger1 = 1
var(14) = 1

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3000,3050]
var(18) = 1

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, Pause]
type = Pause
trigger1 = enemy,life = 0
time = 10
persistent = 0
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250
trigger2 = movecontact

;----------------------------------------------
;Ouroboros
;----------------------------------------------
[StateDef 3060]
type = S
movetype = A
anim = 3001
ctrl = 0
sprpriority = 4

[State 0, VarAdd]
type = VarAdd
trigger1 = 1
v = 1
value = 1
ignorehitpause = 1

[State 0, VarAdd]
type = VarAdd
trigger1 = 1
fv = 1
value = -3

[State 0, BindToRoot]
type = BindToRoot
trigger1 = 1
time = -1
pos = 0,-47
ignorehitpause = 1

[State 0, Ouroboros]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Ouroboros Attack Helper"
ID = 3061
stateno = 3061
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1

[State 0, Ouroboros]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Ouroboros Attack Helper"
ID = 3062
stateno = 3061
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1

[State 0, Ouroboros]
type = Helper
trigger1 = var(1) > 480 && animelem = 16
trigger2 = root,stateno = 3202 && animelem = 16
trigger3 = !root,alive && animelem = 16
helpertype = normal
stateno = 3062
id = 3063
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = var(1) > 480 && animelem = 16
trigger2 = root,stateno = 3202 && animelem = 16
trigger3 = !root,alive && animelem = 16
value = 3062

;----------------------------------------------
;Ouroboros rotating Hit Box
;----------------------------------------------
[Statedef 3061]
type = S
movetype = A
anim = 3002
ctrl = 0
sprpriority = 3
juggle = -1

[State 0, VarAdd]
type = VarAdd
trigger1 = 1
fv = 1
value = 6.85

[State 0, BindToParent]
type = BindToParent
trigger1 = ishelper(3061)
trigger1 = time >= 0
pos = 50*cos(fvar(1)*-Pi/180),50*sin(fvar(1)*-Pi/180)

[State 0, BindToParent]
type = BindToParent
trigger1 = ishelper(3062)
trigger1 = time >= 0
pos = -50*cos(fvar(1)*-Pi/180),-50*sin(fvar(1)*-Pi/180)

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NP,SP,HP
time = -1

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NP,SP,HP
time = -1
stateno = 3061

[State 0, Turn]
type = Turn
trigger1 = p2dist x <= -35 ;&& root,statetype != A
ignorehitpause = 1

[State 1035, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1035, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 1035, Miss]
type = HitDef
trigger1 = 1
attr = S,SP
hitFlag =
sparkXY = -10,0

[State 0, HitDef]
type = HitDef
trigger1 = time > 30
trigger1 = enemynear,hitshakeover
trigger2 = time > 60
trigger2 = enemynear,stateno = [910,921]
attr = SCA,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA          ;B,E,F
animtype = light          ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 8 < 7, 7, fvar(11) * 8)), 0
pausetime = 0,14
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 135), var(36) := -79
ground.type = High      ;Low,Trip,None
air.type = High
ground.hittime = 5
ground.slidetime = 10
air.hittime = 5
ground.velocity = -12,0
air.velocity = -6,ifelse(enemynear,pos y >= 0,-2.1,0)
p2facing = 1
sprpriority = 3
envshake.time = 5
envshake.freq = 60
envshake.ampl = -4
envshake.phase = 90
ignorehitpause = 1

[State 0, HitDef]
type = HitDef
triggerall = time > 30
trigger1 = (enemynear,stateno = 5110 || enemynear,stateno = 5150 && enemynear,alive)
attr = SCA,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = DF        ;HLAFD+-
guardflag = MA          ;B,E,F
animtype = light          ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 8 < 7, 7, fvar(11) * 8)), 0
pausetime = 0,14
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 6)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 135), var(36) := -79
ground.type = High      ;Low,Trip,None
air.type = High
ground.hittime = 5
ground.slidetime = 10
air.hittime = 5
ground.velocity = -12,0
air.velocity = -6,ifelse(enemynear,pos y >= 0,-2.1,0)
p2facing = 1
sprpriority = 3
envshake.time = 5
envshake.freq = 60
envshake.ampl = -4
envshake.phase = 90
ignorehitpause = 1
p2stateno = ifelse((enemynear,name = "Hiryu" && enemynear,authorname = "ImmortaL -SyN-"),911,910)

[State 1006, PosFreeze]
type = PosFreeze
trigger1 = 1
value = 1

[State 3206, VarSet]
type = VarAdd
trigger1 = 1
var(14) = 1

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3000,3050]
var(18) = 1

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit = 1
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1

[State 0, Ouroboros Projectile]
type = Helper
trigger1 = (root,command = "x" || root,command = "y" || root,command = "z")
helpertype = normal
name = "Ouroboros Projectile"
ID = 3064
stateno = 3063
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1
size.xscale = .5
size.yscale = .5
ignorehitpause = 1
persistent = 30

[State 0, DestroySelf]
type = DestroySelf
trigger1 = parent,var(1) > 480
trigger2 = root,stateno = 3202
trigger3 = root,loseko
ignorehitpause = 1

;----------------------------------------------
;Ouroboros Walk away
;----------------------------------------------
[Statedef 3062]
type = S
movetype = A
anim = 1414
sprpriority = 5
facep2 = 1

[State 0, ParentVarSet]
type = ParentVarSet
triggerall = root,var(25) != 2
trigger1 = time = 0
v = 25    ;fv =
value = 0
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(3060)
trigger1 = time = 0
time = 1
pos = 1,-85
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(3063)
trigger1 = time = 0
time = 1
pos = 1,-3
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3060)
trigger1 = time <= 10
y = -1.1
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3063)
y = 3.3
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3060)
trigger1 = anim != 199
y = .35
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3063)
trigger1 = anim != 199
y = 1.35
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = pos y >= -15
value = 199
elem = 5
persistent = 0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = anim = 199
y = 0
ignorehitpause = 1

[State 0, PosSet]
type = PosSet
trigger1 = anim = 199
y = 0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = animelem = 8
trigger1 = anim = 199
x = -3.32
persistent = 0
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = backedgedist <= -50

;------------------------------------------
;Ouroboros Projectiles
;------------------------------------------
[Statedef 3063]
type = A
movetype = A
physics = N
anim = 3003
velset = 5.02,0
sprpriority = 4
ignorehitpause = 1
juggle = -1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
ignorehitpause = 1

[State 0, BindToParent]
type = BindToParent
trigger1 = time = 0
time = 1
pos = 0,0
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = 1
value = ifelse(root,var(25) = 2 && (root,stateno = [3201,3202]), 3004,3003)
ignorehitpause = 1

[State 0, ]
type = AfterImage
trigger1 = time = 0
time = -1
length = 7
PalBright =  0,0,0
PalContrast = 120,120,220
PalAdd = 20,23,23
PalMul = .77,.77,.77
trans = add
TimeGap = 2
FrameGap = 2
ignorehitpause = 1

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = SCA,HP        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA
getpower = 0,0
givepower = 8,5         ;B,E,F
animtype = light          ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 10 < 7, 7, fvar(11) * 10)), 0
pausetime = 2,6
hitSound = -1
guardSound = -1
sparkNo = -1
guard.SparkNo = -1
sparkXY = -10, -32
ground.type = High      ;Low,Trip,None
air.type = High
ground.hittime = 20
ground.slidetime = 20
air.hittime = 20
ground.velocity = -12,0
air.velocity = -3,ifelse(enemynear,pos y >= 0,-2.1,0)
sprpriority = 3
envshake.time = 5
envshake.freq = 60
envshake.ampl = -4
envshake.phase = 90
ignorehitpause = 1
persistent = 0
ignorehitpause = 1

[State 3206, VarSet]
type = VarAdd
trigger1 = 1
var(14) = 1

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8013)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3000,3050]
var(18) = 1

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, Pause]
type = Pause
trigger1 = enemy,life = 0
time = 10
persistent = 0
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250
trigger2 = movecontact

;---------------------------------------------------
;Legion (Swarm of Robo Panthers and Robo Hawks)
;---------------------------------------------------
[Statedef 3120]
type = S
anim = 6666

[State 0, VarSet]
type = VarSet
trigger1 = time = 0
var(1) = 440

[State 0, VarSet]
type = VarSet
trigger1 = time = 0
var(42) = root,facing

;=======<Robo Panthers>===========
[State 0, Helper]
type = Helper
trigger1 = time = 1
helpertype = normal
name = "RoboPanther A 1"
ID = 3120
stateno = 3121
pos = (ifelse(root,facing = 1, -75,-75+var(1))),-55
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 10
helpertype = normal
name = "RoboPanther A 2"
ID = 3120
stateno = 3121
pos = (ifelse(root,facing = 1, -65,-65+var(1))),-65
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 20
helpertype = normal
name = "RoboPanther A 3"
ID = 3120
stateno = 3121
pos = (ifelse(root,facing = 1, -50,-50+var(1))),-75
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "RoboPanther B"
ID = 3122
stateno = 3122
pos = (ifelse(root,facing = 1, -50,-50+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 4
helpertype = normal
name = "RoboPanther C 1"
ID = 3123
stateno = 3123
pos = (ifelse(root,facing = 1, -90,-90+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 16
helpertype = normal
name = "RoboPanther C 2"
ID = 3124
stateno = 3123
pos = (ifelse(root,facing = 1, -70,-70+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 28
helpertype = normal
name = "RoboPanther C 2"
ID = 3125
stateno = 3123
pos = (ifelse(root,facing = 1, 50,50+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

;=======<Robo Hawks>===========

[State 0, Helper]
type = Helper
trigger1 = time = 4
helpertype = normal
name = "RoboHawk 1"
ID = 3126
stateno = 3124
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-105
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 14
helpertype = normal
name = "RoboHawk 2"
ID = 3127
stateno = 3124
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-155
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 24
helpertype = normal
name = "RoboHawk 3"
ID = 3128
stateno = 3124
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-105
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 34
helpertype = normal
name = "RoboHawk 4"
ID = 3129
stateno = 3124
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-155
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 44
helpertype = normal
name = "RoboHawk 5"
ID = 3130
stateno = 3124
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-105
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 54
helpertype = normal
name = "RoboHawk 6"
ID = 3131
stateno = 3124
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-155
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 64
helpertype = normal
name = "RoboHawk 7"
ID = 3132
stateno = 3124
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-105
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 74
helpertype = normal
name = "RoboHawk 8"
ID = 3133
stateno = 3124
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-155
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, ParentVarSet]
type = ParentVarSet
trigger1 = time > 120
v = 25    ;fv =
value = 0
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 150

;------------------------------------
;Robo Panther Jump Down
;------------------------------------
[Statedef 3121]
type = S
movetype = A
physics = N
velset = 4.7,-3.9
sprpriority = 3
juggle = 15

[State 0, Gravity]
type = Gravity
triggerall = time > 2
trigger1 = pos y < 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 3120

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = pos y >= 0
value = 3121
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0
persistent = 0

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 3111
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S185,0
volume = 255
channel = -1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = S,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA
getpower = 0,0
givepower = 10,5      ;HLA
animtype = light         ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
pausetime = 5,10
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 92), var(36) := -35
ground.type = high     ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
ground.velocity = -4.5,-6.56
air.velocity = -4.5,-6.56
persistent = 0
ignorehitpause = 1
fall = 1
fall.recover = 0

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = anim = 3121
trigger1 =!animtime
value = 3122

;----------------------------------------------
;Robo Panther Runs towards Enemy
;----------------------------------------------
[Statedef 3122]
type = S
movetype = A
physics = S
anim = 1405
sprpriority = 3
juggle = 15

[State 0, VelSet]
type = VelSet
trigger1 = 1
x = 6.8

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 3111
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S185,0
volume = 255
channel = -1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = S,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA       ;HLA
animtype = light         ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
pausetime = 5,10
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 92), var(36) := -35
ground.type = high     ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
ground.velocity = -4.5,-6.56
air.velocity = -4.5,-6.56
persistent = 0
ignorehitpause = 1
fall = 1
fall.recover = 0

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250

;----------------------------------------
;Robo Panther Pounce
;----------------------------------------
[Statedef 3123]
type = S
movetype = A
physics = N
sprpriority = 3
juggle = 15

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 3121
persistent = 0

[State 0, VelAdd]
type = Velset
trigger1 = anim = 3121
x = 0
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = anim = 3121
trigger1 = !animtime
value = 3122

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3125)
trigger1 = anim = 3122
x = 2.57

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3125)
trigger1 = anim = 3122
trigger1 = animelemtime(1) < 20
y = -1.6

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3124)
trigger1 = anim = 3122
x = 6.57

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3124)
trigger1 = anim = 3122
trigger1 = animelemtime(1) < 20
y = -3.6

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3123)
trigger1 = anim = 3122
x = 4.57

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3123)
trigger1 = anim = 3122
trigger1 = animelemtime(1) < 20
y = -2.6

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 3122
x = 4.4

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 3122
trigger1 = animelemtime(1) < 20
y = -.28

[State 0, VelAdd]
type = VelAdd
trigger1 = pos y <= 0
trigger1 = anim = 3122
trigger1 = animelemtime(1) >= 20
y = .28

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = anim = 3122 && time > 20
trigger1 = pos y >= 0
value = 3121
persistent = 0

[State 0, PosSet]
type = PosSet
trigger1 = anim = 3121
y = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = S,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA       ;HLA
animtype = light         ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
pausetime = 5,10
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 92), var(36) := -35
ground.type = high     ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
ground.velocity = -4.5,-6.56
air.velocity = -4.5,-6.56
persistent = 0
ignorehitpause = 1
fall = 1
fall.recover = 0

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 3111
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250

;----------------------------------------
;Robo Hawks Glide Attack
;----------------------------------------
[Statedef 3124]
type = S
movetype = A
physics = N
anim = 3123
sprpriority = 2
velset = 10.35,.75
ignorehitpause = 1
juggle = 15

[State 0, PosSet]
type = PosSet
trigger1 = ishelper(3126)
y = -98
persistent = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3126)
x = .023
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3126)
y = -.15
ignorehitpause = 1
;-------------------------
[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3127)
trigger1 = time > 10
x = -.025
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3127)
y = -.075
ignorehitpause = 1
;-------------------------
[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3128)
x = -.035
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3128)
y = -.095
ignorehitpause = 1
;-------------------------
[State 0, PosSet]
type = PosSet
trigger1 = ishelper(3129)
y = -142
persistent = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3129)
x = -.025
ignorehitpause = 1
;--------------------------
[State 0, PosSet]
type = PosSet
trigger1 = ishelper(3130)
y = -122
persistent = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3130)
y = -.085
ignorehitpause = 1
;--------------------------
[State 0, PosSet]
type = PosSet
trigger1 = ishelper(3131)
y = -132
persistent = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3131)
y = -.095
ignorehitpause = 1
;--------------------------
[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3132)
x = .023
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3132)
y = -.14
ignorehitpause = 1
;--------------------------
[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3133)
x = -.023
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3133)
trigger1 = time < 10
y = .031
ignorehitpause = 1

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = S,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA       ;HLA
animtype = light         ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
pausetime = 5,10
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 15), var(36) := -35
ground.type = high     ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
ground.velocity = -4.5,-6.56
air.velocity = -4.5,-6.56
persistent = 0
ignorehitpause = 1
fall = 1
fall.recover = 0

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 3112
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -120
ignorehitpause = 1

;---------------------------------------------------
;Legion (Swarm of Robo Panthers and Robo Hawks)
;---------------------------------------------------
[Statedef 3160]
type = S
anim = 6666

[State 0, VarSet]
type = VarSet
trigger1 = time = 0
var(1) = 440

[State 0, VarSet]
type = VarSet
trigger1 = time = 0
var(42) = root,facing

;=======<Robo Panthers>===========
[State 0, Helper]
type = Helper
trigger1 = time = 1
helpertype = normal
name = "RoboPanther A 1"
ID = 3160
stateno = 3161
pos = (ifelse(root,facing = 1, -75,-75+var(1))),-55
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 10
helpertype = normal
name = "RoboPanther A 2"
ID = 3160
stateno = 3161
pos = (ifelse(root,facing = 1, -65,-65+var(1))),-65
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 20
helpertype = normal
name = "RoboPanther A 3"
ID = 3160
stateno = 3161
pos = (ifelse(root,facing = 1, -50,-50+var(1))),-75
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 30
helpertype = normal
name = "RoboPanther A 4"
ID = 3160
stateno = 3161
pos = (ifelse(root,facing = 1, -45,-45+var(1))),-85
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "RoboPanther B 1"
ID = 3162
stateno = 3162
pos = (ifelse(root,facing = 1, -50,-50+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 10
helpertype = normal
name = "RoboPanther B 2"
ID = 3162
stateno = 3162
pos = (ifelse(root,facing = 1, -35,-35+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 20
helpertype = normal
name = "RoboPanther B 3"
ID = 3162
stateno = 3162
pos = (ifelse(root,facing = 1, -20,-20+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 4
helpertype = normal
name = "RoboPanther C 1"
ID = 3163
stateno = 3163
pos = (ifelse(root,facing = 1, -90,-90+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 16
helpertype = normal
name = "RoboPanther C 2"
ID = 3164
stateno = 3163
pos = (ifelse(root,facing = 1, -70,-70+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 28
helpertype = normal
name = "RoboPanther C 2"
ID = 3165
stateno = 3163
pos = (ifelse(root,facing = 1, 50,50+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 40
helpertype = normal
name = "RoboPanther C 2"
ID = 3165
stateno = 3163
pos = (ifelse(root,facing = 1, -90,-90+var(1))),0
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

;=======<Robo Hawks>===========

[State 0, Helper]
type = Helper
trigger1 = time = 4
helpertype = normal
name = "RoboHawk 1"
ID = 3166
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-105
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 14
helpertype = normal
name = "RoboHawk 2"
ID = 3167
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-155
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 24
helpertype = normal
name = "RoboHawk 3"
ID = 3168
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-105
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 34
helpertype = normal
name = "RoboHawk 4"
ID = 3169
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-155
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 44
helpertype = normal
name = "RoboHawk 5"
ID = 3170
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-105
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 54
helpertype = normal
name = "RoboHawk 6"
ID = 3171
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-155
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 64
helpertype = normal
name = "RoboHawk 7"
ID = 3172
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-105
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 74
helpertype = normal
name = "RoboHawk 8"
ID = 3173
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-155
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 84
helpertype = normal
name = "RoboHawk 9"
ID = 3174
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-105
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 94
helpertype = normal
name = "RoboHawk 10"
ID = 3175
stateno = 3164
pos = (ifelse(root,facing = 1, -50, -50+var(1))),-155
postype = left
facing = var(42)
ownpal = 1
ignorehitpause = 1

[State 0, ParentVarSet]
type = ParentVarSet
trigger1 = time > 120
v = 25    ;fv =
value = 0
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 150

;------------------------------------
;Robo Panther Jump Down
;------------------------------------
[Statedef 3161]
type = S
movetype = A
physics = N
velset = 4.7,-3.9
sprpriority = 3
juggle = 15

[State 0, Gravity]
type = Gravity
triggerall = time > 2
trigger1 = pos y < 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 3120

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = pos y >= 0
value = 3121
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0
persistent = 0

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 3111
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S185,0
volume = 255
channel = -1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = S,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA
getpower = 0,0
givepower = 10,5      ;HLA
animtype = light         ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
pausetime = 5,10
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 92), var(36) := -35
ground.type = high     ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
ground.velocity = -4.5,-6.56
air.velocity = -4.5,-6.56
persistent = 0
ignorehitpause = 1
fall = 1
fall.recover = 0

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = anim = 3121
trigger1 =!animtime
value = 3162

;----------------------------------------------
;Robo Panther Runs towards Enemy
;----------------------------------------------
[Statedef 3162]
type = S
movetype = A
physics = S
anim = 1405
sprpriority = 3
juggle = 15

[State 0, VelSet]
type = VelSet
trigger1 = 1
x = 6.8

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 3111
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S185,0
volume = 255
channel = -1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = S,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA       ;HLA
animtype = light         ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
pausetime = 5,10
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 92), var(36) := -35
ground.type = high     ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
ground.velocity = -4.5,-6.56
air.velocity = -4.5,-6.56
persistent = 0
ignorehitpause = 1
fall = 1
fall.recover = 0

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250

;----------------------------------------
;Robo Panther Pounce
;----------------------------------------
[Statedef 3163]
type = S
movetype = A
physics = N
sprpriority = 3
juggle = 15

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 3121
persistent = 0

[State 0, VelAdd]
type = Velset
trigger1 = anim = 3121
x = 0
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = anim = 3121
trigger1 = !animtime
value = 3122

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3165)
trigger1 = anim = 3122
x = 2.57

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3165)
trigger1 = anim = 3122
trigger1 = animelemtime(1) < 20
y = -1.6

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3164)
trigger1 = anim = 3122
x = 6.57

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3164)
trigger1 = anim = 3122
trigger1 = animelemtime(1) < 20
y = -3.6

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3163)
trigger1 = anim = 3122
x = 4.57

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(3163)
trigger1 = anim = 3122
trigger1 = animelemtime(1) < 20
y = -2.6

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 3122
x = 4.4

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 3122
trigger1 = animelemtime(1) < 20
y = -.28

[State 0, VelAdd]
type = VelAdd
trigger1 = pos y <= 0
trigger1 = anim = 3122
trigger1 = animelemtime(1) >= 20
y = .28

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = anim = 3122 && time > 20
trigger1 = pos y >= 0
value = 3121
persistent = 0

[State 0, PosSet]
type = PosSet
trigger1 = anim = 3121
y = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = S,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA       ;HLA
animtype = light         ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
pausetime = 5,10
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 92), var(36) := -35
ground.type = high     ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
ground.velocity = -4.5,-6.56
air.velocity = -4.5,-6.56
persistent = 0
ignorehitpause = 1
fall = 1
fall.recover = 0

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x > 20, ceil(P2Dist x), 20)), -35
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 3111
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -250

;----------------------------------------
;Robo Hawks Glide Attack
;----------------------------------------
[Statedef 3164]
type = S
movetype = A
physics = N
anim = 3123
sprpriority = 2
velset = 10.35,.75
ignorehitpause = 1
juggle = 15

[State 0, PosSet]
type = PosSet
trigger1 = ishelper(3166)
y = -98
persistent = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3166)
x = .023
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3166)
y = -.15
ignorehitpause = 1
;-------------------------
[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3167)
trigger1 = time > 10
x = -.025
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3167)
y = -.075
ignorehitpause = 1
;-------------------------
[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3168)
x = -.035
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3168)
y = -.095
ignorehitpause = 1
;-------------------------
[State 0, PosSet]
type = PosSet
trigger1 = ishelper(3169)
y = -142
persistent = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3169)
x = -.025
ignorehitpause = 1
;--------------------------
[State 0, PosSet]
type = PosSet
trigger1 = ishelper(3170)
y = -122
persistent = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3170)
y = -.085
ignorehitpause = 1
;--------------------------
[State 0, PosSet]
type = PosSet
trigger1 = ishelper(3171)
y = -132
persistent = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3171)
y = -.095
ignorehitpause = 1
;--------------------------
[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3172)
x = .023
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3172)
y = -.14
ignorehitpause = 1
;--------------------------
[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3173)
x = -.023
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3173)
trigger1 = time < 10
y = .031
ignorehitpause = 1
;--------------------------
[State 0, PosSet]
type = PosSet
trigger1 = ishelper(3174)
y = -98
persistent = 0
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3174)
x = .023
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3174)
y = -.15
ignorehitpause = 1
;-------------------------
[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3175)
trigger1 = time > 10
x = -.025
ignorehitpause = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = ishelper(3175)
y = -.075
ignorehitpause = 1

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 1005, Counter Flag]
type = VarSet
trigger1 = NumEnemy
trigger1 = MoveContact != 1
var(9) = (EnemyNear, MoveType = A)

[State 1005, Dampener]
type = VarSet
trigger1 = 1
fvar(11) = (Root, fvar(10)) * ifElse(var(9), 1.2, 1)

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = S,HA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = MAFD        ;HLAFD+-
guardflag = MA       ;HLA
animtype = light         ;light,medium,hard,back,up,diagup
air.animtype = light
fall.animtype = light
priority = 4,Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * 25 < 7, 7, fvar(11) * 25)), 7
pausetime = 5,10
getpower = 0,0
givepower = 10,5
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 15), var(36) := -35
ground.type = high     ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
ground.velocity = -4.5,-6.56
air.velocity = -4.5,-6.56
persistent = 0
ignorehitpause = 1
fall = 1
fall.recover = 0

[State 1006, HitSound]
type = PlaySnd
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
value = ifElse(MoveGuarded, 3, 2), ifElse(MoveGuarded, 0, 6)
channel = 3
ignorehitPause = 1

[State 1006, HitSpark]
type = Helper
trigger1 = MoveContact = 1 && NumTarget
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = ifElse(MoveGuarded, 8001, 8014)
ID = 8000
name = "Spark"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
facing = -1
ownPal = 1
size.xScale = 1
size.yScale = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, Counter FX]
type = Helper
trigger1 = MoveContact = 1 && NumTarget && var(9)
trigger1 = !(Target, HitShakeOver)
trigger1 = enemynear,time = 1
helperType = Normal
stateNo = 8290
ID = 8290
name = "Counter FX"
posType = P1
pos = ifElse(P2Dist x < 0, 0, ifElse(P2Dist x < 20, ceil(P2Dist x), 20)), 0
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 1006, HitCount]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(13) = 1

[State 1006, Juggle Points]
type = ParentVarAdd
trigger1 = !Time
trigger1 = MoveContact && NumTarget
var(15) = 1

[State 1006, ProjContact]
type = VarSet
trigger1 = MoveContact && NumTarget
var(18) = 1

[State 3206, ProjContact]
type = ParentVarSet
triggerAll = MoveContact && NumTarget
trigger1 = Root, StateNo = [3100,3150]
var(18) = 1

[State 0, HitOverride]
type = HitOverride
trigger1 = 1
attr = SCA,NA,SA,HA,NP,SP,HP
time = -1
stateno = 3112
ignorehitpause = 1

[State 0, HitBy]
type = HitBy
trigger1 = 1
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = enemynear,movecontact
value = SCA,NA,SA,HA,NP,SP,HP
time = -1
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = frontedgedist < -120
ignorehitpause = 1

;----------------------------------------------
;Robo Panther Get Hit
;----------------------------------------------
[Statedef 3111]
type = A
movetype = A
physics = N
anim = 1406
sprpriority = -1

[State 0, VelSet]
type = VelSet
trigger1 = 1
x = -7.36
y = -2.56

[State 0, VelAdd]
type = VelAdd
trigger1 = 1
x = -.73
y = -.32

[State 0, Trans]
type = Trans
trigger1 = 1
trans = addalpha
alpha = 256-(time*12),256

[State 0, DestroySelf]
type = DestroySelf
trigger1 = backedgedist < -250

;----------------------------------------------
;RoboHawk Get Hit
;----------------------------------------------
[Statedef 3112]
type = A
movetype = A
physics = N
anim = 1998
sprpriority = -1

[State 0, VelSet]
type = VelSet
trigger1 = 1
x = -1.36

[State 0, VelAdd]
type = VelAdd
trigger1 = 1
x = -.073
y = -.013

[State 0, AngleDraw]
type = AngleDraw
trigger1 = 1
scale = .5,.5
ignorehitpause = 1

[State 0, Trans]
type = Trans
trigger1 = 1
trans = add
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;========================<SPARKS>=============================
;Guard Spark (Normal)
[StateDef 8000]
type = A
physics = N
moveType = I
anim = 8000
velset = 0,0
sprPriority = 5

[State 8000, Assert: No Shadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8000, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.125 + (0.046875 * Time), 0.125 + (0.046875 * Time)
ignoreHitPause = 1

[State 8000, Transparency]
type = Trans
trigger1 = Time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8000, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8000, End]
type = DestroySelf
trigger1 = Time >= 8


;Guard Spark (Special)
[StateDef 8001]
type = A
physics = N
moveType = I
anim = 8001
velSet = 0,0
sprPriority = 5

[State 8001, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8001, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
ignoreHitPause = 1

[State 8001, Transparency]
type = Trans
trigger1 = time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8001, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8001, End]
type = DestroySelf
trigger1 = Time >= 8


;Weak Hit Spark
[StateDef 8010]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8010, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8010, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8010, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8010, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.3 - (Time * 0.03), 0.3 - (Time * 0.03)
ignoreHitPause = 1

[State 8010, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8010, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8010, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.15 + (0.009375 * Time), 0.15 + (0.009375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time),256

[State 8010, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.15 + (0.009375 * Time), 0.15 + (0.009375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8010, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8010, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.3 - (0.0375 * Time), 0.3 - (0.0375 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8010, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8010, End]
type = DestroySelf
trigger1 = Time >= 16


;Medium Hit Spark
[StateDef 8011]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8011, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8011, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8011, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8011, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.35 - (Time * 0.035), 0.35 - (Time * 0.035)
ignoreHitPause = 1

[State 8011, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8011, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8011, Center]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removetime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.175 + (0.0109375 * Time), 0.175 + (0.0109375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8011, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.175 + (0.0109375 * Time), 0.175 + (0.0109375 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8011, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8011, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.35 - (0.04375 * Time), 0.35 - (0.04375 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8011, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8011, End]
type = DestroySelf
trigger1 = Time >= 16


;Strong Hit Spark
[StateDef 8012]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8012, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8012, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8012, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8012, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.4 - (Time * 0.04), 0.4 - (Time * 0.04)
ignoreHitPause = 1

[State 8012, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8012, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8012, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8012, Streaks Explod]
type = Explod
trigger1 = !time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8012, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8012, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.4 - (0.05 * Time), 0.4 - (0.05 * Time)
trans = AddAlpha
alpha = 128 - (16 * Time), 256

[State 8012, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8012, End]
type = DestroySelf
trigger1 = Time >= 16


;Special Move Hit Spark
[StateDef 8013]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8013, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8013, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8013, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8013, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.45 - (Time * 0.045), 0.45 - (Time * 0.045)
ignoreHitPause = 1

[State 8012, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8013, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8013, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8013, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8013, P2 Back Explod]
type = Explod
trigger1 = !Time
anim = 8013
ID = 3
posType = P1
facing = -1
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = -3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale P2 Back Explod]
type = ModifyExplod
trigger1= NumExplod(3)
ID = 3
scale = 0.4, 0.4
trans = AddAlpha
alpha = 256 - (32 * Time), 256

[State 8013, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(random < 500, -1, 1)
vFacing = ifElse(random < 500, -1, 1)
sprPriority=3
removeTime=8
pauseMoveTime = -1
superMoveTime = -1

[State 8013, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.45 - (0.05625 * Time), 0.45 - (0.05625 * Time)
trans = AddAlpha
alpha = 192 - (24 * Time), 256

[State 8013, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8013, End]
type = DestroySelf
trigger1 = Time >= 16


;Super Hit Spark
[StateDef 8014]
type = A
physics = N
moveType = I
anim = 8010
velSet = 0,0
sprPriority = 5

[State 8014, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8014, AngleSet]
type = AngleSet
trigger1 = !Time
value = 30 * (Random % 12)

[State 8014, AngleAdd]
type = AngleAdd
trigger1 = 1
value = 30

[State 8014, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = 0.5 - (Time * 0.05), 0.5 - (Time * 0.05)
ignoreHitPause = 1

[State 8014, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8014, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8014, Center Explod]
type = Explod
trigger1 = !Time
anim = 8011
ID = 1
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Center Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8014, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8014, P2 Back Explod]
type = Explod
trigger1 = !Time
anim = 8013
ID = 3
posType = P1
facing = ifElse((Parent, StateNo = [3000,3999]), -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = -3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale P2 Back Explod]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 0.5,0.5
trans = AddAlpha
alpha = 256 - (32 * Time), 256

[State 8014, Impact Explod]
type = Explod
trigger1 = !Time
anim = 8014
ID = 4
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 3
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8014, Scale Impact Explod]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 0.5 - (0.0625 * Time), 0.5 - (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (32 * Time),256

[State 8014, Remove Explods]
type = RemoveExplod
trigger1 = time >= 16

[State 8014, End]
type = DestroySelf
trigger1 = Time >= 16

;Normal Slash Spark
[StateDef 8015]
type = A
physics = N
moveType = I
anim = 8015
velSet = 0,0
sprPriority = 5

[State 8015, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8015, AngleSet]
type = AngleSet
trigger1 = !Time
value = 15 * (Random % 24)

[State 8015, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = (0.5 + (Time * 0.15)) / 2, (1 - (Time * 0.1)) / 2
ignoreHitPause = 1

[State 8015, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8015, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8015, Streaks Explod]
type = Explod
trigger1 = !time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8015, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.2 + (0.0125 * Time), 0.2 + (0.0125 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8015, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8015, End]
type = DestroySelf
trigger1 = Time >= 16


;Special Move Slash Spark
[StateDef 8016]
type = A
physics = N
moveType = I
anim = 8015
velSet = 0,0
sprPriority = 5

[State 8016, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8016, AngleSet]
type = AngleSet
trigger1 = !Time
value = 15 * (Random % 24)

[State 8016, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = (0.5 + (Time * 0.15)) / 2, (1 - (Time * 0.1)) / 2
ignoreHitPause = 1

[State 8016, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8016, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8016, Circle]
type = Explod
trigger1 = !Time
anim = 8016
ID = 8016
posType = p1
removeTime = 10
sprPriority = 5
pauseMoveTime = -1
superMoveTime = -1

[State 8016, Circle Scale]
type = ModifyExplod
trigger1 = NumExplod(8016)
ID = 8016
scale = 0.25 + (0.025 * Time), 0.25 + (0.025 * Time)
trans = AddAlpha
alpha = ceil(256 - 25.6 * Time), 256

[State 8016, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8016, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.225 + (0.0140625 * Time), 0.225 + (0.0140625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8016, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8016, End]
type = DestroySelf
trigger1 = Time >= 16


;Super Move Slash Spark
[StateDef 8017]
type = A
physics = N
moveType = I
anim = 8015
velSet = 0,0
sprPriority = 5

[State 8017, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8017, AngleSet]
type = AngleSet
trigger1 = !Time
value = 15 * (Random % 24)

[State 8017, Scale]
type = AngleDraw
trigger1 = Time < 10
scale = (0.5 + (Time * 0.15)) / 2, (1 - (Time * 0.1)) / 2
ignoreHitPause = 1

[State 8017, Scale]
type = AngleDraw
trigger1 = Time >= 10
scale = 0,0
ignoreHitPause = 1

[State 8017, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8017, Circle]
type = Explod
trigger1 = !Time
anim = 8016
ID = 8016
posType = p1
removeTime = 10
sprPriority = 5
pauseMoveTime = -1
superMoveTime = -1

[State 8017, Circle Scale]
type = ModifyExplod
trigger1 = NumExplod(8016)
ID = 8016
scale = 0.3 + (0.03 * Time), 0.3 + (0.03 * Time)
trans = AddAlpha
alpha = ceil(256 - 25.6 * Time), 256

[State 8017, Streaks Explod]
type = Explod
trigger1 = !Time
anim = 8012
ID = 2
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
sprPriority = 5
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8017, Scale Streaks Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.25 + (0.015625 * Time), 0.25 + (0.015625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8017, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 16

[State 8017, End]
type = DestroySelf
trigger1 = Time >= 16

;Reversal Spark
[StateDef 8020]
type = A
physics = N
moveType = I
anim = 8020
velSet = 0,0
sprPriority = 5

[State 8020, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8020, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.09375 * Time), 0.25 + (0.09375 * Time)
ignoreHitPause = 1

[State 8020, Transparency]
type = Trans
trigger1 = Time < 4
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8020, Transparency]
type = Trans
trigger1 = Time >= 4
trans = AddAlpha
alpha = 256 - 64 * (Time - 4), 256
ignoreHitPause = 1

[State 8020, End]
type = DestroySelf
trigger1 = Time >= 8



;======================<JUMP DUST>===========================
[StateDef 8100]
type = S
anim = 1
velSet = 0,0

[State 8100, Bind]
type = BindToRoot
trigger1 = Time

[State 8100, Floor Dust]
type = Explod
trigger1 = !Time
anim = 8100
sprPriority = 3
posType = P1
pos = 0, ceil(pos y)
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8100, Player Dust]
type = Explod
trigger1 = !Time || Time = 2 || Time = 6
anim = 8101
sprPriority = 3
posType = P1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8100, End]
type = DestroySelf
trigger1 = Time >= 7



;======================<DASH DUST>===========================
[StateDef 8103]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8103, posSet]
type = PosSet
trigger1 = !Time = 0
y = 0

[State 8103, Dash Dust]
type = Explod
trigger1 = Time = 0 || Time = 3 || Time = 6
anim = 8103
ID = ifElse((Time = 6), 3, ifElse((Time = 3), 2, 1))
posType = P1
pos = 0,-4
random = 8,8
vel = -3 - (Random / 1000.0), -2 - (Random / 2000.0)
facing = ifElse(Random < 500,-1,1)
vFacing = ifElse(Random < 500,-1,1)
removeTime = 16
sprPriority = 3
pauseMoveTime = -1
superMoveTime = -1

[State 8103, Scale Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 0.1 + (0.025 * Time), 0.1 + (0.025 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8103, Scale Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 0.1 + (0.025 * (Time - 3)), 0.1 + (0.025 * (Time - 3))
trans = AddAlpha
alpha = 256 - (16 * (Time - 3)), 256

[State 8103, Scale Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 0.1 + (0.025 * (Time - 6)), 0.1 + (0.025 * (Time - 6))
trans = AddAlpha
alpha = 256 - (16 * (Time - 6)), 256

[State 8103, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 22

[State 8103, End]
type = DestroySelf
trigger1 = !NumExplod


;======================<IMPACT DUST>===========================
[StateDef 8110]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8110, Impact Dust Explod 1]
type = Explod
trigger1 = !Time
anim = 8110
ID = ifElse(Time = 8, 3, ifElse(Time = 4, 2, 1))
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8110, Impact Dust Explod 2]
type = Explod
trigger1 = !Time
anim = 8120
ID = 2
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8110, Scale]
type = ModifyExplod
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 256, 256 - (64 * (Time - 4))), 256

[State 8110, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 8

[State 8110, End]
type = DestroySelf
trigger1 = !NumExplod


;======================<WALL IMPACT DUST>===========================
[StateDef 8111]
type = A
anim = 1
velSet = 0,0
sprPriority = 5

[State 8111, Impact Dust Explod 1]
type = Explod
trigger1 = !Time
anim = 8111
ID = ifElse(Time = 8, 3, ifElse(Time = 4, 2, 1))
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8111, Impact Dust Explod 2]
type = Explod
trigger1 = !Time
anim = 8121
ID = 2
posType = P1
removeTime = 8
sprPriority = -4
pauseMoveTime = -1
superMoveTime = -1

[State 8111, Scale]
type = ModifyExplod
trigger1 = 1
scale = 0.25 + (0.03125 * Time), 0.25 + (0.03125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 256, 256 - (64 * (Time - 4))), 256

[State 8111, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 8

[State 8111, End]
type = DestroySelf
trigger1 = !NumExplod



;========================<RECOVER FX>=============================
[StateDef 8200]
type = A
velSet = 0,0
anim = 8200
sprPriority = 5

[State 8200, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8200, Scale]
type = AngleDraw
trigger1 = 1
scale = 0.25 + (0.017 * Time), 0.25 + (0.017 * Time)
ignoreHitPause = 1

[State 8200, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = ceil(256 - 17.1 * Time), 256
ignoreHitPause = 1

[State 8200, End]
type = DestroySelf
trigger1 = Time >= 15



;========================<COUNTER FX>=============================
[StateDef 8290]
type = A
physics = N
velSet = 0,0
anim = 1

[State 8290, "Counter!" Text Explod]
type = Explod
trigger1 = !NumExplod(8290)
anim = 8290
ID = 8290
sprPriority = 64
posType = P1
facing = Facing
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8290, Scale]
type = ModifyExplod
trigger1 = Time < 8
ID = 8290
scale = 0.5, .5
trans = AddAlpha
alpha = 256,0

[State 8290, Scale]
type = ModifyExplod
trigger1 = Time >= 8
ID = 8290
scale = 0.5 + 0.0625 * (Time - 8), 0.5 + 0.0625 * (Time - 8)
trans = AddAlpha
alpha = 256 - 32 * (Time - 8), 32 * (Time - 8)

[State 8290, Safety]
type = RemoveExplod
trigger1 = Time >= 16

[State 8290, End]
type = DestroySelf
trigger1 = Time >= 16



;==================<POWER CHARGE FX>==================
;Aura and Dust
[StateDef 8330]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velset = 0,0

[State 8330, BindToRoot]
type = BindToRoot
trigger1 = (Root, StateNo = 730)
pos = 0,0

[State 8330, Charging Sound]
type = PlaySnd
trigger1 = !Time
value = 730,0
channel = 0

[State 8330, Power Charge Aura]
type = Explod
trigger1 = !NumExplod(8330)
ID = 8330
anim = 8330
sprPriority = 3
posType = P1
bindTime = -1
removeTime = -1
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8330, Power Charge Dust]
type = Explod
trigger1 = !(Time % 6)
anim = 8105
sprPriority = -3
posType = P1
pos = 0, -ceil(pos y)
scale = 0.5,0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8330, Modify Aura 1]
type = ModifyExplod
trigger1 = Numexplod(8330) && Root, Power < 3000
ID = 8330
scale = 0.5, 0.1 + 0.4 * (Root, Power / 3000.0)

[State 8330, Modify Aura 2]
type = ModifyExplod
trigger1 = NumExplod(8330) && Root, Power >= 3000
ID = 8330
scale = 0.5, 0.5

[State 8330, StopSnd]
type = StopSnd
trigger1 = Root, StateNo != 730
channel = 0

[State 8330, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 730

[State 8330, End]
type = DestroySelf
trigger1 = Root, StateNo != 730


;Particles
[StateDef 8331]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8331, BindToRoot]
type = BindToRoot
trigger1 = !(Time % 8)
pos = ceil(-151 + (Random / 3.125)), ceil(98 - (Random / 3.125))

[State 8331, Particle]
type = Explod
trigger1 = (Time % 8) = 1
anim = 8331
sprPriority = ifElse(Random < 750, 5, -1)
posType = P1
vel = ((RootDist x + 5) / 32.0), ((RootDist y - 60) / 32.0)
scale = ifElse(Random < 500, 0.5, -0.5), ifElse(Random < 500, 0.5, -0.5)
pauseMoveTime = -1
superMoveTime = -1
ownpal = 1

[State 8331, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 730

[State 8331, End]
type = DestroySelf
trigger1 = Root, StateNo != 730


;==================<VIOLENT WIN VS VEGA PARTICLES>==================
[StateDef 8332]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8332, BindToRoot]
type = BindToRoot
trigger1 = !(Time % 4)
pos = ceil(-40 + (Random /10.25)), ceil(-17 - (Random / 10.25))

[State 8332, Particles]
type = Explod
trigger1 = (Time % 4) = 1
anim = 8332
sprPriority = ifElse(Random < 750,5,-1)
posType = P1
vel = (-(RootDist x + 4) / 10.0),(-(RootDist y - 85) / 10.0)
scale = ifElse(random < 500 ,0.5, -0.5),ifElse(random < 500, 0.5, -0.5)
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 8332, RemoveExplod]
type = RemoveExplod
trigger1 = Root, StateNo != 187 || Root, AnimElemTime(60) >= 0

[State 833, End]
type = DestroySelf
trigger1 = Root, StateNo != 187 || Root, AnimElemTime(60) >= 0



;==================<ZERO COUNTER FX>==================
[StateDef 8350]
type = A
physics = N
moveType = I
anim = 1
ctrl = 0
velSet = 0,0

[State 8350, bgPalFX]
type = bgPalFX
trigger1 = 1
time = 1
color = 16 * Time
mul = 16 * Time, 16 * Time, 16 * Time

[State 8350, Circle Explod]
type = Explod
trigger1 = !Time
anim = 8350
ID = 1
sprPriority = 3
posType = P1
removeTime = 16
superMoveTime = -1
ownPal = 1

[State 8350, Scale]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = (0.0625 * Time), (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8350, Lightning Explod]
type = Explod
trigger1 = !Time
anim = 8351
ID = 2
sprPriority = -2
posType = P1
pos = 0, -ceil(pos y)
superMoveTime = -1
ownPal = 1

[State 8350, End]
type = DestroySelf
trigger1 = Time >= 16



;========================<CUSTOM COMBO>=============================
[StateDef 8400]
type = A
physics = N
moveType = I
anim = 8400
ctrl = 0
velSet = 0,0
sprPriority = 5

[State 8400, NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8400, BGpalFX]
type = BGpalFX
trigger1 = Time < 25
time = 1
mul = 128,128,128

[State 8400, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8400, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8400, Scale]
type = AngleDraw
trigger1 = Time < 8
scale = (0.0625 * Time), (0.0625 * Time)
ignoreHitPause = 1

[State 8400, Scale]
type = AngleDraw
trigger1 = Time >= 8
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8400, Transparency]
type = Trans
trigger1 = Time < 16
trans = AddAlpha
alpha = 256, 256
ignoreHitPause = 1

[State 8400, Transparency]
type = Trans
trigger1 = Time >= 16
trans = AddAlpha
alpha = ceil(256 - 25.6 * (Time - 16)), 256
ignoreHitPause = 1

[State 8400, Lines Explod]
type = Explod
trigger1 = !Time
anim = 8401
ID = 1
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8400, Scale Lines Explod]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 2 - (0.125 * Time), 2 - (0.125 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8400, Circle Explod]
type = Explod
trigger1 = Time = 16
anim = 8402
ID = 2
sprPriority = 5
posType = P1
removeTime = 32
superMoveTime = -1

[State 8400, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = (0.1 * (Time - 16)), (0.1 * (Time - 16))
trans = AddAlpha
alpha = ceil(256 - 25.6 * (Time - 16)), 256

[State 8400, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 26

[State 8400, End]
type = DestroySelf
trigger1 = Time >= 26



;========================<SUPER PAUSE FX>=============================
;Level 1 Super FX
[StateDef 8500]
type = A
velSet = 0,0
anim = 8500
sprPriority = 5

[State 8500, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8500, BGpalFX]
type = BGpalFX
trigger1 = Time < 39
time = 1
color = 0
mul = 0,0,256

[State 8500, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8500, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8500, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8500, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5,0.5
ignoreHitPause = 1

[State 8500, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8500, Lines Explod]
type = Explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8501
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8500, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8500, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1 - (0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8500, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8500, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 - (0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8500, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8502
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 32
superMoveTime = -1

[State 8500, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8500, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8500, End]
type = DestroySelf
trigger1 = Time >= 40


;Level 2 Super FX
[StateDef 8510]
type = A
velSet = 0,0
anim = 8510
sprPriority = 5

[State 8510, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8510, BGpalFX]
type = BGpalFX
trigger1 = Time < 39
time = 1
color = 0
mul = 192,0,256

[State 8510, Rotate]
type = AngleSet
trigger1 = !Time
value =6 * (Random % 60)

[State 8510, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8510, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8510, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8510, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8510, Lines Explod]
type = Explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8511
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8510, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8510, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1 - (0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8510, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8510, Scale Lines Explod 4]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 -(0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8510, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8512
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500,-1,1)
vFacing = ifElse(Random < 500,-1,1)
removeTime = 32
superMoveTime = -1

[State 8510, Scale]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24)<4, 64 * (Time - 24), 256), 256

[State 8510, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8510, End]
type = DestroySelf
trigger1 = Time >= 40


;Level 3 Super FX
[StateDef 8520]
type = A
velset = 0,0
anim = 8520
sprPriority = 5

[State 8520, Assert: NoShadow]
type = AssertSpecial
trigger1 = 1
flag = NoShadow
ignoreHitPause = 1

[State 8520, Assert: NoBarDisplay, NoBG, NoFG]
type = AssertSpecial
trigger1 = Time < 40
flag = NoBarDisplay
flag2 = NoBG
flag3 = NoFG

[State 8520, Rotate]
type = AngleSet
trigger1 = !Time
value = 6 * (Random % 60)

[State 8520, Rotate]
type = AngleAdd
trigger1 = 1
value = -6

[State 8520, Scale]
type = AngleDraw
trigger1 = Time < 16
scale = (0.03125 * Time), (0.03125 * Time)
ignoreHitPause = 1

[State 8520, Scale]
type = AngleDraw
trigger1 = Time >= 16
scale = 0.5, 0.5
ignoreHitPause = 1

[State 8520, Transparency]
type = Trans
trigger1 = 1
trans = AddAlpha
alpha = 256,256
ignoreHitPause = 1

[State 8520, Portrait 1]
type = Explod
trigger1 = !Time
anim = 8525
ID = 20
sprPriority = -16
posType = Back
removeTime = 40
superMoveTime = -1

[State 8520, Portrait 2]
type = Explod
trigger1 = !Time
anim = 8525
ID = 21
sprPriority = -16
posType = Back
removeTime = 40
superMoveTime = -1

[State 8520, Scale Portrait 1a]
type = ModifyExplod
trigger1 = NumExplod(20) && Time < 16
ID = 20
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 1 - (0.03125 * Time), 1 - (0.03125 * Time)
trans = AddAlpha
alpha = (8 * Time), 256

[State 8520, Scale Portrait 2a]
type = ModifyExplod
trigger1 = NumExplod(21) && Time < 16
ID = 21
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 2 - (0.09375 * Time), 2 - (0.09375 * Time)
trans = AddAlpha
alpha = (8 * Time), 256

[State 8520, Scale Portrait 1b]
type = ModifyExplod
trigger1 = NumExplod(20) && (Time = [16,32])
ID = 20
posType = Back
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 256, 256

[State 8520, Scale Portrait 2b]
type = ModifyExplod
trigger1 = NumExplod(21) && (Time = [16,32])
ID = 21
scale = 0,0

[State 8520, Scale Portrait 1c]
type = ModifyExplod
trigger1 = NumExplod(20) && Time >= 32
ID = 20
posType = Back
pos = 160 + (8 * (Time - 32)), floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 128 - 16 * (Time - 32), 256

[State 8520, Scale Portrait 2c]
type = ModifyExplod
trigger1 = NumExplod(21) && Time >= 32
ID = 21
posType = Back
pos = 160 - (8 * (Time - 32)), floor((1.3333333 * GameHeight / GameWidth) * 121)
scale = 0.5, 0.5
trans = AddAlpha
alpha = 128 - 16 * (Time - 32), 256

[State 8520, Lines Explod]
type = explod
trigger1 = Time = 0 || Time = 8 || Time = 16 || Time = 24
anim = 8521
ID = ifElse(Time = 24, 4, ifElse(Time = 16, 3, ifElse(Time = 8, 2, 1)))
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1, 1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 16
superMoveTime = -1

[State 8520, Scale Lines Explod 1]
type = ModifyExplod
trigger1 = NumExplod(1)
ID = 1
scale = 1 - (0.0625 * Time), 1 - (0.0625 * Time)
trans = AddAlpha
alpha = ifElse(Time < 4, 64 * Time, 256), 256

[State 8520, Scale Lines Explod 2]
type = ModifyExplod
trigger1 = NumExplod(2)
ID = 2
scale = 1-(0.0625 * (Time - 8)), 1 - (0.0625 * (Time - 8))
trans = AddAlpha
alpha = ifElse((Time - 8) < 4, 64 * (Time - 8), 256), 256

[State 8520, Scale Lines Explod 3]
type = ModifyExplod
trigger1 = NumExplod(3)
ID = 3
scale = 1 - (0.0625 * (Time - 16)), 1 - (0.0625 * (Time - 16))
trans = AddAlpha
alpha = ifElse((Time - 16) < 4, 64 * (Time - 16), 256), 256

[State 8520, Scale Lines Explod 4]
type = ModifyExplod
trigger1 = NumExplod(4)
ID = 4
scale = 1 - (0.0625 * (Time - 24)), 1 - (0.0625 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8520, Circle Explod]
type = Explod
trigger1 = Time = 24
anim = 8522
ID = 10
sprPriority = 5
posType = P1
facing = ifElse(Random < 500, -1 ,1)
vFacing = ifElse(Random < 500, -1, 1)
removeTime = 32
superMoveTime = -1

[State 8520, Scale Circle Explod]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
scale = 2 - (0.125 * (Time - 24)), 2 - (0.125 * (Time - 24))
trans = AddAlpha
alpha = ifElse((Time - 24) < 4, 64 * (Time - 24), 256), 256

[State 8520, Remove Explods]
type = RemoveExplod
trigger1 = Time >= 40

[State 8520, End]
type = DestroySelf
trigger1 = Time >= 40



;========================<SUPER FINISH>=============================
[StateDef 8600]
type = A
velSet = 0,0
anim = 1

[State 8600, Super Finish Sound]
type = PlaySnd
trigger1 = !Time
value = 8600,0
channel = 0

[State 8600, SndPan]
type = SndPan
trigger1 = Time <= 80
channel = 1
absPan = ceil(sin(GameTime / 20.0 * pi) * 160)

[State 8600, BG PalFX]
type = BGpalFX
trigger1 = Time < 16
time = 1
mul = 0, 0, 0

[State 8600, BG PalFX]
type = BGpalFX
trigger1 = Time = [16,24)
time = 1
mul = 32 * (Time - 16), 32 * (Time - 16), 32 * (Time - 16)

[State 8600, Move Name: Custom Combo]
type = VarSet
trigger1= !Time && Root, var(23) = 900
var(0) = 1

[State 8600, Move Name: Somersault Strike]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3000,3099])
var(0) = 2

[State 8600, Move Name: Total Wipeout]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3100,3199])
var(0) = 3

[State 8600, Move Name: Sonic Hurricane]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3200,3299])
var(0) = 4

[State 8600, Move Name: Opening Gambit]
type = VarSet
trigger1 = !Time && (Root, var(23) = [3300,3399])
var(0) = 5

[State 8600, Super Finish Explod]
type = Explod
trigger1 = !Time
anim = 8600
ID = 8600
ontop = 1
postype = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Super Finish Explod Fade]
type = ModifyExplod
trigger1 = NumExplod(8600)
ID = 8600
trans = AddAlpha
alpha = ifElse(Time < 16, 256, 256 - 32 * (Time - 16)), 256

[State 8600, Text 1]
type = Explod
trigger1 = !Time && var(0)
anim = 8610 + var(0)
ID = 10
onTop = 1
posType = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 32
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Text 2]
type = Explod
trigger1 = !Time && var(0)
anim = 8610 + var(0)
ID = 11
onTop = 1
posType = left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
scale = 0.5, 0.5 * (1.3333333 * GameHeight / GameWidth)
bindTime = -1
removeTime = 8
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Text 1 Fade]
type = ModifyExplod
trigger1 = NumExplod(10)
ID = 10
trans = AddAlpha
alpha = ifElse(Time < 16, 256, 256 - 32 * (Time - 16)), ifElse(Time < 16, 0, 32 * (Time - 16))

[State 8600, Text 2 Fade]
type = ModifyExplod
trigger1 = NumExplod(11)
ID = 11
scale = 0.5 + (0.0625 * Time), 0.5 + (0.0625 * Time)
trans = AddAlpha
alpha = 256 - (32 * Time), 32 * Time

[State 8600, Circle Explod]
type = Explod
trigger1 = !Time
anim = 8601
ID = 8601
under = 1
posType = Left
pos = 160, floor((1.3333333 * GameHeight / GameWidth) * 120)
bindTime = -1
removeTime = 16
pauseMoveTime = -1
superMoveTime = -1

[State 8600, Circle Fade]
type = ModifyExplod
trigger1 = NumExplod(8601)
ID = 8601
scale = (0.25 * Time) * (1.3333333 * GameHeight / GameWidth), (0.25 * Time) * (1.3333333 * GameHeight / GameWidth)
trans = AddAlpha
alpha = 256 - (16 * Time), 256

[State 8600, Assert: NoFG]
type = AssertSpecial
trigger1 = Time < 16
flag = NoFG

[State 8600, Assert: NoBarDisplay]
type = AssertSpecial
trigger1 = Time < 24
flag = NoBarDisplay

[State 8600, RemoveExplod]
type = RemoveExplod
trigger1 = Time >= 24
trigger2 = RoundState < 3

[State 8600, End]
type = DestroySelf
trigger1 = RoundState < 3



;========================<CAMERA CONTROL>=============================
[StateDef 8999]
type = S
velSet = 0,0
anim = 1

[State 8999, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
moveCamera = 1,1
ignoreHitPause = 1

[State 8999, End]
type = DestroySelf
trigger1 = RoundState = 2
