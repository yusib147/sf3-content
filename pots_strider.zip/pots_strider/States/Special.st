; _________________________________________
;| Strider Hiryu by varo_hades             |
; �����������������������������������������
;==============================================================================================
;========================================<SPECIAL MOVES>=======================================
;==============================================================================================

;=====================<Standing Grahm Attack>==========================
[StateDef 1000]
type = S
physics = S
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x"), 0, ifElse((command = "y"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1000, Effect]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 1005
ID = 1005
name = "Sword effect"
posType = P1
pos = 0,0
postype = p1
ownpal = 1
scale = 0.4,0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 1001
ctrl = 0

;=====================<Standing Grahm Attack continue>==========================
[StateDef 1001]
type = S
physics = S
moveType = A
anim = 1010
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1030, ifElse(var(10) = 1, 1020, 1010))

[State 1000, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1000,0
channel = 0

[State 1000, Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 187,0
channel = 1

[State 1000, Effect]
type = Helper
trigger1 = var(10) = 0
trigger1 = animelem = 1
helperType = Normal
stateNo = 1015
ID = 1015
name = "Sword effect"
posType = P1
pos = 0,0
postype = p1
ownpal = 1
scale = 0.5, 0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1000, Effect]
type = Helper
trigger1 = var(10) = 1
trigger1 = animelem = 1
helperType = Normal
stateNo = 1016
ID = 1016
name = "Sword effect"
posType = P1
pos = 0,0
postype = p1
ownpal = 1
scale = 0.6, 0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1000, Effect]
type = Helper
trigger1 = var(10) = 2
trigger1 = animelem = 1
helperType = Normal
stateNo = 1017
ID = 1017
name = "Sword effect"
posType = P1
pos = 0,0
postype = p1
ownpal = 1
scale = 0.7, 0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S,SA
hitflag = MAF
guardflag = MA
animtype = hard
air.animtype = hard
priority = 6,Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10), 119, 105)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10), 119, 105)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 10), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 10), ifElse(var(20), 6, 12)
fall.animType = Back
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
ground.cornerpush.veloff = (ifelse(numhelper(4011), 0, -22.5))
air.hittime = 20
ground.velocity = -7.5,-3.56
guard.velocity = -9.5
guard.cornerPush.velOff = 0
air.velocity = -6.9,-3.56
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<Ex Standing Grahm Attack>=============================
[StateDef 1030]
type = S
physics = N
moveType = A
anim = 1000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 60

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, Effect]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 1005
ID = 1005
name = "Sword effect"
posType = P1
pos = 0,0
postype = p1
ownpal = 1
scale = 0.4,0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1030, End]
type = ChangeState
trigger1 = !AnimTime
value = 1031
ctrl = 0

;=====================<Ex Standing Grahm Attack continue>==========================
[StateDef 1031]
type = S
physics = S
moveType = A
anim = 1040
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 1000, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1000,0
channel = 0

[State 1000, Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 187,0
channel = 1

[State 1000, Effect]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 1018
ID = 1018
name = "Sword effect"
posType = P1
pos = 0,0
postype = p1
ownpal = 1
scale = 0.7, 0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
trigger2 = AnimElem = 4
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = 68, 7
getPower = 0, 0
givePower = 36, 36
pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
guard.pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -7.5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3.5,-1.4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<Crouching Grahm Attack>==========================
[StateDef 1100]
type = S
physics = S
moveType = A
anim = 1001
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a"), 0, ifElse((command = "b"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1000, Effect]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 1005
ID = 1005
name = "Sword effect"
posType = P1
pos = 0,20
postype = p1
ownpal = 1
scale = 0.4,0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1000, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 1101
ctrl = 0

;=====================<Crouching Grahm Attack continue>==========================
[StateDef 1101]
type = S
physics = S
moveType = A
anim = 1011
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1031, ifElse(var(10) = 1, 1021, 1011))

[State 1000, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1000,0
channel = 0

[State 1000, Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 187,0
channel = 1

[State 1000, Effect]
type = Helper
trigger1 = var(10) = 0
trigger1 = animelem = 1
helperType = Normal
stateNo = 1015
ID = 1015
name = "Sword effect"
posType = P1
pos = 0,20
postype = p1
ownpal = 1
scale = 0.5, 0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1000, Effect]
type = Helper
trigger1 = var(10) = 1
trigger1 = animelem = 1
helperType = Normal
stateNo = 1016
ID = 1016
name = "Sword effect"
posType = P1
pos = 0,20
postype = p1
ownpal = 1
scale = 0.6, 0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1000, Effect]
type = Helper
trigger1 = var(10) = 2
trigger1 = animelem = 1
helperType = Normal
stateNo = 1017
ID = 1017
name = "Sword effect"
posType = P1
pos = 0,20
postype = p1
ownpal = 1
scale = 0.7, 0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
attr = S,SA
hitflag = MAF
guardflag = MA
animtype = hard
air.animtype = hard
priority = 6,Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10), 119, 105)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10), 119, 105)))), 7
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 10), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 5, 10), ifElse(var(20), 6, 12)
fall.animType = Back
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
ground.cornerpush.veloff = (ifelse(numhelper(4011), 0, -22.5))
air.hittime = 20
ground.velocity = -7.5,-3.56
guard.velocity = -9.5
guard.cornerPush.velOff = 0
air.velocity = -6.9,-3.56
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -45
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<Ex Crouching Grahm Attack>=============================
[StateDef 1130]
type = S
physics = N
moveType = A
anim = 1001
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 60

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-50 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, Effect]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 1005
ID = 1005
name = "Sword effect"
posType = P1
pos = 0,20
postype = p1
ownpal = 1
scale = 0.4,0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1030, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 1030, End]
type = ChangeState
trigger1 = !AnimTime
value = 1131
ctrl = 0

;=====================<Ex Crouching Grahm Attack continue>==========================
[StateDef 1131]
type = S
physics = S
moveType = A
anim = 1041
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 1000, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1000,0
channel = 0

[State 1000, Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 3
value = 187,0
channel = 1

[State 1000, Effect]
type = Helper
trigger1 = animelem = 1
helperType = Normal
stateNo = 1018
ID = 1018
name = "Sword effect"
posType = P1
pos = 0,20
postype = p1
ownpal = 1
scale = 0.7, 0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = AnimElem = 3
trigger2 = AnimElem = 4
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = 68, 7
getPower = 0, 0
givePower = 36, 36
pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
guard.pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -7.5, 0
ground.cornerPush.velOff = 0
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -3.5,-1.4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 1000, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<Formation>==========================
[StateDef 1200]
type = S
physics = S
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1200, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a"), 0, ifElse((command = "b"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 0, PlaySnd]
type = PlaySnd
trigger1 = !animtime
value = S1100,0
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = !animtime
value = S191,0
volume = 255
channel = -1

[State 0, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 1201
ctrl = 0

;=====================<Formation continue>==========================
[StateDef 1201]
type = S
physics = S
moveType = A
anim = 1101
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Formation Clone 1"
stateno = 1203
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Formation Clone 2"
stateno = 1205
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Formation Clone 3"
stateno = 1207
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,1

[State 0, VelSet]
type = VelSet
trigger1 = time < 20
x = -3.9
y = -7.5

[State 0, VelAdd]
type = VelAdd
trigger1 = time < 20
y = -2.93

[State 0, VelSet]
type = VelSet
trigger1 = time >= 20
x = 0
y = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = time > 20
value = 1202
ctrl = 0

;=====================<Formation continue 2>==========================
[StateDef 1202]
type = S
physics = S
moveType = A
anim = 1102
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, Helper]
type = Helper
trigger1 = animelem = 5
helpertype = normal
name = "Random FX"
ID = 9203
stateno = 9203
pos = -40,-7
postype = p1
ownpal = 1
priority=10
size.xscale = .5
size.yscale = .5
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 15
value = S191,0
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 15
value = S1100,2
volume = 50
channel = -1
persistent = 0

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 0
trigger1 = var(44) = 1
trigger1 = time = 0
x = -145

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 1
trigger1 = var(44) = 1
trigger1 = time = 0
x = -35

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 2
trigger1 = var(44) = 1
trigger1 = time = 0
x = 75

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 0
trigger1 = var(44) = 2
trigger1 = time = 0
x = 145

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 1
trigger1 = var(44) = 2
trigger1 = time = 0
x = 35

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 2
trigger1 = var(44) = 2
trigger1 = time = 0
x = -75

[State 0, VelSet]
type = VelSet
trigger1 = time > 15
x = 3.9
y = 7.5

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 15
trigger1 = pos y < 0
x = 2.3
y = 9.93

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
attr = A,SA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = HLAD        ;HLAFD+-
guardflag = HLA         ;HLA
animtype = hard         ;light,medium,hard,back,up,diagup
air.animtype = hard
fall.animtype = Back       ;HLA
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givepower = 20,10
priority = (ifelse(var(13) = 2,5,(ifelse(var(13) = 3,6,4)))),Hit   ;Hit,Miss,Dodge
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 115, ifElse(var(10), 105, 95)))), 7
pausetime = ifElse(var(20), 5, 10), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -5
ground.type = High      ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
air.hittime = 20
air.cornerpush.veloff = (ifelse(numhelper(4011), 0, -10.5))
ground.velocity = -5.42,-6.2
guard.velocity = 5
air.velocity = -5.42,-6.2
fall = 1
fall.recover = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, VarSet]
type = VarSet
trigger1 = pos y >= 0
v = 10
value = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52
ctrl = 0

;----------------------------------
;Helper states for Formation Clones
;----------------------------------
[Statedef 1203];teleport out
type = A
movetype = I
physics = N
anim = 1103
ctrl = 0
sprpriority = 3

[State 0, VelSet]
type = VelSet
trigger1 = time < 20
x = -8.9
y = -2.1

[State 0, VelAdd]
type = VelAdd
trigger1 = time < 20
y = -2.93

[State 0, VelSet]
type = VelSet
trigger1 = time >= 20
x = 0
y = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = time > 20
value = 1204
ctrl = 0

;------------------------------------------
[Statedef 1204];teleport in for the Fake attack
type = A
movetype = A
physics = N
anim = 1104
ctrl = 0

[State 0, PosSet]
type = PosSet
triggerall = root,facing = 1
trigger1 = time = 0
x = (root,pos x) + -96
y = (root,pos y) + 52

[State 0, PosSet]
type = PosSet
triggerall = root,facing = -1
trigger1 = time = 0
x = (root,pos x) + 96
y = (root,pos y) + 52

[State 0, VelSet]
type = VelSet
trigger1 = time > 15
x = 8.9
y = -2.1

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 15
trigger1 = pos y < 0
y = 9.93

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;------------------------------
[Statedef 1205];teleport out
type = A
movetype = I
physics = N
anim = 1101
ctrl = 0

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, VelSet]
type = VelSet
trigger1 = time < 20
x = -3.9
y = -7.5

[State 0, VelAdd]
type = VelAdd
trigger1 = time < 20
x = 2.3
y = -2.93

[State 0, VelSet]
type = VelSet
trigger1 = time >= 20
x = 0
y = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = time > 20
value = 1206
ctrl = 0

;------------------------------------------
[Statedef 1206];teleport in for the Fake attack
type = A
movetype = A
physics = N
anim = 1105
ctrl = 0

[State 0, PosSet]
type = PosSet
triggerall = root,facing = 1
trigger1 = time = 0
x = (root,pos x) + 156

[State 0, PosSet]
type = PosSet
triggerall = root,facing = -1
trigger1 = time = 0
x = (root,pos x) + -156

[State 0, VelSet]
type = VelSet
trigger1 = time > 15
x = 3.9
y = 7.5

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 15
trigger1 = pos y < 0
y = 9.93

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;------------------------------
[Statedef 1207];teleport out
type = A
movetype = I
physics = N
anim = 1103
ctrl = 0
sprpriority = 3

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, VelSet]
type = VelSet
trigger1 = time < 20
x = -8.9
y = -2.1

[State 0, VelAdd]
type = VelAdd
trigger1 = time < 20
x = 2.3
y = -2.93

[State 0, VelSet]
type = VelSet
trigger1 = time >= 20
x = 0
y = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = time > 20
value = 1208
ctrl = 0

;------------------------------------------
[Statedef 1208];teleport in for the Fake attack
type = A
movetype = A
physics = N
anim = 1104
ctrl = 0

[State 0, PosSet]
type = PosSet
triggerall = root,facing = 1
trigger1 = time = 0
x = (root,pos x) + 256
y = (root,pos y) + 52

[State 0, PosSet]
type = PosSet
triggerall = root,facing = -1
trigger1 = time = 0
x = (root,pos x) + -256
y = (root,pos y) + 52

[State 0, VelSet]
type = VelSet
trigger1 = time > 15
x = 8.9
y = -2.1

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 15
trigger1 = pos y < 0
x = 2.3
y = 9.93

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;=====================<Ex Formation>==========================
[StateDef 1230]
type = S
physics = S
moveType = A
anim = 1100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 60

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = !animtime
value = S1100,0
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = !animtime
value = S191,0
volume = 255
channel = -1

[State 0, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 1231
ctrl = 0

;=====================<Ex Formation continue>==========================
[StateDef 1231]
type = S
physics = S
moveType = A
anim = 1101
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Formation Clone 1"
stateno = 1203
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Formation Clone 2"
stateno = 1205
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Formation Clone 3"
stateno = 1207
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0
movecamera = 1,1

[State 0, VelSet]
type = VelSet
trigger1 = time < 20
x = -3.9
y = -7.5

[State 0, VelAdd]
type = VelAdd
trigger1 = time < 20
y = -2.93

[State 0, VelSet]
type = VelSet
trigger1 = time >= 20
x = 0
y = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = time > 20
value = 1232
ctrl = 0

;=====================<Ex Formation continue 2>==========================
[StateDef 1232]
type = S
physics = S
moveType = A
anim = 1102
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, Helper]
type = Helper
trigger1 = animelem = 5
helpertype = normal
name = "Random FX"
ID = 9203
stateno = 9203
pos = -40,-7
postype = p1
ownpal = 1
priority=10
size.xscale = .5
size.yscale = .5
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 15
value = S191,0
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 15
value = S1100,2
volume = 50
channel = -1
persistent = 0

[State 0, PosSet]
type = PosAdd
TriggerAll = Anim = 1102
trigger1 = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
x = P2Dist X
persistent = 1

[State 0, VelSet]
type = VelSet
trigger1 = time > 15
x = 3.9
y = 7.5

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 15
trigger1 = pos y < 0
x = 2.3
y = 9.93

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
attr = A,SA        ;SCA,NA,SA,HA,NP,SP,HP,NT,ST,HT
hitflag = HLAD        ;HLAFD+-
guardflag = HLA         ;HLA
animtype = hard         ;light,medium,hard,back,up,diagup
air.animtype = hard
fall.animtype = Back       ;HLA
getpower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givepower = 20,10
priority = (ifelse(var(13) = 2,5,(ifelse(var(13) = 3,6,4)))),Hit   ;Hit,Miss,Dodge
damage = 125, 7
pausetime = ifElse(var(20), 5, 10), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -5
ground.type = High      ;Low,Trip,None
air.type = low
ground.hittime = 20
ground.cornerpush.veloff = -10.5
air.hittime = 20
air.cornerpush.veloff = (ifelse(numhelper(4011), 0, -10.5))
ground.velocity = -5.42,-6.2
guard.velocity = 5
air.velocity = -5.42,-6.2
fall = 1
fall.recover = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, VarSet]
type = VarSet
trigger1 = pos y >= 0
v = 10
value = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52
ctrl = 0

;=====================<Ame No Murakamo>==========================
[StateDef 1300]
type = S
physics = S
moveType = A
anim = 1300
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1300, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x"), 0, ifElse((command = "y"), 1, 2))

[State 1300, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1300, ChangeAnim]
type = ChangeAnim
trigger1 = !Time
value = ifElse(var(10) = 2, 1304, ifElse(var(10) = 1, 1302, 1300))

[State 0, VelSet]
type = VelSet
trigger1 = var(10) = 0
trigger1 = time > 12
x = 6
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = var(10) = 0
trigger1 = time >= 35
x = 0
y = 0

[State 0, VelMul]
type = VelMul
trigger1 = var(10) = 0
trigger1 = time > 25
x = .23

[State 0, VelSet]
type = VelSet
trigger1 = var(10) = 1
trigger1 = time > 12
x = 6.5
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = var(10) = 1
trigger1 = time >= 41
x = 0
y = 0

[State 0, VelMul]
type = VelMul
trigger1 = var(10) = 1
trigger1 = time > 31
x = .23

[State 0, VelSet]
type = VelSet
trigger1 = var(10) = 2
trigger1 = time > 12
x = 6.93
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = var(10) = 2
trigger1 = time >= 41
x = 0
y = 0

[State 0, VelMul]
type = VelMul
trigger1 = var(10) = 2
trigger1 = time = 31
x = .23

[State 0, Helper]
type = Helper
triggerall = anim = 1300
trigger1 = animelem = 1
trigger1 = var(10) = 0
sprPriority = 2
helpertype = normal
name = "SLASH 1"
ID = 1300
stateno = 2130
pos = 0,0
postype = p1
ownpal = 1
scale = 0.4,0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 0, Helper]
type = Helper
triggerall = anim = 1302
trigger1 = animelem = 1
trigger1 = var(10) = 1
sprPriority = 2
helpertype = normal
name = "SLASH 1"
ID = 1300
stateno = 2131
pos = 0,0
postype = p1
ownpal = 1
scale = 0.4,0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 0, Helper]
type = Helper
triggerall = anim = 1304
trigger1 = animelem = 1
trigger1 = var(10) = 2
sprPriority = 2
helpertype = normal
name = "SLASH 1"
ID = 1300
stateno = 2132
pos = 0,0
postype = p1
ownpal = 1
scale = 0.4,0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(10) = 0
trigger1 = animelem = 5
helpertype = normal
name = "After image 1"
stateno = 1303
id = 1300
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(10) = 0
trigger1 = animelem = 6
helpertype = normal
name = "After image 2"
stateno = 1303
id = 1301
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(10) = 0
trigger1 = animelem = 7
helpertype = normal
name = "After image 3"
stateno = 1303
id = 1302
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(10) = 1
trigger1 = animelem = 7
helpertype = normal
name = "After image 1"
stateno = 1303
id = 1300
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(10) = 1
trigger1 = animelem = 8
helpertype = normal
name = "After image 2"
stateno = 1303
id = 1301
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(10) = 1
trigger1 = animelem = 9
helpertype = normal
name = "After image 3"
stateno = 1303
id = 1302
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(10) = 2
trigger1 = animelem = 6
helpertype = normal
name = "After image 1"
stateno = 1303
id = 1300
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(10) = 2
trigger1 = animelem = 7
helpertype = normal
name = "After image 2"
stateno = 1303
id = 1301
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(10) = 2
trigger1 = animelem = 8
helpertype = normal
name = "After image 3"
stateno = 1303
id = 1302
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem = 8
trigger1 = var(10) = 0
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 102 < 7, 7, fvar(11) * 102)), 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 5, 10), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 5, 10), ifElse(var(20), 5, 10)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.5,-3.4
ground.cornerpush.veloff = (ifelse(numhelper(4011), 0, -5.5))
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5.5,-3.4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
ID = 1300

[State 1100, HitDef 2]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem = 10
trigger1 = var(10) = 1
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 112 < 7, 7, fvar(11) * 112)), 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
guard.pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.5,-3.4
ground.cornerpush.veloff = (ifelse(numhelper(4011), 0, -5.5))
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5.5,-3.4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
ID = 1300

[State 1100, HitDef 3]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem = 12
trigger1 = var(10) = 2
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 122 < 7, 7, fvar(11) * 122)), 0
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
guard.pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.5,-3.4
ground.cornerpush.veloff = (ifelse(numhelper(4011), 0, -5.5))
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5.5,-3.4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
ID = 1300

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 7
value = S1100,2
volume = 255
channel = -1

[State 1000, Startup Sound]
type = PlaySnd
trigger1 = var(10) = 0
trigger1 = AnimElem = 8
value = 187,0
channel = 1

[State 1000, Startup Sound]
type = PlaySnd
trigger1 = var(10) = 1
trigger1 = AnimElem = 10
value = 187,0
channel = 1

[State 1000, Startup Sound]
type = PlaySnd
trigger1 = var(10) = 2
trigger1 = AnimElem = 12
value = 187,0
channel = 1

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 0
ctrl = 1

;------------------------------------
;After image helper states for above
;------------------------------------
[Statedef 1303]
type = S
movetype = I
physics = S
ctrl = 0
velset = 0,0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1300
value = 1301
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1301
value = 1303
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1302
value = 1304
elem = 4
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
triggerall = ishelper(1300)
trigger1 = root,vel x != 0
time = 1
pos = -10,0
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
triggerall = ishelper(1301)
trigger1 = root,vel x != 0
time = 1
pos = -25,0
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
triggerall = ishelper(1302)
trigger1 = root,vel x != 0
time = 1
pos = -40,0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = (root,vel x = 0 || root,movecontact) && root,stateno = [1300,1302]
x = 10.5
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1300)
trigger1 = 1
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1301)
trigger1 = 1
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1302)
trigger1 = 1
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = rootdist x <= 0
trigger2 = root,movetype = H
trigger3 = root,stateno != [1300,1302]

;========================<Ex Standing Grahm Attack>=============================
[StateDef 1330]
type = S
physics = N
moveType = A
anim = 1305
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 66

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 0, VelSet]
type = VelSet
trigger1 = time > 12
x = 8.93
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = time >= 41
x = 0
y = 0

[State 0, VelMul]
type = VelMul
trigger1 = time = 31
x = .23

[State 0, Helper]
type = Helper
triggerall = anim = 1305
trigger1 = animelem = 1
sprPriority = 2
helpertype = normal
name = "SLASH 1"
ID = 1330
stateno = 2133
pos = 0,0
postype = p1
ownpal = 1
scale = 0.4,0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = animelem = 6
helpertype = normal
name = "After image 1"
stateno = 1333
id = 1330
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = animelem = 7
helpertype = normal
name = "After image 2"
stateno = 1333
id = 1331
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = animelem = 8
helpertype = normal
name = "After image 3"
stateno = 1333
id = 1332
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 1100, HitDef 1]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem = 12
trigger2 = animelem = 13
attr = A, SA
hitFlag = MAF
guardFlag = MA
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 66 < 7, 7, fvar(11) * 66)), 0
getPower = 0, 0
givePower = 36, 36
pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
guard.pauseTime = ifElse(var(20), 4.5, 9), ifElse(var(20), 4.5, 9)
animType = Back
air.animType = Back
fall.animType = Back
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.5,-3.4
ground.cornerpush.veloff = (ifelse(numhelper(4011), 0, -5.5))
guard.velocity = -12.64
guard.cornerPush.velOff = 0
air.velocity = -5.5,-3.4
air.cornerPush.velOff = 0
yAccel = 0.5
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
ID = 1330

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 7
value = S1100,2
volume = 255
channel = -1

[State 1000, Startup Sound]
type = PlaySnd
trigger1 = AnimElem = 12
value = 187,0
channel = 1

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 0
ctrl = 1

;------------------------------------
;After image helper states for above
;------------------------------------
[Statedef 1333]
type = S
movetype = I
physics = S
ctrl = 0
velset = 0,0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1330
value = 1301
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1331
value = 1303
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = root,stateno = 1332
value = 1304
elem = 4
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
triggerall = ishelper(1330)
trigger1 = root,vel x != 0
time = 1
pos = -10,0
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
triggerall = ishelper(1331)
trigger1 = root,vel x != 0
time = 1
pos = -25,0
ignorehitpause = 1

[State 0, BindToRoot]
type = BindToRoot
triggerall = ishelper(1332)
trigger1 = root,vel x != 0
time = 1
pos = -40,0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = (root,vel x = 0 || root,movecontact) && root,stateno = [1330,1332]
x = 10.5
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1330)
trigger1 = 1
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1331)
trigger1 = 1
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1332)
trigger1 = 1
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = rootdist x <= 0
trigger2 = root,movetype = H
trigger3 = root,stateno != [1330,1332]

;=====================<Robo Panther>==========================
[StateDef 1400]
type = S
physics = S
moveType = A
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1400, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a"), 0, ifElse((command = "b"), 1, 2))

[State 1400, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1400, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1400,0
channel = 0

[State 1400, Projectile]
type = Helper
trigger1 = AnimElem = 3
trigger1 = var(44) = 1
helperType = Normal
stateNo = 1405
ID = 1405
name = "Robo Panther"
posType = left
facing = 1
pos = -65,0
ownPal = 1

[State 1400, Projectile]
type = Helper
trigger1 = AnimElem = 3
trigger1 = var(44) = 2
helperType = Normal
stateNo = 1405
ID = 1405
name = "Robo Panther"
posType = Right
facing = -1
pos = 65,0
ownPal = 1

[State 1000, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<Ex Robo Panther>==========================
[StateDef 1430]
type = S
physics = S
moveType = A
anim = 1400
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1430, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1430, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1430, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1430, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 50

[State 1430, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1430, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1430, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1400,0
channel = 0

[State 1430, Projectile]
type = Helper
trigger1 = AnimElem = 3
trigger1 = var(44) = 1
helperType = Normal
stateNo = 1435
ID = 1405
name = "Robo Panther"
posType = left
facing = 1
pos = -65,0
ownPal = 1

[State 1430, Projectile]
type = Helper
trigger1 = AnimElem = 3
trigger1 = var(44) = 2
helperType = Normal
stateNo = 1435
ID = 1405
name = "Robo Panther"
posType = Right
facing = -1
pos = 65,0
ownPal = 1

[State 1430, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<Satellite>==========================
[StateDef 1500]
type = S
physics = S
moveType = A
anim = 1401
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1500, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x" || command = "rlsx"), 0, ifElse((command = "y" || command = "rlsy"), 1, 2))

[State 1500, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1500, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1100,0
channel = 0

[State 1500, Projectile]
type = Helper
trigger1 = AnimElem = 5
trigger1 = !numhelper(1505)
helperType = Normal
stateNo = 1505
ID = 1505
name = "Ouroboros"
posType = P1
pos = -33,-49
ownPal = 1

[State 1500, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<Satellite Attack>==========================
[StateDef 1501]
type = S
physics = S
moveType = A
anim = 1403
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1501, Voice]
type = PlaySnd
trigger1 = time = 0
value = 1500,0
channel = 0

[State 1501, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 11
ctrl = 1

;=====================<Ex Satellite>==========================
[StateDef 1530]
type = S
physics = S
moveType = A
anim = 1401
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 32

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1500, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 1100,0
channel = 0

[State 1500, Projectile]
type = Helper
trigger1 = AnimElem = 5
trigger1 = !numhelper(1535)
helperType = Normal
stateNo = 1535
ID = 1535
name = "Ouroboros"
posType = P1
pos = -33,-49
ownPal = 1

[State 1500, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<Ex Satellite Attack>==========================
[StateDef 1531]
type = S
physics = S
moveType = A
anim = 1403
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 51

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, Voice]
type = PlaySnd
trigger1 = time = 0
value = 1500,0
channel = 0

[State 1501, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 11
ctrl = 1

;=====================<Robo Hawk>==========================
[StateDef 1600]
type = S
physics = S
moveType = A
anim = 1402
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1600, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "c" || command = "rlsc"), 2, ifElse((command = "b" || command = "rlsb"), 1, 0))

[State 1600, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1600, Voice]
type = PlaySnd
trigger1 = time = 0
value = 1500,0
channel = 0

[State 1600, Projectile]
type = Helper
trigger1 = animelem = 5
trigger1 = var(44) = 1
helperType = Normal
stateNo = 1605
ID = 1605
name = "Robo Hawk"
posType = left
facing = 1
pos = -65,0
ownPal = 1

[State 1600, Projectile]
type = Helper
trigger1 = animelem = 5
trigger1 = var(44) = 2
helperType = Normal
stateNo = 1605
ID = 1605
name = "Robo Hawk"
posType = Right
facing = -1
pos = 65,0
ownPal = 1

[State 1600, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<Ex Robo Hawk>=============================
[StateDef 1630]
type = S
physics = N
moveType = A
anim = 1402
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 81

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 1030, Voice]
type = PlaySnd
trigger1 = time = 0
value = 1500,0
channel = 0

[State 1600, Projectile]
type = Helper
trigger1 = animelem = 10
trigger1 = var(44) = 1
helperType = Normal
stateNo = 1635
ID = 1605
name = "Robo Hawk"
posType = left
facing = 1
pos = -65,0
ownPal = 1

[State 1600, Projectile]
type = Helper
trigger1 = animelem = 10
trigger1 = var(44) = 2
helperType = Normal
stateNo = 1635
ID = 1605
name = "Robo Hawk"
posType = Right
facing = -1
pos = 65,0
ownPal = 1

[State 1600, Projectile]
type = Helper
trigger1 = animelem = 5
trigger1 = var(44) = 1
helperType = Normal
stateNo = 1645
ID = 1605
name = "Robo Hawk"
posType = left
facing = 1
pos = -65,0
ownPal = 1

[State 1600, Projectile]
type = Helper
trigger1 = animelem = 5
trigger1 = var(44) = 2
helperType = Normal
stateNo = 1645
ID = 1605
name = "Robo Hawk"
posType = Right
facing = -1
pos = 65,0
ownPal = 1

[State 1600, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;=====================<Excalibur>==========================
[StateDef 1700]
type = S
physics = S
moveType = A
anim = 1700
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a"), 0, ifElse((command = "b"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 0, Helper]
type = Helper
triggerall = anim != 1710
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = var(10) = 0
trigger1 = !animtime
value = 1701

[State 0, ChangeState]
type = ChangeState
trigger1 = var(10) = 1
trigger1 = !animtime
value = 1702

[State 0, ChangeState]
type = ChangeState
trigger1 = var(10) = 2
trigger1 = !animtime
value = 1703

;------<LK Attack>----------
[Statedef 1701]
type = A
movetype = A
physics = N
ctrl = 0
anim = 1701
velset = 3.45,15.7

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 2
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = anim != 1710
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Random FX"
ID = 2706
stateno = 2706
pos = 19,-51
postype = p1
ownpal = 1
size.xscale = .5
size.yscale = .5
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 1
value = S191,0
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S4,5
volume = 255
channel = -1

[State 0, VelSet]
type = VelSet
trigger1 = frontedgedist < 5
y = 0
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = frontedgedist < 5
value = 1710
persistent = 0

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1710
statetype = A       ;S,A,C,L
movetype = I        ;I,A,H
physics = A

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 1710
x = -.034

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 1
helpertype = normal
name = "After image 1"
stateno = 1704
id = 1710
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 3
helpertype = normal
name = "After image 2"
stateno = 1704
id = 1711
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 5
helpertype = normal
name = "After image 3"
stateno = 1704
id = 1712
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
attr = A,SA
hitflag = MAF
guardflag = HA
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = hard
air.animtype = hard
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 30 < 7, 7, fvar(11) * 30)), 0
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -5
ground.type = High
air.type = low
air.hittime = 20
ground.velocity = -4.5,-7.56
air.velocity = -4.5,-7.56
guard.velocity = -2.2
airguard.velocity = -1.2
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit = 1 && !moveguarded
trigger1 = enemynear,time = 1
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = moveguarded
value = 1716

;------<MK Attack>----------
[Statedef 1702]
type = A
movetype = A
physics = N
ctrl = 0
anim = 1702
velset = 9.7,8.7
poweradd = 80

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 2
ignorehitpause = 1

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = anim != 1710
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Random FX"
ID = 2706
stateno = 2706
pos = 19,-51
postype = p1
ownpal = 1
size.xscale = .5
size.yscale = .5
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 1
value = S191,0
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S4,5
volume = 255
channel = -1

[State 0, ScreenBound]
type = ScreenBound
trigger1 = anim = 1702
value = 1
movecamera = 0,1

[State 0, VelSet]
type = VelSet
trigger1 = frontedgedist <= 2 || time >= 24
y = 0
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = frontedgedist <= 2 || time >= 24
value = 1710
persistent = 0

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1710
statetype = A       ;S,A,C,L
movetype = I        ;I,A,H
physics = A

[State 0, VelSet]
type = VelSet
trigger1 = anim = 1710
trigger1 = animelem = 4 || animelem = 5
x = 0
persistent = 0

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 1710
x = .14

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 1
helpertype = normal
name = "After image 1"
stateno = 1705
id = 1710
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 3
helpertype = normal
name = "After image 2"
stateno = 1705
id = 1711
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 5
helpertype = normal
name = "After image 3"
stateno = 1705
id = 1712
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
attr = A,SA
hitflag = MAF
guardflag = MA
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = hard
air.animtype = hard
priority = 5,Hit
damage = ceil(ifElse(fvar(11) * 34 < 7, 7, fvar(11) * 34)), 0
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
air.hittime = 20
ground.velocity = -4.5,-8.56
air.velocity = -4.5,-8.56
guard.velocity = -4.2
airguard.velocity = -1.2
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = enemynear,anim != 5030
trigger1 = enemynear,movetype = H && enemynear,time = 0
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = moveguarded
value = 1716

;------<HK Attack>----------
[Statedef 1703]
type = A
movetype = A
physics = N
ctrl = 0
anim = 1703
velset = 9.7,4.7

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 2
ignorehitpause = 1

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = anim != 1710
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Random FX"
ID = 2706
stateno = 2706
pos = 19,-51
postype = p1
ownpal = 1
size.xscale = .5
size.yscale = .5
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 1
value = S191,0
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S4,5
volume = 255
channel = -1

[State 0, ScreenBound]
type = ScreenBound
trigger1 = anim = 1703
value = 1
movecamera = 0,1

[State 0, VelSet]
type = VelSet
trigger1 = frontedgedist <= 2 || time >= 24
y = 0
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = frontedgedist <= 2 || time >= 24
value = 1703
persistent = 0

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1710
statetype = A       ;S,A,C,L
movetype = I        ;I,A,H
physics = A

[State 0, VelSet]
type = VelSet
trigger1 = anim = 1710
trigger1 = animelem = 4 || animelem = 5
x = 0
persistent = 0

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 1710
x = .14

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 1
helpertype = normal
name = "After image 1"
stateno = 1706
id = 1710
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 3
helpertype = normal
name = "After image 2"
stateno = 1706
id = 1711
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 5
helpertype = normal
name = "After image 3"
stateno = 1706
id = 1712
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 3 || var(20))
attr = A,SA
hitflag = MAF
guardflag = MA
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = hard
air.animtype = hard
priority = 6,Hit
damage = ceil(ifElse(fvar(11) * 37 < 7, 7, fvar(11) * 37)), 0
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
air.hittime = 20
ground.velocity = -4.5,-8.56
air.velocity = -4.5,-8.56
guard.velocity = -4.2
airguard.velocity = -1.2
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = enemynear,anim != 5030
trigger1 = enemynear,movetype = H && enemynear,time = 0
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = moveguarded
value = 1716

;-----------<afterimages lk>-----------
[Statedef 1704]
type = A
movetype = I
physics = N

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1701

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1710)
trigger1 = time = 0
time = 1
pos = -15,-25
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1711)
trigger1 = time = 0
time = 1
pos = -22,-45
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1712)
trigger1 = time = 0
time = 1
pos = -31,-65
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = root,vel x
y = root,vel y

[State 0, VelSet]
type = PosFreeze
trigger1 = root,HitPauseTime
value = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1710)
trigger1 = time > 0
x = -.04
y = -.08
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1711)
trigger1 = time > 0
x = -.09
y = -.19
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1712)
trigger1 = time > 0
x = -.18
y = -.36
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1710)
trigger1 = 1
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1711)
trigger1 = 1
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1712)
trigger1 = 1
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,anim = 1710
value = 1707

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,pos y >= 0
value = 1708

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H || root,moveguarded || root,stateno != 1701
ignorehitpause = 1

;-----------<afterimages mk>-----------
[Statedef 1705]
type = A
movetype = I
physics = N

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1702

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1710)
trigger1 = time = 0
time = 1
pos = -15,-5
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1711)
trigger1 = time = 0
time = 1
pos = -22,-8
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1712)
trigger1 = time = 0
time = 1
pos = -31,-11
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = root,vel x
y = root,vel y

[State 0, VelSet]
type = PosFreeze
trigger1 = root,HitPauseTime
value = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1710)
trigger1 = time > 0
x = -.08
y = -.05
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1711)
trigger1 = time > 0
x = -.29
y = -.15
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1712)
trigger1 = time > 0
x = -.49
y = -.25
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1710)
trigger1 = 1
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1711)
trigger1 = 1
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1712)
trigger1 = 1
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,anim = 1710
value = 1707

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,pos y >= 0
value = 1708

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H || root,moveguarded || root,stateno != 1702
ignorehitpause = 1

;-----------<afterimages hk>-----------
[Statedef 1706]
type = A
movetype = I
physics = N

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1703

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1710)
trigger1 = time = 0
time = 1
pos = -15,-5
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1711)
trigger1 = time = 0
time = 1
pos = -22,-8
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1712)
trigger1 = time = 0
time = 1
pos = -31,-11
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = root,vel x
y = root,vel y

[State 0, VelSet]
type = PosFreeze
trigger1 = root,HitPauseTime
value = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1710)
trigger1 = time > 0
x = -.14
y = -.012
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1711)
trigger1 = time > 0
x = -.35
y = -.024
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1712)
trigger1 = time > 0
x = -.59
y = -.028
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1710)
trigger1 = anim != 1710
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1711)
trigger1 = anim != 1710
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1712)
trigger1 = anim != 1710
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,anim = 1710
value = 1707

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,pos y >= 0
value = 1708

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H || root,moveguarded || root,stateno != 1703
ignorehitpause = 1

;-----------<afterimages end>-----------
[Statedef 1707]
type = U
movetype = U
physics = U
anim = 1710

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, Trans]
type = Trans
trigger1 = 1
trans = addalpha
alpha = 256-(time*12),256

[State 0, VelAdd]
type = VelAdd
trigger1 = root,frontedgedist <= 25
trigger1 = 1
x = -1.75
persistent = 0

[State 0, DestroySelf]
type = DestroySelf
trigger1 = statetime > 50

;-----------<afterimages end>-----------
[Statedef 1708]
type = U
movetype = U
physics = U

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(1710)
x = vel x*2

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(1710)
y = vel y*2
;--------------------

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(1711)
x = vel x*4

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(1711)
y = vel y*4
;--------------------

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(1712)
x = vel x*6

[State 0, VelSet]
type = VelSet
trigger1 = ishelper(1712)
y = vel y*6
;--------------------

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,stateno = 52

;----------------------------------
;Ragnarok Blocked
;----------------------------------
[Statedef 1716]
type = A
movetype = I
physics = N
ctrl = 0
anim = 1710
velset = 0,0
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
trigger1 = enemynear,statetype != A
trigger1 = time = [1,5]
x = -3
y = -2.5

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = time > 5
statetype = A       ;S,A,C,L
movetype = I        ;I,A,H
physics = A         ;A,C,S,N

;=====================<EX Excalibur>==========================
[StateDef 1730]
type = S
physics = S
moveType = A
anim = 1700
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -500
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a" && command = "b"), 0, ifElse((command = "a" && command = "c"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 16

[State 1030, EX FX]
type = Explod
trigger1 = !Time
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
value = 0,1000
channel = 1

[State 0, Helper]
type = Helper
triggerall = anim != 1710
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = var(10) = 0
trigger1 = !animtime
value = 1731

[State 0, ChangeState]
type = ChangeState
trigger1 = var(10) = 1
trigger1 = !animtime
value = 1732

[State 0, ChangeState]
type = ChangeState
trigger1 = var(10) = 2
trigger1 = !animtime
value = 1733

;------<EX LK Attack>----------
[Statedef 1731]
type = A
movetype = A
physics = N
ctrl = 0
anim = 1701
velset = 3.45,15.7

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 16

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 2
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = anim != 1710
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Random FX"
ID = 2706
stateno = 2706
pos = 19,-51
postype = p1
ownpal = 1
size.xscale = .5
size.yscale = .5
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 1
value = S0,10
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S5,4
volume = 255
channel = -1

[State 0, VelSet]
type = VelSet
trigger1 = frontedgedist < 5
y = 0
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = frontedgedist < 5
value = 1710
persistent = 0

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1710
statetype = A       ;S,A,C,L
movetype = I        ;I,A,H
physics = A

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 1710
x = -.034

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 1
helpertype = normal
name = "After image 1"
stateno = 1734
id = 1710
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 3
helpertype = normal
name = "After image 2"
stateno = 1734
id = 1711
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 5
helpertype = normal
name = "After image 3"
stateno = 1734
id = 1712
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
attr = A,SA
hitflag = MAF
guardflag = HA
getPower = 0, 0
givePower = 36, 36
animtype = hard
air.animtype = hard
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 0
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -5
ground.type = High
air.type = low
air.hittime = 20
ground.velocity = -4.5,-7.56
air.velocity = -4.5,-7.56
guard.velocity = -2.2
airguard.velocity = -1.2
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit = 1 && !moveguarded
trigger1 = enemynear,time = 1
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = moveguarded
value = 1716

;------<MK Attack>----------
[Statedef 1732]
type = A
movetype = A
physics = N
ctrl = 0
anim = 1702
velset = 9.7,8.7
poweradd = 0

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 16

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 2
ignorehitpause = 1

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = anim != 1710
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Random FX"
ID = 2706
stateno = 2706
pos = 19,-51
postype = p1
ownpal = 1
size.xscale = .5
size.yscale = .5
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 1
value = S0,10
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S5,4
volume = 255
channel = -1

[State 0, ScreenBound]
type = ScreenBound
trigger1 = anim = 1702
value = 1
movecamera = 0,1

[State 0, VelSet]
type = VelSet
trigger1 = frontedgedist <= 2 || time >= 24
y = 0
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = frontedgedist <= 2 || time >= 24
value = 1710
persistent = 0

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1710
statetype = A       ;S,A,C,L
movetype = I        ;I,A,H
physics = A

[State 0, VelSet]
type = VelSet
trigger1 = anim = 1710
trigger1 = animelem = 4 || animelem = 5
x = 0
persistent = 0

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 1710
x = .14

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 1
helpertype = normal
name = "After image 1"
stateno = 1735
id = 1710
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 3
helpertype = normal
name = "After image 2"
stateno = 1735
id = 1711
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 5
helpertype = normal
name = "After image 3"
stateno = 1735
id = 1712
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
attr = A,SA
hitflag = MAF
guardflag = MA
getPower = 0, 0
givePower = 36, 36
animtype = hard
air.animtype = hard
priority = 5,Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 0
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
air.hittime = 20
ground.velocity = -4.5,-8.56
air.velocity = -4.5,-8.56
guard.velocity = -4.2
airguard.velocity = -1.2
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = enemynear,anim != 5030
trigger1 = enemynear,movetype = H && enemynear,time = 0
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = moveguarded
value = 1716

;------<HK Attack>----------
[Statedef 1733]
type = A
movetype = A
physics = N
ctrl = 0
anim = 1703
velset = 9.7,4.7

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
var(25) = 16

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 2
ignorehitpause = 1

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0
ignorehitpause = 1

[State 0, Helper]
type = Helper
trigger1 = anim != 1710
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Random FX"
ID = 2706
stateno = 2706
pos = 19,-51
postype = p1
ownpal = 1
size.xscale = .5
size.yscale = .5
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 1
value = S0,10
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = S5,4
volume = 255
channel = -1

[State 0, ScreenBound]
type = ScreenBound
trigger1 = anim = 1703
value = 1
movecamera = 0,1

[State 0, VelSet]
type = VelSet
trigger1 = frontedgedist <= 2 || time >= 24
y = 0
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = frontedgedist <= 2 || time >= 24
value = 1703
persistent = 0

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1710
statetype = A       ;S,A,C,L
movetype = I        ;I,A,H
physics = A

[State 0, VelSet]
type = VelSet
trigger1 = anim = 1710
trigger1 = animelem = 4 || animelem = 5
x = 0
persistent = 0

[State 0, VelAdd]
type = VelAdd
trigger1 = anim = 1710
x = .14

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 1
helpertype = normal
name = "After image 1"
stateno = 1736
id = 1710
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 3
helpertype = normal
name = "After image 2"
stateno = 1736
id = 1711
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
triggerall = !moveguarded
trigger1 = time = 5
helpertype = normal
name = "After image 3"
stateno = 1736
id = 1712
pos = 0,0
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 5 || var(20))
attr = A,SA
hitflag = MAF
guardflag = MA
getPower = 0, 0
givePower = 36, 36
animtype = hard
air.animtype = hard
priority = 6,Hit
damage = ceil(ifElse(fvar(11) * 24 < 7, 7, fvar(11) * 24)), 0
pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
guard.pauseTime = ifElse(var(20), 3, 6), ifElse(var(20), 3, 6)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
air.hittime = 20
ground.velocity = -4.5,-8.56
air.velocity = -4.5,-8.56
guard.velocity = -4.2
airguard.velocity = -1.2
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = enemynear,anim != 5030
trigger1 = enemynear,movetype = H && enemynear,time = 0
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = moveguarded
value = 1716

;-----------<afterimages lk>-----------
[Statedef 1734]
type = A
movetype = I
physics = N

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1701

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1710)
trigger1 = time = 0
time = 1
pos = -15,-25
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1711)
trigger1 = time = 0
time = 1
pos = -22,-45
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1712)
trigger1 = time = 0
time = 1
pos = -31,-65
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = root,vel x
y = root,vel y

[State 0, VelSet]
type = PosFreeze
trigger1 = root,HitPauseTime
value = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1710)
trigger1 = time > 0
x = -.04
y = -.08
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1711)
trigger1 = time > 0
x = -.09
y = -.19
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1712)
trigger1 = time > 0
x = -.18
y = -.36
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1710)
trigger1 = 1
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1711)
trigger1 = 1
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1712)
trigger1 = 1
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,anim = 1710
value = 1707

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,pos y >= 0
value = 1708

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H || root,moveguarded || root,stateno != 1731
ignorehitpause = 1

;-----------<afterimages mk>-----------
[Statedef 1735]
type = A
movetype = I
physics = N

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1702

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1710)
trigger1 = time = 0
time = 1
pos = -15,-5
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1711)
trigger1 = time = 0
time = 1
pos = -22,-8
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1712)
trigger1 = time = 0
time = 1
pos = -31,-11
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = root,vel x
y = root,vel y

[State 0, VelSet]
type = PosFreeze
trigger1 = root,HitPauseTime
value = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1710)
trigger1 = time > 0
x = -.08
y = -.05
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1711)
trigger1 = time > 0
x = -.29
y = -.15
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1712)
trigger1 = time > 0
x = -.49
y = -.25
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1710)
trigger1 = 1
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1711)
trigger1 = 1
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1712)
trigger1 = 1
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,anim = 1710
value = 1707

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,pos y >= 0
value = 1708

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H || root,moveguarded || root,stateno != 1732
ignorehitpause = 1

;-----------<afterimages hk>-----------
[Statedef 1736]
type = A
movetype = I
physics = N

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Cipher Slash FX"
ID = 2705
stateno = 2705
pos = 19,-50
postype = p1    ;p2,front,back,left,right
ownpal = 1
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1703

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1710)
trigger1 = time = 0
time = 1
pos = -15,-5
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1711)
trigger1 = time = 0
time = 1
pos = -22,-8
persistent = 0

[State 0, BindToRoot]
type = BindToRoot
trigger1 = ishelper(1712)
trigger1 = time = 0
time = 1
pos = -31,-11
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = root,vel x
y = root,vel y

[State 0, VelSet]
type = PosFreeze
trigger1 = root,HitPauseTime
value = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1710)
trigger1 = time > 0
x = -.14
y = -.012
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1711)
trigger1 = time > 0
x = -.35
y = -.024
ignorehitpause = 1

[State 0, Veladd]
type = Veladd
trigger1 = ishelper(1712)
trigger1 = time > 0
x = -.59
y = -.028
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1710)
trigger1 = anim != 1710
trans = addalpha
alpha = 256,150
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1711)
trigger1 = anim != 1710
trans = addalpha
alpha = 200,130
ignorehitpause = 1

[State 0, Trans]
type = Trans
triggerall = ishelper(1712)
trigger1 = anim != 1710
trans = addalpha
alpha = 156,110
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,anim = 1710
value = 1707

[State 0, ChangeState]
type = ChangeState
triggerall = !root,moveguarded
trigger1 = root,pos y >= 0
value = 1708

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,movetype = H || root,moveguarded || root,stateno != 1733
ignorehitpause = 1

;=====================<Wall Climb Start>==========================
[StateDef 1800]
type = A
movetype = I
physics = N
anim = 1800
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 72 * !var(20)
faceP2 = 1

[State 1800, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "x"), 0, ifElse((command = "y"), 1, 2))

[State 1800, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 0, PlayerPush]
type = PlayerPush
trigger1 = (anim = [1800,1801]) || (anim = [1803,1804])
value = 0

[State 0, ScreenBound]
type = ScreenBound
trigger1 = anim = 1800
value = 1
movecamera = 0,1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = anim = 1800
trigger1 = animelem = 2
value = S4,1
volume = 255
channel = -1

[State 0, VelSet]
type = VelSet
triggerall = anim != [1801,1804]
trigger1 = var(10) = 0
trigger1 = animelem = 3
x = -6.23
y = -3.5
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
triggerall = anim != [1801,1804]
trigger1 = var(10) = 1
trigger1 = animelem = 3
x = -6.23
y = -4.85
ignorehitpause = 1

[State 0, VelSet]
type = VelSet
triggerall = anim != [1801,1804]
trigger1 = var(10) = 2
trigger1 = animelem = 3
x = -6.23
y = -6.35
ignorehitpause = 1

[State 0, Gravity]
type = Gravity
triggerall = anim != [1801,1804]
trigger1 = anim = 1800 && time > 30

[State 0, VelAdd]
type = VelAdd
triggerall = anim != [1801,1804]
trigger1 = anim = 1800 && time > 7
x = -0.085

[State 0, VelSet]
type = VelSet
triggerall = anim != 1801
trigger1 = time > 45
trigger1 = backedgedist < 10
x = 0

[State 0, VelSet]
type = VelSet
triggerall = anim != 1801
trigger1 = time > 45
trigger1 = backedgedist < 10
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = anim != [1801,1804]
trigger1 = prevstateno != 1801 || prevstateno != 1806
trigger1 = time > 45
trigger1 = backedgedist < 10
value = 1811
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = anim = 1811
trigger1 = !animtime
trigger2 = prevstateno = 1801 || prevstateno = 1806
value = 1801
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = prevstateno != 1801
trigger1 = anim = 1811
value = S2,800
volume = 255
channel = -1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = anim = 1801
v = 10    ;fv = 10
value = 0

[State 0, PosSet]
type = PosSet
triggerall = anim != 1800 && facing = 1
trigger1 = 1
x = -145

[State 0, PosSet]
type = PosSet
triggerall = anim != 1800 && facing = -1
trigger1 = 1
x = 145

[State 0, VarSet]
type = VarSet
triggerall = anim = 1801
trigger1 = command = "holdup"
v = 54    ;fv = 10
value = 1

[State 0, VarSet]
type = VarSet
triggerall = anim = 1801
trigger1 = command = "holddown" || command = "holddown" && prevstateno = 1801
v = 54    ;fv = 10
value = 2

[State 0, VarSet]
type = VarSet
trigger1 = (var(54) = [1,2])
trigger1 = command = "Release Up" || command = "Release Down"
trigger2 = anim = 1800 || anim = 1802
v = 54    ;fv = 10
value = 0

[State 0, Response time]
type = VarAdd
trigger1 = var(54) = [1,2]
v = 55   ;fv = 10
value = 1

[State 0, Stop Response time]
type = VarSet
trigger1 = var(54) = 0
v = 55   ;fv = 10
value = 0

;-----<move up or down>-------

[State 0, VelSet]
type = PosAdd
triggerall = screenpos Y >= 99.83
trigger1 = var(54) = 1
y = -2.5

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = var(54) = 1 && var(55) = 1
value = 1803

[State 0, VelSet]
type = PosAdd
triggerall = pos y <= 0
trigger1 = var(54) = 2
y = 2.5

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = var(54) = 2 && var(55) = 1
value = 1804

[State 0, VelSet]
type = PosAdd
trigger1 = var(54) = 0
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = anim != 1800
trigger1 = var(56) = 1
value = 1801

[State 0, VarAdd]
type = VarAdd
triggerall = anim != 1802
trigger1 = var(54) = 0
v = 56    ;fv =
value = 1

[State 0, VarSet]
type = VarSet
trigger1 = var(54) = [1,2]
v = 56    ;fv = 10
value = 0

;----<attack cipher>-------

[State 0, ChangeState]
type = ChangeAnim
trigger1 = anim = 1801 || anim = [1803,1804]
trigger1 = command = "x" ||command = "y" || command = "z"
value = 1802

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1802
statetype = A
movetype = A
physics = N

[State 0, VarSet]
type = VarSet
triggerall = anim = 1802
trigger1 = movecontact
v = 27
value = 2
ignorehitpause = 1

[State 0, HitDef]
type = HitDef
triggerall = enemynear,statetype = A
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = anim = 1802
trigger1 = animelem = 3
attr = A,SA
hitflag = MAF
guardflag = H
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10) = 1, 119, 105)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10) = 1, 119, 105)))), 7
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, HitDef]
type = HitDef
triggerall = enemynear,statetype != A
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = anim = 1802
trigger1 = animelem = 3
attr = A,SA
hitflag = MAF
guardflag = H
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10) = 1, 119, 105)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10) = 1, 119, 105)))), 7
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2facing = 1
p2stateno = 1809
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = anim = 1802
trigger1 = animelem = 2
value = S4,2;1,8
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = anim = 1802
trigger1 = animelem = 2
value = S187,0;1,8
volume = 255
channel = -1

[State 0, Helper]
type = Helper
triggerall = anim = 1802
trigger1 = animelem = 2
helpertype = normal
name = "Cipher Slash FX"
ID = 2805
stateno = 2805
pos = 0,-10
postype = p1
ownpal = 1

[State 0, ChangeState]
type = ChangeAnim
trigger1 = anim = 1802
trigger1 = !animtime
value = 1801

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1802
trigger1 = !animtime
statetype = A
movetype = I
physics = N

[State 0, ChangeState]
type = ChangeState
trigger1 = anim != 1802
trigger1 = command = "down_a" || command = "down_b" || command = "down_c"
value = 1801

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1801
trigger1 = command = "a"
value = 1802

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1801
trigger1 = command = "b"
value = 1803

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1801
trigger1 = command = "c"
value = 1804

[State 0, ChangeState]
type = ChangeState
triggerall = time > 80
trigger1 = anim != 1802
trigger1 = prevstateno != 1806
trigger1 = command = "Wall Switch"
value = 1805

[State 0, ChangeState]
type = ChangeState
triggerall = time > 40
trigger1 = prevstateno = 1806
trigger1 = command = "Wall Switch"
value = 1805

[State 0, ChangeState]
type = ChangeState
trigger1 = (var(57) >= 300 || winko) && (anim != 1802 || anim != 1811)
value = 1807
persistent = 0

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1801 || anim = [1803,1804]
trigger1 = command = "fwd"
value = 1808

;-----------------------------------
;Down slide Kick while in wall climb
;-----------------------------------
[Statedef 1801]
type = A
movetype = A
physics = N
anim = 1806

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S4,5
volume = 255
channel = -1

[State 0, VelSet]
type = VelSet
trigger1 = backedgedist < 10
x = 0
y = 0

[State 0, VarSet]
type = VarSet
trigger1 = prevstateno = 1800
v = 54
value = 0

[State 0, PosSet]
type = PosSet
trigger1 = facing = 1
trigger1 = 1
x = -145

[State 0, PosSet]
type = PosSet
trigger1 = facing = -1
trigger1 = 1
x = 145

[State 0, PosAdd]
type = PosAdd
triggerall = pos y < 0
trigger1 = anim != 1807
y = 6

[State 0, HitDef]
type = HitDef
triggerall = enemynear,statetype = A
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = 1
attr = A,SA
hitflag = MAF
guardflag = H
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10) = 1, 119, 105)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10) = 1, 119, 105)))), 7
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, HitDef]
type = HitDef
triggerall = enemynear,statetype != A
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = 1
attr = A,SA
hitflag = MAF
guardflag = H
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10) = 1, 119, 105)) < 7, 7, fvar(11) * ifElse(var(10) = 2, 126, ifElse(var(10) = 1, 119, 105)))), 7
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2stateno = 1810
p2facing = 1
persistent = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 25
value = 1807

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1807
trigger1 = !animtime
value = 1800

;---------------------------------
;Dive Kick From Wall Climb 1
;---------------------------------
[Statedef 1802]
type = A
movetype = A
physics = N
anim = 1808
velset = 0,0

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S1100,2
volume = 255
channel = -1

[State 0, VarSet]
type = VarSet
trigger1 = prevstateno = 1800
v = 54
value = 0

[State 0, PosSet]
type = PosSet
trigger1 = facing = 1
trigger1 = time <= 6
x = -145

[State 0, PosSet]
type = PosSet
trigger1 = facing = -1
trigger1 = time <= 6
x = 145

[State 0, VelSet]
type = VelSet
trigger1 = time > 6
x = 5.4
y = 10.23

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 6
x = 1.1
y = 5.1

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem = 4 || animelem = 5
attr = SCA,SA
hitflag = MAF
guardflag = H
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 105 < 7, 7, fvar(11) * 105)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -15
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.cornerpush.veloff = (ifelse(numhelper(4011), 0, -12.5))
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2stateno = 1811
p2facing = 1
persistent = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

;---------------------------------
;Dive Kick From Wall Climb 2
;---------------------------------
[Statedef 1803]
type = A
movetype = A
physics = N
anim = 1809
velset = 0,0

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S1100,2
volume = 255
channel = -1

[State 0, VarSet]
type = VarSet
trigger1 = prevstateno = 1800
v = 54
value = 0

[State 0, PosSet]
type = PosSet
trigger1 = facing = 1
trigger1 = time <= 6
x = -145

[State 0, PosSet]
type = PosSet
trigger1 = facing = -1
trigger1 = time <= 6
x = 145

[State 0, PosAdd]
type = PosAdd
trigger1 = animelem = 4
y = -25

[State 0, VelSet]
type = VelSet
trigger1 = time > 6
x = 7.4
y = 8.23

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 6
x = 1.56
y = 5.1

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = 1
attr = SCA,SA
hitflag = MAF
guardflag = H
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 5,Hit
damage = ceil(ifElse(fvar(11) * 119 < 7, 7, fvar(11) * 119)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -15
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.cornerpush.veloff = (ifelse(numhelper(4011), 0, -12.5))
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2stateno = 1811
p2facing = 1
persistent = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

;---------------------------------
;Dive Kick From Wall Climb 3
;---------------------------------
[Statedef 1804]
type = A
movetype = A
physics = N
anim = 1809
velset = 0,0

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S1100,2
volume = 255
channel = -1

[State 0, VarSet]
type = VarSet
trigger1 = prevstateno = 1800
v = 54
value = 0

[State 0, PosSet]
type = PosSet
trigger1 = facing = 1
trigger1 = time <= 6
x = -145

[State 0, PosSet]
type = PosSet
trigger1 = facing = -1
trigger1 = time <= 6
x = 145

[State 0, PosAdd]
type = PosAdd
trigger1 = animelem = 4
y = -25

[State 0, VelSet]
type = VelSet
trigger1 = time > 6
x = 11.4
y = 6.23

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 6
x = 2.97
y = 5.1

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = 1
attr = SCA,SA
hitflag = MAF
guardflag = H
getPower = ifElse(!var(13), 72, 36) * !var(20), 12 * !var(20)
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 6,Hit
damage = ceil(ifElse(fvar(11) * 126 < 7, 7, fvar(11) * 126)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -15
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.cornerpush.veloff = (ifelse(numhelper(4011), 0, -12.5))
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2stateno = 1811
p2facing = 1
persistent = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

;---------------------------------------------
;Glide from one side of the wall to the other
;---------------------------------------------
[Statedef 1805]
type = A
movetype = I
physics = N
anim = 1810
ctrl = 0
velset = 0,0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S4,4
volume = 255
channel = -1

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, ScreenBound]
type = ScreenBound
trigger1 = time > 6
value = 0
movecamera = 0,1

[State 0, VelSet]
type = VelSet
trigger1 = time > 6
x = 10.5

[State 0, ChangeState]
type = ChangeState
trigger1 = frontedgedist < 10
value = 1806

;-------------------------------------------------
;Glide from one side of the wall to the other END
;-------------------------------------------------
[Statedef 1806]
type = A
movetype = I
physics = N
anim = 1811
ctrl = 0
velset = 0,0

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, PosSet]
type = PosSet
triggerall = facing = 1
trigger1 = 1
x = -145

[State 0, PosSet]
type = PosSet
triggerall = facing = -1
trigger1 = 1
x = 145

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1811
trigger1 = !animtime
value = 1800

;-------------------------------------------------
;Jump down from wall (Auto)
;-------------------------------------------------
[Statedef 1807]
type = A
movetype = I
physics = A

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1813
elem = 5

;-------------------------------------------------
;Jump down from wall (Manual)
;-------------------------------------------------
[Statedef 1808]
type = A
movetype = I
physics = A

[State 0, VelSet]
type = VelSet
trigger1 = 1
x = 2.87

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1813
elem = 5

;----------------------------------------------------------
;Custom states for p2 Attacked by Cipher during Wall Climb
;----------------------------------------------------------
[Statedef 1809]
type = S
movetype = H
physics = S
ctrl = 0
facep2 = 1
poweradd = 30

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PosSet]
type = PosSet
trigger1 = time < 12
y = 0

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 1812
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time < 12
x = 0
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = time > 11
x = -8.59

[State 0, VelSet]
type = VelSet
trigger1 = time = [10,15]
y = -.35

[State 0, Gravity]
type = Gravity
trigger1 = 1

[State 0, SelfState]
type = SelfState
trigger1 = time > 20 && pos y > 0
value = 5201

[State 0, SelfState]
type = SelfState
trigger1 = !alive
value = 5000

;----------------------------------------------------------
;Custom states for p2 Attacked by Stomp during Wall Climb
;----------------------------------------------------------
[Statedef 1810]
type = S
movetype = H
physics = S
ctrl = 0
poweradd = 30

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PosSet]
type = PosSet
trigger1 = time < 12
y = 0

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 1812
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time < 12
x = 0
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = time > 11
x = -5.59

[State 0, VelSet]
type = VelSet
trigger1 = time = [10,15]
y = -.35

[State 0, Gravity]
type = Gravity
trigger1 = 1

[State 0, SelfState]
type = SelfState
trigger1 = time > 20 && pos y > 0
value = 5201

[State 0, SelfState]
type = SelfState
trigger1 = !alive
value = 5000

;----------------------------------------------------------
;Custom states for p2 Attacked by Stomp during Wall Climb
;----------------------------------------------------------
[Statedef 1811]
type = U
movetype = H
physics = N
poweradd = 30

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 1814

[State 0, VelSet]
type = VelSet
trigger1 = time <= 12
x = 0
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = statetype = A
trigger1 = time > 12
x = -7.5
y = 10.2

[State 0, VelSet]
type = VelSet
trigger1 = statetype != A
trigger1 = time > 12
x = -7.5

[State 0, VelSet]
type = VelSet
trigger1 = time > 20
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, SelfState];Recover
type = SelfState
trigger1 = time > 20
trigger1 = pos y >= 0
value = 5201

[State 0, SelfState]
type = SelfState
trigger1 = !alive
value = 5000

;=====================<EX Wall Climb Start>==========================
[StateDef 1830]
type = A
movetype = I
physics = N
anim = 1800
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 1030, Button Detect]
type = VarSet
trigger1 = !Time
var(10) = 3

[State 1030, Custom Combo Juggle Points Reset]
type = VarSet
trigger1 = !Time && var(20)
var(15) = 0
ignoreHitPause = 1

[State 1030, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = var(20) := -1
time = 1

[State 1030, EX Flash]
type = VarSet
trigger1 = !Time
trigger1 = prevstateno != 1831
trigger1 = prevstateno != 1836
var(25) = 60

[State 0, TargetpowerAdd]
type = powerAdd
trigger1 = command = "EXWall Climb"
value = -500

[State 1030, EX FX]
type = Explod
trigger1 = !Time
trigger1 = prevstateno != 1831
trigger1 = prevstateno != 1836
anim = 8210
sprPriority = 3
posType = p1
pos = ceil(6 * const(size.xScale)), ceil(-70 * const(size.yScale))
scale = 0.5, 0.5
pauseMoveTime = -1
superMoveTime = -1
ownPal = 1

[State 1030, EX Startup Sound]
type = PlaySnd
trigger1 = !Time
trigger1 = prevstateno != 1831
trigger1 = prevstateno != 1836
value = 0,1000
channel = 1

[State 0, PlayerPush]
type = PlayerPush
trigger1 = (anim = [1800,1801]) || (anim = [1803,1804])
value = 0

[State 0, ScreenBound]
type = ScreenBound
trigger1 = anim = 1800
value = 1
movecamera = 0,1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = anim = 1800
trigger1 = animelem = 2
value = S4,1
volume = 255
channel = -1

[State 0, VelSet]
type = VelSet
triggerall = anim != [1801,1804]
trigger1 = animelem = 3
x = -6.23
y = -4.85
ignorehitpause = 1

[State 0, Gravity]
type = Gravity
triggerall = anim != [1801,1804]
trigger1 = anim = 1800 && time > 30

[State 0, VelAdd]
type = VelAdd
triggerall = anim != [1801,1804]
trigger1 = anim = 1800 && time > 7
x = -0.95

[State 0, VelSet]
type = VelSet
triggerall = anim != 1801
trigger1 = time > 45
trigger1 = backedgedist < 10
x = 0

[State 0, VelSet]
type = VelSet
triggerall = anim != 1801
trigger1 = time > 45
trigger1 = backedgedist < 10
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = anim != [1801,1804]
trigger1 = prevstateno != 1831 || prevstateno != 1836
trigger1 = time > 45
trigger1 = backedgedist < 10
value = 1811
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = anim = 1811
trigger1 = !animtime
trigger2 = prevstateno = 1831 || prevstateno = 1836
value = 1801
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = prevstateno != 1831
trigger1 = anim = 1811
value = S2,800
volume = 255
channel = -1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = anim = 1801
v = 10    ;fv = 10
value = 3

[State 0, PosSet]
type = PosSet
triggerall = anim != 1800 && facing = 1
trigger1 = 1
x = -145

[State 0, PosSet]
type = PosSet
triggerall = anim != 1800 && facing = -1
trigger1 = 1
x = 145

[State 0, VarSet]
type = VarSet
triggerall = anim = 1801
trigger1 = command = "holdup"
v = 54    ;fv = 10
value = 1

[State 0, VarSet]
type = VarSet
triggerall = anim = 1801
trigger1 = command = "holddown" || command = "holddown" && prevstateno = 1831
v = 54    ;fv = 10
value = 2

[State 0, VarSet]
type = VarSet
trigger1 = (var(54) = [1,2])
trigger1 = command = "Release Up" || command = "Release Down"
trigger2 = anim = 1800 || anim = 1802
v = 54    ;fv = 10
value = 0

[State 0, Response time]
type = VarAdd
trigger1 = var(54) = [1,2]
v = 55   ;fv = 10
value = 1

[State 0, Stop Response time]
type = VarSet
trigger1 = var(54) = 0
v = 55   ;fv = 10
value = 0

;-----<move up or down>-------

[State 0, VelSet]
type = PosAdd
triggerall = screenpos Y >= 99.83
trigger1 = var(54) = 1
y = -2.5

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = var(54) = 1 && var(55) = 1
value = 1803

[State 0, VelSet]
type = PosAdd
triggerall = pos y <= 0
trigger1 = var(54) = 2
y = 2.5

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = var(54) = 2 && var(55) = 1
value = 1804

[State 0, VelSet]
type = PosAdd
trigger1 = var(54) = 0
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
triggerall = anim != 1800
trigger1 = var(56) = 1
value = 1801

[State 0, VarAdd]
type = VarAdd
triggerall = anim != 1802
trigger1 = var(54) = 0
v = 56    ;fv =
value = 1

[State 0, VarSet]
type = VarSet
trigger1 = var(54) = [1,2]
v = 56    ;fv = 10
value = 0

;----<attack cipher>-------

[State 0, ChangeState]
type = ChangeAnim
trigger1 = anim = 1801 || anim = [1803,1804]
trigger1 = command = "x" ||command = "y" || command = "z"
value = 1802

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1802
statetype = A
movetype = A
physics = N

[State 0, VarSet]
type = VarSet
triggerall = anim = 1802
trigger1 = movecontact
v = 27
value = 2
ignorehitpause = 1

[State 0, HitDef]
type = HitDef
triggerall = enemynear,statetype = A
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = anim = 1802
trigger1 = animelem = 3
attr = A,SA
hitflag = MAF
guardflag = H
getPower = 0, 0
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 125 < 7, 7, fvar(11) * 125)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, HitDef]
type = HitDef
triggerall = enemynear,statetype != A
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = anim = 1802
trigger1 = animelem = 3
attr = A,SA
hitflag = MAF
guardflag = H
getPower = 0, 0
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 125 < 7, 7, fvar(11) * 125)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2facing = 1
p2stateno = 1839
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = anim = 1802
trigger1 = animelem = 2
value = S4,2;1,8
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = anim = 1802
trigger1 = animelem = 2
value = S187,0;1,8
volume = 255
channel = -1

[State 0, Helper]
type = Helper
triggerall = anim = 1802
trigger1 = animelem = 2
helpertype = normal
name = "Cipher Slash FX"
ID = 2835
stateno = 2835
pos = 0,-10
postype = p1
ownpal = 1

[State 0, ChangeState]
type = ChangeAnim
trigger1 = anim = 1802
trigger1 = !animtime
value = 1801

[State 0, StateTypeSet]
type = StateTypeSet
trigger1 = anim = 1802
trigger1 = !animtime
statetype = A
movetype = I
physics = N

[State 0, ChangeState]
type = ChangeState
trigger1 = anim != 1802
trigger1 = command = "down_a" || command = "down_b" || command = "down_c"
value = 1831

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1801
trigger1 = command = "a"
value = 1832

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1801
trigger1 = command = "b"
value = 1833

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1801
trigger1 = command = "c"
value = 1834

[State 0, ChangeState]
type = ChangeState
triggerall = time > 80
trigger1 = anim != 1802
trigger1 = prevstateno != 1836
trigger1 = command = "Wall Switch"
value = 1835

[State 0, ChangeState]
type = ChangeState
triggerall = time > 40
trigger1 = prevstateno = 1836
trigger1 = command = "Wall Switch"
value = 1835

[State 0, ChangeState]
type = ChangeState
trigger1 = (var(57) >= 500 || winko) && (anim != 1802 || anim != 1811)
value = 1837
persistent = 0

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1801 || anim = [1803,1804]
trigger1 = command = "fwd"
value = 1838

;-----------------------------------
;Down slide Kick while in wall climb
;-----------------------------------
[Statedef 1831]
type = A
movetype = A
physics = N
anim = 1806

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S4,5
volume = 255
channel = -1

[State 0, VelSet]
type = VelSet
trigger1 = backedgedist < 10
x = 0
y = 0

[State 0, VarSet]
type = VarSet
trigger1 = prevstateno = 1830
v = 54
value = 0

[State 0, PosSet]
type = PosSet
trigger1 = facing = 1
trigger1 = 1
x = -145

[State 0, PosSet]
type = PosSet
trigger1 = facing = -1
trigger1 = 1
x = 145

[State 0, PosAdd]
type = PosAdd
triggerall = pos y < 0
trigger1 = anim != 1807
y = 6

[State 0, HitDef]
type = HitDef
triggerall = enemynear,statetype = A
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = 1
attr = A,SA
hitflag = MAF
guardflag = H
getPower = 0, 0
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 125 < 7, 7, fvar(11) * 125)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, HitDef]
type = HitDef
triggerall = enemynear,statetype != A
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = 1
attr = A,SA
hitflag = MAF
guardflag = H
getPower = 0, 0
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 125 < 7, 7, fvar(11) * 125)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 5, 10)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -65
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2stateno = 1840
p2facing = 1
persistent = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 25
value = 1807

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1807
trigger1 = !animtime
value = 1830

;---------------------------------
;Dive Kick From Wall Climb 1
;---------------------------------
[Statedef 1832]
type = A
movetype = A
physics = N
anim = 1808
velset = 0,0

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S1100,2
volume = 255
channel = -1

[State 0, VarSet]
type = VarSet
trigger1 = prevstateno = 1830
v = 54
value = 0

[State 0, PosSet]
type = PosSet
trigger1 = facing = 1
trigger1 = time <= 6
x = -145

[State 0, PosSet]
type = PosSet
trigger1 = facing = -1
trigger1 = time <= 6
x = 145

[State 0, VelSet]
type = VelSet
trigger1 = time > 6
x = 5.4
y = 10.23

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 6
x = 1.1
y = 5.1

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = animelem = 4 || animelem = 5
attr = SCA,SA
hitflag = MAF
guardflag = H
getPower = 0, 0
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 4,Hit
damage = ceil(ifElse(fvar(11) * 135 < 7, 7, fvar(11) * 135)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -15
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.cornerpush.veloff = (ifelse(numhelper(4011), 0, -12.5))
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2stateno = 1841
p2facing = 1
persistent = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

;---------------------------------
;Dive Kick From Wall Climb 2
;---------------------------------
[Statedef 1833]
type = A
movetype = A
physics = N
anim = 1809
velset = 0,0

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S1100,2
volume = 255
channel = -1

[State 0, VarSet]
type = VarSet
trigger1 = prevstateno = 1830
v = 54
value = 0

[State 0, PosSet]
type = PosSet
trigger1 = facing = 1
trigger1 = time <= 6
x = -145

[State 0, PosSet]
type = PosSet
trigger1 = facing = -1
trigger1 = time <= 6
x = 145

[State 0, PosAdd]
type = PosAdd
trigger1 = animelem = 4
y = -25

[State 0, VelSet]
type = VelSet
trigger1 = time > 6
x = 7.4
y = 8.23

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 6
x = 1.56
y = 5.1

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = 1
attr = SCA,SA
hitflag = MAF
guardflag = H
getPower = 0, 0
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 5,Hit
damage = ceil(ifElse(fvar(11) * 135 < 7, 7, fvar(11) * 135)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -15
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.cornerpush.veloff = (ifelse(numhelper(4011), 0, -12.5))
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2stateno = 1841
p2facing = 1
persistent = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

;---------------------------------
;Dive Kick From Wall Climb 3
;---------------------------------
[Statedef 1834]
type = A
movetype = A
physics = N
anim = 1809
velset = 0,0

[State 0, VarSet]
type = VarSet
trigger1 = movecontact
v = 27    ;fv = 10
value = 1
ignorehitpause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S1100,2
volume = 255
channel = -1

[State 0, VarSet]
type = VarSet
trigger1 = prevstateno = 1830
v = 54
value = 0

[State 0, PosSet]
type = PosSet
trigger1 = facing = 1
trigger1 = time <= 6
x = -145

[State 0, PosSet]
type = PosSet
trigger1 = facing = -1
trigger1 = time <= 6
x = 145

[State 0, PosAdd]
type = PosAdd
trigger1 = animelem = 4
y = -25

[State 0, VelSet]
type = VelSet
trigger1 = time > 6
x = 11.4
y = 6.23

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 6
x = 2.97
y = 5.1

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, HitDef]
type = HitDef
trigger1 = !var(16) && (var(15) < 1 || var(20))
trigger1 = 1
attr = SCA,SA
hitflag = MAF
guardflag = H
getPower = 0, 0
givePower = 36, 36
animtype = medium
air.animtype = medium
priority = 6,Hit
damage = ceil(ifElse(fvar(11) * 135 < 7, 7, fvar(11) * 135)), 0
pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
guard.pauseTime = ifElse(var(20), 6, 12), ifElse(var(20), 6, 12)
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 307), var(36) := -15
ground.type = High
air.type = low
ground.slidetime = 65
ground.hittime = 20
air.cornerpush.veloff = (ifelse(numhelper(4011), 0, -12.5))
air.hittime = 20
ground.velocity = -7.5,0
air.velocity = -2.9,-4.7
sprpriority = 1
p2stateno = 1841
p2facing = 1
persistent = 0
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120

[State 0, EnvColor]
type = EnvColor
trigger1 = movehit
value = 255,255,255
time = 1
under = 0
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = hitpausetime
v = 22
value = 2
ignorehitpause = 1
persistent = 0

[State 0, VarSet]
type = VarSet
trigger1 = !hitpausetime
v = 22
value = 0
ignorehitpause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 52

;---------------------------------------------
;Glide from one side of the wall to the other
;---------------------------------------------
[Statedef 1835]
type = A
movetype = I
physics = N
anim = 1810
ctrl = 0
velset = 0,0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 2
value = S4,4
volume = 255
channel = -1

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, ScreenBound]
type = ScreenBound
trigger1 = time > 6
value = 0
movecamera = 0,1

[State 0, VelSet]
type = VelSet
trigger1 = time > 6
x = 10.5

[State 0, ChangeState]
type = ChangeState
trigger1 = frontedgedist < 10
value = 1836

;-------------------------------------------------
;Glide from one side of the wall to the other END
;-------------------------------------------------
[Statedef 1836]
type = A
movetype = I
physics = N
anim = 1811
ctrl = 0
velset = 0,0

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, PosSet]
type = PosSet
triggerall = facing = 1
trigger1 = 1
x = -145

[State 0, PosSet]
type = PosSet
triggerall = facing = -1
trigger1 = 1
x = 145

[State 0, ChangeState]
type = ChangeState
triggerall = anim = 1811
trigger1 = !animtime
value = 1830

;-------------------------------------------------
;Jump down from wall (Auto)
;-------------------------------------------------
[Statedef 1837]
type = A
movetype = I
physics = A

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1813
elem = 5

;-------------------------------------------------
;Jump down from wall (Manual)
;-------------------------------------------------
[Statedef 1838]
type = A
movetype = I
physics = A

[State 0, VelSet]
type = VelSet
trigger1 = 1
x = 2.87

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = time = 0
value = 1813
elem = 5

;----------------------------------------------------------
;Custom states for p2 Attacked by Cipher during Wall Climb
;----------------------------------------------------------
[Statedef 1839]
type = S
movetype = H
physics = S
ctrl = 0
facep2 = 1
poweradd = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PosSet]
type = PosSet
trigger1 = time < 12
y = 0

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 1812
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time < 12
x = 0
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = time > 11
x = -8.59

[State 0, VelSet]
type = VelSet
trigger1 = time = [10,15]
y = -.35

[State 0, Gravity]
type = Gravity
trigger1 = 1

[State 0, SelfState]
type = SelfState
trigger1 = time > 20 && pos y > 0
value = 5201

[State 0, SelfState]
type = SelfState
trigger1 = !alive
value = 5000

;----------------------------------------------------------
;Custom states for p2 Attacked by Stomp during Wall Climb
;----------------------------------------------------------
[Statedef 1840]
type = S
movetype = H
physics = S
ctrl = 0
poweradd = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, PosSet]
type = PosSet
trigger1 = time < 12
y = 0

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 1812
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = time < 12
x = 0
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = time > 11
x = -5.59

[State 0, VelSet]
type = VelSet
trigger1 = time = [10,15]
y = -.35

[State 0, Gravity]
type = Gravity
trigger1 = 1

[State 0, SelfState]
type = SelfState
trigger1 = time > 20 && pos y > 0
value = 5201

[State 0, SelfState]
type = SelfState
trigger1 = !alive
value = 5000

;----------------------------------------------------------
;Custom states for p2 Attacked by Stomp during Wall Climb
;----------------------------------------------------------
[Statedef 1841]
type = U
movetype = H
physics = N
poweradd = 0

[State 0, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 1814

[State 0, VelSet]
type = VelSet
trigger1 = time <= 12
x = 0
y = 0

[State 0, VelSet]
type = VelSet
trigger1 = statetype = A
trigger1 = time > 12
x = -7.5
y = 10.2

[State 0, VelSet]
type = VelSet
trigger1 = statetype != A
trigger1 = time > 12
x = -7.5

[State 0, VelSet]
type = VelSet
trigger1 = time > 20
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, SelfState];Recover
type = SelfState
trigger1 = time > 20
trigger1 = pos y >= 0
value = 5201

[State 0, SelfState]
type = SelfState
trigger1 = !alive
value = 5000

;=====================<Teleport>==========================
[StateDef 1900]
type = S
physics = S
moveType = A
anim = 1900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0 * !var(20)
faceP2 = 1

[State 1000, Button Detect]
type = VarSet
trigger1 = !Time && !AILevel
var(10) = ifElse((command = "a"), 0, ifElse((command = "b"), 1, 2))

[State 1000, Button Detect (AI)]
type = VarSet
trigger1 = !Time && AILevel
var(10) = ifElse((P2MoveType = H || Random < 500), 2, ifElse(Random < 500, 1, 0))

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 0
trigger1=var(44)=1
trigger1 = animelem = 8
x = -145
y = -50

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 1
trigger1=var(44)=1
trigger1 = animelem = 8
x = -10
y = -50

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 2
trigger1=var(44)=1
trigger1 = animelem = 8
x = 175
y = -50

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 0
trigger1=var(44)=2
trigger1 = animelem = 8
x = 145
y = -50

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 1
trigger1=var(44)=2
trigger1 = animelem = 8
x = 10
y = -50

[State 0, PosSet]
type = PosSet
triggerall = var(10) = 2
trigger1=var(44)=2
trigger1 = animelem = 8
x = -175
y = -50

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 8
value = S4,1
volume = 50
channel = -1

[State 0, VelSet]
type = VelSet
trigger1 = time > 32
y = 3.5

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 32
y = .56

[State 0, VarSet]
type = VarSet
triggerall = time >= 32
trigger1 = pos y >= 0
v = 10
value = 0

[State 0, ChangeState]
type = ChangeState
triggerall = time >= 32
trigger1 = pos y >= 0
value = 52

;========================<PUNCH ZERO COUNTER>=============================
[StateDef 2900]
type = S
physics = N
moveType = A
anim = 2900
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 2900, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2900, Voice]
type = PlaySnd
trigger1 = !Time
value = 4, 2
channel = 0

[State 2900, Woosh]
type = PlaySnd
trigger1 = !Time
value = 187,0
channel = 1

[State 2900, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = 1
attr = S, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 42 < 7, 7, fvar(11) * 42)), 0
getpower = 0,0
givePower = 36, 36
pauseTime = 12, 12
guard.pauseTime = 12, 12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 7)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8016)
guard.sparkNo = -1 + 0 * (var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 120), var(36) := -65
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd = -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
ID = 2900
kill = 1

[State 0, Helper]
type = Helper
triggerall = anim = 2900
trigger1 = animelem = 1
sprPriority = 2
helpertype = normal
name = "SLASH 1"
ID = 2900
stateno = 2930
pos = 0,0
postype = p1
ownpal = 1
scale = 0.4,0.5
pausemovetime = 99999999
supermovetime = 99999999
persistent = 0

[State 2900, StateTypeSet: Idle]
type = StateTypeSet
trigger1 = AnimElemTime(5) >= 0
movetype = I

[State 2900, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<KICK ZERO COUNTER>=============================
[StateDef 2910]
type = S
physics = N
moveType = A
anim = 2910
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0

[State 0, VelSet]
type = VelSet
trigger1 = time < 25
x = 5.85

[State 2910, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
value = SCA
time = 1
ignoreHitPause = 1

[State 2910, Voice]
type = PlaySnd
trigger1 = AnimElem = 2
value = 4, 5
channel = 0

[State 2910, Woosh Sound]
type = PlaySnd
trigger1 = AnimElem = 5
value = 101,0
channel = 1

[State 2910, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = 1
attr = C, SA
hitFlag = MAF
guardFlag = M
priority = 4, Hit
damage = ceil(ifElse(fvar(11) * 42 < 7, 7, fvar(11) * 42)), 0
getpower = 0,0
givepower = 36, 36
pauseTime = 12,12
guard.pauseTime = 12,12
animType = DiagUp
air.animType = DiagUp
fall.animType = DiagUp
ground.type = Low
air.type = Low
ground.hitTime = 18
ground.slideTime = 18
guard.hitTime = 18
air.hitTime = 120
ground.velocity = -5.54, -5.25
ground.cornerPush.velOff = 0
guard.velocity = -10.52
guard.cornerPush.velOff = 0
air.velocity = -5.54, -5.25
air.cornerPush.velOff = 0
yAccel = 0.58
fall = 1
fall.recover = 1
fall.recoverTime = 120
forceStand = 1
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8013)
guard.sparkNo = -1 + 0 * (var(34) := 8000)
sparkXY = -10 + 0 * (var(35) := 82), var(36) := -12
palFX.time = 12 * var(9)
palFX.add = 255, 255, 255
palFX.sinAdd= -255, -255, -255, 48
envShake.time = 14
envShake.ampl = 4
envShake.freq = 120
kill = 1

[State 360, 4]
type = VelSet
trigger1 = AnimElem = 12
x = 0

[State 459, StateTypeSet: Idle]
type = StateTypeset
trigger1= AnimElemTime(12) >= 0
moveType = I

[State 2910, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1
