; _________________________________________
;| Strider Hiryu by varo_hades             |
; �����������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<Ouroboros>=============================
[StateDef 3000]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-11 * const(size.xScale)), ceil(-45 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Voice 1]
type = PlaySnd
trigger1 = Time = 0
value = 3000,0
channel = 0

[State 0, Ouroboros]
type = Helper
trigger1 = anim = 3000 && animelem = 8
helpertype = normal
name = "Ouroboros Hyper"
ID = 3010
stateno = 3010
pos = 0,-25
postype = p1
ownpal = 1

[State 3000, ChangeState]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<MAX Ouroboros>=============================
[StateDef 3050]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3050, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(-11 * const(size.xScale)), ceil(-45 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3050, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3050, Voice 1]
type = PlaySnd
trigger1 = Time = 0
value = 3000,0
channel = 0

[State 0, Ouroboros]
type = Helper
trigger1 = anim = 3000 && animelem = 8
helpertype = normal
name = "Ouroboros Hyper"
ID = 3060
stateno = 3060
pos = 0,-25
postype = p1
ownpal = 1

[State 3050, ChangeState]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

;========================<Legion>=============================
[StateDef 3100]
type = S
physics = N
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-55 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Voice 1]
type = PlaySnd
trigger1 = Time = 0
value = 3000,0
channel = 0

[State 0, Legion]
type = Helper
trigger1 = anim = 3100 && animelemtime(3) = 2
helpertype = normal
name = "Legion Hyper"
ID = 3120
stateno = 3120
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = anim = 3100 && time > 130
value = 3101
persistent = 0

[State 3000, ChangeState]
type = ChangeState
trigger1 = anim = 3101 && !animtime
value = 0
ctrl = 1

;========================<MAX Legion>=============================
[StateDef 3150]
type = S
physics = N
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(4) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = Time = 3
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(0 * const(size.xScale)), ceil(-55 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = Time = 3
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, Voice 1]
type = PlaySnd
trigger1 = Time = 0
value = 3000,0
channel = 0

[State 0, Legion]
type = Helper
trigger1 = anim = 3100 && animelemtime(3) = 2
helpertype = normal
name = "Legion Hyper"
ID = 3160
stateno = 3160
pos = 0,0
postype = p1     ;p2,front,back,left,right
ownpal = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = anim = 3100 && time > 150
value = 3101
persistent = 0

[State 3000, ChangeState]
type = ChangeState
trigger1 = anim = 3101 && !animtime
value = 0
ctrl = 1

;========================<Ragnarok>=============================
[StateDef 3200]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3200, Super Pause FX]
type = Helper
trigger1 = Time = 2
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(8 * const(size.xScale)), ceil(-64 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = !Time
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, Voice 1]
type = PlaySnd
trigger1 = Time = 0
value = 3000,0
channel = 0

[State 0, Explod]
type = Explod
trigger1 = animelem = 4
anim = 184
pos = -6,-43
postype = p1  ;p2,front,back,left,right
removetime = -2
scale = .525,.5
sprpriority = 2
ownpal = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 4
value = S181,0
volume = 0
channel = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 9
value = S184,0
volume = 0
channel = 2

[State 0, Explod]
type = Explod
trigger1 = animelem = 9
anim = 3203
pos = 19,-50
postype = p1  ;p2,front,back,left,right
removetime = -2
scale = .5,.5
sprpriority = 2
ownpal = 1

[State 3201, End]
type = ChangeState
trigger1 = !AnimTime
value = 3201
ctrl = 0


;Finish
[StateDef 3201]
type = S
movetype = A
physics = S
anim = 3201
sprpriority = 1
ctrl = 0

[State 0, VelSet]
type = VelSet
trigger1 = 1
y = 0

[State 0, Width]
type = Width
trigger1 = 1
player = 15,0

[State 0, VelSet]
type = VelSet
trigger1 = time < 23
x = 7.4

[State 0, VelMul]
type = Veladd
trigger1 = time > 22
x = 0.31

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time > 10
value = S101,0
volume = 0
channel = -1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = time = 1
value = S3200,0
volume = 255
channel = -1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = animelem = 1 || animelem = 4
value = S100,0
volume = 255
channel = -1

[State 105, Dust Helper]
type = Helper
trigger1 = (animelem = 1 || animelem = 4 || animelem = 7 || time > 24)
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pos = -10,0
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 105, Dust Helper]
type = Helper
triggerall = moveguarded
trigger1 = animtime
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
pos = -10,0
facing = 1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = moveguarded
value = 3201
elem = 9
ignorehitpause = 1
persistent = 0

[State 0, HitDef]
type = HitDef
trigger1 = 1
attr = S, HT
hitflag = HLAF
guardflag = HLA
guardsound = s2,11
priority = 7, Hit
sparkno = -1
sparkxy = 0,-56
sprpriority = 1
p1stateno = 3202
p2stateno = 3211
id = 3211
ignorehitpause = 1
persistent = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 0
ctrl = 1

;-----------------------------------------
;P2 Custom states
;-----------------------------------------
[Statedef 3211];Grabbed
type = S
movetype = H
physics = N
;facep2 = 1

[State 0, VelSet]
type = VelSet
trigger1 = enemynear,stateno = 3202 && enemynear,anim = 3202
x = 0

[State 0, VelSet]
type = VelSet
trigger1 = enemynear,stateno = 3202 && enemynear,anim = 1101
trigger1 = anim != 3211
x = 0
y = -.5

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = Time = 0
value = 3210

[State 0, VelSet]
type = VelSet
trigger1 = anim = 3211
x = 0
y = 0

[State 0, LifeAdd]
type = LifeAdd
trigger1 = time = 70
value = -90
persistent = 0
ignorehitpause = 1

[State 0, LifeAdd]
type = LifeAdd
trigger1 = time = 110
value = -90
persistent = 0
ignorehitpause = 1

[State 0, LifeAdd]
type = LifeAdd
trigger1 = time = 150
value = -90
persistent = 0
ignorehitpause = 1

[State 0, LifeAdd]
type = LifeAdd
trigger1 = time = 180
value = -90
persistent = 0
ignorehitpause = 1

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = enemynear,stateno = [3203,3205]
trigger1 = p2bodydist x < 5
value = 3211
persistent = 0

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = enemynear,stateno = 3206 && enemynear,statetime > 15 || time = 190
value = 3212

;-----------------------------------------
;P2 Custom states Cont.
;-----------------------------------------
[Statedef 3212];Falling
type = A
movetype = H
physics = N

[State 0, LifeAdd]
type = LifeAdd
trigger1 = time = 0
value = -90
persistent = 0
ignorehitpause = 1

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 3212

[State 0, VelSet]
type = VelSet
trigger1 = time < 25
y = -7.55

[State 0, VelAdd]
type = VelAdd
trigger1 = pos y <= 0
trigger1 = time > 35
y = .85

[State 0, VelSet]
type = VelSet
trigger1 = pos y >= 0
x = 0
y = 0

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 30
value = 3213

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = pos y >= 0
value = 3215

;-----------------------------------------
;P2 Custom states FX
;-----------------------------------------
[Statedef 3213]
type = A
movetype = H
physics = N
anim = 3212

[State 0, SprPriority]
type = SprPriority
trigger1 = enemynear,anim = [3212,3213]
value = 3

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosSet]
type = PosSet
trigger1 = enemynear,anim = [3212,3213]
x = enemynear,pos X
y = (enemynear,pos Y) + -55

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = enemynear,anim = 3213
value = 3212
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = enemynear,stateno = 3215
value = S3200,1
volume = 255
channel = -1
persistent = 0

[State 0, PosSet]
type = PosSet
trigger1 = enemynear,stateno = 3215
x = enemynear,pos X
y = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1 = enemynear,stateno = 3215
value = 6014
persistent = 0

[State 0, SprPriority]
type = SprPriority
trigger1 = enemynear,stateno = 3215
value = -1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = enemynear,stateno = 5120
;------------------------------------------
;Ragnarok End
;------------------------------------------
[Statedef 3214]
type = S
anim = 3232
physics = S
ctrl = 0
velset = 0,0
facep2 = 1

[State 0, PosAdd]
type = PosAdd
trigger1 = time = 0
x = (p2dist x) + -20

[State 0, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = !animtime
value = 52

;-----------------------------------------
;P2 Custom states Final.
;-----------------------------------------
[Statedef 3215];Hit Ground
type = A
movetype = H
physics = N
velset = 0,0

[State 0, ChangeAnim2]
type = ChangeAnim2
trigger1 = time = 0
value = 3233
persistent = 0

[State 0, PosSet]
type = PosSet
trigger1 = 1
y = 0

[State 0, EnvShake]
type = EnvShake
trigger1 = time = 0
time = 30
freq = 80
ampl = -4
phase = 90

[State 0, SelfState]
type = SelfState
triggerall = alive
trigger1 = animelemtime(1) > 10
value = 5120

[State 0, SelfState]
type = SelfState
trigger1 = !alive
trigger1 = animelemtime(1) > 10
value = 5150

;-------------------------------------------
;Grabbed and Going Airborne
;-------------------------------------------
[Statedef 3202]
type = S
movetype = I
physics = N
ctrl = 0
anim = 3202
sprpriority = 3

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3202
value = SCA,AA,AP
ignorehitpause=1

[State 0, PlayerPush]
type = PlayerPush
trigger1 = 1
value = 0

[State 0, VelSet]
type = VelSet
trigger1 = time <= 14
x = 0

[State 0, PlaySnd]
type = PlaySnd
triggerall = anim = 3202
trigger1 = animelem = 1
value = S2,800
volume = 255
channel = -1

[State 0, PlaySnd]
type = PlaySnd
triggerall = anim = 3202
trigger1 = animelem = 3
value = S41,1
volume = 255
channel = -1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
triggerall = anim = 3202
trigger1 = animelem = 3
value = S4,0
volume = 255
channel = -1

[State 0, Explod]
type = Explod
triggerall = anim = 3202
trigger1 = animelem = 3
anim = 6003
pos = 0,35
postype = p1
removetime = -2
scale = .5,.5
sprpriority = 2
ownpal = 1

[State 0, TargetBind]
type = TargetBind
trigger1= anim = 3202
trigger1 = AnimElem = 1
pos = 36, 0

[State 0, TargetBind]
type = TargetBind
trigger1= anim = 3202
trigger1 = AnimElem = 2
pos = 26, 0

[State 0, TargetBind]
type = TargetBind
trigger1= anim = 3202
trigger1 = AnimElem = 3
pos = 33, -14

[State 0, VelSet]
type = VelSet
trigger1= anim = 3202
trigger1 = animelem = 3 && time < 50
y = -13.5
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1= anim = 3202
trigger1 = screenpos Y <= 98
y = 0

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 1

[State 0, Helper]
type = Helper
trigger1 = 1
helpertype = player
name = "Screen Pan up"
ID = 3263
stateno = 3263
pos = 0,0
postype = p1
persistent = 0

[State 0, ChangeAnim]
type = ChangeAnim
trigger1= anim = 3202
trigger1 = screenpos Y <= 98
value = 1101
persistent = 0

[State 0, VelSet]
type = VelSet
trigger1 = anim = 1101
x = -3.9
y = -7.5

[State 0, VelSet]
type = VelSet
trigger1 = anim = 1101
trigger1 = animelem = 6
x = 0
y = 0

[State 0, Helper]
type = Helper
trigger1 = anim = 1101
helpertype = normal
name = "Ragnarok Clone 1"
stateno = 3264
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = anim = 1101
helpertype = normal
name = "Ragnarok Clone 2"
stateno = 3265
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = anim = 1101
helpertype = normal
name = "Ragnarok Clone 3"
stateno = 3266
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = enemynear,stateno != 3211
value = 0
ctrl = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = anim = 1101
trigger1 = animelem = 6
value = 3203

;-------------------------------
;Set 1
;-------------------------------
[Statedef 3203]
type = A
physics = n
anim = 3220
velset = 10.4,-2.35
ctrl = 0
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3203
value = SCA,AA,AP
ignorehitpause=1

[State 0, VarAdd]
type = VarAdd
trigger1 = time = 1
v = 45
value = 1
persistent = 0

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosSet]
type = PosSet
trigger1 = time = 0
x = ifelse(facing = 1,(target(3211),pos X) -271,(target(3211),pos X) +271)
y = (target(3211),pos y) +51

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .491
y = -.025

[State 0, ScreenBound]
type = ScreenBound
trigger1 = time >= 0
value = 0

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3240
ID = 3240
pos = -5,-75
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, Helper]
type = Helper
trigger1 = var(45) < 3
trigger1 = time = 0
helpertype = normal
id = 3203
name = "Ragnarok Clone 1"
stateno = 3221
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(45) < 3
trigger1 = time = 0
helpertype = normal
id = 3203
name = "Ragnarok Clone 2"
stateno = 3222
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(45) < 3
trigger1 = time = 0
helpertype = normal
id = 3203
name = "Ragnarok Clone 3"
stateno = 3223
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, VarAdd]
type = VarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, ChangeState]
type = ChangeState
trigger1 = var(45) < 3
trigger1 = time > 37
value = 3204

[State 0, ChangeState]
type = ChangeState
trigger1 = var(45) = 3
trigger1 = time > 35
value = 3206
;-------------------------------
;Clone 1 attacking
;-------------------------------
[Statedef 3221]
type = A
physics = n
anim = 3221
velset = 4.4,-5.35
ctrl = 0
sprpriority = 2
facep2 = 1

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3221
value = SCA,AA,AP
ignorehitpause=1

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3241
ID = 3241
pos = -30,-68
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosSet]
type = PosSet
trigger1 = time = 0
x = ifelse(facing = 1,(root,pos x) +134,(root,pos x) -134)

[State 0, PosSet]
type = PosSet
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
y = 50

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .291
y = -.225

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 37

;-------------------------------
;Clone 2 attacking
;-------------------------------
[Statedef 3222]
type = A
physics = n
anim = 3222
velset = -2.4,-7.35
ctrl = 0
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3222
value = SCA,AA,AP
ignorehitpause=1

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3242
ID = 3242
pos = -28,-68
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosSet]
type = PosSet
trigger1 = time = 0
x = ifelse(facing = 1,(root,pos x) -317,(root,pos x) +317)

[State 0, PosSet]
type = PosSet
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
y = 50

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .21
y = -.425

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y > -35
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y > -35
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y > -35
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y > -35
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 37

;-------------------------------
;Clone 3 attacking
;-------------------------------
[Statedef 3223]
type = A
physics = n
anim = 3225
velset = 1.4,7.35
ctrl = 0
sprpriority = 2
facep2 = 1

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3203
value = SCA,AA,AP
ignorehitpause=1

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3242
ID = 3242
pos = 13,-68
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = -1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosSet]
type = PosSet
trigger1 = time = 0
x = ifelse(facing = 1,(root,pos x) +217,(root,pos x) -217)

[State 0, PosSet]
type = PosSet
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
y = -250

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .22
y = .425

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 37

;------------------------------------------
;Set 2
;------------------------------------------
[Statedef 3204]
type = A
physics = n
anim = 3220
velset = 10.4,-2.35
ctrl = 0
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3204
value = SCA,AA,AP
ignorehitpause=1

[State 0, VarAdd]
type = VarAdd
trigger1 = time = 1
v = 45
value = 1
persistent = 0

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosAdd]
type = PosAdd
trigger1 = time = 0
x = (p2dist x) + -310

[State 0, PosSet]
type = PosSet
trigger1 = time = 0
y = -65

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .491
y = -.025

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0

[State 0, VarAdd]
type = VarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3240
ID = 3240
pos = -5,-75
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, Helper]
type = Helper
trigger1 = var(45) < 3
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 1"
stateno = 3231
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(45) < 3
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 2"
stateno = 3232
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(45) < 3
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 3"
stateno = 3233
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = var(45) < 3
trigger1 = time > 37
value = 3205

[State 0, ChangeState]
type = ChangeState
trigger1 = var(45) = 3
trigger1 = time > 35
value = 3206
;-------------------------------
;Clone 1 attacking
;-------------------------------
[Statedef 3231]
type = A
physics = n
anim = 3220
velset = -10.4,-2.35
ctrl = 0
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3231
value = SCA,AA,AP
ignorehitpause=1

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3240
ID = 3240
pos = -5,-75
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosAdd]
type = PosAdd
trigger1 = time = 0
x = (p2dist x) + -310

[State 0, PosSet]
type = PosSet
trigger1 = time = 0
y = -65

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .491
y = -.025

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 37

;-------------------------------
;Clone 2 attacking
;-------------------------------
[Statedef 3232]
type = A
physics = n
anim = 3222
velset = 1.4,-7.35
ctrl = 0
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3232
value = SCA,AA,AP
ignorehitpause=1

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 4086
ID = 4085
pos = -28,-68
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosAdd]
type = PosAdd
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
x = (p2dist X) + -15

[State 0, PosSet]
type = PosSet
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
y = 50

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .21
y = -.425

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y > -35
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y > -35
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y > -35
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y > -35
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 37

;-------------------------------
;Clone 3 attacking
;-------------------------------
[Statedef 3233]
type = A
physics = n
anim = 3225
velset = 1.4,7.35
ctrl = 0
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3233
value = SCA,AA,AP
ignorehitpause=1

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3242
ID = 3242
pos = 13,-68
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = -1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosAdd]
type = PosAdd
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
x = (p2dist X) + -15

[State 0, PosSet]
type = PosSet
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
y = -250

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .02
y = .425

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < -10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < -10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 37

;------------------------------------------
;Set 3
;------------------------------------------
[Statedef 3205]
type = A
physics = n
anim = 3220
velset = -10.4,-2.35
ctrl = 0
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3205
value = SCA,AA,AP
ignorehitpause=1

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, VarAdd]
type = VarAdd
trigger1 = time = 1
v = 45
value = 1
persistent = 0

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosAdd]
type = PosAdd
trigger1 = time = 0
x = (p2dist x) + -310

[State 0, PosSet]
type = PosSet
trigger1 = time = 0
y = -65

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .491
y = -.025

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0

[State 0, VarAdd]
type = VarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3240
ID = 3240
pos = -5,-75
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, Helper]
type = Helper
trigger1 = var(45) < 3
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 1"
stateno = 3241
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(45) < 3
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 2"
stateno = 3242
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = var(45) < 3
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 3"
stateno = 3243
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = var(45) < 3
trigger1 = time > 37
value = 3203

[State 0, ChangeState]
type = ChangeState
trigger1 = var(45) = 3
trigger1 = time > 35
value = 3206
;-------------------------------
;Clone 1 attacking
;-------------------------------
[Statedef 3241]
type = A
physics = n
anim = 3220
velset = -10.4,-2.35
ctrl = 0
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3241
value = SCA,AA,AP
ignorehitpause=1

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3240
ID = 3240
pos = -5,-75
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = 1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosAdd]
type = PosAdd
trigger1 = time = 0
x = (p2dist x) + -310

[State 0, PosSet]
type = PosSet
trigger1 = time = 0
y = -65

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .491
y = -.025

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 37

;-------------------------------
;Clone 2 attacking
;-------------------------------
[Statedef 3242]
type = A
physics = n
anim = 3224
velset = -6.4,7.35
ctrl = 0
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3242
value = SCA,AA,AP
ignorehitpause=1

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3241
ID = 3241
pos = 3,-68
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = -1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosAdd]
type = PosAdd
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
x = (p2dist X) + -185

[State 0, PosSet]
type = PosSet
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
y = -250

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .352
y = .125

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 37

;-------------------------------
;Clone 3 attacking
;-------------------------------
[Statedef 3243]
type = A
physics = n
anim = 3225
velset = 1.4,6.35
ctrl = 0
facep2 = 1
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3243
value = SCA,AA,AP
ignorehitpause=1

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 3242
ID = 3242
pos = 13,-68
postype = p1  ;p2,front,back,left,right
facing = 1
vfacing = -1
bindtime = 35
removetime = -2
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow

[State 0, PosAdd]
type = PosAdd
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
x = (p2dist X) + -15

[State 0, PosSet]
type = PosSet
trigger1 = enemynear,stateno = 3211
trigger1 = time = 0
y = -250

[State 0, VelAdd]
type = VelAdd
trigger1 = time > 0
x = .102
y = .325

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,8
volume = 255
channel = 1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 20
helperType = Normal
stateNo = 8017
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time > 37

;-------------------------------------------
;Finish!
;-------------------------------------------
[Statedef 3206]
type = A
physics = N
anim = 6666
velset = 0,0

[State 0, VarSet]
type = VarSet
trigger1 = time = 0
v = 45    ;fv = 10
value = 0

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3206
value = SCA,AA,AP
ignorehitpause=1

[State 0, ScreenBound]
type = ScreenBound
trigger1 = 1
value = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 1"
stateno = 3251
id = 3251
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 2"
stateno = 3252
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 3"
stateno = 3253
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, Helper]
type = Helper
trigger1 = time = 0
helpertype = normal
name = "Ragnarok Clone 4"
stateno = 3254
pos = 0,0
postype = p1
ownpal = 1
persistent = 0

[State 0, ChangeState]
type = ChangeState
trigger1 = enemynear,stateno = 3212 && enemynear,anim = 3213
value = 3214

;---------------------------------
;Finisher Clone 1
;---------------------------------
[Statedef 3251]
type = A
anim = 3230
physics = N
ctrl = 0
velset = 8.5,4.5
facep2 = 1
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3251
value = SCA,AA,AP
ignorehitpause=1

[State 0, VelAdd]
type = VelAdd
trigger1 = 1
x = .33
y = .25

[State 0, PosAdd]
type = PosAdd
trigger1 = time = 0
x = (p2dist x) + -165
y = (p2dist y) + -115

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 44
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 44
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 44
value = S2,5
volume = 255
channel = -1
persistent = 0

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 6020
ID = 6020
pos = -40,0
postype = p1  ;p2,front,back,left,right
facing = 1
bindtime = -1
removetime = 13
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 44
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 10
helperType = Normal
stateNo = 8014
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;---------------------------------
;Finisher Clone 2
;---------------------------------
[Statedef 3252]
type = A
anim = 3231
physics = N
ctrl = 0
velset = 1.5,5.5
facep2 = 1
sprpriority = 0

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3252
value = SCA,AA,AP
ignorehitpause=1

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 9203
ID = 9203
pos = -38,-7
postype = p1  ;p2,front,back,left,right
facing = 1
bindtime = -1
removetime = 13
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = 1
x = .23
y = .25

[State 0, PosAdd]
type = PosAdd
trigger1 = time = 0
x = (p2dist x) + -50
y = (p2dist y) + -130

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 46
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 46
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 46
value = S2,5
volume = 255
channel = -1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 46
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 10
helperType = Normal
stateNo = 8014
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;---------------------------------
;Finisher Clone 3
;---------------------------------
[Statedef 3253]
type = A
anim = 3230
physics = N
ctrl = 0
velset = 6.5,4.5
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3253
value = SCA,AA,AP
ignorehitpause=1

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 6020
ID = 6020
pos = -40,-7
postype = p1  ;p2,front,back,left,right
facing = 1
bindtime = -1
removetime = 13
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = 1
x = .33
y = .25

[State 0, PosAdd]
type = PosAdd
trigger1 = time = 0
x = (p2dist x) + -145
y = (p2dist y) + -115

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 46
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 48
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 48
value = S2,5
volume = 255
channel = -1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 48
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 10
helperType = Normal
stateNo = 8014
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;---------------------------------
;Finisher Clone 4
;---------------------------------
[Statedef 3254]
type = A
anim = 3231
physics = N
ctrl = 0
velset = 1.5,5.5
sprpriority = 2

[State 3000, NotHitby]
type = NotHitBy
trigger1 = stateno = 3254
value = SCA,AA,AP
ignorehitpause=1

[State 0, Explod]
type = Explod
trigger1 = time = 0
anim = 9203
ID = 9203
pos = -38,-7
postype = p1  ;p2,front,back,left,right
facing = 1
bindtime = -1
removetime = 13
scale = .5,.5
sprpriority = 3
ownpal = 1

[State 0, VelAdd]
type = VelAdd
trigger1 = 1
x = .23
y = .25

[State 0, PosAdd]
type = PosAdd
trigger1 = time = 0
x = (p2dist x) + -50
y = (p2dist y) + -130

[State 0, ParentVarAdd]
type = ParentVarAdd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
var(13) = 1
persistent = 0

[State 0, HitAdd]
type = HitAdd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 1
persistent = 0

[State 0, PlaySnd]
type = PlaySnd
trigger1 = enemynear,stateno = 3211
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S2,5
volume = 255
channel = -1
persistent = 0

[State 0, EnvColor]
type = EnvColor
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = 255,255,255
time = 1
under = 0
persistent = 0

[State 871, Hit Spark]
type = Helper
trigger1 = time = 10
helperType = Normal
stateNo = 8014
ID = 8000
name = "Spark"
postype = p2  ;p2,front,back,left,right
facing = 1
pos = ceil(-10 * const(size.xScale)), ceil(-55 * const(size.yScale))
ownPal = 1
pauseMoveTime = 65535
superMoveTime = 65535
ignoreHitPause = 1

[State 0, PlaySnd]
type = PlaySnd
trigger1 = p2bodydist x < 10 && p2bodydist Y < 50
value = S3200,2
volume = 255
channel = -1
persistent = 0

[State 0, DestroySelf]
type = DestroySelf
trigger1 = !animtime

;---------------------------------
;Screen Pan for Ragnarok
;---------------------------------
[Statedef 3263]
type = S
anim = 6666

[State 0, PosSet]
type = PosSet
trigger1 = time = 0
y = -50

[State 0, PosAdd]
type = VelAdd
triggerall = root,screenpos Y <= 98
trigger1 = root,pos y < 0
y = -.42

[State 0, DestroySelf]
type = DestroySelf
trigger1 = time >= 55

;------------------------------------
;Clone 1
;------------------------------------
[Statedef 3264];teleport out
type = A
movetype = I
physics = N
anim = 1103
ctrl = 0
sprpriority = 3

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = -8.9
y = -2.1

[State 0, VelAdd]
type = VelAdd
trigger1 = time = 0
y = -2.93

[State 0, VelSet]
type = VelSet
trigger1 = animelem = 6
x = 0
y = 0

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,stateno = [3203,3205]

;------------------------------------
;Clone2
;------------------------------------
[Statedef 3265];teleport out
type = A
movetype = I
physics = N
anim = 1101
ctrl = 0
sprpriority = 3

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, VelSet]
type = VelSet
trigger1 = time = 1
x = -3.9
y = -7.5

[State 0, VelAdd]
type = VelAdd
trigger1 = time = 0
x = 2.3
y = -2.93

[State 0, VelSet]
type = VelSet
trigger1 = animelem = 6
x = 0
y = 0

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,stateno = [3203,3205]

;------------------------------------
;Clone3
;------------------------------------
[Statedef 3266];teleport out
type = A
movetype = I
physics = N
anim = 1103
ctrl = 0
sprpriority = 3

[State 0, Turn]
type = Turn
trigger1 = time = 0

[State 0, VelSet]
type = VelSet
trigger1 = time = 0
x = -8.9
y = -2.1

[State 0, VelAdd]
type = VelAdd
trigger1 = time = 0
x = 2.3
y = -2.93

[State 0, VelSet]
type = VelSet
trigger1 = animelem = 6
x = 0
y = 0

[State 0, DestroySelf]
type = DestroySelf
trigger1 = root,stateno = [3203,3205]

