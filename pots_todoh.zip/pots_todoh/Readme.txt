                            __________________________________________
===========================| Todoh by varo_hades		      |===========================
                            ������������������������������������������        [8.20.17] - Varo_Hades
                                                                              [12.2.19] - BahamianKing
 - Contact:varo_hades@hotmail.com
 - Website:https://varohades.wixsite.com/varohadesmugen
 - Customized version of Snk's Todoh character, for MUGEN 1.0

=====<Features>=====

 - All the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, including CvS2, KOF and AOF
 - Special intros versus Maki, Ryo, Robert, Yuri, Takuma, Mr.Karate, Geese And Mr.Big

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p - two punches       2k - two kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

<NORMAL>

.Low Kick				F + b
.Throw 1:	         		F/B + 2p		(near opponent)
.Throw 2:				F/B + 2k		(near opponent)

<SPECIAL>

.Kasane Ate (EX) (Air)			D, DF, F, p
.Taikuu (EX)				F, D, DF, p
.Stunning Grab (EX)			D, DB, B, p

<SUPER>

.Chou Kasane Ate (MAX):			D, DF, F, D, DF, F, p

<Lv3 SUPER>

.Shingan Kuzu Otoshi:                	D, DF, F, D, DB, B, 2p

<SYSTEM>

.Forward Dash:                  	F, F
.Run:                        	        hold
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	a + x
.Sidestep Attack:            	        p / k
.Forward Roll:                  	F + a + x
.Backward Roll:                 	B + a + x
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold b + y 
.Zero Counter:                  	B, DB, D, p / k 	(during standing or crouching guard)
.Special Move Zero Counter:             F + b + y 	        (during standing or crouching guard)
.Custom Combo:                  	c + z           	(Air also)
.Fall Recovery:                 	a + x      	        (while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

=====<Version History>=====

<12/2/19>
 - Added Pals from Realra

<11/28/19>
 - Added envshake on hit of throw 1
 - Fix counter sound on ShinganKuzu Otoshi 
 - Fix reversed sounds on level1 and 2 supers
 - Fix echo sounds on normal hits
 - Increase damage a bit on special and super moves
 - Added level 3 port by RagingRowen
 - Added intro vs Kasumi

<11/14/19>
 - Projectiles effects colored and fixed by trololo
 - Projectiles recoded by trololo
 - Misc tweaks.

<20/08/17>
 - First release

=====<Special Thanks>=====
 - warusaki3 for sprites, anims, code
 - P.o.t.S. for code, effects, hitsparks, formatting style
 - Jadeeye and Varo_Hades for hyper fonts, hyper portrait
 - Quickfist for color separation and some palettes
 - Everybody at the MUGEN Fighters Guild for feedback
 - The MUGEN Fighters Guild for providing hosting
 - Special thanks to varo for commissioning this char for me! 

=====<Disclaimer>=====

 - Todoh character is property of Snk
 - Capcom vs SNK is property of Capcom
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes
