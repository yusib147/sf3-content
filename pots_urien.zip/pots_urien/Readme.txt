                            __________________________________________
===========================|  Urien By Froz, edited by RagingRowen    |===========================
                            ������������������������������������������        [25th Dec 2021]
 - Customized version of Capcom's Urien character, for MUGEN 1.0+

=====<Features>=====

 - Most of the essential stuff
 - Details and moves taken from his various video game appearances
 - Gameplay mixed from several games, including CvS2, KOF, SFA3 and SFIII

=====<Movelist>=====

 U - up          x - light punch        a - light kick
 D - down        y - medium punch       b - medium kick
 F - forward     z - heavy punch        c - heavy kick
 B - back        p - any punch          k - any kick
 s - start       2p- two punches        2k- two kicks

 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.


<NORMAL>

.Quarrel Punch  			F + y
.Terrible Smash 			F + z
.Quarrel Kick				F + b
.L.Punch to M.Punch Combo       	x > y
.Quarrel Punch to T.Smash Combo       	F + y > F + z


<SPECIAL>
.Metallic Sphere  (EX): 		D, DF, F, p
.Chariot Tackle  (EX):  	        (charge) B, F, k
.Violence Knee Drop  (EX):		(charge) D, U, k 
.Dangerous Headbutt  (EX):		(charge) D, U, p 

<SUPER>

.Temporal Thunder (MAX):		D, DF, F, D, DF, F, p
.Tyrant Slaughter  (MAX):		D, DF, F, D, DF, F, k
.Aegis Reflector:			D, DB, B, D, DB, B, p (Anti-Ground) / k (Anti-Air)

<Lv3 SUPER>

.Dominant Crush:			D, D, D, 2p


<SYSTEM>

.Forward Dash:                  	F, F
   .Run:                        	hold
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	a + x
   .Sidestep Attack:            	p / k
.Forward Roll:                  	F + a + x
.Backward Roll:                 	B + a + x
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold b + y
.Zero Counter:                  	B, DB, D, p / k 	(during standing or crouching guard)
.Custom Combo:                  	c + z           	(Air also)
.Fall Recovery:                 	2p / a + x      	(while falling and allowed)


=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Some Normal attacks can be canceled into Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage

CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start


=====<Miscellaneous>=====

- To change his size to SF3 scale, open the .def file and replace "Constants.cns" with "ConstantsSF3.cns".

=====<Version History>=====

<RagingRowen's Edit>
 (31st Dec 2021)
 - Multi-Color Hitsparks added.
 - Medium Punch damage increased.
 - Aegis Reflector recovery (after releasing projectile) decreased.
 (25th Dec 2021)
 - Changed or added a few Victory Quotes from SFV.
 - Move Priority changed to only 4 to match other PotS chars.
 - Stand HP now super-cancellable.
 - Special-to-Special Cancels removed.
 - EX Metallic Sphere tweaked (e.g. now tracks P2 just before the projectile and juggle limit increased).
 - (EX) Chariot Tackle cancel window made shorter.
 - Chariot Tackle button distance changed, startup frames increased and damage increased.
 - EX Chariot Tackle damage decreased but is now cancellable.
 - EX Dangerous Headbutt has Electric FX for the headbutt to go along with the FX on Hit.
 - Aegis Reflector heavily adjusted to behave closer to SF3.
 - Aegis Reflector timer resetting when hitting fixed.
 - MAX Aegis Reflector (Anti-Air) now a separate Level 1.
 - Vesuvian Burnout changed to Dominant Crush.
 - Midnight Bliss anim set to 9021 (CFJ) since it lacks the sprites for 9020.
 To Do:
 - Multi-Color Hitsparks.
 - Revise Hitboxes and Frame Data.
 - Improve Dominant Crush Sprite Conversion.
 - Attending to Feedback.

<11/12/14>
 -Aegis Reflector deflects projectiles in the same direction.
 -Aegis Reflector deflects opponents in the same direction.
 -Chariot Tackle => Metallic Sphere chain has been removed.
 -Added CFJ stance, SF3 Shock, Custom MB and CFJ Royal Judgement sprites.
 -EX Metallic Sphere doesn't gain power.

<10/16/12>
 -EX Dangerous Headbutt Can now hit twice
 -MAX LVL Aegis Reflector Updated.(Hovers at slow speed, Does more hits and damage)
 -AI has been added
 -Chariot Tackle is a lot safer.
 -Axis has been fixed
 -EX Moves no longer recieve power.
 -EX Metallic Sphere doesn't bounce off when hit on the head.

<10/09/12>
 -EX Dangerous Headbutt does more damage.
 -Violence Knee Drop does more damage. 
 -Vesuvian Burnout has been tuned up. (Juggle and Damage-wise)
 -Metallic Sphere has its angle lowered.
 -Dangerous Headbutt now gives 2 Hits (All the time) and does more damage than it's average versions.
 -Super Cancels has been fixed/Tuned.
 -Quarrel Punch to Terrible Smash Combo has been added.
 -Terrible Smash no longer gives 2 hits.
 -Dash has been tuned.
 -Chariot Tackle gives more Hitstun and less Recovery.

<10/07/12>
 -Finally got the juggling system to work. (Thank you, "Killer Kong?".)
 -Updated the Config for EX Violence Knee Drop. 
 -Cancels have been added/tuned.
 -Temporal Thunder has been fixed and Button detect (Speed now varies by pressing x, y, or z) has been added for LVL1.
 -Destroy Claw Grapple has been fixed.
 -EX Metallic Sphere has been fixed.
 -Fake Punch Winpose has been tuned for more accuracy.
 
<10/05/12>
 -Metallic Sphere does more damage when charged and the FX has been added to notify the charge progress.
 -Config added for EX Violence Knee Drop. 
 -Tuned his "Spartan Bomb" Grapple.
 -Constants tuned. (According to DW's feedback)
 -Cancels have been added/tuned.
 -Temporal Thunder has been fixed.
 -Mashing Buttons at "Destroy Claw" Grapple has been fixed.
 -Charge Particle axis has been fixed.
 -EX Dangerous Headbutt no longer does +2 hits if opponent blocks.


<10/03/12>
 - First release

=====<Special Thanks>=====
 - www.zweifuss.ca/ for the sprites
 - P.o.t.S. for the code, effects, hitsparks, formatting style
 - JMorphMan, and DivineWolf for the inspiration to make this character, 
   not to mention the codes that helped me get past a few problems :P
 - RajaaBoy for helping me out with the Aegis Reflector code
 - Cyanide and Jesuszilla for helping me fix bugs/problems
 - aokmaniac13 for the XIII sprite rips (K's Flame Pillar)
 - 2OS for His Open Source FX
 - 6O8 for His Open Source FX
 - Fido/lifido9999 for his Temporal Thunder and Aegis Reflector FX (Not to mention a few custom sprites, like his run)
 - Goodaldo, Girard, Karasai, and Hyogo/Craptain lolicon/Bomberman for the palettes
 - Buckus for tips and feedback
 - Killer Kong, For feedback and giving a huge help with a few bugs
 - Knuckles8864, for feedback 
 - C.A.N for Feedback and Suggestions
 - Everybody at the MUGEN Fighters Guild for feedback
 - JadeEye, for the AI
 - To Anyone else who i have forgotten

RagingRowen:
 - KarmaCharmeleon for support and help with the Reflector Timer.
 - Loganir & Verz36 for FX.
 - 2OS for Reflector Shatter FX.
 - PeXXeR and more for support.

=====<Disclaimer>=====

 - The Urien character is property of Capcom
 - Capcom vs SNK is property of Capcom
 - Street Fighter 3 is property of Capcom 
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes