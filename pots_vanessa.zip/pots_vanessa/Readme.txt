                             	
	Vanessa by 2Dee4Ever/ReixSeiryu, edited by RagingRowen
___________________________________________________________

Customized version of SNK PLAYMORE's Vanessa character, for MUGEN 1.0

=====<Movelist>=====

 U - up          LP - light punch        LK - light kick
 D - down        MP - medium punch       MK - medium kick
 F - forward     HP - heavy punch        HK - heavy kick
 B - back        P - any punch           K - any kick
 s - start       2P- two punches         2K- two kicks
 
 (Air) - Move must be performed in the air.
 (EX)  - Move has an EX version, performed by pressing two punch/kick buttons.
 (MAX) - Use two punch/kick buttons when performing a Super move to power it up.

-IF YOU DON'T WANT CHAIN COMBOS GO TO THE CONFIG AND CHANGE THE VALUE UNDER VAR 55
TO 0 AND SAVE.Turning off the chain combos will give the character more of a 
cvs-ish type damage for normal attacks. 

<NORMAL>

.One-Two Puncher				F + MP
.Blowback Kicker				F + HK
.Dynamite Puncher		         	F/B + 2P		(near opponent)
.Clinch Puncher					F/B + 2K		(near opponent)

<SPECIAL>
		
.Machine Gun Puncher (EX)			B,DB,D,DF,F+P
.Forbidden Eagle (EX)				F,D,DF+P
.Dash Puncher (EX)				(Charge)B,F+P
.Puncher Weaving (EX)				D,DB,B+P (Hold)
     .Dash Puncher                                    F+P
     .Parrying Puncher                                B+P
     .Forward Puncher Vision                          F+K
     .Backward Puncher Vision                         B+K
.Forward Puncher Vision (EX)			D,DF,F+K
.Backward Puncher Vision (EX)			D,DB,B+K
     (Followups below apply to both Puncher Visions)
     .Upper                                           F+x/y
     .Straight                                        F+z
     .Puncher Weaving                                 B+P

<SUPERS>

.Champion Puncher (MAX)				D,DF,F,D,DF,F+P
     .Puncher Finish					D,DF,F,D,DF,F+P
.Crazy Puncher (MAX)			        D,DB,B,D,DF,F+P
     .Puncher Finish					D,DF,F,D,DF,F+P     

<Lv3 SUPER>

.Gaia Gear					F,B,DB,D,DF,F+2P
.Infinity Puncher                               D,DB,B,D,DF,F+2K

<SYSTEM>

.Run:          		        	F, F
.Backward Dash:                 	B, B
.Low Jump:                      	tap U
.High Jump:                     	tap D, U
.Long Low Jump:                 	tap D, tap U            
.Sidestep:                      	LP + LK
   .Sidestep Attack:            	p / k
.Forward Roll:                  	F + LP + LK
.Backward Roll:                 	B + LP + LK
.Parry High:                    	tap F
.Parry Low:                     	tap D
.Air Parry:                     	tap F           	(Air)
.Power Charge:                  	hold MP + MK
.Zero Counter:                  	B, DB, D, P / K 	(during standing or crouching guard)
.Custom Combo:                  	HP + HK          	(Air also)
.Fall Recovery:                 	2P / 2K  	    	(while falling and allowed)

=====<Gameplay Notes>=====

COMBO SYSTEM:
 - Normal Attacks are able to chain into other normal attacks.
 - Normal attacks can be canceled into Command, Special and Super moves
 - Some Special moves can be canceled into Super moves
 - Some Lv1 Super moves can be canceled into MAX Super moves
 - Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
   but also reduces its damage


CUSTOM COMBO:
 - Removes cancellable attack restrictions and gives you a lot of freedom to combo them
 - Juggle limit is lifted
 - You can only use EX Special or Super moves from the point the character starts flashing faster
   and brighter, and doing so ends Custom Combo
 - Gives you a short invulnerability window at the start

=====<RagingRowen's Update>=====

2022 Version:

20th October:
- Added Vans' Chizuru Sealing Compatibility.
29th September:
- Crouch HP has less recovery.
- Fixed Crouching Normals not Special-Cancelling.
- Fixed Non-Overhead One-Two Puncher going to the Non-Chain version.
- Removed Full Invulnerability from Puncher Vision.
- Gaia Gear gains its extended animation when the 1st hit connects.
28th September:
- Light Normals are now mashable.
- One-Two Puncher is no longer an overhead when chained into.
- Sidestep given a hurtbox.
- Rolls have more limited invulnerability.
27th September:
- Multi-Colored Hitsparks changed to smaller ones.
- Chain Combos removed.
- Various Frame Data changes.
- More Damage Adjustments, mainly to match the CvS2 standard where damage is always a multiple of 7.
- Damage Dampener changed to that of Jmorphman's chars.
- Removed Special Intro Dialogue.
- Removed Envshake from Normals.
- Removed Extra Juggling from Air Normals.
- Several changes to her normal animations.
- One-Two Puncher added.
- Blowback Kicker (her CD in KOF) added.
- Special Cancels revised, with stricter, more CvS-like, cancel windows.
- Specials no longer have increased juggle limits.
- Machine Gun Puncher's command now has priority over Dash Puncher's.
- Machine Gun Puncher revised, with animation speed differences, more consistent hits, the HP variant losing a hit, and more forward movement at the start.
- Dash Puncher startup frames and distance altered.
- Dash Puncher (Weaving variants included) and EX Parrying Puncher juggle reset.
- MP Forbidden Eagle given a more unique animation.
- Champion Puncher hitbox height lowered.
- Puncher Finish damage increased.
- Puncher Finish can now be done from MAX Crazy Puncher.
- Puncher Finish has a unique dampener for when done from MAX Supers.
- Level 3 Commands changed.
- Infinity Puncher's startup attack has slightly more range.

To Do:
- A New Small Port?
- Better Dampening for Puncher Finish(es)
- Maybe revise juggle conditions, likely reserving them for EX's
- Attend to Feedback

2020 Version:
- New Sprites provided by Dampir.
- 9000,1 (Big) Port redone.
- Hitsparks and Damage Dampener updated.
- Various Damage Changes.
- Backward Dash velocity increased.
- Machine Gun Puncher command changed.
- Machine Gun Puncher retweaked.
- EX Dash Puncher launches straight up like the EX Puncher Weaving variant.
- EX Puncher Weaving > Dash Puncher recovery heavily decreased, allowing for juggles.
- Puncher Weaving from EX Puncher Vision (or vice versa) is the EX Variant but without the power cost.
- Added (or changed the) Juggle Limit to Specials that lacked it.
- Added missing Wall Bounce sounds.
- Cheap KO anim fixed.
- More misc tweaks I don't feel like bringing up.

2019 Version:
- New Default Palette.
- New 9000,1 Port.
- add004 content removed.
- Improved AI, can now do Specials and Supers.
- Edited KO Voice to have CVS2-esque echo.
- Changed misplaced sounds.
- Changed Dodge animation.
- Slightly shorter Rolls.
- New Level 3 (Infinity Puncher from KOF XIV) from another version of this char, now complete with Super Finish text.
- Machine Gun Puncher (EX included) nerfed.
- Puncher Weaving can no longer be followed up with EX Puncher Visions.
- EX Puncher Vision being cancelled from any move fixed.
- LVL1 Crazy Puncher nerfed.
- Champion Puncher Finish followup nerfed.
- Gaia Gear adjusted, and fixed some hits not coming out in the corner.
- Other misc. Tweaks and Fixes. 

THANKS TO -

SNK-For creating the original character.

Elecbyte-For Making the MUGEN engine.

Virtualtek-For creating Fighter Factory.

Infinite - References.

2Dee4Ever - The Original Character

walt - (Original) Small Port

swit - For providing a link to this Character in a zip file alongside others.

gui0007 - For providing another version which I took Infinity Puncher from.

KOFHERO77 - For removing the add004 stuff.

Dampir - The Edited Sprites.

Jmorphman & KarmaCharmeleon - Code and Value References.

senorfro and various others - Feedback.

=====<Disclaimer>=====

 - Vanessa is property of SNK
 - KOF is property of SNK
 - This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes