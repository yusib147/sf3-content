; _________________________________________
;| Iron Man by varo_hades                  |
; �����������������������������������������
;==============================================================================================
;========================================<SUPER STATES>========================================
;==============================================================================================

;========================<PROTON CANNON>=============================
[StateDef 3000]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3000, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000, 2999]) && var(7)) || var(20)

[State 3000, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3000, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3000, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3000, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3000, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3000, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3000, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3000, SuperPause FX]
type = Helper
trigger1 = AnimElem = 18
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(95 * const(size.xScale)), ceil(-94 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3000, SuperPause]
type = SuperPause
trigger1 = AnimElem = 18
time = 45
moveTime = 45
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3000, 1.1]
type = PlaySnd
trigger1 = AnimElem = 16
value = 3000, 0
channel = 0

[State 3000, 3.4]
type = Explod
trigger1 = AnimElem = 19
anim = 4086
id = 4086
postype = P1
pos = 95, 0
sprpriority = 5
ownpal = 1
bindtime = -1
scale = .8333,1

[State 3000, 5.1]
type = Helper
trigger1 = AnimElem = 2
name = "Proton Cannon"
id = 3010
postype = P1
pos = 33, -104
stateno = 3010
helpertype = normal
keyctrl = 0
ownpal = 1
persistent = 0
size.xscale = .8333
size.yscale = 1

[State 3000, 5.2]
type = Helper
trigger1 = AnimElem = 19
name = "Beam"
id = 3015
postype = P1
pos = 70, 0
stateno = 3015
helpertype = normal
keyctrl = 0
ownpal = 1
persistent = 0
size.xscale = .8333
size.yscale = 1

[State 3000, 6]
type = HitDef
trigger1 = Time = 0
attr = S, HA
hitflag = MAF
animtype = Hard
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 7
guardflag = MA
pausetime = 0,0
priority = 7, Hit
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -82
ground.type = High
ground.slidetime = 12
ground.hittime  = 15
ground.velocity = -6,-6
guard.velocity = -6
air.velocity = -1,-5
air.hittime = 12
fall = 1
fall.recover = 0
getpower = 0
kill = 0
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3000, 8]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<MAX PROTON CANNON>=============================
[StateDef 3050]
type = S
physics = S
moveType = A
anim = 3000
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3050, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3050, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3050, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3050, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3050, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3050, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3050, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3050, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3050, SuperPause FX]
type = Helper
trigger1 = AnimElem = 18
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(95 * const(size.xScale)), ceil(-94 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3050, SuperPause]
type = SuperPause
trigger1 = AnimElem = 18
time = 45
moveTime = 45
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3050, 1.1]
type = PlaySnd
trigger1 = AnimElem = 16
value = 3000, 1
channel = 0

[State 3050, 3.4]
type = Explod
trigger1 = AnimElem = 19
anim = 4086
id = 4087
postype = P1
pos = 95, 0
sprpriority = 5
ownpal = 1
bindtime = -1
scale = .8333,1

[State 3050, 5.1]
type = Helper
trigger1 = AnimElem = 2
name = "Proton Cannon"
id = 3010
postype = P1
pos = 33, -104
stateno = 3060
helpertype = normal
keyctrl = 0
ownpal = 1
persistent = 0
size.xscale = .8333
size.yscale = 1

[State 3050, 5.2]
type = Helper
trigger1 = AnimElem = 19
name = "Beam"
id = 3015
postype = P1
pos = 70, 0
stateno = 3065
helpertype = normal
keyctrl = 0
ownpal = 1
persistent = 0
size.xscale = .8333
size.yscale = 1

[State 3050, 6]
type = HitDef
trigger1 = Time = 0
attr = S, HA
hitflag = MAF
animtype = Hard
damage = ceil(ifElse(fvar(11) * 20 < 7, 7, fvar(11) * 20)), 7
guardflag = MA
pausetime = 0,0
priority = 7, Hit
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -82
ground.type = High
ground.slidetime = 12
ground.hittime  = 15
ground.velocity = -6,-6
guard.velocity = -6
air.velocity = -1,-5
air.hittime = 12
fall = 1
fall.recover = 0
getpower = 0
kill = 0
envShake.time = 18
envShake.ampl = 6
envShake.freq = 120

[State 3050, 8]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;========================<SUPER ARMOR>=============================
[StateDef 3100]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -1000
faceP2 = 1

[State 3100, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3100, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3100, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3100, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3100, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3100, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3100, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3100, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
time = 1
value = SCA

[State 3100, Super Pause FX]
type = Helper
trigger1 = Time = 4
helperType = Normal
stateNo = 8500
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-81 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3100, SuperPause]
type = SuperPause
trigger1 = Time = 4
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3100, 2] ;Voice
type = PlaySnd
trigger1 = Time = 10
value = 195,0
channel = 0

[State 3100, 4] ;Time left in air
type = VarSet
trigger1 = Time = 0
v = 45
value = 300

[State 3100, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 3101

;Pharaoh Split - Rise
[Statedef 3101]
type = A
movetype = A
physics = N
velset = 0,-1
anim = 3101
sprpriority = 1

[State 3101, 10.1]
type = Explod
triggerall = animelem = 1
trigger1 = Anim = 3101
anim = 4000
id = 3101
postype = P1
pos = -13, -10
sprpriority = 0
ownpal = 1
removetime = 16
bindtime = -1
scale = .8333,1

[State 3101, 10.2]
type = Explod
triggerall = animelem = 1
trigger1 = Anim = 3101
anim = 4000
id = 3101
postype = P1
pos = 0, -10
sprpriority = 0
ownpal = 1
removetime = 16
bindtime = -1
scale = .8333,1

[State 3101, 1]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3101, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 3102

;Pharaoh Split - Transform
[Statedef 3102]
type = A
movetype = A
physics = N
velset = 0,0
anim = 3101
sprpriority = 1

[State 3102, 2]
type = RemoveExplod
trigger1 = 1
ID = 3101

[State 3102, 10.1]
type = Explod
triggerall = animelem = 1
trigger1 = Anim = 3101
anim = 4000
id = 3102
postype = P1
pos = -13, -10
sprpriority = 0
ownpal = 1
removetime = 16
bindtime = -1
scale = .8333,1

[State 3102, 10.2]
type = Explod
triggerall = animelem = 1
trigger1 = Anim = 3101
anim = 4000
id = 3102
postype = P1
pos = 0, -10
sprpriority = 0
ownpal = 1
removetime = 16
bindtime = -1
scale = .8333,1

[State 3102, 1] ;Set jump type to Pharaoh Split
type = VarSet
trigger1 = Time = 0
v = 1
value = 5

[State 3102, 2]
type = PosAdd
trigger1 = AnimTime = 0
y = -25

[State 3102, 3]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3102, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 3103

;Pharaoh Split - Float
[Statedef 3103]
type = A
physics = N
anim = 3101
velset = 0,0
ctrl = 0
sprpriority = 0

[State 3103, 2]
type = RemoveExplod
trigger1 = 1
ID = 3102

[State 3103, 10.1]
type = Explod
triggerall = animelem = 1
trigger1 = Anim = 3101
anim = 4000
id = 3103
postype = P1
pos = -13, -10
sprpriority = 0
ownpal = 1
removetime = 9999
bindtime = -1
scale = .8333,1

[State 3103, 10.2]
type = Explod
triggerall = animelem = 1
trigger1 = Anim = 3101
anim = 4000
id = 3103
postype = P1
pos = 0, -10
sprpriority = 0
ownpal = 1
removetime = 9999
bindtime = -1
scale = .8333,1

[State 3103, 2]
type = PosAdd
trigger1 = command = "holdfwd"
x = 3

[State 3103, 3]
type = PosAdd
trigger1 = command = "holdback"
x = -3

[State 3103, 4]
type = PosAdd
trigger1 = command = "holdup"
trigger1 = Pos Y >= -85 ;-88 is boundary
y = -3

[State 3103, 5]
type = PosAdd
trigger1 = command = "holddown"
trigger1 = Pos Y <= -3 ;0 is boundary
y = 3

[State 3103, 7]
type = Turn
trigger1 = P2Dist X < 0

[State 3103, 8] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3103, 9]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3130

[State 3103, 9]
type = ChangeState
trigger1 = Var(45) <= 0
value = 3107

;Pharaoh Split - Light Kick
[Statedef 3104]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
movehitpersist = 1
sprpriority = 3

[State 3104, 2]
type = RemoveExplod
trigger1 = 1
ID = 3103

[State 3104, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 630
value = 630

[State 3104, 2]
type = PlaySnd
trigger1 = Time = 1
value = 1, 3

[State 3104, 3]
type = HitDef
trigger1 = Time = 0
trigger1 = MoveContact = 0
attr = A, HA
damage    = 20
hitflag = MA
guardflag = HA
priority = 3
pausetime = 11,11
hitSound = -1 + 0 * (var(31) := 3)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -20
ground.type = High
ground.slidetime = 9
ground.hittime  = 9
ground.velocity = -4
air.velocity = -1,-2
getPower = 0
givePower = 36, 36

[State 3104, 4]
type = ChangeAnim
trigger1 = HitPauseTime = 9
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 630
elem = 4

[State 3104, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 3103
ctrl = 1

[State 3104, 3] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3104, 4]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3130

;Pharaoh Split - Medium Kick
[Statedef 3105]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
movehitpersist = 1
sprpriority = 3

[State 3105, 2]
type = RemoveExplod
trigger1 = 1
ID = 3103

[State 3105, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 640
value = 640

[State 3105, 2]
type = PlaySnd
trigger1 = Time = 2
value = 1, 4

[State 3105, 3]
type = HitDef
trigger1 = Time = 0
trigger1 = MoveContact = 0
attr = A, HA
damage = 45
hitflag = MA
guardflag = HA
priority = 4
pausetime = 11,11
hitSound = -1 + 0 * (var(31) := 4)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -17
animtype = Med
ground.type = High
ground.slidetime = 9
ground.hittime  = 9
ground.velocity = -7
air.velocity = -2,-2
getPower = 0
givePower = 36, 36

[State 3105, 4]
type = ChangeAnim
trigger1 = HitPauseTime = 9
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 640
elem = 4

[State 3105, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 3103
ctrl = 1

[State 3105, 3] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3105, 4]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3130

;Pharaoh Split - Strong Kick
[Statedef 3106]
type = A
movetype = A
physics = N
ctrl = 0
velset = 0,0
movehitpersist = 1
sprpriority = 3

[State 3106, 2]
type = RemoveExplod
trigger1 = 1
ID = 3103

[State 3106, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 650
value = 650

[State 3106, 2]
type = PlaySnd
trigger1 = Time = 2
value = 1, 5

[State 3106, 3]
type = HitDef
trigger1 = animelem = 4
attr = A, HA
damage = 75
hitflag = MA
guardflag = HA
priority = 4
pausetime = 11,11
hitSound = -1 + 0 * (var(31) := 5)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -7
animtype = Med
ground.type = High
ground.slidetime = 10
ground.hittime  = 10
ground.velocity = -8
air.velocity = -5,8
getPower = 0
givePower = 36, 36

[State 3106, 4]
type = ChangeAnim
trigger1 = HitPauseTime = 10
trigger1 = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 650
elem = 5

[State 3106, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 3103
ctrl = 1

[State 3106, 3] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3106, 4]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3130

;Pharaoh Split - End
[Statedef 3107]
type = A
movetype = I
physics = N
ctrl = 0
velset = 0,3
sprpriority = 2

[State 3107, 1]
type = ChangeAnim
trigger1 = Anim != 3101
value = 3101

[State 3107, 3]
type = ChangeState
trigger1 = Pos Y >= 0
value = 52 ;JUMPLAND

;Pharaoh Split - HitOverride
[Statedef 3130]
type = A
movetype = H
physics = N
velset = 0,0
movehitpersist = 1
sprpriority = 0

[State 3130, Armor bashing sounds]
type = PlaySnd
trigger1 = Time = 0
value = 8,0
channel = 8
ignorehitpause = 1
persistent = 0

[State 3130, Armor bashing sounds]
type = PlaySnd
trigger1 = Time = 0
value = 8,0
channel = 9
ignorehitpause = 1
persistent = 0

[State 3130, 1]
type = LifeAdd
trigger1 = Time = 0
value = -GetHitVar(damage)
ignorehitpause = 1

[State 3130, 2]
type = ChangeState
trigger1 = Life = 0
value = 5020
ignorehitpause = 1

[State 3130, 3]
type = NotHitBy
trigger1 = 1
value = SCA

[State 3130, 4]
type = PalFx
trigger1 = Time = 0
time = 2
add = 256,0,0
mul = 256,0,0

[State 3130, 5]
type = ChangeState
trigger1 = Time = 0
value = Var(57) ;PrevStateNo

;Pharaoh Split - Light Punch
[Statedef 3131]
type = A
movetype = A
juggle = 2
ctrl = 0
movehitpersist = 1
sprpriority = 2
powerAdd = 0

[State 3131, 2]
type = RemoveExplod
trigger1 = 1
ID = 3103

[State 3131, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 600
value = 600

[State 3131, 2]
type = PlaySnd
trigger1 = Time = 1
value = 1, 0

[State 3131, 3]
type = HitDef
trigger1 = Time = 0
trigger1 = MoveContact = 0
attr = A, HA
damage    = 20
hitflag = MA
guardflag = HA
priority = 3
pausetime = 11,11
hitSound = -1 + 0 * (var(31) := 0)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -62
ground.type = High
ground.slidetime = 9
ground.hittime  = 9
ground.velocity = -5
air.velocity = -2,-2
getPower = 0
givePower = 36, 36

[State 3131, 4]
type = ChangeAnim
trigger1 = HitPauseTime = 9
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 600
elem = 4

[State 3131, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 3103

[State 3131, 6] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3131, 7]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3130

;Pharaoh Split - Medium Punch
[Statedef 3132]
type = A
movetype = A
juggle  = 4
ctrl = 0
movehitpersist = 1
sprpriority = 2
powerAdd = 0

[State 3132, 2]
type = RemoveExplod
trigger1 = 1
ID = 3103

[State 3132, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 610
value = 610

[State 3132, 2]
type = PlaySnd
trigger1 = Time = 2
value = 1, 1

[State 3132, 3]
type = HitDef
trigger1 = Time = 0
trigger1 = MoveContact = 0
attr = A, HA
damage = 45
hitflag = MA
guardflag = HA
priority = 4
pausetime = 11,11
hitSound = -1 + 0 * (var(31) := 1)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -62
animtype = Med
ground.type = High
ground.slidetime = 9
ground.hittime  = 9
ground.velocity = -5
air.velocity = -2,-2
getPower = 0
givePower = 36, 36

[State 3132, 4]
type = ChangeAnim
trigger1 = HitPauseTime = 9
trigger1 = AnimElemTime(3) >= 0 && AnimElemTime(4) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 610
elem = 4

[State 3132, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 3103

[State 3132, 6] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3132, 7]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3130

;Pharaoh Split - Strong Punch
[Statedef 3133]
type = A
movetype = A
juggle = 4
ctrl = 0
movehitpersist = 1
sprpriority = 2
powerAdd = 0

[State 3133, 2]
type = RemoveExplod
trigger1 = 1
ID = 3103

[State 3133, 1]
type = ChangeAnim
trigger1 = Time = 0
trigger1 = Anim != 620
value = 620

[State 3133, 2]
type = PlaySnd
trigger1 = Time = 2
value = 1, 2

[State 3133, 4]
type = Explod
trigger1 = AnimElem = 2
anim = 4040
id = 3133
postype = P1
pos = 0, 0
ontop = 1
ownpal = 1
bindtime = -1
scale = .8333,1

[State 3133, 3]
type = HitDef
trigger1 = Time = 0
trigger1 = MoveContact = 0
attr = A, HA
damage = 75
hitflag = MA
guardflag = HA
priority = 4
pausetime = 11,11
hitSound = -1 + 0 * (var(31) := 2)
guardSound = -1 + 0 * (var(32) := 0)
sparkNo = -1 + 0 * (var(33) := 8014)
guard.sparkNo = -1 + 0*(var(34) := 8001)
sparkXY = -10 + 0 * (var(35) := 157), var(36) := -80
animtype = Med
ground.type = High
ground.slidetime = 10
ground.hittime  = 10
ground.velocity = -9
air.velocity = -5,-8
getPower = 0
givePower = 36, 36

[State 3133, 4]
type = ChangeAnim
trigger1 = HitPauseTime = 10
trigger1 = AnimElemTime(4) >= 0 && AnimElemTime(5) < 0
trigger1 = MoveContact
ignorehitpause = 1
persistent = 0
value = 620
elem = 5

[State 3133, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 3103

[State 3133, 6] ;Super Armor PrevStateNo
type = VarSet
trigger1 = Time = 0
v = 57
value = StateNo

[State 3133, 7]
type = HitOverride
trigger1 = 1
attr = SCA, AA, AP, AT
stateno = 3130

;========================<MAX SUPER ARMOR>=============================
[StateDef 3150]
type = S
physics = S
moveType = A
anim = 3100
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -2000
faceP2 = 1

[State 3150, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3150, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3150, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3150, Corner Push]
type = VarSet
trigger1 = Time = 3
fvar(5) = 0

[State 3150, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3150, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3150, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3150, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(2) < 0
time = 1
value = SCA

[State 3150, Super Pause FX]
type = Helper
trigger1 = Time = 4
helperType = Normal
stateNo = 8510
ID = 8500
name = "Superpause FX"
posType = P1
pos = ceil(5 * const(size.xScale)), ceil(-81 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownPal = 1

[State 3150, SuperPause]
type = SuperPause
trigger1 = Time = 4
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3150, 2] ;Voice
type = PlaySnd
trigger1 = Time = 10
value = 195,0
channel = 0

[State 3150, 4] ;Time left in air
type = VarSet
trigger1 = Time = 0
v = 45
value = 500

[State 3150, 10]
type = ChangeState
trigger1 = AnimTime = 0
value = 3101

;========================<IRON AVENGER>=============================
[StateDef 3200]
type = S
physics = S
moveType = A
anim = 3200
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = -3000
faceP2 = 1

[State 3200, Super Cancel Flag]
type = VarSet
trigger1 = !Time
var(21) = ((PrevStateNo = [1000,2999]) && var(7)) || var(20)

[State 3200, Hyper Cancel Flag]
type = VarSet
trigger1 = !Time
var(22) = (PrevStateNo = [3000,4999]) && var(8)

[State 3200, Custom Combo Reset]
type = PalFX
trigger1 = !Time
trigger1 = !(var(20) := 0)
time = 1

[State 3200, Corner Push]
type = VarSet
trigger1 = 1
fvar(5) = 0

[State 3200, Unguardable]
type = VarSet
trigger1 = Time = 3 && NumEnemy
trigger1 = (EnemyNear, StateNo != [120,155])
var(17) = 43

[State 3200, Super Cancel Flash]
type = PalFX
trigger1 = var(21) || var(22)
trigger1 = !(Time % 2) && Time <= 12
time = 1
add = 255,255,255
ignoreHitPause = 1

[State 3200, Super Cancel Juggle]
type = VarSet
trigger1 = !Time
trigger1 = var(21) || var(22)
var(15) = 0
ignoreHitPause = 1

[State 3200, NotHitBy]
type = NotHitBy
trigger1 = AnimElemTime(5) < 0
time = 1
value = SCA

[State 3200, Super Pause FX]
type = Helper
trigger1 = Animelem = 1
helperType = Normal
stateNo = 8520
ID = 8500
name = "Superpause FX"
posType = p1
pos = ceil(8 * const(size.xScale)), ceil(-64 * const(size.yScale))
superMoveTime = 255
size.xScale = 1
size.yScale = 1
ownpal = 1

[State 3200, Super Pause]
type = SuperPause
trigger1 = Animelem = 1
time = 38
moveTime = 38
p2DefMul = 1
unHittable = 1
anim = -1
sound = s8500,0
darken = 0

[State 3200, 1.1]
type = PlaySnd
trigger1 = Time = 0
value = 181, 0
channel = 0

[State 3200, VelSet]
type = VelSet
trigger1 = Animelem = 2
x = 30
Persistent = 1

[State 3200, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype = H
trigger1 = Time = 0
attr = S, HT
hitflag = M+
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3201
p2stateno = 3205
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3201
down.bounce = 0

[State 3200, HitDef]
type = HitDef
trigger1 = !var(16) && var(15) < 1
trigger1 = EnemyNear,movetype != H
trigger1 = Time = 0
attr = S, HT
hitflag = M-
priority = 1, Miss
sparkNo = -1 + 0 * (var(33) := 0)
sparkxy = -1
p1sprpriority = 1
p2sprpriority = 0
p1facing = 1
p2facing = 1
p1stateno = 3201
p2stateno = 3205
guard.dist = 0
hitSound = -1 + 0 * (var(31) := 800)
fall = 1
fall.recover = 0
id = 3201
down.bounce = 0

[State 3201, ChangeState]
type = ChangeState
Trigger1 = !AnimTime
value = 0
ctrl = 1

;Dash Throw - Throwing
[Statedef 3201]
type = S
movetype = I
physics = S
juggle = 5
poweradd = 0
ctrl = 0
anim = 3210
sprpriority = 2
velset = 0,0

[State 3201, 6]
type = TargetBind
trigger1 = Time = 0
time = 1000
pos = 20, 0

[State 3201, 7]
type = VelSet
trigger1 = Time = 0
x = 10

[State 3201, 7]
type = VelSet
trigger1 = Time = 10
trigger2 = Time = 20
trigger3 = Time = 30
trigger4 = Time = 40
trigger5 = Time = 50
trigger6 = Time = 60
trigger7 = Time = 70
trigger8 = Time = 80
trigger9 = Time = 90
trigger10 = Time = 100
trigger11 = Time = 110
trigger12 = Time = 120
trigger13 = Time = 130
trigger14 = Time = 140
trigger15 = Time = 150
trigger16 = Time = 160
trigger17 = Time = 170
trigger18 = Time = 180
trigger19 = Time = 190
trigger20 = Time = 200
x = 10

[State 3201, 7]
type = VelSet
trigger1 = Time = 210
trigger2 = Time = 220
trigger3 = Time = 230
trigger4 = Time = 240
trigger5 = Time = 250
trigger6 = Time = 260
trigger7 = Time = 270
trigger8 = Time = 280
trigger9 = Time = 290
trigger10 = Time = 300
trigger11 = Time = 310
trigger12 = Time = 320
trigger13 = Time = 330
trigger14 = Time = 340
trigger15 = Time = 350
trigger16 = Time = 360
trigger17 = Time = 370
trigger18 = Time = 380
trigger19 = Time = 390
trigger20 = Time = 400
x = 10

[State 3201, 7]
type = VelSet
trigger1 = Time = 410
trigger2 = Time = 420
trigger3 = Time = 430
trigger4 = Time = 440
trigger5 = Time = 450
trigger6 = Time = 460
trigger7 = Time = 470
trigger8 = Time = 480
trigger9 = Time = 490
trigger10 = Time = 500
trigger11 = Time = 510
trigger12 = Time = 520
trigger13 = Time = 530
trigger14 = Time = 540
trigger15 = Time = 550
trigger16 = Time = 560
trigger17 = Time = 570
trigger18 = Time = 580
trigger19 = Time = 590
trigger20 = Time = 600
x = 10

[State 3201, 7]
type = VelSet
trigger1 = Time = 610
trigger2 = Time = 620
trigger3 = Time = 630
trigger4 = Time = 640
trigger5 = Time = 650
trigger6 = Time = 660
trigger7 = Time = 670
trigger8 = Time = 680
trigger9 = Time = 690
trigger10 = Time = 700
trigger11 = Time = 710
trigger12 = Time = 720
trigger13 = Time = 730
trigger14 = Time = 740
trigger15 = Time = 750
trigger16 = Time = 760
trigger17 = Time = 770
trigger18 = Time = 780
trigger19 = Time = 790
trigger20 = Time = 800
x = 10

[State 3201, 7]
type = VelSet
trigger1 = Time = 810
trigger2 = Time = 820
trigger3 = Time = 830
trigger4 = Time = 840
trigger5 = Time = 850
trigger6 = Time = 860
trigger7 = Time = 870
trigger8 = Time = 880
trigger9 = Time = 890
trigger10 = Time = 900
trigger11 = Time = 910
trigger12 = Time = 920
trigger13 = Time = 930
trigger14 = Time = 940
trigger15 = Time = 950
trigger16 = Time = 960
trigger17 = Time = 970
trigger18 = Time = 980
trigger19 = Time = 990
trigger20 = Time = 1000
x = 10

[State 3201, 9]
type = ScreenBound
trigger1 = Time = 0
value = 0
movecamera = -60

[State 3201, 10]
type = Explod
trigger1 = NumExplod(911) = 0
trigger1 = Time = 10
trigger2 = Time = 20
trigger3 = Time = 30
trigger4 = Time = 40
trigger5 = Time = 50
trigger6 = Time = 60
trigger7 = Time = 70
trigger8 = Time = 80
trigger9 = Time = 90
trigger10 = Time = 100
anim = 4002
id = 911
postype = P1
pos = -68, -6
sprpriority = 0
ownpal = 1
scale = .8333,1

[State 3201, 11]
type = Explod
trigger1 = NumExplod(912) = 0
trigger1 = Time = 10
trigger2 = Time = 20
trigger3 = Time = 30
trigger4 = Time = 40
trigger5 = Time = 50
trigger6 = Time = 60
trigger7 = Time = 70
trigger8 = Time = 80
trigger9 = Time = 90
trigger10 = Time = 100
anim = 4002
id = 912
postype = P1
pos = -16, -15
sprpriority = 0
ownpal = 1
scale = .8333,1

[State 3201, 10]
type = Explod
trigger1 = NumExplod(913) = 0
trigger1 = Time = 10
trigger2 = Time = 20
trigger3 = Time = 30
trigger4 = Time = 40
trigger5 = Time = 50
trigger6 = Time = 60
trigger7 = Time = 70
trigger8 = Time = 80
trigger9 = Time = 90
trigger10 = Time = 100
anim = 3250
id = 913
postype = P1
pos = 0, 0
sprpriority = 10
removetime = 100
ownpal = 1
scale = 1,1

[State 3201, 13.1]
type = PlaySnd
trigger1 = AnimElem = 1
value = 4, 4
channel = 0

[State 3201, 13.2]
type = PlaySnd
trigger1 = Time = 10
trigger2 = Time = 20
trigger3 = Time = 30
trigger4 = Time = 40
trigger5 = Time = 50
trigger6 = Time = 60
trigger7 = Time = 70
trigger8 = Time = 80
trigger9 = Time = 90
trigger10 = Time = 100
value = 41, 1
channel = 3
persistent = 1

[State 3201, 13.2]
type = PlaySnd
trigger1 = Time = 10
trigger2 = Time = 20
trigger3 = Time = 30
trigger4 = Time = 40
trigger5 = Time = 50
trigger6 = Time = 60
trigger7 = Time = 70
trigger8 = Time = 80
trigger9 = Time = 90
trigger10 = Time = 100
value = 101, 0
channel = 2
persistent = 1

[State 3201, 14]
type = ChangeState
;trigger1 = Facing = -1
;trigger1 = ScreenPos X < 46
;trigger2 = Facing = 1
;trigger2 = ScreenPos X > 274
trigger1 = Time = 100
value = 3202
ctrl = 0

;========================<DASH BACKWARDS>==========================
[StateDef 3202]
type = A
physics = N
moveType = I
velSet = 0,0
anim = 3220
ctrl = 0
sprPriority = 1

[State 52, 2]
type = RemoveExplod
trigger1 = 1
ID = 911

[State 52, 3]
type = RemoveExplod
trigger1 = 1
ID = 912

[State 3202, 4]
type = TargetDrop
trigger1 = Time = 0

[State 3202, Back Dash Sound]
type = PlaySnd
trigger1 = AnimElem = 2
value = 105,1

[State 3202, Dust Helper]
type = Helper
trigger1 = AnimElem = 2
helperType = Normal
stateNo = 8103
ID = 8100
name = "Dash Dust"
posType = P1
facing = -1
pauseMoveTime = 255
superMoveTime = 255
ownPal = 1

[State 3202, 4]
type = Explod
trigger1 = AnimElem = 1
anim = 4004
id = 105
postype = P1
pos = -3, -72
ontop = 1
ownpal = 1
removetime = 21
bindtime = -1
scale = .8333,1

[State 3202, 5]
type = Explod
trigger1 = AnimElem = 1
anim = 4004
id = 106
postype = P1
pos = 23, -68
sprpriority = 0
ownpal = 1
removetime = 21
bindtime = -1
scale = .8333,1

[State 3202, VelSet]
type = VelSet
trigger1 = AnimElem = 2
x = -6

[State 3202, End]
type = ChangeState
trigger1 = AnimTime = 0
value = 3203

;========================<UNIBEAM>=============================
[StateDef 3203]
type = S
physics = S
moveType = I
anim = 3230
ctrl = 0
velSet = 0,0
sprPriority = 1
powerAdd = 0
faceP2 = 1

[State 3401, AngleDraw]
type = EnvShake
trigger1 = animelem = 1
time = 60
phase = 90
ampl = Ifelse(random<500,-4,4)
ignorehitpause = 1

[State 3203, 1]
type = PlaySnd
trigger1 = AnimElem = 1
value = 1000, 1
channel = 0

[State 3203, 2]
type = Explod
trigger1 = AnimElem = 2
anim = 4060
id = 1000
postype = P1
pos = -2, 2
sprpriority = 4
ownpal = 1
removetime = 29

[State 3203, 3]
type = Explod
trigger1 = AnimElem = 7, 2
anim = 4061
id = 1001
postype = P1
pos = -2, 2
sprpriority = 6
ownpal = 1
removetime = 18

[State 3203, 4]
type = Explod
trigger1 = AnimElem = 2
trigger2 = AnimElem = 11, 2
anim = 4062
id = 1002
postype = P1
pos = 10, -73
sprpriority = 5
ownpal = 1
removetime = 29
accel = 0.675, 0.45

[State 3203, 5]
type = Explod
trigger1 = AnimElem = 2
trigger2 = AnimElem = 11, 2
anim = 4063
id = 1003
postype = P1
pos = 0, -73
sprpriority = 5
ownpal = 1
removetime = 29
accel = -1.4, 0.675

[State 3203, 6]
type = Explod
trigger1 = AnimElem = 2
trigger2 = AnimElem = 11, 2
anim = 4064
id = 1004
postype = P1
pos = 4, -81
sprpriority = 5
ownpal = 1
removetime = 29
accel = -0.14625, -0.675

[State 3203, 7.1]
type = Helper
trigger1 = AnimElem = 7, 2
name = "Unibeam Attacker"
id = 3210
postype = P1
pos = 4, -76
stateno = 3210
helpertype = normal
keyctrl = 0
ownpal = 1

[State 3203, Width]
type = Width
trigger1 = AnimElemTime(5) = 0
value = 30,0

[State 3203, End]
type = ChangeState
trigger1 = !AnimTime
value = 0
ctrl = 1

; Reverse Dash Throw - P2(1)
[Statedef 3205]
type = S
movetype = H
physics = N
ctrl = 0
velset = 0,0

[State 3205, 1]
type = ChangeAnim2
trigger1 = Time = 0
value = 825

[State 3205, 2]
type = ScreenBound
trigger1 = 1
value = 0

[State 3205, 7]
type = ChangeState
;trigger1 = Facing = 1
;trigger1 = ScreenPos X < 20
;trigger2 = Facing = -1
;trigger2 = ScreenPos X > 300
trigger1 = Time = 100
value = 3206

;Repulsor Throw - P2
[Statedef 3206]
type = S
movetype = H
physics = N
ctrl = 0
sprpriority = -1

[State 3205, 1]
type = ChangeAnim2
trigger1 = Time = 0
value = 3205

[State 3206, 2]
type = VelSet
trigger1 = Time = 0
x = 0
y = 0

[State 3206, 7]
type = SelfState
trigger1 = Time = 150
value = 5050
