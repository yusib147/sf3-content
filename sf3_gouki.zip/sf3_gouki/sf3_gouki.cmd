;����AI�R�}���h��������������������������������������������������������������������
[Command]
name = "AI_1"
command = D, D, D, D, D, D, D, D, D, D, D, D, D, D, D
time = 1

[Command]
name = "AI_2"
command = F, F, F, F, F, F, F, F, F, F, F, F, F, F, F
time = 1

[Command]
name = "AI_3"
command = U, U, U, U, U, U, U, U, U, U, U, U, U, U, U
time = 1

[Command]
name = "AI_4"
command = B, B, B, B, B, B, B, B, B, B, B, B, B, B, B
time = 1
 
[Command]
name = "AI_5"
command = a, a, a, a, a, a, a, a, a, a, a, a, a, a, a
time = 1

[Command]
name = "AI_6"
command = b, b, b, b, b, b, b, b, b, b, b, b, b, b, b
time = 1

[Command]
name = "AI_7"
command = c, c, c, c, c, c, c, c, c, c, c, c, c, c, c
time = 1

[Command]
name = "AI_8"
command = x, x, x, x, x, x, x, x, x, x, x, x, x, x, x
time = 1

[Command]
name = "AI_9"
command = y, y, y, y, y, y, y, y, y, y, y, y, y, y, y
time = 1

[Command]
name = "AI_10"
command = z, z, z, z, z, z, z, z, z, z, z, z, z, z, z
time = 1

[Command]
name = "AI_11"
command = s, s, s, s, s, s, s, s, s, s, s, s, s, s, s
time = 1

[Command]
name = "AI_12"
command = F, F, F, F, F, F, F, F, F, F, F, F, F, F, a
time = 1

[Command]
name = "AI_13"
command = U, U, U, U, U, U, U, U, U, U, U, U, U, U, a
time = 1

[Command]
name = "AI_14"
command = B, B, B, B, B, B, B, B, B, B, B, B, B, B, a
time = 1
 
[Command]
name = "AI_15"
command = a, a, a, a, a, a, a, a, a, a, a, a, a, a, b
time = 1

[Command]
name = "AI_16"
command = b, b, b, b, b, b, b, b, b, b, b, b, b, b, a
time = 1

[Command]
name = "AI_17"
command = c, c, c, c, c, c, c, c, c, c, c, c, c, c, a
time = 1

[Command]
name = "AI_18"
command = x, x, x, x, x, x, x, x, x, x, x, x, x, x, a
time = 1

[Command]
name = "AI_19"
command = y, y, y, y, y, y, y, y, y, y, y, y, y, y, a
time = 1

[Command]
name = "AI_20"
command = z, z, z, z, z, z, z, z, z, z, z, z, z, z, a
time = 1

[Command]
name = "AI_21"
command = s, s, s, s, s, s, s, s, s, s, s, s, s, s, a
time = 1

[Command]
name = "AI_22"
command = F, F, F, F, F, F, F, F, F, F, F, F, F, F, b
time = 1

[Command]
name = "AI_23"
command = U, U, U, U, U, U, U, U, U, U, U, U, U, U, b
time = 1

[Command]
name = "AI_24"
command = B, B, B, B, B, B, B, B, B, B, B, B, B, B, b
time = 1
 
[Command]
name = "AI_25"
command = a, a, a, a, a, a, a, a, a, a, a, a, a, a, c
time = 1

[Command]
name = "AI_26"
command = b, b, b, b, b, b, b, b, b, b, b, b, b, b, c
time = 1

[Command]
name = "AI_27"
command = c, c, c, c, c, c, c, c, c, c, c, c, c, c, b
time = 1

[Command]
name = "AI_28"
command = x, x, x, x, x, x, x, x, x, x, x, x, x, x, b
time = 1

[Command]
name = "AI_29"
command = y, y, y, y, y, y, y, y, y, y, y, y, y, y, b
time = 1

[Command]
name = "AI_30"
command = z, z, z, z, z, z, z, z, z, z, z, z, z, z, b
time = 1

[Command]
name = "AI_31"
command = s, s, s, s, s, s, s, s, s, s, s, s, s, s, b
time = 1

[Command]
name = "AI_32"
command = F, F, F, F, F, F, F, F, F, F, F, F, F, F, c
time = 1

[Command]
name = "AI_33"
command = U, U, U, U, U, U, U, U, U, U, U, U, U, U, c
time = 1

[Command]
name = "AI_34"
command = B, B, B, B, B, B, B, B, B, B, B, B, B, B, c
time = 1
 
[Command]
name = "AI_35"
command = a, a, a, a, a, a, a, a, a, a, a, a, a, a, x
time = 1

[Command]
name = "AI_36"
command = b, b, b, b, b, b, b, b, b, b, b, b, b, b, x
time = 1

[Command]
name = "AI_37"
command = c, c, c, c, c, c, c, c, c, c, c, c, c, c, x
time = 1

[Command]
name = "AI_38"
command = x, x, x, x, x, x, x, x, x, x, x, x, x, x, c
time = 1

[Command]
name = "AI_39"
command = y, y, y, y, y, y, y, y, y, y, y, y, y, y, c
time = 1

[Command]
name = "AI_40"
command = z, z, z, z, z, z, z, z, z, z, z, z, z, z, c
time = 1

[Command]
name = "AI_41"
command = s, s, s, s, s, s, s, s, s, s, s, s, s, s, c
time = 1

[Command]
name = "AI_42"
command = F, F, F, F, F, F, F, F, F, F, F, F, F, F, x
time = 1

[Command]
name = "AI_43"
command = U, U, U, U, U, U, U, U, U, U, U, U, U, U, x
time = 1

[Command]
name = "AI_44"
command = B, B, B, B, B, B, B, B, B, B, B, B, B, B, x
time = 1
 
[Command]
name = "AI_45"
command = a, a, a, a, a, a, a, a, a, a, a, a, a, a, x
time = 1

[Command]
name = "AI_46"
command = b, b, b, b, b, b, b, b, b, b, b, b, b, b, x
time = 1

[Command]
name = "AI_47"
command = c, c, c, c, c, c, c, c, c, c, c, c, c, c, x
time = 1

[Command]
name = "AI_48"
command = x, x, x, x, x, x, x, x, x, x, x, x, x, x, y
time = 1

[Command]
name = "AI_49"
command = y, y, y, y, y, y, y, y, y, y, y, y, y, y, x
time = 1

[Command]
name = "AI_50"
command = z, z, z, z, z, z, z, z, z, z, z, z, z, z, x
time = 1


;�����X�[�p�[�A�[�c����������������������������������������������������������������

[Command]
name = "�u���E"
command = ~x, x, F, a, z
time = 30

[Command]
name = "�u���E"
command = ~x, x, F, a, ~z
time = 30

[Command]
name = "��������a"
command = ~D, D, D, x+y+z
time = 24

[Command]
name = "��������a"
command = ~D, D, D, x+y
time = 24

[Command]
name = "��������a"
command = ~D, D, D, y+z
time = 24

[Command]
name = "��������a"
command = ~D, D, D, x+z
time = 24

[Command]
name = "�ŎE���g��"
command = ~D, DF, F, D, DF, x
time = 24

[Command]
name = "�ŎE���g��"
command = ~D, DF, F, D, DF, ~x
time = 24

[Command]
name = "�ŎE���g��"
command = ~D, DF, F, D, DF, y
time = 24

[Command]
name = "�ŎE���g��"
command = ~D, DF, F, D, DF, ~y
time = 24

[Command]
name = "�ŎE���g��"
command = ~D, DF, F, D, DF, z
time = 24

[Command]
name = "�ŎE���g��"
command = ~D, DF, F, D, DF, ~z
time = 24

[Command]
name = "�ŎE������"
command = ~D, DF, F, D, DF, a
time = 24

[Command]
name = "�ŎE������"
command = ~D, DF, F, D, DF, ~a
time = 24

[Command]
name = "�ŎE������"
command = ~D, DF, F, D, DF, b
time = 24

[Command]
name = "�ŎE������"
command = ~D, DF, F, D, DF, ~b
time = 24

[Command]
name = "�ŎE������"
command = ~D, DF, F, D, DF, c
time = 24

[Command]
name = "�ŎE������"
command = ~D, DF, F, D, DF, ~c
time = 24

[Command]
name = "�ŎE������"
command = ~D, DB, B, D, DB, a
time = 24

[Command]
name = "�ŎE������"
command = ~D, DB, B, D, DB, ~a
time = 24

[Command]
name = "�ŎE������"
command = ~D, DB, B, D, DB, b
time = 24

[Command]
name = "�ŎE������"
command = ~D, DB, B, D, DB, ~b
time = 24

[Command]
name = "�ŎE������"
command = ~D, DB, B, D, DB, c
time = 24

[Command]
name = "�ŎE������"
command = ~D, DB, B, D, DB, ~c
time = 24

;�����K�E�Z������������������������������������������������������������������������
[Command]
name = "���g����_x"
command = ~D, DF, F, x
time = 12

[Command]
name = "���g����_y"
command = ~D, DF, F, y
time = 12

[Command]
name = "���g����_z"
command = ~D, DF, F, z
time = 12

[Command]
name = "���g����_x"
command = ~D, DF, F, ~x
time = 12

[Command]
name = "���g����_y"
command = ~D, DF, F, ~y
time = 12

[Command]
name = "���g����_z"
command = ~D, DF, F, ~z
time = 12

[Command]
name = "�ܔM�g����_x"
command = ~F, DF, D, DB, B, x
time = 18

[Command]
name = "�ܔM�g����_y"
command = ~F, DF, D, DB, B, y
time = 18

[Command]
name = "�ܔM�g����_z"
command = ~F, DF, D, DB, B, z
time = 18

[Command]
name = "�ܔM�g����_x"
command = ~F, DF, D, DB, B, ~x
time = 18

[Command]
name = "�ܔM�g����_y"
command = ~F, DF, D, DB, B, ~y
time = 18

[Command]
name = "�ܔM�g����_z"
command = ~F, DF, D, DB, B, ~z
time = 18

[Command]
name = "��������_x"
command = ~F, D, DF, x
time = 15

[Command]
name = "��������_y"
command = ~F, D, DF, y
time = 15

[Command]
name = "��������_z"
command = ~F, D, DF, z
time = 15

[Command]
name = "��������_x"
command = ~F, D, DF, ~x
time = 15

[Command]
name = "��������_y"
command = ~F, D, DF, ~y
time = 15

[Command]
name = "��������_z"
command = ~F, D, DF, ~z
time = 15

[Command]
name = "�S�S�P_a"
command = ~F, D, DF, a
time = 15

[Command]
name = "�S�S�P_b"
command = ~F, D, DF, b
time = 15

[Command]
name = "�S�S�P_c"
command = ~F, D, DF, c
time = 15

[Command]
name = "�S�S�P_a"
command = ~F, D, DF, ~a
time = 15

[Command]
name = "�S�S�P_b"
command = ~F, D, DF, ~b
time = 15

[Command]
name = "�S�S�P_c"
command = ~F, D, DF, ~c
time = 15

[Command]
name = "�����a��r_a"
command = ~D, DB, B, a
time = 12

[Command]
name = "�����a��r_b"
command = ~D, DB, B, b
time = 12

[Command]
name = "�����a��r_c"
command = ~D, DB, B, c
time = 12

[Command]
name = "�����a��r_a"
command = ~D, DB, B, ~a
time = 12

[Command]
name = "�����a��r_b"
command = ~D, DB, B, ~b
time = 12

[Command]
name = "�����a��r_c"
command = ~D, DB, B, ~c
time = 12

[Command]
name = "���C���M��1"
command = ~F, D, DF, x+y
time = 15

[Command]
name = "���C���M��1"
command = ~F, D, DF, y+z
time = 15

[Command]
name = "���C���M��1"
command = ~F, D, DF, z+x
time = 15

[Command]
name = "���C���M��2"
command = ~F, D, DF, a+b
time = 15

[Command]
name = "���C���M��2"
command = ~F, D, DF, b+c
time = 15

[Command]
name = "���C���M��2"
command = ~F, D, DF, c+a
time = 15

[Command]
name = "���C���M��3"
command = ~B, D, DB, x+y
time = 15

[Command]
name = "���C���M��3"
command = ~B, D, DB, y+z
time = 15

[Command]
name = "���C���M��3"
command = ~B, D, DB, z+x
time = 15

[Command]
name = "���C���M��4"
command = ~B, D, DB, a+b
time = 15

[Command]
name = "���C���M��4"
command = ~B, D, DB, b+c
time = 15

[Command]
name = "���C���M��4"
command = ~B, D, DB, c+a
time = 15

[Command]
name = "���o�K�`��"
command = x
time = 1

[Command]
name = "���o�K�`��"
command = y
time = 1

[Command]
name = "���o�K�`��"
command = z
time = 1

[Command]
name = "���o�K�`��"
command = a
time = 1

[Command]
name = "���o�K�`��"
command = b
time = 1

[Command]
name = "���o�K�`��"
command = c
time = 1

[Command]
name = "���o�K�`��"
command = F
time = 1

[Command]
name = "���o�K�`��"
command = D
time = 1

[Command]
name = "���o�K�`��"
command = B
time = 1

[Command]
name = "���o�K�`��"
command = U
time = 1

;�����X�e�b�v�ړ�������������������������������������������������������������������
[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;�����_�E�������������������������������������������������������������������������
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1

[Command]
name = "recovery";Required (do not remove)
command = a+b
time = 1

[Command]
name = "recovery";Required (do not remove)
command = x+a
time = 1

[Command]
name = "recovery";Required (do not remove)
command = y+b
time = 1

[Command]
name = "recovery";Required (do not remove)
command = z+c
time = 1

[Command]
name = "recovery";Required (do not remove)
command = x+z
time = 1

[Command]
name = "recovery";Required (do not remove)
command = a+c
time = 1

;����������������������������������������������������������������������������������
[Command]
name = "x+a"
command = x+a
time = 1

[Command]
name = "y+b"
command = y+b
time = 1

[Command]
name = "z+c"
command = z+c
time = 1

;�����V���O������������������������������������������������������������������������
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1

;�����{�^���������ςȂ�����������������������������������������������������������
[Command]
name = "holdx"
command = /$x
time = 1

[Command]
name = "holdy"
command = /$y
time = 1

[Command]
name = "holdz" 
command = /$z
time = 1

[Command]
name = "holda"
command = /$a
time = 1

[Command]
name = "holdb"
command = /$b
time = 1

[Command]
name = "holdc"
command = /$c
time = 1

[Command]
name = "holds"
command = /$s
time = 1

[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1


;�������ꑀ�쁙��������������������������������������������������������������������
[Command]
name = "fwd"
command = F
time = 1

[Command]
name = "back"
command = B
time = 1

[Command]
name = "down"
command = /D
time = 1

[Command]
name = "down"
command = /DF
time = 1

[Command]
name = "down"
command = /DB
time = 1

;quick standing
[Command]
name = "quick"
command = D
time = 1

;longjump
[Command]
name = "longjump_f"
command = D, UF
time = 10

[Command]
name = "longjump_b"
command = D, UB
time = 10

[Command]
name = "longjump_u"
command = D, U
time = 10

[Command];�i�O�u���b�L���O�R�}���h�j
name = "bl1"
command = F
time = 1

[Command];�i���u���b�L���O�R�}���h�j
name = "bl2"
command = D
time = 1




[Statedef -1]

;����AI���쁙��������������������������������������������������������������������
[State -1, AI]
type = Varset
triggerall = numhelper(30000)
triggerall = helper(30000),var(15) = 1
triggerall = var(50) != 1
trigger1 = command = "AI_1"
trigger2 = command = "AI_2"
trigger3 = command = "AI_3"
trigger4 = command = "AI_4"
trigger5 = command = "AI_5"
trigger6 = command = "AI_6"
trigger7 = command = "AI_7"
trigger8 = command = "AI_8"
trigger9 = command = "AI_9"
trigger10 = command = "AI_10"
trigger11 = command = "AI_11"
trigger12 = command = "AI_12"
trigger13 = command = "AI_13"
trigger14 = command = "AI_14"
trigger15 = command = "AI_15"
trigger16 = command = "AI_16"
trigger17 = command = "AI_17"
trigger18 = command = "AI_18"
trigger19 = command = "AI_19"
trigger20 = command = "AI_20"
trigger21 = command = "AI_21"
trigger22 = command = "AI_22"
trigger23 = command = "AI_23"
trigger24 = command = "AI_24"
trigger25 = command = "AI_25"
trigger26 = command = "AI_26"
trigger27 = command = "AI_27"
trigger28 = command = "AI_28"
trigger29 = command = "AI_29"
trigger30 = command = "AI_30"
trigger31 = command = "AI_31"
trigger32 = command = "AI_32"
trigger33 = command = "AI_33"
trigger34 = command = "AI_34"
trigger35 = command = "AI_35"
trigger36 = command = "AI_36"
trigger37 = command = "AI_37"
trigger38 = command = "AI_38"
trigger39 = command = "AI_39"
trigger40 = command = "AI_40"
trigger41 = command = "AI_41"
trigger42 = command = "AI_42"
trigger43 = command = "AI_43"
trigger44 = command = "AI_44"
trigger45 = command = "AI_45"
trigger46 = command = "AI_46"
trigger47 = command = "AI_47"
trigger48 = command = "AI_48"
trigger49 = command = "AI_49"
trigger50 = command = "AI_50"
v = 50
value = 1

;�����R�}���h���́�����������������������������������������������������������������

[State -1, Varset]
type = Varset
triggerall = Command = "longjump_u" || Command = "longjump_f" || Command = "longjump_b"
trigger1 = !var(38) && !fvar(16)
trigger2 = var(38)
trigger2 = var(58):= 40+ifelse(command="longjump_f",2,ifelse(command="longjump_b",3,1))
var(55) = 40
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "FF"
trigger1 = !var(38) && !fvar(16)
trigger2 = var(38)
trigger2 = var(58):= 100
var(55) = 100
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "BB"
trigger1 = !var(38) && !fvar(16)
trigger2 = var(38)
trigger2 = var(58):= 105
var(55) = 105
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "x"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(command="holddown",400,200)
var(55) = ifelse(command="holddown",400,200)
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "y"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(command="holddown",410,ifelse(command="holdfwd",900,210))
var(55) = ifelse(command="holddown",410,ifelse(command="holdfwd",900,210))
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "z"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(command="holddown",420,220)
var(55) = ifelse(command="holddown",420,220)
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "a"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(command="holddown",430,230)
var(55) = ifelse(command="holddown",430,230)
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "b"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(command="holddown",440,240)
var(55) = ifelse(command="holddown",440,240)
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "c"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(command="holddown",450,250)
var(55) = ifelse(command="holddown",450,250)
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "x"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= 600
var(26) = 600
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "y"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= 610
var(26) = 610
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "z"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= 620
var(26) = 620
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "a"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= 630
var(26) = 630
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "b"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= ifelse(vel X>0&&command="holddown",910,640)
var(26) = ifelse(vel X>0&&command="holddown",910,640)
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = Command = "c"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= 650
var(26) = 650
ignorehitpause = 1

[State -1, Varset]
type = Varset
trigger1 = (command = "s") || (command = "z+c")
trigger1 = command != "holdfwd"
trigger1 = command != "holdback"
trigger1 = command != "holddown"
var(55) = 195
ignorehitpause = 1

[State -1, Varset]
type = Varset
trigger1 = command = "y+b"
trigger1 = command != "holdfwd"
trigger1 = command != "holdback"
trigger1 = command != "holddown"
var(55) = 920
ignorehitpause = 1

[State -1, Varset]
type = Varset
trigger1 = command = "x+a"
trigger1 = command != "holddown"
var(55) = 800
ignorehitpause = 1

;���g����
[State -1, Varset]
type = Varset
triggerall = Command = "���g����_x" || Command = "���g����_y" || Command = "���g����_z"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(Command = "���g����_z",1020,ifelse(Command = "���g����_y",1010,1000))
var(55) = ifelse(Command = "���g����_z",1020,ifelse(Command = "���g����_y",1010,1000))
ignorehitpause = 1

;�a��g����
[State -1, Varset]
type = Varset
triggerall = Command = "���g����_x" || Command = "���g����_y" || Command = "���g����_z"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= ifelse(Command = "���g����_z",1620,ifelse(Command = "���g����_y",1610,1600))
var(26) = ifelse(Command = "���g����_z",1620,ifelse(Command = "���g����_y",1610,1600))
ignorehitpause = 1

;��������
[State -1, Varset]
type = Varset
triggerall = Command = "��������_x" || Command = "��������_y" || Command = "��������_z"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(Command = "��������_z",1120,ifelse(Command = "��������_y",1110,1100))
var(55) = ifelse(Command = "��������_z",1120,ifelse(Command = "��������_y",1110,1100))
ignorehitpause = 1

;�ܔM�g����
[State -1, Varset]
type = Varset
triggerall = Command = "�ܔM�g����_x" || Command = "�ܔM�g����_y" || Command = "�ܔM�g����_z"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(Command = "�ܔM�g����_z",1720,ifelse(Command = "�ܔM�g����_y",1710,1700))
var(55) = ifelse(Command = "�ܔM�g����_z",1720,ifelse(Command = "�ܔM�g����_y",1710,1700))
ignorehitpause = 1

;�����a��r
[State -1, Varset]
type = Varset
triggerall = Command = "�����a��r_a" || Command = "�����a��r_b" || Command = "�����a��r_c"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(command = "�����a��r_c",1220,ifelse(Command = "�����a��r_b",1210,1200))
var(55) = ifelse(command = "�����a��r_c",1220,ifelse(Command = "�����a��r_b",1210,1200))
ignorehitpause = 1

;�󒆗����a��r
[State -1, Varset]
type = Varset
triggerall = Command = "�����a��r_a" || Command = "�����a��r_b" || Command = "�����a��r_c"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= ifelse(command = "�����a��r_c",1320,ifelse(Command = "�����a��r_b",1310,1300))
var(26) = ifelse(command = "�����a��r_c",1320,ifelse(Command = "�����a��r_b",1310,1300))
ignorehitpause = 1

;�S�S�P
[State -1, Varset]
type = Varset
triggerall = Command = "�S�S�P_a" || Command = "�S�S�P_b" || Command = "�S�S�P_c"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= 1500
var(55) = 1500
ignorehitpause = 1

[State -1, Varset]
type = Varset
trigger1 = Command = "�S�S�P_a" || Command = "�S�S�P_b" || Command = "�S�S�P_c"
var(10) = ifelse(command = "�S�S�P_c",2,ifelse(Command = "�S�S�P_b",1,0))
ignorehitpause = 1

;���C���M��
[State -1, Varset]
type = Varset
triggerall = Command = "���C���M��1" || Command = "���C���M��2" || Command = "���C���M��3" || Command = "���C���M��4"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= ifelse(command = "���C���M��1",1400,ifelse(Command = "���C���M��3",1420,ifelse(Command = "���C���M��2",1410,1430)))
var(55) = ifelse(command = "���C���M��1",1400,ifelse(Command = "���C���M��3",1420,ifelse(Command = "���C���M��2",1410,1430)))
ignorehitpause = 1

;�ŎE���g��
[State -1, Varset]
type = Varset
triggerall = var(2) = 0 || var(2) = 1
triggerall = Power >= 1120+(!var(2))*160
triggerall = Command = "�ŎE���g��"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= 3000
var(55) = 3000
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = var(2) = 0 || var(2) = 1
triggerall = Power >= 1120+(!var(2))*160
triggerall = Command = "�ŎE���g��"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= 3100
var(26) = 3100
ignorehitpause = 1

;�ŎE������
[State -1, Varset]
type = Varset
triggerall = var(2) = 0 || var(2) = 2
triggerall = Power >= 1120+(!var(2))*160
triggerall = ifelse(var(2)=2,Command="�ŎE���g��",Command="�ŎE������")
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= 3200
var(55) = 3200
ignorehitpause = 1

;�ŎE������
[State -1, Varset]
type = Varset
triggerall = var(2) = 0 || var(2) = 3
triggerall = Power >= 1120+(!var(2))*160
triggerall = ifelse(var(2)=3,Command="�ŎE������",Command="�ŎE������")
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= 3300
var(55) = 3300
ignorehitpause = 1

[State -1, Varset]
type = Varset
triggerall = var(2) = 0 || var(2) = 3
triggerall = Power >= 1120+(!var(2))*160
triggerall = ifelse(var(2)=3,Command="�ŎE������",Command="�ŎE������")
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(47):= 3400
var(26) = 3400
ignorehitpause = 1

;��������a
[State -1, Varset]
type = Varset
triggerall = Power >= 2240+(!var(2))*320
triggerall = Command = "��������a"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= 3500
var(55) = 3500
ignorehitpause = 1

;�u���E
[State -1, Varset]
type = Varset
triggerall = Power >= 2240+(!var(2))*320
triggerall = Command = "�u���E"
trigger1 = !var(38) && fvar(16)<2
trigger2 = var(38)
trigger2 = var(58):= 3600
var(55) = 3600
ignorehitpause = 1

;��s���͉���
[State -1, Varset]
type = Varset
trigger1 = var(55) != var(57)
var(56) = helper(30000),var(19)
ignorehitpause = 1

[State -1, Varset]
type = Varset
trigger1 = 1
var(57) = var(55)
ignorehitpause = 1

[State -1, VarAdd]
type = VarAdd
trigger1 = Var(55)
trigger1 = Var(56) > 0
var(56) = -1

[State -1, Varset]
type = Varset
trigger1 = var(26) != var(28)
var(27) = helper(30000),var(19)
ignorehitpause = 1

[State -1, Varset]
type = Varset
trigger1 = 1
var(28) = var(26)
ignorehitpause = 1

[State -1, VarAdd]
type = VarAdd
trigger1 = Var(26)
trigger1 = Var(27) > 0
var(27) = -1

;�K�E�Z�����i�n��Z�j

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = [3500,3600]
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = numhelper(30000)
triggerall = helper(30000),var(11) = 1
triggerall = !var(13)
trigger1 = stateno = 3200 && animelemtime(6) <= 0 && var(38) = 3200
trigger2 = stateno = 3200 && animelemtime(8) <= 0 && var(38) = 3201
trigger3 = stateno = 3210 && animelemtime(5) <= 0 && var(38) = 3210
trigger4 = stateno = 3210 && animelemtime(7) <= 0 && var(38) = 3211
trigger5 = stateno = 3220 && animelemtime(5) <= 0 && var(38) = 3220
trigger6 = stateno = 3220 && animelemtime(7) <= 0 && var(38) = 3221
trigger7 = stateno = 3300 && animelemtime(11) <= 0 && var(38) = 3300
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = 3000
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = numhelper(30000)
triggerall = helper(30000),var(11) = 1
triggerall = !var(13)
trigger1 = stateno = 3200 && animelemtime(6) <= 0 && var(38) = 3200
trigger2 = stateno = 3200 && animelemtime(8) <= 0 && var(38) = 3201
trigger3 = stateno = 3210 && animelemtime(5) <= 0 && var(38) = 3210
trigger4 = stateno = 3210 && animelemtime(7) <= 0 && var(38) = 3211
trigger5 = stateno = 3220 && animelemtime(5) <= 0 && var(38) = 3220
trigger6 = stateno = 3220 && animelemtime(7) <= 0 && var(38) = 3221
trigger7 = stateno = 3300 && animelemtime(11) <= 0 && var(38) = 3300
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = 3200
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = numhelper(30000)
triggerall = helper(30000),var(11) = 1
triggerall = !var(13)
trigger1 = stateno = 3300 && animelemtime(11) <= 0 && var(38) = 3300
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(55)
triggerall = (var(55) = [3200,3300]) || (var(55) = [3500,3600])
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = numhelper(30000)
triggerall = helper(30000),var(11) = 1
triggerall = !var(13)
trigger1 = stateno = 3000 && (Animelemtime(21) > 0) && (Animelemtime(26) < 0)
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = 3300
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = numhelper(30000)
triggerall = helper(30000),var(11) = 1
triggerall = !var(13)
trigger1 = stateno = 3200 && animelemtime(6) <= 0 && var(38) = 3200
trigger2 = stateno = 3200 && animelemtime(8) <= 0 && var(38) = 3201
trigger3 = stateno = 3210 && animelemtime(5) <= 0 && var(38) = 3210
trigger4 = stateno = 3210 && animelemtime(7) <= 0 && var(38) = 3211
trigger5 = stateno = 3220 && animelemtime(5) <= 0 && var(38) = 3220
trigger6 = stateno = 3220 && animelemtime(7) <= 0 && var(38) = 3221
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(47)
triggerall = var(47) = 3100
triggerall = roundstate = 2
triggerall = StateType = A
triggerall = var(50) = 0
triggerall = numhelper(30000)
triggerall = helper(30000),var(11) = 1
triggerall = !var(13)
trigger1 = stateno = 3200 && var(38)
trigger2 = stateno = 3210 && var(38)
trigger3 = stateno = 3220 && var(38)
trigger4 = stateno = 3300 && var(38)
trigger5 = stateno = 3400 && var(38)
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(26)
triggerall = var(26) = 3400
triggerall = roundstate = 2
triggerall = StateType = A
triggerall = var(50) = 0
triggerall = numhelper(30000)
triggerall = helper(30000),var(11) = 1
triggerall = !var(13)
trigger1 = stateno = 3100 && (Animelemtime(11) > 0) && (Animelemtime(12) < 4)
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(47)
triggerall = var(47) = 3400
triggerall = roundstate = 2
triggerall = StateType = A
triggerall = var(50) = 0
triggerall = numhelper(30000)
triggerall = helper(30000),var(11) = 1
triggerall = !var(13)
trigger1 = stateno = 3200 && var(38)
trigger2 = stateno = 3210 && var(38)
trigger3 = stateno = 3220 && var(38)
trigger4 = stateno = 3300 && var(38)
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(47)
triggerall = var(47) = 3100 || var(47) = 3400
triggerall = roundstate = 2
triggerall = StateType = A
triggerall = var(50) = 0
triggerall = !var(13)
triggerall = var(38)
trigger1 = stateno = [1210,1220]
trigger1 = Animelemtime(6) <= 0
trigger2 = stateno = [1300,1320] 
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(47)
triggerall = var(47) = 3100 || var(47) = 3400
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = roundstate = 2
triggerall = StateType = A
triggerall = var(50) = 0
triggerall = !var(13)
triggerall = var(38)
trigger1 = stateno = [1100,1120] 
trigger2 = stateno = [1200,1220] 
trigger3 = stateno = [1520,1530] 
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(26)
triggerall = var(26) = 3100 || var(26) = 3400
triggerall = roundstate = 2
triggerall = StateType = A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = [1600,1620]
trigger1 = Animelemtime(6-var(22)*3) > 0 && Animelemtime(7) < 6
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = [3000,3300]
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger4 = stateno = 225 && Animelemtime(6) <= 0 && var(38) = 225
trigger5 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger6 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger7 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger8 = stateno = 420 && Animelemtime(4) <= 0 && var(38) = 420
trigger9 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger10 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
trigger11 = stateno = 1100 && Animelemtime(4) <= 0 && var(38) = 1100
trigger12 = stateno = 1110 && Animelemtime(4) <= 0 && var(38) = 1110
trigger13 = stateno = 1120 && Animelemtime(4) <= 0 && var(38) = 1120
trigger14 = stateno = 1120 && Animelemtime(6) <= 0 && var(38) = 1121
trigger15 = stateno = [1210,1220]
trigger15 = Animelemtime(5) <= 0 && var(38)
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = 3500
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = 1100 && Animelemtime(4) <= 0 && var(38) = 1100
trigger2 = stateno = 1110 && Animelemtime(4) <= 0 && var(38) = 1110
trigger3 = stateno = 1120 && Animelemtime(4) <= 0 && var(38) = 1120
trigger4 = stateno = 1120 && Animelemtime(6) <= 0 && var(38) = 1121
trigger5 = stateno = [1210,1220]
trigger5 = Animelemtime(5) <= 0 && var(38)
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(55)
triggerall = var(55) = 3500
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = [1000,1020]
trigger1 = Animelemtime(5) > 0 && Animelemtime(8) < 0
trigger2 = stateno = [1700,1720]
trigger2 = Animelemtime(7) > 0 && Animelemtime(10) < 0
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = 3500
triggerall = numhelper(30000)
triggerall = helper(30000),var(7) = 1
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger4 = stateno = 225 && Animelemtime(6) <= 0 && var(38) = 225
trigger5 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger6 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger7 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger8 = stateno = 420 && Animelemtime(4) <= 0 && var(38) = 420
trigger9 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger10 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(55)
triggerall = var(55) = [3000,3300]
triggerall = var(55) != 3100
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = [1000,1020]
trigger1 = Animelemtime(5) > 0 && Animelemtime(8) < 0
trigger2 = stateno = [1700,1720]
trigger2 = Animelemtime(7) > 0 && Animelemtime(10) < 0
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = [1100,1500]
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger4 = stateno = 225 && Animelemtime(6) <= 0 && var(38) = 225
trigger5 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger6 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger7 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger8 = stateno = 420 && Animelemtime(4) <= 0 && var(38) = 420
trigger9 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger10 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = (var(58) = [1000,1020]) || (var(58) = [1700,1720])
triggerall = !fvar(36)
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger4 = stateno = 225 && Animelemtime(6) <= 0 && var(38) = 225
trigger5 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger6 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger7 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger8 = stateno = 420 && Animelemtime(4) <= 0 && var(38) = 420
trigger9 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger10 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
ignorehitpause = 0

[State -1]
type = ChangeState
value = var(58)
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(7) = 1
triggerall = (var(58) = [1100,1500]) || (var(58) = [3000,3300]) || (var(58) = 3500)
triggerall = var(58) != [1300,1320]
triggerall = !var(13)
trigger1 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger2 = Stateno = 220 && Animelemtime(8) <= 0 && var(38) = 220
trigger3 = Stateno = 221 && Animelemtime(7) <= 0 && var(38) = 221
trigger4 = stateno = 225 && Animelemtime(8) <= 0 && var(38) = 10225
trigger5 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger6 = Stateno = 240 && Animelemtime(6) <= 0 && var(38) = 240
trigger7 = Stateno = 250 && Animelemtime(10) <= 0 && var(38) = 250
trigger8 = Stateno = 255 && Animelemtime(6) <= 0 && var(38) = 255
trigger9 = Stateno = 255 && Animelemtime(12) <= 0 && var(38) = 256
trigger10 = Stateno = 420 && Animelemtime(7) <= 0 && var(38) = 10420
trigger11 = Stateno = 450 && Animelemtime(7) <= 0 && var(38) = 450
trigger12 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger13 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

[State -1]
type = ChangeState
value = var(58)
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(7) = 1
triggerall = (var(58) = [1000,1020]) || (var(58) = [1700,1720])
triggerall = !fvar(36)
triggerall = !var(13)
trigger1 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger2 = Stateno = 220 && Animelemtime(8) <= 0 && var(38) = 220
trigger3 = Stateno = 221 && Animelemtime(7) <= 0 && var(38) = 221
trigger4 = stateno = 225 && Animelemtime(8) <= 0 && var(38) = 10225
trigger5 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger6 = Stateno = 240 && Animelemtime(6) <= 0 && var(38) = 240
trigger7 = Stateno = 250 && Animelemtime(10) <= 0 && var(38) = 250
trigger8 = Stateno = 255 && Animelemtime(6) <= 0 && var(38) = 255
trigger9 = Stateno = 255 && Animelemtime(12) <= 0 && var(38) = 256
trigger10 = Stateno = 420 && Animelemtime(7) <= 0 && var(38) = 10420
trigger11 = Stateno = 450 && Animelemtime(7) <= 0 && var(38) = 450
trigger12 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger13 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = [1100,1120]
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = [1200,1220]
trigger1 = Animelemtime(5) <= 0 && var(38)
trigger2 = stateno = 1510 && var(38)
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = var(58) = [1200,1220]
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = 1100 && Animelemtime(4) <= 0 && var(38) = 1100
trigger2 = stateno = 1110 && Animelemtime(4) <= 0 && var(38) = 1110
trigger3 = stateno = 1120 && Animelemtime(4) <= 0 && var(38) = 1120
trigger4 = stateno = 1120 && Animelemtime(6) <= 0 && var(38) = 1121
trigger5 = stateno = 1510 && var(38)
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(55)
triggerall = var(55) = [1100,1220]
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = [1000,1020]
trigger1 = Animelemtime(5) > 0 && Animelemtime(8) < 0
trigger2 = stateno = [1700,1720]
trigger2 = Animelemtime(7) > 0 && Animelemtime(10) < 0
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(58)
triggerall = (var(58) = [1000,1020]) || (var(58) = [1700,1720])
triggerall = !fvar(36)
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = 1100 && Animelemtime(4) <= 0 && var(38) = 1100
trigger2 = stateno = 1110 && Animelemtime(4) <= 0 && var(38) = 1110
trigger3 = stateno = 1120 && Animelemtime(4) <= 0 && var(38) = 1120
trigger4 = stateno = 1120 && Animelemtime(6) <= 0 && var(38) = 1121
trigger5 = stateno = 1510 && var(38)
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(47)
triggerall = var(47) = [1300,1320]
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = roundstate = 2
triggerall = StateType = A
triggerall = var(50) = 0
triggerall = !var(13)
triggerall = var(38)
trigger1 = stateno = [1100,1120] 
trigger2 = stateno = [1200,1220] 
trigger3 = stateno = [1520,1530] 
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(26)
triggerall = var(26) = [1300,1320]
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = roundstate = 2
triggerall = StateType = A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = stateno = [1600,1620]
trigger1 = Animelemtime(6-var(22)*3) > 0 && Animelemtime(7) < 6
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(47)
triggerall = var(47) = [1600,1620]
triggerall = !fvar(36)
triggerall = numhelper(30000)
triggerall = helper(30000),var(10) = 1
triggerall = roundstate = 2
triggerall = StateType = A
triggerall = var(50) = 0
triggerall = !var(13)
triggerall = var(38)
trigger1 = stateno = [1100,1120] 
trigger2 = stateno = [1200,1220] 
trigger3 = stateno = [1300,1320] 
trigger4 = stateno = [1520,1530] 
ignorehitpause = 0

[State -1]
type = ChangeState
value = var(47)
triggerall = var(50) = 0
triggerall = StateType = A
triggerall = numhelper(30000)
triggerall = helper(30000),var(7) = 1
triggerall = (var(47) = [1300,1320])||var(47)=3100||var(47)=3400
triggerall = var(38)
triggerall = !var(13)
trigger1 = Stateno = 600
trigger2 = Stateno = 605
trigger3 = Stateno = 610
trigger4 = Stateno = 615
trigger5 = Stateno = 620
trigger6 = Stateno = 625
trigger7 = Stateno = 630
trigger8 = Stateno = 635
trigger9 = Stateno = 640
trigger10 = Stateno = 645
trigger11 = Stateno = 650
trigger12 = Stateno = 655
trigger13 = Stateno = 910
ignorehitpause = 0

[State -1]
type = ChangeState
value = var(47)
triggerall = var(50) = 0
triggerall = !fvar(36)
triggerall = StateType = A
triggerall = numhelper(30000)
triggerall = helper(30000),var(7) = 1
triggerall = var(47) = [1600,1620]
triggerall = var(38)
triggerall = !var(13)
trigger1 = Stateno = 600
trigger2 = Stateno = 605
trigger3 = Stateno = 610
trigger4 = Stateno = 615
trigger5 = Stateno = 620
trigger6 = Stateno = 625
trigger7 = Stateno = 630
trigger8 = Stateno = 635
trigger9 = Stateno = 640
trigger10 = Stateno = 645
trigger11 = Stateno = 650
trigger12 = Stateno = 655
trigger13 = Stateno = 910
ignorehitpause = 0

[State -1]
type = ChangeState
value = 40
triggerall = numhelper(30000)
triggerall = helper(30000),var(8) = 1
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = var(58) = [41,43]
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger4 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger5 = Stateno = 220 && Animelemtime(8) <= 0 && var(38) = 220
trigger6 = Stateno = 221 && Animelemtime(7) <= 0 && var(38) = 221
trigger7 = stateno = 225 && Animelemtime(6) <= 0 && var(38) = 225
trigger8 = stateno = 225 && Animelemtime(8) <= 0 && var(38) = 10225
trigger9 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger10 = Stateno = 240 && Animelemtime(6) <= 0 && var(38) = 240
trigger11 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger12 = Stateno = 250 && Animelemtime(10) <= 0 && var(38) = 250
trigger13 = Stateno = 255 && Animelemtime(6) <= 0 && var(38) = 255
trigger14 = Stateno = 255 && Animelemtime(12) <= 0 && var(38) = 256
trigger15 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger16 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger17 = stateno = 420 && Animelemtime(4) <= 0 && var(38) = 420
trigger18 = Stateno = 420 && Animelemtime(7) <= 0 && var(38) = 10420
trigger19 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger20 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
trigger21 = Stateno = 450 && Animelemtime(7) <= 0 && var(38) = 450
trigger22 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger23 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

[State -2, ChangeState]
type = ChangeState
triggerall = fvar(2) >= 56.0
trigger1 = statetype != A
trigger1 = ctrl
value = 5300
ignorehitpause = 0

;�����R�}���h��s���́�������������������������������������������������������������
;Reversal �K�E�Z�����i�n��Z)
[State -1, ChangeState]
type = ChangeState
value = Var(55)
triggerall = Var(55) = 3600
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
trigger1 = ctrl 
trigger2 = fvar(2) < 56
trigger2 = stateno = 5001
trigger2 = HitOver
trigger3 = fvar(2) < 56
trigger3 = stateno = 5011
trigger3 = HitOver
trigger4 = statetype = S
trigger4 = stateno = 151 || stateno = 6151
trigger4 = HitOver
trigger5 = statetype = C
trigger5 = stateno = 153 || stateno = 6153
trigger5 = HitOver
trigger6 = statetype = S
trigger6 = stateno = [4000,4015]
trigger6 = animelemtime(4) = 0
trigger7 = statetype = C
trigger7 = stateno = [4100,4115]
trigger7 = animelemtime(4) = 0
trigger8 = fvar(2) < 56
trigger8 = stateno = 5120
trigger8 = AnimElemTime(10) = 0
trigger9 = stateno = 5123
trigger9 = AnimElemTime(10) = 0
trigger10 = stateno = 5124
trigger10 = AnimElemTime(10) = 0
trigger11 = !var(13)
trigger11 = (stateno = [200,225]) || (stateno = [230,240]) || (stateno = [250,450]) || stateno = 900
trigger12 = stateno = 40
trigger12 = pos Y = 0
trigger13 = stateno = 100
trigger13 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1, ChangeState]
type = ChangeState
value = Var(55)
triggerall = (Var(55) = [1100,1500]) || (Var(55) = [3000,3500])
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
trigger1 = ctrl 
trigger2 = fvar(2) < 56
trigger2 = stateno = 5001
trigger2 = HitOver
trigger3 = fvar(2) < 56
trigger3 = stateno = 5011
trigger3 = HitOver
trigger4 = statetype = S
trigger4 = stateno = 151 || stateno = 6151
trigger4 = HitOver
trigger5 = statetype = C
trigger5 = stateno = 153 || stateno = 6153
trigger5 = HitOver
trigger6 = statetype = S
trigger6 = stateno = [4000,4015]
trigger6 = animelemtime(4) = 0
trigger7 = statetype = C
trigger7 = stateno = [4100,4115]
trigger7 = animelemtime(4) = 0
trigger8 = fvar(2) < 56
trigger8 = stateno = 5120
trigger8 = AnimElemTime(10) = 0
trigger9 = stateno = 5123
trigger9 = AnimElemTime(10) = 0
trigger10 = stateno = 5124
trigger10 = AnimElemTime(10) = 0
trigger11 = (stateno = [200,225]) || (stateno = [230,240]) || (stateno = [250,450]) || stateno = 900
trigger11 = movetype = A && time <= 3
trigger12 = stateno = 40
trigger12 = pos Y = 0
trigger13 = stateno = 100
trigger13 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1, ChangeState]
type = ChangeState
value = Var(55)
triggerall = Var(55) = 195 || var(55) = 800 || var(55) = 920
triggerall = StateType != A
triggerall = var(50) = 0
trigger1 = ctrl 
trigger2 = fvar(2) < 56
trigger2 = stateno = 5001
trigger2 = HitOver
trigger3 = fvar(2) < 56
trigger3 = stateno = 5011
trigger3 = HitOver
trigger4 = statetype = S
trigger4 = stateno = 151 || stateno = 6151
trigger4 = HitOver
trigger5 = statetype = C
trigger5 = stateno = 153 || stateno = 6153
trigger5 = HitOver
trigger6 = statetype = S
trigger6 = stateno = [4000,4015]
trigger6 = animelemtime(4) = 0
trigger7 = statetype = C
trigger7 = stateno = [4100,4115]
trigger7 = animelemtime(4) = 0
trigger8 = fvar(2) < 56
trigger8 = stateno = 5120
trigger8 = AnimElemTime(10) = 0
trigger9 = stateno = 5123
trigger9 = AnimElemTime(10) = 0
trigger10 = stateno = 5124
trigger10 = AnimElemTime(10) = 0
trigger11 = (stateno = [200,225]) || (stateno = [230,240]) || (stateno = [250,450]) || stateno = 900
trigger11 = movetype = A && time <= 3
trigger12 = stateno = 40
trigger12 = pos Y = 0
trigger13 = stateno = 100
trigger13 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1, ChangeState]
type = ChangeState
value = Var(55)
triggerall = (var(55) = [1000,1020]) || (var(55) = [1700,1720])
triggerall = !fvar(36)
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 0
trigger1 = ctrl 
trigger2 = fvar(2) < 56
trigger2 = stateno = 5001
trigger2 = HitOver
trigger3 = fvar(2) < 56
trigger3 = stateno = 5011
trigger3 = HitOver
trigger4 = statetype = S
trigger4 = stateno = 151 || stateno = 6151
trigger4 = HitOver
trigger5 = statetype = C
trigger5 = stateno = 153 || stateno = 6153
trigger5 = HitOver
trigger6 = statetype = S
trigger6 = stateno = [4000,4015]
trigger6 = animelemtime(4) = 0
trigger7 = statetype = C
trigger7 = stateno = [4100,4115]
trigger7 = animelemtime(4) = 0
trigger8 = fvar(2) < 56
trigger8 = stateno = 5120
trigger8 = AnimElemTime(10) = 0
trigger9 = stateno = 5123
trigger9 = AnimElemTime(10) = 0
trigger10 = stateno = 5124
trigger10 = AnimElemTime(10) = 0
trigger11 = (stateno = [200,225]) || (stateno = [230,240]) || (stateno = [250,450]) || stateno = 900
trigger11 = movetype = A && time <= 3
trigger12 = stateno = 40
trigger12 = pos Y = 0
trigger13 = stateno = 100
trigger13 = AnimElemTime(5) >= 1
ignorehitpause = 0

;�K�E�Z�����i�󒆋Z�j
[State -1, 0]
type = ChangeState
value = var(26)
triggerall = (var(26) = [1300,1320]) || var(26) = 3100 || var(26) = 3400
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = ctrl
trigger2 = stateno = [600,655]
trigger2 = movetype = A && time <= 3
ignorehitpause = 0

[State -1, 0]
type = ChangeState
value = var(26)
triggerall = var(26) = [1600,1620]
triggerall = !fvar(36)
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = var(50) = 0
triggerall = !var(13)
trigger1 = ctrl
trigger2 = stateno = [600,655]
trigger2 = movetype = A && time <= 3
ignorehitpause = 0

;�����ʏ�U������������������������������������������������������������������������

;������p���`
[State -1]
type = ChangeState
value = ifelse(P2bodydist X <= 28*const(size.xscale),225,220)
triggerall = (command = "z" && command != "holddown") || var(55) = 220
triggerall = var(50) = 0
triggerall = StateType != A
trigger1 = ctrl 
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = ifelse(P2bodydist X <= 28*const(size.xscale),225,220)
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 220
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger4 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger5 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger6 = Stateno = 240 && Animelemtime(6) <= 0 && var(38) = 240
trigger7 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger8 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger9 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger10 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger11 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
trigger12 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger13 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

;����������������������������������������������������������������������������������
;���W�j�E
[State -1]
type = ChangeState
value = 900
triggerall = (Command = "y" && Command = "holdfwd" && Command != "holddown") || var(55) = 900
triggerall = var(50) = 0
triggerall = StateType != A
trigger1 = ctrl 
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = 900
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 900
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger4 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger5 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
ignorehitpause = 0

;�������p���`
[State -1]
type = ChangeState
value = ifelse(P2bodydist X <= 22*const(size.xscale),215,210)
triggerall = (command = "y" && command != "holddown") || var(55) = 210
triggerall = var(50) = 0
triggerall = StateType != A
trigger1 = ctrl 
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = ifelse(P2bodydist X <= 22*const(size.xscale),215,210)
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 210
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger4 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger5 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
ignorehitpause = 0

;����������������������������������������������������������������������������������

;�������p���`
[State -1]
type = ChangeState
value = ifelse(P2bodydist X <= 8*const(size.xscale),205,200)
triggerall = (Command = "x" && Command != "holddown") || var(55) = 200
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = !var(13)
trigger1 = ctrl 
trigger2 = Stateno = 200
trigger2 = Animelemtime(5) >= 0
trigger3 = Stateno = 205
trigger3 = Animelemtime(8) >= 1
trigger4 = Stateno = 400
trigger4 = Animelemtime(5) >= 0
trigger5 = Stateno = 430
trigger5 = Animelemtime(5) >= 0
trigger6 = stateno = 100
trigger6 = AnimelemTime(5) >= 1
ignorehitpause = 0

;�A�ŃL�����Z��
[State -1]
type = ChangeState
value = ifelse(P2bodydist X<=ceil(8*const(size.xscale)),205,200)
triggerall = var(58) = 200
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = !var(13)
triggerall = var(38)
trigger1 = Stateno = 200
trigger2 = Stateno = 400
trigger3 = Stateno = 430
ignorehitpause = 0

;����������������������������������������������������������������������������������

;������L�b�N
[State -1]
type = ChangeState
value = ifelse(P2bodydist X <= 33*const(size.xscale),255,250)
triggerall = (command = "c" && command != "holddown") || var(55) = 250
triggerall = var(50) = 0
triggerall = StateType != A
trigger1 = ctrl 
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = ifelse(P2bodydist X <= 33*const(size.xscale),255,250)
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 250
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger4 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger5 = Stateno = 220 && Animelemtime(8) <= 0 && var(38) = 220
trigger6 = Stateno = 221 && Animelemtime(7) <= 0 && var(38) = 221
trigger7 = stateno = 225 && Animelemtime(6) <= 0 && var(38) = 225
trigger8 = stateno = 225 && Animelemtime(8) <= 0 && var(38) = 10225
trigger9 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger10 = Stateno = 240 && Animelemtime(6) <= 0 && var(38) = 240
trigger11 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger12 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger13 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger14 = stateno = 420 && Animelemtime(4) <= 0 && var(38) = 420
trigger15 = Stateno = 420 && Animelemtime(7) <= 0 && var(38) = 10420
trigger16 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger17 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
trigger18 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger19 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

;����������������������������������������������������������������������������������

;�������L�b�N
[State -1]
type = ChangeState
value = ifelse(P2bodydist X <= 22*const(size.xscale),245,240)
triggerall = (command = "b" && command != "holddown") || var(55) = 240
triggerall = var(50) = 0
triggerall = StateType != A
trigger1 = ctrl 
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = ifelse(P2bodydist X <= 22*const(size.xscale),245,240)
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 240
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger4 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger5 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger6 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger7 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger8 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger9 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger10 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

;����������������������������������������������������������������������������������
;������L�b�N
[State -1]
type = ChangeState
value = 230
triggerall = (command = "a" && command != "holddown") || var(55) = 230
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = !var(13)
trigger1 = ctrl 
trigger2 = Stateno = 200
trigger2 = Animelemtime(5) >= 0
trigger3 = Stateno = 205
trigger3 = Animelemtime(8) >= 1
trigger4 = Stateno = 400
trigger4 = Animelemtime(5) >= 0
trigger5 = Stateno = 430
trigger5 = Animelemtime(5) >= 0
trigger6 = stateno = 100
trigger6 = AnimelemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = 230
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 230
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
ignorehitpause = 0

;����������������������������������������������������������������������������������
;���Ⴊ�ݑ�p���`
[State -1]
type = ChangeState
value = 420
triggerall = (command = "z" && command = "holddown") || var(55) = 420
triggerall = var(50) = 0
triggerall = StateType != A
trigger1 = ctrl 
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = 420
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 420
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger4 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger5 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger6 = Stateno = 240 && Animelemtime(6) <= 0 && var(38) = 240
trigger7 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger8 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger9 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger10 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger11 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
trigger12 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger13 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

;����������������������������������������������������������������������������������
;���Ⴊ�ݒ��p���`
[State -1]
type = ChangeState
value = 410
triggerall = (command = "y" && command = "holddown") || var(55) = 410
triggerall = var(50) = 0
triggerall = StateType != A
trigger1 = ctrl 
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = 410
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 410
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger4 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger5 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
ignorehitpause = 0

;����������������������������������������������������������������������������������
;���Ⴊ�ݏ��p���`
[State -1]
type = ChangeState
value = 400
triggerall = (command = "x" && command = "holddown") || var(55) = 400
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = !var(13)
trigger1 = ctrl
trigger2 = Stateno = 200
trigger2 = Animelemtime(5) >= 0
trigger3 = Stateno = 205
trigger3 = Animelemtime(8) >= 1
trigger4 = Stateno = 400
trigger4 = Animelemtime(5) >= 0
trigger5 = Stateno = 430
trigger5 = Animelemtime(5) >= 0
trigger6 = stateno = 100
trigger6 = AnimelemTime(5) >= 1
ignorehitpause = 0

;�A�ŃL�����Z��
[State -1]
type = ChangeState
value = 400
triggerall = var(58) = 400
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = !var(13)
triggerall = var(38)
trigger1 = Stateno = 200
trigger2 = Stateno = 400
trigger3 = Stateno = 430
ignorehitpause = 0

;����������������������������������������������������������������������������������
;���Ⴊ�ݑ�L�b�N
[State -1]
type = ChangeState
value = 450
triggerall = (command = "c" && command = "holddown") || var(55) = 450
triggerall = var(50) = 0
triggerall = StateType != A
trigger1 = ctrl 
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = 450
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 450
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger4 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger5 = Stateno = 220 && Animelemtime(8) <= 0 && var(38) = 220
trigger6 = Stateno = 221 && Animelemtime(7) <= 0 && var(38) = 221
trigger7 = stateno = 225 && Animelemtime(6) <= 0 && var(38) = 225
trigger8 = stateno = 225 && Animelemtime(8) <= 0 && var(38) = 10225
trigger9 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger10 = Stateno = 240 && Animelemtime(6) <= 0 && var(38) = 240
trigger11 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger12 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger13 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger14 = stateno = 420 && Animelemtime(4) <= 0 && var(38) = 420
trigger15 = Stateno = 420 && Animelemtime(7) <= 0 && var(38) = 10420
trigger16 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger17 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
trigger18 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger19 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

;����������������������������������������������������������������������������������
;���Ⴊ�ݒ��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = (command = "b" && command = "holddown") || var(55) = 440
triggerall = var(50) = 0
triggerall = StateType != A
trigger1 = ctrl 
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) >= 1
ignorehitpause = 0

[State -1]
type = ChangeState
value = 440
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 440
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger4 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger5 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger6 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger7 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger8 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger9 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger10 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

;����������������������������������������������������������������������������������
;���Ⴊ�ݏ��L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = (command = "a" && command = "holddown") || var(55) = 430
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = !var(13)
trigger1 = ctrl 
trigger2 = Stateno = 200
trigger2 = Animelemtime(5) >= 0
trigger3 = Stateno = 205
trigger3 = Animelemtime(8) >= 1
trigger4 = Stateno = 400
trigger4 = Animelemtime(5) >= 0
trigger5 = Stateno = 430
trigger5 = Animelemtime(5) >= 0
trigger6 = stateno = 100
trigger6 = AnimelemTime(5) >= 1
ignorehitpause = 0

;�A�ŃL�����Z��
[State -1]
type = ChangeState
value = 430
triggerall = var(58) = 430
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = !var(13)
triggerall = var(38)
trigger1 = Stateno = 200
trigger2 = Stateno = 400
trigger3 = Stateno = 430
ignorehitpause = 0

[State -1]
type = ChangeState
value = 430
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = numhelper(30000)
triggerall = helper(30000),var(5) = 1
triggerall = var(58) = 430
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
ignorehitpause = 0

;�����W�����v�U��������������������������������������������������������������������

;�W�����v��p���`
[State -1]
type = ChangeState
value = ifelse(vel X=0,620,625)
trigger1 = command = "z" || var(26) = 620
trigger1 = var(50) = 0
trigger1 = StateType = A
trigger1 = ctrl
ignorehitpause = 0

[State -1]
type = ChangeState
value = ifelse(vel X=0,620,625)
triggerall = var(50) = 0
triggerall = StateType = A
triggerall = numhelper(30000)
triggerall = helper(30000),var(6) = 1
triggerall = var(47) = 620
triggerall = var(38)
triggerall = !var(13)
trigger1 = Stateno = 600
trigger2 = Stateno = 605
trigger3 = Stateno = 610
trigger4 = Stateno = 615
trigger5 = Stateno = 630
trigger6 = Stateno = 635
trigger7 = Stateno = 640
trigger8 = Stateno = 645
trigger9 = Stateno = 910
ignorehitpause = 0

;����������������������������������������������������������������������������������
;�W�����v���p���`
[State -1]
type = ChangeState
value = ifelse(vel X=0,615,610)
trigger1 = command = "y" || var(26) = 610
trigger1 = var(50) = 0
trigger1 = StateType = A
trigger1 = ctrl
ignorehitpause = 0

[State -1]
type = ChangeState
value = ifelse(vel X=0,615,610)
triggerall = var(50) = 0
triggerall = StateType = A
triggerall = numhelper(30000)
triggerall = helper(30000),var(6) = 1
triggerall = var(47) = 610
triggerall = var(38)
triggerall = !var(13)
trigger1 = Stateno = 600
trigger2 = Stateno = 605
trigger3 = Stateno = 630
trigger4 = Stateno = 635
ignorehitpause = 0

;����������������������������������������������������������������������������������
;�W�����v���p���`
[State -1]
type = ChangeState
value = ifelse(vel X=0,605,600)
trigger1 = command = "x" || var(26) = 600
trigger1 = var(50) = 0
trigger1 = StateType = A
trigger1 = ctrl
ignorehitpause = 0

;����������������������������������������������������������������������������������
;�W�����v��L�b�N
[State -1]
type = ChangeState
value = ifelse(vel X=0,655,650)
trigger1 = command = "c" || var(26) = 650
trigger1 = var(50) = 0
trigger1 = StateType = A
trigger1 = ctrl
ignorehitpause = 0

[State -1]
type = ChangeState
value = ifelse(vel X=0,655,650)
triggerall = var(50) = 0
triggerall = StateType = A
triggerall = numhelper(30000)
triggerall = helper(30000),var(6) = 1
triggerall = var(47) = 650
triggerall = var(38)
triggerall = !var(13)
trigger1 = Stateno = 600
trigger2 = Stateno = 605
trigger3 = Stateno = 610
trigger4 = Stateno = 615
trigger5 = Stateno = 620
trigger6 = Stateno = 625
trigger7 = Stateno = 630
trigger8 = Stateno = 635
trigger9 = Stateno = 640
trigger10 = Stateno = 645
trigger11 = Stateno = 910
ignorehitpause = 0

;����������������������������������������������������������������������������������
;�V����n�r
[State -1]
type = ChangeState
value = 910
triggerall = (Vel X > 0 && Command = "b" && Command = "holddown") || Var(37) = 910
triggerall = vel X >= 0
triggerall = var(50) = 0
triggerall = StateType = A
triggerall = pos Y <= -76*const(size.yscale)
trigger1 = ctrl
ignorehitpause = 0

[State -1]
type = ChangeState
value = 910
triggerall = var(50) = 0
triggerall = StateType = A
triggerall = Vel X > 0
triggerall = pos Y <= -80
triggerall = numhelper(30000)
triggerall = helper(30000),var(6) = 1
triggerall = var(47) = 910
triggerall = var(38)
triggerall = !var(13)
trigger1 = Stateno = 600
trigger2 = Stateno = 605
trigger3 = Stateno = 610
trigger4 = Stateno = 615
trigger5 = Stateno = 630
trigger6 = Stateno = 635
ignorehitpause = 0

;�W�����v���L�b�N
[State -1]
type = ChangeState
value = ifelse(vel X=0,645,640)
trigger1 = command = "b" || var(26) = 640
trigger1 = var(50) = 0
trigger1 = StateType = A
trigger1 = ctrl
ignorehitpause = 0

[State -1]
type = ChangeState
value = ifelse(vel X=0,645,640)
triggerall = var(50) = 0
triggerall = StateType = A
triggerall = numhelper(30000)
triggerall = helper(30000),var(6) = 1
triggerall = var(47) = 640
triggerall = var(38)
triggerall = !var(13)
trigger1 = Stateno = 600
trigger2 = Stateno = 605
trigger3 = Stateno = 610
trigger4 = Stateno = 615
trigger5 = Stateno = 630
trigger6 = Stateno = 635
ignorehitpause = 0

;����������������������������������������������������������������������������������
;�W�������L�b�N
[State -1]
type = ChangeState
value = ifelse(vel X=0,635,630)
trigger1 = command = "a" || var(26) = 630
trigger1 = var(50) = 0
trigger1 = StateType = A
trigger1 = ctrl
ignorehitpause = 0


;�����X�e�b�v�ړ�������������������������������������������������������������������

; �O�X�e�b�v
[State -1]
type = ChangeState
value = ifelse(p2dist X >= 0,100,105)
trigger1 = var(55) = 100
trigger1 = command != "holddown"
trigger1 = var(50) = 0
trigger1 = statetype != A
trigger1 = ctrl
ignorehitpause = 0

; ��X�e�b�v
[State -1]
type = ChangeState
value = ifelse(p2dist X >= 0,105,100)
trigger1 = var(55) = 105
trigger1 = command != "holddown"
trigger1 = var(50) = 0
trigger1 = statetype != A
trigger1 = ctrl
ignorehitpause = 0


[State -1]
type = ChangeState
value = var(58)
triggerall = numhelper(30000)
triggerall = helper(30000),var(9) = 1
triggerall = var(50) = 0
triggerall = StateType != A
triggerall = var(58) = 100 || var(58) = 105
triggerall = !var(13)
trigger1 = stateno = 200 && Animelemtime(5) <= 0 && var(38) = 200
trigger2 = stateno = 205 && Animelemtime(6) <= 0 && var(38) = 205
trigger3 = Stateno = 210 && Animelemtime(6) <= 0 && var(38) = 210
trigger4 = stateno = 215 && Animelemtime(7) <= 0 && var(38) = 215
trigger5 = Stateno = 220 && Animelemtime(8) <= 0 && var(38) = 220
trigger6 = Stateno = 221 && Animelemtime(7) <= 0 && var(38) = 221
trigger7 = stateno = 225 && Animelemtime(6) <= 0 && var(38) = 225
trigger8 = stateno = 225 && Animelemtime(8) <= 0 && var(38) = 10225
trigger9 = Stateno = 230 && Animelemtime(5) <= 0 && var(38) = 230
trigger10 = Stateno = 240 && Animelemtime(6) <= 0 && var(38) = 240
trigger11 = stateno = 245 && Animelemtime(7) <= 0 && var(38) = 245
trigger12 = Stateno = 250 && Animelemtime(10) <= 0 && var(38) = 250
trigger13 = Stateno = 255 && Animelemtime(6) <= 0 && var(38) = 255
trigger14 = Stateno = 255 && Animelemtime(12) <= 0 && var(38) = 256
trigger15 = stateno = 400 && Animelemtime(5) <= 0 && var(38) = 400
trigger16 = stateno = 410 && Animelemtime(5) <= 0 && var(38) = 410
trigger17 = stateno = 420 && Animelemtime(4) <= 0 && var(38) = 420
trigger18 = Stateno = 420 && Animelemtime(7) <= 0 && var(38) = 10420
trigger19 = stateno = 430 && Animelemtime(5) <= 0 && var(38) = 430
trigger20 = stateno = 440 && Animelemtime(9) <= 0 && var(38) = 440
trigger21 = Stateno = 450 && Animelemtime(7) <= 0 && var(38) = 450
trigger22 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 900
trigger23 = Stateno = 900 && Animelemtime(6) <= 0 && var(38) = 901
ignorehitpause = 0

;����������������������������������������������������������������������������������
;��s���͉���
[State -1, Varset]
type = Varset
trigger1 = !var(13)
trigger1 = !Var(56)
trigger1 = !fvar(19)
trigger1 = !fvar(16)
var(55) = 0

[State -1, Varset]
type = Varset
trigger1 = var(55) = 0
var(57) = 0

[State -1, VarSet]
type = VarSet
trigger1 = !var(13)
trigger1 = !var(38)
trigger1 = var(58)
var(58) = 0

[State -1, Varset]
type = Varset
trigger1 = !var(13)
trigger1 = !Var(27)
trigger1 = !fvar(16)
var(26) = 0

[State -1, Varset]
type = Varset
trigger1 = Var(26) = 0
var(28) = 0

[State -1, VarSet]
type = VarSet
trigger1 = !var(13)
trigger1 = !var(38)
trigger1 = var(47)
var(47) = 0

;����AI���쁢��������������������������������������������������������������������
[State -1, ���̎���v�Ē�]
type = VarRandom
trigger1 = roundstate = 2
trigger1 = var(50) = 1
trigger1 = statetype != A
v = 51
range = 0,99

[State -1, ���̎���v�Ē�]
type = VarRandom
trigger1 = roundstate = 2
trigger1 = var(50) = 1
trigger1 = statetype = A
v = 51
range = 100,199

;�����u��
[State -2, HitOverride] 
type = HitOverride
triggerall = var(50) = 1
triggerall = statetype != A
triggerall = stateno != [40,50]
trigger1 = (ctrl||stateno=21||((stateno = [4000,4115])&&time>5)) && fvar(31) && random < 250+var(22)*50
trigger2 = (stateno = [120,131]) && random < 150
trigger3 = (stateno = [4000,4115]) && time<=5 && random < 750
trigger4 = (stateno = [6150,6153]) && fvar(32) && random < 300+var(22)*100
trigger5 = numhelper(30000) && helper(30000),var(4) = 1
trigger5 = (stateno = [150,153]) && fvar(32) && random < 300+var(22)*100
slot = 0
attr = SA, NA, SA, HA
stateno = 4000
time = 1

[State -2, HitOverride] 
type = HitOverride
triggerall = var(50) = 1
triggerall = statetype != A
triggerall = stateno != [40,50]
trigger1 = (ctrl||stateno=21||((stateno = [4000,4115])&&time>5)) && fvar(31) && random < 250+P2BodyDist X+var(22)*50
trigger2 = (stateno = [120,131]) && random < 150+p2bodydist X+var(22)*50
trigger3 = (stateno = [4000,4115]) && time<=5 && random < 750
trigger4 = (stateno = [6150,6153]) && fvar(32) && random < 300+P2BodyDist X+var(22)*100
trigger5 = numhelper(30000) && helper(30000),var(4) = 1
trigger5 = (stateno = [150,153]) && fvar(32) && random < 300+P2BodyDist X+var(22)*100
slot = 1
attr = SA, NP, SP
stateno = 4010
time = 1

[State -2, HitOverride] 
type = HitOverride
triggerall = var(50) = 1
triggerall = statetype != A
triggerall = stateno != [40,50]
trigger1 = (ctrl||stateno=21||((stateno = [4000,4115])&&time>5)) && fvar(31) && random < 250+P2BodyDist X+var(22)*50
trigger2 = (stateno = [4000,4115]) && time<=5 && random < 750
trigger3 = (stateno = [6150,6153]) && fvar(32) && random < 300+P2BodyDist X+var(22)*100
trigger4 = numhelper(30000) && helper(30000),var(4) = 1
trigger4 = (stateno = [150,153]) && fvar(32) && random < 300+P2BodyDist X+var(22)*100
slot = 6
attr = SA, HP
stateno = 4010
time = 1

;���u��
[State -2, HitOverride]
type = HitOverride
triggerall = var(50) = 1
triggerall = statetype != A
triggerall = stateno != [40,50]
trigger1 = (ctrl||stateno=21||((stateno = [4000,4115])&&time>5)) && fvar(31) && random < 250+var(22)*50
trigger2 = (stateno = [120,131]) && random < 150+var(22)*50
trigger3 = (stateno = [4000,4115]) && time<=5 && random < 750
trigger4 = (stateno = [6150,6153]) && fvar(32) && random < 250+var(22)*50
trigger5 = numhelper(30000) && helper(30000),var(4) = 1
trigger5 = (stateno = [150,153]) && fvar(32) && random < 250+var(22)*50
slot = 2
attr = C, NA, SA, HA
stateno = 4100
time = 1

[State -2, HitOverride]
type = HitOverride
triggerall = var(50) = 1
triggerall = statetype != A
triggerall = stateno != [40,50]
trigger1 = (ctrl||stateno=21||((stateno = [4000,4115])&&time>5)) && fvar(31) && random < 250+P2BodyDist X+var(22)*50
trigger2 = (stateno = [120,131]) && random < 150+p2bodydist X+var(22)*50
trigger3 = (stateno = [4000,4115]) && time<=5 && random < 750
trigger4 = (stateno = [6150,6153]) && fvar(32) && random < 250+P2BodyDist X+var(22)*50
trigger5 = numhelper(30000) && helper(30000),var(4) = 1
trigger5 = (stateno = [150,153]) && fvar(32) && random < 250+P2BodyDist X+var(22)*50
slot = 3
attr = C, NP, SP
stateno = 4110
time = 1

[State -2, HitOverride]
type = HitOverride
triggerall = var(50) = 1
triggerall = statetype != A
triggerall = stateno != [40,50]
trigger1 = (ctrl||stateno=21||((stateno = [4000,4115])&&time>5)) && fvar(31) && random < 250+P2BodyDist X+var(22)*50
trigger2 = (stateno = [4000,4115]) && time<=5 && random < 750
trigger3 = (stateno = [6150,6153]) && fvar(32) && random < 250+P2BodyDist X+var(22)*50
trigger4 = numhelper(30000) && helper(30000),var(4) = 1
trigger4 = (stateno = [150,153]) && fvar(32) && random < 250+P2BodyDist X+var(22)*50
slot = 7
attr = C, HP
stateno = 4110
time = 1

;�󒆃u��
[State -2, HitOverride]
type = HitOverride
triggerall = var(50) = 1
triggerall = statetype = A
trigger1 = (ctrl||(stateno=5040&&var(0)=1)||(stateno=5040&&Hitover=1)||((stateno = [4200,4205])&&time>5)) && fvar(31) && random < 300+var(22)*50
trigger2 = (stateno = [4200,4205]) && time<=5 && random < 750
trigger3 = (stateno = [6154,6155]) && fvar(32) && random < 300+var(22)*50
trigger4 = numhelper(30000) && helper(30000),var(4) = 1
trigger4 = (stateno = [154,155]) && fvar(32) && random < 300+var(22)*50
slot = 4
attr = SCA, AA
stateno = 4200
time = 1

[State -2, HitOverride]
type = HitOverride
triggerall = var(50) = 1
triggerall = statetype = A
trigger1 = (ctrl||(stateno=5040&&var(0)=1)||(stateno=5040&&Hitover=1)||((stateno = [4200,4205])&&time>5)) && fvar(31) && random < 300+P2BodyDist X+var(22)*50
trigger2 = (stateno = [4200,4205]) && time<=5 && random < 750
trigger3 = (stateno = [6154,6155]) && fvar(32) && random < 300+P2BodyDist X+var(22)*50
trigger4 = numhelper(30000) && helper(30000),var(4) = 1
trigger4 = (stateno = [154,155]) && fvar(32) && random < 300+P2BodyDist X+var(22)*50
slot = 5
attr = SCA, AP
stateno = 4205
time = 1

[State -1, �K�[�h]
type = changestate
value = 120
triggerall = var(50) = 1
triggerall = StateNo != [120,155]
triggerall = StateNo != [40,50]
triggerall = ctrl || stateno = 21
triggerall = statetype != A
triggerall = inguarddist
trigger1 = Random <= 300
trigger2 = enemy,numproj > 0
trigger2 = Random <= 400
trigger3 = P2BodyDist X > 90
trigger3 = Random <= 500
trigger4 = EnemyNear,Time > 50
trigger4 = Random <= 600
ctrl = 0

[State -1, velset]
type = velset
trigger1 = var(50) = 1
trigger1 = stateno = [120,132]
trigger1 = statetype != A
x = 0

[State -1, ��������a]
type = ChangeState
value = 3500
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(22) = 1
triggerall = Power >= 2240+(!var(2))*320
triggerall = StateType != A
triggerall = P2StateType != L
triggerall = !var(13) 
trigger1 = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(40*const(size.xscale))]
trigger1 = var(51) = [95,100)
trigger1 = P2StateType != A
trigger1 = movetype = I
trigger1 = ctrl||stateno=21||stateno=[120,131]
trigger2 = P2BodyDist X = [ceil(30*const(size.xscale)),ceil(80*const(size.xscale))]
trigger2 = P2BodyDist Y = [ceil(-120*const(size.yscale)),ceil(120*const(size.yscale))]
trigger2 = var(51) = [90,100)
trigger2 = P2StateType = A
trigger2 = P2StateNo != [821,823]
trigger2 = enemy,vel X > 0
trigger2 = movetype = I
trigger2 = ctrl||stateno=21||stateno=[120,131]
ignorehitpause = 0

[State -1, �S�S�P]
type = ChangeState
value = 1500
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = StateType != A
triggerall = P2BodyDist Y = [ceil(-70*const(size.yscale)),ceil(70*const(size.yscale))]
triggerall = p2statetype != L
triggerall = !var(13)
triggerall = movetype != H 
trigger1 = var(51) = [10,10+(enemy,numproj>0)*10]
trigger1 = P2BodyDist X >= ceil(25*const(size.xscale))
trigger1 = movetype = I
trigger1 = ctrl||stateno=21
trigger2 = var(51) = [0,100-var(22)*90)
trigger2 = P2BodyDist X >= 0
trigger2 = stateno = 225
trigger2 = Animelemtime(6) <= 0 && var(38) = 225
trigger2 = numtarget(225)
trigger2 = target(225),statetype = A
trigger3 = var(51) = [0,10-var(22)*5)
trigger3 = P2BodyDist X >= 0
trigger3 = stateno = 225
trigger3 = Animelemtime(6) <= 0 && var(38) = 225
trigger3 = numtarget(225)
trigger3 = target(225),statetype != A
trigger4 = var(51) = [0,10 -var(22)*5)
trigger4 = P2BodyDist X >= 0
trigger4 = stateno = 440
trigger4 = Animelemtime(8) <= 0 && var(38) = 420
trigger4 = numtarget(440)
trigger4 = target(440),statetype != A
ignorehitpause = 0

[State -1, �O�_�b�V��]
type = ChangeState
value = 100
trigger1 = RoundState = 2
trigger1 = Enemynear,movetype != A
trigger1 = var(51) = 0
trigger1 = var(50) = 1
trigger1 = random < 200
trigger1 = P2bodydist X = [70+var(22)*30,100+var(22)*30]
trigger1 = statetype != A
trigger1 = p2statetype != L
trigger1 = p2statetype != A
trigger1 = enemy, numproj = 0
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, �������p���`]
type = ChangeState
value = 200
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 1
triggerall = var(51) = 0
triggerall = random < 400
triggerall = P2BodyDist X >= ceil(60*fvar(4))
triggerall = p2statetype != L
triggerall = p2movetype != A
triggerall = Enemy,NumHelper = 0 || Enemy,NumProj = 0
triggerall = !InGuardDist
trigger1 = movetype = I
trigger1 = ctrl || stateno = 21
ignorehitpause = 0

[State -1, ���p���`]
type = ChangeState
value = 210+(random<500)*200
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = statetype != A
triggerall = P2BodyDist X >= ceil(60*const(size.xscale))
triggerall = movetype != H
triggerall = movetype = I
trigger1 = enemy, numproj = 0
trigger1 = Power < 1120+(!var(2))*160
trigger1 = p2statetype = L
trigger1 = p2stateno = [5100,5110]
trigger1 = Random = [0,499]
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, ���p���`]
type = ChangeState
value = 210+(random<500)*200
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = statetype != A
triggerall = P2BodyDist X >= ceil(150*const(size.xscale))
triggerall = movetype != H
triggerall = movetype = I
trigger1 = enemy, numproj = 0
trigger1 = Power < 1120+(!var(2))*160
trigger1 = enemy,statetype != A
trigger1 = enemy,statetype != L
trigger1 = Random = [0,30]
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, �u���E]
type = ChangeState
value = 3600
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = Power >= 2240+(!var(2))*320
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(80*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-70*const(size.yscale)),ceil(70*const(size.yscale))]
triggerall = !var(13) 
trigger1 = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(30*const(size.xscale))]
trigger1 = var(51) = [0,40+var(22)*40)
trigger1 = P2StateType != A
trigger1 = movetype = I
trigger1 = ctrl||stateno=21||stateno=[120,131]
trigger1 = p2movetype = A
trigger2 = var(51) = [0,50)
trigger2 = stateno = 225
trigger2 = Animelemtime(6) >= 0
trigger2 = Animelemtime(10) < 0
trigger2 = numtarget(225)
trigger2 = target(225),statetype = A
trigger3 = var(51) = [0,50)
trigger3 = stateno = 250
trigger3 = Animelemtime(10) >= 0
trigger3 = Animelemtime(12) < 0
trigger3 = numtarget(250)
trigger3 = (target(250),stateno = [5000,5001])||(target(250),stateno = [5600,5610])
trigger4 = var(51) = [0,100)
trigger4 = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(20*const(size.xscale))]
trigger4 = p2movetype != H
trigger4 = P2StateType != A
trigger4 = stateno = 1525
trigger4 = Animelemtime(5) = 1
trigger5 = var(51) = [0,40+var(22)*40)
trigger5 = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(30*const(size.xscale))]
trigger5 = p2movetype = A
trigger5 = P2StateType != A
trigger5 = (stateno = [200,225]) || (stateno = [230,240]) || (stateno = [250,450]) || stateno = 900
trigger6 = var(51) = [0,30)
trigger6 = P2BodyDist X = [ceil(-70*const(size.xscale)),ceil(30*const(size.xscale))]
trigger6 = P2movetype = A
trigger6 = P2statetype != A
trigger6 = fvar(2) < 56
trigger6 = stateno = 5120
trigger6 = AnimElemTime(10) = 0
trigger7 = var(51) = [0,30)
trigger7 = P2BodyDist X = [ceil(-70*const(size.xscale)),ceil(30*const(size.xscale))]
trigger7 = P2movetype = A
trigger7 = P2statetype != A
trigger7 = stateno = 5123
trigger7 = AnimElemTime(10) = 0
trigger8 = var(51) = [0,30)
trigger8 = P2BodyDist X = [ceil(-70*const(size.xscale)),ceil(30*const(size.xscale))]
trigger8 = P2movetype = A
trigger8 = P2statetype != A
trigger8 = stateno = 5124
trigger8 = AnimElemTime(10) = 0
ignorehitpause = 0

[State -1, �u���E]
type = ChangeState
value = 3600
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = Power >= 2240+(!var(2))*320
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(60*const(size.xscale))]
triggerall = !var(13) 
triggerall = P2StateType != A
triggerall = p2movetype = A
trigger1 = var(51) = [70,85)
trigger1 = stateno = [4000,4015]
trigger1 = animelemtime(4) = 0
trigger2 = var(51) = [70,85)
trigger2 = stateno = [4100,4115]
trigger2 = animelemtime(4) = 0
trigger3 = var(51) = [70,85)
trigger3 = stateno = 200 || stateno = 900
ignorehitpause = 0

[State -1, �ŎE������]
type = ChangeState
value = 3200
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(2) = 0 || var(2) = 2
triggerall = Power >= 1120+(!var(2))*160
triggerall = StateType != A
triggerall = !var(13) 
trigger1 = var(51) = [0,100)
trigger1 = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(40*const(size.xscale))]
trigger1 = fvar(38) >= 2
trigger1 = Stateno = 430
trigger1 = Animelemtime(5) <= 0 && var(38) = 430
trigger1 = numtarget(430)
trigger1 = target(430),stateno = [5000,5011]
trigger2 = var(51) = [50,100)
trigger2 = P2BodyDist X = [ceil(-60*const(size.xscale)),ceil(15*const(size.xscale))]
trigger2 = P2movetype = A
trigger2 = P2statetype != A
trigger2 = fvar(2) < 56
trigger2 = stateno = 5120
trigger2 = AnimElemTime(10) = 0
trigger3 = var(51) = [50,100)
trigger3 = P2BodyDist X = [ceil(-60*const(size.xscale)),ceil(15*const(size.xscale))]
trigger3 = P2movetype = A
trigger3 = P2statetype != A
trigger3 = stateno = 5123
trigger3 = AnimElemTime(10) = 0
trigger4 = var(51) = [50,100)
trigger4 = P2BodyDist X = [ceil(-60*const(size.xscale)),ceil(15*const(size.xscale))]
trigger4 = P2movetype = A
trigger4 = P2statetype != A
trigger4 = stateno = 5124
trigger4 = AnimElemTime(10) = 0
ignorehitpause = 0

[State -1, �ŎE������]
type = ChangeState
value = 3200
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(2) = 0 || var(2) = 2
triggerall = Power >= 1120+(!var(2))*160
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(40*const(size.xscale))]
triggerall = !var(13) 
triggerall = P2movetype = A
triggerall = P2statetype != A
trigger1 = var(51) = [50,57)
trigger1 = movetype = I
trigger1 = ctrl||stateno=21||stateno=[120,131]
trigger2 = var(51) = [50,55)
trigger2 = stateno = [4000,4015]
trigger2 = animelemtime(4) = 0
trigger3 = var(51) = [50,55)
trigger3 = stateno = [4100,4115]
trigger3 = animelemtime(4) = 0
ignorehitpause = 0

[State -1, �ŎE���g��]
type = ChangeState
value = 3000
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [0,100)
triggerall = var(2) = 0 || var(2) = 1
triggerall = Power >= 1120+(!var(2))*160
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(80*const(size.xscale))]
triggerall = !var(13) 
trigger1 = fvar(38) >= 2
trigger1 = Stateno = 430
trigger1 = Animelemtime(5) <= 0 && var(38) = 430
trigger1 = numtarget(430)
trigger1 = target(430),stateno = [5000,5011]
ignorehitpause = 0

[State -1, ����]
type = ChangeState
value = 800
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [0,20+(enemy,BackEdgeBodyDist<=5)*20]
triggerall = fvar(39) != [1,12]
triggerall = fvar(21) <= 2
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(15*const(size.xscale))]
triggerall = p2statetype != A
triggerall = p2statetype != L
triggerall = p2movetype != H
trigger1 = movetype = I
trigger1 = ctrl||stateno=21||stateno=[120,131]
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) = 1
ignorehitpause = 0

[State -1, ���Ⴊ�ݏ��L�b�N]
type = ChangeState
value = 430
triggerall = roundstate = 2
triggerall = Power >= 1120+(!var(2))*160
triggerall = var(50) = 1
triggerall = P2BodyDist X = (ceil(-10*const(size.xscale)),ceil(20*const(size.xscale))]
triggerall = statetype != A
triggerall = p2statetype != L
triggerall = p2statetype != A
triggerall = !var(13) 
trigger1 = Random = [0,200)
trigger1 = movetype = I
trigger1 = ctrl||stateno=21||(((stateno=[4000,4015])||(stateno=[4100,4115]))&&animelemtime(4)=0)||stateno=[120,131]
trigger2 = Random = [0,200)
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) = 1
trigger3 = Random = [0,1000)
trigger3 = fvar(38) < 2
trigger3 = Stateno = 430
trigger3 = var(38) = 430
trigger3 = numtarget(430)
ignorehitpause = 0

[State -1, �ŎE���a��]
type = ChangeState
value = 3100
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [100,150)
triggerall = var(2) = 0 || var(2) = 1
triggerall = Power >= 1120+(!var(2))*160
triggerall = StateType = A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(60*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(10*const(size.yscale)),ceil(60*const(size.yscale))]
triggerall = !var(13) 
trigger1 = stateno = 1320
trigger1 = var(38)
trigger1 = numtarget
trigger1 = target,statetype = A
ignorehitpause = 0

[State -1, �ŎE���g��]
type = ChangeState
value = 3000
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [0,40)
triggerall = var(2) = 0 || var(2) = 1
triggerall = Power >= 1120+(!var(2))*160
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(50*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-70*const(size.yscale)),ceil(70*const(size.yscale))]
triggerall = !var(13) 
trigger1 = stateno = 1100
trigger1 = Animelemtime(4) <= 0 && var(38) = 1100
trigger1 = numtarget(1100)
trigger1 = target(1100),statetype = A
ignorehitpause = 0

[State -1, �ŎE������]
type = ChangeState
value = 3300
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [0,50)
triggerall = var(2) = 0 || var(2) = 3
triggerall = Power >= 1120+(!var(2))*160
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(20*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-60*const(size.yscale)),ceil(60*const(size.yscale))]
triggerall = !var(13) 
triggerall = movetype = I
triggerall = ctrl||stateno=21
trigger1 = numtarget(1200)
trigger1 = target(1200),statetype = A
trigger2 = numtarget(1320)
trigger2 = target(1320),statetype = A
trigger3 = numtarget(1321)
trigger3 = target(1321),statetype = A
ignorehitpause = 0

[State -1, �ŎE������]
type = ChangeState
value = 3400
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [150,200)
triggerall = var(2) = 0 || var(2) = 3
triggerall = Power >= 1120+(!var(2))*160
triggerall = StateType = A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(70*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-60*const(size.yscale)),ceil(40*const(size.yscale))]
triggerall = !var(13) 
trigger1 = stateno = 1320
trigger1 = var(38)
trigger1 = numtarget
trigger1 = target,statetype = A
ignorehitpause = 0

[State -1, ������p���`(��)]
type = ChangeState
value = 225
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [0,40)
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(20*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-60*const(size.yscale)),ceil(60*const(size.yscale))]
triggerall = !var(13) 
triggerall = movetype = I
triggerall = ctrl||stateno=21
trigger1 = numtarget(1200)
trigger1 = target(1200),statetype = A
trigger2 = numtarget(1320)
trigger2 = target(1320),statetype = A
trigger3 = numtarget(1321)
trigger3 = target(1321),statetype = A
ignorehitpause = 0

[State -1, ������]
type = ChangeState
value = 1100+(random<50)*10+(random<200)*10
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 1
triggerall = P2BodyDist Y = [ceil(-130*const(size.yscale)),0]
triggerall = enemy, numproj = 0
triggerall = p2statetype != L
triggerall = !var(13)
triggerall = var(5) = 0
triggerall = movetype != H 
triggerall = P2BodyDist X = [ceil((-20+(enemynear,vel X>0)*20)*const(size.xscale)),ceil(45*const(size.xscale))]
triggerall = movetype = I
triggerall = ctrl||stateno=21||stateno=[120,131]
trigger1 = var(51) = [30,30+(p2movetype=A)*4]
trigger1 = enemynear,stateno != [120,155]
trigger2 = var(51) = [30,59]
trigger2 = numtarget(1200)
trigger2 = target(1200),statetype = A
trigger3 = var(51) = [30,59]
trigger3 = numtarget(1320)
trigger3 = target(1320),statetype = A
trigger4 = var(51) = [30,59]
trigger4 = numtarget(1321)
trigger4 = target(1321),statetype = A
trigger5 = var(51) = [30,80]
trigger5 = p2movetype = A
trigger5 = stateno = 100
trigger5 = AnimElemTime(5) = 1
trigger6 = var(51) = [30,80]
trigger6 = p2movetype = A
trigger6 = stateno = [4000,4015]
trigger6 = animelemtime(4) = 0
trigger7 = var(51) = [30,80]
trigger7 = p2movetype = A
trigger7 = stateno = [4100,4115]
trigger7 = animelemtime(4) = 0
ignorehitpause = 0

[State -1, ������]
type = ChangeState
value = 1100+(random<50)*10+(random<200)*10
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 1
triggerall = P2BodyDist Y = [ceil(-130*const(size.yscale)),0]
triggerall = enemy, numproj = 0
triggerall = p2statetype != L
triggerall = !var(13)
triggerall = var(5) = 0
triggerall = movetype != H 
triggerall = P2BodyDist X = [ceil((-20+(enemynear,vel X>0)*20)*const(size.xscale)),ceil(45*const(size.xscale))]
triggerall = p2movetype = A
triggerall = var(51) = [30,80]
trigger1 = stateno = [4000,4015]
trigger1 = animelemtime(4) = 0
trigger2 = stateno = [4100,4115]
trigger2 = animelemtime(4) = 0
ignorehitpause = 0

[State -1, ���Ⴊ�ݑ�p���`]
type = ChangeState
value = 420
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 1
triggerall = P2BodyDist Y = [ceil(-120*const(size.yscale)),ceil(-50*const(size.yscale))]
triggerall = enemy, numproj = 0
triggerall = p2statetype != L
triggerall = !var(13)
triggerall = var(5) = 0
triggerall = movetype != H 
trigger1 = P2BodyDist X = [ceil((-10+(enemynear,vel X>0)*10)*const(size.xscale)),ceil(20*const(size.xscale))]
trigger1 = var(51) = [40,44]
trigger1 = movetype = I
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, ������]
type = ChangeState
value = 1100+(P2BodyDist X<=ceil(10*const(size.xscale)))*10+(P2BodyDist X<=ceil(5*const(size.xscale)))*10
triggerall = roundstate = 2
triggerall = StateType != A
triggerall = var(50) = 1
triggerall = P2BodyDist Y = [ceil(-130*const(size.yscale)),0]
triggerall = enemy, numproj = 0
triggerall = p2statetype != L
triggerall = !var(13)
triggerall = movetype != H 
trigger1 = var(51) = [0,40)
trigger1 = P2BodyDist X = [ceil(-60*const(size.xscale)),ceil(15*const(size.xscale))]
trigger1 = stateno = [4000,4115]
trigger1 = Animelemtime(4) = 0
trigger2 = var(51) = [0,40)
trigger2 = P2BodyDist X = [ceil(-60*const(size.xscale)),ceil(15*const(size.xscale))]
trigger2 = P2movetype = A
trigger2 = fvar(2) < 56
trigger2 = stateno = 5120
trigger2 = AnimElemTime(10) = 0
trigger3 = var(51) = [0,40)
trigger3 = P2BodyDist X = [ceil(-60*const(size.xscale)),ceil(15*const(size.xscale))]
trigger3 = P2movetype = A
trigger3 = stateno = 5123
trigger3 = AnimElemTime(10) = 0
trigger4 = var(51) = [0,40)
trigger4 = P2BodyDist X = [ceil(-60*const(size.xscale)),ceil(15*const(size.xscale))]
trigger4 = P2movetype = A
trigger4 = stateno = 5124
trigger4 = AnimElemTime(10) = 0
ignorehitpause = 0

[State -1, ������]
type = ChangeState
value = 1100
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [0,100)
triggerall = StateType != A
triggerall = Power < 2240+(!var(2))*320
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(20*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-60*const(size.yscale)),ceil(60*const(size.yscale))]
triggerall = !var(13) 
triggerall = movetype = I
triggerall = ctrl||stateno=21||stateno=[120,131]
trigger1 = numtarget(1200)
trigger1 = target(1200),statetype = A
trigger2 = numtarget(1320)
trigger2 = target(1320),statetype = A
trigger3 = numtarget(1321)
trigger3 = target(1321),statetype = A
ignorehitpause = 0

[State -1, ������]
type = ChangeState
value = 1200
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = StateType != A
triggerall = P2BodyDist X = [ ceil(-10*const(size.xscale)),ceil(70*const(size.xscale))]
triggerall = p2statetype = S
triggerall = !var(13)
trigger1 = var(51) = [0,30)
trigger1 = stateno = 225
trigger1 = Animelemtime(6) <= 0
trigger1 = numtarget(225)
trigger1 = target(225),stateno = [5000,5011]
trigger2 = var(51) = [0,100)
trigger2 = stateno = 440
trigger2 = Animelemtime(8) <= 0
trigger2 = numtarget(440)
trigger2 = target(440),stateno = [5000,5011]
ignorehitpause = 0

[State -1, ������]
type = ChangeState
value = 1100+(P2BodyDist X<=ceil(10*const(size.xscale)))*10+(P2BodyDist X<=ceil(5*const(size.xscale)))*10
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [0,100)
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(15*const(size.xscale))]
triggerall = !var(13) 
triggerall = var(38)
trigger1 = stateno = 225
trigger1 = Animelemtime(6) <= 0
trigger1 = numtarget(225)
trigger1 = target(225),stateno = [5000,5011]
trigger2 = stateno = 245
trigger2 = Animelemtime(7) <= 0
trigger2 = numtarget(245)
trigger2 = target(245),stateno = [5000,5011]
ignorehitpause = 0

[State -1, ������]
type = ChangeState
value = 1210+random%2*10
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = var(51) = [0,100)
triggerall = StateType != A
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(20*const(size.xscale))]
triggerall = p2statetype = S
triggerall = !var(13) 
trigger1 = stateno = 215
trigger1 = Animelemtime(7) <= 0
trigger1 = numtarget(215)
trigger1 = target(215),stateno = [5000,5001]
trigger2 = stateno = 245
trigger2 = Animelemtime(7) <= 0
trigger2 = numtarget(245)
trigger2 = target(245),stateno = [5000,5001]
ignorehitpause = 0

[State -1, �g����]
type = ChangeState
value = 1000+random%3*10
triggerall = roundstate = 2
triggerall = fvar(36) = 0
triggerall = var(50) = 1
triggerall = StateType != A
triggerall = p2statetype != L
triggerall = !var(13)
trigger1 = var(5) = 0
trigger1 = P2BodyDist X > ceil(20*const(size.xscale))+(enemy,BackEdgeBodyDist<=10)*100
trigger1 = P2BodyDist Y >= ceil(-20*const(size.yscale))
trigger1 = movetype != H
trigger1 = var(51) = 0
trigger1 = movetype = I
trigger1 = ctrl||stateno=21
trigger2 = p2statetype != A
trigger2 = stateno = 225
trigger2 = Animelemtime(6) <= 0
trigger2 = numtarget(225)
trigger2 = target(225),BackEdgeBodyDist >= 10
trigger2 = var(38) = 225
trigger3 = p2statetype != A
trigger3 = stateno = 440
trigger3 = Animelemtime(8) <= 0
trigger3 = numtarget(440)
trigger3 = target(440),BackEdgeBodyDist >= 10
trigger3 = var(38) = 440
trigger4 = p2statetype != A
trigger4 = stateno = 215
trigger4 = Animelemtime(7) <= 0
trigger4 = numtarget(215)
trigger4 = target(215),BackEdgeBodyDist >= 10
trigger4 = var(38) = 215
trigger5 = p2statetype != A
trigger5 = stateno = 245
trigger5 = Animelemtime(7) <= 0
trigger5 = numtarget(245)
trigger5 = target(245),BackEdgeBodyDist >= 10
trigger5 = var(38) = 245
ignorehitpause = 0

[State -1, �������p���`(��)]
type = ChangeState
value = 215
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = P2BodyDist X = [0,ceil(15*const(size.xscale))]
triggerall = statetype != A
trigger1 = Random = [500,650]
trigger1 = p2statetype != L
trigger1 = p2statetype != A
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, �������L�b�N(��)]
type = ChangeState
value = 245
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = P2BodyDist X = [0,ceil(20*const(size.xscale))]
triggerall = statetype != A
trigger1 = Random = [800,1000)
trigger1 = p2statetype != L
trigger1 = p2statetype != A
trigger1 = ctrl||stateno=21
trigger2 = Random = [600,1000]
trigger2 = ctrl||stateno=21
trigger2 = numtarget(620)||numtarget(625)||numtarget(650)||numtarget(655)||numtarget(910)||numtarget(1530)||var(14)
ignorehitpause = 0

[State -1, ������p���`(��)]
type = ChangeState
value = 225
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = P2BodyDist X = [0,ceil(25*const(size.xscale))]
triggerall = statetype != A
triggerall = p2statetype != L
triggerall = p2statetype != A
trigger1 = Random = [0,200]
trigger1 = ctrl||stateno=21
trigger2 = Random = [0,200)
trigger2 = stateno = 100
trigger2 = AnimElemTime(5) = 1
trigger3 = Random = [0,400]
trigger3 = ctrl||stateno=21
trigger3 = numtarget(620)||numtarget(625)||numtarget(650)||numtarget(655)||numtarget(910)||numtarget(1530)||var(14)
ignorehitpause = 0

[State -1, ������L�b�N]
type = ChangeState
value = 250
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = P2BodyDist X = [ceil((40+(enemynear,vel X>0)*10)*const(size.xscale)),ceil((70+(enemynear,vel X>0)*10)*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-80*const(size.yscale)),ceil(80*const(size.yscale))]
triggerall = statetype != A
triggerall = var(5) = 0
trigger1 = p2statetype != L
trigger1 = p2statetype != C
trigger1 = Random = [400,410)
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, ���Ⴊ�ݒ��L�b�N]
type = ChangeState
value = 440
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = P2BodyDist X = [0,ceil(70*const(size.xscale))]
triggerall = P2BodyDist Y = 0
triggerall = statetype != A
triggerall = p2statetype != L
triggerall = movetype = I
trigger1 = Random = [100,200-(P2movetype=A)*50]
trigger1 = ctrl||stateno=21||stateno=[120,131]
trigger2 = Random = [100,600]
trigger2 = stateno = [4000,4015]
trigger2 = animelemtime(4) = 0
trigger3 = Random = [100,600]
trigger3 = stateno = [4100,4115]
trigger3 = animelemtime(4) = 0
trigger4 = Random = [0,600]
trigger4 = ctrl||stateno=21
trigger4 = numtarget(620)||numtarget(625)||numtarget(650)||numtarget(655)||numtarget(1530)||var(14)
ignorehitpause = 0

[State -1, ���Ⴊ�ݑ�L�b�N]
type = ChangeState
value = 450
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = P2BodyDist X = [ceil(80*const(size.xscale)),ceil(100*const(size.xscale))]
triggerall = P2BodyDist Y = 0
triggerall = statetype != A
trigger1 = Random = [900,910]
trigger1 = p2statetype != L
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, ���W�j�E]
type = ChangeState
value = 900
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = P2BodyDist X = [0,ceil(10*const(size.xscale))]
triggerall = statetype != A
triggerall = movetype = I
triggerall = p2statetype = C
triggerall = p2movetype != A
trigger1 = Random = [100,180]
trigger1 = ctrl||stateno=21
trigger1 = stateno != [130,131]
ignorehitpause = 0

[State -1, ���[�v�A�^�b�N]
type = ChangeState
value = 920
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = P2BodyDist X = [ceil(30*const(size.xscale)),ceil(40*const(size.xscale)))
triggerall = statetype != A
triggerall = movetype = I
triggerall = p2statetype = C
triggerall = p2movetype != A
trigger1 = Random = [100,180]
trigger1 = ctrl||stateno=21
trigger1 = stateno != [130,131]
ignorehitpause = 0

[State -1, �a��g����]
type = ChangeState
value = 1600+random%3*10
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = fvar(36) = 0
triggerall = P2BodyDist Y = [ceil(30*const(size.yscale)),ceil(200*const(size.yscale))]
triggerall = statetype = A
;triggerall = p2statetype != L
triggerall = pos Y <= ceil(-60*const(size.yscale))
triggerall = vel Y >= 0
triggerall = Random = [300-(vel X<=0)*100,1000)
triggerall = ctrl
trigger1 = vel X > 0
trigger1 = P2BodyDist X = [ceil(70*const(size.xscale)),ceil(150*const(size.xscale))]
trigger2 = vel X = 0
trigger2 = P2BodyDist X = [ceil(100*const(size.xscale)),ceil(200*const(size.xscale))]
trigger3 = vel X < 0
trigger3 = P2BodyDist X = [ceil(50*const(size.xscale)),ceil(300*const(size.xscale))]
ignorehitpause = 0

[State -1, �󒆗��������r]
type = ChangeState
value = 1320
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = var(50) = 1
triggerall = p2statetype != L && p2statetype != C
triggerall = P2BodyDist X = [ceil((-70-(vel X<0)*30)*const(size.xscale)),ceil((70+(vel X>0)*50)*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-70*const(size.yscale)),ceil(110*const(size.yscale))]
triggerall = stateno != 5020
triggerall = var(5) = 0
trigger1 = var(51) = [100,100+(p2statetype=A)*5]
trigger1 = vel Y < 0
trigger1 = ctrl
trigger1 = pos Y <= ceil(-70*const(size.yscale))
trigger2 = var(51) = [120,121]
trigger2 = vel Y >= 0
trigger2 = ctrl
trigger2 = pos Y <= ceil(-70*const(size.yscale))
ignorehitpause = 0

[State -1, �V����n�r]
type = ChangeState
value = 910
triggerall = roundstate = 2
triggerall = vel X > 0
triggerall = var(50) = 1
triggerall = P2BodyDist X = [ceil(60*const(size.xscale)),ceil(100*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(10*const(size.yscale)),ceil(120*const(size.yscale))]
triggerall = statetype = A
triggerall = p2statetype = C
triggerall = pos Y <= -76*const(size.yscale)
trigger1 = Random = [0,300)
trigger1 = ctrl
ignorehitpause = 0

[State -1, �W�����v��p���`]
type = ChangeState
value = 625
triggerall = roundstate = 2
triggerall = vel X > 0
triggerall = var(50) = 1
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil((50+(var(3)=1)*15)*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-20*const(size.yscale)),ceil((60+(var(3)=1)*10)*const(size.yscale))]
triggerall = statetype = A
triggerall = movetype = I
triggerall = p2statetype != L
triggerall = ctrl
trigger1 = pos Y = [ceil((-55-(var(3)=1)*15)*const(size.yscale)),ceil((-45-(var(3)=1)*15)*const(size.yscale))]
trigger1 = vel Y > 0
trigger1 = Random = [500,800+(enemynear,ctrl=0)*100)
trigger2 = pos Y = [ceil(-55*const(size.yscale)),ceil(-45*const(size.yscale))]
trigger2 = vel Y > 0
trigger2 = numenemy
trigger2 = enemy,stateno = 7200 || enemy,stateno = [5300,5301]
ignorehitpause = 0

[State -1, �W�����v��p���`]
type = ChangeState
value = 620
triggerall = roundstate = 2
triggerall = vel X = 0
triggerall = var(50) = 1
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(40*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-20*const(size.yscale)),ceil(65*const(size.yscale))]
triggerall = statetype = A
triggerall = movetype = I
triggerall = p2statetype != L
triggerall = ctrl
trigger1 = pos Y = [ceil(-65*const(size.yscale)),ceil(-55*const(size.yscale))]
trigger1 = vel Y > 0
trigger1 = Random = [0,150)
ignorehitpause = 0

[State -1, �W�����v��L�b�N]
type = ChangeState
value = 650
triggerall = roundstate = 2
triggerall = vel X != 0
triggerall = var(50) = 1
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil((100+(vel X>0)*20)*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-20*const(size.yscale)),ceil((60+(var(3)=1)*10)*const(size.yscale))]
triggerall = statetype = A
triggerall = movetype = I
triggerall = p2statetype != L
triggerall = ctrl
trigger1 = pos Y < ceil(-70*const(size.yscale))
trigger1 = time > 5
trigger1 = Random = [0,200)
trigger2 = pos Y = [ceil((-55-(var(3)=1)*15)*const(size.yscale)),ceil((-45-(var(3)=1)*15)*const(size.yscale))]
trigger2 = vel Y > 0
trigger2 = Random = [500,800+(enemynear,ctrl=0)*100)
ignorehitpause = 0

[State -1, �W�����v���L�b�N]
type = ChangeState
value = 645
triggerall = roundstate = 2
triggerall = vel X = 0
triggerall = var(50) = 1
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(80*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-20*const(size.yscale)),ceil(60*const(size.yscale))]
triggerall = statetype = A
triggerall = movetype = I
triggerall = p2statetype != L
triggerall = ctrl
trigger1 = pos Y = [ceil(-60*const(size.yscale)),ceil(-40*const(size.yscale))]
trigger1 = vel Y > 0
trigger1 = Random = [400,600)
ignorehitpause = 0

[State -1, �W�����v��L�b�N]
type = ChangeState
value = 655
triggerall = roundstate = 2
triggerall = vel X = 0
triggerall = var(50) = 1
triggerall = P2BodyDist X = [ceil(-10*const(size.xscale)),ceil(80*const(size.xscale))]
triggerall = P2BodyDist Y = [ceil(-40*const(size.yscale)),ceil(65*const(size.yscale))]
triggerall = statetype = A
triggerall = movetype = I
triggerall = p2statetype != L
triggerall = ctrl
trigger1 = pos Y <= ceil(-60*const(size.yscale))
trigger1 = Random = [0,100)
trigger2 = pos Y = [ceil(-65*const(size.yscale)),ceil(-55*const(size.yscale))]
trigger2 = vel Y > 0
trigger2 = Random = [0,300)
ignorehitpause = 0

[State -1, �W�����v�J�n]
type = ChangeState
value = 40
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = statetype = S
triggerall = movetype = I
trigger1 = ctrl||stateno=21||stateno = [120,131]
trigger1 = P2BodyDist X = [ceil(80*const(size.xscale)),ceil(130*const(size.xscale)))
trigger1 = enemy,statetype != A
trigger1 = enemy,statetype != L
trigger1 = Random < 20+(enemy,numproj>0)*100
trigger1 = fvar(32):= 2
trigger2 = ctrl||stateno=21||stateno = [120,131]
trigger2 = P2BodyDist X = [ceil(150*const(size.xscale)),ceil(200*const(size.xscale)))
trigger2 = enemy,statetype != A
trigger2 = enemy,statetype != L
trigger2 = Random < 10+(enemy,numproj>0)*70
trigger2 = fvar(32):= 2
trigger3 = ctrl||stateno=21
trigger3 = P2BodyDist X < ceil(80*const(size.xscale))
trigger3 = Random < 5
trigger3 = fvar(32):= 3
trigger4 = ctrl||stateno=21
trigger4 = P2BodyDist X > ceil(130*const(size.xscale))
trigger4 = Random < 30
trigger4 = fvar(32):= 3
trigger5 = ctrl||stateno=21||stateno = [120,131]
trigger5 = P2BodyDist X <= 100
trigger5 = Random < 50+(enemynear,hitdefattr=SCA,HT)*350
trigger5 = enemynear,hitdefattr = SCA,NT,ST,HT
trigger5 = fvar(32):= 1

[State -1, ����]
type = ChangeState
value = 1720
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = fvar(29) = 1
triggerall = statetype != A
triggerall = enemy, numproj = 0
triggerall = p2movetype != A
trigger1 = ctrl||stateno=21
trigger1 = P2BodyDist X > 240
trigger1 = Random <= 50
trigger2 = ctrl||stateno=21
trigger2 = Random <= 200
trigger2 = P2BodyDist X > 150
trigger2 = p2statetype = L
trigger2 = p2stateno = [5100,5110]

[State -1, ����]
type = ChangeState
value = 195
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = fvar(29) = 1
triggerall = statetype != A
triggerall = enemy, numproj = 0
triggerall = p2movetype != A
trigger1 = ctrl||stateno=21
trigger1 = P2BodyDist X > 240
trigger1 = Random <= 50
trigger2 = ctrl||stateno=21
trigger2 = Random <= 200
trigger2 = P2BodyDist X > 150
trigger2 = p2statetype = L
trigger2 = p2stateno = [5100,5110]

[State -1, �󒆎�g]
type = ChangeState
value = 5210
triggerall = stateno = 5050
triggerall = roundstate = 2
triggerall = var(50) = 1
triggerall = fvar(2) != 56
triggerall = vel Y > -1
triggerall = alive
triggerall = canrecover
triggerall = pos Y = [-120,-20)
trigger1 = Random < 30
trigger2 = P2BodyDist X = [-90,90]
trigger2 = var(51) = [30,39]
trigger2 = enemy,hitdefattr = SA, AA, AT, AP

[State -1, �O�_�b�V��]
type = ChangeState
value = 1400
trigger1 = RoundState = 2
trigger1 = var(51) = [0,20+var(22)*20]
trigger1 = var(50) = 1
trigger1 = P2bodydist X <= 100
trigger1 = BackEdgeBodyDist <= 10
trigger1 = statetype != A
trigger1 = enemy,movetype = A
trigger1 = movetype = I
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, �O�_�b�V��]
type = ChangeState
value = 1400
trigger1 = RoundState = 2
trigger1 = var(51) = [0,30+var(22)*20]
trigger1 = var(50) = 1
trigger1 = P2bodydist X >= 80
trigger1 = enemy,BackEdgeBodyDist > 100
trigger1 = statetype != A
trigger1 = enemy, movetype = A
trigger1 = movetype = I
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, �O�_�b�V��]
type = ChangeState
value = 1410
trigger1 = RoundState = 2
trigger1 = var(51) = [0,20+var(22)*20]
trigger1 = var(50) = 1
trigger1 = P2bodydist X = [80,120]
trigger1 = enemy,BackEdgeBodyDist > 20
trigger1 = statetype != A
trigger1 = enemy, numproj = 1
trigger1 = movetype = I
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, �O�_�b�V��]
type = ChangeState
value = 100
triggerall = RoundState = 2
triggerall = Enemynear,movetype != A
triggerall = var(51) = [0,1]
triggerall = var(50) = 1
triggerall = P2bodydist X >= 150+var(22)*30
triggerall = statetype != A
triggerall = enemy, numproj = 0
trigger1 = stateno != [100,105]
trigger1 = movetype = I
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, ��_�b�V��]
type = ChangeState
value = 105
triggerall = RoundState = 2
triggerall = Enemy,movetype = A
triggerall = var(50) = 1
triggerall = var(51) = [0,5]
triggerall = P2bodydist X = [70,110)
triggerall = BackEdgeBodyDist > 10
triggerall = statetype != A
triggerall = enemy, numproj = 0
trigger1 = stateno != [100,105]
trigger1 = movetype = I
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, ��_�b�V��]
type = ChangeState
value = ifelse(random<300+var(22)*200,1430,105)
triggerall = RoundState = 2
triggerall = Enemynear,statetype = L
triggerall = var(50) = 1
triggerall = var(51) = [30,59]
triggerall = P2bodydist X < 70
triggerall = BackEdgeBodyDist > 10
triggerall = statetype != A
triggerall = enemy, numproj = 0
trigger1 = stateno != [100,105]
trigger1 = movetype = I
trigger1 = ctrl||stateno=21
ignorehitpause = 0

[State -1, ����]
type = ChangeState
value = 21
trigger1 = roundstate = 2
trigger1 = var(50) = 1
trigger1 = p2bodydist x >= 60
trigger1 = ctrl
trigger1 = random < 200
trigger1 = !InGuardDist
trigger1 = statetype = S
trigger1 = stateno != [120,155]
trigger1 = stateno != [20,21]
trigger1 = stateno != [10,12]
