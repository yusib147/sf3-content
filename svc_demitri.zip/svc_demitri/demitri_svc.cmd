;-| Super Motions |--------------------------------------------------------

[Command]
name = "�~�b�h�i�C�g�v���W���["
command = ~x,x,F,a,b
time = 25

[Command]
name = "�f�����E�t���A"
command = ~D,DF,F,D,DF,F,x+y
time = 25

[Command]
name = "�~�b�h�i�C�g�u���X"
command = ~D,F,DF,x+y
time = 15

[Command]
name = "�d�r�E�J�I�X�t���A"
command = ~D,DF,F,x+y
time = 15

;-| Special Motions |------------------------------------------------------

[Command]
name = "�o�b�g�X�s���E��"
command = ~D,DB,B,b
time = 15

[Command]
name = "�o�b�g�X�s���E��"
command = ~D,DB,B,a
time = 15

[Command]
name = "�f�����N���C�h���E��"
command = ~F,D,DF,y
time = 15

[Command]
name = "�f�����N���C�h���E��"
command = ~F,D,DF,x
time = 15

[Command]
name = "�J�I�X�t���A�E��"
command = ~D,DF,F,y
time = 15

[Command]
name = "�J�I�X�t���A�E��"
command = ~D,DF,F,x
time = 15

[Command]
name = "����ړ��E�O"
command = ~$B,$F,a+y
time = 10

[Command]
name = "����ړ��E��"
command = ~$F,$B,a+y
time = 10

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "BF"
command = $B, $F
time = 10

[Command]
name = "FB"
command = $F, $B
time = 10

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery"
command = x+y
time = 1

[Command]
name = "recovery"
command = a+x
time = 1

[Command]
name = "step"
command = a+y
time = 1

[Command]
name = "�o�b�g�_�C�u"
command = a+x
time = 1

[Command]
name = "���C�g�v���W���["
command = y+b
time = 1

;-| Dir + Button |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

[Command]
name = "down"
command = D
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Statedef -1]

;===========================================================================

;---------------------------------------------------------------------------
; �~�b�h�i�C�g�v���W���[
[State -1]
type = ChangeState
value = 2100
triggerall = power >= 1000
triggerall = command = "�~�b�h�i�C�g�v���W���["
trigger1 = statetype != A && var(0) != 1 && (stateno = 200|stateno = 205|stateno = 230|stateno = 235|stateno = 245)
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact
trigger11 = stateno = [110,116]

; ��L�����p
[State -1]
type = ChangeState
value = 2100
triggerall = power >= 1000
triggerall = command = "�~�b�h�i�C�g�v���W���["
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 2100
triggerall = command = "�~�b�h�i�C�g�v���W���["
triggerall = var(13) > 0
trigger1 = (stateno = 1100|stateno = 1110) && movecontact
trigger2 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �f�����E�t���A
[State -1]
type = ChangeState
value = 2200
triggerall = numproj = 0
triggerall = (var(31) = 0 && var(59) = 0 && life <= 500)|(var(31) = 1 && power >= 2000 && numhelper(2500) = 0)|(var(31) = 1 && var(13) > 528 && numhelper(2500) = 1)
triggerall = command = "�f�����E�t���A"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact
trigger11 = stateno = [110,116]

; ��L�����p
[State -1]
type = ChangeState
value = 2200
triggerall = numproj = 0
triggerall = (var(31) = 0 && var(59) = 0 && life <= 500)|(var(31) = 1 && power >= 2000 && numhelper(2500) = 0)|(var(31) = 1 && var(13) > 528 && numhelper(2500) = 1)
triggerall = command = "�f�����E�t���A"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 2200
triggerall = numproj = 0
triggerall = var(59) = 0 && life <= 500
triggerall = command = "�f�����E�t���A"
triggerall = var(13) > 0
trigger1 = (stateno = 1100|stateno = 1110) && movecontact
trigger2 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �~�b�h�i�C�g�u���X
[State -1]
type = ChangeState
value = 2000
triggerall = power >= 1000
triggerall = command = "�~�b�h�i�C�g�u���X"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact
trigger11 = stateno = [110,116]

; ��L�����p
[State -1]
type = ChangeState
value = 2000
triggerall = power >= 1000
triggerall = command = "�~�b�h�i�C�g�u���X"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 2000
triggerall = command = "�~�b�h�i�C�g�u���X"
triggerall = var(13) > 0
trigger1 = (stateno = 1100|stateno = 1110) && movecontact
trigger2 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �o�b�g�X�s���E��
[State -1]
type = ChangeState
value = 1310
triggerall = command = "�o�b�g�X�s���E��"
trigger1 = ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact
trigger11 = stateno = [110,116]
trigger12 = stateno = 605&& movecontact

; ��L�����p
[State -1]
type = ChangeState
value = 1310
triggerall = command = "�o�b�g�X�s���E��"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 1310
triggerall = command = "�o�b�g�X�s���E��"
triggerall = var(13) > 0
trigger1 = var(14) = 1
trigger2 = (stateno = 1100|stateno = 1110) && movecontact
trigger3 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �o�b�g�X�s���E��
[State -1]
type = ChangeState
value = 1300
triggerall = command = "�o�b�g�X�s���E��"
trigger1 = ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact
trigger11 = stateno = [110,116]
trigger12 = stateno = 605&& movecontact

; ��L�����p
[State -1]
type = ChangeState
value = 1300
triggerall = command = "�o�b�g�X�s���E��"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 1300
triggerall = command = "�o�b�g�X�s���E��"
triggerall = var(13) > 0
trigger1 = var(14) = 1
trigger2 = (stateno = 1100|stateno = 1110) && movecontact
trigger3 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �΂߃f�����N���C�h���E��
[State -1]
type = ChangeState
value = 1210
triggerall = command = "�f�����N���C�h���E��"
trigger1 = statetype != A && stateno = [110,116]

;---------------------------------------------------------------------------
; �΂߃f�����N���C�h���E��
[State -1]
type = ChangeState
value = 1200
triggerall = command = "�f�����N���C�h���E��"
trigger1 = statetype != A && stateno = [110,116]

;---------------------------------------------------------------------------
; �f�����N���C�h���E��
[State -1]
type = ChangeState
value = 1110
triggerall = command = "�f�����N���C�h���E��"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact
trigger11 = stateno = [110,116]

; ��L�����p
[State -1]
type = ChangeState
value = 1110
triggerall = command = "�f�����N���C�h���E��"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 1110
triggerall = command = "�f�����N���C�h���E��"
triggerall = var(13) > 0
trigger1 = var(14) = 1
trigger2 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �f�����N���C�h���E��
[State -1]
type = ChangeState
value = 1100
triggerall = command = "�f�����N���C�h���E��"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact

; ��L�����p
[State -1]
type = ChangeState
value = 1100
triggerall = command = "�f�����N���C�h���E��"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 1100
triggerall = command = "�f�����N���C�h���E��"
triggerall = var(13) > 0
trigger1 = var(14) = 1
trigger2 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �󒆂d�r�E�J�I�X�t���A
[State -1]
type = ChangeState
value = 1410
triggerall = numproj = 0
triggerall = power >= 1000
triggerall = command = "�d�r�E�J�I�X�t���A"
trigger1 = statetype = A && ctrl
trigger2 = stateno = 605&& movecontact

;---------------------------------------------------------------------------
; �󒆃J�I�X�t���A�E��
[State -1]
type = ChangeState
value = 1015
triggerall = numproj = 0
triggerall = command = "�J�I�X�t���A�E��"
trigger1 = statetype = A && ctrl
trigger2 = stateno = 605&& movecontact

;---------------------------------------------------------------------------
; �󒆃J�I�X�t���A�E��
[State -1]
type = ChangeState
value = 1010
triggerall = numproj = 0
triggerall = command = "�J�I�X�t���A�E��"
trigger1 = statetype = A && ctrl
trigger2 = stateno = 605&& movecontact

;---------------------------------------------------------------------------
; �d�r�E�J�I�X�t���A
[State -1]
type = ChangeState
value = 1400
triggerall = numproj = 0
triggerall = power >= 1000
triggerall = command = "�d�r�E�J�I�X�t���A"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = [2300,2301]
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact
trigger11 = stateno = [110,116]

; ��L�����p
[State -1]
type = ChangeState
value = 1400
triggerall = numproj = 0
triggerall = power >= 1000
triggerall = command = "�d�r�E�J�I�X�t���A"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 1400
triggerall = numproj = 0
triggerall = command = "�d�r�E�J�I�X�t���A"
triggerall = var(13) > 0
trigger1 = (stateno = 1100|stateno = 1110) && movecontact
trigger2 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �J�I�X�t���A�E��
[State -1]
type = ChangeState
value = 1005
triggerall = numproj = 0
triggerall = command = "�J�I�X�t���A�E��"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact
trigger11 = stateno = [110,116]

; ��L�����p
[State -1]
type = ChangeState
value = 1005
triggerall = numproj = 0
triggerall = command = "�J�I�X�t���A�E��"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 1005
triggerall = numproj = 0
triggerall = command = "�J�I�X�t���A�E��"
triggerall = var(13) > 0
trigger1 = var(14) = 1
trigger2 = (stateno = 1100|stateno = 1110) && movecontact
trigger3 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �J�I�X�t���A�E��
[State -1]
type = ChangeState
value = 1000
triggerall = numproj = 0
triggerall = command = "�J�I�X�t���A�E��"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215 && movecontact
trigger6 = stateno = 235 && movecontact
trigger7 = stateno = 245 && movecontact
trigger8 = stateno = 400 && movecontact
trigger9 = stateno = 410 && movecontact
trigger10 = stateno = 430 && movecontact
trigger11 = stateno = [110,116]

; ��L�����p
[State -1]
type = ChangeState
value = 1000
triggerall = numproj = 0
triggerall = command = "�J�I�X�t���A�E��"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 1000
triggerall = numproj = 0
triggerall = command = "�J�I�X�t���A�E��"
triggerall = var(13) > 0
trigger1 = var(14) = 1
trigger2 = (stateno = 1100|stateno = 1110) && movecontact
trigger3 = (stateno = 1200|stateno = 1210) && movecontact

;===========================================================================
;---------------------------------------------------------------------------
; �w���Y���C�h
[State -1]
type = ChangeState
value = 900
trigger1 = command = "holdup" && (command = "a"|command = "b")
trigger1 = p2statetype = L && p2stateno != 5120
trigger1 = stateno = 40 && var(2) = 0

;---------------------------------------------------------------------------
; �o�b�g�_�C�u
[State -1]
type = ChangeState
value = 800
triggerall = command = "�o�b�g�_�C�u"
trigger1 = statetype = S && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; ���C�g�v���W���[
[State -1]
type = ChangeState
value = 850
triggerall = command = "���C�g�v���W���["
trigger1 = statetype = S && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �K�[�L�����X�e�b�v
[State -1]
type = ChangeState
value = 2300
triggerall = stateno = [150,153]
trigger1 = command = "FF"
trigger1 = power >= 200
trigger2 = command = "step"
trigger2 = power >= 600

; �K�[�L�����ӂ��Ƃ΂�
[State -1]
type = ChangeState
value = 2400
trigger1 = stateno = 150|stateno = 152
trigger1 = command = "���C�g�v���W���["
trigger1 = power >= 1000

;---------------------------------------------------------------------------
; ����ړ��E�O
[State -1]
type = ChangeState
value = 110
triggerall = command = "BF" && command = "hold_a" && command = "hold_y"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact

[State -1]
type = ChangeState
value = 110
triggerall = command = "����ړ��E�O"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact

; ��L�����p
[State -1]
type = ChangeState
value = 110
triggerall = (command = "BF" && command = "hold_a" && command = "hold_y")|command = "����ړ��E�O"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 110
triggerall = (command = "BF" && command = "hold_a" && command = "hold_y")|command = "����ړ��E�O"
triggerall = var(13) > 0
trigger1 = var(14) = 1
trigger2 = (stateno = 1100|stateno = 1110) && movecontact
trigger3 = (stateno = 1200|stateno = 1210) && movecontact

; ����ړ��E��
[State -1]
type = ChangeState
value = 115
triggerall = command = "FB" && command = "hold_a" && command = "hold_y"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact

[State -1]
type = ChangeState
value = 115
triggerall = command = "����ړ��E��"
trigger1 = statetype != A && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301
trigger4 = (stateno = [200,205]) && movecontact
trigger5 = stateno = 215&& movecontact
trigger6 = stateno = 235&& movecontact
trigger7 = stateno = 245&& movecontact
trigger8 = stateno = 400&& movecontact
trigger9 = stateno = 410&& movecontact
trigger10 = stateno = 430&& movecontact

; ��L�����p
[State -1]
type = ChangeState
value = 115
triggerall = (command = "FB" && command = "hold_a" && command = "hold_y")|command = "����ړ��E��"
trigger1 = (stateno = [200,205]) && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger2 = stateno = 215 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger3 = stateno = 235 && animelemtime(3) >= 0 && animelemtime(4) < 0
trigger4 = stateno = 245 && animelemtime(3) >= 0 && animelemtime(5) < 0
trigger5 = stateno = 400 && animelemtime(2) >= 0 && animelemtime(3) < 0
trigger6 = stateno = 410 && animelemtime(3) >= 0 && animelemtime(7) < 0
trigger7 = stateno = 430 && animelemtime(2) >= 0 && animelemtime(3) < 0

; �ǂ��L�����p
[State -1]
type = ChangeState
value = 115
triggerall = (command = "FB" && command = "hold_a" && command = "hold_y")|command = "����ړ��E��"
triggerall = var(13) > 0
trigger1 = var(14) = 1
trigger2 = (stateno = 1100|stateno = 1110) && movecontact
trigger3 = (stateno = 1200|stateno = 1210) && movecontact

;---------------------------------------------------------------------------
; �t�����g�X�e�b�v
[State -1]
type = ChangeState
value = 100
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
; �o�b�N�X�e�b�v
[State -1]
type = ChangeState
value = 105
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
; ����
[State -1]
type = ChangeState
value = 195
triggerall = command = "start"
trigger1 = statetype != A && ctrl

;===========================================================================
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
; �`�F�[���R���{�p
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
; �������p���`�E�R���{��
[State -1]
type = ChangeState
value = 706
triggerall = var(0) = 1 && movecontact
triggerall = command = "x" && command != "holddown"
trigger1 = stateno = 700|stateno = 720|stateno = 740|stateno = 755|stateno = 721|stateno = 756

;---------------------------------------------------------------------------
; �������p���`�E�R���{��
[State -1]
type = ChangeState
value = 711
triggerall = var(0) = 1 && movecontact
triggerall = command = "y" && command != "holddown"
trigger1 = stateno = 700|stateno = 720|stateno = 740|stateno = 755|stateno = 721|stateno = 756
trigger2 = stateno = 705|stateno = 706|stateno = 250|stateno = 725
trigger3 = stateno = 745|stateno = 746|stateno = 450|stateno = 760

;---------------------------------------------------------------------------
; ������L�b�N�E�R���{��
[State -1]
type = ChangeState
value = 721
triggerall = var(0) = 1 && movecontact
triggerall = command = "a" && command != "holddown"
trigger1 = stateno = 700|stateno = 740

;---------------------------------------------------------------------------
; �������L�b�N�E�R���{��
[State -1]
type = ChangeState
value = 725
triggerall = var(0) = 1 && movecontact
triggerall = command = "a" && command != "holddown"
trigger1 = stateno = 700|stateno = 720|stateno = 740|stateno = 755|stateno = 721|stateno = 756
trigger2 = stateno = 705|stateno = 706|stateno = 745|stateno = 746

;---------------------------------------------------------------------------
; �������L�b�N�E�R���{��
[State -1]
type = ChangeState
value = 730
triggerall = var(0) = 1 && movecontact
triggerall = command = "b" && command != "holddown"
trigger1 = stateno = 700|stateno = 720|stateno = 740|stateno = 755|stateno = 721|stateno = 756
trigger2 = stateno = 705|stateno = 706|stateno = 250|stateno = 725
trigger3 = stateno = 745|stateno = 746|stateno = 450|stateno = 760
trigger4 = stateno = 710|stateno = 711|stateno = 420|stateno = 750

;---------------------------------------------------------------------------
; ���Ⴊ�ݒ��p���`�E�R���{��
[State -1]
type = ChangeState
value = 746
triggerall = var(0) = 1 && movecontact
triggerall = command = "x" && command = "holddown"
trigger1 = stateno = 700|stateno = 720|stateno = 740|stateno = 755|stateno = 721|stateno = 756

;---------------------------------------------------------------------------
; ���Ⴊ�݋��p���`�E�R���{��
[State -1]
type = ChangeState
value = 750
triggerall = var(0) = 1 && movecontact
triggerall = command = "y" && command = "holddown"
trigger1 = stateno = 700|stateno = 720|stateno = 740|stateno = 755|stateno = 721|stateno = 756
trigger2 = stateno = 705|stateno = 706|stateno = 250|stateno = 725
trigger3 = stateno = 745|stateno = 746|stateno = 450|stateno = 760

;---------------------------------------------------------------------------
; ���Ⴊ�ݎ�L�b�N�E�R���{��
[State -1]
type = ChangeState
value = 756
triggerall = var(0) = 1 && movecontact
triggerall = command = "a" && command = "holddown"
trigger1 = stateno = 700|stateno = 740

;---------------------------------------------------------------------------
; ���Ⴊ�ݒ��L�b�N�E�R���{��
[State -1]
type = ChangeState
value = 760
triggerall = var(0) = 1 && movecontact
triggerall = command = "a" && command = "holddown"
trigger1 = stateno = 700|stateno = 720|stateno = 740|stateno = 755|stateno = 721|stateno = 756
trigger2 = stateno = 705|stateno = 706|stateno = 745|stateno = 746

;---------------------------------------------------------------------------
; ���Ⴊ�݋��L�b�N�E�R���{��
[State -1]
type = ChangeState
value = 765
triggerall = var(0) = 1 && movecontact
triggerall = command = "b" && command = "holddown"
trigger1 = stateno = 700|stateno = 720|stateno = 740|stateno = 755|stateno = 721|stateno = 756
trigger2 = stateno = 705|stateno = 706|stateno = 250|stateno = 725
trigger3 = stateno = 745|stateno = 746|stateno = 450|stateno = 760
trigger4 = stateno = 710|stateno = 711|stateno = 420|stateno = 750

;---------------------------------------------------------------------------
; ������p���`�E�`�F�[���R���{�J�n
[State -1]
type = ChangeState
value = 700
triggerall = command = "x" && command != "holddown" && command = "holdfwd"
trigger1 = statetype = S && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �������p���`�E�`�F�[���R���{�J�n
[State -1]
type = ChangeState
value = 705
triggerall = command = "x" && command != "holddown" && command = "holdback"
trigger1 = statetype = S && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �������p���`�E�`�F�[���R���{�J�n
[State -1]
type = ChangeState
value = 710
triggerall = command = "y" && command != "holddown" && command = "holdfwd"
trigger1 = statetype = S && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; ������L�b�N�E�`�F�[���R���{�J�n
[State -1]
type = ChangeState
value = 720
triggerall = command = "a" && command != "holddown" && command = "holdfwd"
trigger1 = statetype = S && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �T�^���Y�y�C���i�`�F�[���R���{�J�n�j�i�����E���o�[B�����L�b�N�j
[State -1]
type = ChangeState
value = 250
triggerall = command = "a" && command != "holddown" && command = "holdback"
trigger1 = statetype = S && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; ���Ⴊ�ݎ�p���`�E�`�F�[���R���{�J�n
[State -1]
type = ChangeState
value = 740
triggerall = command = "x" && command = "holddown" && command = "holdfwd"
trigger1 = statetype = C && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; ���Ⴊ�ݒ��p���`�E�`�F�[���R���{�J�n
[State -1]
type = ChangeState
value = 745
triggerall = command = "x" && command = "holddown" && command = "holdback"
trigger1 = statetype = C && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �o�b�g�X�N���[���i�`�F�[���R���{�J�n�j�i���Ⴊ�݁E���o�[DF���ꋭ�p���`�j
[State -1]
type = ChangeState
value = 420
triggerall = command = "y" && command = "holddown" && command = "holdfwd"
trigger1 = statetype = C && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; ���Ⴊ�ݎ�L�b�N�E�`�F�[���R���{�J�n
[State -1]
type = ChangeState
value = 755
triggerall = command = "a" && command = "holddown" && command = "holdfwd"
trigger1 = statetype = C && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �f�����X���b�V���i�`�F�[���R���{�J�n�j�i���Ⴊ�݁E���o�[DB�����L�b�N�j
[State -1]
type = ChangeState
value = 450
triggerall = command = "a" && command = "holddown" && command = "holdback"
trigger1 = statetype = C && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �`�F�[���R���{�p
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------

;---------------------------------------------------------------------------
; �����E��p���`
[State -1]
type = ChangeState
value = ifelse(P2bodydist x < 20,205,200)
triggerall = command = "x" && command != "holddown"
trigger1 = statetype = S && ctrl
trigger2 = (stateno = [200,205]) && animelemtime(2) > 1
trigger3 = stateno = 230 && animelemtime(3) > 1 && movecontact = 0
trigger4 = stateno = 235 && animelemtime(3) > 1
trigger5 = stateno = 400 && animelemtime(2) > 1
trigger6 = stateno = 430 && animelemtime(2) > 1
trigger7 = stateno = [100,101]
trigger8 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �����E���p���`
[State -1]
type = ChangeState
value = ifelse(P2bodydist x < 30,215,210)
triggerall = command = "y" && command != "holddown"
trigger1 = statetype = S && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �����E��L�b�N
[State -1]
type = ChangeState
value = ifelse(P2bodydist x < 20,235,230)
triggerall = command = "a" && command != "holddown"
trigger1 = statetype = S && ctrl
trigger2 = (stateno = [200,205]) && animelemtime(2) > 1
trigger3 = stateno = 230 && animelemtime(3) > 1 && movecontact = 0
trigger4 = stateno = 235 && animelemtime(3) > 1
trigger5 = stateno = 400 && animelemtime(2) > 1
trigger6 = stateno = 430 && animelemtime(2) > 1
trigger7 = stateno = [100,101]
trigger8 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; �����E���L�b�N
[State -1]
type = ChangeState
value = ifelse(P2bodydist x < 30,245,240)
triggerall = command = "b" && command != "holddown"
trigger1 = statetype = S && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; ���Ⴊ�݁E��p���`
[State -1]
type = ChangeState
value = 400
triggerall = command = "x" && command = "holddown"
trigger1 = statetype = C && ctrl
trigger2 = (stateno = [200,205]) && animelemtime(2) > 1
trigger3 = stateno = 230 && animelemtime(3) > 1 && movecontact = 0
trigger4 = stateno = 235 && animelemtime(3) > 1
trigger5 = stateno = 400 && animelemtime(2) > 1
trigger6 = stateno = 430 && animelemtime(2) > 1
trigger7 = stateno = [100,101]
trigger8 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; ���Ⴊ�݁E���p���`
[State -1]
type = ChangeState
value = 410
triggerall = command = "y" && command = "holddown"
trigger1 = statetype = C && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; ���Ⴊ�݁E��L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = command = "a" && command = "holddown"
trigger1 = statetype = C && ctrl
trigger2 = (stateno = [200,205]) && animelemtime(2) > 1
trigger3 = stateno = 230 && animelemtime(3) > 1 && movecontact = 0
trigger4 = stateno = 235 && animelemtime(3) > 1
trigger5 = stateno = 400 && animelemtime(2) > 1
trigger6 = stateno = 430 && animelemtime(2) > 1
trigger7 = stateno = [100,101]
trigger8 = stateno = 2300 && animelemtime(4) > 0|stateno = 2301

;---------------------------------------------------------------------------
; ���Ⴊ�݁E���L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = command = "b" && command = "holddown"
trigger1 = statetype = C && ctrl
trigger2 = stateno = [100,101]
trigger3 = stateno = [2300,2301]

;---------------------------------------------------------------------------
; �󒆎�p���`
[State -1]
type = ChangeState
value = ifelse(vel x = 0,600,605)
triggerall = command = "x"
trigger1 = statetype = A && ctrl

;---------------------------------------------------------------------------
; �󒆋��p���`
[State -1]
type = ChangeState
value = ifelse(vel x = 0,610,615)
triggerall = command = "y"
trigger1 = statetype = A && ctrl

;---------------------------------------------------------------------------
; �󒆎�L�b�N
[State -1]
type = ChangeState
value = ifelse(vel x = 0,630,635)
triggerall = command = "a"
trigger1 = statetype = A && ctrl

;---------------------------------------------------------------------------
; �󒆋��L�b�N
[State -1]
type = ChangeState
value = ifelse(vel x = 0,640,645)
triggerall = command = "b"
trigger1 = statetype = A && ctrl