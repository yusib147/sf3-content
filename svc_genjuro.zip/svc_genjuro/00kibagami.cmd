;-| CPU |--------------------------------------------------------
[Command]
name = "cpu"
command =D,D,D,D,D,D,D,D
time = 0

[Command]
name = "cpu"
command =F,F,F,F,F,F,F
time = 0

[Command]
name = "cpu"
command =U,U,U,U,U,U,U,U
time = 0

[Command]
name = "cpu"
command = B,B,B,B,B,B,B
time = 0

;-| Super Motions |--------------------------------------------------------
[Command]
name = "�g���▽"
command =~D,DF,F,D,DF,F,b
time = 35


[Command]
name = "�n���Ɋy"
command =~D,DB,B,D,DB,B,y
time = 35

[Command]
name = "�܌�"
command =~D,DB,B,D,DB,B,x
time = 35

[Command]
name = "�܌�"
command =~D,DF,F,D,DF,F,a
time = 35

[Command]
name = "�^��g��x"
command =~D,DF,F,D,DF,F,x
time = 35

[Command]
name = "�^��g��y"
command =~D,DF,F,D,DF,F,y
time = 35

[Command]
name = "�^��g��a"
command =~D,DF,F,D,DF,F,a
time = 35

[Command]
name = "�^��g��b"
command =~D,DF,F,D,DF,F,b
time = 35

[Command]
name = "�^�󗳊�a"
command =~D,DB,B,D,DB,B,a
time = 35

[Command]
name = "�^�󗳊�b"
command =~D,DB,B,D,DB,B,b
time = 35

;-| Special Motions |------------------------------------------------------
[Command]
name = "�e��"
command =~D,DB,B,F,c
time = 20

[Command]
name = "�S�Sx"
command =~D,DB,B,F,x
time = 20

[Command]
name = "�S�Sy"
command =~D,DB,B,F,y
time = 20

[Command]
name = "�S�Sa"
command =~D,DB,B,F,a
time = 20

[Command]
name = "�S�Sb"
command =~D,DB,B,F,b
time = 20

[Command]
name = "����x"
command =~F,D,DF,x
time = 13

[Command]
name = "����y"
command =~F,D,DF,y
time = 13

[Command]
name = "����a"
command =~F,D,DF,a
time = 13

[Command]
name = "����b"
command =~F,D,DF,b
time = 13

[Command]
name = "�t����x"
command =~B,D,DB,x
time = 13

[Command]
name = "�t����y"
command =~B,D,DB,y
time = 13

[Command]
name = "�t����a"
command =~B,D,DB,a
time = 13

[Command]
name = "�t����b"
command =~B,D,DB,b
time = 13

[Command]
name = "�t����"
command =~B,D,DB
time = 13

[Command]
name = "�g��x"
command =~D,DF,F,x
time = 10

[Command]
name = "�g��y"
command =~D,DF,F,y
time = 10

[Command]
name = "�g��a"
command =~D,DF,F,a
time = 10

[Command]
name = "�g��b"
command =~D,DF,F,b
time = 10

[Command]
name = "����x"
command =~D,DB,B,x
time = 10

[Command]
name = "����y"
command =~D,DB,B,y
time = 10

[Command]
name = "����a"
command =~D,DB,B,a
time = 10

[Command]
name = "����b"
command =~D,DB,B,b
time = 10

[Command]
name = "���̋��n"
command =~D,DB,B,z
time = 10

[Command]
name = "���̋��n"
command =~D,DB,B,y+b
time = 10

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "����x"
command =~D,D,x
time = 12

[Command]
name = "����y"
command =~D,D,y
time = 12

[Command]
name = "����a"
command =~D,D,a
time = 12

[Command]
name = "����b"
command =~D,D,b
time = 12

[Command]
name = "FF"   ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"   ;Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "ABC"
command = x+a+y
time = 1

[Command]
name = "AB"
command = x+a
time = 1

[Command]
name = "CD"
command = y+b
time = 1

[Command]
name = "FS"
command = a+y
time = 1

[Command]
name = "recovery";Required (do not remove)
command = a+x
time = 1


;-| Dir + Button |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Statedef -1]
;===========================================================================
;�▽
[State -1]
type = ChangeState
value = 7000
triggerall = command = "�g���▽"; && life < 333
;triggerall = fvar(28) = 0
triggerall = statetype != A && fvar(25) = 1
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = ctrl || anim = 101

;�▽�E�L�����Z��
[State -1]
type = null;changestate
value = 7000
triggerall = command = "�g���▽" && life < 333
;triggerall = fvar(28) = 0
triggerall = statetype != A && fvar(25) = 1
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;�▽�ǂ��L����
[State -1]
type = null;changestate
value = 7000
triggerall = command = "�g���▽" && life < 333
;triggerall = fvar(28) = 0
triggerall = statetype != A && fvar(25) = 1
triggerall = movecontact && var(13) = 0
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = var(11) = 1


;===========================================================================
;���a�n
[State -1]
type = ChangeState
value = 3400
triggerall = command = "�n���Ɋy" && var(1) = 0
triggerall = fvar(28) = 0 || fvar(28) = 1
triggerall = statetype != A && fvar(25) = 1
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = ctrl || anim = 101

;���a�n�E�L�����Z��
[State -1]
type = changestate
value = 3400
triggerall = command = "�n���Ɋy" && var(1) = 0
triggerall = fvar(28) = 0 || fvar(28) = 1
triggerall = statetype != A && fvar(25) = 1
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���a�n�ǂ��L����
[State -1]
type = changestate
value = 3400
triggerall = command = "�n���Ɋy"
triggerall = fvar(28) = 0 || fvar(28) = 1
triggerall = statetype != A && fvar(25) = 1
triggerall = movecontact && var(13) = 0
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = var(11) = 1

;===========================================================================
;��M
[State -1]
type = ChangeState
value = 3300
triggerall = command = "ABC" && var(1) = 0
triggerall = fvar(28) = 0 || fvar(28) = 1 || fvar(28) = 2
triggerall = statetype != A && fvar(23) = 0
triggerall = ctrl || anim = 101
trigger1 = (fvar(29) = 0 || fvar(29) = 2) && numhelper(2025)
trigger2 = fvar(29) = 1 && Power >= 2000

;��M�E�L�����Z��
[State -1]
type = changestate
value = 3300
triggerall = command = "ABC"
triggerall = (fvar(29) = 0 || (fvar(29) = 2) && numhelper(2025)) || (fvar(29) = 1 && Power >= 2000)
triggerall = statetype != A && numhelper(2025) && fvar(23) = 0
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;��M�ǂ��L����
[State -1]
type = changestate
value = 3300
triggerall = command = "ABC"
triggerall = (fvar(29) = 0 || (fvar(29) = 2) && numhelper(2025)) || (fvar(29) = 1 && Power >= 2000)
triggerall = statetype != A && numhelper(2025) && fvar(23) = 0
triggerall = movecontact && var(13) = 0
trigger1 = var(11) = 1
;===========================================================================
;�n�E�\�A
[State -1]
type = ChangeState
value = 3600
triggerall = command = "�^�󗳊�a" || command = "�^�󗳊�b"
triggerall = fvar(28) = 0 || fvar(28) = 2
triggerall = statetype != A && var(1) = 0 && fvar(25) = 1
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = ctrl || anim = 101

;�n�E�\�A�E�L�����Z��
[State -1]
type = changestate
value = 3600
triggerall = command = "�^�󗳊�a" || command = "�^�󗳊�b"
triggerall = fvar(28) = 0 || fvar(28) = 2
triggerall = statetype != A && fvar(25) = 1
triggerall = movecontact
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;�n�E�\�A�ǂ��L����
[State -1]
type = changestate
value = 3600
triggerall = command = "�^�󗳊�a" || command = "�^�󗳊�b"
triggerall = fvar(28) = 0 || fvar(28) = 2
triggerall = statetype != A && var(10) = 1 && fvar(25) = 1
triggerall = movecontact && var(13) = 0
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = var(11) = 1

;===========================================================================
;���܌�
[State -1]
type = ChangeState
value = 3000
triggerall = command = "�^��g��x" || command = "�^��g��y"
triggerall = fvar(28) = 0 || fvar(28) = 2
triggerall = statetype != A && var(1) = 0
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = ctrl || anim = 101

;���܌��E�L�����Z��
[State -1]
type = changestate
value = 3000
triggerall = command = "�^��g��x" || command = "�^��g��y"
triggerall = fvar(28) = 0 || fvar(28) = 2
triggerall = statetype != A
triggerall = movecontact
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���܌��ǂ��L����
[State -1]
type = changestate
value = 3000
triggerall = command = "�^��g��x" || command = "�^��g��y"
triggerall = fvar(28) = 0 || fvar(28) = 2
triggerall = statetype != A && var(10) = 1
triggerall = movecontact && var(13) = 0
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = var(11) = 1
;===========================================================================
;�e��
[State -1]
type = ChangeState
value = 740
triggerall = command = "�e��"
triggerall = statetype != A
triggerall = fvar(29) = 0 || fvar(29) = 2
trigger1 = ctrl

;===========================================================================
;�܌��a
[State -1]
type = ChangeState
value = 3500
triggerall = (fvar(28) = 0 && command = "�܌�") || (fvar(28) = 1 && (command = "�^��g��x" || command = "�^��g��y"))
triggerall = statetype != A && var(1) = 0
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = ctrl || anim = 101

;�܌��a�E�L�����Z��
[State -1]
type = changestate
value = 3500
triggerall = (fvar(28) = 0 && command = "�܌�") || (fvar(28) = 1 && (command = "�^��g��x" || command = "�^��g��y"))
triggerall = statetype != A
triggerall = movecontact
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;�܌��a�ǂ��L����
[State -1]
type = changestate
value = 3500
triggerall = (fvar(28) = 0 && command = "�܌�") || (fvar(28) = 1 && (command = "�^��g��x" || command = "�^��g��y"))
triggerall = statetype != A && var(10) = 1 && var(1) = 0
triggerall = movecontact && var(13) = 0
triggerall = (fvar(29) != 1 && numhelper(2025)) || (fvar(29) =1 && power >= 1000)
trigger1 = var(11) = 1

;===========================================================================
;��E�S�S�E
[State -1]
type = ChangeState
value = 1300
triggerall = command = "�S�Sx"
triggerall = statetype != A
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = ctrl || anim = 101

;��E�S�S�E�E�L�����Z��
[State -1]
type = ChangeState
value = 1300
triggerall = command = "�S�Sx"
triggerall = statetype != A
triggerall = movecontact
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;��E�S�S�E�ǂ��L����
[State -1]
type = ChangeState
value = 1300
triggerall = command = "�S�Sx"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact && stateno != 1370 && var(13) = 0
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = var(11) = 1

;���E�S�S�E
[State -1]
type = ChangeState
value = 1310
triggerall = command = "�S�Sy"
triggerall = statetype != A
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = ctrl || anim = 101

;���E�S�S�E�E�L�����Z��
[State -1]
type = ChangeState
value = 1310
triggerall = command = "�S�Sy"
triggerall = statetype != A
triggerall = movecontact
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���E�S�S�E�ǂ��L����
[State -1]
type = ChangeState
value = 1310
triggerall = command = "�S�Sy"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact && stateno != 1370 && var(13) = 0
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = var(11) = 1
;===========================================================================
;��E��_��
[State -1]
type = ChangeState
value = 1500
triggerall = command = "�S�Sa" && fvar(28) = 0 || command = "����a" && fvar(28) = 2
triggerall = statetype != A && var(1) = 0
trigger1 = ctrl || anim = 101

;��E��_�ˁE�L�����Z��
[State -1]
type = ChangeState
value = 1500
triggerall = command = "�S�Sa" && fvar(28) = 0 || command = "����a" && fvar(28) = 2
triggerall = statetype != A && var(1) = 0
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;��E��_�˂ǂ��L����
[State -1]
type = ChangeState
value = 1500
triggerall = command = "�S�Sa" && fvar(28) = 0 || command = "����a" && fvar(28) = 2
triggerall = statetype != A && var(10) = 1 && var(1) = 0
triggerall = movecontact && var(13) = 0
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = var(11) = 1

;���E��_��
[State -1]
type = ChangeState
value = 1501
triggerall = command = "�S�Sb" && fvar(28) = 0 || command = "����b" && fvar(28) = 2
triggerall = statetype != A && var(1) = 0
trigger1 = ctrl || anim = 101

;���E��_�ˁE�L�����Z��
[State -1]
type = ChangeState
value = 1501
triggerall = command = "�S�Sb" && fvar(28) = 0 || command = "����b" && fvar(28) = 2
triggerall = statetype != A && var(1) = 0
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���E��_�˂ǂ��L����
[State -1]
type = ChangeState
value = 1501
triggerall = command = "�S�Sb" && fvar(28) = 0 || command = "����b" && fvar(28) = 2
triggerall = statetype != A && var(10) = 1 && var(1) = 0
triggerall = movecontact && var(13) = 0
trigger1 = var(11) = 1

;===========================================================================
;===========================================================================
;��E�����n
[State -1]
type = ChangeState
value = 1100
triggerall = command = "����x"
triggerall = statetype != A
triggerall = fvar(28) = 0 || fvar(28) = 1 || fvar(28) = 2
trigger1 = ctrl || anim = 101

;��E�����n�E�L�����Z��
[State -1]
type = ChangeState
value = 1100
triggerall = command = "����x"
triggerall = statetype != A
triggerall = movecontact
triggerall = fvar(28) = 0 || fvar(28) = 1 || fvar(28) = 2
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;��E�����n�ǂ��L����
[State -1]
type = ChangeState
value = 1100
triggerall = command = "����x"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact && var(13) = 0
triggerall = fvar(28) = 0 || fvar(28) = 1 || fvar(28) = 2
trigger1 = var(11) = 1

;���E�����n
[State -1]
type = ChangeState
value = 1110
triggerall = command = "����y"
triggerall = statetype != A
triggerall = fvar(28) = 0 || fvar(28) = 1 || fvar(28) = 2
trigger1 = ctrl || anim = 101

;���E�����n�E�L�����Z��
[State -1]
type = ChangeState
value = 1110
triggerall = command = "����y"
triggerall = statetype != A
triggerall = movecontact
triggerall = fvar(28) = 0 || fvar(28) = 1 || fvar(28) = 2
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���E�����n�ǂ��L����
[State -1]
type = ChangeState
value = 1110
triggerall = command = "����y"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact && var(13) = 0
triggerall = fvar(28) = 0 || fvar(28) = 1 || fvar(28) = 2
trigger1 = var(11) = 1
;===========================================================================
;���n
[State -1]
type = ChangeState
value = 1700
triggerall = ((command = "����a" || command = "����b") && fvar(28) = 1) || (command = "����b" && fvar(28) = 0)
triggerall = statetype != A && p2bodydist X <= 32
triggerall = p2statetype = S || p2statetype = C
trigger1 = ctrl || anim = 101

;���n�E�L�����Z��
[State -1]
type = ChangeState
value = 1700
triggerall = ((command = "����a" || command = "����b") && fvar(28) = 1) || (command = "����b" && fvar(28) = 0)
triggerall = statetype != A && p2bodydist X <= 32
triggerall = movecontact
triggerall = p2statetype = S || p2statetype = C
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���n�ǂ��L����
[State -1]
type = ChangeState
value = 1700
triggerall = ((command = "����a" || command = "����b") && fvar(28) = 1) || (command = "����b" && fvar(28) = 0)
triggerall = statetype != A && var(10) = 1 && var(13) = 0
triggerall = movecontact && p2bodydist X <= 32
triggerall = p2statetype = S || p2statetype = C
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = var(11) = 1

;===========================================================================
;���؎a
[State -1]
type = ChangeState
value = ifelse(numhelper(2025)=1,1660,1600)
triggerall = ((command = "����a" || command = "����b") && fvar(28) = 2) || (command = "����a" && fvar(28) = 0)
triggerall = statetype != A && p2bodydist X <= 20
triggerall = fvar(28) = 0 || fvar(28) = 2
triggerall = p2statetype = S || p2statetype = C
trigger1 = ctrl || anim = 101

;���؎a�E�L�����Z��
[State -1]
type = ChangeState
value = ifelse(numhelper(2025)=1,1660,1600)
triggerall = ((command = "����a" || command = "����b") && fvar(28) = 2) || (command = "����a" && fvar(28) = 0)
triggerall = statetype != A && p2bodydist X <= 20
triggerall = movecontact
triggerall = p2statetype = S || p2statetype = C
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���؎a�ǂ��L����
[State -1]
type = ChangeState
value = ifelse(numhelper(2025)=1,1660,1600)
triggerall = ((command = "����a" || command = "����b") && fvar(28) = 2) || (command = "����a" && fvar(28) = 0)
triggerall = statetype != A && var(10) = 1 && var(13) = 0
triggerall = movecontact && p2bodydist X <= 20
triggerall = p2statetype = S || p2statetype = C
triggerall = fvar(28) = 0 || fvar(28) = 2
trigger1 = var(11) = 1
;===========================================================================
;���̋��n
[State -1]
type = ChangeState
value = 700
triggerall = command = "���̋��n"
triggerall = statetype != A && numhelper(2025) && fvar(25) = 1 && var(13) = 0 && fvar(29) != 1 && var(4) = 0
trigger1 = ctrl || anim = 101
trigger2 = stateno = 52

;===========================================================================
;��E���؎a
[State -1]
type = ChangeState
value = 1000
triggerall = command = "����x" && fvar(28) = 0 || command = "����x" && fvar(28) = 1
triggerall = statetype != A && numhelper(1040) = 0
trigger1 = ctrl || anim = 101

;��E���؎a�E�L�����Z��
[State -1]
type = ChangeState
value = 1000
triggerall = command = "����x" && fvar(28) = 0 || command = "����x" && fvar(28) = 1
triggerall = statetype != A && numhelper(1040) = 0
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;��E���؎a�ǂ��L����
[State -1]
type = ChangeState
value = 1000
triggerall = command = "����x" && fvar(28) = 0 || command = "����x" && fvar(28) = 1
triggerall = statetype != A && var(10) = 1 && var(13) = 0
triggerall = movecontact && numhelper(1040) = 0
trigger1 = var(11) = 1

;���E���؎a
[State -1]
type = ChangeState
value = 1010
triggerall = command = "����y" && fvar(28) = 0 || command = "����y" && fvar(28) = 1
triggerall = statetype != A && numhelper(1040) = 0
trigger1 = ctrl || anim = 101

;���E���؎a�E�L�����Z��
[State -1]
type = ChangeState
value = 1010
triggerall = command = "����y" && fvar(28) = 0 || command = "����y" && fvar(28) = 1
triggerall = statetype != A && numhelper(1040) = 0
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���E���؎a�ǂ��L����
[State -1]
type = ChangeState
value = 1010
triggerall = command = "����y" && fvar(28) = 0 || command = "����y" && fvar(28) = 1
triggerall = statetype != A && var(10) = 1 && var(13) = 0
triggerall = movecontact && numhelper(1040) = 0
trigger1 = var(11) = 1

;===========================================================================
;��E�����؁E�Ҋ�
[State -1]
type = ChangeState
value = 1020
triggerall = command = "����a" && fvar(28) = 0 || command = "����x" && fvar(28) = 2
triggerall = statetype != A && numhelper(1040) = 0
trigger1 = ctrl || anim = 101

;��E�����؁E�Ҋ��E�L�����Z��
[State -1]
type = ChangeState
value = 1020
triggerall = command = "����a" && fvar(28) = 0 || command = "����x" && fvar(28) = 2
triggerall = statetype != A && numhelper(1040) = 0
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;��E�����؁E�Ҋ��ǂ��L����
[State -1]
type = ChangeState
value = 1020
triggerall = command = "����a" && fvar(28) = 0 || command = "����x" && fvar(28) = 2
triggerall = statetype != A && var(10) = 1 && var(13) = 0
triggerall = movecontact && numhelper(1040) = 0
trigger1 = var(11) = 1

;���E�����؁E�Ҋ�
[State -1]
type = ChangeState
value = 1030
triggerall = command = "����b" && fvar(28) = 0 || command = "����y" && fvar(28) = 2
triggerall = statetype != A && numhelper(1040) = 0
trigger1 = ctrl || anim = 101

;���E�����؁E�Ҋ��E�L�����Z��
[State -1]
type = ChangeState
value = 1030
triggerall = command = "����b" && fvar(28) = 0 || command = "����y" && fvar(28) = 2
triggerall = statetype != A && numhelper(1040) = 0
triggerall = movecontact
triggerall = fvar(28) = 0 || fvar(28) = 1 || fvar(28) = 2
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���E�����؁E�Ҋ��ǂ��L����
[State -1]
type = ChangeState
value = 1030
triggerall = command = "����b" && fvar(28) = 0 || command = "����y" && fvar(28) = 2
triggerall = statetype != A && var(10) = 1 && numhelper(1040) = 0
triggerall = movecontact && var(13) = 0
trigger1 = var(11) = 1

;===========================================================================
;��E�O��E
[State -1]
type = ChangeState
value = 1200
triggerall = command = "�g��a" && fvar(28) = 0 || command = "�g��x" && fvar(28) = 2
triggerall = statetype != A
trigger1 = ctrl || anim = 101

;��E�O��E�E�L�����Z��
[State -1]
type = ChangeState
value = 1200
triggerall = command = "�g��a" && fvar(28) = 0 || command = "�g��x" && fvar(28) = 2
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;��E�O��E�ǂ��L����
[State -1]
type = ChangeState
value = 1200
triggerall = command = "�g��a" && fvar(28) = 0 || command = "�g��x" && fvar(28) = 2
triggerall = statetype != A && var(10) = 1
triggerall = movecontact && var(13) = 0
trigger1 = var(11) = 1

;���E�O��E
[State -1]
type = ChangeState
value = 1210
triggerall = command = "�g��b" && fvar(28) = 0 || command = "�g��y" && fvar(28) = 2
triggerall = statetype != A
trigger1 = ctrl || anim = 101

;���E�O��E�E�L�����Z��
[State -1]
type = ChangeState
value = 1210
triggerall = command = "�g��b" && fvar(28) = 0 || command = "�g��y" && fvar(28) = 2
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���E�O��E�ǂ��L����
[State -1]
type = ChangeState
value = 1210
triggerall = command = "�g��b" && fvar(28) = 0 || command = "�g��y" && fvar(28) = 2
triggerall = statetype != A && var(10) = 1
triggerall = movecontact && var(13) = 0
trigger1 = var(11) = 1

;===========================================================================
;��E�O�A�E
[State -1]
type = ChangeState
value = 1250
triggerall = command = "�g��x" 
triggerall = fvar(28) = 0 || fvar(28) = 1
triggerall = statetype != A
trigger1 = ctrl || anim = 101

;��E�O�A�E�E�L�����Z��
[State -1]
type = ChangeState
value = 1250
triggerall = command = "�g��x" 
triggerall = fvar(28) = 0 || fvar(28) = 1
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;��E�O�A�E�ǂ��L����
[State -1]
type = ChangeState
value = 1250
triggerall = command = "�g��x" 
triggerall = fvar(28) = 0 || fvar(28) = 1
triggerall = statetype != A && var(10) = 1 && var(13) = 0
triggerall = movecontact && (stateno != [1250,1299])
trigger1 = var(11) = 1

;���E�O�A�E
[State -1]
type = ChangeState
value = 1255
triggerall = command = "�g��y" 
triggerall = fvar(28) = 0 || fvar(28) = 1
triggerall = statetype != A
trigger1 = ctrl || anim = 101

;���E�O�A�E�E�L�����Z��
[State -1]
type = ChangeState
value = 1255
triggerall = command = "�g��y" 
triggerall = fvar(28) = 0 || fvar(28) = 1
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;���E�O�A�E�ǂ��L����
[State -1]
type = ChangeState
value = 1255
triggerall = command = "�g��y" 
triggerall = fvar(28) = 0 || fvar(28) = 1
triggerall = statetype != A && var(10) = 1 && var(13) = 0
triggerall = movecontact && (stateno != [1250,1299])
trigger1 = var(11) = 1

;===========================================================================
;�o�b�N�_�b�V��
[State -1,B_Dash]
type = ChangeState
value = 105
triggerall = command = "c"
triggerall = statetype != A && fvar(25) = 1
triggerall = command = "holdback"
trigger1 = ctrl
trigger2 = stateno = 52

;����
[State -1]
type = ChangeState
value = 730
triggerall = command="c"
triggerall = statetype != A && fvar(29) != 1
trigger1 = ctrl
trigger2 = stateno = 100
trigger3 = stateno = 52

;---------------------------------------------------------------------------
;AB����
[State -1]
type = ChangeState
value = 800
triggerall = (fvar(28) = 1 && command = "AB")
triggerall = statetype = S && fvar(13) = 0
triggerall = ctrl || anim = 101
triggerall = stateno != 101
trigger1 = (p2statetype = S) || (p2statetype = C)
trigger1 = p2movetype != H
trigger2 = (p2statetype = S) || (p2statetype = C)
trigger2 = p2movetype != H
trigger2 = command = "holdfwd" || command = "holdback"

;AB����
[State -1]
type = ChangeState
value = 800
triggerall = (fvar(28) != 1 && command = "y")
triggerall = command = "holdfwd" || command = "holdback"
triggerall = statetype = S && fvar(13) = 0
triggerall = (p2bodydist X = [-8,8])
triggerall = ctrl || anim = 101
triggerall = stateno != 101
trigger1 = (p2statetype = S) || (p2statetype = C)
trigger1 = p2movetype != H

;---------------------------------------------------------------------------
;CD����2
[State -1]
type = ChangeState
value = 900
triggerall = (fvar(28) = 1 && command = "CD")
triggerall = statetype = S && fvar(13) = 0
triggerall = ctrl || anim = 101
triggerall = stateno != 101
trigger1 = (p2statetype = S) || (p2statetype = C)
trigger1 = p2movetype != H
trigger2 = (p2statetype = S) || (p2statetype = C)
trigger2 = p2movetype != H
trigger2 = command = "holdfwd" || command = "holdback"

;CD����
[State -1]
type = ChangeState
value = 900
triggerall = (fvar(28) != 1 && command = "b")
triggerall = command = "holdfwd" || command = "holdback"
triggerall = statetype = S && fvar(13) = 0
triggerall = (p2bodydist X = [-8,8])
triggerall = ctrl || anim = 101
triggerall = stateno != 101
trigger1 = (p2statetype = S) || (p2statetype = C)
trigger1 = p2movetype != H

;========================================================================
;��ǂ�����
[State -1]
type = ChangeState
value = 710
triggerall = command = "x" || command = "y" || command = "a"
triggerall = command = "holdup"
triggerall = fvar(29) != 1
triggerall = statetype != A
triggerall = (enemy,stateno = [5100,5110]) || (enemy,stateno = 5050 && enemy,canrecover = 0) || (enemy,stateno = 1391 && enemy,movetype = H) || ((enemy,stateno = [3900,3920]) && enemy,movetype = H)
trigger1 = ctrl || anim = 101
trigger2 = stateno = 40 || (stateno = [10,12]) || (stateno =[52,53])
;========================================================================
;���ǂ�����
[State -1]
type = ChangeState
value = 194
triggerall = command = "x" || command = "y" || command = "a"
triggerall = command = "holdfwd" && command = "holddown"
triggerall = statetype != A
triggerall = (p2stateno = [5100,5120]) || p2statetype = L || ((enemy,stateno = [3900,3920]) && enemy,movetype = H)
triggerall = fvar(29) != 1
trigger1 = ctrl || anim = 101

;========================================================================
;�ǂ�����
[State -1]
type = ChangeState
value = 501
triggerall = command = "b" && command = "holdfwd" && command = "holddown"
triggerall = statetype != A
triggerall = (p2stateno = [5100,5120]) || p2statetype = L || ((enemy,stateno = [3900,3920]) && enemy,movetype = H)
triggerall = fvar(29) != 1
trigger1 = ctrl || anim = 101

;========================================================================
;�ǂ�����
[State -1]
type = ChangeState
value = 500
triggerall = command = "b" && command = "holdfwd" && command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || anim = 101

;�ǂ�����
[State -1]
type = ChangeState
value = 505
triggerall = command = "b" && command = "holdfwd" && command = "holddown"
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = 205) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger2 = (stateno = 215) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 245) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger5 = (stateno = 400) && animelem = 3,>= 0 && animelem = 4,<= 0
trigger6 = (stateno = 415) && animelem = 6,>= 0 && animelem = 7,<= 0

;========================================================================
;---------------------------------------------------------------------------
;GCFS
[State -1,FS]
type = ChangeState
value = 260
triggerall = Power>=1000 && (fvar(29) = [0,1])
triggerall = stateno=150 || stateno=152
triggerall = Statetype!=A
trigger1 = command = "FS"
trigger2 = command = "c"

;GCFS
[State -1,FS]
type = ChangeState
value = 260
triggerall = Power>=1000 && (fvar(29) = [0,1])
triggerall = stateno=150 || stateno=152
triggerall = Statetype != A
trigger1 = command = "FF"

;---------------------------------------------------------------------------
;���i
[State -1,]
type = ChangeState
value = 545
triggerall = Statetype != A && ctrl = 1
triggerall = fvar(29) != 1
trigger1 = command = "FS"

;�_�b�V��
[State -1,Dash]
type = ChangeState
value = 100
triggerall = Statetype != A && ctrl
trigger1 = command = "FF"

;�o�b�N�_�b�V��
[State -1,B_Dash]
type = ChangeState
value = 105
triggerall = Statetype != A && ctrl
trigger1 = command = "BB"
trigger1 = command != "�t����"

;GC�U��
[State -1,GC_Attack]
type = ChangeState
value = 255
triggerall = Power>=1000
triggerall = stateno=150 || stateno=152
triggerall = Statetype != A
trigger1 = command = "CD" || command = "z"


;===========================================================================
;����
[State -1]
type = ChangeState
value = ifelse(p2stateno=195,196,195)
triggerall = command = "start"
triggerall = statetype != A && var(1) = 0
trigger1 = ctrl || anim = 101
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;������a��
[State -1]
type = ChangeState
value = ifelse(p2bodydist X <= 22,205,200)
triggerall = command = "x"
triggerall = command != "holddown" && var(1) = 0 && stateno != 100
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52
trigger3 = stateno = 205 && movecontact && fvar(13) = 0
trigger4 = stateno = 400 && movecontact && fvar(13) = 0

;�������a��
[State -1]
type = ChangeState
value = ifelse(p2bodydist X <= 46,215,210)
triggerall = command = "a"
triggerall = command != "holddown" && var(1) = 0 && stateno != 100
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52

;������a��
[State -1]
type = ChangeState
value = ifelse(p2bodydist X <= 35,235,230)
triggerall = command = "y"
triggerall = command != "holddown" && var(1) = 0 && stateno != 100
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52

;�������L�b�N
[State -1]
type = ChangeState
value = ifelse(p2bodydist X <= 25,245,240)
triggerall = command = "b"
triggerall = command != "holddown" && var(1) = 0 && stateno != 100
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;�K�[�h����
[State -1]
type = ChangeState
value = 550
triggerall = command = "z" && var(13) = 0
triggerall = command != "holddown" && var(1) = 0 && fvar(25) = 1
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�a��
[State -1]
type = ChangeState
value = 400
triggerall = command = "x"
triggerall = command = "holddown" && var(1) = 0 && stateno != 100
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 52
trigger3 = stateno = 205 && movecontact && fvar(13) = 0
trigger4 = stateno = 400 && movecontact && fvar(13) = 0

;---------------------------------------------------------------------------
;���Ⴊ�ݒ��a��
[State -1]
type = ChangeState
value = ifelse(p2bodydist X <= 30,415,410)
triggerall = command = "a"
triggerall = command = "holddown" && var(1) = 0 && stateno != 100
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;���Ⴊ�݋��a��
[State -1]
type = ChangeState
value = ifelse(p2bodydist X <= 60,435,430)
triggerall = command = "y"
triggerall = command = "holddown" && var(1) = 0 && stateno != 100
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;���Ⴊ�݃L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = command = "b"
triggerall = command = "holddown" && var(1) = 0 && stateno != 100
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;�󒆎�a��
[State -1]
type = ChangeState
value = 600
triggerall = command = "x" && var(1) = 0
trigger1 = statetype = A
trigger1 = ctrl
;---------------------------------------------------------------------------
;�󒆒��a��
[State -1]
type = ChangeState
value = 610
triggerall = command = "a" && var(1) = 0
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆋��a��
[State -1]
type = ChangeState
value = ifelse(vel X = 0,630,635)
triggerall = command = "y" && var(1) = 0
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆏R��
[State -1]
type = ChangeState
value = 640
triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl


