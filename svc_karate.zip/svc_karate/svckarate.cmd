;-| AI |------------------------------------------------------
[Command]
name = "CPU1"
command = U, D, F
time = 1

[Command]
name = "CPU2"
command = U, B, F
time = 1

[Command]
name = "CPU3"
command = U, D, D
time = 1

[Command]
name = "CPU4"
command = F, B, U
time = 1

[Command]
name = "CPU5"
command = U, F, U, B
time = 1

[Command]
name = "CPU6"
command = U, D, B
time = 1

[Command]
name = "CPU7"
command = F, F, B
time = 1

[Command]
name = "CPU8"
command = U, D, U
time = 1

[Command]
name = "CPU9"
command = F, B, B
time = 1

[Command]
name = "CPU10"
command = F, F, B, B
time = 1

[Command]
name = "CPU11"
command = U, U, F
time = 1

[Command]
name = "CPU12"
command = U, B, B
time = 1

[Command]
name = "CPU13"
command = U, B, F, F
time = 1

[Command]
name = "CPU14"
command = U, F, B, U
time = 1

[Command]
name = "CPU15"
command = U, B, F, U
time = 1

[Command]
name = "CPU16"
command = U, B, B, B
time = 1

[Command]
name = "CPU17"
command = U, D, B, F
time = 1

[Command]
name = "CPU18"
command = U, D, B, D
time = 1

[Command]
name = "CPU19"
command = U, D, F, U
time = 1

[Command]
name = "CPU20"
command = U, D, U, B
time = 1

[Command]
name = "CPU21"
command = U, D, F, F
time = 1

[Command]
name = "CPU22"
command = F, F, F, F
time = 1

[Command]
name = "CPU23"
command = U, U, U, D
time = 1

[Command]
name = "CPU24"
command = B, B, B
time = 1

[Command]
name = "CPU25"
command = D, D, D, D
time = 1

[Command]
name = "CPU26"
command = D, D, D
time = 1

[Command]
name = "CPU27"
command = F, F, F
time = 1

[Command]
name = "CPU28"
command = U, U, U
time = 1

[Command]
name = "CPU29"
command = U, U, B, B
time = 1

[Command]
name = "CPU30"
command = D, D, F, F
time = 1

[Command]
name = "CPU31"
command = U, D, F, U, D
time = 1

[Command]
name = "CPU32"
command = U, B, F, U, D
time = 1

[Command]
name = "CPU33"
command = U, D, D, U, D
time = 1

[Command]
name = "CPU34"
command = F, B, U, U, D
time = 1

[Command]
name = "CPU35"
command = U, F, U, B, U, D
time = 1

[Command]
name = "CPU36"
command = U, D, B, U, D
time = 1

[Command]
name = "CPU37"
command = F, F, B, U, D
time = 1

[Command]
name = "CPU38"
command = U, D, U, U, D
time = 1

[Command]
name = "CPU39"
command = F, B, B, U, D
time = 1

[Command]
name = "CPU40"
command = F, F, B, B, U, D
time = 1

[Command]
name = "CPU41"
command = U, U, F, U, D
time = 1

[Command]
name = "CPU42"
command = U, B, B, U, D
time = 1

[Command]
name = "CPU43"
command = U, B, F, F, U, D
time = 1

[Command]
name = "CPU44"
command = U, F, B, U, U, D
time = 1

[Command]
name = "CPU45"
command = U, B, F, U, U, D
time = 1

[Command]
name = "CPU46"
command = U, B, B, B, U, D
time = 1

[Command]
name = "CPU47"
command = U, D, B, F, U, D
time = 1

[Command]
name = "CPU48"
command = U, D, B, D, U, D
time = 1

[Command]
name = "CPU49"
command = U, D, F, U, U, D
time = 1

[Command]
name = "CPU50"
command = U, D, U, B, U, D
time = 1

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name = "ranbu1"
command = ~D, DF, F, DF, D, DB, B, x
time = 35

[Command]
name = "ranbu2"
command = ~D, DF, F, DF, D, DB, B, y
time = 35

[Command]
name = "ranbu3"
command = ~D, DF, F, DF, D, DB, B, x+y
time = 40

[Command]
name = "kijin_s"
command = ~D, DB, B, D, DB, x+y
time = 35

[Command]
name = "kohou_s"
command = ~D, DF, F, D, DF, x
time = 35

[Command]
name = "kohou_s"
command = ~D, DF, F, D, DF, y
time = 35

[Command]
name = "sikou3"
command = ~F, B, DB, D, DF, F, x+y
time = 35

;-| �K�E�Z |------------------------------------------------------
[Command]
name = "sikou1"
command = ~F, B, DB, D, DF, F, x
time = 35

[Command]
name = "sikou2"
command = ~F, B, DB, D, DF, F, y
time = 35

[Command]
name = "kijin"
command = ~D, DB, B, D, DB, x
time = 35

[Command]
name = "kijin"
command = ~D, DB, B, D, DB, y
time = 35

[Command]
name = "koou1"
command = ~D, DF, F, x
time = 12

[Command]
name = "koou2"
command = ~D, DF, F, y
time = 12

[Command]
name = "kohou1"
command = ~F, D, DF, x
time = 12

[Command]
name = "kohou2"
command = ~F, D, DF, y
time = 12

[Command]
name = "burai1"
command = ~D, DB, B, x
time = 12

[Command]
name = "burai2"
command = ~D, DB, B, y
time = 12

[Command]
name = "zanretsu1"
command = ~B, D, DB, x
time = 15

[Command]
name = "zanretsu2"
command = ~B, D, DB, y
time = 15

[Command]
name = "hien1"
command = ~D, B, a
time = 12

[Command]
name = "hien2"
command = ~D, B, b
time = 12

[Command]
name = "shoran1"
command = ~F, DF, D, DB, B, a
time = 18

[Command]
name = "shoran2"
command = ~F, DF, D, DB, B, b
time = 18

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "longjump"
command = D, $U
time = 12

[Command]
name = "FF"     
command = F, F
time = 12

[Command]
name = "BB"     
command = B, B
time = 10

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "recovery"
command = x+a
time = 10

[Command]
name = "throw_1"
command = x+a
time = 10

[Command]
name = "throw_2"
command = y+b
time = 10

[Command]
name = "gc_step"
command = y+a
time = 10

;-| �����ƃ{�^���ŏo���Z |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "chargex"
command = /x
time = 1

[Command]
name = "chargey"
command = /y
time = 1

[Command]
name = "chargea"
command = /a
time = 1

; ���̋L�q���͐�΂ɏ����Ȃ��ł��������B
[Statedef -1]
;===========================================================================
;AI�p

;AI
[State -1, AI]
type = VarSet
triggerall = var(59) != 1
;triggerall = var(12) = 0
triggerall = RoundState != 3
trigger1  = command = "CPU1"
trigger2  = command = "CPU2"
trigger3  = command = "CPU3"
trigger4  = command = "CPU4"
trigger5  = command = "CPU5"
trigger6  = command = "CPU6"
trigger7  = command = "CPU7"
trigger8  = command = "CPU8"
trigger9  = command = "CPU9"
trigger10  = command = "CPU10"
trigger11  = command = "CPU11"
trigger12  = command = "CPU12"
trigger13  = command = "CPU13"
trigger14  = command = "CPU14"
trigger15  = command = "CPU15"
trigger16  = command = "CPU16"
trigger17  = command = "CPU17"
trigger18  = command = "CPU18"
trigger19  = command = "CPU19"
trigger20  = command = "CPU20"
trigger21  = command = "CPU21"
trigger22  = command = "CPU22"
trigger23  = command = "CPU23"
trigger24  = command = "CPU24"
trigger25  = command = "CPU25"
trigger26  = command = "CPU26"
trigger27  = command = "CPU27"
trigger28  = command = "CPU28"
trigger29  = command = "CPU29"
trigger30  = command = "CPU30"
trigger31  = command = "CPU31"
trigger32  = command = "CPU32"
trigger33  = command = "CPU33"
trigger34  = command = "CPU34"
trigger35  = command = "CPU35"
trigger36  = command = "CPU36"
trigger37  = command = "CPU37"
trigger38  = command = "CPU38"
trigger39  = command = "CPU39"
trigger40  = command = "CPU40"
trigger41  = command = "CPU41"
trigger42  = command = "CPU42"
trigger43  = command = "CPU43"
trigger44  = command = "CPU44"
trigger45  = command = "CPU45"
trigger46  = command = "CPU46"
trigger47  = command = "CPU47"
trigger48  = command = "CPU48"
trigger49  = command = "CPU49"
trigger50  = command = "CPU50"
var(59) = 1

;===========================================================================
;===========================================================================
;�K�[�h
[state -1, Guard]
type = ChangeState
value = Ifelse (StateType != A && (Enemy, HitDefAttr = SA, AA, AT, AP), 130, ifelse (StateType = A, 132, 131))
triggerall = Var(59)= 1 && MoveType = I && enemy,MoveType = A  && (abs(enemynear,Pos X - Pos X)) <= 60 && Ctrl
trigger1 = Random <= ifelse (StateType = A,150,250) 

;---------------------------------------------------------------------------
;�W�����v
[State -1, Jump]
type = ChangeState
value = 40
triggerall = Var(59) = 1 && StateType != A && enemy,MoveType = I && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))
trigger1 = BackEdgebodyDist > 5 && (abs(enemynear,Pos X - Pos X)) <= 110 && Random <= 150
trigger2 = ((abs(enemynear,Pos X - Pos X)) >= 100 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random = [300,400]

;---------------------------------------------------------------------------
;��g
[State -1]
type = ChangeState
value = 5210
triggerall = Var(59) = 1 && Alive && GetHitVar(fall.recover) && Vel Y > -1 && random <= 550
trigger1 = StateNo = 5050
persistent = 0

;---------------------------------------------------------------------------
;��g�i�󒆁j
[State -1]
type = ChangeState
value = 5200
triggerall = Var(59) = 1 && Alive && GetHitVar(fall.recover) && Vel Y > 0 && Pos Y >= -20 && random <= 250
trigger1 = StateNo = 5050
persistent = 0

;---------------------------------------------------------------------------
;�����՗���
[State -1, gate]
type = ChangeState
value = 3100
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = (100*life/const(data.life))<=50
triggerall = var(53) = 0
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [0,120]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && (abs(enemynear,Pos Y - Pos Y)) <= 30) && Random <= 400
trigger2 = stateno = 365 && (var(48) = 1 || var(48) = 2) && Random <= 750
trigger3 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && (animelem=14,>0 && animelem=15,<0) && var(46) && Random <= 200

;---------------------------------------------------------------------------
;���e���������i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 3300
triggerall = var(12) = 10
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = (100*life/const(data.life))<=50
triggerall = var(53) = 0
triggerall = statetype != A
triggerall = enemy,statetype != L
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 150 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && (Random = [601,640]) && P2MoveType != H
trigger2 = var(11) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && (Random = [350,550]) && ((abs(enemynear,Pos Y - Pos Y)) <= 180 && (abs(enemynear,Pos Y - Pos Y)) >= 100)

;---------------------------------------------------------------------------
;���e���������i�{�C�j
[State -1, gate]
type = ChangeState
value = 3000
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 200 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 150 && P2MoveType != H

;---------------------------------------------------------------------------
;�^�E�S�_��
[State -1, gate]
type = ChangeState
value = 3200
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = power >= 1000
triggerall = statetype != A
triggerall = enemy,statetype != L
triggerall = P2BodyDist X < 30
triggerall = p2statetype = S || p2statetype = C
trigger1 = (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && Random = [200,300]

;---------------------------------------------------------------------------
;�Ɍ��ՖC�i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 3400
triggerall = var(12) = 10
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = power >= 1000
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [0,55]) && enemy,MoveType = A && Ctrl) && Random >= 550
trigger2 = var(11) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && (Random = [550,749]) && ((abs(enemynear,Pos Y - Pos Y)) <= 130 && (abs(enemynear,Pos Y - Pos Y)) >= 80)

;---------------------------------------------------------------------------
;�e���������i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 3500
triggerall = var(12) = 10
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = power >= 1000
triggerall = statetype != A
triggerall = enemy,statetype != L
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 200 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && (Random = [551,600]) && P2MoveType != H
trigger2 = var(11) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && (Random = [750,850]) && ((abs(enemynear,Pos Y - Pos Y)) <= 180 && (abs(enemynear,Pos Y - Pos Y)) >= 100)

;---------------------------------------------------------------------------
;�S�_��
[State -1, gate]
type = ChangeState
value = 1700
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
triggerall = P2BodyDist X < 30
triggerall = p2statetype = S || p2statetype = C
trigger1 = (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && Random <= 150

;---------------------------------------------------------------------------
;�e���������i�{�C�j
[State -1, gate]
type = ChangeState
value = 1600
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 200 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && (Random = [551,650]) && P2MoveType != H

;---------------------------------------------------------------------------
;�b�󌝁i�{�C�j
[State -1, gate]
type = ChangeState
value = 1200
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = ((abs(enemynear,Pos X - Pos X)) <= 25 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random = [151,210]
trigger2 = var(11) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && Random <= 450 && ((abs(enemynear,Pos Y - Pos Y)) <= 180 && (abs(enemynear,Pos Y - Pos Y)) >= 100)
trigger3 = stateno = 365 && (var(48) = 1 || var(48) = 2) && (abs(enemynear,Pos X - Pos X)) <= 45 && Random >= 750

;---------------------------------------------------------------------------
;�b�󌝁i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 2100
triggerall = var(12) = 10
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = ((abs(enemynear,Pos X - Pos X)) <= 25 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random = [151,210]
trigger2 = var(11) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && Random > 920 && ((abs(enemynear,Pos Y - Pos Y)) <= 180 && (abs(enemynear,Pos Y - Pos Y)) >= 130)
trigger3 = stateno = 365 && (var(48) = 1 || var(48) = 2) && (abs(enemynear,Pos X - Pos X)) <= 45 && Random >= 850

;---------------------------------------------------------------------------
;�ՖC�i�{�C�j
[State -1, gate]
type = ChangeState
value = 1400
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [0,55]) && enemy,MoveType = A && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 250
trigger2 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && (animelem=11,>0 && animelem=12,<0) && var(46) && Random <= 450
trigger3 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && (animelem=7,>0 && animelem=15,<0) && var(46) && Random >= 830

;---------------------------------------------------------------------------
;�ՖC�i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 1900
triggerall = var(12) = 10
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (P2StateType = A && ((abs(enemynear,Pos X - Pos X)) <= 60) && (abs(enemynear,Pos Y - Pos Y)) <= 40 && Ctrl) && Random <= 400 && enemy,statetype != A

;---------------------------------------------------------------------------
;�������i�{�C�j
[State -1, gate]
type = ChangeState
value = 1000
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 120 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random = [251,400]
trigger2 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2)) && Random >= 660
trigger3 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2)) && Random >= 750
trigger4 = stateno = 365 && (var(48) = 1 || var(48) = 2) && Random = [450,750]

;---------------------------------------------------------------------------
;�������i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 1800
triggerall = var(12) = 10
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 150 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random = [301,400]
trigger2 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2)) && Random >= 560
trigger3 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2)) && Random >= 650
trigger4 = stateno = 365 && (var(48) = 1 || var(48) = 2) && Random = [250,750]

;---------------------------------------------------------------------------
;�ҌՖ�����
[State -1, gate]
type = ChangeState
value = 2200
triggerall = var(12) = 10
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = var(11) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && Random <= 850 && ((abs(enemynear,Pos Y - Pos Y)) <= 180 && (abs(enemynear,Pos Y - Pos Y)) >= 100)

;---------------------------------------------------------------------------
;�Ɍ��ՖC�i�{�C�j
[State -1, gate]
type = ChangeState
value = 1500
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [0,55]) && enemy,MoveType = A && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 250
trigger2 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && (animelem=11,>0 && animelem=12,<0) && var(5) && var(46) && Random <= 450
trigger3 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && (animelem=7,>0 && animelem=15,<0) && var(46) && Random <= 179

;---------------------------------------------------------------------------
;�ė��r
[State -1, gate]
type = ChangeState
value = 2300
triggerall = var(12) = 10
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L && enemy,statetype != A
trigger1 = ((abs(enemynear,Pos X - Pos X)) <= 100 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random >= 920 && P2MoveType != A

;---------------------------------------------------------------------------
;�򉍎����r�i�{�C�j
[State -1, gate]
type = ChangeState
value = 1100
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 100 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random = [550,600]
trigger2 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || var(48) = 1) && Random >= 450
trigger3 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && (animelem=11,>0 && animelem=12,<0) && var(5) && var(46) && Random = [880,950]
trigger4 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && (animelem=11,>0 && animelem=12,<0) && var(46) && Random = [580,600]
trigger5 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && (animelem=7,>0 && animelem=8,<0) && var(46) && Random = [180,400]

;---------------------------------------------------------------------------
;�򉍎����r�i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 2000
triggerall = var(12) = 10
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 130 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random = [550,600]
trigger2 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || var(48) = 1) && Random >= 780

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���t�����g�X�e�b�v
[State -1]
type = ChangeState
value = 101
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = Power >= 200
triggerall = Random = [500,550]
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 1300
triggerall = var(12) = 0
triggerall = var(59) = 1
triggerall = var(46) = 0
triggerall = statetype != A
triggerall = roundstate = 2
trigger1 = power < 3000
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 180 && Ctrl) && Random >= 900

;---------------------------------------------------------------------------
;�t�����g�O�����h�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(59) = 1
triggerall = roundstate = 2
trigger1 = statetype = S
trigger1 = ((abs(enemynear,Pos X - Pos X)) >= 90 && Ctrl) && Random = [650,850+var(12)*10]

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 1
triggerall = roundstate = 2
trigger1 = statetype = S
trigger1 = ((abs(enemynear,Pos X - Pos X)) <= 100 && Ctrl) && Random >= 990

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = enemy,statetype != L
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 102 || stateno = 103) && animelem=2,>0)
trigger1 = ((abs(enemynear,Pos X - Pos X)) <= 30 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 150

;---------------------------------------------------------------------------
;�S��
[State -1]
type = ChangeState
value = 360
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = ((abs(enemynear,Pos X - Pos X)) <= 50 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && enemy,statetype != A && Random <= 90
trigger2 = ((abs(enemynear,Pos X - Pos X)) <= 50 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && enemy,statetype = C && Random >= 900

;---------------------------------------------------------------------------
;�S�ԁi�L�����Z���Łj
[State -1]
type = ChangeState
value = 365
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2)) && Random <= 120 && enemy,statetype != A && ((abs(enemynear,Pos X - Pos X)) >= 32)
trigger2 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2)) && Random <= 120 && enemy,statetype != A && ((abs(enemynear,Pos X - Pos X)) >= 32)
trigger3 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2)) && Random <= 120 && enemy,statetype != A && ((abs(enemynear,Pos X - Pos X)) >= 32)
trigger4 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2)) && Random <= 120 && enemy,statetype != A && ((abs(enemynear,Pos X - Pos X)) >= 32)
trigger5 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12) && Random <= 120 && enemy,statetype != A && ((abs(enemynear,Pos X - Pos X)) >= 32)
trigger6 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12) && Random <= 120 && enemy,statetype != A && ((abs(enemynear,Pos X - Pos X)) >= 32)

;---------------------------------------------------------------------------
;�ߋ���������p���`
[State -1, Taunt]
type = ChangeState
value = 201
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X <= 20
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = ((abs(enemynear,Pos X - Pos X)) <= 35 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 100 && P2MoveType != H

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [45,55]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 300 && P2MoveType != H

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [0,45]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 50 && P2MoveType != H
trigger2 = enemy,MoveType = H && ((abs(enemynear,Pos X - Pos X)) = [0,45]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && Random <= 550 && enemy,statetype != A

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [50,65]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 50 && P2MoveType != H

;---------------------------------------------------------------------------
;�ߋ���������L�b�N
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = P2BodyDist X <= 20
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [0,45]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random >= 850 && P2MoveType != H

;---------------------------------------------------------------------------
;������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [46,60]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && (Random = [150,240])

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = ((abs(enemynear,Pos X - Pos X)) <= 40 && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 80 && P2MoveType != H

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 410
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [0,45]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 50 && P2MoveType != H
trigger2 = enemy,MoveType = H && ((abs(enemynear,Pos X - Pos X)) = [10,50]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)) && Random <= 350 && enemy,statetype != A
trigger3 = (P2StateType = A && ((abs(enemynear,Pos X - Pos X)) <= 50) && (abs(enemynear,Pos Y - Pos Y)) <= 60 && Ctrl) && Random <= 800 && enemy,statetype != A

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [0,70-(var(12)*2)]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random <= 180

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = enemy,statetype != L
trigger1 = (((abs(enemynear,Pos X - Pos X)) = [0,70]) && (ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0))) && Random >= 880

;---------------------------------------------------------------------------
;�����W�����v��L�b�N
[State -1]
type = ChangeState
value = 621
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = vel X = 0 && var(12) = 10
trigger1 = ctrl
trigger1 = ((abs(enemynear,Pos X - Pos X)) = [50,100]) && (Random = [51,400]) && time > 8 && Ctrl

;---------------------------------------------------------------------------
;�΂߃W�����v��L�b�N
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = (vel X != 0 && var(12) = 10) || var(12) = 0
trigger1 = ctrl
trigger1 = ((abs(enemynear,Pos X - Pos X)) = [30,100]) && (Random = [51,400]) && time > 8 && Ctrl

;---------------------------------------------------------------------------
;�����W�����v���L�b�N
[State -1]
type = ChangeState
value = 631
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = vel X = 0
trigger1 = ctrl
trigger1 = (abs(enemynear,Pos X - Pos X)) <= 80 && (Random = [451,900]) && time > 8 && Ctrl
 
;---------------------------------------------------------------------------
;�΂߃W�����v���L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = var(59) = 1
triggerall = roundstate = 2
triggerall = statetype = A
triggerall = vel X != 0
trigger1 = ctrl
trigger1 = (abs(enemynear,Pos X - Pos X)) <= 80 && (Random = [451,900]) && time > 8 && Ctrl

;===========================================================================
;---------------------------------------------------------------------------
;�����՗���
[State -1, gate]
type = ChangeState
value = 3100
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "ranbu3"
triggerall = (100*life/const(data.life))<=50
triggerall = var(53) = 0
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 350 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger18 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger19 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger20 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger21 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;���e���������i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 3300
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "sikou3"
triggerall = (100*life/const(data.life))<=50
triggerall = var(53) = 0
triggerall = statetype != A
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 350 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger18 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger19 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger20 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger21 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;���e���������i�{�C�j
[State -1, gate]
type = ChangeState
value = 3000
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "sikou3"
triggerall = power >= 1000
triggerall = statetype != A
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 350 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger18 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger19 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger20 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger21 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�^�E�S�_��
[State -1, gate]
type = ChangeState
value = 3200
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "kijin_s"
triggerall = power >= 1000
triggerall = statetype != A
triggerall = P2BodyDist X < 30
triggerall = p2statetype = S || p2statetype = C
;triggerall = p2movetype != H
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 350 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger18 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger19 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger20 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger21 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�Ɍ��ՖC�i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 3400
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "kohou_s"
triggerall = power >= 1000
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 350 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger18 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger19 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger20 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger21 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�e���������i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 3500
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "sikou1" || Command = "sikou2"
triggerall = power >= 1000
triggerall = statetype != A
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 350 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger18 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger19 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger20 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger21 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�S�_��
[State -1, gate]
type = ChangeState
value = 1700
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "kijin"
triggerall = statetype != A
triggerall = P2BodyDist X < 30
triggerall = p2statetype = S || p2statetype = C
;triggerall = p2movetype != H
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1900 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�e���������i�{�C�j
[State -1, gate]
type = ChangeState
value = 1600
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "sikou1" || Command = "sikou2"
triggerall = statetype != A
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 1900 && (var(48) = 1 || var(48) = 2) && var(46)
trigger40 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�b�󌝁i�{�C�j
[State -1, gate]
type = ChangeState
value = 1200
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "zanretsu1" || Command = "zanretsu2"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)

;---------------------------------------------------------------------------
;�b�󌝁i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 2100
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "zanretsu1" || Command = "zanretsu2"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)

;---------------------------------------------------------------------------
;�ՖC�i�{�C�j
[State -1, gate]
type = ChangeState
value = 1400
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "kohou1" || Command = "kohou2"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1900 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�ՖC�i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 1900
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "kohou1" || Command = "kohou2"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�������i�{�C�j
[State -1, gate]
type = ChangeState
value = 1000
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "koou1" || Command = "koou2"
triggerall = statetype != A
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 1900 && (var(48) = 1 || var(48) = 2) && var(46)
trigger40 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�������i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 1800
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "koou1" || Command = "koou2"
triggerall = statetype != A
triggerall = NumProjID(1005) = 0 && NumProjID(1605) = 0 && NumProjID(1805) = 0 && NumProjID(3005) = 0 && NumProjID(3305) = 0 && NumProjID(3505) = 0
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 1900 && (var(48) = 1 || var(48) = 2) && var(46)
trigger40 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�ҌՖ�����
[State -1, gate]
type = ChangeState
value = 2200
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "burai1" || Command = "burai2"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 1900 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�Ɍ��ՖC�i�{�C�j
[State -1, gate]
type = ChangeState
value = 1500
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "kohou_s"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1900 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�ė��r
[State -1, gate]
type = ChangeState
value = 2300
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "shoran1" || Command = "shoran2"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)

;---------------------------------------------------------------------------
;�򉍎����r�i�{�C�j
[State -1, gate]
type = ChangeState
value = 1100
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "hien1" || Command = "hien2"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 1900 && (var(48) = 1 || var(48) = 2) && var(46)
trigger40 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;---------------------------------------------------------------------------
;�򉍎����r�i�m�[�}���j
[State -1, gate]
type = ChangeState
value = 2000
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Command = "hien1" || Command = "hien2"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger11 = stateno = 325 && (var(48) = 1 || var(48) = 2)
trigger12 = stateno = 335 && (var(48) = 1 || var(48) = 2)
trigger13 = stateno = 340 && (var(48) = 1 || var(48) = 2)
trigger14 = stateno = 355 && (var(48) = 1 || var(48) = 2)
trigger15 = stateno = 360 && (var(48) = 1 || var(48) = 2)
trigger16 = stateno = 365 && (var(48) = 1 || var(48) = 2)
trigger17 = stateno = 200 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger18 = stateno = 201 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger19 = stateno = 211 && (animelem=3,<0 || animelem=5,>0) && var(46)
trigger20 = stateno = 221 && (animelem=5,<0 || animelem=6,>0) && var(46)
trigger21 = stateno = 400 && (animelem=2,<0 || animelem=4,>0) && var(46)
trigger22 = stateno = 410 && (animelem=3,<0 || animelem=6,>0) && var(46)
trigger23 = stateno = 420 && (animelem=5,<0 || animelem=7,>0) && var(46) && !var(12)
trigger24 = stateno = 420 && (animelem=2,<0 || animelem=3,>0) && var(46) && var(12)
trigger25 = stateno = 430 && (animelem=3,<0 || animelem=4,>0) && var(46)
trigger26 = stateno = 210 && var(46)
trigger27 = stateno = 220 && var(46)
trigger28 = stateno = 230 && var(46)
trigger29 = stateno = 231 && var(46)
trigger30 = stateno = 300 && (var(48) = 1 || var(48) = 2) && var(46)
trigger31 = stateno = 310 && (var(48) = 1 || var(48) = 2) && var(46)
trigger32 = stateno = 320 && (var(48) = 1 || var(48) = 2) && var(46)
trigger33 = stateno = 330 && (var(48) = 1 || var(48) = 2) && var(46)
trigger34 = stateno = 350 && (var(48) = 1 || var(48) = 2) && var(46)
trigger35 = stateno = 370 && (var(48) = 1 || var(48) = 2) && var(46)
trigger36 = stateno = 1400 && (var(48) = 1 || var(48) = 2) && var(46)
trigger37 = stateno = 1500 && (var(48) = 1 || var(48) = 2) && var(46)
trigger38 = stateno = 1700 && (var(48) = 1 || var(48) = 2) && var(46)
trigger39 = stateno = 1900 && (var(48) = 1 || var(48) = 2) && var(46)
trigger40 = stateno = 2200 && (var(48) = 1 || var(48) = 2) && var(46)

;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z���U��
[State -1]
type = ChangeState
value = ifelse(var(12),345,235)
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = Power >= 1000 
triggerall = Command = "throw_2" 
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�K�[�h�L�����Z���t�����g�X�e�b�v
[State -1]
type = ChangeState
value = 101
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = (Command = "gc_step" && Power >= 600) || (Command = "FF" && Power >= 200)
trigger1 = stateno = 150
trigger2 = stateno = 151
trigger3 = stateno = 152
trigger4 = stateno = 153

;---------------------------------------------------------------------------
;�p���[����
[State -1]
type = ChangeState
value = 1300
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = var(46) = 0
triggerall = statetype != A
triggerall = ctrl
triggerall = (command = "chargex" && command = "chargey" && command = "chargea")
triggerall = roundstate = 2
trigger1 = power < 3000

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = var(59) = 0
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;�t�����g�O�����h�X�e�b�v
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(59) = 0
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall = var(59) = 0
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�O�p����
[State -1, Run Back]
type = ChangeState
value = 48
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = command = "holdup"
triggerall = stateno = 50 && prevstateno != 48
triggerall = pos y < -20
trigger1 = frontedgebodydist < 5 && command = "holdback"
trigger2 = backedgebodydist < 5 && command = "holdfwd"

;---------------------------------------------------------------------------
;����
[State -1, Throw]
type = ChangeState
value = 900
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = (command = "throw_1" || command = "throw_2")
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 102 || stateno = 103) && animelem=2,>0)

;---------------------------------------------------------------------------
;�����U���i�p���`�j
[State -1]
type = ChangeState
value = 300
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown" && command = "holdback"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))

;---------------------------------------------------------------------------
;�����U���i�L�b�N�j
[State -1]
type = ChangeState
value = 310
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown" && command = "holdback"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))

;---------------------------------------------------------------------------
;�{�f�B�[�u���[
[State -1]
type = ChangeState
value = 320
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown" && command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;�{�f�B�[�u���[�i�L�����Z���Łj
[State -1]
type = ChangeState
value = 325
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown" && command = "holdfwd"
triggerall = statetype != A
trigger1 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger2 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger8 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger9 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))

;---------------------------------------------------------------------------
;���[�L�b�N
[State -1]
type = ChangeState
value = 330
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown" && command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;���[�L�b�N�i�L�����Z���Łj
[State -1]
type = ChangeState
value = 335
triggerall = var(12) = 0
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown" && command = "holdfwd"
triggerall = statetype != A
trigger1 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger2 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger8 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger9 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))

;---------------------------------------------------------------------------
;�S���낵
[State -1]
type = ChangeState
value = 340
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown" && command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))

;---------------------------------------------------------------------------
;������
[State -1]
type = ChangeState
value = 350
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown" && command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;������i�L�����Z���Łj
[State -1]
type = ChangeState
value = 355
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown" && command = "holdfwd"
triggerall = statetype != A
trigger1 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger2 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger8 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger9 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))

;---------------------------------------------------------------------------
;�S��
[State -1]
type = ChangeState
value = 360
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown" && command = "holdfwd"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;�S�ԁi�L�����Z���Łj
[State -1]
type = ChangeState
value = 365
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown" && command = "holdfwd"
triggerall = statetype != A
trigger1 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger2 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger8 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger9 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))

;---------------------------------------------------------------------------
;��ԗ��Ƃ�
[State -1]
type = ChangeState
value = 370
triggerall = var(12) = 10
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown" && command = "holdback"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger3 = stateno = 201 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger4 = stateno = 211 && ((animelem=3,>0 && animelem=5,<0) || (var(48) = 1 || var(48) = 2))
trigger5 = stateno = 221 && ((animelem=5,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger6 = stateno = 400 && ((animelem=2,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))
trigger7 = stateno = 410 && ((animelem=3,>0 && animelem=6,<0) || (var(48) = 1 || var(48) = 2))
trigger8 = stateno = 420 && ((animelem=5,>0 && animelem=7,<0) || (var(48) = 1 || var(48) = 2)) && !var(12)
trigger9 = stateno = 420 && ((animelem=2,>0 && animelem=3,<0) || (var(48) = 1 || var(48) = 2)) && var(12)
trigger10 = stateno = 430 && ((animelem=3,>0 && animelem=4,<0) || (var(48) = 1 || var(48) = 2))

;---------------------------------------------------------------------------
;�ߋ���������p���`
[State -1, Taunt]
type = ChangeState
value = 201
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = P2BodyDist X <= 20
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && animelem=3,>0
trigger3 = stateno = 201 && animelem=3,>0
trigger4 = stateno = 221 && animelem=5,>0
trigger5 = stateno = 400 && animelem=3,>0
trigger6 = stateno = 420 && animelem=2,>0 && var(12)

;---------------------------------------------------------------------------
;������������p���`
[State -1, Taunt]
type = ChangeState
value = 200
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && animelem=3,>0
trigger3 = stateno = 201 && animelem=3,>0
trigger4 = stateno = 221 && animelem=5,>0
trigger5 = stateno = 400 && animelem=3,>0
trigger6 = stateno = 420 && animelem=2,>0 && var(12)

;---------------------------------------------------------------------------
;�ߋ����������p���`
[State -1, Taunt]
type = ChangeState
value = 211
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;�������������p���`
[State -1, Taunt]
type = ChangeState
value = 210
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;�ߋ���������L�b�N
[State -1, Taunt]
type = ChangeState
value = 221
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = P2BodyDist X <= 20
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && animelem=3,>0
trigger3 = stateno = 201 && animelem=3,>0
trigger4 = stateno = 221 && animelem=5,>0
trigger5 = stateno = 400 && animelem=3,>0
trigger6 = stateno = 420 && animelem=2,>0 && var(12)

;---------------------------------------------------------------------------
;������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 220
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && animelem=3,>0
trigger3 = stateno = 201 && animelem=3,>0
trigger4 = stateno = 221 && animelem=5,>0
trigger5 = stateno = 400 && animelem=3,>0
trigger6 = stateno = 420 && animelem=2,>0 && var(12)

;---------------------------------------------------------------------------
;�ߋ����������L�b�N
[State -1, Taunt]
type = ChangeState
value = 231
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = P2BodyDist X <= 25
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;�������������L�b�N
[State -1, Taunt]
type = ChangeState
value = 230
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && animelem=3,>0
trigger3 = stateno = 201 && animelem=3,>0
trigger4 = stateno = 221 && animelem=5,>0
trigger5 = stateno = 400 && animelem=3,>0
trigger6 = stateno = 420 && animelem=2,>0 && var(12)

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 410
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 420
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)
trigger2 = stateno = 200 && animelem=3,>0
trigger3 = stateno = 201 && animelem=3,>0
trigger4 = stateno = 221 && animelem=5,>0
trigger5 = stateno = 400 && animelem=3,>0
trigger6 = stateno = 420 && animelem=2,>0 && var(12)

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || ((stateno = 100 || stateno = 101) && animelem=2,>0)

;---------------------------------------------------------------------------
;�����W�����v��p���`
[State -1]
type = ChangeState
value = 601
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
triggerall = vel X = 0 && var(12) = 10
trigger1 = ctrl

;---------------------------------------------------------------------------
;�΂߃W�����v��p���`
[State -1]
type = ChangeState
value = 600
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "x"
triggerall = statetype = A
triggerall = (vel X != 0 && var(12) = 10) || var(12) = 0
trigger1 = ctrl

;---------------------------------------------------------------------------
;�W�����v���p���`
[State -1]
type = ChangeState
value = 610
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�����W�����v��L�b�N
[State -1]
type = ChangeState
value = 621
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
triggerall = vel X = 0 && var(12) = 10
trigger1 = ctrl

;---------------------------------------------------------------------------
;�΂߃W�����v��L�b�N
[State -1]
type = ChangeState
value = 620
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "a"
triggerall = statetype = A
triggerall = (vel X != 0 && var(12) = 10) || var(12) = 0
trigger1 = ctrl

;---------------------------------------------------------------------------
;�����W�����v���L�b�N
[State -1]
type = ChangeState
value = 631
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
triggerall = vel X = 0
trigger1 = ctrl
 
;---------------------------------------------------------------------------
;�΂߃W�����v���L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = var(59) = 0
triggerall = roundstate = 2
triggerall = command = "b"
triggerall = statetype = A
triggerall = vel X != 0
trigger1 = ctrl

;---------------------------------------------------------------------------