;===========================================================================
; CMD file for Sagat(SVC CHAOS Ver).
;===========================================================================

;-| Super Motions |---------------------------------------------------------
[Command]
name = "qcf2_xy"
command = ~D, DF, F, D, DF, F, x+y
time = 35

[Command]
name = "qcf2_ab"
command = ~D, DF, F, D, DF, F, a+b
time = 35

[Command]
name = "qcf2_x"
command = ~D, DF, F, D, DF, F, x
time = 35

[Command]
name = "qcf2_y"
command = ~D, DF, F, D, DF, F, y
time = 35

[Command]
name = "qcf2_a"
command = ~D, DF, F, D, DF, F, a
time = 35

[Command]
name = "qcf2_b"
command = ~D, DF, F, D, DF, F, b
time = 35

[Command]
name = "qcb2_x"
command = ~D, DB, B, D, DB, B, x
time = 35

[Command]
name = "qcb2_y"
command = ~D, DB, B, D, DB, B, y
time = 35

[Command]
name = "qcb2_a"
command = ~D, DB, B, D, DB, B, a
time = 35

[Command]
name = "qcb2_b"
command = ~D, DB, B, D, DB, B, b
time = 35

;-| Special Motions |-------------------------------------------------------
[Command]
name = "qcf_x"
command = ~D, DF, F, x

[Command]
name = "qcf_y"
command = ~D, DF, F, y

[Command]
name = "qcf_a"
command = ~D, DF, F, a

[Command]
name = "qcf_b"
command = ~D, DF, F, b

[Command]
name = "qcf_s"
command = ~D, DF, F, s

[Command]
name = "dp_x"
command = ~F, D, DF, x

[Command]
name = "dp_y"
command = ~F, D, DF, y

[Command]
name = "dp_a"
command = ~F, D, DF, a

[Command]
name = "dp_b"
command = ~F, D, DF, b

;-| Button Combination |----------------------------------------------------
[Command]
name = "call-st"
command = a+y
time = 1

[Command]
name = "call-st"
command = s
time = 1

[Command]
name = "xa"
command = x+a
time = 1

[Command]
name = "by"
command = y+b
time = 1

[Command]
name = "ay"
command = a+y
time = 1

;-| Dir + Button |----------------------------------------------------------

[Command]
name = "q_fwd"
command = /F, a+x
time = 1

[Command]
name = "q_fwd"
command = /F, z
time = 1

[Command]
name = "q_back"
command = /B, a+x
time = 1

[Command]
name = "q_back"
command = /B, z
time = 1

;-| Single Button |---------------------------------------------------------

[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1

[Command]
name = "down"
command = D
time = 1

;----------------------------- ���o�K�`��
[Command]
name = "random"
command = x
time = 1

[Command]
name = "random"
command = y
time = 1

[Command]
name = "random"
command = z
time = 1

[Command]
name = "random"
command = a
time = 1

[Command]
name = "random"
command = b
time = 1

[Command]
name = "random"
command = c
time = 1

[Command]
name = "random"
command = F
time = 1

[Command]
name = "random"
command = DF
time = 1

[Command]
name = "random"
command = D
time = 1

[Command]
name = "random"
command = DB
time = 1

[Command]
name = "random"
command = B
time = 1

[Command]
name = "random"
command = UB
time = 1

[Command]
name = "random"
command = U
time = 1

[Command]
name = "random"
command = UF
time = 1

;-| Do not remove! |--------------------------------------------------------
[Command]
name = "recovery"
command = a+x
time = 1

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_s"
command = /s
time = 1

[Command]
name = "holdupfwd"
command = /UF
time = 1

[Command]
name = "holdupback"
command = /UB
time = 1

[Command]
name = "fwd_y"
command = /F,y
time = 1

[Command]
name = "fwd_b"
command = /F,b
time = 1

[Command]
name = "back_y"
command = /B,y
time = 1

[Command]
name = "back_b"
command = /B,b
time = 1

;===========================================================================


[Statedef -1]

;=====================================================================
; �L�����Z���ݒ�
;=====================================================================
;------------------------ �L�����Z���ݒ胊�Z�b�g
[State -1]
type = varset
trigger1 = var(40)
var(40) = 0
;------------------------ �X�[�p�[�L�����Z��
[State -1]
type = varset
triggerall = RoundState = 2
triggerall = !var(40)
triggerall = MoveContact
trigger1  = 0
var(40) = -1
removeongethit = 1
;------------------------ �_�b�V���L�����Z��
[State -1]
type = varset
triggerall = RoundState = 2
trigger1 = !var(40)
trigger1 = StateNo = 100 || StateNo = 110 || (StateNo = 4100 && AnimElem = 3,> 0)
var(40) = 1
;------------------------ �K�E�Z�L�����Z��
[State -1]
type = varset
triggerall = RoundState = 2
triggerall = !var(40)
triggerall = MoveContact
trigger1  = StateNo = 200 || StateNo = 205 || StateNo = 210 || StateNo = 230 && AnimElemNo(0) <= 6
trigger2  = StateNo = 400 || StateNo = 420 || StateNo = 305
var(40) = 2
removeongethit = 1
;------------------------ ���K�E�Z�L�����Z��
[State -1]
type = varset
triggerall = RoundState = 2
triggerall = !var(40)
triggerall  = MoveContact
trigger1  = StateNo = 220 || StateNo = 225 || StateNo = 235 && AnimElemNo(0) <= 6
trigger2  = StateNo = 410 || StateNo = 430
var(40) = 3
removeongethit = 1
;------------------------ �ǂ��ł��L�����Z��
[State -1]
type = varset
triggerall = var(30)
triggerall = RoundState = 2
triggerall = !var(40)
triggerall = var(47) && fvar(0) > 0
trigger1  = !MoveContact && (StateNo = 200 || StateNo = 205 || StateNo = 210 || StateNo = 230 && AnimElemNo(0) <= 6)
trigger2  = !MoveContact && (StateNo = 400 || StateNo = 420)
trigger3  = StateNo = 215 || StateNo = 220 || StateNo = 225 || StateNo = 230 && AnimElemNo(0) > 6 || StateNo = 235
trigger4  = StateNo = 410 || StateNo = 430
trigger5  = MoveHit && StateNo = [1000,1999]
var(40) = 4
removeongethit = 1

;=====================================================================
; ��s���͏���
;=====================================================================
;---------------------------------------------------------------------------
; �Z�ԍ�
; 1 -�^�C�K�[�A�b�p�[�J�b�g�E��
; 2 -�^�C�K�[�A�b�p�[�J�b�g�E��
; 3 -�^�C�K�[�V���b�g�E��
; 4 -�^�C�K�[�V���b�g�E��
; 5 -�O�����h�^�C�K�[�V���b�g�E��
; 6 -�O�����h�^�C�K�[�V���b�g�E��
; 7 -�A���O���[�`���[�W
; 8 -�^�C�K�[�N���b�V���E��
; 9 -�^�C�K�[�N���b�V���E��
; 10 -�^�C�K�[�L���m���E��
; 11 -�^�C�K�[�L���m���E��
; 12 -�^�C�K�[�W�F�m�T�C�h�E�m�[�}��
; 13 -�O�����h�^�C�K�[�L���m���E��
; 14 -�O�����h�^�C�K�[�L���m���E��
; 15 -�^�C�K�[���C�h�E��
; 16 -�^�C�K�[���C�h�E��
; 17 -�^�C�K�[�W�F�m�T�C�h�E�l�`�w
; 18 -�^�C�K�[�X�g�[��
;---------------------------------------------------------------------------
[State -1]
type = VarAdd
trigger1 = var(56)
var(56) = -1

[State -1]
type = VarSet
;triggerall = var(56) < 6
trigger1 = !var(56)
trigger2 = (var(55) & 256) && command != "holdup"
trigger3 = (var(55) & 512) && command != "holddown"
trigger4 = (var(55) & 1024) && command != "holdback"
trigger5 = (var(55) & 2048) && command != "holdfwd"
trigger6 = (var(55) & 4096) && command != "hold_a"
trigger7 = (var(55) & 8192) && command != "hold_b"
trigger8 = (var(55) & 16384) && command != "hold_x"
trigger9 = (var(55) & 32768) && command != "hold_y"
trigger10 = (var(55) & 65536) && command != "hold_s"
var(55) = 0

[State -1]
type = VarSet
trigger1 = !var(55)
var(56) = 0

[State -1]
type = VarSet
trigger1 = command = "qcf_x"
trigger2 = command = "qcf_y"
trigger3 = command = "qcf_a"
trigger4 = command = "qcf_b"
trigger5 = command = "qcf_s"
trigger6 = command = "dp_x"
trigger7 = command = "dp_y"
trigger8 = command = "dp_a"
trigger9 = command = "dp_b"
trigger10= command = "qcf2_x"
trigger11= command = "qcf2_y"
trigger12= command = "qcf2_a"
trigger13= command = "qcf2_b"
trigger14= command = "qcb2_x"
trigger15= command = "qcb2_y"
trigger16= command = "qcb2_a"
trigger17= command = "qcb2_b"
trigger18= command = "qcf2_xy"
trigger19= command = "qcf2_ab"
var(56) = 10
;---------------------------------------
[State -1]
type = VarSet
trigger1 = command = "qcf_x"
var(55) = 3 | 2048 | 16384

[State -1]
type = VarSet
trigger1 = command = "qcf_y"
var(55) = 4 | 2048 | 32768

[State -1]
type = VarSet
trigger1 = command = "qcf_a"
var(55) = 5 | 2048 | 4096

[State -1]
type = VarSet
trigger1 = command = "qcf_b"
var(55) = 6 | 2048 | 8192

[State -1]
type = VarSet
trigger1 = command = "qcf_s"
var(55) = 7 | 2048 | 65536

[State -1]
type = VarSet
trigger1 = command = "dp_x"
var(55) = 1 | 2048 | 512 | 16384

[State -1]
type = VarSet
trigger1 = command = "dp_y"
var(55) = 2 | 2048 | 512 | 32768

[State -1]
type = VarSet
trigger1 = command = "dp_a"
var(55) = 8 | 2048 | 512 | 4096

[State -1]
type = VarSet
trigger1 = command = "dp_b"
var(55) = 9 | 2048 | 512 | 8192

[State -1]
type = VarSet
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = command = "qcf2_x"
var(55) = 10 | 2048 | 16384

[State -1]
type = VarSet
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = command = "qcf2_y"
var(55) = 11 | 2048 | 32768

[State -1]
type = VarSet
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = command = "qcf2_a"
var(55) = 12 | 2048 | 4096

[State -1]
type = VarSet
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=1)
triggerall = command = "qcf2_b"
var(55) = 12 | 2048 | 8192

[State -1]
type = VarSet
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = command = "qcb2_x"
var(55) = 13 | 1024 | 16384

[State -1]
type = VarSet
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = command = "qcb2_y"
var(55) = 14 | 1024 | 32768

[State -1]
type = VarSet
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = command = "qcb2_a"
var(55) = 15 | 1024 | 4096

[State -1]
type = VarSet
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = command = "qcb2_b"
var(55) = 16 | 1024 | 8192

[State -1]
type = VarSet
trigger1 = Power >= 2000 && var(30)=0 && var(47)=0
trigger2 = Power >= 1000 && var(30)=1 && fvar(0) > 0
trigger3 = var(30)=2 && ((!var(49) && (100*life/const(data.life))<=50) || var(44) = 2)
triggerall = command = "qcf2_ab"
var(55) = 17 | 1024 | 4096 | 8192

[State -1]
type = VarSet
trigger1 = Power >= 3000 && var(30)=0 && var(47)=0
trigger2 = Power >= 1000 && var(30)=1 && fvar(0) > 0 && ((100*life/const(data.life))<=25 || var(44) = 2)
triggerall = command = "qcf2_xy"
var(55) = 18 | 1024 | 16384 | 32768

;=====================================================================
; Super Arts
;=====================================================================

;---------------------------------------------------------------------------
; �^�C�K�[�X�g�[���EMAX2
[State -1]
type = ChangeState
value = 3400
triggerall = (var(55) & 255) = 18
trigger1 = Power >= 3000 && var(30)=0 && var(47)=0
trigger2 = Power >= 1000 && var(30)=1 && fvar(0) > 0 && ((100*life/const(data.life))<=25 || var(44) = 2)
triggerall = var(30)!=2
triggerall = StateType != A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------------
; �^�C�K�[�W�F�m�T�C�h�EMAX
[State -1]
type = ChangeState
value = 3250
triggerall = (var(55) & 255) = 17
trigger1 = Power >= 2000 && var(30)=0 && var(47)=0
trigger2 = Power >= 1000 && var(30)=1 && fvar(0) > 0
trigger3 = var(30)=2 && ((!var(49) && (100*life/const(data.life))<=50) || var(44) = 2)
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------------
; �^�C�K�[�W�F�m�T�C�h�E�m�[�}��
[State -1]
type = ChangeState
value = 3200
triggerall = (var(55) & 255) = 12
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=1)
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------------
; �^�C�K�[�L���m����
[State -1]
type = ChangeState
value = 3000
triggerall = (var(55) & 255) = 10
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------------
; �^�C�K�[�L���m����
[State -1]
type = ChangeState
value = 3010
triggerall = (var(55) & 255) = 11
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------------
; �O�����h�^�C�K�[�L���m����
[State -1]
type = ChangeState
value = 3050
triggerall = (var(55) & 255) = 13
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------------
; �O�����h�^�C�K�[�L���m����
[State -1]
type = ChangeState
value = 3060
triggerall = (var(55) & 255) = 14
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------------
; �^�C�K�[���C�h��
[State -1]
type = ChangeState
value = 3100
triggerall = (var(55) & 255) = 15
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------------
; �^�C�K�[���C�h��
[State -1]
type = ChangeState
value = 3110
triggerall = (var(55) & 255) = 16
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;=====================================================================
; Special Arts 
;=====================================================================

;---------------------------------------------------------------------------
; �^�C�K�[�A�b�p�[�J�b�g��
[State -1]
type = ChangeState
value = 1000
triggerall = (var(55) & 255) = 1
triggerall= StateType != A
trigger1 = ctrl || (var(40)=[1,2])
trigger2 = var(40) = 4 && (StateNo != [1000,1009]) && (StateNo != [1030,1039])
removeongethit = (var(40) = 4)

;---------------------------------------------------------------------------
; �^�C�K�[�A�b�p�[�J�b�g��
[State -1]
type = ChangeState
value = 1005
triggerall = (var(55) & 255) = 2
triggerall= StateType != A
trigger1 = ctrl || (var(40)=[1,2])
trigger2 = var(40) = 4 && (StateNo != [1000,1009]) && (StateNo != [1030,1039])
removeongethit = (var(40) = 4)

;---------------------------------------------------------------------------
; �^�C�K�[�N���b�V����
[State -1]
type = ChangeState
value = 1030
triggerall = (var(55) & 255) = 8
triggerall= StateType != A
trigger1 = ctrl || (var(40)=[1,2])
trigger2 = var(40) = 4 && (StateNo != [1000,1009]) && (StateNo != [1030,1039])
removeongethit = (var(40) = 4)

;---------------------------------------------------------------------------
; �^�C�K�[�N���b�V����
[State -1]
type = ChangeState
value = 1035
triggerall = (var(55) & 255) = 9
triggerall= StateType != A
trigger1 = ctrl || (var(40)=[1,2])
trigger2 = var(40) = 4 && (StateNo != [1000,1009]) && (StateNo != [1030,1039])
removeongethit = (var(40) = 4)

;---------------------------------------------------------------------------
; �A���O���[�`���[�W
[State -1]
type = ChangeState
value = 3300
triggerall = (var(55) & 255) = 7
triggerall= StateType != A
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=1)
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------------
; �^�C�K�[�V���b�g��
[State -1]
type = ChangeState
value = 1010
triggerall = (var(55) & 255) = 3
triggerall= StateType != A
trigger1 = ctrl || (var(40)=[1,2])
trigger2 = var(40) = 4 && (StateNo != [1010,1029])
removeongethit = (var(40) = 4)

;---------------------------------------------------------------------------
; �^�C�K�[�V���b�g��
[State -1]
type = ChangeState
value = 1015
triggerall = (var(55) & 255) = 4
triggerall= StateType != A
trigger1 = ctrl || (var(40)=[1,2])
trigger2 = var(40) = 4 && (StateNo != [1010,1029])
removeongethit = (var(40) = 4)

;---------------------------------------------------------------------------
; �O�����h�^�C�K�[�V���b�g��
[State -1]
type = ChangeState
value = 1020
triggerall = (var(55) & 255) = 5
triggerall= StateType != A
trigger1 = ctrl || (var(40)=[1,2])
trigger2 = var(40) = 4 && (StateNo != [1010,1029])
removeongethit = (var(40) = 4)

;---------------------------------------------------------------------------
; �O�����h�^�C�K�[�V���b�g��
[State -1]
type = ChangeState
value = 1025
triggerall = (var(55) & 255) = 6
triggerall= StateType != A
trigger1 = ctrl || (var(40)=[1,2])
trigger2 = var(40) = 4 && (StateNo != [1010,1029])
removeongethit = (var(40) = 4)

;=====================================================================
; Basic Throws
;=====================================================================

;---------------------------------------------------------------------------
; �^�C�K�[���C�W
[State -1]
type = ChangeState
value = 900
triggerall = StateType = S && Ctrl
trigger1 = var(30) = 2 && Command = "xa"
trigger2 = var(30) != 2 && P2MoveType != H && !P2StateType = A
trigger2 = (Command = "fwd_y" && P2BodyDist X < 8) || (Command = "back_y" && P2BodyDist X < 20)

;---------------------------------------------------------------------------
; �^�C�K�[�L�����[
[State -1]
type = ChangeState
value = 910
triggerall = StateType = S && Ctrl
trigger1 = var(30) = 2 && Command = "by"
trigger2 = var(30) != 2 && P2MoveType != H && !P2StateType = A
trigger2 = (Command = "fwd_b" && P2BodyDist X < 8) || (Command = "back_b" && P2BodyDist X < 20)

;---------------------------------------------------------------------
; Special Attacks , Moves and so on.
;---------------------------------------------------------------------

;---------------------------------------------------------------------------
; �p���[MAX���[�h����
[State -1]
type = ChangeState
value = 4200
triggerall = command = "ay"
triggerall = power >= 1000 && var(47) = 0 && var(30) = 1
trigger1 = ctrl && statetype != A
trigger2 = var(40)=1

;------------------------ �N�C�b�NMAX����
[State -1]
type = ChangeState
value = 4210
triggerall = command = "ay"
triggerall = power >= 2000 && var(47) = 0 && var(30) = 1
trigger1 = statetype != A
trigger1 = MoveContact && StateNo = [200,799]

;---------------------------------------------------------------------
; �n��ӂ��Ƃ΂��U��
[State -1]
type = ChangeState
value = 500
triggerall = var(30) != 2
triggerall = Command = "by"
trigger1 = StateType != A && (Ctrl || var(40)=1)

;---------------------------------------------------------------------
; �󒆂ӂ��Ƃ΂��U��
[State -1]
type = ChangeState
value = 510
triggerall = var(30) != 2
triggerall = Command = "by"
trigger1 = StateType = A && Ctrl

;---------------------------------------------------------------------
; �K�[�h�L�����Z���ً}��𓮍�i�O�E��j
[State -1]
type = ChangeState
value = 4050
triggerall = Command = "recovery" && Power >= 1000 && var(30) != 2
triggerall = StateType != A
trigger1 = (StateNo = 150 || StateNo = 152)
trigger2 = MoveContact && Var(30) = 1 && StateNo = [200,799]

;---------------------------------------------------------------------
; �K�[�h�L�����Z���O�����h�t�����g�X�e�b�v
[State -1]
type = ChangeState
value = 4100
triggerall = Var(30) = 2
triggerall = (Command = "ay" || Command = "FF")
triggerall = (Power >= 600 || (var(30) = 2 && fvar(0) > 0)) && StateType != A
trigger1 = (StateNo = 150 || StateNo = 151 || StateNo = 152 || StateNo = 153)

;---------------------------------------------------------------------
; �ً}��𓮍�i�O�j
[State -1]
type = ChangeState
value = 4000
triggerall = Command = "xa" && !Command = "holdback" && var(30) != 2
trigger1 = StateType = S && (Ctrl || var(40)=1)

;---------------------------------------------------------------------
; �ً}��𓮍�i��j
[State -1]
type = ChangeState
value = 4010
triggerall = Command = "q_back" && !Command = "holdfwd" && var(30) != 2
trigger1 = StateType = S && (Ctrl || var(40)=1)

;---------------------------------------------------------------------
; �K�[�h�L�����Z��������΂��U��
[State -1]
type = ChangeState
value = 4500
triggerall = Command = "by"
triggerall = (Power >= 1000 || (var(30) = 2 && fvar(0) > 0)) && StateType != A
trigger1 = (StateNo = 150 || StateNo = 152)

;=====================================================================
; Dir + Button
;=====================================================================

;---------------------------------------------------------------------------
; �^�C�K�[�t�b�N
[State -1]
type = ChangeState
value = 300
triggerall = command = "x" && command = "holdfwd" && command != "holddown"
trigger1 = statetype = S && (Ctrl || var(40)=1)

;---------------------------------------------------------------------------
; �^�C�K�[�e�C��
[State -1]
type = ChangeState
value = 305
triggerall = command = "b" && command = "holdback" && command = "holddown"
trigger1 = statetype = C && (Ctrl || var(40)=1)

;=====================================================================
; Basic Arts
;=====================================================================

;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = ifelse(p2BodyDist X < 20,200,205)
triggerall = command = "x" && command != "holddown"
trigger1 = statetype = S && (Ctrl || var(40)=1)
;---------------------------------------------------------------------------
; ������P
[State -1]
type = ChangeState
value = ifelse(p2BodyDist X < 20,210,215)
triggerall = command = "y" && command != "holddown"
trigger1 = statetype = S && (Ctrl || var(40)=1)
;---------------------------------------------------------------------------
; ������K
[State -1]
type = ChangeState
value = ifelse(p2BodyDist X < 20,220,225)
triggerall = command = "a" && command != "holddown"
trigger1 = statetype = S && (Ctrl || var(40)=1)
;---------------------------------------------------------------------------
; ������K
[State -1]
type = ChangeState
value = ifelse(p2BodyDist X < 20,230,235)
triggerall = command = "b" && command != "holddown"
trigger1 = statetype = S && (Ctrl || var(40)=1)
;---------------------------------------------------------------------------
; ���ݎ�P
[State -1]
type = ChangeState
value = 400
triggerall = command = "x" && command = "holddown"
trigger1 = (statetype = C && Ctrl) || var(40)=1
;---------------------------------------------------------------------------
; ���݋�P
[State -1]
type = ChangeState
value = 410
triggerall = command = "y" && command = "holddown"
trigger1 = (statetype = C && Ctrl) || var(40)=1
;---------------------------------------------------------------------------
; ���ݎ�K
[State -1]
type = ChangeState
value = 420
triggerall = command = "a" && command = "holddown"
trigger1 = (statetype = C && Ctrl) || var(40)=1
;---------------------------------------------------------------------------
; ���݋�K
[State -1]
type = ChangeState
value = 430
triggerall = command = "b" && command = "holddown"
trigger1 = (statetype = C && Ctrl) || var(40)=1
;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = IfElse(var(32) != 2 && Vel X = 0,600,605)
triggerall = command = "x"
trigger1 = statetype = A && ctrl
;---------------------------------------------------------------------------
; �W�����v��P
[State -1]
type = ChangeState
value = 610
triggerall = command = "y"
trigger1 = statetype = A && ctrl
;---------------------------------------------------------------------------
; �W�����v��K
[State -1]
type = ChangeState
value = IfElse(var(32) != 2 && Vel X = 0,620,625)
triggerall = command = "a"
trigger1 = statetype = A && ctrl
;---------------------------------------------------------------------------
; �W�����v��K
[State -1]
type = ChangeState
value = IfElse(var(32) != 2 && Vel X = 0,630,635)
triggerall = command = "b"
trigger1 = statetype = A && ctrl

;=====================================================================
; Taunts
;=====================================================================

;---------------------------------------------------------------------------
; ����
[State -1]
type = ChangeState
value = 195
trigger1 = command = "s"
trigger1 = statetype = S && ctrl

;=====================================================================
; Basic Animation
;=====================================================================

;---------------------------------------------------------------------------
; �_�b�V��
[State -1]
type = ChangeState
value = IfElse(var(30)=2,110,100)
trigger1 = command = "FF"
trigger1 = statetype = S && ctrl
;---------------------------------------------------------------------------
; �o�b�N�X�e�b�v
[State -1]
type = ChangeState
value = 105
trigger1 = command = "BB"
trigger1 = statetype = S && ctrl
