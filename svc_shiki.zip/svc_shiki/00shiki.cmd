;-| CPU |--------------------------------------------------------
[Command]
name = "cpu"
command =D,D,D,D,D,D,D,D
time = 0

[Command]
name = "cpu"
command =F,F,F,F,F,F,F
time = 0

[Command]
name = "cpu"
command =U,U,U,U,U,U,U,U
time = 0

[Command]
name = "cpu"
command = B,B,B,B,B,B,B
time = 0

;-| Super Motions |--------------------------------------------------------
[Command]
name = "��M"
command =~F,DF,D,DB,B,F,DF,D,DB,B,x+y
time = 40

[Command]
name = "��M"
command =~D,B,F,x+y
time = 35

[Command]
name = "�F"
command =~D,DB,B,DB,D,DF,F,a+b
time = 25

[Command]
name = "�F"
command =~D,B,F,a+b
time = 20

[Command]
name = "�V��x"
command =~D,DB,B,DB,D,DF,F,x
time = 25

[Command]
name = "�V��x"
command =~D,B,F,x
time = 20

[Command]
name = "�V��y"
command =~D,DB,B,DB,D,DF,F,y
time = 25

[Command]
name = "�V��y"
command =~D,B,F,y
time = 20

;-| Special Motions |------------------------------------------------------
[Command]
name = "����"
command =~F,DF,D,DB,B,a
time = 17

[Command]
name = "����"
command =~F,DF,D,DB,B,b
time = 17

[Command]
name = "����x"
command =~F,D,DF,x
time = 13

[Command]
name = "����y"
command =~F,D,DF,y
time = 13

[Command]
name = "�t����a"
command =~B,D,DB,a
time = 13

[Command]
name = "�t����b"
command =~B,D,DB,b
time = 13

[Command]
name = "�t����"
command =~B,D,DB
time = 13

[Command]
name = "�g��x"
command =~D,DF,F,x
time = 10

[Command]
name = "�g��y"
command =~D,DF,F,y
time = 10

[Command]
name = "�g��a"
command =~D,DF,F,a
time = 10

[Command]
name = "�g��b"
command =~D,DF,F,b
time = 10

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "����x"
command =~D,D,x
time = 12

[Command]
name = "����y"
command =~D,D,y
time = 12

[Command]
name = "����a"
command =~D,D,a
time = 12

[Command]
name = "����b"
command =~D,D,b
time = 12

[Command]
name = "FF"   ;Required (do not remove)
command = F, F
time = 15

[Command]
name = "BB"   ;Required (do not remove)
command = B, B
time = 15

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "ABC"
command = x+a+y
time = 1

[Command]
name = "AB"
command = x+a
time = 1

[Command]
name = "CD"
command = y+b
time = 1

[Command]
name = "FS"
command = a+y
time = 1

[Command]
name = "recovery";Required (do not remove)
command = a+x
time = 1


;-| Dir + Button |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Command]
name = "holdz"
command = /z
time = 1

[Command]
name = "holda"
command = /a
time = 1

[Command]
name = "holdb"
command = /b
time = 1

[Command]
name = "holdc"
command = /c
time = 1

[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Statedef -1]
;===========================================================================
;��M
[State -1]
type = ChangeState
value = 3300
triggerall = command = "��M"
triggerall = fvar(25) = 1
triggerall = statetype != A && power >= 2000
trigger1 = ctrl

;��M
[State -1]
type = ChangeState
value = 3300
triggerall = command = "��M"
triggerall = fvar(25) = 1
triggerall = statetype != A && power >= 2000
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 13,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0
trigger8 = (stateno = 505) && animelem = 8,>= 0 && animelem = 12,<= 0
trigger9 = (stateno = 510) && animelem = 6,>= 0 && animelem = 7,<= 0

;��M�E�ǂ��L����
[State -1]
type = ChangeState
value = 3300
triggerall = command = "��M"
triggerall = fvar(25) = 1
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1
trigger2 = fvar(10) >= 198 && stateno = 3010

;===========================================================================
;�F��
[State -1]
type = ChangeState
value = 3100
triggerall = command = "�F"

triggerall = statetype != A && life <= 500
triggerall = fvar(26) || (fvar(26) = 0 && var(5) = 0)
trigger1 = ctrl

;�F��
[State -1]
type = ChangeState
value = 3100
triggerall = command = "�F"

triggerall = statetype != A && life <= 500
triggerall = movecontact
triggerall = fvar(26) || (fvar(26) = 0 && var(5) = 0)
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 13,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0
trigger8 = (stateno = 505) && animelem = 8,>= 0 && animelem = 12,<= 0
trigger9 = (stateno = 510) && animelem = 6,>= 0 && animelem = 7,<= 0

;�F��ǂ��L����
[State -1]
type = ChangeState
value = 3100
triggerall = command = "�F"
triggerall = statetype != A && life <= 500
triggerall = fvar(26) || (fvar(26) = 0 && var(5) = 0)
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;===========================================================================
;��E�V���g�{�@
[State -1]
type = ChangeState
value = 3000
triggerall = command = "�V��x"

triggerall = statetype != A && power >= 1000
trigger1 = ctrl

;��E�V���g�{�@
[State -1]
type = ChangeState
value = 3000
triggerall = command = "�V��x"

triggerall = statetype != A && power >= 1000
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 13,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0
trigger8 = (stateno = 505) && animelem = 8,>= 0 && animelem = 12,<= 0
trigger9 = (stateno = 510) && animelem = 6,>= 0 && animelem = 7,<= 0

;��E�V���g�{�ǂ��L����
[State -1]
type = ChangeState
value = 3000
triggerall = command = "�V��x"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;���E�V���g�{�@
[State -1]
type = ChangeState
value = 3005
triggerall = command = "�V��y"

triggerall = statetype != A && power >= 1000
trigger1 = ctrl

;���E�V���g�{�@
[State -1]
type = ChangeState
value = 3005
triggerall = command = "�V��y"

triggerall = statetype != A && power >= 1000
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 13,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0
trigger8 = (stateno = 505) && animelem = 8,>= 0 && animelem = 12,<= 0
trigger9 = (stateno = 510) && animelem = 6,>= 0 && animelem = 7,<= 0

;���E�V���g�{�ǂ��L����
[State -1]
type = ChangeState
value = 3005
triggerall = command = "�V��y"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;===========================================================================
;����
[State -1]
type = ChangeState
value = 1300
triggerall = command = "����"
triggerall = numhelper(1390) = 0
triggerall = statetype != A
;triggerall = p2bodydist X <= 15
trigger1 = ctrl

;����
[State -1]
type = ChangeState
value = 1300
triggerall = command = "����"
triggerall = numhelper(1390) = 0
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;�����ǂ��L����
[State -1]
type = ChangeState
value = 1300
triggerall = command = "����"
triggerall = numhelper(1390) = 0
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;===========================================================================
;��E�V���ց@
[State -1]
type = ChangeState
value = 1100
triggerall = command = "����x"

triggerall = statetype != A
trigger1 = ctrl

;��E�V���ց@
[State -1]
type = ChangeState
value = 1100
triggerall = command = "����x"

triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;��E�V���ցE��
[State -1]
type = ChangeState
value = 1105
triggerall = command = "����x"

triggerall = statetype = A
trigger1 = ctrl
trigger2 = movecontact
trigger2 = (stateno = 610) && animelem = 7,>= 0 && animelem = 9,<= 0
trigger3 = movecontact
trigger3 = (stateno = 640) && animelem = 5,>= 0 && animelem = 7,<= 0

;��E�V���ւǂ��L����
[State -1]
type = ChangeState
value = 1105
triggerall = command = "����x"
triggerall = statetype = A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;��E�V���ւǂ��L����
[State -1]
type = ChangeState
value = 1100
triggerall = command = "����x"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;���E�V���ց@
[State -1]
type = ChangeState
value = 1110
triggerall = command = "����y"

triggerall = statetype != A
trigger1 = ctrl

;���E�V���ց@
[State -1]
type = ChangeState
value = 1110
triggerall = command = "����y"

triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;���E�V���ցE��
[State -1]
type = ChangeState
value = 1115
triggerall = command = "����y"

triggerall = statetype = A
trigger1 = ctrl
trigger2 = movecontact
trigger2 = (stateno = 610) && animelem = 7,>= 0 && animelem = 9,<= 0
trigger3 = movecontact
trigger3 = (stateno = 640) && animelem = 5,>= 0 && animelem = 7,<= 0

;���E�V���ւǂ��L����
[State -1]
type = ChangeState
value = 1115
triggerall = command = "����y"
triggerall = statetype = A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;���E�V���ւǂ��L����
[State -1]
type = ChangeState
value = 1110
triggerall = command = "����y"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;===========================================================================
;���J��
[State -1]
type = ChangeState
value = 1600
triggerall = command = "�t����a"
triggerall = fvar(25) = 1
triggerall = statetype != A
trigger1 = ctrl

;���J��
[State -1]
type = ChangeState
value = 1601
triggerall = command = "�t����b"
triggerall = fvar(25) = 1
triggerall = statetype != A
trigger1 = ctrl

;���J��
[State -1]
type = ChangeState
value = 1600
triggerall = command = "�t����a"
triggerall = fvar(25) = 1
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;���J��
[State -1]
type = ChangeState
value = 1601
triggerall = command = "�t����b"
triggerall = fvar(25) = 1
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;���J��
[State -1]
type = ChangeState
value = 1600
triggerall = command = "�t����a"
triggerall = fvar(25) = 1
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;���J��
[State -1]
type = ChangeState
value = 1601
triggerall = command = "�t����b"
triggerall = fvar(25) = 1
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;===========================================================================
;��E�~�ՁE��
[State -1]
type = ChangeState
value = 1500
triggerall = command = "�g��a"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = movecontact
trigger2 = (stateno = 610) && animelem = 7,>= 0 && animelem = 9,<= 0
trigger3 = movecontact
trigger3 = (stateno = 640) && animelem = 5,>= 0 && animelem = 7,<= 0

;��E�~�ՁE��
[State -1]
type = ChangeState
value = 1500
triggerall = command = "�g��a"
triggerall = statetype = A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;���E�~�ՁE��
[State -1]
type = ChangeState
value = 1505
triggerall = command = "�g��b"
triggerall = statetype = A
trigger1 = ctrl
trigger2 = movecontact
trigger2 = (stateno = 610) && animelem = 7,>= 0 && animelem = 9,<= 0
trigger3 = movecontact
trigger3 = (stateno = 640) && animelem = 5,>= 0 && animelem = 7,<= 0

;���E�~�ՁE��
[State -1]
type = ChangeState
value = 1505
triggerall = command = "�g��b"
triggerall = statetype = A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;===========================================================================
;��E�I�P
[State -1]
type = ChangeState
value = 1000
triggerall = command = "�g��x"
triggerall = statetype != A
trigger1 = ctrl

;��E�I�P
[State -1]
type = ChangeState
value = 1000
triggerall = command = "�g��x"
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;��E�I�P�ǂ��L����
[State -1]
type = ChangeState
value = 1000
triggerall = command = "�g��x"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;���E�I�P
[State -1]
type = ChangeState
value = 1010
triggerall = command = "�g��y"

triggerall = statetype != A
trigger1 = ctrl

;���E�I�P
[State -1]
type = ChangeState
value = 1010
triggerall = command = "�g��y"

triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;���E�I�P�ǂ��L����
[State -1]
type = ChangeState
value = 1010
triggerall = command = "�g��y"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;===========================================================================
;��E����
[State -1]
type = ChangeState
value = 1400
triggerall = command = "�g��a"

triggerall = statetype != A
trigger1 = ctrl

;��E����
[State -1]
type = ChangeState
value = 1400
triggerall = command = "�g��a"

triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;��E���؂ǂ��L����
[State -1]
type = ChangeState
value = 1400
triggerall = command = "�g��a"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;���E����
[State -1]
type = ChangeState
value = 1410
triggerall = command = "�g��b"

triggerall = statetype != A
trigger1 = ctrl

;���E����
[State -1]
type = ChangeState
value = 1410
triggerall = command = "�g��b"

triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;���E���؂ǂ��L����
[State -1]
type = ChangeState
value = 1410
triggerall = command = "�g��b"
triggerall = statetype != A && var(10) = 1
triggerall = movecontact
trigger1 = var(11) = 1

;---------------------------------------------------------------------------
;�o�b�N�_�b�V��
[State -1,B_Dash]
type = ChangeState
value = 105
triggerall = command = "ABC" || command = "c"
triggerall = statetype != A && fvar(25) = 1
triggerall = command = "holdback"
trigger1 = ctrl
trigger2 = stateno = 52

;�O�������ړ�
[State -1]
type = ChangeState
value = 300
triggerall = command = "ABC"||command="c"
triggerall = statetype != A && fvar(25) = 1
trigger1 = ctrl
trigger2 = stateno = 100
trigger3 = stateno = 52

;---------------------------------------------------------------------------
;AB����
[State -1]
type = ChangeState
value = 800
triggerall = command = "AB"
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
trigger1 = (p2statetype = S) || (p2statetype = C)
trigger1 = p2movetype != H
trigger2 = (p2statetype = S) || (p2statetype = C)
trigger2 = p2movetype != H
trigger2 = command = "holdfwd" || command = "holdback"
;---------------------------------------------------------------------------
;CD����2
[State -1]
type = ChangeState
value = 900
triggerall = command = "CD"
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
trigger1 = (p2statetype = S) || (p2statetype = C)
trigger1 = p2movetype != H
trigger2 = (p2statetype = S) || (p2statetype = C)
trigger2 = p2movetype != H
trigger2 = command = "holdfwd" || command = "holdback"

;========================================================================
;�A�ˎa��E�։�
[State -1]
type = ChangeState
value = 500
triggerall = command = "x" && command = "holdfwd"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl

;�A�ˎa��E�։�
[State -1]
type = ChangeState
value = 500
triggerall = command = "x" && command = "holdfwd"
triggerall = command != "holddown"
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0

;========================================================================
;�A�ˎa��E�]��
[State -1]
type = ChangeState
value = 550
triggerall = command = "a" && command = "holdfwd"
triggerall = command != "holddown"
triggerall = statetype != A
trigger1 = ctrl

;�A�ˎa��E�]��
[State -1]
type = ChangeState
value = 550
triggerall = command = "a" && command = "holdfwd"
triggerall = command != "holddown"
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0

;===========================================================================
;���߁Ex
[State -1]
type = ChangeState
value = 1200
triggerall = command = "����x"

triggerall = statetype != A
trigger1 = ctrl

;���߁Ex
[State -1]
type = ChangeState
value = 1200
triggerall = command = "����x"

triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;���߁Ea
[State -1]
type = ChangeState
value = 1210
triggerall = command = "����a"
triggerall = statetype != A
trigger1 = ctrl

;���߁Ea
[State -1]
type = ChangeState
value = 1210
triggerall = command = "����a"
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;���߁Ey
[State -1]
type = ChangeState
value = 1220
triggerall = command = "����y"
triggerall = statetype != A
trigger1 = ctrl

;���߁Ey
[State -1]
type = ChangeState
value = 1220
triggerall = command = "����y"
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;���߁Eb
[State -1]
type = ChangeState
value = 1230
triggerall = command = "����b"
triggerall = statetype != A
trigger1 = ctrl

;���߁Eb
[State -1]
type = ChangeState
value = 1230
triggerall = command = "����b"
triggerall = statetype != A
triggerall = movecontact
trigger1 = (stateno = [200,205]) && animelem = 6,>= 0 && animelem = 8,<= 0
trigger2 = (stateno = 215) && animelem = 9,>= 0 && animelem = 11,<= 0
trigger3 = (stateno = 235) && animelem = 5,>= 0 && animelem = 6,<= 0
trigger4 = (stateno = 400) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger5 = (stateno = 430) && animelem = 6,>= 0 && animelem = 7,<= 0
trigger6 = (stateno = 440) && animelem = 4,>= 0 && animelem = 6,<= 0
trigger7 = (stateno = 500) && animelem = 4,>= 0 && animelem = 5,<= 0

;---------------------------------------------------------------------------
;GCFS
[State -1,FS]
type = ChangeState
value = 260
triggerall = Power>=1000
triggerall = stateno=150 || stateno=152
triggerall = Statetype!=A
trigger1 = command = "FS"
trigger2 = command = "c"

;GCFS
[State -1,FS]
type = ChangeState
value = 260
triggerall = Power>=1000
triggerall = stateno=150 || stateno=152
triggerall = Statetype != A
trigger1 = command = "FF"

;�_�b�V��
[State -1,Dash]
type = ChangeState
value = 100
triggerall = Statetype != A && ctrl
trigger1 = command = "FF"

;�o�b�N�_�b�V��
[State -1,B_Dash]
type = ChangeState
value = 105
triggerall = Statetype != A && ctrl
trigger1 = command = "BB"
trigger1 = command != "�t����"

;GC�U��
[State -1,GC_Attack]
type = ChangeState
value = 250
triggerall = Power>=1000
triggerall = stateno=150 || stateno=152
triggerall = Statetype != A
trigger1 = command = "CD" || command = "z"


;===========================================================================
;����
[State -1]
type = ChangeState
value = 195
triggerall = command = "start"
triggerall = statetype != A && var(1) = 0
trigger1 = ctrl
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;������p���`
[State -1]
type = ChangeState
value = ifelse(p2bodydist X<=15,205,200)
triggerall = command = "x"
triggerall = command != "holddown" && var(1) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52
trigger3 = stateno = 205 && movecontact
trigger4 = stateno = 400 && movecontact

;�������p���`
[State -1]
type = ChangeState
value = ifelse(p2bodydist X<=38,215,210)
triggerall = command = "y"
triggerall = command != "holddown" && var(1) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52

;������L�b�N
[State -1]
type = ChangeState
value = ifelse(p2bodydist X<=10,235,230)
triggerall = command = "a"
triggerall = command != "holddown" && var(1) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52
trigger3 = stateno = 235 && movecontact

;�������L�b�N
[State -1]
type = ChangeState
value = ifelse(p2bodydist X<=32,245,240)
triggerall = command = "b"
triggerall = command != "holddown" && var(1) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = command = "x"
triggerall = command = "holddown" && var(1) = 0
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 52
trigger3 = stateno = 205 && movecontact
trigger4 = stateno = 400 && movecontact

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 410
triggerall = command = "y"
triggerall = command = "holddown" && var(1) = 0
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = command = "a"
triggerall = command = "holddown" && var(1) = 0
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = command = "b"
triggerall = command = "holddown" && var(1) = 0
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 52

;---------------------------------------------------------------------------
;�󒆎�p���`
[State -1]
type = ChangeState
value = 600
triggerall = command = "x" && var(1) = 0
trigger1 = statetype = A
trigger1 = ctrl
;---------------------------------------------------------------------------
;�󒆋��p���`
[State -1]
type = ChangeState
value = 610
triggerall = command = "y" && var(1) = 0
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆎�L�b�N
[State -1]
type = ChangeState
value = 630
triggerall = command = "a" && var(1) = 0
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆋��L�b�N
[State -1]
type = ChangeState
value = 640

triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl


