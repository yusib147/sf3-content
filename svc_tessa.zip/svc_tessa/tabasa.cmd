;-| Super Motions |--------------------------------------------------------

[Command]
name = "mf"
command = ~D, DB, B, D, DB, B, x
time = 40

[Command]
name = "mf"
command = ~D, DB, B, D, DB, B, y
time = 40

[Command]
name = "df"
command = ~D, DF, F, D, DF, F, a
time = 40

[Command]
name = "df"
command = ~D, DF, F, D, DF, F, b
time = 40

[Command]
name = "te"
command = ~D, DF, F, D, DF, F, x
time = 35

[Command]
name = "te"
command = ~D, DF, F, D, DF, F, y
time = 35

;-| Special Motions |------------------------------------------------------
[Command]
name = "as"
command = ~F, DF, D, DB, x

[Command]
name = "as"
command = ~F, DF, D, DB, y

[Command]
name = "lev_x"
command = ~F, D, DF, x

[Command]
name = "lev_y"
command = ~F, D, DF, y

[Command]
name = "jam"
command = ~F, D, DF, a

[Command]
name = "jam"
command = ~F, D, DF, b

[Command]
name = "wave_x"
command = ~D, DF, F, x

[Command]
name = "wave_y"
command = ~D, DF, F, y

[Command]
name = "wf"
command = ~D, DF, F, a

[Command]
name = "wf"
command = ~D, DF, F, b

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

[Command]
name = "daij"
command = ~$D, $U
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x+y
time = 1

[Command]
name = "x+a"
command = x+a
time = 1

[Command]
name = "y+b"
command = y+b
time = 1
;-| Dir + Button |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holdx"
command = /$x
time = 1

[Command]
name = "holdy"
command = /$y
time = 1

[Command]
name = "holdb"
command = /$b
time = 1
;---------------------------------------------------------------------------

[Statedef -1]

;===========================================================================
;---------------------------------------------------------------------------

;===========================================================================
;���e�I�t�H�[��
[State -1, Kung Fu Throw]
type = ChangeState
value = 3500
triggerall = life < 500
triggerall = var(51) = 0
triggerall = statetype = S
triggerall = command = "mf"
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]
;---------------------------------------------------------------------------
;�f�X�t�F���m
[State -1, Kung Fu Throw]
type = ChangeState
value = 3200
triggerall = power >= 1000
triggerall = statetype = S
triggerall = ctrl || (StateNo = [100,101])
triggerall = numhelper(3300) = 0
trigger1 = command = "df"
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]
;---------------------------------------------------------------------------
;�g���C�V�N���G�b�W
[State -1, Kung Fu Throw]
type = ChangeState
value = 3000
triggerall = power >= 1000
triggerall = statetype = S
triggerall = command = "te"
triggerall = NumProjID(1500) = 0
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]
;---------------------------------------------------------------------------
;�A�X�Z���h�u���[�t
[State -1, Kung Fu Throw]
type = ChangeState
value = 1600
triggerall = statetype != A
triggerall = command = "as"
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]
;---------------------------------------------------------------------------
;�����F���[�\�[�h
[State -1, lv]
type = ChangeState
value = 1200
triggerall = command = "lev_x"
trigger1 = statetype != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]

[State -1, lv]
type = ChangeState
value = 1200
triggerall = command = "lev_x"
triggerall = var(50) != 0
triggerall = statetype != A
trigger1 =  movecontact=0 && ((stateno=[300,340])|| StateNo=400)
trigger2 =  ((stateno=[200,240])|| (StateNo=[410,440]))
trigger3 = (stateno = 750) && movecontact && time = [12,15]
;trigger3 = (stateno = 1200) && movecontact && time = [7,12]
;trigger3 = (stateno = 1210) && movecontact && time = [7,14]
trigger4 = (stateno = 1800) && movecontact && time = [17,20]

;�����F���[�\�[�h
[State -1, lv]
type = ChangeState
value = 1210
triggerall = command = "lev_y"
trigger1 = statetype != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]

[State -1, lv]
type = ChangeState
value = 1210
triggerall = command = "lev_y"
triggerall = var(50) != 0
triggerall = statetype != A
trigger1 =  movecontact=0 && ((stateno=[300,340])|| StateNo=400)
trigger2 =  ((stateno=[200,240])|| (StateNo=[410,440]))
trigger3 = (stateno = 750) && movecontact && time = [12,15]
;trigger3 = (stateno = 1200) && movecontact && time = [7,12]
;trigger3 = (stateno = 1210) && movecontact && time = [7,14]
trigger4 = (stateno = 1800) && movecontact && time = [17,20]
;---------------------------------------------------------------------------
;�W���~���O�S�[�X�g
[State -1, lv]
type = ChangeState
value = 1400
triggerall = NumHelper(1530) = 0
triggerall = NumProjID(1500) = 0
triggerall = command = "jam"
trigger1 = statetype != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]
;---------------------------------------------------------------------------
;�`���N���E�F�[�u
[State -1, wave]
type = ChangeState
value = 1000
triggerall = (command = "wave_x") || (command = "wave_y")
triggerall = NumProjID(1000) = 0
triggerall = NumProjID(1500) = 0
trigger1 = statetype != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]

;---------------------------------------------------------------------------
;�`���N���E�F�[�u
[State -1, wave]
type = ChangeState
value = 1100
triggerall = (command = "wave_x") || (command = "wave_y")
triggerall = NumProjID(1000) = 0
trigger1 = statetype = A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]
;---------------------------------------------------------------------------
;���C���_�[�t�B�X�g
[State -1, wf]
type = ChangeState
value = 1800
triggerall = command = "wf"
trigger1 = statetype != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]

[State -1, wf]
type = ChangeState
value = 1800
triggerall = command = "wf"
triggerall = var(50) != 0
triggerall = statetype != A
trigger1 =  movecontact=0 && ((stateno=[300,340])|| StateNo=400)
trigger2 =  ((stateno=[200,240])|| (StateNo=[410,440]))
trigger3 = (stateno = 750) && movecontact && time = [12,15]
trigger4 = (stateno = 1200) && movecontact && time = [7,12]
trigger5 = (stateno = 1210) && movecontact && time = [7,14]
;trigger4 = (stateno = 1800) && movecontact && time = [17,20]
;===========================================================================
;�����t���X�R
[State -1, Stand Light Punch]
type = ChangeState
value = 700
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = command = "holdfwd"
triggerall = NumProjID(1500) = 0
trigger1 = statetype = S
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]

[State -1, Stand Light Punch]
type = ChangeState
value = 700
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = command = "holdfwd"
triggerall = var(50) != 0
triggerall = statetype != A
triggerall = NumProjID(1500) = 0
trigger1 =  movecontact=0 && ((stateno=[300,340])|| StateNo=400)
trigger2 =  ((stateno=[200,240])|| (StateNo=[410,440]))
trigger3 = (stateno = 750) && movecontact && time = [12,15]
trigger4 = (stateno = 1200) && movecontact && time = [7,12]
trigger5 = (stateno = 1210) && movecontact && time = [7,14]
trigger6 = (stateno = 1800) && movecontact && time = [17,20]
;---------------------------------------------------------------------------
;�_�b�V��
[State -1, Run Fwd]
type = ChangeState
value = 100
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;�K�[�h�L�����Z���e�c
[State -1, g]
type = ChangeState
value = 101
triggerall = stateno = [150,153];�K�[�L����
triggerall = power >= 200
triggerall = statetype != A
trigger1 = command = "FF"
;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 104
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;����
[State -1, Kung Fu Throw]
type = ChangeState
value = 800
triggerall = statetype = S
triggerall = ctrl || (StateNo = [100,101])
triggerall = stateno != 100
;triggerall = p2bodydist X < 3
;triggerall = (p2statetype = S) || (p2statetype = C)
triggerall = p2movetype != H
trigger1 = command = "x+a"
trigger2 = command = "y+b"


;===========================================================================
;---------------------------------------------------------------------------
;�K�[�h�L�����Z��
[State -1, g]
type = ChangeState
value = 780
triggerall = stateno = [150,153];�K�[�L����
triggerall = power >= 1000
triggerall = statetype != A
trigger1 = command = "y+b"
;---------------------------------------------------------------------------
;������p���`��
[State -1, Stand Light Punch]
type = ChangeState
value = 300
triggerall = p2bodydist X < 15
triggerall = command = "x"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl || (StateNo = [100,101])

;---------------------------------------------------------------------------
;�������p���`��
[State -1, Stand Strong Punch]
type = ChangeState
value = 310
triggerall = p2bodydist X < 15
triggerall = command = "y"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl || (StateNo = [100,101])

;---------------------------------------------------------------------------
;������L�b�N��
[State -1, Stand Light Kick]
type = ChangeState
value = 330
triggerall = p2bodydist X < 15
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl || (StateNo = [100,101])

;---------------------------------------------------------------------------
;�������L�b�N��
[State -1, Standing Strong Kick]
type = ChangeState
value = 340
triggerall = p2bodydist X < 15
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl || (StateNo = [100,101])
;---------------------------------------------------------------------------
;������p���`
[State -1, Stand Light Punch]
type = ChangeState
value = 200
triggerall = command = "x"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl || (StateNo = [100,101])

;---------------------------------------------------------------------------
;�������p���`
[State -1, Stand Strong Punch]
type = ChangeState
value = 210
triggerall = command = "y"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl || (StateNo = [100,101])

;---------------------------------------------------------------------------
;������L�b�N
[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl || (StateNo = [100,101])

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Standing Strong Kick]
type = ChangeState
value = 240
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl || (StateNo = [100,101])

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = command = "start"
trigger1 = statetype != A
trigger1 = ctrl || (StateNo = [100,101])

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerall = command = "x"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl

;---------------------------------------------------------------------------
;���Ⴊ�݃t���X�R
[State -1, Stand Light Punch]
type = ChangeState
value = 720
triggerall = command = "y"
triggerall = command = "holdfwd"
triggerall = command = "holddown"
triggerall = statetype != A
triggerall = NumProjID(1500) = 0
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]
trigger7 = (stateno = 740) && movecontact && time = [10,15]

[State -1, Stand Light Punch]
type = ChangeState
value = 720
triggerall = command = "y"
triggerall = command = "holdfwd"
triggerall = command = "holddown"
triggerall = var(50) != 0
triggerall = statetype != A
triggerall = NumProjID(1500) = 0
trigger1 =  movecontact=0 && ((stateno=[300,340])|| StateNo=400)
trigger2 =  ((stateno=[200,240])|| (StateNo=[410,440]))
trigger3 = (stateno = 750) && movecontact && time = [12,15]
trigger4 = (stateno = 1200) && movecontact && time = [7,12]
trigger5 = (stateno = 1210) && movecontact && time = [7,14]
trigger6 = (stateno = 1800) && movecontact && time = [17,20]

;���Ⴊ�݋��p���`
[State -1, Crouching Strong Punch]
type = ChangeState
value = 410
triggerall = command = "y"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl

;---------------------------------------------------------------------------
;���Ⴊ�ݔL��
[State -1, Stand Light Punch]
type = ChangeState
value = 740
triggerall = command = "a"
triggerall = command = "holdfwd"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]

[State -1, Stand Light Punch]
type = ChangeState
value = 740
triggerall = command = "a"
triggerall = command = "holdfwd"
triggerall = command = "holddown"
triggerall = var(50) != 0
triggerall = statetype != A
trigger1 =  movecontact=0 && ((stateno=[300,340])|| StateNo=400)
trigger2 =  ((stateno=[200,240])|| (StateNo=[410,440]))
;trigger3 = (stateno = 750) && movecontact && time = [12,15]
trigger3 = (stateno = 1200) && movecontact && time = [7,12]
trigger4 = (stateno = 1210) && movecontact && time = [7,14]
trigger5 = (stateno = 1800) && movecontact && time = [17,18]

;���Ⴊ�ݎ�L�b�N
[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerall = command = "a"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl

;---------------------------------------------------------------------------
;���Ⴊ�ݔL��
[State -1, Stand Light Punch]
type = ChangeState
value = 750
triggerall = command = "b"
triggerall = command = "holdfwd"
triggerall = command = "holddown"
triggerall = statetype != A
trigger1 = ctrl || (StateNo = [100,101])
trigger2 = (stateno = 300) && movecontact && time = [4,10]
trigger3 = (stateno = 310) && movecontact && time = [10,14]
trigger4 = (stateno = 330) && movecontact && time = [4,6]
trigger5 = (stateno = 340) && movecontact && time = [5,8]
trigger6 = (stateno = 400) && movecontact && time = [5,7]

[State -1, Stand Light Punch]
type = ChangeState
value = 750
triggerall = command = "b"
triggerall = command = "holdfwd"
triggerall = command = "holddown"
triggerall = var(50) != 0
triggerall = statetype != A
trigger1 =  movecontact=0 && ((stateno=[300,340])|| StateNo=400)
trigger2 =  ((stateno=[200,240])|| (StateNo=[410,440]))
;trigger3 = (stateno = 750) && movecontact && time = [12,15]
trigger3 = (stateno = 1200) && movecontact && time = [7,12]
trigger4 = (stateno = 1210) && movecontact && time = [7,14]
trigger5 = (stateno = 1800) && movecontact && time = [17,18]

;���Ⴊ�݋��L�b�N
[State -1, Crouching Strong Kick]
type = ChangeState
value = 440
triggerall = command = "b"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆎�p���`
[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆋��p���`
[State -1, Jump Strong Punch]
type = ChangeState
value = 610
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl
trigger2 = stateno = 105

;---------------------------------------------------------------------------
;�󒆎�L�b�N����
[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerall = command = "a"
trigger1= Vel X = 0
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆎�L�b�N��
[State -1, Jump Light Kick]
type = ChangeState
value = 631
triggerall = command = "a"
trigger1 = statetype = A
trigger1 = ctrl
;---------------------------------------------------------------------------
;��������[
[State -1, Jump Strong Kick]
type = ChangeState
value = 760
triggerall = NumHelper(770) = 0
triggerall = command = "b"
triggerall = command = "holddown"
trigger1 = statetype = A
trigger1 = ctrl

;�󒆋��L�b�N
[State -1, Jump Strong Kick]
type = ChangeState
value = 640
triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl


