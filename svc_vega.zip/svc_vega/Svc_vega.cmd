;=====================================================================
;  CMD File For "Vega"	                      		     Made By H"
;                                       Ver. 0.95  
;=====================================================================

;=====================================================================
; Definition of the Commands
;=====================================================================
;-| Super Motions |---------------------------------------------------
[Command]
name = "Final Psycho Crusher"
command = ~D, F, D, F, x+y
Time = 35

[Command]
name = "Mega Psycho Crusher"
command = ~D, F, D, F, x
Time = 35

[Command]
name = "Mega Psycho Crusher"
command = ~D, F, D, F, y
Time = 35

[Command]
name = "Knee Press Nightmare(MAX)"
command = ~D, F, D, F, a+b
Time = 35

[Command]
name = "Knee Press Nightmare"
command = ~D, F, D, F, a
Time = 35

[Command]
name = "Knee Press Nightmare"
command = ~D, F, D, F, b
Time = 35

;-| Special Motions |-------------------------------------------------

[Command]
name = "Head Press"
command = ~D,U, a
time = 20

[Command]
name = "Head Press"
command = ~D,U, b
time = 20

[Command]
name = "Devil Reverse"
command = ~D,U, x
time = 20

[Command]
name = "Devil Reverse"
command = ~D,U, y
time = 20

[Command]
name = "Psycho Crusher_x"
command = ~B,F, x
time = 20

[Command]
name = "Psycho Crusher_y"
command = ~B,F, y
time = 20

[Command]
name = "Double Knee Press_a"
command = ~B,F, a
time = 20

[Command]
name = "Double Knee Press_b"
command = ~B,F, b
time = 20

[Command]
name = "Vega Warp_1"
command = ~F, D, DF, x+y

[Command]
name = "Vega Warp_2"
command = ~B, D, DB, x+y

[Command]
name = "Vega Warp_3"
command = ~F, D, DF, a+b

[Command]
name = "Vega Warp_4"
command = ~B, D, DB, a+b

;-| Double Tap |------------------------------------------------------
[Command]
name = "FF";Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB";Required (do not remove)
command = B, B
time = 10

;-| 2/3 Button Combination |------------------------------------------
[Command]
name = "Power-Max"
command = a+y
time = 1

[Command]
name = "recovery";Required (do not remove)
command = a+x
time = 1

[Command]
name = "by"
command = b+y
time = 1

;-| Dir + Button |----------------------------------------------------
[Command]
name = "fwd_b"
command = /F,b
time = 1

[Command]
name = "fwd_y"
command = /F,y
time = 1

[Command]
name = "back_b"
command = /B,b
time = 1

[Command]
name = "back_y"
command = /B,y
time = 1

[Command]
name = "q_back"
command = /B, a+x
time = 1

[Command]
name = "q_back"
command = /B, z
time = 1

;-| Single Button |---------------------------------------------------
[Command]
name = "x"
command = x
time = 1

[Command]
name = "a"
command = a
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1

[Command]
name = "random"
command = x
time = 1

[Command]
name = "random"
command = a
time = 1

[Command]
name = "random"
command = y
time = 1

[Command]
name = "random"
command = b
time = 1

[Command]
name = "random"
command = c
time = 1

[Command]
name = "random"
command = z
time = 1

[Command]
name = "random"
command = s
time = 1

;-| Hold Button |-----------------------------------------------------
[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_s"
command = /s
time = 1

;-| Hold Dir |--------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup";Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holdupfwd"
command = /UF
time = 1

[Command]
name = "holdupback"
command = /UB
time = 1

;=====================================================================
; State Entry for Commands
;=====================================================================

[Statedef -1]

;=====================================================================
; �L�����Z���ݒ�
;=====================================================================
;------------------------ �L�����Z���ݒ胊�Z�b�g
[State -1]
type = varset
trigger1 = var(40)
var(40) = 0
;------------------------ �_�b�V���L�����Z��
[State -1]
type = varset
triggerall = RoundState = 2
trigger1 = !var(40)
trigger1 = StateNo = 100 || StateNo = 110 || (StateNo = 4100 && AnimElem = 3,> 0)
var(40) = 1
;------------------------ ����Z�L�����Z��
[State -1]
type = varset
triggerall = RoundState = 2
triggerall = !var(40)
triggerall = MoveContact
trigger1  = 0
var(40) = 2
ignorehitpause = 1
;------------------------ �K�E�Z�E���K�E�Z�L�����Z��
[State -1]
type = varset
triggerall = RoundState = 2
triggerall = !var(40)
triggerall  = MoveContact
trigger1 = (StateNo = [200,205]) || StateNo = 215 || StateNo = 235 || StateNo = 245
trigger2 = StateNo = 400 || StateNo = 410 || StateNo = 430
var(40) = 3
ignorehitpause = 1
;------------------------ �ǂ��ł��L�����Z��
[State -1]
type = varset
triggerall = var(30)
triggerall = RoundState = 2
triggerall = !var(40)
triggerall = var(47) && fvar(0) > 0
trigger1 = !MoveContact && ((StateNo = [200,205]) || StateNo = 215 || StateNo = 235 || StateNo = 245)
trigger2 = !MoveContact && (StateNo = 400 || StateNo = 410 || StateNo = 430)
trigger3 = StateNo = 210 || StateNo = 230 || StateNo = 240 || StateNo = 440
trigger4  = MoveHit && StateNo = [1000,1999]
var(40) = 4
ignorehitpause = 1
;------------------------ �X�[�p�[�L�����Z��
[State -1]
type = varset
triggerall = RoundState = 2
triggerall = !var(40)
triggerall = MoveContact
triggerall = Power >= 2000 || Power >= 1000 && Fvar(3) > 0
trigger1  = 0
var(40) = -1
ignorehitpause = 1

;=====================================================================
; CPU Function
;=====================================================================
;
;=====================================================================
; Super Arts
;=====================================================================

;---------------------------------------------------------------------
; �t�@�C�i���T�C�R�N���b�V���[�iMAX2�j
[State -1]
type = ChangeState
value = 3500
triggerall= Command = "Final Psycho Crusher"
trigger1 = Power >= 3000 && var(30)=0 && var(47)=0
trigger2 = Power >= 1000 && var(30)=1 && fvar(0) > 0 && ((100*life/const(data.life))<=25 || var(44) = 2)
trigger3 = var(30)=2 && ((!var(49) && (100*life/const(data.life))<=50) || var(44) = 2)
triggerall = StateType != A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------
; ���K�T�C�R�N���b�V���[�i�m�[�}���Łj
[State -1]
type = ChangeState
value = 3100
triggerall = Command = "Mega Psycho Crusher"
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------
; �j�[�v���X�i�C�g���A�iMAX�j
[State -1]
type = ChangeState
value = 3010
triggerall = Command = "Knee Press Nightmare(MAX)"
trigger1 = Power >= 2000 && var(30)=0 && var(47)=0
trigger2 = Power >= 1000 && var(30)=1 && fvar(0) > 0
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;---------------------------------------------------------------------
; �j�[�v���X�i�C�g���A�i�m�[�}���Łj
[State -1]
type = ChangeState
value = 3000
triggerall = Command = "Knee Press Nightmare"
trigger1 = Power >= 1000 && var(30)=0 && var(47)=0
trigger2 = (Power >= 1000 || fvar(0) > 0) && (var(30)=[1,2])
triggerall = !StateType = A && (Ctrl || (var(40)=[1,3]))

;=====================================================================
; Special Arts 
;=====================================================================

;---------------------------------------------------------------------
; �w�b�h�v���X
[State -1]
type = ChangeState
value = 1200
triggerall = Command = "Head Press"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3]) || StateNo = 40
trigger2 = var(40) = 4 && (StateNo != [1200,1299])
ignorehitpause = (var(40) = 4)

;------------------------ ��s���͗p
[State -1]
type = VarSet
fvar(3) = 1
triggerall = fvar(3)=0 && (Command = "x" || Command = "y")
trigger1 = stateno = 1202

[State -1]
type = VarSet
fvar(3) = 0
triggerall = fvar(3)=1
trigger1 = stateno != [1200,1299]

;------------------------ �T�}�[�\���g�X�J���_�C�o�[
[State -1]
type = ChangeState
value = 1210
triggerall = fvar(3) = 1 
triggerall = StateType = A 
trigger1 = StateNo = 1202 && AnimElem = 11,> 0

;---------------------------------------------------------------------
; �f�r�����o�[�X
[State -1]
type = ChangeState
value = 1250
triggerall = Command = "Devil Reverse"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3]) || StateNo = 40
trigger2 = var(40) = 4 && (StateNo != [1200,1299])
ignorehitpause = (var(40) = 4)

;------------------------ �f�r�����o�[�X
[State -1]
type = ChangeState
value = 1252
triggerall = Command = "x" || Command = "y"
triggerall = StateType = A
trigger1 = StateNo = 1251 && AnimElem = 2,> 0

;---------------------------------------------------------------------
; �T�C�R�N���b�V���[�E��
[State -1]
type = ChangeState
value = 1000
triggerall = Command = "Psycho Crusher_x"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3])
trigger2 = var(40) = 4 && (StateNo != [1000,1099])
ignorehitpause = (var(40) = 4)

;---------------------------------------------------------------------
; �T�C�R�N���b�V���[�E��
[State -1]
type = ChangeState
value = 1010
triggerall = Command = "Psycho Crusher_y"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3])
trigger2 = var(40) = 4 && (StateNo != [1000,1099])
ignorehitpause = (var(40) = 4)

;---------------------------------------------------------------------
; �_�u���j�[�v���X�E��
[State -1]
type = ChangeState
value = 1100
triggerall = Command = "Double Knee Press_a"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3])
trigger2 = var(40) = 4 && (StateNo != [1100,1199])
ignorehitpause = (var(40) = 4)

;---------------------------------------------------------------------
; �_�u���j�[�v���X�E��
[State -1]
type = ChangeState
value = 1110
triggerall = Command = "Double Knee Press_b"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3])
trigger2 = var(40) = 4 && (StateNo != [1100,1199])
ignorehitpause = (var(40) = 4)

;---------------------------------------------------------------------
; �x�K���[�v�P
[State -1]
type = ChangeState
value = 1300
triggerall = Command = "Vega Warp_1"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3])
trigger2 = var(40) = 4 && (StateNo != [1300,1399])
ignorehitpause = (var(40) = 4)

;---------------------------------------------------------------------
; �x�K���[�v�Q
[State -1]
type = ChangeState
value = 1310
triggerall = Command = "Vega Warp_2"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3])
trigger2 = var(40) = 4 && (StateNo != [1300,1399])
ignorehitpause = (var(40) = 4)

;---------------------------------------------------------------------
; �x�K���[�v�R
[State -1]
type = ChangeState
value = 1320
triggerall = Command = "Vega Warp_3"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3])
trigger2 = var(40) = 4 && (StateNo != [1300,1399])
ignorehitpause = (var(40) = 4)

;---------------------------------------------------------------------
; �x�K���[�v�S
[State -1]
type = ChangeState
value = 1330
triggerall = Command = "Vega Warp_4"
triggerall = StateType != A
trigger1 = Ctrl || (var(40)=[1,3])
trigger2 = var(40) = 4 && (StateNo != [1300,1399])
ignorehitpause = (var(40) = 4)

;=====================================================================
; Basic Animation
;=====================================================================

;---------------------------------------------------------------------------
; �_�b�V��
[State -1]
type = ChangeState
value = IfElse(var(30)=2,110,100)
trigger1 = command = "FF"
trigger1 = statetype = S && ctrl

;---------------------------------------------------------------------
;RunBack
[State -1]
type = ChangeState
value = 105
trigger1 = Command = "BB" && StateType = S && Ctrl

;=====================================================================
; 2/3 Buttons
;=====================================================================
;
;=====================================================================
; Basic Throws
;=====================================================================

;---------------------------------------------------------------------
; �f�b�h���[�X���[�i�o�ʏ퓊���j
[State -1]
type = ChangeState
value = 800
triggerall = StateType = S && Ctrl
trigger1 = var(30) = 2 && Command = "recovery"
trigger2 = var(30) != 2 && P2MoveType != H && !P2StateType = A
trigger2 = (Command = "fwd_y" && P2BodyDist X < 8) || (Command = "back_y" && P2BodyDist X < 20)

;---------------------------------------------------------------------
; �f�X�^���[�i�j�ʏ퓊���j
[State -1]
type = ChangeState
value = 850
triggerall = StateType = S && Ctrl
trigger1 = var(30) = 2 && Command = "by"
trigger2 = var(30) != 2 && P2MoveType != H && !P2StateType = A
trigger2 = (Command = "fwd_b" && P2BodyDist X < 8) || (Command = "back_b" && P2BodyDist X < 20)

;---------------------------------------------------------------------
; Special Attacks , Moves and so on.
;---------------------------------------------------------------------

;---------------------------------------------------------------------------
; �p���[MAX���[�h����
[State -1]
type = ChangeState
value = 4200
triggerall = command = "Power-Max"
triggerall = power >= 1000 && var(47) = 0 && var(30) = 1
trigger1 = ctrl && statetype != A
trigger2 = var(40)=1

;------------------------ �N�C�b�NMAX����
[State -1]
type = ChangeState
value = 4210
triggerall = command = "Power-Max"
triggerall = power >= 2000 && var(47) = 0 && var(30) = 1
trigger1 = statetype != A
trigger1 = MoveContact && StateNo = [200,799]

;---------------------------------------------------------------------
; �K�[�h�L�����Z���O�����h�t�����g�X�e�b�v
[State -1]
type = ChangeState
value = 4100
triggerall = Var(30) = 2
triggerall = (Command = "Power-Max" || Command = "FF")
triggerall = (Power >= 600 || (var(30) = 2 && fvar(0) > 0)) && StateType != A
trigger1 = (StateNo = 150 || StateNo = 151 || StateNo = 152 || StateNo = 153)

;---------------------------------------------------------------------
; �n��ӂ��Ƃ΂��U��
[State -1]
type = ChangeState
value = 500
triggerall = Command = "by"
trigger1 = StateType != A && (Ctrl || var(40)=1)
trigger1 = var(30) != 2

;---------------------------------------------------------------------
; �󒆂ӂ��Ƃ΂��U��
[State -1]
type = ChangeState
value = 510
triggerall = Command = "by"
trigger1 = StateType = A && Ctrl
trigger1 = var(30) != 2

;---------------------------------------------------------------------
; �K�[�h�L�����Z���ً}��𓮍�i�O�E��j
[State -1]
type = ChangeState
value = 4050
triggerall = Command = "recovery" && Power >= 1000 && var(30) != 2
triggerall = StateType != A
trigger1 = (StateNo = 150 || StateNo = 152)
trigger2 = MoveContact && Var(30) = 1 && StateNo = [200,799]

;---------------------------------------------------------------------
; �ً}��𓮍�i�O�j
[State -1]
type = ChangeState
value = 4000
triggerall = Command = "recovery" && !Command = "holdback" && var(30) != 2
trigger1 = StateType = S && (Ctrl || var(40)=1)

;---------------------------------------------------------------------
; �ً}��𓮍�i��j
[State -1]
type = ChangeState
value = 4010
triggerall = Command = "q_back" && !Command = "holdfwd" && var(30) != 2
trigger1 = StateType = S && (Ctrl || var(40)=1)

;---------------------------------------------------------------------
; �K�[�h�L�����Z��������΂��U��
[State -1]
type = ChangeState
value = 4500
triggerall = Command = "by"
triggerall = (Power >= 1000 || (var(30) = 2 && fvar(0) > 0)) && StateType != A
trigger1 = (StateNo = 150 || StateNo = 152)

;=====================================================================
; Dir + Button
;=====================================================================

;=====================================================================
; Taunts
;=====================================================================

;---------------------------------------------------------------------
; ����
[State -1]
type = ChangeState
value = 195
triggerall = command = "s"
trigger1 = StateType != A && Ctrl = 1

;=====================================================================
; Basic Arts
;=====================================================================

;---------------------------------------------------------------------
; ��p���`
[State -1]
type = ChangeState
value = IfElse(P2BodyDist X <= 15,205,200)
triggerall = Command = "x" && !Command = "holddown"
trigger1 = StateType = S && (Ctrl || var(40)=1)
trigger2  = MoveContact && ((StateNo = [200,205]) || StateNo = 235 || StateNo = 400 || StateNo = 430)
trigger3  = (StateNo = 200 && AnimElem = 3,> 0)
trigger4  = (StateNo = 205 && AnimElem = 3,> 0)
trigger5  = (StateNo = 235 && AnimElem = 5,> 0)
trigger6  = (StateNo = 400 && AnimElem = 3,> 0)
trigger7  = (StateNo = 430 && AnimElem = 5,> 0)

;---------------------------------------------------------------------
; ��L�b�N
[State -1]
type = ChangeState
value = IfElse(P2BodyDist X <= 15,235,230)
triggerall = Command = "a" && !Command = "holddown"
trigger1 = StateType = S && (Ctrl || var(40)=1)
trigger2  = MoveContact && ((StateNo = [200,205]) || StateNo = 235 || StateNo = 400 || StateNo = 430)
trigger3  = (StateNo = 200 && AnimElem = 3,> 0)
trigger4  = (StateNo = 205 && AnimElem = 3,> 0)
trigger5  = (StateNo = 235 && AnimElem = 5,> 0)
trigger6  = (StateNo = 400 && AnimElem = 3,> 0)
trigger7  = (StateNo = 430 && AnimElem = 5,> 0)

;---------------------------------------------------------------------
; ���p���`
[State -1]
type = ChangeState
value = IfElse(P2BodyDist X <= 15,215,210)
triggerall = Command = "y" && !Command = "holddown"
trigger1 = StateType = S && (Ctrl || var(40)=1)

;---------------------------------------------------------------------
; ���L�b�N
[State -1]
type = ChangeState
value = IfElse(P2BodyDist X <= 15,245,240)
triggerall = Command = "b" && !Command = "holddown"
trigger1 = StateType = S && (Ctrl || var(40)=1)

;---------------------------------------------------------------------
; ���Ⴊ�ݎ�p���`
[State -1]
type = ChangeState
value = 400
triggerall = Command = "x" && Command = "holddown"
trigger1 = StateType = C && (Ctrl || var(40)=1)
trigger2  = MoveContact && ((StateNo = [200,205]) || StateNo = 235 || StateNo = 400 || StateNo = 430)
trigger3  = (StateNo = 200 && AnimElem = 3,> 0)
trigger4  = (StateNo = 205 && AnimElem = 3,> 0)
trigger5  = (StateNo = 235 && AnimElem = 5,> 0)
trigger6  = (StateNo = 400 && AnimElem = 3,> 0)
trigger7  = (StateNo = 430 && AnimElem = 5,> 0)

;---------------------------------------------------------------------
; ���Ⴊ�݋��p���`
[State -1]
type = ChangeState
value = 410
triggerall = Command = "y" && Command = "holddown"
trigger1 = StateType = C && (Ctrl || var(40)=1)

;---------------------------------------------------------------------
; ���Ⴊ�ݎ�L�b�N
[State -1]
type = ChangeState
value = 430
triggerall = Command = "a" && Command = "holddown"
trigger1 = StateType = C && (Ctrl || var(40)=1)
trigger2  = MoveContact && ((StateNo = [200,205]) || StateNo = 235 || StateNo = 400 || StateNo = 430)
trigger3  = (StateNo = 200 && AnimElem = 3,> 0)
trigger4  = (StateNo = 205 && AnimElem = 3,> 0)
trigger5  = (StateNo = 235 && AnimElem = 5,> 0)
trigger6  = (StateNo = 400 && AnimElem = 3,> 0)
trigger7  = (StateNo = 430 && AnimElem = 5,> 0)

;---------------------------------------------------------------------
; ���Ⴊ�݋��L�b�N
[State -1]
type = ChangeState
value = 440
triggerall = Command = "b" && Command = "holddown"
trigger1 = StateType = C && (Ctrl || var(40)=1)

;---------------------------------------------------------------------
; �W�����v��p���`
[State -1]
type = ChangeState
value = IfElse(((var(32) != [2,3]) && Vel X = 0),600,605)
triggerall = Command = "x"
triggerall = StateType = A && StateNo != 105
trigger1 = Ctrl

;---------------------------------------------------------------------
; �W�����v���p���`
[State -1]
type = ChangeState
value = IfElse(((var(32) != [2,3]) && Vel X = 0),610,615)
triggerall = Command = "y"
triggerall = StateType = A && StateNo != 105
trigger1 = Ctrl

;---------------------------------------------------------------------
; �W�����v��L�b�N
[State -1]
type = ChangeState
value = IfElse(((var(32) != [2,3]) && Vel X = 0),630,635)
triggerall = Command = "a"
triggerall = StateType = A && StateNo != 105
trigger1 = Ctrl

;---------------------------------------------------------------------
; �W�����v���L�b�N
[State -1]
type = ChangeState
value = IfElse(((var(32) != [2,3]) && Vel X = 0),640,645)
triggerall = Command = "b"
triggerall = StateType = A && StateNo != 105
trigger1 = Ctrl

